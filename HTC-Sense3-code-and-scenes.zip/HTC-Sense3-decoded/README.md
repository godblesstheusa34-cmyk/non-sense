# HTC Sense 3 decoded reference — Chris's launcher project

This package contains decoded material from the supplied HTC Pyramid/Sensation
firmware 1.45.401.2 (Android 2.3.4), plus analysis tools written for this task.
It is a research and implementation reference. It is not an installable Samsung
launcher or recovered original HTC source project.

Start with FINDINGS.md, then CODEX-HANDOFF.md. Machine-readable results are in
m10/, the original code as deoptimized assembly is in smali/, and Java
decompiler reconstructions are in java/. Use smali/ to check questionable Java.

Original vendor files remain in the previously supplied HTC-Sense3-reference.zip.
native/ adds the two matching native libraries needed to identify the M10
serialization and rendering formats; these were recovered from the same ROM.

Decoded resource XML and original PNG resources are under resources/.
textures/ contains top-mip PNG exports of supported embedded M10 textures.
Each index.json maps the PNGs to source scenes and texture IDs. Native row
orientation and premultiplication are preserved; UV conventions may require
flipping or alpha conversion when adapting them to another renderer.

The package retains original proprietary HTC material supplied by the user.
It does not change its ownership or licensing. Newly written Python decoders
are separate from the reconstructed vendor code.
