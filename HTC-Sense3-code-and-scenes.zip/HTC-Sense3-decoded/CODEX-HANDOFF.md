# Instructions for the Android implementation

Read FINDINGS.md and VALIDATION.json first. This package is a decoded reference
for the Fluid Home project, not a Gradle project or an installable APK.

## Preserve the requested product

- Target Chris's Samsung Galaxy S24 Ultra and aim for fluid 120 Hz rendering.
- Use the phone's installed app icons, a static wallpaper, multiple home
  screens, and supported Android widget hosting.
- The main transition starts at the finger's swipe origin. A directional
  wave bends/lifts the icon plane, changes the shadows with depth, and reveals
  the next page behind it.
- Keep that wave as the main transition. The extracted Sense ring/cylinder
  arrangement is reference material, not a replacement for the requested design.
- This is a home launcher, not a lock-screen replacement. Weather is optional.

## Use the evidence

1. Inspect RingSlideAnimator, PageSlideControl, PageSinkControl, SettingUtil,
   RingSlideController and EaseOutCubic in java/Rosie/sources/.
2. Cross-check important behavior in smali/Rosie/ when the reconstructed Java
   is ambiguous. All five components have matching reassembled DEX files.
3. Read m10/Rosie/port/scenes/Rosie_workspace.json and Rosie_shortcut.json.
   The tree includes names, transforms, dimensions, markers and sampled tracks.
4. A controller sample record stores frame, repeat and value. The covered
   integer-frame interval is [frame, frame + repeat), relative to start_frame.
   For packed tracks, Size's high bit marks run-length compression. The stored
   count is a record count, not an animation duration.
5. Markers contain start_frame, duration_frames and an inclusive end_frame:
   end = start + max(duration, 1) - 1. Zero-duration markers identify a pose.
6. Use textures/*/index.json to map PNGs to source scene and texture ID. A
   Sprite's DiffuseMap identifies a texture; shared Fusion texture libraries
   may contain it. Preserve original image orientation/alpha until the chosen
   rendering convention is established.

## Build modern code

Implement a modern renderer and launcher behavior using the current project.
Treat extracted Java, DEX and native libraries as analysis inputs; they are
not drop-in application modules. Separate touch progress, page selection,
wave geometry, per-icon transforms and shading so the gesture remains
responsive while the animation runs.

Use the recovered 400 ms single-page snap and easing coefficients as optional
reference values to compare on-device, not as mandatory values for the new
wave. Normalize original design coordinates to the actual viewport. Account
for cancellation, interrupted swipes, velocity, changing direction, widget
touch routing, and Android lifecycle behavior.

Maintain the repository's APK build workflow. Produce a downloadable debug
APK through the project's established CI path. Verify the gesture and frame
timing on the S24 Ultra before claiming that 120 Hz has been achieved.

## Do not overstate the recovery

There is no complete native renderer port here. Unknown M10 fields remain
explicitly opaque. Do not replace them with guessed values while describing
the result as an exact recreation. Document which behavior is recovered,
which is inferred, and which is new implementation.
