# What was recovered

The supplied HTC Sensation/Pyramid ROM contains usable information about the
original Sense 3 launcher: readable reconstructed code, scene hierarchies,
animation samples, named animation ranges, resource XML, and embedded graphics.
This is substantially more useful than an extracted APK alone. It is still
reference material, not a completed port to the Samsung S24 Ultra.

## Recovery results

| Component | M10 files | Decoded animation track instances | Embedded PNG exports |
|---|---:|---:|---:|
| Rosie launcher | 54 | 212 | 23 |
| 3D clock widgets | 58 | 2,422 | 181 |
| 3D weather widgets | 87 | 9,563 | 2 |
| Shared Fusion graphics | 3 | 0 | 625 |
| Total | 202 | 12,197 | 831 |

Track counts include repeated tracks across related scenes. They are not a
count of unique effects. PNGs are deduplicated within each component; identical
images can still occur in different components. The 831 exports cover 1,083
texture references. Eleven weather textures in format 14 remain unexported.
Existing ordinary PNGs from the APKs are also included under resources/ and
are not included in this table.

Five ODEX components were deoptimized, reassembled into standard DEX files,
and decompiled into Java: Rosie, HtcClock3DWidget, HtcWeather3DWidget,
com.htc.fusion.fx, and com.htc.android.rosie. See VALIDATION.json for class counts
and checksums. The Java is a decompiler reconstruction, not HTC's original
source. Smali is included for checking uncertain Java translations.

## Specific launcher findings

### Layout and transitions

The decoded integer resources specify seven home screens, default screen
index 3, and a 4 by 4 workspace grid. The workspace scene has a 540 by 960
design canvas; page containers have 530 by 748 dimensions. These are original
design coordinates, not values to apply unchanged to the S24 Ultra.

The active configuration enables ring sliding. The main movement is split
between Page_Slide_X, Page_Slide_Z, page containers, and their child timelines.
Page containers carry positions and quaternion rotations. The source also
contains a separate page-slide implementation; its presence does not mean it
is the active configuration for this ROM.

Evidence: resources/Rosie/res/values/integers.xml;
m10/Rosie/port/scenes/Rosie_workspace.json;
java/Rosie/sources/com/htc/launcher/settings/SettingUtil.java;
java/Rosie/sources/com/htc/android/rosie/home/fxcontrol/PageSlideControl.java.

### Finger movement directly selects animation frames

RingSlideAnimator chooses an animation marker according to the page,
direction, and scrolling state. For a leftward adjacent-page transition,
the essential mapping is:

    frame = marker.StartFrame +
            (marker.EndFrame - marker.StartFrame + 1) * swipe_fraction

For the 0-to-1 marker, the binary stores start 357 and duration 30.
The Java-facing inclusive end is 386. The formula advances from 357 toward
387 as the swipe fraction approaches 1; 387 is the next segment's boundary.
This distinction avoids an off-by-one error in reproducing the movement.

Examples from Page_Slide_X:

| Marker | Start | Stored duration | Inclusive end |
|---|---:|---:|---:|
| 0to1 | 357 | 30 | 386 |
| 1to2 | 387 | 30 | 416 |
| 2to3 | 417 | 30 | 446 |
| 6to0 | 537 | 60 | 596 |
| 0to6 | 600 | 60 | 659 |
| s_0to1 | 850 | 30 | 879 |

The range names, coordinates and samples are decoded from the files. How they
combine into a rendered image still depends on the native scene graph and
control implementation. A full renderer has not been reconstructed.

Evidence: RingSlideAnimator.java and Rosie_workspace.json; native marker
conversion in NATIVE-FORMAT-EVIDENCE.txt.

### The normal configured single-page snap is 400 milliseconds

SettingUtil.loadSettings overrides the initial 650 ms field value with
AddAdapter.EXCUTE_SHORTCUT, which resolves to 400. RingSlideController uses
that duration for the ordinary one-page case. Multi-page and home-return
paths have different durations; 400 ms is not a universal duration for Sense.

The short-scroll easing function is a fifth-degree polynomial, despite the
class being named EaseOutCubic. With normalized elapsed time t in [0,1]:

    eased = 5.5*t - 13*t^2 + 16*t^3 - 10*t^4 + 2.5*t^5

The long-scroll coefficients are also present in SettingUtil. The old
Java scrolling loop schedules callbacks with a 16 ms delay. A modern app
should use the device's display frame timing rather than copying that loop.

Evidence: SettingUtil.java, AddAdapter.java, RingSlideController.java,
SlideController.java, and widget/EaseOutCubic.java under java/Rosie/sources/
com/htc/launcher/.

### Animation frames are not display refresh rate or fixed playback time

The main workspace stores FramesPerSecond near 29.97, but swipe-driven code
sets frame positions directly. A 30-frame range therefore does not establish
a one-second swipe, and the file's frame rate is not a 30 Hz limit on a new
renderer. Preserve continuous progress and interpolate deliberately when
adapting sampled data to a display running at a higher refresh rate.

### Depth movement has its own control

PageSinkControl maps scroll progress onto a sine-shaped depth excursion,
then maps that result onto the z_move marker using the sink extent. When
starting from rest, the basic sink amount is sin(pi * progress). Continued
gestures carry phase state, so the actual control is more involved than a
single fixed sine curve.

Evidence: java/Rosie/sources/com/htc/android/rosie/home/fxcontrol/PageSinkControl.java.

## What is still unresolved

- No complete rendering or runtime test has been performed on HTC hardware,
  an emulator, or the S24 Ultra. The APKs have not become portable by decoding.
- Native control metadata, some property types, font payloads and other
  binary fields remain opaque. Their offsets and SHA256 hashes are retained.
- The full scene graph evaluation, texture UV conventions, blending,
  quaternion interpolation and native control behavior have not been reproduced.
- Eleven format-14 weather textures were preserved as referenced binary
  payloads rather than assigned a guessed PNG interpretation.
- PNG exports preserve native row order and premultiplication. Some textures
  look inverted in a normal image viewer because their original texture
  coordinates determine orientation. The exports are not preprocessed assets
  guaranteed to look correct when dropped into another renderer.
- The original renderer is a proprietary 32-bit ARM component with HTC/old
  Android dependencies. This package does not provide a modern replacement.

## What this means for Chris's launcher

Codex can now study actual gesture-to-animation mappings, easing coefficients,
depth control, layout resources and sampled transforms. Those can inform the
modern app's behavior and design. Chris's requested finger-origin wave that
bends/lifts icons is a new effect; it was not found as a ready-made Sense
feature. The implementation should preserve that goal and use Sense's depth
and fluidity as reference.
