.class public Lcom/htc/widget3d/weather/Weather2x2Widget;
.super Lcom/htc/widget3d/weather/WeatherWidgetBaseMed;
.source "Weather2x2Widget.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/htc/widget3d/weather/Weather2x2Widget$GetFxControls;
    }
.end annotation


# static fields
.field private static final ASSET_FORECAST_M10PATH:Ljava/lang/String; = "scenes/forecast_state/"

.field private static final TAG:Ljava/lang/String; = "WeatherWidget2x2"


# instance fields
.field protected SZ_DEFAULT_M10PATH:Ljava/lang/String;

.field protected SZ_DEFAULT_M10PATH_LAND:Ljava/lang/String;

.field private WEATHER_COUNT:I

.field private fx_HitBox:Lcom/htc/fusion/fx/controls/FxHitbox;

.field private fx_Status:Lcom/htc/fusion/fx/FxScene;

.field private fxsc_Status:Lcom/htc/fusion/fx/controls/FxSceneContainer;

.field private fxtc_Status:Lcom/htc/fusion/fx/FxTimelineControl;

.field private fxtc_Weather:Lcom/htc/fusion/fx/FxTimelineControl;

.field private fxtl_City:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field private fxtl_Condition:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field private fxtl_Empty:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field private fxtl_EmptyCity:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field private fxtl_HL:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field private fxtl_Temp:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field private isNeedInitState:Z

.field private isWeatherDataAvalible:Z

.field private landScene:Lcom/htc/fusion/fx/FxScene;

.field private mCityIndex:I

.field private mGetFxControls:Lcom/htc/widget3d/weather/Weather2x2Widget$GetFxControls;

.field private mTapListener:Lcom/htc/fusion/fx/MessageListener;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/htc/fusion/fx/MessageListener",
            "<",
            "Lcom/htc/fusion/fx/controls/FxHitbox$TapParameters;",
            ">;"
        }
    .end annotation
.end field

.field protected mWidgetID:I

.field protected mWorker:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

.field private m_WeaInfo:Lcom/htc/widget3d/weather/WeatherInfo2x2;

.field private m_bInitial:Z

.field private m_fxScene:Lcom/htc/fusion/fx/FxScene;

.field private m_nTiltEndFrame:I

.field private m_nTiltStartFrame:I

.field private m_timelineTilt:Lcom/htc/fusion/fx/FxTimelineControl;

.field private portScene:Lcom/htc/fusion/fx/FxScene;


# direct methods
.method public constructor <init>()V
    .registers 4

    .prologue
    const/4 v2, 0x0

    const/4 v1, 0x0

    .line 36
    invoke-direct {p0}, Lcom/htc/widget3d/weather/WeatherWidgetBaseMed;-><init>()V

    .line 40
    const-string v0, "scenes/Weather_2x2.m10"

    iput-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->SZ_DEFAULT_M10PATH:Ljava/lang/String;

    .line 41
    const-string v0, "scenes/Weather_2x2_land.m10"

    iput-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->SZ_DEFAULT_M10PATH_LAND:Ljava/lang/String;

    .line 44
    const/4 v0, 0x1

    iput v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->WEATHER_COUNT:I

    .line 48
    iput-boolean v1, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->isWeatherDataAvalible:Z

    .line 49
    iput-boolean v1, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->isNeedInitState:Z

    .line 51
    iput v1, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->mCityIndex:I

    .line 52
    const/4 v0, 0x2

    iput v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->mWidgetID:I

    .line 59
    iput-object v2, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtl_Condition:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 271
    iput-object v2, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_timelineTilt:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 272
    iput v1, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_nTiltStartFrame:I

    .line 273
    iput v1, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_nTiltEndFrame:I

    .line 324
    return-void
.end method

.method static synthetic access$000(Lcom/htc/widget3d/weather/Weather2x2Widget;)Lcom/htc/android/rosie/widget/Widget$Host;
    .registers 2
    .param p0, "x0"    # Lcom/htc/widget3d/weather/Weather2x2Widget;

    .prologue
    .line 36
    invoke-virtual {p0}, Lcom/htc/widget3d/weather/Weather2x2Widget;->getHost()Lcom/htc/android/rosie/widget/Widget$Host;

    move-result-object v0

    return-object v0
.end method

.method static synthetic access$100(Lcom/htc/widget3d/weather/Weather2x2Widget;)Landroid/content/Context;
    .registers 2
    .param p0, "x0"    # Lcom/htc/widget3d/weather/Weather2x2Widget;

    .prologue
    .line 36
    invoke-virtual {p0}, Lcom/htc/widget3d/weather/Weather2x2Widget;->getContext()Landroid/content/Context;

    move-result-object v0

    return-object v0
.end method

.method static synthetic access$200(Lcom/htc/widget3d/weather/Weather2x2Widget;)V
    .registers 1
    .param p0, "x0"    # Lcom/htc/widget3d/weather/Weather2x2Widget;

    .prologue
    .line 36
    invoke-direct {p0}, Lcom/htc/widget3d/weather/Weather2x2Widget;->initWeatherControl()V

    return-void
.end method

.method static synthetic access$300(Lcom/htc/widget3d/weather/Weather2x2Widget;)Z
    .registers 2
    .param p0, "x0"    # Lcom/htc/widget3d/weather/Weather2x2Widget;

    .prologue
    .line 36
    iget-boolean v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->isWeatherDataAvalible:Z

    return v0
.end method

.method static synthetic access$400(Lcom/htc/widget3d/weather/Weather2x2Widget;)V
    .registers 1
    .param p0, "x0"    # Lcom/htc/widget3d/weather/Weather2x2Widget;

    .prologue
    .line 36
    invoke-direct {p0}, Lcom/htc/widget3d/weather/Weather2x2Widget;->initWeatherState()V

    return-void
.end method

.method static synthetic access$500(Lcom/htc/widget3d/weather/Weather2x2Widget;)Landroid/content/Context;
    .registers 2
    .param p0, "x0"    # Lcom/htc/widget3d/weather/Weather2x2Widget;

    .prologue
    .line 36
    invoke-virtual {p0}, Lcom/htc/widget3d/weather/Weather2x2Widget;->getContext()Landroid/content/Context;

    move-result-object v0

    return-object v0
.end method

.method static synthetic access$600(Lcom/htc/widget3d/weather/Weather2x2Widget;)Landroid/content/Context;
    .registers 2
    .param p0, "x0"    # Lcom/htc/widget3d/weather/Weather2x2Widget;

    .prologue
    .line 36
    invoke-virtual {p0}, Lcom/htc/widget3d/weather/Weather2x2Widget;->getContext()Landroid/content/Context;

    move-result-object v0

    return-object v0
.end method

.method private initWeatherControl()V
    .registers 11

    .prologue
    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x2

    .line 186
    const-string v3, "WeatherWidget2x2"

    const-string v4, "InitWeatherControl"

    invoke-static {v3, v4}, Lcom/htc/widget3d/weather/util/LOG;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 188
    invoke-virtual {p0}, Lcom/htc/widget3d/weather/Weather2x2Widget;->getScene()Lcom/htc/fusion/fx/FxScene;

    move-result-object v3

    iput-object v3, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_fxScene:Lcom/htc/fusion/fx/FxScene;

    .line 190
    iget-object v3, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_fxScene:Lcom/htc/fusion/fx/FxScene;

    if-nez v3, :cond_17

    .line 223
    :goto_16
    return-void

    .line 191
    :cond_17
    iget v3, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->mWidgetID:I

    if-eq v3, v5, :cond_1f

    iget v3, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->mWidgetID:I

    if-ne v3, v6, :cond_b6

    .line 192
    :cond_1f
    const/16 v3, 0xa

    new-array v2, v3, [Ljava/lang/String;

    const-string v3, "timeline.weather"

    aput-object v3, v2, v7

    const-string v3, "panel.hitbox"

    aput-object v3, v2, v8

    const-string v3, "textlabel.empty_city"

    aput-object v3, v2, v5

    const-string v3, "textlabel.empty_page"

    aput-object v3, v2, v6

    const-string v3, "timeline.tilt_weather"

    aput-object v3, v2, v9

    const/4 v3, 0x5

    const-string v4, "scenecontainer.weather_state"

    aput-object v4, v2, v3

    const/4 v3, 0x6

    const-string v4, "textlabel.city"

    aput-object v4, v2, v3

    const/4 v3, 0x7

    const-string v4, "textlabel.temp"

    aput-object v4, v2, v3

    const/16 v3, 0x8

    const-string v4, "textlabel.H_L"

    aput-object v4, v2, v3

    const/16 v3, 0x9

    const-string v4, "textlabel.weather"

    aput-object v4, v2, v3

    .line 198
    .local v2, "szArrary":[Ljava/lang/String;
    iget-object v3, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_fxScene:Lcom/htc/fusion/fx/FxScene;

    invoke-virtual {v3, v2}, Lcom/htc/fusion/fx/FxScene;->getDescendants([Ljava/lang/String;)[Lcom/htc/fusion/fx/FxObject;

    move-result-object v0

    .line 199
    .local v0, "itemArray":[Lcom/htc/fusion/fx/FxObject;
    aget-object v3, v0, v7

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtc_Weather:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 200
    aget-object v3, v0, v8

    check-cast v3, Lcom/htc/fusion/fx/controls/FxHitbox;

    iput-object v3, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fx_HitBox:Lcom/htc/fusion/fx/controls/FxHitbox;

    .line 201
    aget-object v3, v0, v5

    check-cast v3, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v3, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtl_EmptyCity:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 202
    aget-object v3, v0, v6

    check-cast v3, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v3, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtl_Empty:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 203
    aget-object v3, v0, v9

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_timelineTilt:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 204
    const/4 v3, 0x5

    aget-object v3, v0, v3

    check-cast v3, Lcom/htc/fusion/fx/controls/FxSceneContainer;

    iput-object v3, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxsc_Status:Lcom/htc/fusion/fx/controls/FxSceneContainer;

    .line 205
    const/4 v3, 0x6

    aget-object v3, v0, v3

    check-cast v3, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v3, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtl_City:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 206
    const/4 v3, 0x7

    aget-object v3, v0, v3

    check-cast v3, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v3, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtl_Temp:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 207
    const/16 v3, 0x8

    aget-object v3, v0, v3

    check-cast v3, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v3, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtl_HL:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 208
    const/16 v3, 0x9

    aget-object v3, v0, v3

    check-cast v3, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v3, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtl_Condition:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 210
    iget-object v3, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_timelineTilt:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v3, :cond_b1

    .line 211
    iget-object v3, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_timelineTilt:Lcom/htc/fusion/fx/FxTimelineControl;

    const-string v4, "tilt"

    invoke-virtual {v3, v4}, Lcom/htc/fusion/fx/FxTimelineControl;->getMarker(Ljava/lang/String;)Lcom/htc/fusion/fx/Marker;

    move-result-object v1

    .line 212
    .local v1, "marker":Lcom/htc/fusion/fx/Marker;
    if-eqz v1, :cond_b1

    .line 213
    iget v3, v1, Lcom/htc/fusion/fx/Marker;->StartFrame:I

    iput v3, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_nTiltStartFrame:I

    .line 214
    iget v3, v1, Lcom/htc/fusion/fx/Marker;->EndFrame:I

    iput v3, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_nTiltEndFrame:I

    .line 221
    .end local v0    # "itemArray":[Lcom/htc/fusion/fx/FxObject;
    .end local v1    # "marker":Lcom/htc/fusion/fx/Marker;
    .end local v2    # "szArrary":[Ljava/lang/String;
    :cond_b1
    :goto_b1
    invoke-direct {p0}, Lcom/htc/widget3d/weather/Weather2x2Widget;->setHitBox()V

    goto/16 :goto_16

    .line 219
    :cond_b6
    const-string v3, "WeatherWidget2x2"

    const-string v4, "invalid widgetID"

    invoke-static {v3, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_b1
.end method

.method private initWeatherInfo()V
    .registers 4

    .prologue
    const-string v2, ""

    .line 151
    const-string v0, "WeatherWidget2x2"

    const-string v1, "initWeatherInfo"

    invoke-static {v0, v1}, Lcom/htc/widget3d/weather/util/LOG;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 152
    new-instance v0, Lcom/htc/widget3d/weather/WeatherInfo2x2;

    invoke-direct {v0}, Lcom/htc/widget3d/weather/WeatherInfo2x2;-><init>()V

    iput-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_WeaInfo:Lcom/htc/widget3d/weather/WeatherInfo2x2;

    .line 153
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_WeaInfo:Lcom/htc/widget3d/weather/WeatherInfo2x2;

    const-string v1, ""

    iput-object v2, v0, Lcom/htc/widget3d/weather/WeatherInfo2x2;->szCity:Ljava/lang/String;

    .line 154
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_WeaInfo:Lcom/htc/widget3d/weather/WeatherInfo2x2;

    const-string v1, ""

    iput-object v2, v0, Lcom/htc/widget3d/weather/WeatherInfo2x2;->szDescription:Ljava/lang/String;

    .line 155
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_WeaInfo:Lcom/htc/widget3d/weather/WeatherInfo2x2;

    const-string v1, ""

    iput-object v2, v0, Lcom/htc/widget3d/weather/WeatherInfo2x2;->szCurTemp:Ljava/lang/String;

    .line 156
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_WeaInfo:Lcom/htc/widget3d/weather/WeatherInfo2x2;

    const-string v1, ""

    iput-object v2, v0, Lcom/htc/widget3d/weather/WeatherInfo2x2;->curHitemp:Ljava/lang/String;

    .line 157
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_WeaInfo:Lcom/htc/widget3d/weather/WeatherInfo2x2;

    const-string v1, ""

    iput-object v2, v0, Lcom/htc/widget3d/weather/WeatherInfo2x2;->curLowTemp:Ljava/lang/String;

    .line 158
    return-void
.end method

.method private initWeatherState()V
    .registers 4

    .prologue
    .line 145
    const-string v0, "WeatherWidget2x2"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "condition:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_WeaInfo:Lcom/htc/widget3d/weather/WeatherInfo2x2;

    iget-object v2, v2, Lcom/htc/widget3d/weather/WeatherInfo2x2;->szDescription:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 146
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_WeaInfo:Lcom/htc/widget3d/weather/WeatherInfo2x2;

    invoke-virtual {p0, v0}, Lcom/htc/widget3d/weather/Weather2x2Widget;->setInfoToControl(Lcom/htc/widget3d/weather/WeatherInfo2x2;)V

    .line 147
    invoke-virtual {p0}, Lcom/htc/widget3d/weather/Weather2x2Widget;->playWeatherUpdate()V

    .line 148
    return-void
.end method

.method private setHitBox()V
    .registers 3

    .prologue
    const/4 v1, 0x1

    .line 227
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fx_HitBox:Lcom/htc/fusion/fx/controls/FxHitbox;

    if-nez v0, :cond_d

    .line 228
    const-string v0, "WeatherWidget2x2"

    const-string v1, "Control Hitbox.weather == null !!"

    invoke-static {v0, v1}, Lcom/htc/widget3d/weather/util/LOG;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 269
    :goto_c
    return-void

    .line 231
    :cond_d
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fx_HitBox:Lcom/htc/fusion/fx/controls/FxHitbox;

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/controls/FxHitbox;->setEnabledGestures(I)V

    .line 232
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fx_HitBox:Lcom/htc/fusion/fx/controls/FxHitbox;

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/controls/FxHitbox;->setEnabled(Z)V

    .line 234
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->mTapListener:Lcom/htc/fusion/fx/MessageListener;

    if-nez v0, :cond_22

    .line 235
    new-instance v0, Lcom/htc/widget3d/weather/Weather2x2Widget$1;

    invoke-direct {v0, p0}, Lcom/htc/widget3d/weather/Weather2x2Widget$1;-><init>(Lcom/htc/widget3d/weather/Weather2x2Widget;)V

    iput-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->mTapListener:Lcom/htc/fusion/fx/MessageListener;

    .line 266
    :cond_22
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fx_HitBox:Lcom/htc/fusion/fx/controls/FxHitbox;

    invoke-virtual {v0}, Lcom/htc/fusion/fx/controls/FxHitbox;->getTapSource()Lcom/htc/fusion/fx/IMessageSource;

    move-result-object v0

    if-eqz v0, :cond_33

    .line 267
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fx_HitBox:Lcom/htc/fusion/fx/controls/FxHitbox;

    invoke-virtual {v0}, Lcom/htc/fusion/fx/controls/FxHitbox;->getTapSource()Lcom/htc/fusion/fx/IMessageSource;

    move-result-object v0

    invoke-interface {v0}, Lcom/htc/fusion/fx/IMessageSource;->unbindAll()V

    .line 268
    :cond_33
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fx_HitBox:Lcom/htc/fusion/fx/controls/FxHitbox;

    invoke-virtual {v0}, Lcom/htc/fusion/fx/controls/FxHitbox;->getTapSource()Lcom/htc/fusion/fx/IMessageSource;

    move-result-object v0

    iget-object v1, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->mTapListener:Lcom/htc/fusion/fx/MessageListener;

    invoke-interface {v0, v1}, Lcom/htc/fusion/fx/IMessageSource;->bind(Lcom/htc/fusion/fx/IMessageListener;)V

    goto :goto_c
.end method

.method private updateWeatherInfo()V
    .registers 7

    .prologue
    const-string v5, "\u00b0"

    const-string v4, "WeatherWidget2x2"

    .line 162
    const-string v2, "WeatherWidget2x2"

    const-string v2, "updateWeatherInfo"

    invoke-static {v4, v2}, Lcom/htc/widget3d/weather/util/LOG;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 163
    iget-object v2, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->mCityInfo:Lcom/htc/widget3d/weather/data/CityInfo;

    if-eqz v2, :cond_9e

    .line 164
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->mCityInfo:Lcom/htc/widget3d/weather/data/CityInfo;

    .line 166
    .local v0, "cityinfo":Lcom/htc/widget3d/weather/data/CityInfo;
    invoke-virtual {v0}, Lcom/htc/widget3d/weather/data/CityInfo;->getCity()Lcom/htc/widget3d/weather/data/City;

    move-result-object v2

    iget-object v2, v2, Lcom/htc/widget3d/weather/data/City;->current:Lcom/htc/widget3d/weather/data/City$Condition;

    invoke-virtual {v2}, Lcom/htc/widget3d/weather/data/City$Condition;->today()Lcom/htc/widget3d/weather/data/DayForecast;

    move-result-object v1

    .line 167
    .local v1, "today":Lcom/htc/widget3d/weather/data/DayForecast;
    iget-object v2, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_WeaInfo:Lcom/htc/widget3d/weather/WeatherInfo2x2;

    iget-object v3, v0, Lcom/htc/widget3d/weather/data/CityInfo;->displayName:Ljava/lang/String;

    iput-object v3, v2, Lcom/htc/widget3d/weather/WeatherInfo2x2;->szCity:Ljava/lang/String;

    .line 168
    iget-boolean v2, v0, Lcom/htc/widget3d/weather/data/CityInfo;->hasWeatherData:Z

    if-eqz v2, :cond_9d

    .line 169
    const-string v2, "WeatherWidget2x2"

    const-string v2, "cityinfo.hasWeatherData"

    invoke-static {v4, v2}, Lcom/htc/widget3d/weather/util/LOG;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 170
    const/4 v2, 0x1

    iput-boolean v2, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->isWeatherDataAvalible:Z

    .line 171
    iget-boolean v2, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->isWeatherDataAvalible:Z

    iput-boolean v2, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->isNeedInitState:Z

    .line 172
    iget-object v2, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_WeaInfo:Lcom/htc/widget3d/weather/WeatherInfo2x2;

    invoke-virtual {v1}, Lcom/htc/widget3d/weather/data/DayForecast;->getCondition()Ljava/lang/String;

    move-result-object v3

    iput-object v3, v2, Lcom/htc/widget3d/weather/WeatherInfo2x2;->szDescription:Ljava/lang/String;

    .line 173
    iget-object v2, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_WeaInfo:Lcom/htc/widget3d/weather/WeatherInfo2x2;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v4, Lcom/htc/widget3d/weather/Weather2x2Widget;->mUnit:Lcom/htc/widget3d/weather/data/City$UNIT;

    invoke-virtual {v1, v4}, Lcom/htc/widget3d/weather/data/DayForecast;->getCurrent(Lcom/htc/widget3d/weather/data/City$UNIT;)I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "\u00b0"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    iput-object v3, v2, Lcom/htc/widget3d/weather/WeatherInfo2x2;->szCurTemp:Ljava/lang/String;

    .line 174
    iget-object v2, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_WeaInfo:Lcom/htc/widget3d/weather/WeatherInfo2x2;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v4, Lcom/htc/widget3d/weather/Weather2x2Widget;->mUnit:Lcom/htc/widget3d/weather/data/City$UNIT;

    invoke-virtual {v1, v4}, Lcom/htc/widget3d/weather/data/DayForecast;->getHigh(Lcom/htc/widget3d/weather/data/City$UNIT;)I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "\u00b0"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    iput-object v3, v2, Lcom/htc/widget3d/weather/WeatherInfo2x2;->curHitemp:Ljava/lang/String;

    .line 175
    iget-object v2, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_WeaInfo:Lcom/htc/widget3d/weather/WeatherInfo2x2;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    sget-object v4, Lcom/htc/widget3d/weather/Weather2x2Widget;->mUnit:Lcom/htc/widget3d/weather/data/City$UNIT;

    invoke-virtual {v1, v4}, Lcom/htc/widget3d/weather/data/DayForecast;->getLow(Lcom/htc/widget3d/weather/data/City$UNIT;)I

    move-result v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, "\u00b0"

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    iput-object v3, v2, Lcom/htc/widget3d/weather/WeatherInfo2x2;->curLowTemp:Ljava/lang/String;

    .line 176
    iget-object v2, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_WeaInfo:Lcom/htc/widget3d/weather/WeatherInfo2x2;

    invoke-virtual {v1}, Lcom/htc/widget3d/weather/data/DayForecast;->getForecastIcon()I

    move-result v3

    iput v3, v2, Lcom/htc/widget3d/weather/WeatherInfo2x2;->condition:I

    .line 177
    invoke-direct {p0}, Lcom/htc/widget3d/weather/Weather2x2Widget;->initWeatherState()V

    .line 183
    .end local v0    # "cityinfo":Lcom/htc/widget3d/weather/data/CityInfo;
    .end local v1    # "today":Lcom/htc/widget3d/weather/data/DayForecast;
    :cond_9d
    :goto_9d
    return-void

    .line 181
    :cond_9e
    const-string v2, "WeatherWidget2x2"

    const-string v2, "mCityInfo == null"

    invoke-static {v4, v2}, Lcom/htc/widget3d/weather/util/LOG;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_9d
.end method


# virtual methods
.method protected finalize()V
    .registers 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    .prologue
    .line 85
    invoke-super {p0}, Ljava/lang/Object;->finalize()V

    .line 86
    const-string v0, "WeatherWidget2x2"

    const-string v1, "mem : finalize called"

    invoke-static {v0, v1}, Lcom/htc/widget3d/weather/util/LOG;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 87
    return-void
.end method

.method protected getScene()Lcom/htc/fusion/fx/FxScene;
    .registers 4

    .prologue
    .line 91
    const-string v0, "WeatherWidget2x2"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "getScene() , isPortrait=="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    sget-boolean v2, Lcom/htc/widget3d/weather/Weather2x2Widget;->isPortrait:Z

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/htc/widget3d/weather/util/LOG;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 92
    sget-boolean v0, Lcom/htc/widget3d/weather/Weather2x2Widget;->isPortrait:Z

    if-eqz v0, :cond_21

    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->portScene:Lcom/htc/fusion/fx/FxScene;

    :goto_20
    return-object v0

    :cond_21
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->landScene:Lcom/htc/fusion/fx/FxScene;

    goto :goto_20
.end method

.method protected initData()V
    .registers 3

    .prologue
    .line 138
    invoke-super {p0}, Lcom/htc/widget3d/weather/WeatherWidgetBaseMed;->initData()V

    .line 139
    const-string v0, "WeatherWidget2x2"

    const-string v1, "updateData"

    invoke-static {v0, v1}, Lcom/htc/widget3d/weather/util/LOG;->i(Ljava/lang/String;Ljava/lang/String;)V

    .line 140
    invoke-direct {p0}, Lcom/htc/widget3d/weather/Weather2x2Widget;->updateWeatherInfo()V

    .line 141
    return-void
.end method

.method protected initWidget()V
    .registers 2

    .prologue
    .line 125
    invoke-super {p0}, Lcom/htc/widget3d/weather/WeatherWidgetBaseMed;->initWidget()V

    .line 127
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_WeaInfo:Lcom/htc/widget3d/weather/WeatherInfo2x2;

    if-nez v0, :cond_a

    .line 128
    invoke-direct {p0}, Lcom/htc/widget3d/weather/Weather2x2Widget;->initWeatherInfo()V

    .line 129
    :cond_a
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->mGetFxControls:Lcom/htc/widget3d/weather/Weather2x2Widget$GetFxControls;

    if-eqz v0, :cond_11

    .line 130
    invoke-direct {p0}, Lcom/htc/widget3d/weather/Weather2x2Widget;->initWeatherControl()V

    .line 134
    :cond_11
    return-void
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .registers 5
    .param p1, "newConfiguration"    # Landroid/content/res/Configuration;

    .prologue
    const/4 v2, 0x1

    .line 97
    invoke-super {p0, p1}, Lcom/htc/widget3d/weather/WeatherWidgetBaseMed;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 98
    const-string v0, "WeatherWidget2x2"

    const-string v1, "onConfigurationChanged"

    invoke-static {v0, v1}, Lcom/htc/widget3d/weather/util/LOG;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 100
    iget v0, p1, Landroid/content/res/Configuration;->orientation:I

    if-ne v2, v0, :cond_1e

    move v0, v2

    :goto_10
    sput-boolean v0, Lcom/htc/widget3d/weather/Weather2x2Widget;->isPortrait:Z

    .line 103
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->mWorker:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    if-eqz v0, :cond_1d

    .line 104
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->mWorker:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    iget-object v1, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->mGetFxControls:Lcom/htc/widget3d/weather/Weather2x2Widget$GetFxControls;

    invoke-interface {v0, v1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->cancel(Ljava/lang/Runnable;)V

    .line 106
    :cond_1d
    return-void

    .line 100
    :cond_1e
    const/4 v0, 0x0

    goto :goto_10
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .registers 5
    .param p1, "saved"    # Landroid/os/Bundle;

    .prologue
    const/4 v2, 0x1

    .line 67
    invoke-super {p0, p1}, Lcom/htc/widget3d/weather/WeatherWidgetBaseMed;->onCreate(Landroid/os/Bundle;)V

    .line 69
    const-string v0, "WeatherWidget2x2"

    const-string v1, "onCreate"

    invoke-static {v0, v1}, Lcom/htc/widget3d/weather/util/LOG;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 71
    invoke-virtual {p0}, Lcom/htc/widget3d/weather/Weather2x2Widget;->getHost()Lcom/htc/android/rosie/widget/Widget$Host;

    move-result-object v0

    invoke-interface {v0}, Lcom/htc/android/rosie/widget/Widget$Host;->getWorker()Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    move-result-object v0

    iput-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->mWorker:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    .line 72
    invoke-virtual {p0}, Lcom/htc/widget3d/weather/Weather2x2Widget;->getHost()Lcom/htc/android/rosie/widget/Widget$Host;

    move-result-object v0

    iget-object v1, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->SZ_DEFAULT_M10PATH:Ljava/lang/String;

    invoke-interface {v0, v1, v2}, Lcom/htc/android/rosie/widget/Widget$Host;->createScene(Ljava/lang/String;Z)Lcom/htc/fusion/fx/FxScene;

    move-result-object v0

    iput-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->portScene:Lcom/htc/fusion/fx/FxScene;

    .line 74
    invoke-virtual {p0}, Lcom/htc/widget3d/weather/Weather2x2Widget;->getHost()Lcom/htc/android/rosie/widget/Widget$Host;

    move-result-object v0

    iget-object v1, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->SZ_DEFAULT_M10PATH_LAND:Ljava/lang/String;

    invoke-interface {v0, v1, v2}, Lcom/htc/android/rosie/widget/Widget$Host;->createScene(Ljava/lang/String;Z)Lcom/htc/fusion/fx/FxScene;

    move-result-object v0

    iput-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->landScene:Lcom/htc/fusion/fx/FxScene;

    .line 79
    new-instance v0, Lcom/htc/widget3d/weather/Weather2x2Widget$GetFxControls;

    invoke-direct {v0, p0}, Lcom/htc/widget3d/weather/Weather2x2Widget$GetFxControls;-><init>(Lcom/htc/widget3d/weather/Weather2x2Widget;)V

    iput-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->mGetFxControls:Lcom/htc/widget3d/weather/Weather2x2Widget$GetFxControls;

    .line 80
    return-void
.end method

.method protected onHostMessage(Landroid/os/Message;)V
    .registers 4
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    .line 110
    iget v0, p1, Landroid/os/Message;->what:I

    packed-switch v0, :pswitch_data_22

    .line 120
    :goto_5
    invoke-super {p0, p1}, Lcom/htc/widget3d/weather/WeatherWidgetBaseMed;->onHostMessage(Landroid/os/Message;)V

    .line 121
    return-void

    .line 112
    :pswitch_9
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->mWorker:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    if-eqz v0, :cond_1c

    .line 113
    const-string v0, "WeatherWidget2x2"

    const-string v1, "HOST_ORIENTATION_CHANGE_COMPLETE"

    invoke-static {v0, v1}, Lcom/htc/widget3d/weather/util/LOG;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 114
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->mWorker:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    iget-object v1, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->mGetFxControls:Lcom/htc/widget3d/weather/Weather2x2Widget$GetFxControls;

    invoke-interface {v0, v1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->post(Ljava/lang/Runnable;)V

    goto :goto_5

    .line 117
    :cond_1c
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->mGetFxControls:Lcom/htc/widget3d/weather/Weather2x2Widget$GetFxControls;

    invoke-virtual {v0}, Lcom/htc/widget3d/weather/Weather2x2Widget$GetFxControls;->run()V

    goto :goto_5

    .line 110
    :pswitch_data_22
    .packed-switch 0x3
        :pswitch_9
    .end packed-switch
.end method

.method public onTiltChanged(F)V
    .registers 5
    .param p1, "fTilt"    # F

    .prologue
    .line 277
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_timelineTilt:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_11

    .line 278
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_timelineTilt:Lcom/htc/fusion/fx/FxTimelineControl;

    iget v1, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_nTiltStartFrame:I

    iget v2, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->m_nTiltEndFrame:I

    invoke-static {p1, v1, v2}, Lcom/htc/android/rosie/widget/WidgetHelper;->convertTiltAngleToFrame(FII)F

    move-result v1

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/FxTimelineControl;->setFrame(F)V

    .line 279
    :cond_11
    return-void
.end method

.method protected playEmptyPage(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5
    .param p1, "city"    # Ljava/lang/String;
    .param p2, "error_msg"    # Ljava/lang/String;

    .prologue
    .line 286
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtl_Empty:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_9

    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtl_Empty:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v0, p2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 287
    :cond_9
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtl_EmptyCity:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_12

    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtl_EmptyCity:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v0, p1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 288
    :cond_12
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtc_Weather:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_1e

    .line 289
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtc_Weather:Lcom/htc/fusion/fx/FxTimelineControl;

    const-string v1, "empty_page"

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/FxTimelineControl;->playMarker(Ljava/lang/String;)V

    .line 293
    :goto_1d
    return-void

    .line 291
    :cond_1e
    const-string v0, "WeatherWidget2x2"

    const-string v1, "fxtc_Weather=null"

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_1d
.end method

.method public playWeatherUpdate()V
    .registers 3

    .prologue
    .line 282
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fx_Status:Lcom/htc/fusion/fx/FxScene;

    if-eqz v0, :cond_b

    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fx_Status:Lcom/htc/fusion/fx/FxScene;

    const-string v1, "In"

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/FxScene;->playMarker(Ljava/lang/String;)V

    .line 283
    :cond_b
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtc_Weather:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_16

    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtc_Weather:Lcom/htc/fusion/fx/FxTimelineControl;

    const-string v1, "weather_update"

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/FxTimelineControl;->playMarker(Ljava/lang/String;)V

    .line 284
    :cond_16
    return-void
.end method

.method public setInfoToControl(Lcom/htc/widget3d/weather/WeatherInfo2x2;)V
    .registers 5
    .param p1, "info"    # Lcom/htc/widget3d/weather/WeatherInfo2x2;

    .prologue
    .line 297
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtl_City:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_b

    .line 298
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtl_City:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iget-object v1, p1, Lcom/htc/widget3d/weather/WeatherInfo2x2;->szCity:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 300
    :cond_b
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtl_Condition:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_16

    .line 301
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtl_Condition:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iget-object v1, p1, Lcom/htc/widget3d/weather/WeatherInfo2x2;->szDescription:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 303
    :cond_16
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtl_Temp:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_21

    .line 304
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtl_Temp:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iget-object v1, p1, Lcom/htc/widget3d/weather/WeatherInfo2x2;->szCurTemp:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 306
    :cond_21
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtl_HL:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_45

    .line 307
    iget-object v0, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxtl_HL:Lcom/htc/fusion/fx/controls/FxTextLabel;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v2, p1, Lcom/htc/widget3d/weather/WeatherInfo2x2;->curHitemp:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " / "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p1, Lcom/htc/widget3d/weather/WeatherInfo2x2;->curLowTemp:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 310
    :cond_45
    iget v0, p1, Lcom/htc/widget3d/weather/WeatherInfo2x2;->condition:I

    invoke-virtual {p0, v0}, Lcom/htc/widget3d/weather/Weather2x2Widget;->setStatusControl(I)V

    .line 311
    return-void
.end method

.method public setStatusControl(I)V
    .registers 7
    .param p1, "condition"    # I

    .prologue
    .line 314
    const/4 v0, 0x0

    .line 315
    .local v0, "m10Path":Ljava/lang/String;
    const/4 v1, 0x0

    .line 316
    .local v1, "tlPath":Ljava/lang/String;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "scenes/forecast_state/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-static {p1}, Lcom/htc/widget3d/weather/util/WeatherUtil;->getForecastScenePath(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 317
    const-string v2, "WeatherWidget2x2"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "m10path :"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 318
    const/4 v2, 0x1

    invoke-static {v0, v2}, Lcom/htc/fusion/fx/FxScene;->create(Ljava/lang/String;Z)Lcom/htc/fusion/fx/FxScene;

    move-result-object v2

    iput-object v2, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fx_Status:Lcom/htc/fusion/fx/FxScene;

    .line 319
    iget-object v2, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxsc_Status:Lcom/htc/fusion/fx/controls/FxSceneContainer;

    if-eqz v2, :cond_43

    iget-object v2, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fxsc_Status:Lcom/htc/fusion/fx/controls/FxSceneContainer;

    iget-object v3, p0, Lcom/htc/widget3d/weather/Weather2x2Widget;->fx_Status:Lcom/htc/fusion/fx/FxScene;

    invoke-virtual {v2, v3}, Lcom/htc/fusion/fx/controls/FxSceneContainer;->setScene(Lcom/htc/fusion/fx/FxScene;)V

    .line 321
    :cond_43
    return-void
.end method
