.class public Lcom/htc/widget3d/weather/OptionActivity$UIHandler;
.super Landroid/os/Handler;
.source "OptionActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/widget3d/weather/OptionActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "UIHandler"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/widget3d/weather/OptionActivity;


# direct methods
.method public constructor <init>(Lcom/htc/widget3d/weather/OptionActivity;)V
    .registers 2

    .prologue
    .line 119
    iput-object p1, p0, Lcom/htc/widget3d/weather/OptionActivity$UIHandler;->this$0:Lcom/htc/widget3d/weather/OptionActivity;

    invoke-direct {p0}, Landroid/os/Handler;-><init>()V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .registers 4
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    .line 122
    iget v0, p1, Landroid/os/Message;->what:I

    packed-switch v0, :pswitch_data_16

    .line 130
    invoke-super {p0, p1}, Landroid/os/Handler;->handleMessage(Landroid/os/Message;)V

    .line 133
    :goto_8
    return-void

    .line 124
    :pswitch_9
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity$UIHandler;->this$0:Lcom/htc/widget3d/weather/OptionActivity;

    invoke-static {v0}, Lcom/htc/widget3d/weather/OptionActivity;->access$100(Lcom/htc/widget3d/weather/OptionActivity;)V

    .line 126
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity$UIHandler;->this$0:Lcom/htc/widget3d/weather/OptionActivity;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/htc/widget3d/weather/OptionActivity;->showWaitCursor(Z)V

    goto :goto_8

    .line 122
    nop

    :pswitch_data_16
    .packed-switch 0x1
        :pswitch_9
    .end packed-switch
.end method
