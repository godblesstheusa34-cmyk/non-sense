.class public Lcom/htc/widget3d/weather/OptionActivity;
.super Landroid/app/Activity;
.source "OptionActivity.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/htc/widget3d/weather/OptionActivity$BuildCityList;,
        Lcom/htc/widget3d/weather/OptionActivity$ItemClickListener;,
        Lcom/htc/widget3d/weather/OptionActivity$AddButtonListener;,
        Lcom/htc/widget3d/weather/OptionActivity$UIHandler;
    }
.end annotation


# static fields
.field private static final DIALOG_WAIT:I = 0x1

.field private static final MAX_CITY:I = 0xf

.field private static final MSG_DATA_INIT_READY:I = 0x1

.field public static final TAG:Ljava/lang/String; = "WeatherWidget"


# instance fields
.field private bListInitialized:Z

.field private mActivity:Landroid/app/Activity;

.field private mAdapter:Landroid/widget/ArrayAdapter;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/widget/ArrayAdapter",
            "<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private mAddCityText:Landroid/widget/TextView;

.field private mCityIndex:I

.field private mCityInfo:Lcom/htc/widget3d/weather/data/CityInfo;

.field private mCurrentCityList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList",
            "<",
            "Lcom/htc/widget3d/weather/data/CityInfo;",
            ">;"
        }
    .end annotation
.end field

.field private mHandler:Landroid/os/Handler;

.field private mLayoutAddCity:Landroid/view/ViewGroup;

.field private mListView:Lcom/htc/widget/HtcListView;

.field private mMaxCityCount:I

.field private mMaxCityCountFromProvider:I

.field private mMaxCityCountFromSetting:I

.field private mProgressDlg:Landroid/app/ProgressDialog;

.field private mStrings:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList",
            "<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 4

    .prologue
    const/16 v2, 0xf

    const/4 v1, 0x0

    .line 38
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 43
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mProgressDlg:Landroid/app/ProgressDialog;

    .line 57
    iput v2, p0, Lcom/htc/widget3d/weather/OptionActivity;->mMaxCityCount:I

    .line 58
    iput v2, p0, Lcom/htc/widget3d/weather/OptionActivity;->mMaxCityCountFromSetting:I

    .line 59
    iput v1, p0, Lcom/htc/widget3d/weather/OptionActivity;->mMaxCityCountFromProvider:I

    .line 60
    iput-boolean v1, p0, Lcom/htc/widget3d/weather/OptionActivity;->bListInitialized:Z

    .line 455
    return-void
.end method

.method static synthetic access$100(Lcom/htc/widget3d/weather/OptionActivity;)V
    .registers 1
    .param p0, "x0"    # Lcom/htc/widget3d/weather/OptionActivity;

    .prologue
    .line 38
    invoke-direct {p0}, Lcom/htc/widget3d/weather/OptionActivity;->initListView()V

    return-void
.end method

.method static synthetic access$202(Lcom/htc/widget3d/weather/OptionActivity;I)I
    .registers 2
    .param p0, "x0"    # Lcom/htc/widget3d/weather/OptionActivity;
    .param p1, "x1"    # I

    .prologue
    .line 38
    iput p1, p0, Lcom/htc/widget3d/weather/OptionActivity;->mCityIndex:I

    return p1
.end method

.method static synthetic access$302(Lcom/htc/widget3d/weather/OptionActivity;Lcom/htc/widget3d/weather/data/CityInfo;)Lcom/htc/widget3d/weather/data/CityInfo;
    .registers 2
    .param p0, "x0"    # Lcom/htc/widget3d/weather/OptionActivity;
    .param p1, "x1"    # Lcom/htc/widget3d/weather/data/CityInfo;

    .prologue
    .line 38
    iput-object p1, p0, Lcom/htc/widget3d/weather/OptionActivity;->mCityInfo:Lcom/htc/widget3d/weather/data/CityInfo;

    return-object p1
.end method

.method static synthetic access$400(Lcom/htc/widget3d/weather/OptionActivity;)Ljava/util/ArrayList;
    .registers 2
    .param p0, "x0"    # Lcom/htc/widget3d/weather/OptionActivity;

    .prologue
    .line 38
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mCurrentCityList:Ljava/util/ArrayList;

    return-object v0
.end method

.method static synthetic access$500(Lcom/htc/widget3d/weather/OptionActivity;)V
    .registers 1
    .param p0, "x0"    # Lcom/htc/widget3d/weather/OptionActivity;

    .prologue
    .line 38
    invoke-direct {p0}, Lcom/htc/widget3d/weather/OptionActivity;->backtoLauncher()V

    return-void
.end method

.method static synthetic access$600(Lcom/htc/widget3d/weather/OptionActivity;)V
    .registers 1
    .param p0, "x0"    # Lcom/htc/widget3d/weather/OptionActivity;

    .prologue
    .line 38
    invoke-direct {p0}, Lcom/htc/widget3d/weather/OptionActivity;->launchAddCityActivity()V

    return-void
.end method

.method static synthetic access$700(Lcom/htc/widget3d/weather/OptionActivity;)Z
    .registers 2
    .param p0, "x0"    # Lcom/htc/widget3d/weather/OptionActivity;

    .prologue
    .line 38
    invoke-direct {p0}, Lcom/htc/widget3d/weather/OptionActivity;->prepareWeatherProvider()Z

    move-result v0

    return v0
.end method

.method static synthetic access$800(Lcom/htc/widget3d/weather/OptionActivity;)Landroid/os/Handler;
    .registers 2
    .param p0, "x0"    # Lcom/htc/widget3d/weather/OptionActivity;

    .prologue
    .line 38
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mHandler:Landroid/os/Handler;

    return-object v0
.end method

.method private backtoLauncher()V
    .registers 6

    .prologue
    .line 286
    iget-object v3, p0, Lcom/htc/widget3d/weather/OptionActivity;->mCityInfo:Lcom/htc/widget3d/weather/data/CityInfo;

    if-eqz v3, :cond_85

    iget-object v3, p0, Lcom/htc/widget3d/weather/OptionActivity;->mCityInfo:Lcom/htc/widget3d/weather/data/CityInfo;

    invoke-virtual {v3}, Lcom/htc/widget3d/weather/data/CityInfo;->getLocationInfo()Lcom/htc/util/weather/WeatherLocation;

    move-result-object v3

    if-eqz v3, :cond_85

    .line 288
    const/4 v2, 0x0

    .line 289
    .local v2, "nTempUnit":I
    iget-object v3, p0, Lcom/htc/widget3d/weather/OptionActivity;->mCityInfo:Lcom/htc/widget3d/weather/data/CityInfo;

    invoke-virtual {v3}, Lcom/htc/widget3d/weather/data/CityInfo;->getLocationInfo()Lcom/htc/util/weather/WeatherLocation;

    move-result-object v1

    .line 290
    .local v1, "loc":Lcom/htc/util/weather/WeatherLocation;
    iget-object v3, p0, Lcom/htc/widget3d/weather/OptionActivity;->mActivity:Landroid/app/Activity;

    invoke-virtual {v3}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    .line 291
    .local v0, "intent":Landroid/content/Intent;
    if-eqz v0, :cond_85

    .line 292
    const-string v3, "select_city"

    iget v4, p0, Lcom/htc/widget3d/weather/OptionActivity;->mCityIndex:I

    invoke-static {v4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 295
    const-string v3, "name_"

    invoke-virtual {v1}, Lcom/htc/util/weather/WeatherLocation;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 296
    const-string v3, "state_"

    invoke-virtual {v1}, Lcom/htc/util/weather/WeatherLocation;->getState()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 297
    const-string v3, "country_"

    invoke-virtual {v1}, Lcom/htc/util/weather/WeatherLocation;->getCountry()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 298
    const-string v3, "code_"

    invoke-virtual {v1}, Lcom/htc/util/weather/WeatherLocation;->getCode()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 299
    const-string v3, "timezone_"

    invoke-virtual {v1}, Lcom/htc/util/weather/WeatherLocation;->getTimezone()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 300
    const-string v3, "timezoneid_"

    invoke-virtual {v1}, Lcom/htc/util/weather/WeatherLocation;->getTimezoneId()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 301
    const-string v3, "latitude_"

    invoke-virtual {v1}, Lcom/htc/util/weather/WeatherLocation;->getLatitude()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 302
    const-string v3, "longitude_"

    invoke-virtual {v1}, Lcom/htc/util/weather/WeatherLocation;->getLongitude()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 303
    const-string v3, "app_"

    invoke-virtual {v1}, Lcom/htc/util/weather/WeatherLocation;->getApp()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 304
    const-string v3, "index_"

    iget v4, p0, Lcom/htc/widget3d/weather/OptionActivity;->mCityIndex:I

    invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 305
    const/4 v3, -0x1

    invoke-virtual {p0, v3, v0}, Landroid/app/Activity;->setResult(ILandroid/content/Intent;)V

    .line 306
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 309
    .end local v0    # "intent":Landroid/content/Intent;
    .end local v1    # "loc":Lcom/htc/util/weather/WeatherLocation;
    .end local v2    # "nTempUnit":I
    :cond_85
    return-void
.end method

.method private initListView()V
    .registers 5

    .prologue
    .line 137
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->bListInitialized:Z

    .line 139
    new-instance v0, Landroid/widget/ArrayAdapter;

    iget-object v1, p0, Lcom/htc/widget3d/weather/OptionActivity;->mActivity:Landroid/app/Activity;

    const/high16 v2, 0x7f030000

    iget-object v3, p0, Lcom/htc/widget3d/weather/OptionActivity;->mStrings:Ljava/util/ArrayList;

    invoke-direct {v0, v1, v2, v3}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;ILjava/util/List;)V

    iput-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mAdapter:Landroid/widget/ArrayAdapter;

    .line 140
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mListView:Lcom/htc/widget/HtcListView;

    if-eqz v0, :cond_2a

    .line 141
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mListView:Lcom/htc/widget/HtcListView;

    iget-object v1, p0, Lcom/htc/widget3d/weather/OptionActivity;->mAdapter:Landroid/widget/ArrayAdapter;

    invoke-virtual {v0, v1}, Lcom/htc/widget/HtcListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 142
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mListView:Lcom/htc/widget/HtcListView;

    invoke-virtual {v0}, Landroid/view/View;->requestFocus()Z

    .line 144
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mListView:Lcom/htc/widget/HtcListView;

    new-instance v1, Lcom/htc/widget3d/weather/OptionActivity$1;

    invoke-direct {v1, p0}, Lcom/htc/widget3d/weather/OptionActivity$1;-><init>(Lcom/htc/widget3d/weather/OptionActivity;)V

    invoke-virtual {v0, v1}, Lcom/htc/widget/HtcAdapterView;->setOnItemClickListener(Lcom/htc/widget/HtcAdapterView$OnItemClickListener;)V

    .line 162
    :cond_2a
    return-void
.end method

.method private isCityViewExist(Ljava/lang/String;)Z
    .registers 5
    .param p1, "name"    # Ljava/lang/String;

    .prologue
    .line 370
    if-eqz p1, :cond_26

    iget-object v2, p0, Lcom/htc/widget3d/weather/OptionActivity;->mCurrentCityList:Ljava/util/ArrayList;

    if-eqz v2, :cond_26

    .line 371
    iget-object v2, p0, Lcom/htc/widget3d/weather/OptionActivity;->mCurrentCityList:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v1

    .line 372
    .local v1, "size":I
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_d
    if-ge v0, v1, :cond_26

    .line 373
    iget-object v2, p0, Lcom/htc/widget3d/weather/OptionActivity;->mCurrentCityList:Ljava/util/ArrayList;

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/htc/widget3d/weather/data/CityInfo;

    invoke-virtual {v2}, Lcom/htc/widget3d/weather/data/CityInfo;->getDisplayName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_23

    .line 374
    const/4 v2, 0x1

    .line 377
    .end local v0    # "i":I
    .end local v1    # "size":I
    :goto_22
    return v2

    .line 372
    .restart local v0    # "i":I
    .restart local v1    # "size":I
    :cond_23
    add-int/lit8 v0, v0, 0x1

    goto :goto_d

    .line 377
    .end local v0    # "i":I
    .end local v1    # "size":I
    :cond_26
    const/4 v2, 0x0

    goto :goto_22
.end method

.method private launchAddCityActivity()V
    .registers 6

    .prologue
    .line 246
    iget-object v2, p0, Lcom/htc/widget3d/weather/OptionActivity;->mCurrentCityList:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    iget v3, p0, Lcom/htc/widget3d/weather/OptionActivity;->mMaxCityCount:I

    if-lt v2, v3, :cond_1b

    .line 247
    invoke-virtual {p0}, Landroid/content/ContextWrapper;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const v3, 0x7f06006b

    const/16 v4, 0x1f4

    invoke-static {v2, v3, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v2

    invoke-virtual {v2}, Landroid/widget/Toast;->show()V

    .line 259
    :cond_1a
    :goto_1a
    return-void

    .line 250
    :cond_1b
    new-instance v1, Landroid/content/Intent;

    const-string v2, "com.htc.Weather.intent.action.SEARCH"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 251
    .local v1, "intent":Landroid/content/Intent;
    if-eqz v1, :cond_1a

    .line 252
    const-string v2, "com.htc.Weather"

    const-string v3, "com.htc.Weather.AddCity"

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 254
    const/16 v2, 0x1001

    :try_start_2d
    invoke-virtual {p0, v1, v2}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V
    :try_end_30
    .catch Landroid/content/ActivityNotFoundException; {:try_start_2d .. :try_end_30} :catch_31

    goto :goto_1a

    .line 255
    :catch_31
    move-exception v0

    .line 256
    .local v0, "e":Landroid/content/ActivityNotFoundException;
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_1a
.end method

.method private prepareWeatherProvider()Z
    .registers 12

    .prologue
    const/4 v10, 0x1

    const/4 v7, 0x0

    const-string v9, "com.htc.htclocationservice"

    .line 383
    const/4 v5, 0x0

    .line 385
    .local v5, "size":I
    const/4 v2, 0x0

    .line 386
    .local v2, "loc":Lcom/htc/util/weather/WeatherLocation;
    const/4 v6, 0x2

    new-array v4, v6, [Ljava/lang/String;

    const-string v6, "com.htc.htclocationservice"

    aput-object v9, v4, v7

    const-string v6, "com.htc.elroy.Weather"

    aput-object v6, v4, v10

    .line 388
    .local v4, "pkgname":[Ljava/lang/String;
    invoke-virtual {p0}, Landroid/content/ContextWrapper;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v6

    invoke-static {v6, v4}, Lcom/htc/util/weather/WeatherUtility;->loadMultiAppLocationsFilterByApp(Landroid/content/ContentResolver;[Ljava/lang/String;)[Lcom/htc/util/weather/WeatherLocation;

    move-result-object v3

    .line 390
    .local v3, "locs":[Lcom/htc/util/weather/WeatherLocation;
    array-length v6, v3

    if-lez v6, :cond_f6

    .line 392
    aget-object v6, v3, v7

    invoke-virtual {v6}, Lcom/htc/util/weather/WeatherLocation;->getApp()Ljava/lang/String;

    move-result-object v6

    if-eqz v6, :cond_4f

    aget-object v6, v3, v7

    invoke-virtual {v6}, Lcom/htc/util/weather/WeatherLocation;->getApp()Ljava/lang/String;

    move-result-object v6

    const-string v7, "com.htc.htclocationservice"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_4f

    .line 394
    iget v6, p0, Lcom/htc/widget3d/weather/OptionActivity;->mMaxCityCountFromSetting:I

    add-int/lit8 v6, v6, 0x1

    iput v6, p0, Lcom/htc/widget3d/weather/OptionActivity;->mMaxCityCount:I

    .line 400
    :goto_38
    array-length v5, v3

    .line 401
    iput v5, p0, Lcom/htc/widget3d/weather/OptionActivity;->mMaxCityCountFromProvider:I

    .line 403
    iget-object v6, p0, Lcom/htc/widget3d/weather/OptionActivity;->mCurrentCityList:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->clear()V

    .line 404
    iget-object v6, p0, Lcom/htc/widget3d/weather/OptionActivity;->mStrings:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->clear()V

    .line 406
    const/4 v1, 0x0

    .local v1, "i":I
    :goto_46
    if-ge v1, v5, :cond_f2

    .line 407
    aget-object v2, v3, v1

    .line 409
    if-nez v2, :cond_54

    .line 406
    :goto_4c
    add-int/lit8 v1, v1, 0x1

    goto :goto_46

    .line 397
    .end local v1    # "i":I
    :cond_4f
    iget v6, p0, Lcom/htc/widget3d/weather/OptionActivity;->mMaxCityCountFromSetting:I

    iput v6, p0, Lcom/htc/widget3d/weather/OptionActivity;->mMaxCityCount:I

    goto :goto_38

    .line 412
    .restart local v1    # "i":I
    :cond_54
    new-instance v0, Lcom/htc/widget3d/weather/data/CityInfo;

    invoke-direct {v0}, Lcom/htc/widget3d/weather/data/CityInfo;-><init>()V

    .line 414
    .local v0, "cityinfo":Lcom/htc/widget3d/weather/data/CityInfo;
    invoke-virtual {v0, v2}, Lcom/htc/widget3d/weather/data/CityInfo;->setLocationInfo(Lcom/htc/util/weather/WeatherLocation;)V

    .line 416
    invoke-virtual {v2}, Lcom/htc/util/weather/WeatherLocation;->getApp()Ljava/lang/String;

    move-result-object v6

    if-eqz v6, :cond_94

    invoke-virtual {v2}, Lcom/htc/util/weather/WeatherLocation;->getApp()Ljava/lang/String;

    move-result-object v6

    const-string v7, "com.htc.htclocationservice"

    invoke-virtual {v6, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_94

    .line 418
    iget-object v6, p0, Lcom/htc/widget3d/weather/OptionActivity;->mStrings:Ljava/util/ArrayList;

    const v7, 0x7f060068

    invoke-virtual {p0, v7}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 433
    :goto_7a
    invoke-virtual {v2}, Lcom/htc/util/weather/WeatherLocation;->getCode()Ljava/lang/String;

    move-result-object v6

    if-eqz v6, :cond_8a

    invoke-virtual {v2}, Lcom/htc/util/weather/WeatherLocation;->getCode()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v6

    if-nez v6, :cond_ed

    .line 434
    :cond_8a
    sget-object v6, Lcom/htc/widget3d/weather/data/WeatherModel$QUERY_TYPE;->GOOGLE_GEOCODE:Lcom/htc/widget3d/weather/data/WeatherModel$QUERY_TYPE;

    iput-object v6, v0, Lcom/htc/widget3d/weather/data/CityInfo;->type_:Lcom/htc/widget3d/weather/data/WeatherModel$QUERY_TYPE;

    .line 442
    :goto_8e
    iget-object v6, p0, Lcom/htc/widget3d/weather/OptionActivity;->mCurrentCityList:Ljava/util/ArrayList;

    invoke-virtual {v6, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_4c

    .line 421
    :cond_94
    invoke-virtual {v2}, Lcom/htc/util/weather/WeatherLocation;->getState()Ljava/lang/String;

    move-result-object v6

    if-eqz v6, :cond_a4

    invoke-virtual {v2}, Lcom/htc/util/weather/WeatherLocation;->getState()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v6

    if-nez v6, :cond_e3

    .line 423
    :cond_a4
    invoke-virtual {v2}, Lcom/htc/util/weather/WeatherLocation;->getCountry()Ljava/lang/String;

    move-result-object v6

    if-eqz v6, :cond_d9

    invoke-virtual {v2}, Lcom/htc/util/weather/WeatherLocation;->getCountry()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v6

    if-lez v6, :cond_d9

    .line 424
    iget-object v6, p0, Lcom/htc/widget3d/weather/OptionActivity;->mStrings:Ljava/util/ArrayList;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2}, Lcom/htc/util/weather/WeatherLocation;->getName()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, ", "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v2}, Lcom/htc/util/weather/WeatherLocation;->getCountry()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_7a

    .line 427
    :cond_d9
    iget-object v6, p0, Lcom/htc/widget3d/weather/OptionActivity;->mStrings:Ljava/util/ArrayList;

    invoke-virtual {v0}, Lcom/htc/widget3d/weather/data/CityInfo;->getDisplayName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_7a

    .line 430
    :cond_e3
    iget-object v6, p0, Lcom/htc/widget3d/weather/OptionActivity;->mStrings:Ljava/util/ArrayList;

    invoke-virtual {v0}, Lcom/htc/widget3d/weather/data/CityInfo;->getDisplayName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_7a

    .line 436
    :cond_ed
    sget-object v6, Lcom/htc/widget3d/weather/data/WeatherModel$QUERY_TYPE;->QUERY_CODE_ACCU_WEATHER:Lcom/htc/widget3d/weather/data/WeatherModel$QUERY_TYPE;

    iput-object v6, v0, Lcom/htc/widget3d/weather/data/CityInfo;->type_:Lcom/htc/widget3d/weather/data/WeatherModel$QUERY_TYPE;

    goto :goto_8e

    .line 444
    .end local v0    # "cityinfo":Lcom/htc/widget3d/weather/data/CityInfo;
    :cond_f2
    const/4 v3, 0x0

    .line 445
    const/4 v2, 0x0

    move v6, v10

    .line 449
    .end local v1    # "i":I
    :goto_f5
    return v6

    :cond_f6
    move v6, v7

    goto :goto_f5
.end method


# virtual methods
.method public onActivityResult(IILandroid/content/Intent;)V
    .registers 15
    .param p1, "requestCode"    # I
    .param p2, "resultCode"    # I
    .param p3, "data"    # Landroid/content/Intent;

    .prologue
    const/4 v10, 0x0

    const v9, 0x7f06006a

    const/16 v8, 0x1f4

    const/4 v7, 0x1

    const/4 v6, 0x0

    .line 312
    if-nez p3, :cond_b

    .line 366
    :goto_a
    return-void

    .line 315
    :cond_b
    packed-switch p1, :pswitch_data_be

    .line 363
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    goto :goto_a

    .line 318
    :pswitch_12
    if-ne p2, v7, :cond_3e

    .line 322
    const-string v4, "status"

    invoke-virtual {p3, v4, v6}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v4

    if-eqz v4, :cond_24

    .line 323
    invoke-static {p0, v9, v8}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v4

    invoke-virtual {v4}, Landroid/widget/Toast;->show()V

    goto :goto_a

    .line 326
    :cond_24
    iput-boolean v6, p0, Lcom/htc/widget3d/weather/OptionActivity;->bListInitialized:Z

    .line 327
    new-instance v0, Lcom/htc/widget3d/weather/OptionActivity$BuildCityList;

    invoke-direct {v0, p0, v10}, Lcom/htc/widget3d/weather/OptionActivity$BuildCityList;-><init>(Lcom/htc/widget3d/weather/OptionActivity;Lcom/htc/widget3d/weather/OptionActivity$1;)V

    .line 328
    .local v0, "data_process":Lcom/htc/widget3d/weather/OptionActivity$BuildCityList;
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 358
    .end local v0    # "data_process":Lcom/htc/widget3d/weather/OptionActivity$BuildCityList;
    :cond_2e
    :goto_2e
    new-instance v2, Landroid/content/Intent;

    const-string v4, "com.htc.Weather.add_location_changed"

    invoke-direct {v2, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 359
    .local v2, "intent":Landroid/content/Intent;
    const-string v4, "com.htc.Weather.add_location_changed"

    invoke-virtual {v2, v4, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 360
    invoke-virtual {p0, v2}, Landroid/content/ContextWrapper;->sendBroadcast(Landroid/content/Intent;)V

    goto :goto_a

    .line 329
    .end local v2    # "intent":Landroid/content/Intent;
    :cond_3e
    const/4 v4, 0x2

    if-ne p2, v4, :cond_2e

    .line 331
    new-array v3, v7, [Lcom/htc/util/weather/WeatherLocation;

    .line 332
    .local v3, "loc":[Lcom/htc/util/weather/WeatherLocation;
    new-instance v4, Lcom/htc/util/weather/WeatherLocation;

    invoke-direct {v4}, Lcom/htc/util/weather/WeatherLocation;-><init>()V

    aput-object v4, v3, v6

    .line 334
    aget-object v4, v3, v6

    const-string v5, "latitude"

    invoke-virtual {p3, v5}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lcom/htc/util/weather/WeatherLocation;->setLatitude(Ljava/lang/String;)V

    .line 335
    aget-object v4, v3, v6

    const-string v5, "longitude"

    invoke-virtual {p3, v5}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lcom/htc/util/weather/WeatherLocation;->setLongitude(Ljava/lang/String;)V

    .line 336
    aget-object v4, v3, v6

    const-string v5, "name"

    invoke-virtual {p3, v5}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lcom/htc/util/weather/WeatherLocation;->setName(Ljava/lang/String;)V

    .line 337
    aget-object v4, v3, v6

    const-string v5, "state"

    invoke-virtual {p3, v5}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lcom/htc/util/weather/WeatherLocation;->setState(Ljava/lang/String;)V

    .line 338
    aget-object v4, v3, v6

    const-string v5, "country"

    invoke-virtual {p3, v5}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Lcom/htc/util/weather/WeatherLocation;->setCountry(Ljava/lang/String;)V

    .line 339
    aget-object v4, v3, v6

    const-string v5, "com.htc.elroy.Weather"

    invoke-virtual {v4, v5}, Lcom/htc/util/weather/WeatherLocation;->setApp(Ljava/lang/String;)V

    .line 341
    new-instance v1, Lcom/htc/widget3d/weather/data/CityInfo;

    invoke-direct {v1}, Lcom/htc/widget3d/weather/data/CityInfo;-><init>()V

    .line 342
    .local v1, "info":Lcom/htc/widget3d/weather/data/CityInfo;
    aget-object v4, v3, v6

    invoke-virtual {v1, v4}, Lcom/htc/widget3d/weather/data/CityInfo;->setLocationInfo(Lcom/htc/util/weather/WeatherLocation;)V

    .line 343
    sget-object v4, Lcom/htc/widget3d/weather/data/WeatherModel$QUERY_TYPE;->GOOGLE_GEOCODE:Lcom/htc/widget3d/weather/data/WeatherModel$QUERY_TYPE;

    iput-object v4, v1, Lcom/htc/widget3d/weather/data/CityInfo;->type_:Lcom/htc/widget3d/weather/data/WeatherModel$QUERY_TYPE;

    .line 345
    invoke-virtual {v1}, Lcom/htc/widget3d/weather/data/CityInfo;->getDisplayName()Ljava/lang/String;

    move-result-object v4

    invoke-direct {p0, v4}, Lcom/htc/widget3d/weather/OptionActivity;->isCityViewExist(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_a9

    .line 346
    invoke-static {p0, v9, v8}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v4

    invoke-virtual {v4}, Landroid/widget/Toast;->show()V

    goto/16 :goto_a

    .line 350
    :cond_a9
    invoke-virtual {p0}, Landroid/content/ContextWrapper;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v4

    const-string v5, "com.htc.elroy.Weather"

    invoke-static {v4, v5, v3}, Lcom/htc/util/weather/WeatherUtility;->addLocation(Landroid/content/ContentResolver;Ljava/lang/String;[Lcom/htc/util/weather/WeatherLocation;)V

    .line 352
    iput-boolean v6, p0, Lcom/htc/widget3d/weather/OptionActivity;->bListInitialized:Z

    .line 353
    new-instance v0, Lcom/htc/widget3d/weather/OptionActivity$BuildCityList;

    invoke-direct {v0, p0, v10}, Lcom/htc/widget3d/weather/OptionActivity$BuildCityList;-><init>(Lcom/htc/widget3d/weather/OptionActivity;Lcom/htc/widget3d/weather/OptionActivity$1;)V

    .line 354
    .restart local v0    # "data_process":Lcom/htc/widget3d/weather/OptionActivity$BuildCityList;
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    goto/16 :goto_2e

    .line 315
    :pswitch_data_be
    .packed-switch 0x1001
        :pswitch_12
    .end packed-switch
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 9
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .prologue
    const/4 v6, 0x1

    .line 66
    invoke-virtual {p0, v6}, Landroid/app/Activity;->requestWindowFeature(I)Z

    .line 67
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 69
    const v4, 0x7f030002

    invoke-virtual {p0, v4}, Landroid/app/Activity;->setContentView(I)V

    .line 70
    invoke-virtual {p0, v6}, Lcom/htc/widget3d/weather/OptionActivity;->showWaitCursor(Z)V

    .line 73
    const-string v4, "common_app_bkg"

    const v5, 0x20806b7

    invoke-static {p0, v4, v5}, Lcom/htc/util/skin/HtcSkinUtil;->getDrawableResIdentifier(Landroid/content/Context;Ljava/lang/String;I)I

    move-result v0

    .line 74
    .local v0, "bgId":I
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v4

    invoke-virtual {v4, v0}, Landroid/view/Window;->setBackgroundDrawableResource(I)V

    .line 76
    const v4, 0x7f080002

    invoke-virtual {p0, v4}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Lcom/htc/widget/Title1;

    .line 77
    .local v3, "title":Lcom/htc/widget/Title1;
    if-eqz v3, :cond_4b

    .line 78
    invoke-virtual {v3}, Lcom/htc/widget/Title1;->disablePulldownButton()V

    .line 79
    const v4, 0x7f060057

    invoke-virtual {v3, v4}, Lcom/htc/widget/Title1;->setLeftTitle(I)V

    .line 80
    const v4, 0x20806e5

    invoke-virtual {v3, v4}, Lcom/htc/widget/Title1;->setRightButtonImage2(I)V

    .line 81
    const v4, 0x202022c

    invoke-virtual {v3, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/ImageButton;

    .line 82
    .local v1, "btnAdd":Landroid/widget/ImageButton;
    new-instance v4, Lcom/htc/widget3d/weather/OptionActivity$AddButtonListener;

    invoke-direct {v4, p0}, Lcom/htc/widget3d/weather/OptionActivity$AddButtonListener;-><init>(Lcom/htc/widget3d/weather/OptionActivity;)V

    invoke-virtual {v1, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 84
    .end local v1    # "btnAdd":Landroid/widget/ImageButton;
    :cond_4b
    const v4, 0x7f080003

    invoke-virtual {p0, v4}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Lcom/htc/widget/HtcListView;

    iput-object v4, p0, Lcom/htc/widget3d/weather/OptionActivity;->mListView:Lcom/htc/widget/HtcListView;

    .line 85
    iget-object v4, p0, Lcom/htc/widget3d/weather/OptionActivity;->mListView:Lcom/htc/widget/HtcListView;

    invoke-virtual {v4, v6}, Landroid/view/View;->setRoundedCornerEnabled(Z)V

    .line 106
    iput-object p0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mActivity:Landroid/app/Activity;

    .line 107
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    iput-object v4, p0, Lcom/htc/widget3d/weather/OptionActivity;->mStrings:Ljava/util/ArrayList;

    .line 108
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    iput-object v4, p0, Lcom/htc/widget3d/weather/OptionActivity;->mCurrentCityList:Ljava/util/ArrayList;

    .line 110
    new-instance v4, Lcom/htc/widget3d/weather/OptionActivity$UIHandler;

    invoke-direct {v4, p0}, Lcom/htc/widget3d/weather/OptionActivity$UIHandler;-><init>(Lcom/htc/widget3d/weather/OptionActivity;)V

    iput-object v4, p0, Lcom/htc/widget3d/weather/OptionActivity;->mHandler:Landroid/os/Handler;

    .line 113
    const/4 v4, 0x0

    iput-boolean v4, p0, Lcom/htc/widget3d/weather/OptionActivity;->bListInitialized:Z

    .line 114
    new-instance v2, Lcom/htc/widget3d/weather/OptionActivity$BuildCityList;

    const/4 v4, 0x0

    invoke-direct {v2, p0, v4}, Lcom/htc/widget3d/weather/OptionActivity$BuildCityList;-><init>(Lcom/htc/widget3d/weather/OptionActivity;Lcom/htc/widget3d/weather/OptionActivity$1;)V

    .line 115
    .local v2, "data_process":Lcom/htc/widget3d/weather/OptionActivity$BuildCityList;
    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    .line 117
    return-void
.end method

.method protected onCreateDialog(I)Landroid/app/Dialog;
    .registers 6
    .param p1, "id"    # I

    .prologue
    const/4 v3, 0x1

    .line 199
    if-ne p1, v3, :cond_2c

    .line 200
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mProgressDlg:Landroid/app/ProgressDialog;

    if-nez v0, :cond_29

    .line 201
    new-instance v0, Landroid/app/ProgressDialog;

    invoke-direct {v0, p0}, Landroid/app/ProgressDialog;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mProgressDlg:Landroid/app/ProgressDialog;

    .line 202
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mProgressDlg:Landroid/app/ProgressDialog;

    invoke-virtual {p0}, Landroid/content/ContextWrapper;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f060059

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/ProgressDialog;->setMessage(Ljava/lang/CharSequence;)V

    .line 203
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mProgressDlg:Landroid/app/ProgressDialog;

    invoke-virtual {v0, v3}, Landroid/app/ProgressDialog;->setIndeterminate(Z)V

    .line 204
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mProgressDlg:Landroid/app/ProgressDialog;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 206
    :cond_29
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mProgressDlg:Landroid/app/ProgressDialog;

    .line 208
    :goto_2b
    return-object v0

    :cond_2c
    const/4 v0, 0x0

    goto :goto_2b
.end method

.method protected onDestroy()V
    .registers 3

    .prologue
    const/4 v1, 0x0

    .line 225
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mProgressDlg:Landroid/app/ProgressDialog;

    if-eqz v0, :cond_c

    .line 226
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mProgressDlg:Landroid/app/ProgressDialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    .line 227
    iput-object v1, p0, Lcom/htc/widget3d/weather/OptionActivity;->mProgressDlg:Landroid/app/ProgressDialog;

    .line 229
    :cond_c
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mLayoutAddCity:Landroid/view/ViewGroup;

    if-eqz v0, :cond_15

    .line 230
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mLayoutAddCity:Landroid/view/ViewGroup;

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 234
    :cond_15
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mStrings:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 237
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mCurrentCityList:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 240
    iput-object v1, p0, Lcom/htc/widget3d/weather/OptionActivity;->mHandler:Landroid/os/Handler;

    .line 242
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    .line 243
    return-void
.end method

.method protected onResume()V
    .registers 3

    .prologue
    .line 213
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 215
    iget-boolean v1, p0, Lcom/htc/widget3d/weather/OptionActivity;->bListInitialized:Z

    if-eqz v1, :cond_10

    .line 217
    new-instance v0, Lcom/htc/widget3d/weather/OptionActivity$BuildCityList;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lcom/htc/widget3d/weather/OptionActivity$BuildCityList;-><init>(Lcom/htc/widget3d/weather/OptionActivity;Lcom/htc/widget3d/weather/OptionActivity$1;)V

    .line 218
    .local v0, "data_process":Lcom/htc/widget3d/weather/OptionActivity$BuildCityList;
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 220
    .end local v0    # "data_process":Lcom/htc/widget3d/weather/OptionActivity$BuildCityList;
    :cond_10
    return-void
.end method

.method public showWaitCursor(Z)V
    .registers 4
    .param p1, "bShow"    # Z

    .prologue
    const/4 v1, 0x1

    .line 186
    if-eqz p1, :cond_7

    .line 187
    invoke-virtual {p0, v1}, Landroid/app/Activity;->showDialog(I)V

    .line 195
    :cond_6
    :goto_6
    return-void

    .line 189
    :cond_7
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mProgressDlg:Landroid/app/ProgressDialog;

    if-eqz v0, :cond_6

    .line 190
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mProgressDlg:Landroid/app/ProgressDialog;

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 191
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mProgressDlg:Landroid/app/ProgressDialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->cancel()V

    .line 192
    iget-object v0, p0, Lcom/htc/widget3d/weather/OptionActivity;->mProgressDlg:Landroid/app/ProgressDialog;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setCancelable(Z)V

    goto :goto_6
.end method
