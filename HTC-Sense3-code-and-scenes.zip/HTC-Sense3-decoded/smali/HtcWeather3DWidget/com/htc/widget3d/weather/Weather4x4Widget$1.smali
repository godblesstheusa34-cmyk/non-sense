.class Lcom/htc/widget3d/weather/Weather4x4Widget$1;
.super Lcom/htc/fusion/fx/MessageListener;
.source "Weather4x4Widget.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/htc/widget3d/weather/Weather4x4Widget;->initWeatherControl()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/htc/fusion/fx/MessageListener",
        "<",
        "Lcom/htc/fusion/fx/FxPlaybackInfo;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/widget3d/weather/Weather4x4Widget;


# direct methods
.method constructor <init>(Lcom/htc/widget3d/weather/Weather4x4Widget;)V
    .registers 2

    .prologue
    .line 587
    iput-object p1, p0, Lcom/htc/widget3d/weather/Weather4x4Widget$1;->this$0:Lcom/htc/widget3d/weather/Weather4x4Widget;

    invoke-direct {p0}, Lcom/htc/fusion/fx/MessageListener;-><init>()V

    return-void
.end method


# virtual methods
.method public onMessageReceived(Lcom/htc/fusion/fx/FxPlaybackInfo;)V
    .registers 6
    .param p1, "message"    # Lcom/htc/fusion/fx/FxPlaybackInfo;

    .prologue
    const/4 v3, 0x0

    .line 591
    # getter for: Lcom/htc/widget3d/weather/Weather4x4Widget;->TAG:Ljava/lang/String;
    invoke-static {}, Lcom/htc/widget3d/weather/Weather4x4Widget;->access$100()Ljava/lang/String;

    move-result-object v1

    const-string v2, " NextWeatherControl FxPlaybackInfo.onMessageReceived"

    invoke-static {v1, v2}, Lcom/htc/widget3d/weather/util/LOG;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 593
    iget-object v1, p0, Lcom/htc/widget3d/weather/Weather4x4Widget$1;->this$0:Lcom/htc/widget3d/weather/Weather4x4Widget;

    # getter for: Lcom/htc/widget3d/weather/Weather4x4Widget;->m_bSwipeCity:Z
    invoke-static {v1}, Lcom/htc/widget3d/weather/Weather4x4Widget;->access$200(Lcom/htc/widget3d/weather/Weather4x4Widget;)Z

    move-result v1

    if-eqz v1, :cond_5c

    .line 595
    # getter for: Lcom/htc/widget3d/weather/Weather4x4Widget;->TAG:Ljava/lang/String;
    invoke-static {}, Lcom/htc/widget3d/weather/Weather4x4Widget;->access$100()Ljava/lang/String;

    move-result-object v1

    const-string v2, " need to do next-current scene switch"

    invoke-static {v1, v2}, Lcom/htc/widget3d/weather/util/LOG;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 596
    iget-object v1, p0, Lcom/htc/widget3d/weather/Weather4x4Widget$1;->this$0:Lcom/htc/widget3d/weather/Weather4x4Widget;

    iget-object v2, p0, Lcom/htc/widget3d/weather/Weather4x4Widget$1;->this$0:Lcom/htc/widget3d/weather/Weather4x4Widget;

    # getter for: Lcom/htc/widget3d/weather/Weather4x4Widget;->mNextIndex:I
    invoke-static {v2}, Lcom/htc/widget3d/weather/Weather4x4Widget;->access$300(Lcom/htc/widget3d/weather/Weather4x4Widget;)I

    move-result v2

    iput v2, v1, Lcom/htc/widget3d/weather/Weather4x4Widget;->mCurrIndex:I

    .line 597
    iget-object v1, p0, Lcom/htc/widget3d/weather/Weather4x4Widget$1;->this$0:Lcom/htc/widget3d/weather/Weather4x4Widget;

    # getter for: Lcom/htc/widget3d/weather/Weather4x4Widget;->mFxCurWeatherCtr:Lcom/htc/widget3d/weather/Weather4x4Widget$WeatherControl;
    invoke-static {v1}, Lcom/htc/widget3d/weather/Weather4x4Widget;->access$400(Lcom/htc/widget3d/weather/Weather4x4Widget;)Lcom/htc/widget3d/weather/Weather4x4Widget$WeatherControl;

    move-result-object v0

    .line 598
    .local v0, "temp":Lcom/htc/widget3d/weather/Weather4x4Widget$WeatherControl;
    iget-object v1, p0, Lcom/htc/widget3d/weather/Weather4x4Widget$1;->this$0:Lcom/htc/widget3d/weather/Weather4x4Widget;

    iget-object v2, p0, Lcom/htc/widget3d/weather/Weather4x4Widget$1;->this$0:Lcom/htc/widget3d/weather/Weather4x4Widget;

    # getter for: Lcom/htc/widget3d/weather/Weather4x4Widget;->mFxNextWeatherCtr:Lcom/htc/widget3d/weather/Weather4x4Widget$WeatherControl;
    invoke-static {v2}, Lcom/htc/widget3d/weather/Weather4x4Widget;->access$500(Lcom/htc/widget3d/weather/Weather4x4Widget;)Lcom/htc/widget3d/weather/Weather4x4Widget$WeatherControl;

    move-result-object v2

    # setter for: Lcom/htc/widget3d/weather/Weather4x4Widget;->mFxCurWeatherCtr:Lcom/htc/widget3d/weather/Weather4x4Widget$WeatherControl;
    invoke-static {v1, v2}, Lcom/htc/widget3d/weather/Weather4x4Widget;->access$402(Lcom/htc/widget3d/weather/Weather4x4Widget;Lcom/htc/widget3d/weather/Weather4x4Widget$WeatherControl;)Lcom/htc/widget3d/weather/Weather4x4Widget$WeatherControl;

    .line 599
    iget-object v1, p0, Lcom/htc/widget3d/weather/Weather4x4Widget$1;->this$0:Lcom/htc/widget3d/weather/Weather4x4Widget;

    # setter for: Lcom/htc/widget3d/weather/Weather4x4Widget;->mFxNextWeatherCtr:Lcom/htc/widget3d/weather/Weather4x4Widget$WeatherControl;
    invoke-static {v1, v0}, Lcom/htc/widget3d/weather/Weather4x4Widget;->access$502(Lcom/htc/widget3d/weather/Weather4x4Widget;Lcom/htc/widget3d/weather/Weather4x4Widget$WeatherControl;)Lcom/htc/widget3d/weather/Weather4x4Widget$WeatherControl;

    .line 600
    iget-object v1, p0, Lcom/htc/widget3d/weather/Weather4x4Widget$1;->this$0:Lcom/htc/widget3d/weather/Weather4x4Widget;

    # getter for: Lcom/htc/widget3d/weather/Weather4x4Widget;->mFxCurWeatherCtr:Lcom/htc/widget3d/weather/Weather4x4Widget$WeatherControl;
    invoke-static {v1}, Lcom/htc/widget3d/weather/Weather4x4Widget;->access$400(Lcom/htc/widget3d/weather/Weather4x4Widget;)Lcom/htc/widget3d/weather/Weather4x4Widget$WeatherControl;

    move-result-object v1

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Lcom/htc/widget3d/weather/Weather4x4Widget$WeatherControl;->setVisilbe(Z)V

    .line 601
    iget-object v1, p0, Lcom/htc/widget3d/weather/Weather4x4Widget$1;->this$0:Lcom/htc/widget3d/weather/Weather4x4Widget;

    # getter for: Lcom/htc/widget3d/weather/Weather4x4Widget;->mFxNextWeatherCtr:Lcom/htc/widget3d/weather/Weather4x4Widget$WeatherControl;
    invoke-static {v1}, Lcom/htc/widget3d/weather/Weather4x4Widget;->access$500(Lcom/htc/widget3d/weather/Weather4x4Widget;)Lcom/htc/widget3d/weather/Weather4x4Widget$WeatherControl;

    move-result-object v1

    invoke-virtual {v1, v3}, Lcom/htc/widget3d/weather/Weather4x4Widget$WeatherControl;->setVisilbe(Z)V

    .line 602
    iget-object v1, p0, Lcom/htc/widget3d/weather/Weather4x4Widget$1;->this$0:Lcom/htc/widget3d/weather/Weather4x4Widget;

    # getter for: Lcom/htc/widget3d/weather/Weather4x4Widget;->mFxNextWeatherCtr:Lcom/htc/widget3d/weather/Weather4x4Widget$WeatherControl;
    invoke-static {v1}, Lcom/htc/widget3d/weather/Weather4x4Widget;->access$500(Lcom/htc/widget3d/weather/Weather4x4Widget;)Lcom/htc/widget3d/weather/Weather4x4Widget$WeatherControl;

    move-result-object v1

    invoke-virtual {v1}, Lcom/htc/widget3d/weather/Weather4x4Widget$WeatherControl;->stop()V

    .line 603
    iget-object v1, p0, Lcom/htc/widget3d/weather/Weather4x4Widget$1;->this$0:Lcom/htc/widget3d/weather/Weather4x4Widget;

    # setter for: Lcom/htc/widget3d/weather/Weather4x4Widget;->m_bSwipeCity:Z
    invoke-static {v1, v3}, Lcom/htc/widget3d/weather/Weather4x4Widget;->access$202(Lcom/htc/widget3d/weather/Weather4x4Widget;Z)Z

    .line 605
    .end local v0    # "temp":Lcom/htc/widget3d/weather/Weather4x4Widget$WeatherControl;
    :cond_5c
    return-void
.end method

.method public bridge synthetic onMessageReceived(Ljava/lang/Object;)V
    .registers 2
    .param p1, "x0"    # Ljava/lang/Object;

    .prologue
    .line 587
    check-cast p1, Lcom/htc/fusion/fx/FxPlaybackInfo;

    .end local p1    # "x0":Ljava/lang/Object;
    invoke-virtual {p0, p1}, Lcom/htc/widget3d/weather/Weather4x4Widget$1;->onMessageReceived(Lcom/htc/fusion/fx/FxPlaybackInfo;)V

    return-void
.end method
