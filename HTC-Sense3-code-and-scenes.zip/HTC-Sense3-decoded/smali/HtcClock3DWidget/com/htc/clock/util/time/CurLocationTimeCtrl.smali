.class public Lcom/htc/clock/util/time/CurLocationTimeCtrl;
.super Lcom/htc/clock/util/time/TimeCtrl;
.source "CurLocationTimeCtrl.java"

# interfaces
.implements Lcom/htc/clock/util/location/LocationListener;


# instance fields
.field private mCheckAutoTimeAlready:Z

.field private mLocCtrl:Lcom/htc/clock/util/location/LocationCtrl;

.field private mLocCtrlNeedRegister:Z

.field private m_bAutoSyn:Z


# direct methods
.method public constructor <init>()V
    .registers 2

    .prologue
    const/4 v0, 0x0

    .line 17
    invoke-direct {p0}, Lcom/htc/clock/util/time/TimeCtrl;-><init>()V

    .line 19
    iput-boolean v0, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mLocCtrlNeedRegister:Z

    .line 20
    iput-boolean v0, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mCheckAutoTimeAlready:Z

    .line 21
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->m_bAutoSyn:Z

    return-void
.end method


# virtual methods
.method public checkCurTimezoneProblem()Z
    .registers 9

    .prologue
    const/4 v7, 0x1

    const/4 v6, 0x0

    .line 142
    iget-boolean v4, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->m_bAutoSyn:Z

    if-eqz v4, :cond_a8

    .line 143
    iget-object v4, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mLocCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    if-nez v4, :cond_c

    move v4, v7

    .line 173
    :goto_b
    return v4

    .line 146
    :cond_c
    iget-object v4, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mLocCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v4}, Lcom/htc/clock/util/location/LocationCtrl;->getTimeZoneId()Ljava/lang/String;

    move-result-object v3

    .line 147
    .local v3, "timeZoneStr":Ljava/lang/String;
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "checkCurTimezoneProblem~ timZoneStr = "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 148
    const/4 v1, 0x0

    .line 149
    .local v1, "locTz":Ljava/util/TimeZone;
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_92

    .line 150
    invoke-static {v3}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v1

    .line 155
    :goto_33
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "checkCurTimezoneProblem~ locTz = "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 156
    invoke-virtual {p0}, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->getCalendar()Ljava/util/Calendar;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/Calendar;->getTimeZone()Ljava/util/TimeZone;

    move-result-object v0

    .line 157
    .local v0, "SysTz":Ljava/util/TimeZone;
    invoke-virtual {p0}, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->getCalendar()Ljava/util/Calendar;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/Calendar;->getTimeZone()Ljava/util/TimeZone;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/TimeZone;->getID()Ljava/lang/String;

    move-result-object v2

    .line 158
    .local v2, "systz":Ljava/lang/String;
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "checkCurTimezoneProblem~ SysTz = "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 159
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "checkCurTimezoneProblem~ systzID = "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 161
    invoke-virtual {v0, v1}, Ljava/util/TimeZone;->hasSameRules(Ljava/util/TimeZone;)Z

    move-result v4

    if-eqz v4, :cond_97

    move v4, v6

    .line 162
    goto/16 :goto_b

    .line 153
    .end local v0    # "SysTz":Ljava/util/TimeZone;
    .end local v2    # "systz":Ljava/lang/String;
    :cond_92
    invoke-static {}, Ljava/util/TimeZone;->getDefault()Ljava/util/TimeZone;

    move-result-object v1

    goto :goto_33

    .line 164
    .restart local v0    # "SysTz":Ljava/util/TimeZone;
    .restart local v2    # "systz":Ljava/lang/String;
    :cond_97
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_a0

    move v4, v6

    .line 165
    goto/16 :goto_b

    .line 168
    :cond_a0
    const-string v4, "checkCurTimezoneProblem~ timezone not the same~"

    invoke-static {v4}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    move v4, v7

    .line 169
    goto/16 :goto_b

    .end local v0    # "SysTz":Ljava/util/TimeZone;
    .end local v1    # "locTz":Ljava/util/TimeZone;
    .end local v2    # "systz":Ljava/lang/String;
    .end local v3    # "timeZoneStr":Ljava/lang/String;
    :cond_a8
    move v4, v6

    .line 173
    goto/16 :goto_b
.end method

.method public checkSystemAutoSynTimezone()Z
    .registers 5

    .prologue
    .line 179
    const/4 v1, 0x0

    .line 180
    .local v1, "ret":Z
    invoke-virtual {p0}, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->isTimeAutoState()Z

    move-result v0

    .line 181
    .local v0, "isAuto":Z
    iget-boolean v2, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->m_bAutoSyn:Z

    if-eq v2, v0, :cond_c

    .line 182
    const/4 v1, 0x1

    .line 183
    iput-boolean v0, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->m_bAutoSyn:Z

    .line 185
    :cond_c
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "checkSystemAutoSynTimezone~ m_bAutoSyn:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-boolean v3, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->m_bAutoSyn:Z

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 186
    const/4 v2, 0x1

    iput-boolean v2, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mCheckAutoTimeAlready:Z

    .line 187
    return v1
.end method

.method public getCalendar()Ljava/util/Calendar;
    .registers 6

    .prologue
    .line 114
    iget-boolean v2, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->m_bAutoSyn:Z

    if-eqz v2, :cond_20

    .line 115
    iget-object v2, p0, Lcom/htc/clock/util/time/TimeCtrl;->mCalendar:Ljava/util/Calendar;

    if-nez v2, :cond_16

    .line 116
    const-string v2, "TimeCtrl~ getCalendar null"

    invoke-static {v2}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    .line 117
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v2

    iput-object v2, p0, Lcom/htc/clock/util/time/TimeCtrl;->mCalendar:Ljava/util/Calendar;

    .line 122
    :goto_13
    iget-object v2, p0, Lcom/htc/clock/util/time/TimeCtrl;->mCalendar:Ljava/util/Calendar;

    .line 137
    :goto_15
    return-object v2

    .line 120
    :cond_16
    iget-object v2, p0, Lcom/htc/clock/util/time/TimeCtrl;->mCalendar:Ljava/util/Calendar;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    invoke-virtual {v2, v3, v4}, Ljava/util/Calendar;->setTimeInMillis(J)V

    goto :goto_13

    .line 126
    :cond_20
    const/4 v0, 0x0

    .line 127
    .local v0, "timeZoneStr":Ljava/lang/String;
    iget-object v2, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mLocCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    if-eqz v2, :cond_2b

    .line 128
    iget-object v2, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mLocCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v2}, Lcom/htc/clock/util/location/LocationCtrl;->getTimeZoneId()Ljava/lang/String;

    move-result-object v0

    .line 130
    :cond_2b
    const/4 v1, 0x0

    .line 131
    .local v1, "tz":Ljava/util/TimeZone;
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_3b

    .line 132
    invoke-static {v0}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v1

    .line 137
    :goto_36
    invoke-static {v1}, Ljava/util/Calendar;->getInstance(Ljava/util/TimeZone;)Ljava/util/Calendar;

    move-result-object v2

    goto :goto_15

    .line 135
    :cond_3b
    invoke-static {}, Ljava/util/TimeZone;->getDefault()Ljava/util/TimeZone;

    move-result-object v1

    goto :goto_36
.end method

.method public getTimeZoneCity()Ljava/lang/String;
    .registers 4

    .prologue
    const/4 v2, 0x0

    .line 204
    iget-object v0, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mLocCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    .line 205
    .local v0, "locCtrl":Lcom/htc/clock/util/location/LocationCtrl;
    if-nez v0, :cond_c

    .line 206
    const-string v1, "CurLocationTimeCtrl~ getTimeZoneCity~ Ctrl is not init"

    invoke-static {v1}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    move-object v1, v2

    .line 223
    :goto_b
    return-object v1

    .line 209
    :cond_c
    iget-boolean v1, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mCheckAutoTimeAlready:Z

    if-nez v1, :cond_17

    .line 210
    const-string v1, "CurLocationTimeCtrl~ getTimeZoneCity~ setting not init"

    invoke-static {v1}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    move-object v1, v2

    .line 211
    goto :goto_b

    .line 213
    :cond_17
    const-string v1, "CurLocationTimeCtrl~ getTimeZoneCity~"

    invoke-static {v1}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 214
    iget-boolean v1, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->m_bAutoSyn:Z

    if-eqz v1, :cond_2e

    .line 215
    invoke-virtual {p0}, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->checkCurTimezoneProblem()Z

    move-result v1

    if-eqz v1, :cond_29

    .line 216
    sget-object v1, Lcom/htc/clock/util/location/LocationUtil;->sDefaultLocName:Ljava/lang/String;

    goto :goto_b

    .line 219
    :cond_29
    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationCtrl;->getLocName()Ljava/lang/String;

    move-result-object v1

    goto :goto_b

    .line 223
    :cond_2e
    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationCtrl;->getLocName()Ljava/lang/String;

    move-result-object v1

    goto :goto_b
.end method

.method protected handlerInit()V
    .registers 3

    .prologue
    .line 94
    const-string v0, "CurLocationTimeCtrl~ handlerInit"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 95
    iget-object v0, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mLocCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    if-eqz v0, :cond_14

    iget-boolean v0, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mLocCtrlNeedRegister:Z

    if-eqz v0, :cond_14

    .line 96
    iget-object v0, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mLocCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    iget-object v1, p0, Lcom/htc/clock/util/time/TimeCtrl;->mHandler:Landroid/os/Handler;

    invoke-virtual {v0, v1, p0}, Lcom/htc/clock/util/location/LocationCtrl;->register(Landroid/os/Handler;Lcom/htc/clock/util/location/LocationListener;)V

    .line 98
    :cond_14
    invoke-super {p0}, Lcom/htc/clock/util/time/TimeCtrl;->handlerInit()V

    .line 99
    return-void
.end method

.method protected handlerSettingChanged()V
    .registers 4

    .prologue
    .line 103
    iget-boolean v2, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mCheckAutoTimeAlready:Z

    if-nez v2, :cond_15

    const/4 v2, 0x1

    move v1, v2

    .line 104
    .local v1, "firstCheck":Z
    :goto_6
    invoke-virtual {p0}, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->checkSystemAutoSynTimezone()Z

    move-result v0

    .line 107
    .local v0, "changed":Z
    if-nez v0, :cond_e

    if-eqz v1, :cond_11

    .line 108
    :cond_e
    invoke-super {p0}, Lcom/htc/clock/util/time/TimeCtrl;->handlerTimeZoneChanged()V

    .line 110
    :cond_11
    invoke-super {p0}, Lcom/htc/clock/util/time/TimeCtrl;->handlerSettingChanged()V

    .line 111
    return-void

    .line 103
    .end local v0    # "changed":Z
    .end local v1    # "firstCheck":Z
    :cond_15
    const/4 v2, 0x0

    move v1, v2

    goto :goto_6
.end method

.method public init(Landroid/content/Context;Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;ILandroid/os/Handler;Ljava/lang/String;)V
    .registers 12
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "listener"    # Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;
    .param p3, "type"    # I
    .param p4, "handler"    # Landroid/os/Handler;
    .param p5, "timezone"    # Ljava/lang/String;

    .prologue
    .line 23
    const-string v0, "CurLocationTimeCtrl~ init"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 24
    or-int/lit8 p3, p3, 0xc

    .line 25
    iget-object v0, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mLocCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    if-nez v0, :cond_21

    .line 26
    new-instance v0, Lcom/htc/clock/util/location/LocationCtrl;

    invoke-direct {v0, p1}, Lcom/htc/clock/util/location/LocationCtrl;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mLocCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    .line 27
    iget-object v0, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mLocCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationCtrl;->addCurLoc()Z

    .line 28
    iget-object v0, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mLocCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    const-string v1, "cur"

    invoke-virtual {v0, v1}, Lcom/htc/clock/util/location/LocationCtrl;->setLocKey(Ljava/lang/String;)V

    .line 29
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mLocCtrlNeedRegister:Z

    .line 32
    :cond_21
    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move-object v4, p4

    invoke-super/range {v0 .. v5}, Lcom/htc/clock/util/time/TimeCtrl;->init(Landroid/content/Context;Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;ILandroid/os/Handler;Ljava/lang/String;)V

    .line 34
    return-void
.end method

.method public init(Landroid/content/Context;Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;Lcom/htc/clock/util/location/LocationCtrl;ILandroid/os/Handler;)V
    .registers 12
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "listener"    # Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;
    .param p3, "locCtrl"    # Lcom/htc/clock/util/location/LocationCtrl;
    .param p4, "type"    # I
    .param p5, "handler"    # Landroid/os/Handler;

    .prologue
    .line 37
    or-int/lit8 p4, p4, 0xc

    .line 38
    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p4

    move-object v4, p5

    invoke-super/range {v0 .. v5}, Lcom/htc/clock/util/time/TimeCtrl;->init(Landroid/content/Context;Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;ILandroid/os/Handler;Ljava/lang/String;)V

    .line 39
    iput-object p3, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mLocCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    .line 40
    return-void
.end method

.method public isChinaLocationService()Z
    .registers 2

    .prologue
    .line 229
    const/4 v0, 0x0

    return v0
.end method

.method public isHelpTurnOnLoc()Z
    .registers 2

    .prologue
    .line 234
    const/4 v0, 0x0

    return v0
.end method

.method public isResume()Z
    .registers 2

    .prologue
    .line 54
    const/4 v0, 0x0

    return v0
.end method

.method public isTimeAutoState()Z
    .registers 5

    .prologue
    const/4 v3, 0x1

    .line 196
    :try_start_1
    iget-object v1, p0, Lcom/htc/clock/util/time/TimeCtrl;->mContext:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const-string v2, "auto_time"

    invoke-static {v1, v2}, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;)I
    :try_end_c
    .catch Landroid/provider/Settings$SettingNotFoundException; {:try_start_1 .. :try_end_c} :catch_13

    move-result v1

    if-lez v1, :cond_11

    move v1, v3

    .line 199
    :goto_10
    return v1

    .line 196
    :cond_11
    const/4 v1, 0x0

    goto :goto_10

    .line 198
    :catch_13
    move-exception v1

    move-object v0, v1

    .local v0, "snfe":Landroid/provider/Settings$SettingNotFoundException;
    move v1, v3

    .line 199
    goto :goto_10
.end method

.method public isTimezoneAutoSyn()Z
    .registers 2

    .prologue
    .line 191
    iget-boolean v0, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->m_bAutoSyn:Z

    return v0
.end method

.method public onCityUpdate(Lcom/htc/clock/util/location/LocationCtrl;)V
    .registers 3
    .param p1, "weatherCtrl"    # Lcom/htc/clock/util/location/LocationCtrl;

    .prologue
    .line 63
    const-string v0, "CurLocationTimeCtrl~ onCityUpdate"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 64
    invoke-super {p0}, Lcom/htc/clock/util/time/TimeCtrl;->onTimeZoneChanged()V

    .line 66
    return-void
.end method

.method public onTempUnitChange(Lcom/htc/clock/util/location/LocationCtrl;)V
    .registers 2
    .param p1, "weatherCtrl"    # Lcom/htc/clock/util/location/LocationCtrl;

    .prologue
    .line 72
    return-void
.end method

.method protected onTimeZoneChange()V
    .registers 2

    .prologue
    .line 81
    iget-boolean v0, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->m_bAutoSyn:Z

    if-eqz v0, :cond_7

    .line 82
    invoke-super {p0}, Lcom/htc/clock/util/time/TimeCtrl;->onTimeZoneChanged()V

    .line 84
    :cond_7
    return-void
.end method

.method public onWeatherUpdate(Lcom/htc/clock/util/location/LocationCtrl;)V
    .registers 2
    .param p1, "weatherCtrl"    # Lcom/htc/clock/util/location/LocationCtrl;

    .prologue
    .line 78
    return-void
.end method

.method public uninit()V
    .registers 2

    .prologue
    .line 43
    const-string v0, "CurLocationTimeCtrl~ uninit"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 44
    iget-object v0, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mLocCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    if-eqz v0, :cond_12

    iget-boolean v0, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mLocCtrlNeedRegister:Z

    if-eqz v0, :cond_12

    .line 45
    iget-object v0, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mLocCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationCtrl;->unRegister()V

    .line 47
    :cond_12
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;->mLocCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    .line 48
    invoke-super {p0}, Lcom/htc/clock/util/time/TimeCtrl;->uninit()V

    .line 49
    return-void
.end method
