.class Lcom/htc/clock/util/time/TimeCtrl$MyUIHandler;
.super Landroid/os/Handler;
.source "TimeCtrl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock/util/time/TimeCtrl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "MyUIHandler"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/clock/util/time/TimeCtrl;


# direct methods
.method constructor <init>(Lcom/htc/clock/util/time/TimeCtrl;Landroid/os/Looper;)V
    .registers 3
    .param p2, "looper"    # Landroid/os/Looper;

    .prologue
    .line 194
    iput-object p1, p0, Lcom/htc/clock/util/time/TimeCtrl$MyUIHandler;->this$0:Lcom/htc/clock/util/time/TimeCtrl;

    .line 195
    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 196
    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .registers 6
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    .line 198
    iget v0, p1, Landroid/os/Message;->what:I

    .line 199
    .local v0, "what":I
    packed-switch v0, :pswitch_data_3a

    .line 219
    :goto_5
    return-void

    .line 201
    :pswitch_6
    iget-object v1, p0, Lcom/htc/clock/util/time/TimeCtrl$MyUIHandler;->this$0:Lcom/htc/clock/util/time/TimeCtrl;

    iget-object v1, v1, Lcom/htc/clock/util/time/TimeCtrl;->mCalendar:Ljava/util/Calendar;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Ljava/util/Calendar;->setTimeInMillis(J)V

    .line 202
    iget-object v1, p0, Lcom/htc/clock/util/time/TimeCtrl$MyUIHandler;->this$0:Lcom/htc/clock/util/time/TimeCtrl;

    invoke-virtual {v1}, Lcom/htc/clock/util/time/TimeCtrl;->onSecond()V

    .line 203
    const/16 v1, 0x3e9

    iget-object v2, p0, Lcom/htc/clock/util/time/TimeCtrl$MyUIHandler;->this$0:Lcom/htc/clock/util/time/TimeCtrl;

    invoke-static {v2}, Lcom/htc/clock/util/time/TimeCtrl;->access$100(Lcom/htc/clock/util/time/TimeCtrl;)J

    move-result-wide v2

    invoke-virtual {p0, v1, v2, v3}, Landroid/os/Handler;->sendEmptyMessageAtTime(IJ)Z

    goto :goto_5

    .line 206
    :pswitch_22
    iget-object v1, p0, Lcom/htc/clock/util/time/TimeCtrl$MyUIHandler;->this$0:Lcom/htc/clock/util/time/TimeCtrl;

    invoke-virtual {v1}, Lcom/htc/clock/util/time/TimeCtrl;->onMinute()V

    goto :goto_5

    .line 209
    :pswitch_28
    iget-object v1, p0, Lcom/htc/clock/util/time/TimeCtrl$MyUIHandler;->this$0:Lcom/htc/clock/util/time/TimeCtrl;

    invoke-virtual {v1}, Lcom/htc/clock/util/time/TimeCtrl;->onTimeChanged()V

    goto :goto_5

    .line 212
    :pswitch_2e
    iget-object v1, p0, Lcom/htc/clock/util/time/TimeCtrl$MyUIHandler;->this$0:Lcom/htc/clock/util/time/TimeCtrl;

    invoke-virtual {v1}, Lcom/htc/clock/util/time/TimeCtrl;->onTimeZoneChanged()V

    goto :goto_5

    .line 215
    :pswitch_34
    iget-object v1, p0, Lcom/htc/clock/util/time/TimeCtrl$MyUIHandler;->this$0:Lcom/htc/clock/util/time/TimeCtrl;

    invoke-virtual {v1}, Lcom/htc/clock/util/time/TimeCtrl;->onSettingChanged()V

    goto :goto_5

    .line 199
    :pswitch_data_3a
    .packed-switch 0x3e9
        :pswitch_6
        :pswitch_22
        :pswitch_28
        :pswitch_2e
        :pswitch_34
    .end packed-switch
.end method
