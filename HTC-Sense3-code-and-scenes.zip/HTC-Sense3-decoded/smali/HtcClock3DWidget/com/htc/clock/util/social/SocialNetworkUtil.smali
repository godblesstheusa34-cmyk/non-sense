.class public Lcom/htc/clock/util/social/SocialNetworkUtil;
.super Ljava/lang/Object;
.source "SocialNetworkUtil.java"


# static fields
.field static ACTION_PLUGIN_COMPOSE_MESSAGE:Ljava/lang/String;

.field static API_level:I

.field static CLASS_FRIENDSTREAM_AP:Ljava/lang/String;

.field static CLASS_FRIENDSTREAM_ENTRANCE:Ljava/lang/String;

.field static CLASS_FRIENDSTREAM_SETTINGS:Ljava/lang/String;

.field static CLASS_TABLET_FRIENDSTREAM_AP:Ljava/lang/String;

.field static EXTRA_SETTINGS_PAGE:Ljava/lang/String;

.field static FEATURE_NAME_FRIENDSTREAM_ADAPTER:Ljava/lang/String;

.field static METADATA_PLUGIN_ACCOUNT_TYPE:Ljava/lang/String;

.field static PKG_FRIENDSTREAM_AP:Ljava/lang/String;

.field static PREF_SCREEN_KEY_ACCOUNTS_AND_SYNC:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .prologue
    const-string v1, "com.htc.friendstream.FriendStream"

    .line 16
    const-string v0, "com.htc.friendstream.intent.action.COMPOSE_MESSAGE"

    sput-object v0, Lcom/htc/clock/util/social/SocialNetworkUtil;->ACTION_PLUGIN_COMPOSE_MESSAGE:Ljava/lang/String;

    .line 17
    const-string v0, "com.htc.friendstream.intent.metadata.ACCOUNT_TYPE"

    sput-object v0, Lcom/htc/clock/util/social/SocialNetworkUtil;->METADATA_PLUGIN_ACCOUNT_TYPE:Ljava/lang/String;

    .line 18
    const-string v0, "AddFriendStreamAdapter"

    sput-object v0, Lcom/htc/clock/util/social/SocialNetworkUtil;->FEATURE_NAME_FRIENDSTREAM_ADAPTER:Ljava/lang/String;

    .line 19
    const-string v0, "com.htc.friendstream"

    sput-object v0, Lcom/htc/clock/util/social/SocialNetworkUtil;->PKG_FRIENDSTREAM_AP:Ljava/lang/String;

    .line 20
    const-string v0, "com.htc.friendstream.FriendStream"

    sput-object v1, Lcom/htc/clock/util/social/SocialNetworkUtil;->CLASS_FRIENDSTREAM_AP:Ljava/lang/String;

    .line 21
    const-string v0, "com.htc.friendstream.SettingsActivity"

    sput-object v0, Lcom/htc/clock/util/social/SocialNetworkUtil;->CLASS_FRIENDSTREAM_SETTINGS:Ljava/lang/String;

    .line 22
    const-string v0, "com.htc.friendstream.intent.EXTRA_SETTINGS_PAGE"

    sput-object v0, Lcom/htc/clock/util/social/SocialNetworkUtil;->EXTRA_SETTINGS_PAGE:Ljava/lang/String;

    .line 23
    const-string v0, "prefscreen_accounts"

    sput-object v0, Lcom/htc/clock/util/social/SocialNetworkUtil;->PREF_SCREEN_KEY_ACCOUNTS_AND_SYNC:Ljava/lang/String;

    .line 24
    const-string v0, "com.htc.friendstream.SwitchMultipleActivityMain"

    sput-object v0, Lcom/htc/clock/util/social/SocialNetworkUtil;->CLASS_TABLET_FRIENDSTREAM_AP:Ljava/lang/String;

    .line 25
    const-string v0, "com.htc.friendstream.FriendStream"

    sput-object v1, Lcom/htc/clock/util/social/SocialNetworkUtil;->CLASS_FRIENDSTREAM_ENTRANCE:Ljava/lang/String;

    .line 26
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    sput v0, Lcom/htc/clock/util/social/SocialNetworkUtil;->API_level:I

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .prologue
    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static isLoggedIn(Landroid/content/Context;)Z
    .registers 13
    .param p0, "context"    # Landroid/content/Context;

    .prologue
    const/4 v11, 0x0

    .line 29
    sget-object v9, Lcom/htc/clock/util/social/SocialNetworkUtil;->FEATURE_NAME_FRIENDSTREAM_ADAPTER:Ljava/lang/String;

    invoke-static {p0, v9}, Lcom/htc/opensense/plugin/PluginRegistryHelper;->getPlugins(Landroid/content/Context;Ljava/lang/String;)[Lcom/htc/opensense/plugin/Plugin;

    move-result-object v7

    .line 31
    .local v7, "plugins":[Lcom/htc/opensense/plugin/Plugin;
    invoke-static {p0}, Landroid/accounts/AccountManager;->get(Landroid/content/Context;)Landroid/accounts/AccountManager;

    move-result-object v0

    .line 32
    .local v0, "am":Landroid/accounts/AccountManager;
    const/4 v8, 0x0

    .line 33
    .local v8, "type":Ljava/lang/String;
    const/4 v4, 0x0

    .line 34
    .local v4, "isLoggedIn":Z
    move-object v1, v7

    .local v1, "arr$":[Lcom/htc/opensense/plugin/Plugin;
    array-length v5, v1

    .local v5, "len$":I
    const/4 v3, 0x0

    .local v3, "i$":I
    :goto_10
    if-ge v3, v5, :cond_6b

    aget-object v6, v1, v3

    .line 35
    .local v6, "plugin":Lcom/htc/opensense/plugin/Plugin;
    const/4 v8, 0x0

    .line 36
    if-eqz v6, :cond_8d

    .line 37
    iget-object v9, v6, Lcom/htc/opensense/plugin/Plugin;->pluginMeta:Ljava/lang/String;

    if-eqz v9, :cond_82

    .line 38
    iget-object v8, v6, Lcom/htc/opensense/plugin/Plugin;->pluginMeta:Ljava/lang/String;

    .line 43
    :cond_1d
    :goto_1d
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "SocialNetworkUtil type:"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 44
    invoke-static {v8}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_8d

    .line 45
    invoke-virtual {v0, v8}, Landroid/accounts/AccountManager;->getAccountsByType(Ljava/lang/String;)[Landroid/accounts/Account;

    move-result-object v2

    .line 46
    .local v2, "as":[Landroid/accounts/Account;
    if-eqz v2, :cond_8d

    array-length v9, v2

    if-lez v9, :cond_8d

    .line 47
    aget-object v9, v2, v11

    if-eqz v9, :cond_8d

    aget-object v9, v2, v11

    iget-object v9, v9, Landroid/accounts/Account;->name:Ljava/lang/String;

    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    if-nez v9, :cond_8d

    .line 48
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "SocialNetworkUtil as[0].name:"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    aget-object v10, v2, v11

    iget-object v10, v10, Landroid/accounts/Account;->name:Ljava/lang/String;

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 49
    const/4 v4, 0x1

    .line 57
    .end local v2    # "as":[Landroid/accounts/Account;
    .end local v6    # "plugin":Lcom/htc/opensense/plugin/Plugin;
    :cond_6b
    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "SocialNetworkUtil isloggedin:"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 58
    return v4

    .line 40
    .restart local v6    # "plugin":Lcom/htc/opensense/plugin/Plugin;
    :cond_82
    iget-object v9, v6, Lcom/htc/opensense/plugin/Plugin;->component_name:Landroid/content/ComponentName;

    if-eqz v9, :cond_1d

    .line 41
    iget-object v9, v6, Lcom/htc/opensense/plugin/Plugin;->component_name:Landroid/content/ComponentName;

    invoke-virtual {v9}, Landroid/content/ComponentName;->getPackageName()Ljava/lang/String;

    move-result-object v8

    goto :goto_1d

    .line 34
    :cond_8d
    add-int/lit8 v3, v3, 0x1

    goto :goto_10
.end method

.method public static launchLoginPage(Landroid/content/Context;)V
    .registers 5
    .param p0, "hostActivity"    # Landroid/content/Context;

    .prologue
    .line 62
    sget v1, Lcom/htc/clock/util/social/SocialNetworkUtil;->API_level:I

    const/16 v2, 0xb

    if-lt v1, v2, :cond_a

    .line 63
    const-string v1, "com.htc.friendstream.settings.AddAccountActivity"

    sput-object v1, Lcom/htc/clock/util/social/SocialNetworkUtil;->CLASS_FRIENDSTREAM_SETTINGS:Ljava/lang/String;

    .line 64
    :cond_a
    new-instance v1, Landroid/content/Intent;

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    sget-object v2, Lcom/htc/clock/util/social/SocialNetworkUtil;->PKG_FRIENDSTREAM_AP:Ljava/lang/String;

    sget-object v3, Lcom/htc/clock/util/social/SocialNetworkUtil;->CLASS_FRIENDSTREAM_SETTINGS:Ljava/lang/String;

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    const/high16 v2, 0x10000000

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    move-result-object v1

    sget-object v2, Lcom/htc/clock/util/social/SocialNetworkUtil;->EXTRA_SETTINGS_PAGE:Ljava/lang/String;

    sget-object v3, Lcom/htc/clock/util/social/SocialNetworkUtil;->PREF_SCREEN_KEY_ACCOUNTS_AND_SYNC:Ljava/lang/String;

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    .line 68
    .local v0, "intent":Landroid/content/Intent;
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 69
    return-void
.end method

.method public static launchMainPage(Landroid/content/Context;)V
    .registers 4
    .param p0, "hostActivity"    # Landroid/content/Context;

    .prologue
    .line 80
    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 81
    .local v0, "intent":Landroid/content/Intent;
    sget-object v1, Lcom/htc/clock/util/social/SocialNetworkUtil;->PKG_FRIENDSTREAM_AP:Ljava/lang/String;

    sget-object v2, Lcom/htc/clock/util/social/SocialNetworkUtil;->CLASS_FRIENDSTREAM_AP:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 82
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 84
    return-void
.end method
