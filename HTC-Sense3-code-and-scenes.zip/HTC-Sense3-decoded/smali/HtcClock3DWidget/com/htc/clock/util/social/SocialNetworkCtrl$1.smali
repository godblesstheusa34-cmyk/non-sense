.class Lcom/htc/clock/util/social/SocialNetworkCtrl$1;
.super Ljava/lang/Object;
.source "SocialNetworkCtrl.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock/util/social/SocialNetworkCtrl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/clock/util/social/SocialNetworkCtrl;


# direct methods
.method constructor <init>(Lcom/htc/clock/util/social/SocialNetworkCtrl;)V
    .registers 2

    .prologue
    .line 73
    iput-object p1, p0, Lcom/htc/clock/util/social/SocialNetworkCtrl$1;->this$0:Lcom/htc/clock/util/social/SocialNetworkCtrl;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    .prologue
    .line 77
    iget-object v1, p0, Lcom/htc/clock/util/social/SocialNetworkCtrl$1;->this$0:Lcom/htc/clock/util/social/SocialNetworkCtrl;

    invoke-static {v1}, Lcom/htc/clock/util/social/SocialNetworkCtrl;->access$100(Lcom/htc/clock/util/social/SocialNetworkCtrl;)Lcom/htc/clock/util/social/SocialNetworkCtrl$OnUpdateListener;

    move-result-object v0

    .line 78
    .local v0, "listener":Lcom/htc/clock/util/social/SocialNetworkCtrl$OnUpdateListener;
    if-eqz v0, :cond_11

    .line 79
    iget-object v1, p0, Lcom/htc/clock/util/social/SocialNetworkCtrl$1;->this$0:Lcom/htc/clock/util/social/SocialNetworkCtrl;

    invoke-virtual {v1}, Lcom/htc/clock/util/social/SocialNetworkCtrl;->getLastSocialData()Lcom/htc/clock/util/social/SocialData;

    move-result-object v1

    invoke-interface {v0, v1}, Lcom/htc/clock/util/social/SocialNetworkCtrl$OnUpdateListener;->onUpdate(Lcom/htc/clock/util/social/SocialData;)V

    .line 80
    :cond_11
    return-void
.end method
