.class public final enum Lcom/htc/clock/util/location/LocationCtrl$LocationState;
.super Ljava/lang/Enum;
.source "LocationCtrl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock/util/location/LocationCtrl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "LocationState"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum",
        "<",
        "Lcom/htc/clock/util/location/LocationCtrl$LocationState;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/htc/clock/util/location/LocationCtrl$LocationState;

.field public static final enum NO_DATA:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

.field public static final enum OK:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

.field public static final enum ONLY_LOC:Lcom/htc/clock/util/location/LocationCtrl$LocationState;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    .prologue
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x0

    .line 54
    new-instance v0, Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    const-string v1, "NO_DATA"

    invoke-direct {v0, v1, v2}, Lcom/htc/clock/util/location/LocationCtrl$LocationState;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->NO_DATA:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    new-instance v0, Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    const-string v1, "ONLY_LOC"

    invoke-direct {v0, v1, v3}, Lcom/htc/clock/util/location/LocationCtrl$LocationState;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->ONLY_LOC:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    new-instance v0, Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    const-string v1, "OK"

    invoke-direct {v0, v1, v4}, Lcom/htc/clock/util/location/LocationCtrl$LocationState;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->OK:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    .line 53
    const/4 v0, 0x3

    new-array v0, v0, [Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    sget-object v1, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->NO_DATA:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    aput-object v1, v0, v2

    sget-object v1, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->ONLY_LOC:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    aput-object v1, v0, v3

    sget-object v1, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->OK:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    aput-object v1, v0, v4

    sput-object v0, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->$VALUES:[Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 53
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/htc/clock/util/location/LocationCtrl$LocationState;
    .registers 2
    .param p0, "name"    # Ljava/lang/String;

    .prologue
    .line 53
    const-class v0, Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    .end local p0    # "name":Ljava/lang/String;
    check-cast p0, Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    return-object p0
.end method

.method public static values()[Lcom/htc/clock/util/location/LocationCtrl$LocationState;
    .registers 1

    .prologue
    .line 53
    sget-object v0, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->$VALUES:[Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    invoke-virtual {v0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    return-object v0
.end method
