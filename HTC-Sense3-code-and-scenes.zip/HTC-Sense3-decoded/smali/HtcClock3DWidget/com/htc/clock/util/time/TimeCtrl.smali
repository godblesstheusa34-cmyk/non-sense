.class public Lcom/htc/clock/util/time/TimeCtrl;
.super Ljava/lang/Object;
.source "TimeCtrl.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/htc/clock/util/time/TimeCtrl$1;,
        Lcom/htc/clock/util/time/TimeCtrl$DbChangeObserver;,
        Lcom/htc/clock/util/time/TimeCtrl$MyUIHandler;,
        Lcom/htc/clock/util/time/TimeCtrl$MyBGHandler;,
        Lcom/htc/clock/util/time/TimeCtrl$MyReceiver;,
        Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;
    }
.end annotation


# static fields
.field public static final TIME_TYPE_MIN:I = 0x2

.field public static final TIME_TYPE_SETTING:I = 0x8

.field public static final TIME_TYPE_TIMEZONE:I = 0x4

.field public static final WHAT_ON_INIT_DATA:I = 0x3

.field public static final WHAT_ON_SETTING_CHANGED:I = 0x2

.field public static final WHAT_ON_START_SECOND:I = 0x1

.field public static final WHAT_UI_MINUTE:I = 0x3ea

.field public static final WHAT_UI_SECOND:I = 0x3e9

.field public static final WHAT_UI_SETTING_CHANGED:I = 0x3ed

.field public static final WHAT_UI_TIMEZONE_CHANGED:I = 0x3ec

.field public static final WHAT_UI_TIME_CHANGED:I = 0x3eb

.field private static mB24hourFormat:Z


# instance fields
.field mBGLooper:Landroid/os/Looper;

.field mCalendar:Ljava/util/Calendar;

.field private mCityCode:Ljava/lang/String;

.field protected mCityName:Ljava/lang/String;

.field mContext:Landroid/content/Context;

.field private mDateFormat:Ljava/lang/String;

.field mHandler:Landroid/os/Handler;

.field mListener:Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;

.field mReceiver:Landroid/content/BroadcastReceiver;

.field mSettingChangeObserver:Landroid/database/ContentObserver;

.field private mTimeZoneStr:Ljava/lang/String;

.field mType:I

.field mUIHandler:Landroid/os/Handler;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .prologue
    .line 323
    const/4 v0, 0x0

    sput-boolean v0, Lcom/htc/clock/util/time/TimeCtrl;->mB24hourFormat:Z

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    .prologue
    .line 25
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 53
    new-instance v0, Lcom/htc/clock/util/time/TimeCtrl$MyUIHandler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, p0, v1}, Lcom/htc/clock/util/time/TimeCtrl$MyUIHandler;-><init>(Lcom/htc/clock/util/time/TimeCtrl;Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mUIHandler:Landroid/os/Handler;

    .line 306
    const-string v0, "EE, MM-dd"

    iput-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mDateFormat:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$100(Lcom/htc/clock/util/time/TimeCtrl;)J
    .registers 3
    .param p0, "x0"    # Lcom/htc/clock/util/time/TimeCtrl;

    .prologue
    .line 25
    invoke-direct {p0}, Lcom/htc/clock/util/time/TimeCtrl;->getNextSecTime()J

    move-result-wide v0

    return-wide v0
.end method

.method private getNextSecTime()J
    .registers 9

    .prologue
    const-wide/16 v6, 0x3e8

    .line 223
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    .line 224
    .local v2, "now":J
    rem-long v4, v2, v6

    sub-long v4, v6, v4

    add-long v0, v2, v4

    .line 225
    .local v0, "next":J
    return-wide v0
.end method

.method private initBGHandler(Landroid/os/Handler;)V
    .registers 5
    .param p1, "handler"    # Landroid/os/Handler;

    .prologue
    .line 112
    const/4 v0, 0x0

    .line 113
    .local v0, "looper":Landroid/os/Looper;
    if-eqz p1, :cond_7

    .line 114
    invoke-virtual {p1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v0

    .line 116
    :cond_7
    if-nez v0, :cond_1f

    .line 117
    iget-object v2, p0, Lcom/htc/clock/util/time/TimeCtrl;->mBGLooper:Landroid/os/Looper;

    if-nez v2, :cond_1d

    .line 118
    new-instance v1, Landroid/os/HandlerThread;

    const-string v2, "TimeCtrl"

    invoke-direct {v1, v2}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    .line 119
    .local v1, "thread":Landroid/os/HandlerThread;
    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    .line 120
    invoke-virtual {v1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v2

    iput-object v2, p0, Lcom/htc/clock/util/time/TimeCtrl;->mBGLooper:Landroid/os/Looper;

    .line 122
    .end local v1    # "thread":Landroid/os/HandlerThread;
    :cond_1d
    iget-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mBGLooper:Landroid/os/Looper;

    .line 124
    :cond_1f
    new-instance v2, Lcom/htc/clock/util/time/TimeCtrl$MyBGHandler;

    invoke-direct {v2, p0, v0}, Lcom/htc/clock/util/time/TimeCtrl$MyBGHandler;-><init>(Lcom/htc/clock/util/time/TimeCtrl;Landroid/os/Looper;)V

    iput-object v2, p0, Lcom/htc/clock/util/time/TimeCtrl;->mHandler:Landroid/os/Handler;

    .line 125
    return-void
.end method


# virtual methods
.method public getCalendar()Ljava/util/Calendar;
    .registers 3

    .prologue
    .line 346
    iget-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mCalendar:Ljava/util/Calendar;

    if-nez v0, :cond_e

    .line 347
    const-string v0, "TimeCtrl~ getCalendar null"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    .line 348
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v0

    .line 351
    :goto_d
    return-object v0

    .line 350
    :cond_e
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "TimeCtrl~ getCalendar tz:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/htc/clock/util/time/TimeCtrl;->mCalendar:Ljava/util/Calendar;

    invoke-virtual {v1}, Ljava/util/Calendar;->getTimeZone()Ljava/util/TimeZone;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/TimeZone;->getID()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 351
    iget-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mCalendar:Ljava/util/Calendar;

    goto :goto_d
.end method

.method public getDateFormat()Ljava/lang/String;
    .registers 2

    .prologue
    .line 308
    iget-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mDateFormat:Ljava/lang/String;

    return-object v0
.end method

.method public getTimeZoneCity()Ljava/lang/String;
    .registers 2

    .prologue
    .line 356
    iget-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mCityName:Ljava/lang/String;

    return-object v0
.end method

.method protected handlerInit()V
    .registers 8

    .prologue
    const/16 v6, 0x3ec

    .line 284
    const-string v4, "TimeCtrl~ handlerInit"

    invoke-static {v4}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 285
    const/4 v0, 0x0

    .line 286
    .local v0, "bUpdateCity":Z
    iget-object v4, p0, Lcom/htc/clock/util/time/TimeCtrl;->mCityCode:Ljava/lang/String;

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_3f

    .line 287
    iget-object v4, p0, Lcom/htc/clock/util/time/TimeCtrl;->mContext:Landroid/content/Context;

    invoke-virtual {v4}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v4

    iget-object v5, p0, Lcom/htc/clock/util/time/TimeCtrl;->mCityCode:Ljava/lang/String;

    invoke-static {v4, v5}, Lcom/htc/util/weather/WeatherUtility;->getLocationListByCode(Landroid/content/ContentResolver;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 288
    .local v1, "locationListCursor":Landroid/database/Cursor;
    if-eqz v1, :cond_3f

    .line 289
    invoke-interface {v1}, Landroid/database/Cursor;->getCount()I

    move-result v4

    if-lez v4, :cond_3c

    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v4

    if-eqz v4, :cond_3c

    .line 290
    invoke-static {v1}, Lcom/htc/util/weather/WeatherUtility;->CursorToWeatherLocation(Landroid/database/Cursor;)Lcom/htc/util/weather/WeatherLocation;

    move-result-object v2

    .line 291
    .local v2, "tempWeatherLocation":Lcom/htc/util/weather/WeatherLocation;
    invoke-virtual {v2}, Lcom/htc/util/weather/WeatherLocation;->getName()Ljava/lang/String;

    move-result-object v4

    iput-object v4, p0, Lcom/htc/clock/util/time/TimeCtrl;->mCityName:Ljava/lang/String;

    .line 292
    invoke-virtual {v2}, Lcom/htc/util/weather/WeatherLocation;->getTimezoneId()Ljava/lang/String;

    move-result-object v3

    .line 293
    .local v3, "timeZoneStr":Ljava/lang/String;
    invoke-virtual {p0, v3}, Lcom/htc/clock/util/time/TimeCtrl;->setTimeZone(Ljava/lang/String;)V

    .line 294
    const/4 v0, 0x1

    .line 296
    .end local v2    # "tempWeatherLocation":Lcom/htc/util/weather/WeatherLocation;
    .end local v3    # "timeZoneStr":Ljava/lang/String;
    :cond_3c
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 299
    .end local v1    # "locationListCursor":Landroid/database/Cursor;
    :cond_3f
    invoke-virtual {p0}, Lcom/htc/clock/util/time/TimeCtrl;->handlerSettingChanged()V

    .line 300
    if-eqz v0, :cond_4e

    .line 301
    iget-object v4, p0, Lcom/htc/clock/util/time/TimeCtrl;->mUIHandler:Landroid/os/Handler;

    invoke-static {v4, v6}, Lcom/htc/clock/util/MyUtil;->removeMessage(Landroid/os/Handler;I)V

    .line 302
    iget-object v4, p0, Lcom/htc/clock/util/time/TimeCtrl;->mUIHandler:Landroid/os/Handler;

    invoke-static {v4, v6}, Lcom/htc/clock/util/MyUtil;->sendMessage(Landroid/os/Handler;I)V

    .line 304
    :cond_4e
    return-void
.end method

.method protected handlerSettingChanged()V
    .registers 4

    .prologue
    .line 277
    invoke-virtual {p0}, Lcom/htc/clock/util/time/TimeCtrl;->updateFormat()Z

    move-result v0

    .line 278
    .local v0, "bUpdate":Z
    if-eqz v0, :cond_d

    .line 279
    iget-object v1, p0, Lcom/htc/clock/util/time/TimeCtrl;->mUIHandler:Landroid/os/Handler;

    const/16 v2, 0x3ed

    invoke-static {v1, v2}, Lcom/htc/clock/util/MyUtil;->sendMessage(Landroid/os/Handler;I)V

    .line 281
    :cond_d
    return-void
.end method

.method protected handlerTimeZoneChanged()V
    .registers 3

    .prologue
    const/16 v1, 0x3ec

    .line 164
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v0

    iput-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mCalendar:Ljava/util/Calendar;

    .line 165
    iget-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mUIHandler:Landroid/os/Handler;

    invoke-static {v0, v1}, Lcom/htc/clock/util/MyUtil;->removeMessage(Landroid/os/Handler;I)V

    .line 166
    iget-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mUIHandler:Landroid/os/Handler;

    invoke-static {v0, v1}, Lcom/htc/clock/util/MyUtil;->sendMessage(Landroid/os/Handler;I)V

    .line 167
    return-void
.end method

.method public init(Landroid/content/Context;Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;ILandroid/os/Handler;Ljava/lang/String;)V
    .registers 11
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "listener"    # Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;
    .param p3, "type"    # I
    .param p4, "handler"    # Landroid/os/Handler;
    .param p5, "locCode"    # Ljava/lang/String;

    .prologue
    const/4 v3, 0x0

    .line 62
    iget-object v1, p0, Lcom/htc/clock/util/time/TimeCtrl;->mReceiver:Landroid/content/BroadcastReceiver;

    if-nez v1, :cond_76

    .line 63
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "TimeCtrl~ init mCityCode:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 64
    iput-object p1, p0, Lcom/htc/clock/util/time/TimeCtrl;->mContext:Landroid/content/Context;

    .line 65
    iput-object p2, p0, Lcom/htc/clock/util/time/TimeCtrl;->mListener:Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;

    .line 66
    iput p3, p0, Lcom/htc/clock/util/time/TimeCtrl;->mType:I

    .line 67
    iput-object p5, p0, Lcom/htc/clock/util/time/TimeCtrl;->mCityCode:Ljava/lang/String;

    .line 68
    invoke-virtual {p0, v3}, Lcom/htc/clock/util/time/TimeCtrl;->setTimeZone(Ljava/lang/String;)V

    .line 70
    invoke-direct {p0, p4}, Lcom/htc/clock/util/time/TimeCtrl;->initBGHandler(Landroid/os/Handler;)V

    .line 76
    new-instance v1, Lcom/htc/clock/util/time/TimeCtrl$MyReceiver;

    invoke-direct {v1, p0, v3}, Lcom/htc/clock/util/time/TimeCtrl$MyReceiver;-><init>(Lcom/htc/clock/util/time/TimeCtrl;Lcom/htc/clock/util/time/TimeCtrl$1;)V

    iput-object v1, p0, Lcom/htc/clock/util/time/TimeCtrl;->mReceiver:Landroid/content/BroadcastReceiver;

    .line 77
    new-instance v0, Landroid/content/IntentFilter;

    invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V

    .line 78
    .local v0, "filter":Landroid/content/IntentFilter;
    const-string v1, "android.intent.action.TIME_SET"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 79
    and-int/lit8 v1, p3, 0x2

    if-lez v1, :cond_43

    .line 80
    const-string v1, "android.intent.action.TIME_TICK"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 82
    :cond_43
    and-int/lit8 v1, p3, 0x4

    if-lez v1, :cond_4c

    .line 83
    const-string v1, "android.intent.action.TIMEZONE_CHANGED"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 85
    :cond_4c
    iget-object v1, p0, Lcom/htc/clock/util/time/TimeCtrl;->mReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {p1, v1, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 87
    iget-object v1, p0, Lcom/htc/clock/util/time/TimeCtrl;->mSettingChangeObserver:Landroid/database/ContentObserver;

    if-nez v1, :cond_70

    and-int/lit8 v1, p3, 0x8

    if-lez v1, :cond_70

    .line 88
    new-instance v1, Lcom/htc/clock/util/time/TimeCtrl$DbChangeObserver;

    iget-object v2, p0, Lcom/htc/clock/util/time/TimeCtrl;->mHandler:Landroid/os/Handler;

    invoke-direct {v1, p0, v2}, Lcom/htc/clock/util/time/TimeCtrl$DbChangeObserver;-><init>(Lcom/htc/clock/util/time/TimeCtrl;Landroid/os/Handler;)V

    iput-object v1, p0, Lcom/htc/clock/util/time/TimeCtrl;->mSettingChangeObserver:Landroid/database/ContentObserver;

    .line 89
    iget-object v1, p0, Lcom/htc/clock/util/time/TimeCtrl;->mContext:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    sget-object v2, Landroid/provider/Settings$System;->CONTENT_URI:Landroid/net/Uri;

    const/4 v3, 0x1

    iget-object v4, p0, Lcom/htc/clock/util/time/TimeCtrl;->mSettingChangeObserver:Landroid/database/ContentObserver;

    invoke-virtual {v1, v2, v3, v4}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V

    .line 91
    :cond_70
    iget-object v1, p0, Lcom/htc/clock/util/time/TimeCtrl;->mHandler:Landroid/os/Handler;

    const/4 v2, 0x3

    invoke-static {v1, v2}, Lcom/htc/clock/util/MyUtil;->sendMessage(Landroid/os/Handler;I)V

    .line 93
    .end local v0    # "filter":Landroid/content/IntentFilter;
    :cond_76
    return-void
.end method

.method public is24HourFormat()Z
    .registers 2

    .prologue
    .line 325
    sget-boolean v0, Lcom/htc/clock/util/time/TimeCtrl;->mB24hourFormat:Z

    return v0
.end method

.method protected onMinute()V
    .registers 2

    .prologue
    .line 229
    iget-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mListener:Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;

    .line 230
    .local v0, "listener":Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;
    if-eqz v0, :cond_7

    .line 231
    invoke-interface {v0}, Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;->onMinute()V

    .line 233
    :cond_7
    return-void
.end method

.method protected onSecond()V
    .registers 2

    .prologue
    .line 236
    iget-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mListener:Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;

    .line 237
    .local v0, "listener":Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;
    if-eqz v0, :cond_7

    .line 238
    invoke-interface {v0}, Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;->onSecond()V

    .line 240
    :cond_7
    return-void
.end method

.method protected onSettingChanged()V
    .registers 2

    .prologue
    .line 257
    iget-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mListener:Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;

    .line 258
    .local v0, "listener":Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;
    if-eqz v0, :cond_7

    .line 259
    invoke-interface {v0}, Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;->onFormatChanged()V

    .line 261
    :cond_7
    return-void
.end method

.method protected onTimeChanged()V
    .registers 2

    .prologue
    .line 243
    iget-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mListener:Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;

    .line 244
    .local v0, "listener":Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;
    if-eqz v0, :cond_7

    .line 245
    invoke-interface {v0}, Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;->onTimeChanged()V

    .line 247
    :cond_7
    return-void
.end method

.method protected onTimeZoneChanged()V
    .registers 2

    .prologue
    .line 250
    iget-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mListener:Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;

    .line 251
    .local v0, "listener":Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;
    if-eqz v0, :cond_7

    .line 252
    invoke-interface {v0}, Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;->onTimeZoneChanged()V

    .line 254
    :cond_7
    return-void
.end method

.method public setTimeZone(Ljava/lang/String;)V
    .registers 5
    .param p1, "timezone"    # Ljava/lang/String;

    .prologue
    .line 96
    const/4 v0, 0x0

    .line 97
    .local v0, "tz":Ljava/util/TimeZone;
    iput-object p1, p0, Lcom/htc/clock/util/time/TimeCtrl;->mTimeZoneStr:Ljava/lang/String;

    .line 98
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_d

    .line 99
    invoke-static {p1}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v0

    .line 102
    :cond_d
    if-eqz v0, :cond_36

    .line 103
    invoke-static {v0}, Ljava/util/Calendar;->getInstance(Ljava/util/TimeZone;)Ljava/util/Calendar;

    move-result-object v1

    iput-object v1, p0, Lcom/htc/clock/util/time/TimeCtrl;->mCalendar:Ljava/util/Calendar;

    .line 108
    :goto_15
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "TimeCtrl~ setTimeZone tz:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/htc/clock/util/time/TimeCtrl;->mCalendar:Ljava/util/Calendar;

    invoke-virtual {v2}, Ljava/util/Calendar;->getTimeZone()Ljava/util/TimeZone;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/TimeZone;->getID()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 109
    return-void

    .line 106
    :cond_36
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v1

    iput-object v1, p0, Lcom/htc/clock/util/time/TimeCtrl;->mCalendar:Ljava/util/Calendar;

    goto :goto_15
.end method

.method public uninit()V
    .registers 4

    .prologue
    const/4 v2, 0x0

    .line 128
    iget-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mSettingChangeObserver:Landroid/database/ContentObserver;

    if-eqz v0, :cond_12

    .line 129
    iget-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mContext:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    iget-object v1, p0, Lcom/htc/clock/util/time/TimeCtrl;->mSettingChangeObserver:Landroid/database/ContentObserver;

    invoke-virtual {v0, v1}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V

    .line 130
    iput-object v2, p0, Lcom/htc/clock/util/time/TimeCtrl;->mSettingChangeObserver:Landroid/database/ContentObserver;

    .line 132
    :cond_12
    iget-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mBGLooper:Landroid/os/Looper;

    if-eqz v0, :cond_1b

    .line 133
    iget-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mBGLooper:Landroid/os/Looper;

    invoke-virtual {v0}, Landroid/os/Looper;->quit()V

    .line 135
    :cond_1b
    iget-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mReceiver:Landroid/content/BroadcastReceiver;

    if-eqz v0, :cond_28

    .line 136
    iget-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mContext:Landroid/content/Context;

    iget-object v1, p0, Lcom/htc/clock/util/time/TimeCtrl;->mReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v0, v1}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 137
    iput-object v2, p0, Lcom/htc/clock/util/time/TimeCtrl;->mReceiver:Landroid/content/BroadcastReceiver;

    .line 139
    :cond_28
    iput-object v2, p0, Lcom/htc/clock/util/time/TimeCtrl;->mListener:Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;

    .line 140
    return-void
.end method

.method public update24HourFormat()Z
    .registers 4

    .prologue
    .line 329
    const/4 v1, 0x0

    .line 330
    .local v1, "ret":Z
    iget-object v2, p0, Lcom/htc/clock/util/time/TimeCtrl;->mContext:Landroid/content/Context;

    invoke-static {v2}, Landroid/text/format/DateFormat;->is24HourFormat(Landroid/content/Context;)Z

    move-result v0

    .line 331
    .local v0, "is24Hour":Z
    sget-boolean v2, Lcom/htc/clock/util/time/TimeCtrl;->mB24hourFormat:Z

    if-eq v2, v0, :cond_e

    .line 332
    const/4 v1, 0x1

    .line 333
    sput-boolean v0, Lcom/htc/clock/util/time/TimeCtrl;->mB24hourFormat:Z

    .line 335
    :cond_e
    return v1
.end method

.method public updateDateFormat()Z
    .registers 5

    .prologue
    .line 312
    const/4 v1, 0x0

    .line 313
    .local v1, "ret":Z
    iget-object v2, p0, Lcom/htc/clock/util/time/TimeCtrl;->mContext:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    const-string v3, "date_format_short"

    invoke-static {v2, v3}, Landroid/provider/Settings$System;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 314
    .local v0, "format":Ljava/lang/String;
    if-eqz v0, :cond_20

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_20

    .line 315
    iget-object v2, p0, Lcom/htc/clock/util/time/TimeCtrl;->mDateFormat:Ljava/lang/String;

    invoke-static {v2, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_20

    .line 316
    const/4 v1, 0x1

    .line 317
    iput-object v0, p0, Lcom/htc/clock/util/time/TimeCtrl;->mDateFormat:Ljava/lang/String;

    .line 320
    :cond_20
    return v1
.end method

.method public updateFormat()Z
    .registers 3

    .prologue
    .line 339
    const/4 v0, 0x0

    .line 340
    .local v0, "bUpdated":Z
    invoke-virtual {p0}, Lcom/htc/clock/util/time/TimeCtrl;->updateDateFormat()Z

    move-result v1

    or-int/2addr v0, v1

    .line 341
    invoke-virtual {p0}, Lcom/htc/clock/util/time/TimeCtrl;->update24HourFormat()Z

    move-result v1

    or-int/2addr v0, v1

    .line 342
    return v0
.end method
