.class Lcom/htc/clock/util/location/LocationCtrl$BGHandler;
.super Landroid/os/Handler;
.source "LocationCtrl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock/util/location/LocationCtrl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "BGHandler"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/clock/util/location/LocationCtrl;


# direct methods
.method constructor <init>(Lcom/htc/clock/util/location/LocationCtrl;Landroid/os/Looper;)V
    .registers 3
    .param p2, "looper"    # Landroid/os/Looper;

    .prologue
    .line 677
    iput-object p1, p0, Lcom/htc/clock/util/location/LocationCtrl$BGHandler;->this$0:Lcom/htc/clock/util/location/LocationCtrl;

    .line 678
    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 679
    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .registers 6
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    const/4 v3, 0x1

    .line 682
    iget v2, p1, Landroid/os/Message;->what:I

    packed-switch v2, :pswitch_data_44

    .line 703
    :cond_6
    :goto_6
    return-void

    .line 684
    :pswitch_7
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Lcom/htc/util/weather/WSPData;

    .line 685
    .local v0, "data":Lcom/htc/util/weather/WSPData;
    iget-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl$BGHandler;->this$0:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v2, v0}, Lcom/htc/clock/util/location/LocationCtrl;->onReceiverWeatherData(Lcom/htc/util/weather/WSPData;)V

    goto :goto_6

    .line 689
    .end local v0    # "data":Lcom/htc/util/weather/WSPData;
    :pswitch_11
    iget-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl$BGHandler;->this$0:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-static {v2}, Lcom/htc/clock/util/location/LocationCtrl;->access$200(Lcom/htc/clock/util/location/LocationCtrl;)Lcom/htc/clock/util/location/LocationListener;

    move-result-object v2

    if-eqz v2, :cond_6

    iget-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl$BGHandler;->this$0:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-static {v2}, Lcom/htc/clock/util/location/LocationCtrl;->access$200(Lcom/htc/clock/util/location/LocationCtrl;)Lcom/htc/clock/util/location/LocationListener;

    move-result-object v2

    invoke-interface {v2}, Lcom/htc/clock/util/location/LocationListener;->isResume()Z

    move-result v2

    if-eqz v2, :cond_6

    .line 690
    iget-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl$BGHandler;->this$0:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v2}, Lcom/htc/clock/util/location/LocationCtrl;->forceRetryWeather()V

    goto :goto_6

    .line 694
    :pswitch_2b
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v0, Lcom/htc/util/weather/WSPData;

    .line 695
    .restart local v0    # "data":Lcom/htc/util/weather/WSPData;
    iget v2, p1, Landroid/os/Message;->arg1:I

    if-ne v2, v3, :cond_3a

    move v1, v3

    .line 696
    .local v1, "forceUpdateResult":Z
    :goto_34
    iget-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl$BGHandler;->this$0:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v2, v1, v0}, Lcom/htc/clock/util/location/LocationCtrl;->onReceiverForceRetWeatherData(ZLcom/htc/util/weather/WSPData;)V

    goto :goto_6

    .line 695
    .end local v1    # "forceUpdateResult":Z
    :cond_3a
    const/4 v2, 0x0

    move v1, v2

    goto :goto_34

    .line 700
    .end local v0    # "data":Lcom/htc/util/weather/WSPData;
    :pswitch_3d
    iget-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl$BGHandler;->this$0:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v2}, Lcom/htc/clock/util/location/LocationCtrl;->updateWeatherData()V

    goto :goto_6

    .line 682
    nop

    :pswitch_data_44
    .packed-switch 0x1
        :pswitch_7
        :pswitch_11
        :pswitch_2b
        :pswitch_3d
    .end packed-switch
.end method
