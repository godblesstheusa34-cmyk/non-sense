.class public Lcom/htc/clock/util/MyUtil;
.super Ljava/lang/Object;
.source "MyUtil.java"


# static fields
.field public static final TAB_WORLDCLOCK:Ljava/lang/String; = "1"

.field public static final WORLDCLOCK_ACTION:Ljava/lang/String; = "worldclock_action"

.field public static final WORLDCLOCK_EXTRA_CITY_CODE:Ljava/lang/String; = "worldclock_city_code"


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static compareString(Ljava/lang/String;Ljava/lang/String;)Z
    .registers 3
    .param p0, "a"    # Ljava/lang/String;
    .param p1, "b"    # Ljava/lang/String;

    .prologue
    .line 36
    if-eqz p0, :cond_7

    .line 37
    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    .line 42
    :goto_6
    return v0

    .line 39
    :cond_7
    if-nez p1, :cond_b

    .line 40
    const/4 v0, 0x1

    goto :goto_6

    .line 42
    :cond_b
    const/4 v0, 0x0

    goto :goto_6
.end method

.method public static launchWorldClockAp(Landroid/content/Context;Ljava/lang/String;)V
    .registers 5
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "code"    # Ljava/lang/String;

    .prologue
    .line 14
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.MAIN"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 15
    .local v0, "intent":Landroid/content/Intent;
    const/high16 v1, 0x10000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 16
    const/high16 v1, 0x4000000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 17
    const-string v1, "worldclock_action"

    const-string v2, "1"

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 18
    const-string v1, "worldclock_city_code"

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 19
    const-string v1, "com.htc.android.worldclock"

    const-string v2, "com.htc.android.worldclock.WorldClockTabControl"

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 21
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 22
    return-void
.end method

.method public static removeMessage(Landroid/os/Handler;I)V
    .registers 2
    .param p0, "handler"    # Landroid/os/Handler;
    .param p1, "what"    # I

    .prologue
    .line 77
    if-nez p0, :cond_3

    .line 81
    :goto_2
    return-void

    .line 80
    :cond_3
    invoke-virtual {p0, p1}, Landroid/os/Handler;->removeMessages(I)V

    goto :goto_2
.end method

.method public static safe_parseInt(Ljava/lang/String;)I
    .registers 5
    .param p0, "intStr"    # Ljava/lang/String;

    .prologue
    .line 25
    const/4 v1, 0x0

    .line 27
    .local v1, "iRet":I
    :try_start_1
    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_4} :catch_6

    move-result v1

    .line 32
    :goto_5
    return v1

    .line 28
    :catch_6
    move-exception v0

    .line 29
    .local v0, "e":Ljava/lang/Exception;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "safe_parseInt~ parse error e:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 30
    const/4 v1, 0x0

    goto :goto_5
.end method

.method public static sendMessage(Landroid/os/Handler;I)V
    .registers 4
    .param p0, "handler"    # Landroid/os/Handler;
    .param p1, "what"    # I

    .prologue
    .line 47
    const-wide/16 v0, 0x0

    invoke-static {p0, p1, v0, v1}, Lcom/htc/clock/util/MyUtil;->sendMessage(Landroid/os/Handler;IJ)V

    .line 48
    return-void
.end method

.method public static sendMessage(Landroid/os/Handler;IJ)V
    .registers 6
    .param p0, "handler"    # Landroid/os/Handler;
    .param p1, "what"    # I
    .param p2, "delay"    # J

    .prologue
    .line 51
    if-nez p0, :cond_3

    .line 59
    :goto_2
    return-void

    .line 54
    :cond_3
    const-wide/16 v0, 0x0

    cmp-long v0, p2, v0

    if-lez v0, :cond_d

    .line 55
    invoke-virtual {p0, p1, p2, p3}, Landroid/os/Handler;->sendEmptyMessageDelayed(IJ)Z

    goto :goto_2

    .line 57
    :cond_d
    invoke-virtual {p0, p1}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    goto :goto_2
.end method

.method public static sendMessage(Landroid/os/Handler;Landroid/os/Message;)V
    .registers 4
    .param p0, "handler"    # Landroid/os/Handler;
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    .line 62
    const-wide/16 v0, 0x0

    invoke-static {p0, p1, v0, v1}, Lcom/htc/clock/util/MyUtil;->sendMessage(Landroid/os/Handler;Landroid/os/Message;J)V

    .line 63
    return-void
.end method

.method public static sendMessage(Landroid/os/Handler;Landroid/os/Message;J)V
    .registers 6
    .param p0, "handler"    # Landroid/os/Handler;
    .param p1, "msg"    # Landroid/os/Message;
    .param p2, "delay"    # J

    .prologue
    .line 66
    if-nez p0, :cond_3

    .line 74
    :goto_2
    return-void

    .line 69
    :cond_3
    const-wide/16 v0, 0x0

    cmp-long v0, p2, v0

    if-lez v0, :cond_d

    .line 70
    invoke-virtual {p0, p1, p2, p3}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    goto :goto_2

    .line 72
    :cond_d
    invoke-virtual {p0, p1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto :goto_2
.end method
