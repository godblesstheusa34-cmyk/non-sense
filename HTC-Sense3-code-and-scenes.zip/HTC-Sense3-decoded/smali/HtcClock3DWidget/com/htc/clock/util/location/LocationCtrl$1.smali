.class Lcom/htc/clock/util/location/LocationCtrl$1;
.super Landroid/content/BroadcastReceiver;
.source "LocationCtrl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/htc/clock/util/location/LocationCtrl;->initConnReceiver()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/clock/util/location/LocationCtrl;


# direct methods
.method constructor <init>(Lcom/htc/clock/util/location/LocationCtrl;)V
    .registers 2

    .prologue
    .line 293
    iput-object p1, p0, Lcom/htc/clock/util/location/LocationCtrl$1;->this$0:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 7
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "intent"    # Landroid/content/Intent;

    .prologue
    const/4 v3, 0x2

    .line 297
    const-string v0, "mConnectChangeRec onReceive~"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 298
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl$1;->this$0:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-static {v0}, Lcom/htc/clock/util/location/LocationCtrl;->access$000(Lcom/htc/clock/util/location/LocationCtrl;)Landroid/os/Handler;

    move-result-object v0

    invoke-static {v0, v3}, Lcom/htc/clock/util/MyUtil;->removeMessage(Landroid/os/Handler;I)V

    .line 299
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl$1;->this$0:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-static {v0}, Lcom/htc/clock/util/location/LocationCtrl;->access$000(Lcom/htc/clock/util/location/LocationCtrl;)Landroid/os/Handler;

    move-result-object v0

    const-wide/16 v1, 0x1f4

    invoke-static {v0, v3, v1, v2}, Lcom/htc/clock/util/MyUtil;->sendMessage(Landroid/os/Handler;IJ)V

    .line 300
    return-void
.end method
