.class public Lcom/htc/clock/util/location/WeatherForecast;
.super Ljava/lang/Object;
.source "WeatherForecast.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/htc/clock/util/location/WeatherForecast$UNIT;
    }
.end annotation


# static fields
.field public static final NO_TEMPERATUR:I = -0x1f4


# instance fields
.field private mCondition:Ljava/lang/String;

.field private mCurC:I

.field private mCurF:I

.field private mDate:Ljava/lang/String;

.field private mHighC:I

.field private mHighF:I

.field private mLowC:I

.field private mLowF:I


# direct methods
.method public constructor <init>()V
    .registers 2

    .prologue
    const/16 v0, -0x1f4

    .line 20
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 11
    iput v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mHighF:I

    .line 12
    iput v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mHighC:I

    .line 13
    iput v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mLowF:I

    .line 14
    iput v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mLowC:I

    .line 15
    iput v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mCurF:I

    .line 16
    iput v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mCurC:I

    .line 21
    return-void
.end method

.method private calculateTemperature(I)I
    .registers 4
    .param p1, "val"    # I

    .prologue
    .line 124
    int-to-float v0, p1

    const/high16 v1, 0x42000000    # 32.0f

    sub-float/2addr v0, v1

    const/high16 v1, 0x40a00000    # 5.0f

    mul-float/2addr v0, v1

    const/high16 v1, 0x41100000    # 9.0f

    div-float/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    return v0
.end method

.method private getTempFromString(Ljava/lang/String;)I
    .registers 6
    .param p1, "tempStr"    # Ljava/lang/String;

    .prologue
    .line 24
    const/16 v1, -0x1f4

    .line 25
    .local v1, "temp":I
    if-eqz p1, :cond_8

    .line 27
    :try_start_4
    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_7} :catch_9

    move-result v1

    .line 33
    :cond_8
    :goto_8
    return v1

    .line 28
    :catch_9
    move-exception v0

    .line 29
    .local v0, "e":Ljava/lang/Exception;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "getTempFromString~ exception"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/htc/clock/util/MyLog;->w(Ljava/lang/String;)V

    .line 30
    const/16 v1, -0x1f4

    goto :goto_8
.end method


# virtual methods
.method public getCondition()Ljava/lang/String;
    .registers 2

    .prologue
    .line 120
    iget-object v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mCondition:Ljava/lang/String;

    return-object v0
.end method

.method public getCur(Lcom/htc/clock/util/location/WeatherForecast$UNIT;)I
    .registers 3
    .param p1, "unit"    # Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    .prologue
    .line 100
    sget-object v0, Lcom/htc/clock/util/location/WeatherForecast$UNIT;->_C:Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    if-ne p1, v0, :cond_7

    .line 101
    iget v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mCurC:I

    .line 104
    :goto_6
    return v0

    :cond_7
    iget v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mCurF:I

    goto :goto_6
.end method

.method public getDate()Ljava/lang/String;
    .registers 2

    .prologue
    .line 112
    iget-object v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mDate:Ljava/lang/String;

    return-object v0
.end method

.method public getHigh(Lcom/htc/clock/util/location/WeatherForecast$UNIT;)I
    .registers 3
    .param p1, "unit"    # Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    .prologue
    .line 48
    sget-object v0, Lcom/htc/clock/util/location/WeatherForecast$UNIT;->_C:Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    if-ne p1, v0, :cond_7

    .line 49
    iget v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mHighC:I

    .line 53
    :goto_6
    return v0

    :cond_7
    iget v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mHighF:I

    goto :goto_6
.end method

.method public getLow(Lcom/htc/clock/util/location/WeatherForecast$UNIT;)I
    .registers 3
    .param p1, "unit"    # Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    .prologue
    .line 68
    sget-object v0, Lcom/htc/clock/util/location/WeatherForecast$UNIT;->_C:Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    if-ne p1, v0, :cond_7

    .line 69
    iget v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mLowC:I

    .line 72
    :goto_6
    return v0

    :cond_7
    iget v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mLowF:I

    goto :goto_6
.end method

.method public setCondition(Ljava/lang/String;)V
    .registers 2
    .param p1, "condition"    # Ljava/lang/String;

    .prologue
    .line 116
    iput-object p1, p0, Lcom/htc/clock/util/location/WeatherForecast;->mCondition:Ljava/lang/String;

    .line 117
    return-void
.end method

.method public setCur(II)V
    .registers 4
    .param p1, "f"    # I
    .param p2, "c"    # I

    .prologue
    .line 81
    iput p1, p0, Lcom/htc/clock/util/location/WeatherForecast;->mCurF:I

    .line 82
    iput p2, p0, Lcom/htc/clock/util/location/WeatherForecast;->mCurC:I

    .line 84
    iget v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mLowF:I

    if-le v0, p1, :cond_a

    .line 85
    iput p1, p0, Lcom/htc/clock/util/location/WeatherForecast;->mLowF:I

    .line 87
    :cond_a
    iget v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mHighF:I

    if-ge v0, p1, :cond_10

    .line 88
    iput p1, p0, Lcom/htc/clock/util/location/WeatherForecast;->mHighF:I

    .line 91
    :cond_10
    iget v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mLowC:I

    if-le v0, p2, :cond_16

    .line 92
    iput p2, p0, Lcom/htc/clock/util/location/WeatherForecast;->mLowC:I

    .line 94
    :cond_16
    iget v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mHighC:I

    if-ge v0, p2, :cond_1c

    .line 95
    iput p2, p0, Lcom/htc/clock/util/location/WeatherForecast;->mHighC:I

    .line 97
    :cond_1c
    return-void
.end method

.method public setCurByForecast()V
    .registers 3

    .prologue
    .line 76
    iget v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mLowF:I

    iget v1, p0, Lcom/htc/clock/util/location/WeatherForecast;->mHighF:I

    add-int/2addr v0, v1

    div-int/lit8 v0, v0, 0x2

    iput v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mCurF:I

    .line 77
    iget v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mLowC:I

    iget v1, p0, Lcom/htc/clock/util/location/WeatherForecast;->mHighC:I

    add-int/2addr v0, v1

    div-int/lit8 v0, v0, 0x2

    iput v0, p0, Lcom/htc/clock/util/location/WeatherForecast;->mCurC:I

    .line 78
    return-void
.end method

.method public setDate(Ljava/lang/String;)V
    .registers 2
    .param p1, "date"    # Ljava/lang/String;

    .prologue
    .line 108
    iput-object p1, p0, Lcom/htc/clock/util/location/WeatherForecast;->mDate:Ljava/lang/String;

    .line 109
    return-void
.end method

.method public setHigh(II)V
    .registers 3
    .param p1, "f"    # I
    .param p2, "c"    # I

    .prologue
    .line 43
    iput p1, p0, Lcom/htc/clock/util/location/WeatherForecast;->mHighF:I

    .line 44
    iput p2, p0, Lcom/htc/clock/util/location/WeatherForecast;->mHighC:I

    .line 45
    return-void
.end method

.method public setHigh(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5
    .param p1, "f"    # Ljava/lang/String;
    .param p2, "c"    # Ljava/lang/String;

    .prologue
    .line 37
    invoke-direct {p0, p1}, Lcom/htc/clock/util/location/WeatherForecast;->getTempFromString(Ljava/lang/String;)I

    move-result v1

    .line 38
    .local v1, "intF":I
    invoke-direct {p0, p2}, Lcom/htc/clock/util/location/WeatherForecast;->getTempFromString(Ljava/lang/String;)I

    move-result v0

    .line 39
    .local v0, "intC":I
    invoke-virtual {p0, v1, v0}, Lcom/htc/clock/util/location/WeatherForecast;->setHigh(II)V

    .line 40
    return-void
.end method

.method public setLow(II)V
    .registers 3
    .param p1, "f"    # I
    .param p2, "c"    # I

    .prologue
    .line 63
    iput p1, p0, Lcom/htc/clock/util/location/WeatherForecast;->mLowF:I

    .line 64
    iput p2, p0, Lcom/htc/clock/util/location/WeatherForecast;->mLowC:I

    .line 65
    return-void
.end method

.method public setLow(Ljava/lang/String;Ljava/lang/String;)V
    .registers 5
    .param p1, "f"    # Ljava/lang/String;
    .param p2, "c"    # Ljava/lang/String;

    .prologue
    .line 57
    invoke-direct {p0, p1}, Lcom/htc/clock/util/location/WeatherForecast;->getTempFromString(Ljava/lang/String;)I

    move-result v1

    .line 58
    .local v1, "intF":I
    invoke-direct {p0, p2}, Lcom/htc/clock/util/location/WeatherForecast;->getTempFromString(Ljava/lang/String;)I

    move-result v0

    .line 59
    .local v0, "intC":I
    invoke-virtual {p0, v1, v0}, Lcom/htc/clock/util/location/WeatherForecast;->setLow(II)V

    .line 60
    return-void
.end method
