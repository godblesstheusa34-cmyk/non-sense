.class public Lcom/htc/clock/util/location/LocationCtrl;
.super Ljava/lang/Object;
.source "LocationCtrl.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/htc/clock/util/location/LocationCtrl$BGHandler;,
        Lcom/htc/clock/util/location/LocationCtrl$UIHandler;,
        Lcom/htc/clock/util/location/LocationCtrl$LocationState;,
        Lcom/htc/clock/util/location/LocationCtrl$State;
    }
.end annotation


# static fields
.field public static final APP_LOCATION_SERVICE:Ljava/lang/String; = "com.htc.htclocationservice"

.field private static final CATEGORY_NAME:Ljava/lang/String; = "WeatherClock"

.field public static final CURRENT_LOCATION_AVAIABLE:Ljava/lang/String; = "com.htc.Weather.location.avaiable"

.field public static final CURRENT_LOCATION_KEY:Ljava/lang/String; = "cur"

.field private static final DEGREE:Ljava/lang/String; = "\u00b0"

.field public static final MAX_RETRY_CNT:I = 0xa

.field public static final MAX_RETRY_CNT_IMMEDIATE:I = 0x2

.field private static final OVERDUE_OFFSET:J = 0x2bf20L

.field public static final WHAT_ON_CONNECTION_UPDATE:I = 0x2

.field public static final WHAT_ON_WEATHER_DELETE:I = 0x4

.field public static final WHAT_ON_WEATHER_FORCE_UPDATE:I = 0x3

.field public static final WHAT_ON_WEATHER_UPDATE:I = 0x1

.field public static final WHAT_UI_CITY_CHANGED:I = 0x3e9

.field public static final WHAT_UI_TEMP_CHANGED:I = 0x3eb

.field public static final WHAT_UI_WEATHER_CHANGED:I = 0x3ea

.field private static final sRetryTimes:[J


# instance fields
.field public mBOnReceiveWeatherData:Z

.field private mConnectChangeRec:Landroid/content/BroadcastReceiver;

.field private mContext:Landroid/content/Context;

.field private mHandler:Landroid/os/Handler;

.field private mIsWithCurLocation:Z

.field private mLastForceSyncTime:J

.field private mListener:Lcom/htc/clock/util/location/LocationListener;

.field private mLocDataMap:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap",
            "<",
            "Ljava/lang/String;",
            "Lcom/htc/clock/util/location/LocationData;",
            ">;"
        }
    .end annotation
.end field

.field private mLocKey:Ljava/lang/String;

.field private mLocationAvailable:Z

.field private mLocationEnable:Z

.field private mRetryEnable:Z

.field private mRetryForceCnt:I

.field public mSOnReceiveLog:Ljava/lang/StringBuffer;

.field private mState:Lcom/htc/clock/util/location/LocationCtrl$State;

.field private mTempUnitEnable:Z

.field private mTempUnitReceiver:Landroid/content/BroadcastReceiver;

.field private mUIHandler:Landroid/os/Handler;

.field private mUnit:Lcom/htc/clock/util/location/WeatherForecast$UNIT;

.field private mWSPReqList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList",
            "<",
            "Lcom/htc/util/weather/WSPRequest;",
            ">;"
        }
    .end annotation
.end field

.field private mWeatherApReceiver:Landroid/content/BroadcastReceiver;

.field private mWeatherReceiver:Landroid/content/BroadcastReceiver;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .prologue
    .line 184
    const/4 v0, 0x4

    new-array v0, v0, [J

    fill-array-data v0, :array_a

    sput-object v0, Lcom/htc/clock/util/location/LocationCtrl;->sRetryTimes:[J

    return-void

    nop

    :array_a
    .array-data 8
        0x3a98
        0x7530
        0xea60
        0x927c0
    .end array-data
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 6
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    const/4 v3, 0x1

    const/4 v2, 0x0

    .line 79
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 46
    iput-boolean v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mBOnReceiveWeatherData:Z

    .line 47
    new-instance v0, Ljava/lang/StringBuffer;

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    iput-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mSOnReceiveLog:Ljava/lang/StringBuffer;

    .line 67
    iput-boolean v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mIsWithCurLocation:Z

    .line 69
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocDataMap:Ljava/util/HashMap;

    .line 70
    sget-object v0, Lcom/htc/clock/util/location/LocationCtrl$State;->NONE:Lcom/htc/clock/util/location/LocationCtrl$State;

    iput-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mState:Lcom/htc/clock/util/location/LocationCtrl$State;

    .line 71
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mWSPReqList:Ljava/util/ArrayList;

    .line 73
    sget-object v0, Lcom/htc/clock/util/location/WeatherForecast$UNIT;->_C:Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    iput-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mUnit:Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    .line 76
    iput-boolean v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mRetryEnable:Z

    .line 77
    iput-boolean v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mTempUnitEnable:Z

    .line 182
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLastForceSyncTime:J

    .line 183
    iput v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mRetryForceCnt:I

    .line 649
    new-instance v0, Lcom/htc/clock/util/location/LocationCtrl$UIHandler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, p0, v1}, Lcom/htc/clock/util/location/LocationCtrl$UIHandler;-><init>(Lcom/htc/clock/util/location/LocationCtrl;Landroid/os/Looper;)V

    iput-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mUIHandler:Landroid/os/Handler;

    .line 880
    iput-boolean v3, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocationAvailable:Z

    .line 894
    iput-boolean v3, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocationEnable:Z

    .line 80
    iput-object p1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    .line 82
    return-void
.end method

.method static synthetic access$000(Lcom/htc/clock/util/location/LocationCtrl;)Landroid/os/Handler;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock/util/location/LocationCtrl;

    .prologue
    .line 32
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mHandler:Landroid/os/Handler;

    return-object v0
.end method

.method static synthetic access$100(Lcom/htc/clock/util/location/LocationCtrl;)Lcom/htc/clock/util/location/WeatherForecast$UNIT;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock/util/location/LocationCtrl;

    .prologue
    .line 32
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mUnit:Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    return-object v0
.end method

.method static synthetic access$102(Lcom/htc/clock/util/location/LocationCtrl;Lcom/htc/clock/util/location/WeatherForecast$UNIT;)Lcom/htc/clock/util/location/WeatherForecast$UNIT;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock/util/location/LocationCtrl;
    .param p1, "x1"    # Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    .prologue
    .line 32
    iput-object p1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mUnit:Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    return-object p1
.end method

.method static synthetic access$200(Lcom/htc/clock/util/location/LocationCtrl;)Lcom/htc/clock/util/location/LocationListener;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock/util/location/LocationCtrl;

    .prologue
    .line 32
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mListener:Lcom/htc/clock/util/location/LocationListener;

    return-object v0
.end method

.method static synthetic access$300(Lcom/htc/clock/util/location/LocationCtrl;)Landroid/os/Handler;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock/util/location/LocationCtrl;

    .prologue
    .line 32
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mUIHandler:Landroid/os/Handler;

    return-object v0
.end method

.method static synthetic access$400(Lcom/htc/clock/util/location/LocationCtrl;)Z
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock/util/location/LocationCtrl;

    .prologue
    .line 32
    iget-boolean v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mIsWithCurLocation:Z

    return v0
.end method

.method private addLoc(Lcom/htc/clock/util/location/LocationData;)Z
    .registers 6
    .param p1, "locData"    # Lcom/htc/clock/util/location/LocationData;

    .prologue
    .line 117
    const/4 v0, 0x0

    .line 118
    .local v0, "addRet":Z
    if-eqz p1, :cond_1a

    .line 119
    invoke-virtual {p1}, Lcom/htc/clock/util/location/LocationData;->getLocCode()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/htc/util/weather/WSPUtility;->generateWSPRequestForLocCode(Ljava/lang/String;)Lcom/htc/util/weather/WSPRequest;

    move-result-object v1

    .line 121
    .local v1, "wasReq":Lcom/htc/util/weather/WSPRequest;
    invoke-virtual {p0, v1}, Lcom/htc/clock/util/location/LocationCtrl;->addWSPReq(Lcom/htc/util/weather/WSPRequest;)Z

    move-result v0

    .line 122
    if-eqz v0, :cond_1b

    .line 123
    iget-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocDataMap:Ljava/util/HashMap;

    invoke-virtual {p1}, Lcom/htc/clock/util/location/LocationData;->getLocCode()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 128
    .end local v1    # "wasReq":Lcom/htc/util/weather/WSPRequest;
    :cond_1a
    :goto_1a
    return v0

    .line 125
    .restart local v1    # "wasReq":Lcom/htc/util/weather/WSPRequest;
    :cond_1b
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "addLoc~ fail, locData:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {p1}, Lcom/htc/clock/util/location/LocationData;->getLocCode()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    goto :goto_1a
.end method

.method private allowBackgroundData(Landroid/content/Context;)Z
    .registers 4
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    .line 917
    const-string v1, "connectivity"

    invoke-virtual {p1, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/net/ConnectivityManager;

    .line 919
    .local v0, "cm":Landroid/net/ConnectivityManager;
    if-eqz v0, :cond_f

    .line 921
    invoke-virtual {v0}, Landroid/net/ConnectivityManager;->getBackgroundDataSetting()Z

    move-result v1

    .line 924
    :goto_e
    return v1

    .line 923
    :cond_f
    const-string v1, "allowBackgroundData can\'t get Connectivity Manager"

    invoke-static {v1}, Lcom/htc/clock/util/MyLog;->w(Ljava/lang/String;)V

    .line 924
    const/4 v1, 0x0

    goto :goto_e
.end method

.method private getTemp(I)Ljava/lang/String;
    .registers 4
    .param p1, "temp"    # I

    .prologue
    .line 631
    const/16 v1, -0x1f4

    if-ne p1, v1, :cond_7

    .line 632
    const-string v1, ""

    .line 637
    :goto_6
    return-object v1

    .line 634
    :cond_7
    new-instance v0, Ljava/lang/StringBuffer;

    const/16 v1, 0xa

    invoke-direct {v0, v1}, Ljava/lang/StringBuffer;-><init>(I)V

    .line 635
    .local v0, "strBuffer":Ljava/lang/StringBuffer;
    invoke-virtual {v0, p1}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    .line 636
    const-string v1, "\u00b0"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 637
    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_6
.end method

.method public static getWeatheApCityName(Lcom/htc/util/weather/WeatherLocation;)Ljava/lang/String;
    .registers 5
    .param p0, "weatherLoc"    # Lcom/htc/util/weather/WeatherLocation;

    .prologue
    const-string v3, ", "

    .line 850
    const-string v0, ""

    .line 851
    .local v0, "cityName":Ljava/lang/String;
    if-eqz p0, :cond_45

    .line 852
    invoke-virtual {p0}, Lcom/htc/util/weather/WeatherLocation;->getName()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_1a

    invoke-virtual {p0}, Lcom/htc/util/weather/WeatherLocation;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_1a

    .line 854
    invoke-virtual {p0}, Lcom/htc/util/weather/WeatherLocation;->getName()Ljava/lang/String;

    move-result-object v0

    .line 855
    :cond_1a
    invoke-virtual {p0}, Lcom/htc/util/weather/WeatherLocation;->getState()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_46

    invoke-virtual {p0}, Lcom/htc/util/weather/WeatherLocation;->getState()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_46

    .line 857
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p0}, Lcom/htc/util/weather/WeatherLocation;->getState()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 862
    :cond_45
    :goto_45
    return-object v0

    .line 858
    :cond_46
    invoke-virtual {p0}, Lcom/htc/util/weather/WeatherLocation;->getCountry()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_45

    invoke-virtual {p0}, Lcom/htc/util/weather/WeatherLocation;->getCountry()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_45

    .line 860
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {p0}, Lcom/htc/util/weather/WeatherLocation;->getCountry()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_45
.end method

.method private initConnReceiver()V
    .registers 4

    .prologue
    .line 293
    new-instance v1, Lcom/htc/clock/util/location/LocationCtrl$1;

    invoke-direct {v1, p0}, Lcom/htc/clock/util/location/LocationCtrl$1;-><init>(Lcom/htc/clock/util/location/LocationCtrl;)V

    iput-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mConnectChangeRec:Landroid/content/BroadcastReceiver;

    .line 303
    new-instance v0, Landroid/content/IntentFilter;

    invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V

    .line 304
    .local v0, "intentFilter":Landroid/content/IntentFilter;
    const-string v1, "android.net.conn.BACKGROUND_DATA_SETTING_CHANGED"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 306
    const-string v1, "android.net.conn.CONNECTIVITY_CHANGE"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 307
    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    iget-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mConnectChangeRec:Landroid/content/BroadcastReceiver;

    invoke-virtual {v1, v2, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 308
    return-void
.end method

.method private initTempUnitReceiver()V
    .registers 4

    .prologue
    .line 337
    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mTempUnitReceiver:Landroid/content/BroadcastReceiver;

    if-nez v1, :cond_26

    .line 338
    const-string v1, "initTempUnitReceiver~"

    invoke-static {v1}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 339
    new-instance v1, Lcom/htc/clock/util/location/LocationCtrl$2;

    invoke-direct {v1, p0}, Lcom/htc/clock/util/location/LocationCtrl$2;-><init>(Lcom/htc/clock/util/location/LocationCtrl;)V

    iput-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mTempUnitReceiver:Landroid/content/BroadcastReceiver;

    .line 367
    new-instance v0, Landroid/content/IntentFilter;

    invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V

    .line 368
    .local v0, "intentFilter":Landroid/content/IntentFilter;
    const-string v1, "com.htc.sync.provider.weather.SETTINGS_UPDATED"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 369
    const-string v1, "com.htc.sync.provider.weather.setting.temperatureunit"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addCategory(Ljava/lang/String;)V

    .line 371
    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    iget-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mTempUnitReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v1, v2, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 373
    .end local v0    # "intentFilter":Landroid/content/IntentFilter;
    :cond_26
    return-void
.end method

.method private initWeatherReceiver()V
    .registers 7

    .prologue
    .line 376
    iget-object v4, p0, Lcom/htc/clock/util/location/LocationCtrl;->mWeatherReceiver:Landroid/content/BroadcastReceiver;

    if-nez v4, :cond_5a

    .line 377
    const-string v4, "initWeatherReceiver~ init weatherReceiver"

    invoke-static {v4}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 378
    new-instance v4, Lcom/htc/clock/util/location/LocationCtrl$3;

    invoke-direct {v4, p0}, Lcom/htc/clock/util/location/LocationCtrl$3;-><init>(Lcom/htc/clock/util/location/LocationCtrl;)V

    iput-object v4, p0, Lcom/htc/clock/util/location/LocationCtrl;->mWeatherReceiver:Landroid/content/BroadcastReceiver;

    .line 421
    new-instance v2, Landroid/content/IntentFilter;

    invoke-direct {v2}, Landroid/content/IntentFilter;-><init>()V

    .line 422
    .local v2, "intentFilter":Landroid/content/IntentFilter;
    const-string v4, "com.htc.sync.provider.weather.result"

    invoke-virtual {v2, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 424
    const-string v4, "WeatherClock"

    invoke-virtual {v2, v4}, Landroid/content/IntentFilter;->addCategory(Ljava/lang/String;)V

    .line 426
    iget-object v4, p0, Lcom/htc/clock/util/location/LocationCtrl;->mWSPReqList:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .local v1, "i$":Ljava/util/Iterator;
    :goto_25
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_53

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/htc/util/weather/WSPRequest;

    .line 427
    .local v3, "wspReq":Lcom/htc/util/weather/WSPRequest;
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "initWeatherReceiver~ wspReq.toString():"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v3}, Lcom/htc/util/weather/WSPRequest;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 429
    invoke-virtual {v3}, Lcom/htc/util/weather/WSPRequest;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/content/IntentFilter;->addCategory(Ljava/lang/String;)V

    goto :goto_25

    .line 431
    .end local v3    # "wspReq":Lcom/htc/util/weather/WSPRequest;
    :cond_53
    iget-object v4, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    iget-object v5, p0, Lcom/htc/clock/util/location/LocationCtrl;->mWeatherReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v4, v5, v2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 433
    .end local v1    # "i$":Ljava/util/Iterator;
    .end local v2    # "intentFilter":Landroid/content/IntentFilter;
    :cond_5a
    iget-object v4, p0, Lcom/htc/clock/util/location/LocationCtrl;->mWeatherApReceiver:Landroid/content/BroadcastReceiver;

    if-nez v4, :cond_7d

    .line 434
    const-string v4, "initWeatherReceiver~ init mWeatherApReceiver"

    invoke-static {v4}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 437
    const-string v0, "com.htc.Weather.delete_current_location"

    .line 439
    .local v0, "DELETE_LOCATION_CUR_CHANGED":Ljava/lang/String;
    new-instance v4, Lcom/htc/clock/util/location/LocationCtrl$4;

    invoke-direct {v4, p0}, Lcom/htc/clock/util/location/LocationCtrl$4;-><init>(Lcom/htc/clock/util/location/LocationCtrl;)V

    iput-object v4, p0, Lcom/htc/clock/util/location/LocationCtrl;->mWeatherApReceiver:Landroid/content/BroadcastReceiver;

    .line 456
    new-instance v2, Landroid/content/IntentFilter;

    invoke-direct {v2}, Landroid/content/IntentFilter;-><init>()V

    .line 457
    .restart local v2    # "intentFilter":Landroid/content/IntentFilter;
    const-string v4, "com.htc.Weather.delete_current_location"

    invoke-virtual {v2, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 458
    iget-object v4, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    iget-object v5, p0, Lcom/htc/clock/util/location/LocationCtrl;->mWeatherApReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v4, v5, v2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 460
    .end local v0    # "DELETE_LOCATION_CUR_CHANGED":Ljava/lang/String;
    .end local v2    # "intentFilter":Landroid/content/IntentFilter;
    :cond_7d
    return-void
.end method

.method public static isUseWirelessNetworks(Landroid/content/Context;)Z
    .registers 3
    .param p0, "context"    # Landroid/content/Context;

    .prologue
    .line 912
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    const-string v1, "network"

    invoke-static {v0, v1}, Landroid/provider/Settings$Secure;->isLocationProviderEnabled(Landroid/content/ContentResolver;Ljava/lang/String;)Z

    move-result v0

    return v0
.end method

.method private isUsedTempC()Z
    .registers 4

    .prologue
    .line 841
    const/4 v0, 0x1

    .line 842
    .local v0, "bUseTempC":Z
    iget-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    invoke-static {v2}, Lcom/htc/util/weather/WSPUtility;->getTemperatureUnit(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    .line 843
    .local v1, "tempUnit":Ljava/lang/String;
    if-eqz v1, :cond_15

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_15

    .line 844
    const-string v2, "c"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    .line 846
    :cond_15
    return v0
.end method

.method private setHandler(Landroid/os/Handler;)V
    .registers 4
    .param p1, "handler"    # Landroid/os/Handler;

    .prologue
    .line 707
    const/4 v0, 0x0

    .line 709
    .local v0, "looper":Landroid/os/Looper;
    if-eqz p1, :cond_7

    .line 710
    invoke-virtual {p1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v0

    .line 713
    :cond_7
    if-nez v0, :cond_e

    .line 714
    const-string v1, "setHandler~ no looper"

    invoke-static {v1}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    .line 716
    :cond_e
    new-instance v1, Lcom/htc/clock/util/location/LocationCtrl$BGHandler;

    invoke-direct {v1, p0, v0}, Lcom/htc/clock/util/location/LocationCtrl$BGHandler;-><init>(Lcom/htc/clock/util/location/LocationCtrl;Landroid/os/Looper;)V

    iput-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mHandler:Landroid/os/Handler;

    .line 717
    return-void
.end method


# virtual methods
.method public addCurLoc()Z
    .registers 10

    .prologue
    const/4 v8, 0x1

    .line 132
    invoke-static {}, Lcom/htc/util/weather/WSPUtility;->generateWSPReqestForCurrentLocation()Lcom/htc/util/weather/WSPRequest;

    move-result-object v4

    .line 133
    .local v4, "wasReq":Lcom/htc/util/weather/WSPRequest;
    invoke-virtual {p0, v4}, Lcom/htc/clock/util/location/LocationCtrl;->addWSPReq(Lcom/htc/util/weather/WSPRequest;)Z

    move-result v0

    .line 135
    .local v0, "bRet":Z
    if-eqz v0, :cond_47

    .line 136
    const/4 v1, 0x0

    .line 137
    .local v1, "curLocData":Lcom/htc/clock/util/location/LocationData;
    iget-object v6, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    invoke-virtual {v6}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v6

    const-string v7, "com.htc.htclocationservice"

    invoke-static {v6, v7}, Lcom/htc/util/weather/WeatherUtility;->loadLocations(Landroid/content/ContentResolver;Ljava/lang/String;)[Lcom/htc/util/weather/WeatherLocation;

    move-result-object v3

    .line 139
    .local v3, "locs":[Lcom/htc/util/weather/WeatherLocation;
    const/4 v5, 0x0

    .line 140
    .local v5, "wthLoc":Lcom/htc/util/weather/WeatherLocation;
    sget-object v2, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->NO_DATA:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    .line 141
    .local v2, "locState":Lcom/htc/clock/util/location/LocationCtrl$LocationState;
    if-eqz v3, :cond_38

    array-length v6, v3

    if-lez v6, :cond_38

    .line 142
    const/4 v6, 0x0

    aget-object v5, v3, v6

    .line 143
    sget-object v2, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->ONLY_LOC:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    .line 150
    :goto_25
    new-instance v1, Lcom/htc/clock/util/location/LocationData;

    .end local v1    # "curLocData":Lcom/htc/clock/util/location/LocationData;
    iget-object v6, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    invoke-direct {v1, v6, v5, v2}, Lcom/htc/clock/util/location/LocationData;-><init>(Landroid/content/Context;Lcom/htc/util/weather/WeatherLocation;Lcom/htc/clock/util/location/LocationCtrl$LocationState;)V

    .line 151
    .restart local v1    # "curLocData":Lcom/htc/clock/util/location/LocationData;
    iput-boolean v8, v1, Lcom/htc/clock/util/location/LocationData;->mIsCurLocation:Z

    .line 152
    iput-boolean v8, p0, Lcom/htc/clock/util/location/LocationCtrl;->mIsWithCurLocation:Z

    .line 153
    iget-object v6, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocDataMap:Ljava/util/HashMap;

    const-string v7, "cur"

    invoke-virtual {v6, v7, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 157
    .end local v1    # "curLocData":Lcom/htc/clock/util/location/LocationData;
    .end local v2    # "locState":Lcom/htc/clock/util/location/LocationCtrl$LocationState;
    .end local v3    # "locs":[Lcom/htc/util/weather/WeatherLocation;
    .end local v5    # "wthLoc":Lcom/htc/util/weather/WeatherLocation;
    :goto_37
    return v0

    .line 145
    .restart local v1    # "curLocData":Lcom/htc/clock/util/location/LocationData;
    .restart local v2    # "locState":Lcom/htc/clock/util/location/LocationCtrl$LocationState;
    .restart local v3    # "locs":[Lcom/htc/util/weather/WeatherLocation;
    .restart local v5    # "wthLoc":Lcom/htc/util/weather/WeatherLocation;
    :cond_38
    new-instance v5, Lcom/htc/util/weather/WeatherLocation;

    .end local v5    # "wthLoc":Lcom/htc/util/weather/WeatherLocation;
    invoke-direct {v5}, Lcom/htc/util/weather/WeatherLocation;-><init>()V

    .line 146
    .restart local v5    # "wthLoc":Lcom/htc/util/weather/WeatherLocation;
    const-string v6, ""

    invoke-virtual {v5, v6}, Lcom/htc/util/weather/WeatherLocation;->setName(Ljava/lang/String;)V

    .line 147
    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Lcom/htc/util/weather/WeatherLocation;->setTimezoneId(Ljava/lang/String;)V

    goto :goto_25

    .line 155
    .end local v1    # "curLocData":Lcom/htc/clock/util/location/LocationData;
    .end local v2    # "locState":Lcom/htc/clock/util/location/LocationCtrl$LocationState;
    .end local v3    # "locs":[Lcom/htc/util/weather/WeatherLocation;
    .end local v5    # "wthLoc":Lcom/htc/util/weather/WeatherLocation;
    :cond_47
    const-string v6, "addCurLoc~ fail"

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    goto :goto_37
.end method

.method public addLoc(Lcom/htc/util/weather/WeatherLocation;)Z
    .registers 4
    .param p1, "wthLoc"    # Lcom/htc/util/weather/WeatherLocation;

    .prologue
    .line 106
    new-instance v0, Lcom/htc/clock/util/location/LocationData;

    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    invoke-direct {v0, v1, p1}, Lcom/htc/clock/util/location/LocationData;-><init>(Landroid/content/Context;Lcom/htc/util/weather/WeatherLocation;)V

    .line 107
    .local v0, "locData":Lcom/htc/clock/util/location/LocationData;
    invoke-direct {p0, v0}, Lcom/htc/clock/util/location/LocationCtrl;->addLoc(Lcom/htc/clock/util/location/LocationData;)Z

    move-result v1

    return v1
.end method

.method public addLoc(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z
    .registers 6
    .param p1, "locCode"    # Ljava/lang/String;
    .param p2, "locName"    # Ljava/lang/String;
    .param p3, "timezoneid"    # Ljava/lang/String;

    .prologue
    .line 111
    new-instance v0, Lcom/htc/clock/util/location/LocationData;

    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    invoke-direct {v0, v1, p1, p2, p3}, Lcom/htc/clock/util/location/LocationData;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 113
    .local v0, "locData":Lcom/htc/clock/util/location/LocationData;
    invoke-direct {p0, v0}, Lcom/htc/clock/util/location/LocationCtrl;->addLoc(Lcom/htc/clock/util/location/LocationData;)Z

    move-result v1

    return v1
.end method

.method public addWSPReq(Lcom/htc/util/weather/WSPRequest;)Z
    .registers 5
    .param p1, "wspReq"    # Lcom/htc/util/weather/WSPRequest;

    .prologue
    const/4 v2, 0x0

    .line 169
    if-nez p1, :cond_a

    .line 170
    const-string v0, "addWSPReq~ the WSPReq is wrong"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    move v0, v2

    .line 179
    :goto_9
    return v0

    .line 173
    :cond_a
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mState:Lcom/htc/clock/util/location/LocationCtrl$State;

    sget-object v1, Lcom/htc/clock/util/location/LocationCtrl$State;->START:Lcom/htc/clock/util/location/LocationCtrl$State;

    if-ne v0, v1, :cond_17

    .line 175
    const-string v0, "addWSPReq~ the WSPReq is wrong becasue start"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    move v0, v2

    .line 176
    goto :goto_9

    .line 178
    :cond_17
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mWSPReqList:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 179
    const/4 v0, 0x1

    goto :goto_9
.end method

.method public checkLocEnable()Z
    .registers 5

    .prologue
    .line 897
    iget-boolean v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocationEnable:Z

    .line 898
    .local v0, "bOrg":Z
    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mListener:Lcom/htc/clock/util/location/LocationListener;

    .line 899
    .local v1, "listener":Lcom/htc/clock/util/location/LocationListener;
    if-eqz v1, :cond_14

    invoke-interface {v1}, Lcom/htc/clock/util/location/LocationListener;->isHelpTurnOnLoc()Z

    move-result v2

    if-eqz v2, :cond_14

    .line 900
    iget-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    invoke-static {v2}, Lcom/htc/clock/util/location/LocationCtrl;->isUseWirelessNetworks(Landroid/content/Context;)Z

    move-result v2

    iput-boolean v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocationEnable:Z

    .line 902
    :cond_14
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "checkLocEnable enable:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-boolean v3, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocationEnable:Z

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 903
    iget-boolean v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocationEnable:Z

    if-eq v0, v2, :cond_32

    const/4 v2, 0x1

    :goto_31
    return v2

    :cond_32
    const/4 v2, 0x0

    goto :goto_31
.end method

.method public checkLocService()V
    .registers 5

    .prologue
    const/4 v3, 0x1

    .line 883
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mListener:Lcom/htc/clock/util/location/LocationListener;

    .line 884
    .local v0, "listener":Lcom/htc/clock/util/location/LocationListener;
    if-eqz v0, :cond_1c

    invoke-interface {v0}, Lcom/htc/clock/util/location/LocationListener;->isChinaLocationService()Z

    move-result v1

    if-eqz v1, :cond_1c

    .line 885
    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const-string v2, "com.htc.Weather.location.avaiable"

    invoke-static {v1, v2, v3}, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    move-result v1

    if-ne v3, v1, :cond_1d

    move v1, v3

    :goto_1a
    iput-boolean v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocationAvailable:Z

    .line 888
    :cond_1c
    return-void

    .line 885
    :cond_1d
    const/4 v1, 0x0

    goto :goto_1a
.end method

.method public checkTempUnit()Z
    .registers 3

    .prologue
    .line 866
    sget-object v0, Lcom/htc/clock/util/location/WeatherForecast$UNIT;->_C:Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    .line 867
    .local v0, "unit":Lcom/htc/clock/util/location/WeatherForecast$UNIT;
    invoke-direct {p0}, Lcom/htc/clock/util/location/LocationCtrl;->isUsedTempC()Z

    move-result v1

    if-eqz v1, :cond_12

    .line 868
    sget-object v0, Lcom/htc/clock/util/location/WeatherForecast$UNIT;->_C:Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    .line 873
    :goto_a
    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mUnit:Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    if-eq v0, v1, :cond_15

    .line 874
    iput-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mUnit:Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    .line 875
    const/4 v1, 0x1

    .line 877
    :goto_11
    return v1

    .line 870
    :cond_12
    sget-object v0, Lcom/htc/clock/util/location/WeatherForecast$UNIT;->_F:Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    goto :goto_a

    .line 877
    :cond_15
    const/4 v1, 0x0

    goto :goto_11
.end method

.method public forceRetryWeather()V
    .registers 7

    .prologue
    const/4 v5, 0x2

    .line 311
    iget-object v3, p0, Lcom/htc/clock/util/location/LocationCtrl;->mHandler:Landroid/os/Handler;

    invoke-static {v3, v5}, Lcom/htc/clock/util/MyUtil;->removeMessage(Landroid/os/Handler;I)V

    .line 313
    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->getState()Lcom/htc/clock/util/location/LocationCtrl$State;

    move-result-object v3

    sget-object v4, Lcom/htc/clock/util/location/LocationCtrl$State;->START:Lcom/htc/clock/util/location/LocationCtrl$State;

    if-eq v3, v4, :cond_f

    .line 334
    :cond_e
    :goto_e
    return-void

    .line 316
    :cond_f
    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->isNeedUpdate()Z

    move-result v3

    if-eqz v3, :cond_e

    .line 319
    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->getRetryCnt()I

    move-result v0

    .line 320
    .local v0, "cnt":I
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "forceRetryWeather~ cnt:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 322
    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->isForceUpdateAvailable()Z

    move-result v3

    if-eqz v3, :cond_e

    .line 323
    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->forceUpdateIfNoData()V

    .line 325
    if-ge v0, v5, :cond_e

    .line 327
    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->getRetryPendingTime()J

    move-result-wide v1

    .line 328
    .local v1, "pending":J
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "forceRetryWeather~ schedule pending:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 329
    iget-object v3, p0, Lcom/htc/clock/util/location/LocationCtrl;->mHandler:Landroid/os/Handler;

    invoke-static {v3, v5, v1, v2}, Lcom/htc/clock/util/MyUtil;->sendMessage(Landroid/os/Handler;IJ)V

    goto :goto_e
.end method

.method public forceToSync()V
    .registers 8

    .prologue
    .line 202
    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->isForceUpdateAvailable()Z

    move-result v5

    if-nez v5, :cond_7

    .line 222
    :cond_6
    :goto_6
    return-void

    .line 206
    :cond_7
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 208
    .local v0, "currentTime":J
    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->getRetryPendingTime()J

    move-result-wide v2

    .line 209
    .local v2, "retryPending":J
    const-wide/16 v5, 0x0

    cmp-long v5, v2, v5

    if-gtz v5, :cond_42

    .line 210
    iput-wide v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLastForceSyncTime:J

    .line 211
    iget v5, p0, Lcom/htc/clock/util/location/LocationCtrl;->mRetryForceCnt:I

    add-int/lit8 v5, v5, 0x1

    iput v5, p0, Lcom/htc/clock/util/location/LocationCtrl;->mRetryForceCnt:I

    .line 212
    const-string v5, "forceToSync~"

    invoke-static {v5}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 213
    iget-object v5, p0, Lcom/htc/clock/util/location/LocationCtrl;->mWSPReqList:Ljava/util/ArrayList;

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v5

    if-lez v5, :cond_6

    .line 214
    iget-object v5, p0, Lcom/htc/clock/util/location/LocationCtrl;->mWSPReqList:Ljava/util/ArrayList;

    iget-object v6, p0, Lcom/htc/clock/util/location/LocationCtrl;->mWSPReqList:Ljava/util/ArrayList;

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    new-array v6, v6, [Lcom/htc/util/weather/WSPRequest;

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [Lcom/htc/util/weather/WSPRequest;

    .line 216
    .local v4, "wspReqArray":[Lcom/htc/util/weather/WSPRequest;
    iget-object v5, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    const-string v6, "WeatherClock"

    invoke-static {v5, v6, v4}, Lcom/htc/util/weather/WSPUtility;->triggerSyncService(Landroid/content/Context;Ljava/lang/String;[Lcom/htc/util/weather/WSPRequest;)V

    goto :goto_6

    .line 220
    .end local v4    # "wspReqArray":[Lcom/htc/util/weather/WSPRequest;
    :cond_42
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "forceToSync~ wait retryPending:"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    goto :goto_6
.end method

.method public forceUpdateIfNoData()V
    .registers 3

    .prologue
    .line 283
    sget-object v0, Lcom/htc/clock/util/location/LocationCtrl$State;->START:Lcom/htc/clock/util/location/LocationCtrl$State;

    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mState:Lcom/htc/clock/util/location/LocationCtrl$State;

    if-eq v0, v1, :cond_7

    .line 290
    :cond_6
    :goto_6
    return-void

    .line 286
    :cond_7
    const-string v0, "forceUpdateIfNoData~"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 287
    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->isNeedUpdate()Z

    move-result v0

    if-eqz v0, :cond_6

    .line 288
    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->forceToSync()V

    goto :goto_6
.end method

.method public getHTemp()Ljava/lang/String;
    .registers 7

    .prologue
    const-string v5, ""

    .line 604
    iget-object v3, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocDataMap:Ljava/util/HashMap;

    iget-object v4, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocKey:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/htc/clock/util/location/LocationData;

    .line 605
    .local v0, "locData":Lcom/htc/clock/util/location/LocationData;
    if-nez v0, :cond_12

    .line 606
    const-string v3, ""

    move-object v3, v5

    .line 613
    :goto_11
    return-object v3

    .line 608
    :cond_12
    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationData;->getForecast()Lcom/htc/clock/util/location/WeatherForecast;

    move-result-object v2

    .line 609
    .local v2, "weatherForecast":Lcom/htc/clock/util/location/WeatherForecast;
    if-nez v2, :cond_1c

    .line 610
    const-string v3, ""

    move-object v3, v5

    goto :goto_11

    .line 612
    :cond_1c
    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationData;->getForecast()Lcom/htc/clock/util/location/WeatherForecast;

    move-result-object v3

    iget-object v4, p0, Lcom/htc/clock/util/location/LocationCtrl;->mUnit:Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    invoke-virtual {v3, v4}, Lcom/htc/clock/util/location/WeatherForecast;->getHigh(Lcom/htc/clock/util/location/WeatherForecast$UNIT;)I

    move-result v1

    .line 613
    .local v1, "temp":I
    invoke-direct {p0, v1}, Lcom/htc/clock/util/location/LocationCtrl;->getTemp(I)Ljava/lang/String;

    move-result-object v3

    goto :goto_11
.end method

.method public getLTemp()Ljava/lang/String;
    .registers 7

    .prologue
    const-string v5, ""

    .line 618
    iget-object v3, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocDataMap:Ljava/util/HashMap;

    iget-object v4, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocKey:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/htc/clock/util/location/LocationData;

    .line 619
    .local v0, "locData":Lcom/htc/clock/util/location/LocationData;
    if-nez v0, :cond_12

    .line 620
    const-string v3, ""

    move-object v3, v5

    .line 627
    :goto_11
    return-object v3

    .line 622
    :cond_12
    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationData;->getForecast()Lcom/htc/clock/util/location/WeatherForecast;

    move-result-object v2

    .line 623
    .local v2, "weatherForecast":Lcom/htc/clock/util/location/WeatherForecast;
    if-nez v2, :cond_1c

    .line 624
    const-string v3, ""

    move-object v3, v5

    goto :goto_11

    .line 626
    :cond_1c
    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationData;->getForecast()Lcom/htc/clock/util/location/WeatherForecast;

    move-result-object v3

    iget-object v4, p0, Lcom/htc/clock/util/location/LocationCtrl;->mUnit:Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    invoke-virtual {v3, v4}, Lcom/htc/clock/util/location/WeatherForecast;->getLow(Lcom/htc/clock/util/location/WeatherForecast$UNIT;)I

    move-result v1

    .line 627
    .local v1, "temp":I
    invoke-direct {p0, v1}, Lcom/htc/clock/util/location/LocationCtrl;->getTemp(I)Ljava/lang/String;

    move-result-object v3

    goto :goto_11
.end method

.method public getLastUpdateTime()J
    .registers 4

    .prologue
    .line 769
    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocDataMap:Ljava/util/HashMap;

    iget-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocKey:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/htc/clock/util/location/LocationData;

    .line 770
    .local v0, "locData":Lcom/htc/clock/util/location/LocationData;
    if-eqz v0, :cond_11

    .line 771
    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationData;->getLastUpdateTime()J

    move-result-wide v1

    .line 773
    :goto_10
    return-wide v1

    :cond_11
    const-wide/16 v1, 0x0

    goto :goto_10
.end method

.method public getLocCode()Ljava/lang/String;
    .registers 4

    .prologue
    .line 790
    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocDataMap:Ljava/util/HashMap;

    iget-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocKey:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/htc/clock/util/location/LocationData;

    .line 791
    .local v0, "locData":Lcom/htc/clock/util/location/LocationData;
    if-eqz v0, :cond_11

    .line 792
    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationData;->getLocCode()Ljava/lang/String;

    move-result-object v1

    .line 794
    :goto_10
    return-object v1

    :cond_11
    const/4 v1, 0x0

    goto :goto_10
.end method

.method public getLocConditionId()Ljava/lang/String;
    .registers 6

    .prologue
    .line 566
    const/4 v0, 0x0

    .line 567
    .local v0, "locConditon":Ljava/lang/String;
    iget-object v3, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocDataMap:Ljava/util/HashMap;

    iget-object v4, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocKey:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/htc/clock/util/location/LocationData;

    .line 568
    .local v1, "locData":Lcom/htc/clock/util/location/LocationData;
    const/4 v2, 0x0

    .line 569
    .local v2, "weatherForecast":Lcom/htc/clock/util/location/WeatherForecast;
    if-eqz v1, :cond_12

    .line 570
    invoke-virtual {v1}, Lcom/htc/clock/util/location/LocationData;->getForecast()Lcom/htc/clock/util/location/WeatherForecast;

    move-result-object v2

    .line 572
    :cond_12
    if-eqz v2, :cond_18

    .line 573
    invoke-virtual {v2}, Lcom/htc/clock/util/location/WeatherForecast;->getCondition()Ljava/lang/String;

    move-result-object v0

    .line 576
    :cond_18
    if-nez v0, :cond_1c

    .line 577
    const-string v0, ""

    .line 579
    :cond_1c
    return-object v0
.end method

.method public getLocConditionIdInt()I
    .registers 6

    .prologue
    .line 583
    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->getLocConditionId()Ljava/lang/String;

    move-result-object v0

    .line 584
    .local v0, "conditionId":Ljava/lang/String;
    const/4 v2, 0x0

    .line 586
    .local v2, "id":I
    :try_start_5
    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_8} :catch_a

    move-result v2

    .line 591
    :goto_9
    return v2

    .line 587
    :catch_a
    move-exception v1

    .line 588
    .local v1, "e":Ljava/lang/Exception;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "getLocConditionIdInt~ exception:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 589
    const/4 v2, 0x0

    goto :goto_9
.end method

.method public getLocKey()Ljava/lang/String;
    .registers 2

    .prologue
    .line 165
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocKey:Ljava/lang/String;

    return-object v0
.end method

.method public getLocName()Ljava/lang/String;
    .registers 5

    .prologue
    .line 556
    const/4 v1, 0x0

    .line 557
    .local v1, "locName":Ljava/lang/String;
    iget-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocDataMap:Ljava/util/HashMap;

    iget-object v3, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocKey:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/htc/clock/util/location/LocationData;

    .line 558
    .local v0, "locData":Lcom/htc/clock/util/location/LocationData;
    if-eqz v0, :cond_11

    .line 559
    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationData;->getLocName()Ljava/lang/String;

    move-result-object v1

    .line 561
    :cond_11
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "LocationCtrl~ getLocName:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 562
    return-object v1
.end method

.method public getLocState()Lcom/htc/clock/util/location/LocationCtrl$LocationState;
    .registers 4

    .prologue
    .line 720
    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocDataMap:Ljava/util/HashMap;

    iget-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocKey:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/htc/clock/util/location/LocationData;

    .line 721
    .local v0, "locData":Lcom/htc/clock/util/location/LocationData;
    if-nez v0, :cond_f

    .line 722
    sget-object v1, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->NO_DATA:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    .line 724
    :goto_e
    return-object v1

    :cond_f
    iget-object v1, v0, Lcom/htc/clock/util/location/LocationData;->mState:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    goto :goto_e
.end method

.method public getLocTemp()Ljava/lang/String;
    .registers 5

    .prologue
    .line 595
    iget-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocDataMap:Ljava/util/HashMap;

    iget-object v3, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocKey:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/htc/clock/util/location/LocationData;

    .line 596
    .local v0, "locData":Lcom/htc/clock/util/location/LocationData;
    if-nez v0, :cond_f

    .line 597
    const-string v2, ""

    .line 600
    :goto_e
    return-object v2

    .line 599
    :cond_f
    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationData;->getForecast()Lcom/htc/clock/util/location/WeatherForecast;

    move-result-object v2

    iget-object v3, p0, Lcom/htc/clock/util/location/LocationCtrl;->mUnit:Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    invoke-virtual {v2, v3}, Lcom/htc/clock/util/location/WeatherForecast;->getCur(Lcom/htc/clock/util/location/WeatherForecast$UNIT;)I

    move-result v1

    .line 600
    .local v1, "temp":I
    invoke-direct {p0, v1}, Lcom/htc/clock/util/location/LocationCtrl;->getTemp(I)Ljava/lang/String;

    move-result-object v2

    goto :goto_e
.end method

.method public getRetryCnt()I
    .registers 2

    .prologue
    .line 252
    iget v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mRetryForceCnt:I

    return v0
.end method

.method public getRetryPendingTime()J
    .registers 15

    .prologue
    const-wide/16 v12, 0x0

    const/4 v11, 0x1

    .line 225
    const-wide/16 v7, 0x0

    .line 226
    .local v7, "waitTime":J
    sget-object v9, Lcom/htc/clock/util/location/LocationCtrl;->sRetryTimes:[J

    array-length v2, v9

    .line 227
    .local v2, "maxSize":I
    iget v9, p0, Lcom/htc/clock/util/location/LocationCtrl;->mRetryForceCnt:I

    sub-int v10, v2, v11

    if-le v9, v10, :cond_28

    .line 228
    sget-object v9, Lcom/htc/clock/util/location/LocationCtrl;->sRetryTimes:[J

    sub-int v10, v2, v11

    aget-wide v7, v9, v10

    .line 233
    :goto_14
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 234
    .local v0, "currentTime":J
    const-wide/16 v3, 0x0

    .line 235
    .local v3, "pending":J
    iget-wide v9, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLastForceSyncTime:J

    cmp-long v9, v9, v12

    if-nez v9, :cond_2f

    iget v9, p0, Lcom/htc/clock/util/location/LocationCtrl;->mRetryForceCnt:I

    if-nez v9, :cond_2f

    .line 237
    iput-wide v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLastForceSyncTime:J

    .line 238
    move-wide v3, v7

    .line 248
    :cond_27
    :goto_27
    return-wide v3

    .line 230
    .end local v0    # "currentTime":J
    .end local v3    # "pending":J
    :cond_28
    sget-object v9, Lcom/htc/clock/util/location/LocationCtrl;->sRetryTimes:[J

    iget v10, p0, Lcom/htc/clock/util/location/LocationCtrl;->mRetryForceCnt:I

    aget-wide v7, v9, v10

    goto :goto_14

    .line 240
    .restart local v0    # "currentTime":J
    .restart local v3    # "pending":J
    :cond_2f
    iget-wide v9, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLastForceSyncTime:J

    add-long v5, v9, v7

    .line 241
    .local v5, "startSyncTime":J
    sub-long v3, v5, v0

    .line 242
    cmp-long v9, v3, v7

    if-lez v9, :cond_3b

    .line 243
    move-wide v3, v7

    goto :goto_27

    .line 244
    :cond_3b
    cmp-long v9, v3, v12

    if-gez v9, :cond_27

    .line 245
    const-wide/16 v3, 0x0

    goto :goto_27
.end method

.method public getState()Lcom/htc/clock/util/location/LocationCtrl$State;
    .registers 2

    .prologue
    .line 814
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mState:Lcom/htc/clock/util/location/LocationCtrl$State;

    return-object v0
.end method

.method public getTimeZoneId()Ljava/lang/String;
    .registers 4

    .prologue
    .line 806
    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocDataMap:Ljava/util/HashMap;

    iget-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocKey:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/htc/clock/util/location/LocationData;

    .line 807
    .local v0, "locData":Lcom/htc/clock/util/location/LocationData;
    if-eqz v0, :cond_11

    .line 808
    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationData;->getLocTimeZoneId()Ljava/lang/String;

    move-result-object v1

    .line 810
    :goto_10
    return-object v1

    :cond_11
    const/4 v1, 0x0

    goto :goto_10
.end method

.method public getWeatherLocation()Lcom/htc/util/weather/WeatherLocation;
    .registers 4

    .prologue
    .line 798
    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocDataMap:Ljava/util/HashMap;

    iget-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocKey:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/htc/clock/util/location/LocationData;

    .line 799
    .local v0, "locData":Lcom/htc/clock/util/location/LocationData;
    if-eqz v0, :cond_11

    .line 800
    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationData;->getWeatherLocation()Lcom/htc/util/weather/WeatherLocation;

    move-result-object v1

    .line 802
    :goto_10
    return-object v1

    :cond_11
    const/4 v1, 0x0

    goto :goto_10
.end method

.method public isCurrentLocation()Z
    .registers 3

    .prologue
    .line 781
    iget-boolean v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mIsWithCurLocation:Z

    if-eqz v0, :cond_10

    .line 782
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocKey:Ljava/lang/String;

    const-string v1, "cur"

    invoke-static {v0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_10

    .line 783
    const/4 v0, 0x1

    .line 786
    :goto_f
    return v0

    :cond_10
    const/4 v0, 0x0

    goto :goto_f
.end method

.method public isForceUpdateAvailable()Z
    .registers 5

    .prologue
    const/4 v3, 0x1

    const/4 v2, 0x0

    .line 190
    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->isLocServiceEnable()Z

    move-result v1

    if-nez v1, :cond_e

    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->isWithCurrentLocation()Z

    move-result v1

    if-nez v1, :cond_30

    :cond_e
    move v0, v3

    .line 191
    .local v0, "isLocationEnable":Z
    :goto_f
    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    invoke-direct {p0, v1}, Lcom/htc/clock/util/location/LocationCtrl;->allowBackgroundData(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_29

    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    invoke-static {v1}, Lcom/htc/util/http/NetworkUtil;->isActiveNetwork(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_29

    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    invoke-static {v1}, Lcom/htc/util/weather/WSPUtility;->isSyncAutomatically(Landroid/content/Context;)Z

    move-result v1

    if-eqz v1, :cond_29

    if-nez v0, :cond_32

    .line 195
    :cond_29
    const-string v1, "forceToSync~ no way to update"

    invoke-static {v1}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    move v1, v2

    .line 198
    :goto_2f
    return v1

    .end local v0    # "isLocationEnable":Z
    :cond_30
    move v0, v2

    .line 190
    goto :goto_f

    .restart local v0    # "isLocationEnable":Z
    :cond_32
    move v1, v3

    .line 198
    goto :goto_2f
.end method

.method public isLocServiceAvailable()Z
    .registers 2

    .prologue
    .line 891
    iget-boolean v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocationAvailable:Z

    return v0
.end method

.method public isLocServiceEnable()Z
    .registers 3

    .prologue
    .line 907
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "isLocServiceEnable enable:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocationEnable:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 908
    iget-boolean v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocationEnable:Z

    return v0
.end method

.method public isNeedUpdate()Z
    .registers 15

    .prologue
    .line 730
    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->getLocState()Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    move-result-object v10

    sget-object v11, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->OK:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    if-eq v10, v11, :cond_f

    .line 731
    const-string v10, "isNeedUpdate~ no weather"

    invoke-static {v10}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 732
    const/4 v10, 0x1

    .line 765
    :goto_e
    return v10

    .line 734
    :cond_f
    iget-object v10, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    invoke-static {v10}, Lcom/htc/util/weather/WSPUtility;->getAutoSyncFrequency(Landroid/content/Context;)J

    move-result-wide v10

    const-wide/32 v12, 0x2bf20

    add-long v6, v10, v12

    .line 736
    .local v6, "updateInterval":J
    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->getLastUpdateTime()J

    move-result-wide v8

    .line 737
    .local v8, "updateTime":J
    add-long v3, v8, v6

    .line 738
    .local v3, "nextAutoSyncTime":J
    invoke-static {}, Lcom/htc/clock/util/MyLog;->IsDebugLog()Z

    move-result v10

    if-eqz v10, :cond_103

    .line 739
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v5

    .line 740
    .local v5, "time":Ljava/util/Calendar;
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v10

    invoke-virtual {v5, v10, v11}, Ljava/util/Calendar;->setTimeInMillis(J)V

    .line 741
    const/4 v10, 0x5

    invoke-virtual {v5, v10}, Ljava/util/Calendar;->get(I)I

    move-result v0

    .line 742
    .local v0, "day":I
    const/16 v10, 0xa

    invoke-virtual {v5, v10}, Ljava/util/Calendar;->get(I)I

    move-result v1

    .line 743
    .local v1, "hour":I
    const/16 v10, 0xc

    invoke-virtual {v5, v10}, Ljava/util/Calendar;->get(I)I

    move-result v2

    .line 744
    .local v2, "min":I
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "isNeedUpdate~ updateInterval:"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const-wide/32 v11, 0xea60

    div-long v11, v6, v11

    invoke-virtual {v10, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 745
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "isNeedUpdate~ current):"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, ":"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, ":"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 746
    invoke-virtual {v5, v8, v9}, Ljava/util/Calendar;->setTimeInMillis(J)V

    .line 747
    const/4 v10, 0x5

    invoke-virtual {v5, v10}, Ljava/util/Calendar;->get(I)I

    move-result v0

    .line 748
    const/16 v10, 0xa

    invoke-virtual {v5, v10}, Ljava/util/Calendar;->get(I)I

    move-result v1

    .line 749
    const/16 v10, 0xc

    invoke-virtual {v5, v10}, Ljava/util/Calendar;->get(I)I

    move-result v2

    .line 750
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "isNeedUpdate~ updateTime):"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, ":"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, ":"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 753
    invoke-virtual {v5, v3, v4}, Ljava/util/Calendar;->setTimeInMillis(J)V

    .line 754
    const/4 v10, 0x5

    invoke-virtual {v5, v10}, Ljava/util/Calendar;->get(I)I

    move-result v0

    .line 755
    const/16 v10, 0xa

    invoke-virtual {v5, v10}, Ljava/util/Calendar;->get(I)I

    move-result v1

    .line 756
    const/16 v10, 0xc

    invoke-virtual {v5, v10}, Ljava/util/Calendar;->get(I)I

    move-result v2

    .line 757
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "isNeedUpdate~ nextAutoSyncTime):"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, ":"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, ":"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 760
    .end local v0    # "day":I
    .end local v1    # "hour":I
    .end local v2    # "min":I
    .end local v5    # "time":Ljava/util/Calendar;
    :cond_103
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v10

    sub-long/2addr v10, v3

    const-wide/16 v12, 0x0

    cmp-long v10, v10, v12

    if-ltz v10, :cond_116

    .line 761
    const-string v10, "isNeedUpdate~ true"

    invoke-static {v10}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 762
    const/4 v10, 0x1

    goto/16 :goto_e

    .line 764
    :cond_116
    const-string v10, "isNeedUpdate~ false"

    invoke-static {v10}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 765
    const/4 v10, 0x0

    goto/16 :goto_e
.end method

.method public isWithCurrentLocation()Z
    .registers 2

    .prologue
    .line 777
    iget-boolean v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mIsWithCurLocation:Z

    return v0
.end method

.method public onReceiverForceRetWeatherData(ZLcom/htc/util/weather/WSPData;)V
    .registers 3
    .param p1, "bForceRet"    # Z
    .param p2, "data"    # Lcom/htc/util/weather/WSPData;

    .prologue
    .line 490
    return-void
.end method

.method public onReceiverWeatherData(Lcom/htc/util/weather/WSPData;)V
    .registers 9
    .param p1, "data"    # Lcom/htc/util/weather/WSPData;

    .prologue
    const/4 v6, 0x0

    const/4 v5, 0x1

    .line 493
    if-nez p1, :cond_c

    .line 494
    iget-object v3, p0, Lcom/htc/clock/util/location/LocationCtrl;->mSOnReceiveLog:Ljava/lang/StringBuffer;

    const-string v4, "onReceiverWeatherData~ data is null\n"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 525
    :cond_b
    :goto_b
    return-void

    .line 497
    :cond_c
    iget-object v3, p0, Lcom/htc/clock/util/location/LocationCtrl;->mSOnReceiveLog:Ljava/lang/StringBuffer;

    const-string v4, "onReceiverWeatherData~ data:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {p1}, Lcom/htc/util/weather/WSPData;->toDebugInfo()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 501
    const/4 v2, 0x0

    .line 505
    .local v2, "locData":Lcom/htc/clock/util/location/LocationData;
    invoke-virtual {p1}, Lcom/htc/util/weather/WSPData;->getType()I

    move-result v3

    if-ne v3, v5, :cond_39

    move v1, v5

    .line 506
    .local v1, "isCurData":Z
    :goto_23
    if-eqz v1, :cond_3b

    .line 507
    iget-object v3, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocDataMap:Ljava/util/HashMap;

    const-string v4, "cur"

    invoke-virtual {v3, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    .end local v2    # "locData":Lcom/htc/clock/util/location/LocationData;
    check-cast v2, Lcom/htc/clock/util/location/LocationData;

    .line 511
    .restart local v2    # "locData":Lcom/htc/clock/util/location/LocationData;
    :goto_2f
    if-nez v2, :cond_48

    .line 512
    iget-object v3, p0, Lcom/htc/clock/util/location/LocationCtrl;->mSOnReceiveLog:Ljava/lang/StringBuffer;

    const-string v4, "onReceiverWeatherData~ locData == null\n"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    goto :goto_b

    .end local v1    # "isCurData":Z
    :cond_39
    move v1, v6

    .line 505
    goto :goto_23

    .line 509
    .restart local v1    # "isCurData":Z
    :cond_3b
    iget-object v3, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocDataMap:Ljava/util/HashMap;

    invoke-virtual {p1}, Lcom/htc/util/weather/WSPData;->getLocCode()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    .end local v2    # "locData":Lcom/htc/clock/util/location/LocationData;
    check-cast v2, Lcom/htc/clock/util/location/LocationData;

    .restart local v2    # "locData":Lcom/htc/clock/util/location/LocationData;
    goto :goto_2f

    .line 515
    :cond_48
    invoke-virtual {v2, p1, v6}, Lcom/htc/clock/util/location/LocationData;->setupByWSPData(Lcom/htc/util/weather/WSPData;Z)Z

    move-result v0

    .line 517
    .local v0, "change":Z
    invoke-virtual {p1}, Lcom/htc/util/weather/WSPData;->getLocCode()Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocKey:Ljava/lang/String;

    invoke-static {v3, v4}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_60

    if-eqz v1, :cond_64

    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->isCurrentLocation()Z

    move-result v3

    if-eqz v3, :cond_64

    .line 519
    :cond_60
    invoke-virtual {p0, v0}, Lcom/htc/clock/util/location/LocationCtrl;->sendWSPUpdateMessage(Z)V

    goto :goto_b

    .line 520
    :cond_64
    invoke-virtual {p1}, Lcom/htc/util/weather/WSPData;->getType()I

    move-result v3

    if-ne v3, v5, :cond_b

    .line 521
    iget-object v3, v2, Lcom/htc/clock/util/location/LocationData;->mState:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    sget-object v4, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->NO_DATA:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    if-eq v3, v4, :cond_b

    .line 522
    invoke-virtual {p0, v0}, Lcom/htc/clock/util/location/LocationCtrl;->sendWSPUpdateMessage(Z)V

    goto :goto_b
.end method

.method public register(Landroid/os/Handler;Lcom/htc/clock/util/location/LocationListener;)V
    .registers 4
    .param p1, "handler"    # Landroid/os/Handler;
    .param p2, "listener"    # Lcom/htc/clock/util/location/LocationListener;

    .prologue
    .line 261
    const-string v0, "register"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 262
    iput-object p2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mListener:Lcom/htc/clock/util/location/LocationListener;

    .line 263
    invoke-direct {p0, p1}, Lcom/htc/clock/util/location/LocationCtrl;->setHandler(Landroid/os/Handler;)V

    .line 264
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mWeatherReceiver:Landroid/content/BroadcastReceiver;

    if-nez v0, :cond_11

    .line 265
    invoke-direct {p0}, Lcom/htc/clock/util/location/LocationCtrl;->initWeatherReceiver()V

    .line 267
    :cond_11
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mTempUnitReceiver:Landroid/content/BroadcastReceiver;

    if-nez v0, :cond_1c

    iget-boolean v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mTempUnitEnable:Z

    if-eqz v0, :cond_1c

    .line 268
    invoke-direct {p0}, Lcom/htc/clock/util/location/LocationCtrl;->initTempUnitReceiver()V

    .line 270
    :cond_1c
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mConnectChangeRec:Landroid/content/BroadcastReceiver;

    if-nez v0, :cond_27

    iget-boolean v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mRetryEnable:Z

    if-eqz v0, :cond_27

    .line 271
    invoke-direct {p0}, Lcom/htc/clock/util/location/LocationCtrl;->initConnReceiver()V

    .line 273
    :cond_27
    sget-object v0, Lcom/htc/clock/util/location/LocationCtrl$State;->START:Lcom/htc/clock/util/location/LocationCtrl$State;

    iput-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mState:Lcom/htc/clock/util/location/LocationCtrl$State;

    .line 274
    invoke-direct {p0}, Lcom/htc/clock/util/location/LocationCtrl;->isUsedTempC()Z

    move-result v0

    if-eqz v0, :cond_39

    .line 275
    sget-object v0, Lcom/htc/clock/util/location/WeatherForecast$UNIT;->_C:Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    iput-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mUnit:Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    .line 279
    :goto_35
    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->updateWeatherData()V

    .line 280
    return-void

    .line 277
    :cond_39
    sget-object v0, Lcom/htc/clock/util/location/WeatherForecast$UNIT;->_F:Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    iput-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mUnit:Lcom/htc/clock/util/location/WeatherForecast$UNIT;

    goto :goto_35
.end method

.method public requestCurData()Lcom/htc/util/weather/WSPData;
    .registers 4

    .prologue
    .line 93
    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    invoke-static {}, Lcom/htc/util/weather/WSPUtility;->generateWSPReqestForCurrentLocation()Lcom/htc/util/weather/WSPRequest;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/htc/util/weather/WSPUtility;->request(Landroid/content/Context;Lcom/htc/util/weather/WSPRequest;)Lcom/htc/util/weather/WSPData;

    move-result-object v0

    .line 95
    .local v0, "data":Lcom/htc/util/weather/WSPData;
    return-object v0
.end method

.method public requestLocData(Ljava/lang/String;)Lcom/htc/util/weather/WSPData;
    .registers 5
    .param p1, "locCode"    # Ljava/lang/String;

    .prologue
    .line 99
    const/4 v0, 0x0

    .line 100
    .local v0, "data":Lcom/htc/util/weather/WSPData;
    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    invoke-static {p1}, Lcom/htc/util/weather/WSPUtility;->generateWSPRequestForLocCode(Ljava/lang/String;)Lcom/htc/util/weather/WSPRequest;

    move-result-object v2

    invoke-static {v1, v2}, Lcom/htc/util/weather/WSPUtility;->request(Landroid/content/Context;Lcom/htc/util/weather/WSPRequest;)Lcom/htc/util/weather/WSPData;

    move-result-object v0

    .line 102
    return-object v0
.end method

.method public sendWSPUpdateMessage(Z)V
    .registers 4
    .param p1, "bCityChanged"    # Z

    .prologue
    .line 818
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mListener:Lcom/htc/clock/util/location/LocationListener;

    if-nez v0, :cond_a

    .line 819
    const-string v0, "sendWSPUpdateMessage~ listener is null"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    .line 838
    :goto_9
    return-void

    .line 823
    :cond_a
    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->getLocState()Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    move-result-object v0

    sget-object v1, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->OK:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    if-ne v0, v1, :cond_15

    .line 824
    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->setRetryCntBack()V

    .line 827
    :cond_15
    if-eqz p1, :cond_2a

    .line 830
    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->getLocState()Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    move-result-object v0

    sget-object v1, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->NO_DATA:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    if-ne v0, v1, :cond_22

    .line 831
    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->checkLocService()V

    .line 834
    :cond_22
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mUIHandler:Landroid/os/Handler;

    const/16 v1, 0x3e9

    invoke-static {v0, v1}, Lcom/htc/clock/util/MyUtil;->sendMessage(Landroid/os/Handler;I)V

    goto :goto_9

    .line 836
    :cond_2a
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mUIHandler:Landroid/os/Handler;

    const/16 v1, 0x3ea

    invoke-static {v0, v1}, Lcom/htc/clock/util/MyUtil;->sendMessage(Landroid/os/Handler;I)V

    goto :goto_9
.end method

.method public setLocKey(Ljava/lang/String;)V
    .registers 2
    .param p1, "locKey"    # Ljava/lang/String;

    .prologue
    .line 161
    iput-object p1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocKey:Ljava/lang/String;

    .line 162
    return-void
.end method

.method public setRetryCntBack()V
    .registers 3

    .prologue
    .line 256
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLastForceSyncTime:J

    .line 257
    const/4 v0, 0x0

    iput v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mRetryForceCnt:I

    .line 258
    return-void
.end method

.method public setRetryEnable(Z)V
    .registers 2
    .param p1, "enable"    # Z

    .prologue
    .line 85
    iput-boolean p1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mRetryEnable:Z

    .line 86
    return-void
.end method

.method public setTempUnitEnable(Z)V
    .registers 2
    .param p1, "enable"    # Z

    .prologue
    .line 89
    iput-boolean p1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mTempUnitEnable:Z

    .line 90
    return-void
.end method

.method public unRegister()V
    .registers 4

    .prologue
    const/4 v2, 0x0

    .line 463
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mHandler:Landroid/os/Handler;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/htc/clock/util/MyUtil;->removeMessage(Landroid/os/Handler;I)V

    .line 464
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mHandler:Landroid/os/Handler;

    const/4 v1, 0x2

    invoke-static {v0, v1}, Lcom/htc/clock/util/MyUtil;->removeMessage(Landroid/os/Handler;I)V

    .line 465
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mHandler:Landroid/os/Handler;

    const/4 v1, 0x3

    invoke-static {v0, v1}, Lcom/htc/clock/util/MyUtil;->removeMessage(Landroid/os/Handler;I)V

    .line 466
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mHandler:Landroid/os/Handler;

    const/4 v1, 0x4

    invoke-static {v0, v1}, Lcom/htc/clock/util/MyUtil;->removeMessage(Landroid/os/Handler;I)V

    .line 468
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mWeatherReceiver:Landroid/content/BroadcastReceiver;

    if-eqz v0, :cond_26

    .line 469
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mWeatherReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v0, v1}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 470
    iput-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mWeatherReceiver:Landroid/content/BroadcastReceiver;

    .line 472
    :cond_26
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mTempUnitReceiver:Landroid/content/BroadcastReceiver;

    if-eqz v0, :cond_33

    .line 473
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mTempUnitReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v0, v1}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 474
    iput-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mTempUnitReceiver:Landroid/content/BroadcastReceiver;

    .line 476
    :cond_33
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mWeatherApReceiver:Landroid/content/BroadcastReceiver;

    if-eqz v0, :cond_40

    .line 477
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mWeatherApReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v0, v1}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 478
    iput-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mWeatherApReceiver:Landroid/content/BroadcastReceiver;

    .line 480
    :cond_40
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mConnectChangeRec:Landroid/content/BroadcastReceiver;

    if-eqz v0, :cond_4d

    .line 481
    iget-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mContext:Landroid/content/Context;

    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl;->mConnectChangeRec:Landroid/content/BroadcastReceiver;

    invoke-virtual {v0, v1}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 482
    iput-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mConnectChangeRec:Landroid/content/BroadcastReceiver;

    .line 484
    :cond_4d
    sget-object v0, Lcom/htc/clock/util/location/LocationCtrl$State;->STOP:Lcom/htc/clock/util/location/LocationCtrl$State;

    iput-object v0, p0, Lcom/htc/clock/util/location/LocationCtrl;->mState:Lcom/htc/clock/util/location/LocationCtrl$State;

    .line 485
    return-void
.end method

.method public updateDataByForeCast()Z
    .registers 5

    .prologue
    .line 641
    iget-object v2, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocDataMap:Ljava/util/HashMap;

    iget-object v3, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocKey:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/htc/clock/util/location/LocationData;

    .line 642
    .local v1, "locData":Lcom/htc/clock/util/location/LocationData;
    const/4 v0, 0x0

    .line 643
    .local v0, "bUpdate":Z
    if-eqz v1, :cond_11

    .line 644
    invoke-virtual {v1}, Lcom/htc/clock/util/location/LocationData;->updateForecastDateNow()Z

    move-result v0

    .line 646
    :cond_11
    return v0
.end method

.method public updateWeatherData()V
    .registers 12

    .prologue
    const/4 v10, 0x1

    const-string v9, "cur"

    .line 528
    const/4 v6, 0x0

    .line 529
    .local v6, "wspData":Lcom/htc/util/weather/WSPData;
    const/4 v4, 0x0

    .line 530
    .local v4, "locData":Lcom/htc/clock/util/location/LocationData;
    const/4 v0, 0x0

    .line 531
    .local v0, "bCityChanged":Z
    const/4 v1, 0x0

    .line 532
    .local v1, "bwithCurData":Z
    iget-object v7, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocDataMap:Ljava/util/HashMap;

    invoke-virtual {v7}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v7

    invoke-interface {v7}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    .local v3, "i$":Ljava/util/Iterator;
    :cond_11
    :goto_11
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_74

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    .line 533
    .local v5, "locKey":Ljava/lang/String;
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "updateWeatherData~ locKey:"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 534
    iget-object v7, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocDataMap:Ljava/util/HashMap;

    invoke-virtual {v7, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    .end local v4    # "locData":Lcom/htc/clock/util/location/LocationData;
    check-cast v4, Lcom/htc/clock/util/location/LocationData;

    .line 535
    .restart local v4    # "locData":Lcom/htc/clock/util/location/LocationData;
    const-string v7, "cur"

    invoke-virtual {v9, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_68

    .line 536
    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->requestCurData()Lcom/htc/util/weather/WSPData;

    move-result-object v6

    .line 540
    :goto_47
    invoke-virtual {v4, v6, v10}, Lcom/htc/clock/util/location/LocationData;->setupByWSPData(Lcom/htc/util/weather/WSPData;Z)Z

    move-result v2

    .line 541
    .local v2, "change":Z
    const-string v7, "cur"

    invoke-virtual {v9, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_11

    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->isCurrentLocation()Z

    move-result v7

    if-eqz v7, :cond_11

    .line 543
    invoke-virtual {p0}, Lcom/htc/clock/util/location/LocationCtrl;->isCurrentLocation()Z

    move-result v7

    if-eqz v7, :cond_60

    .line 544
    move v0, v2

    .line 546
    :cond_60
    iget-object v7, v4, Lcom/htc/clock/util/location/LocationData;->mState:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    sget-object v8, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->NO_DATA:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    if-eq v7, v8, :cond_71

    move v1, v10

    :goto_67
    goto :goto_11

    .line 538
    .end local v2    # "change":Z
    :cond_68
    invoke-virtual {v4}, Lcom/htc/clock/util/location/LocationData;->getLocCode()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {p0, v7}, Lcom/htc/clock/util/location/LocationCtrl;->requestLocData(Ljava/lang/String;)Lcom/htc/util/weather/WSPData;

    move-result-object v6

    goto :goto_47

    .line 546
    .restart local v2    # "change":Z
    :cond_71
    const/4 v7, 0x0

    move v1, v7

    goto :goto_67

    .line 549
    .end local v2    # "change":Z
    .end local v5    # "locKey":Ljava/lang/String;
    :cond_74
    const-string v7, "cur"

    iget-object v7, p0, Lcom/htc/clock/util/location/LocationCtrl;->mLocKey:Ljava/lang/String;

    invoke-virtual {v9, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_81

    if-eqz v1, :cond_81

    .line 550
    const/4 v0, 0x1

    .line 552
    :cond_81
    invoke-virtual {p0, v0}, Lcom/htc/clock/util/location/LocationCtrl;->sendWSPUpdateMessage(Z)V

    .line 553
    return-void
.end method
