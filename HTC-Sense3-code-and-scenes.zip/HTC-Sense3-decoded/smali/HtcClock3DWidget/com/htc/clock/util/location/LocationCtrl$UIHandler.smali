.class Lcom/htc/clock/util/location/LocationCtrl$UIHandler;
.super Landroid/os/Handler;
.source "LocationCtrl.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock/util/location/LocationCtrl;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "UIHandler"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/clock/util/location/LocationCtrl;


# direct methods
.method constructor <init>(Lcom/htc/clock/util/location/LocationCtrl;Landroid/os/Looper;)V
    .registers 3
    .param p2, "looper"    # Landroid/os/Looper;

    .prologue
    .line 653
    iput-object p1, p0, Lcom/htc/clock/util/location/LocationCtrl$UIHandler;->this$0:Lcom/htc/clock/util/location/LocationCtrl;

    .line 654
    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 655
    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .registers 4
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    .line 658
    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl$UIHandler;->this$0:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-static {v1}, Lcom/htc/clock/util/location/LocationCtrl;->access$200(Lcom/htc/clock/util/location/LocationCtrl;)Lcom/htc/clock/util/location/LocationListener;

    move-result-object v0

    .line 659
    .local v0, "listener":Lcom/htc/clock/util/location/LocationListener;
    if-nez v0, :cond_9

    .line 673
    :goto_8
    return-void

    .line 662
    :cond_9
    iget v1, p1, Landroid/os/Message;->what:I

    packed-switch v1, :pswitch_data_22

    goto :goto_8

    .line 664
    :pswitch_f
    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl$UIHandler;->this$0:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-interface {v0, v1}, Lcom/htc/clock/util/location/LocationListener;->onCityUpdate(Lcom/htc/clock/util/location/LocationCtrl;)V

    goto :goto_8

    .line 667
    :pswitch_15
    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl$UIHandler;->this$0:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-interface {v0, v1}, Lcom/htc/clock/util/location/LocationListener;->onWeatherUpdate(Lcom/htc/clock/util/location/LocationCtrl;)V

    goto :goto_8

    .line 670
    :pswitch_1b
    iget-object v1, p0, Lcom/htc/clock/util/location/LocationCtrl$UIHandler;->this$0:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-interface {v0, v1}, Lcom/htc/clock/util/location/LocationListener;->onTempUnitChange(Lcom/htc/clock/util/location/LocationCtrl;)V

    goto :goto_8

    .line 662
    nop

    :pswitch_data_22
    .packed-switch 0x3e9
        :pswitch_f
        :pswitch_15
        :pswitch_1b
    .end packed-switch
.end method
