.class public Lcom/htc/clock3dwidget/weatherclock/WeatherView;
.super Ljava/lang/Object;
.source "WeatherView.java"


# static fields
.field static final ACTION_HIDE_WEATHER_WALLPAPER:Ljava/lang/String; = "com.htc.weatherwallpaper.service.intent.action.HIDE_WEATHER_WALLPAPER"

.field static final ACTION_SHOW_WEATHER_WALLPAPER:Ljava/lang/String; = "com.htc.weatherwallpaper.service.intent.action.SHOW_WEATHER_WALLPAPER"

.field protected static final flagUseTodayAnimation:Z

.field protected static final mMapToWeatherWallpaper:[I


# instance fields
.field API_level:I

.field protected flagUseWeatherAnimation:Z

.field private m3DLock:Ljava/lang/Object;

.field private mArabic:Z

.field protected mBNeedToUpdate:Z

.field protected mBNeedUpdateTemp:Z

.field private mCellX:I

.field private mCellY:I

.field protected mCityRest:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mCityRestText:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field protected mCityView:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field protected mConditionLength:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mConditionView:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field protected mContext:Landroid/content/Context;

.field protected mDfMode:I

.field protected mFrameNumber:I

.field protected mFxTextIndH:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field protected mFxTextIndL:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field protected mHTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field protected mHost:Lcom/htc/android/rosie/widget/Widget$Host;

.field protected mImgToday:Lcom/htc/fusion/fx/controls/FxSceneContainer;

.field private mIsWeatherWallpaperShowing:Z

.field protected mLTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field protected mMode:I

.field protected mNeedPlayWeatherWallpaperAnimation:Z

.field protected mNoWeatherView:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field protected mParentWidget:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

.field protected mPlayAnimationWhenStartAnimation:Z

.field private mPlayWWPTime:J

.field protected mPreviousMode:I

.field protected mPreviousResId:I

.field protected mStateResources:Lcom/htc/weather/StateResources;

.field protected mTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field protected mTime:I

.field private mTodayAnimation:Lcom/htc/fusion/fx/FxScene;

.field protected mWeatherType:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mWeekDayView:Lcom/htc/fusion/fx/controls/FxTextLabel;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .prologue
    .line 66
    const/16 v0, 0x2c

    new-array v0, v0, [I

    fill-array-data v0, :array_a

    sput-object v0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mMapToWeatherWallpaper:[I

    return-void

    :array_a
    .array-data 4
        0x7
        0x6
        0x1
        0x1
        0x6
        0x1
        0x1
        0x1
        0x1
        0x1
        0x1
        0x4
        0x4
        0x4
        0x8
        0x8
        0x8
        0x4
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x5
        0x1
        0x1
        0x5
        0x7
        0x5
        0x9
        0x3
        0x2
        0x1
        0x1
        0x2
        0x1
        0x4
        0x4
        0x8
        0x8
        0x5
        0x5
    .end array-data
.end method

.method constructor <init>(Landroid/content/Context;Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Lcom/htc/android/rosie/widget/Widget$Host;)V
    .registers 9
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "widget"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;
    .param p3, "host"    # Lcom/htc/android/rosie/widget/Widget$Host;

    .prologue
    const/4 v4, 0x1

    const/4 v2, -0x1

    const/4 v3, 0x0

    .line 74
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 25
    iput-boolean v4, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->flagUseWeatherAnimation:Z

    .line 51
    iput v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mPreviousResId:I

    .line 57
    iput v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mFrameNumber:I

    .line 58
    iput v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mTime:I

    .line 59
    iput v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mMode:I

    .line 60
    iput v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mDfMode:I

    .line 61
    iput v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mPreviousMode:I

    .line 63
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mNeedPlayWeatherWallpaperAnimation:Z

    .line 64
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mPlayAnimationWhenStartAnimation:Z

    .line 70
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mArabic:Z

    .line 72
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    iput v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->API_level:I

    .line 84
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mBNeedToUpdate:Z

    .line 86
    iput v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mCellX:I

    .line 87
    iput v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mCellY:I

    .line 273
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mBNeedUpdateTemp:Z

    .line 416
    const-wide/16 v1, 0x0

    iput-wide v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mPlayWWPTime:J

    .line 490
    new-instance v1, Ljava/lang/Object;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    iput-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->m3DLock:Ljava/lang/Object;

    .line 539
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mIsWeatherWallpaperShowing:Z

    .line 75
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v1

    iget-object v1, v1, Landroid/content/res/Configuration;->locale:Ljava/util/Locale;

    invoke-virtual {v1}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v0

    .line 76
    .local v0, "locale":Ljava/lang/String;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "locale="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 77
    const-string v1, "ar"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_62

    .line 78
    iput-boolean v4, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mArabic:Z

    .line 82
    :goto_61
    return-void

    .line 80
    :cond_62
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mArabic:Z

    goto :goto_61
.end method

.method private getDrawableFromResId(Landroid/content/res/Resources;I)Landroid/graphics/drawable/Drawable;
    .registers 6
    .param p1, "res"    # Landroid/content/res/Resources;
    .param p2, "resId"    # I

    .prologue
    .line 472
    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    .line 473
    .local v0, "drawable":Landroid/graphics/drawable/Drawable;
    if-nez v0, :cond_1e

    .line 474
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "getDrawableFromResId~ can\'t get drawable object:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    .line 475
    const/4 v1, 0x0

    .line 478
    :goto_1d
    return-object v1

    .line 477
    :cond_1e
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setDither(Z)V

    move-object v1, v0

    .line 478
    goto :goto_1d
.end method

.method private declared-synchronized getWeatherRes()Lcom/htc/weather/StateResources;
    .registers 3

    .prologue
    .line 298
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mStateResources:Lcom/htc/weather/StateResources;

    if-nez v0, :cond_13

    .line 299
    new-instance v0, Lcom/htc/weather/StateResources;

    invoke-direct {v0}, Lcom/htc/weather/StateResources;-><init>()V

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mStateResources:Lcom/htc/weather/StateResources;

    .line 300
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mStateResources:Lcom/htc/weather/StateResources;

    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mContext:Landroid/content/Context;

    invoke-virtual {v0, v1}, Lcom/htc/weather/StateResources;->init(Landroid/content/Context;)V

    .line 302
    :cond_13
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mStateResources:Lcom/htc/weather/StateResources;
    :try_end_15
    .catchall {:try_start_1 .. :try_end_15} :catchall_17

    monitor-exit p0

    return-object v0

    .line 298
    :catchall_17
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method private isPlayingWWP()Z
    .registers 7

    .prologue
    .line 458
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    .line 460
    .local v0, "curTime":J
    iget-wide v4, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mPlayWWPTime:J

    sub-long v2, v0, v4

    .line 461
    .local v2, "dif":J
    const-wide/16 v4, 0x0

    cmp-long v4, v4, v2

    if-gez v4, :cond_16

    const-wide/16 v4, 0x3e8

    cmp-long v4, v2, v4

    if-gez v4, :cond_16

    .line 462
    const/4 v4, 0x1

    .line 464
    :goto_15
    return v4

    :cond_16
    const/4 v4, 0x0

    goto :goto_15
.end method

.method private setIndicatorText()V
    .registers 6

    .prologue
    const-string v4, ""

    .line 219
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mContext:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const v3, 0x7f060006

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 221
    .local v0, "indH":Ljava/lang/String;
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mContext:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const v3, 0x7f060007

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    .line 223
    .local v1, "indL":Ljava/lang/String;
    iget-boolean v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mArabic:Z

    if-eqz v2, :cond_2f

    .line 224
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mFxTextIndH:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const-string v3, ""

    invoke-virtual {v2, v4}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 225
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mFxTextIndL:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const-string v3, ""

    invoke-virtual {v2, v4}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 230
    :goto_2e
    return-void

    .line 227
    :cond_2f
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mFxTextIndH:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v2, v0}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 228
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mFxTextIndL:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v2, v1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    goto :goto_2e
.end method

.method private setLocationInfoVisibility(Z)V
    .registers 3
    .param p1, "visible"    # Z

    .prologue
    .line 251
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mCityRest:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_9

    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mCityRest:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, p1}, Lcom/htc/fusion/fx/FxTimelineControl;->setVisibility(Z)Ljava/util/ArrayList;

    .line 252
    :cond_9
    return-void
.end method

.method private setTodayImage(I)V
    .registers 11
    .param p1, "conditionId"    # I

    .prologue
    const/4 v7, 0x1

    const-string v8, "In"

    .line 306
    iget-object v5, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mImgToday:Lcom/htc/fusion/fx/controls/FxSceneContainer;

    if-nez v5, :cond_8

    .line 334
    :cond_7
    :goto_7
    return-void

    .line 309
    :cond_8
    iget v5, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mPreviousResId:I

    if-eq v5, p1, :cond_7

    .line 311
    invoke-static {v7}, Lcom/htc/clock3dwidget/ClockUtils;->getMode10Path(Z)Ljava/lang/String;

    move-result-object v2

    .line 314
    .local v2, "m10Path":Ljava/lang/String;
    const/16 v5, 0xa

    if-ge p1, v5, :cond_84

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "0"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    move-object v1, v5

    .line 316
    .local v1, "id":Ljava/lang/String;
    :goto_2c
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, ".m10"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    .line 317
    .local v3, "path":Ljava/lang/String;
    iget-object v5, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mHost:Lcom/htc/android/rosie/widget/Widget$Host;

    invoke-interface {v5, v3, v7}, Lcom/htc/android/rosie/widget/Widget$Host;->createScene(Ljava/lang/String;Z)Lcom/htc/fusion/fx/FxScene;

    move-result-object v5

    iput-object v5, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mTodayAnimation:Lcom/htc/fusion/fx/FxScene;

    .line 319
    iget-object v5, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mTodayAnimation:Lcom/htc/fusion/fx/FxScene;

    if-eqz v5, :cond_81

    .line 320
    iget-object v5, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mImgToday:Lcom/htc/fusion/fx/controls/FxSceneContainer;

    invoke-virtual {v5, v7}, Lcom/htc/fusion/fx/controls/FxSceneContainer;->setVisibility(Z)Ljava/util/ArrayList;

    .line 321
    iget-object v5, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mImgToday:Lcom/htc/fusion/fx/controls/FxSceneContainer;

    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mTodayAnimation:Lcom/htc/fusion/fx/FxScene;

    invoke-virtual {v5, v6}, Lcom/htc/fusion/fx/controls/FxSceneContainer;->setScene(Lcom/htc/fusion/fx/FxScene;)V

    .line 322
    sget-boolean v5, Lcom/htc/clock3dwidget/ClockUtils;->SUPPORT_TIMELINE:Z

    if-eqz v5, :cond_8a

    .line 323
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "timeline.s_"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 324
    .local v0, "condition":Ljava/lang/String;
    iget-object v5, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mTodayAnimation:Lcom/htc/fusion/fx/FxScene;

    invoke-virtual {v5, v0}, Lcom/htc/fusion/fx/FxScene;->findControl(Ljava/lang/String;)Lcom/htc/fusion/fx/FxControl;

    move-result-object v4

    check-cast v4, Lcom/htc/fusion/fx/FxTimelineControl;

    .line 325
    .local v4, "timelineToday":Lcom/htc/fusion/fx/FxTimelineControl;
    if-eqz v4, :cond_81

    .line 326
    const-string v5, "In"

    invoke-virtual {v4, v8}, Lcom/htc/fusion/fx/FxTimelineControl;->playMarker(Ljava/lang/String;)V

    .line 332
    .end local v0    # "condition":Ljava/lang/String;
    .end local v4    # "timelineToday":Lcom/htc/fusion/fx/FxTimelineControl;
    :cond_81
    :goto_81
    iput p1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mPreviousResId:I

    goto :goto_7

    .line 314
    .end local v1    # "id":Ljava/lang/String;
    .end local v3    # "path":Ljava/lang/String;
    :cond_84
    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    move-object v1, v5

    goto :goto_2c

    .line 329
    .restart local v1    # "id":Ljava/lang/String;
    .restart local v3    # "path":Ljava/lang/String;
    :cond_8a
    iget-object v5, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mTodayAnimation:Lcom/htc/fusion/fx/FxScene;

    const-string v6, "In"

    invoke-virtual {v5, v8}, Lcom/htc/fusion/fx/FxScene;->playMarker(Ljava/lang/String;)V

    goto :goto_81
.end method

.method private setWeatherViewVisibility(Z)V
    .registers 3
    .param p1, "visible"    # Z

    .prologue
    .line 255
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mWeekDayView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_9

    .line 256
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mWeekDayView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v0, p1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setVisibility(Z)Ljava/util/ArrayList;

    .line 257
    :cond_9
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_12

    .line 258
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v0, p1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setVisibility(Z)Ljava/util/ArrayList;

    .line 259
    :cond_12
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mHTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_1b

    .line 260
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mHTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v0, p1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setVisibility(Z)Ljava/util/ArrayList;

    .line 261
    :cond_1b
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mLTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_24

    .line 262
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mLTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v0, p1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setVisibility(Z)Ljava/util/ArrayList;

    .line 263
    :cond_24
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mFxTextIndH:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_2d

    .line 264
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mFxTextIndH:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v0, p1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setVisibility(Z)Ljava/util/ArrayList;

    .line 265
    :cond_2d
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mFxTextIndL:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_36

    .line 266
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mFxTextIndL:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v0, p1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setVisibility(Z)Ljava/util/ArrayList;

    .line 267
    :cond_36
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mConditionView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_3f

    .line 268
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mConditionView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v0, p1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setVisibility(Z)Ljava/util/ArrayList;

    .line 269
    :cond_3f
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mNoWeatherView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_48

    .line 270
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mNoWeatherView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v0, p1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setVisibility(Z)Ljava/util/ArrayList;

    .line 271
    :cond_48
    return-void
.end method

.method private showDataError()V
    .registers 5

    .prologue
    const-string v3, ""

    .line 233
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mContext:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f06001e

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 234
    .local v0, "text":Ljava/lang/String;
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mNoWeatherView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v1, :cond_4d

    .line 235
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mConditionView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const-string v2, ""

    invoke-virtual {v1, v3}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 236
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mNoWeatherView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v1, v0}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 240
    :goto_1f
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mImgToday:Lcom/htc/fusion/fx/controls/FxSceneContainer;

    if-eqz v1, :cond_29

    .line 241
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mImgToday:Lcom/htc/fusion/fx/controls/FxSceneContainer;

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Lcom/htc/fusion/fx/controls/FxSceneContainer;->setVisibility(Z)Ljava/util/ArrayList;

    .line 243
    :cond_29
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const-string v2, ""

    invoke-virtual {v1, v3}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 244
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mHTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const-string v2, ""

    invoke-virtual {v1, v3}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 245
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mLTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const-string v2, ""

    invoke-virtual {v1, v3}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 246
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mFxTextIndH:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const-string v2, ""

    invoke-virtual {v1, v3}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 247
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mFxTextIndL:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const-string v2, ""

    invoke-virtual {v1, v3}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 248
    return-void

    .line 238
    :cond_4d
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mConditionView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v1, v0}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    goto :goto_1f
.end method


# virtual methods
.method public IsNeedUpdate()Z
    .registers 2

    .prologue
    .line 294
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mBNeedUpdateTemp:Z

    if-nez v0, :cond_8

    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mBNeedToUpdate:Z

    if-eqz v0, :cond_a

    :cond_8
    const/4 v0, 0x1

    :goto_9
    return v0

    :cond_a
    const/4 v0, 0x0

    goto :goto_9
.end method

.method public animationEnd()V
    .registers 2

    .prologue
    .line 413
    const-string v0, "animationEnd"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->d(Ljava/lang/String;)V

    .line 414
    return-void
.end method

.method public attach3DObject()V
    .registers 1

    .prologue
    .line 494
    return-void
.end method

.method public checkPlayAnimationTime()V
    .registers 4

    .prologue
    .line 482
    new-instance v0, Ljava/io/File;

    const-string v1, "/data/data/"

    const-string v2, "WeatherWallpaperEasy"

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 483
    .local v0, "file":Ljava/io/File;
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_13

    .line 484
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mPlayAnimationWhenStartAnimation:Z

    .line 487
    :goto_12
    return-void

    .line 486
    :cond_13
    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mPlayAnimationWhenStartAnimation:Z

    goto :goto_12
.end method

.method public clear()V
    .registers 2

    .prologue
    .line 345
    const/4 v0, -0x1

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mPreviousResId:I

    .line 346
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->uiStopTodayAnimation()V

    .line 347
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mImgToday:Lcom/htc/fusion/fx/controls/FxSceneContainer;

    if-eqz v0, :cond_d

    .line 348
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mImgToday:Lcom/htc/fusion/fx/controls/FxSceneContainer;

    .line 351
    :cond_d
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->detach3DObject()V

    .line 352
    return-void
.end method

.method public detach3DObject()V
    .registers 1

    .prologue
    .line 497
    return-void
.end method

.method public initAnimation()V
    .registers 3

    .prologue
    const/4 v1, 0x0

    .line 527
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->flagUseWeatherAnimation:Z

    if-eqz v0, :cond_c

    .line 529
    iput v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mFrameNumber:I

    .line 530
    iput v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mTime:I

    .line 531
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->attach3DObject()V

    .line 533
    :cond_c
    return-void
.end method

.method public isUseWWPAnimation()Z
    .registers 2

    .prologue
    .line 504
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->flagUseWeatherAnimation:Z

    return v0
.end method

.method public isWeatherVisiable()Z
    .registers 7

    .prologue
    const/4 v5, 0x1

    const/4 v4, 0x0

    .line 106
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mParentWidget:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    invoke-virtual {v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getWeatherCtrl()Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v1

    .line 107
    .local v1, "weatherCtrl":Lcom/htc/clock/util/location/LocationCtrl;
    invoke-virtual {v1}, Lcom/htc/clock/util/location/LocationCtrl;->isLocServiceEnable()Z

    move-result v2

    if-nez v2, :cond_14

    invoke-virtual {v1}, Lcom/htc/clock/util/location/LocationCtrl;->isWithCurrentLocation()Z

    move-result v2

    if-nez v2, :cond_37

    :cond_14
    move v0, v5

    .line 109
    .local v0, "isLocationEnable":Z
    :goto_15
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "weatherView isWeatherVisiable~ isLocationEnable:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 111
    sget-object v2, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->OK:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    invoke-virtual {v1}, Lcom/htc/clock/util/location/LocationCtrl;->getLocState()Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    move-result-object v3

    if-ne v2, v3, :cond_39

    if-eqz v0, :cond_39

    move v2, v5

    .line 115
    :goto_36
    return v2

    .end local v0    # "isLocationEnable":Z
    :cond_37
    move v0, v4

    .line 107
    goto :goto_15

    .restart local v0    # "isLocationEnable":Z
    :cond_39
    move v2, v4

    .line 115
    goto :goto_36
.end method

.method public onPause()V
    .registers 4

    .prologue
    const/4 v2, 0x0

    .line 515
    invoke-virtual {p0, v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->setInstanceVisiable(Z)V

    .line 516
    iget-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mIsWeatherWallpaperShowing:Z

    if-eqz v1, :cond_1a

    .line 517
    iput-boolean v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mIsWeatherWallpaperShowing:Z

    .line 518
    new-instance v0, Landroid/content/Intent;

    const-string v1, "com.htc.weatherwallpaper.service.intent.action.HIDE_WEATHER_WALLPAPER"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 519
    .local v0, "intent":Landroid/content/Intent;
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mHost:Lcom/htc/android/rosie/widget/Widget$Host;

    invoke-interface {v1}, Lcom/htc/android/rosie/widget/Widget$Host;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    .line 521
    .end local v0    # "intent":Landroid/content/Intent;
    :cond_1a
    return-void
.end method

.method public onResume()V
    .registers 2

    .prologue
    .line 511
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->setInstanceVisiable(Z)V

    .line 512
    return-void
.end method

.method public requestShowWeatherWallpaper(IIIII)Z
    .registers 10
    .param p1, "condition"    # I
    .param p2, "icon_x"    # I
    .param p3, "icon_y"    # I
    .param p4, "icon_w"    # I
    .param p5, "icon_h"    # I

    .prologue
    const/4 v3, 0x1

    .line 545
    new-instance v1, Landroid/content/Intent;

    const-string v2, "com.htc.weatherwallpaper.service.intent.action.SHOW_WEATHER_WALLPAPER"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 546
    .local v1, "intent":Landroid/content/Intent;
    const-string v2, "WeatherCondition"

    invoke-virtual {v1, v2, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 547
    const/4 v2, 0x4

    new-array v0, v2, [I

    const/4 v2, 0x0

    aput p2, v0, v2

    aput p3, v0, v3

    const/4 v2, 0x2

    aput p4, v0, v2

    const/4 v2, 0x3

    aput p5, v0, v2

    .line 548
    .local v0, "iconInfo":[I
    const-string v2, "iconInfo"

    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[I)Landroid/content/Intent;

    .line 549
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mIsWeatherWallpaperShowing:Z

    .line 550
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mHost:Lcom/htc/android/rosie/widget/Widget$Host;

    invoke-interface {v2}, Lcom/htc/android/rosie/widget/Widget$Host;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2, v1}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 551
    return v3
.end method

.method public setInstanceVisiable(Z)V
    .registers 2
    .param p1, "bool"    # Z

    .prologue
    .line 508
    return-void
.end method

.method public setNeedPlayWeatherWallpaper(Z)V
    .registers 2
    .param p1, "flag"    # Z

    .prologue
    .line 500
    iput-boolean p1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mNeedPlayWeatherWallpaperAnimation:Z

    .line 501
    return-void
.end method

.method public setPlayWWP(Z)V
    .registers 2
    .param p1, "bPlayWWP"    # Z

    .prologue
    .line 536
    iput-boolean p1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->flagUseWeatherAnimation:Z

    .line 537
    return-void
.end method

.method public setPosition(II)V
    .registers 3
    .param p1, "cellX"    # I
    .param p2, "cellY"    # I

    .prologue
    .line 419
    iput p1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mCellX:I

    .line 420
    iput p2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mCellY:I

    .line 421
    return-void
.end method

.method public startTodayAnimation()V
    .registers 5

    .prologue
    .line 355
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mParentWidget:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    const v1, 0x8009

    const-wide/16 v2, 0x0

    invoke-virtual {v0, v1, v2, v3}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->sendUiMessageDelayed(IJ)V

    .line 356
    return-void
.end method

.method public startWWPAnimation(J)Z
    .registers 9
    .param p1, "delayTime"    # J

    .prologue
    const v5, 0x8013

    const/4 v4, 0x0

    .line 384
    const/4 v0, 0x0

    .line 385
    .local v0, "bGoToPlay":Z
    iget-boolean v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->flagUseWeatherAnimation:Z

    if-eqz v2, :cond_5f

    .line 386
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mParentWidget:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    invoke-virtual {v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getWeatherCtrl()Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v1

    .line 387
    .local v1, "wthCtrl":Lcom/htc/clock/util/location/LocationCtrl;
    if-eqz v1, :cond_25

    sget-object v2, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->OK:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    invoke-virtual {v1}, Lcom/htc/clock/util/location/LocationCtrl;->getLocState()Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    move-result-object v3

    if-ne v2, v3, :cond_25

    invoke-virtual {v1}, Lcom/htc/clock/util/location/LocationCtrl;->isCurrentLocation()Z

    move-result v2

    if-eqz v2, :cond_49

    invoke-virtual {v1}, Lcom/htc/clock/util/location/LocationCtrl;->isLocServiceEnable()Z

    move-result v2

    if-nez v2, :cond_49

    .line 391
    :cond_25
    if-eqz v1, :cond_43

    .line 392
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "startWWPAnimation~ wthCtrl.getLocState():"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v1}, Lcom/htc/clock/util/location/LocationCtrl;->getLocState()Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    :goto_41
    move v2, v4

    .line 409
    .end local v1    # "wthCtrl":Lcom/htc/clock/util/location/LocationCtrl;
    :goto_42
    return v2

    .line 395
    .restart local v1    # "wthCtrl":Lcom/htc/clock/util/location/LocationCtrl;
    :cond_43
    const-string v2, "startWWPAnimation~ wthCtrl is null"

    invoke-static {v2}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    goto :goto_41

    .line 400
    :cond_49
    iget-boolean v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mPlayAnimationWhenStartAnimation:Z

    if-nez v2, :cond_5d

    .line 401
    const-string v2, "startWWPAnimation~ play"

    invoke-static {v2}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 402
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mParentWidget:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    invoke-virtual {v2, v5}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 403
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mParentWidget:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    invoke-virtual {v2, v5, p1, p2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->sendUiMessageDelayed(IJ)V

    .line 405
    const/4 v0, 0x1

    .line 407
    :cond_5d
    iput-boolean v4, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mNeedPlayWeatherWallpaperAnimation:Z

    .end local v1    # "wthCtrl":Lcom/htc/clock/util/location/LocationCtrl;
    :cond_5f
    move v2, v0

    .line 409
    goto :goto_42
.end method

.method public uiResetLayout()V
    .registers 1

    .prologue
    .line 468
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->uiUpdate()V

    .line 469
    return-void
.end method

.method public uiStartTodayAnimation()V
    .registers 5

    .prologue
    .line 360
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mParentWidget:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    const v1, 0x8009

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 374
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->flagUseWeatherAnimation:Z

    if-eqz v0, :cond_1d

    .line 375
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mPlayAnimationWhenStartAnimation:Z

    if-eqz v0, :cond_1a

    .line 376
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mParentWidget:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    const v1, 0x8013

    const-wide/16 v2, 0x0

    invoke-virtual {v0, v1, v2, v3}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->sendUiMessageDelayed(IJ)V

    .line 379
    :cond_1a
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mNeedPlayWeatherWallpaperAnimation:Z

    .line 381
    :cond_1d
    return-void
.end method

.method public uiStartWWPAnimation()V
    .registers 10

    .prologue
    .line 424
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mParentWidget:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    const v7, 0x8013

    invoke-virtual {v0, v7}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 425
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->flagUseWeatherAnimation:Z

    if-eqz v0, :cond_12

    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->isPlayingWWP()Z

    move-result v0

    if-eqz v0, :cond_18

    .line 426
    :cond_12
    const-string v0, "uiStartWWPAnimation~ fail"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 455
    :cond_17
    :goto_17
    return-void

    .line 429
    :cond_18
    const/4 v2, -0x1

    .local v2, "icon_x":I
    const/4 v3, -0x1

    .line 430
    .local v3, "icon_y":I
    const/4 v4, -0x1

    .local v4, "icon_w":I
    const/4 v5, -0x1

    .line 431
    .local v5, "icon_h":I
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mImgToday:Lcom/htc/fusion/fx/controls/FxSceneContainer;

    if-eqz v0, :cond_93

    .line 432
    const/4 v0, 0x2

    new-array v6, v0, [I

    .line 433
    .local v6, "location":[I
    iget v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mCellX:I

    .line 434
    iget v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mCellY:I

    .line 440
    .end local v6    # "location":[I
    :goto_27
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "uiStartWWPAnimation~ mDfMode:"

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v7, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mDfMode:I

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v7, " icon_x:"

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v7, " icon_y:"

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v7, " icon_w:"

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v7, " icon_h:"

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 443
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mDfMode:I

    if-lez v0, :cond_17

    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mDfMode:I

    sget-object v7, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mMapToWeatherWallpaper:[I

    array-length v7, v7

    if-gt v0, v7, :cond_17

    .line 444
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mParentWidget:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->buildCache()V

    .line 445
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v7

    iput-wide v7, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mPlayWWPTime:J

    .line 447
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mParentWidget:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getWeatherCtrl()Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v0

    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationCtrl;->getLocConditionId()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    .local v1, "conditionId":I
    move-object v0, p0

    .line 449
    invoke-virtual/range {v0 .. v5}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->requestShowWeatherWallpaper(IIIII)Z

    move-result v0

    if-nez v0, :cond_17

    goto :goto_17

    .line 437
    .end local v1    # "conditionId":I
    :cond_93
    const-string v0, "uiStartWWPAnimation~ mImgToday null"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    goto :goto_27
.end method

.method public uiStopTodayAnimation()V
    .registers 3

    .prologue
    .line 337
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mParentWidget:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    const v1, 0x800a

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 338
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mImgToday:Lcom/htc/fusion/fx/controls/FxSceneContainer;

    if-eqz v0, :cond_11

    .line 339
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mImgToday:Lcom/htc/fusion/fx/controls/FxSceneContainer;

    invoke-virtual {v0}, Lcom/htc/fusion/fx/controls/FxSceneContainer;->stop()V

    .line 341
    :cond_11
    return-void
.end method

.method public uiUpdate()V
    .registers 19

    .prologue
    .line 119
    const-string v15, "weatherView uiUpdate~"

    invoke-static {v15}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 120
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mParentWidget:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    move-object v15, v0

    invoke-virtual {v15}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getWeatherCtrl()Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v14

    .line 121
    .local v14, "weatherCtrl":Lcom/htc/clock/util/location/LocationCtrl;
    const/4 v10, 0x0

    .line 122
    .local v10, "locName":Ljava/lang/String;
    const/4 v12, 0x0

    .line 123
    .local v12, "openResetOption":Z
    const/4 v11, 0x0

    .line 124
    .local v11, "openLocOption":Z
    invoke-virtual {v14}, Lcom/htc/clock/util/location/LocationCtrl;->isLocServiceEnable()Z

    move-result v15

    if-nez v15, :cond_1d

    invoke-virtual {v14}, Lcom/htc/clock/util/location/LocationCtrl;->isWithCurrentLocation()Z

    move-result v15

    if-nez v15, :cond_130

    :cond_1d
    const/4 v15, 0x1

    move v8, v15

    .line 125
    .local v8, "isLocationEnable":Z
    :goto_1f
    invoke-virtual/range {p0 .. p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->isWeatherVisiable()Z

    move-result v15

    if-eqz v15, :cond_167

    .line 127
    invoke-virtual {v14}, Lcom/htc/clock/util/location/LocationCtrl;->getLocName()Ljava/lang/String;

    move-result-object v10

    .line 128
    invoke-virtual {v14}, Lcom/htc/clock/util/location/LocationCtrl;->getLocConditionId()Ljava/lang/String;

    move-result-object v6

    .line 129
    .local v6, "conditionIdStr":Ljava/lang/String;
    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v16, "weather visible, condition id="

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    invoke-static {v15}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 130
    const/4 v5, -0x1

    .line 132
    .local v5, "conditionId":I
    :try_start_44
    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    :try_end_47
    .catch Ljava/lang/Exception; {:try_start_44 .. :try_end_47} :catch_134

    move-result v5

    .line 136
    :goto_48
    if-ltz v5, :cond_138

    .line 137
    invoke-direct/range {p0 .. p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->getWeatherRes()Lcom/htc/weather/StateResources;

    move-result-object v15

    invoke-virtual {v15, v5}, Lcom/htc/weather/StateResources;->getConditionText(I)Ljava/lang/String;

    move-result-object v13

    .line 138
    .local v13, "text":Ljava/lang/String;
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mNoWeatherView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move-object v15, v0

    if-eqz v15, :cond_63

    .line 139
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mNoWeatherView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move-object v15, v0

    const-string v16, ""

    invoke-virtual/range {v15 .. v16}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 141
    :cond_63
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mConditionView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move-object v15, v0

    invoke-virtual {v15, v13}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 142
    move-object/from16 v0, p0

    move v1, v5

    invoke-direct {v0, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->setTodayImage(I)V

    .line 148
    .end local v13    # "text":Ljava/lang/String;
    :goto_71
    invoke-virtual {v14}, Lcom/htc/clock/util/location/LocationCtrl;->getLocTemp()Ljava/lang/String;

    move-result-object v4

    .line 149
    .local v4, "LocTemp":Ljava/lang/String;
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move-object v15, v0

    invoke-virtual {v15, v4}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 150
    invoke-virtual {v14}, Lcom/htc/clock/util/location/LocationCtrl;->getHTemp()Ljava/lang/String;

    move-result-object v2

    .line 151
    .local v2, "HTemp":Ljava/lang/String;
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mHTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move-object v15, v0

    invoke-virtual {v15, v2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 152
    invoke-virtual {v14}, Lcom/htc/clock/util/location/LocationCtrl;->getLTemp()Ljava/lang/String;

    move-result-object v3

    .line 153
    .local v3, "LTemp":Ljava/lang/String;
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mLTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move-object v15, v0

    invoke-virtual {v15, v3}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 154
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v15

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v16

    invoke-static/range {v15 .. v16}, Ljava/lang/Math;->max(II)I

    move-result v9

    .line 155
    .local v9, "length":I
    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v16, "temperature length="

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    invoke-static {v15}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 156
    packed-switch v9, :pswitch_data_200

    .line 168
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mWeatherType:Lcom/htc/fusion/fx/FxTimelineControl;

    move-object v15, v0

    const-string v16, "position_3"

    invoke-virtual/range {v15 .. v16}, Lcom/htc/fusion/fx/FxTimelineControl;->playMarker(Ljava/lang/String;)V

    .line 171
    :goto_c4
    invoke-direct/range {p0 .. p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->setIndicatorText()V

    .line 193
    .end local v2    # "HTemp":Ljava/lang/String;
    .end local v3    # "LTemp":Ljava/lang/String;
    .end local v4    # "LocTemp":Ljava/lang/String;
    .end local v5    # "conditionId":I
    .end local v6    # "conditionIdStr":Ljava/lang/String;
    .end local v9    # "length":I
    :goto_c7
    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v16, "mCityView="

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    const-string v16, ", openLocOption="

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15, v11}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v15

    const-string v16, ", openResetOption="

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15, v12}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    invoke-static {v15}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 195
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mCityView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move-object v15, v0

    invoke-virtual {v15, v10}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 196
    if-eqz v11, :cond_1be

    .line 197
    const/4 v15, 0x0

    move-object/from16 v0, p0

    move v1, v15

    invoke-direct {v0, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->setWeatherViewVisibility(Z)V

    .line 198
    const/4 v15, 0x1

    move-object/from16 v0, p0

    move v1, v15

    invoke-direct {v0, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->setLocationInfoVisibility(Z)V

    .line 199
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mCityRestText:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move-object v15, v0

    if-eqz v15, :cond_129

    .line 200
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mCityRestText:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move-object v15, v0

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mContext:Landroid/content/Context;

    move-object/from16 v16, v0

    invoke-virtual/range {v16 .. v16}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v16

    const v17, 0x7f060018

    invoke-virtual/range {v16 .. v17}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v16

    invoke-virtual/range {v15 .. v16}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 215
    :cond_129
    :goto_129
    const/4 v15, 0x0

    move v0, v15

    move-object/from16 v1, p0

    iput-boolean v0, v1, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mBNeedToUpdate:Z

    .line 216
    return-void

    .line 124
    .end local v8    # "isLocationEnable":Z
    :cond_130
    const/4 v15, 0x0

    move v8, v15

    goto/16 :goto_1f

    .line 133
    .restart local v5    # "conditionId":I
    .restart local v6    # "conditionIdStr":Ljava/lang/String;
    .restart local v8    # "isLocationEnable":Z
    :catch_134
    move-exception v7

    .line 134
    .local v7, "e":Ljava/lang/Exception;
    const/4 v5, -0x1

    goto/16 :goto_48

    .line 144
    .end local v7    # "e":Ljava/lang/Exception;
    :cond_138
    const/4 v15, -0x1

    move v0, v15

    move-object/from16 v1, p0

    iput v0, v1, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mPreviousResId:I

    .line 145
    invoke-direct/range {p0 .. p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->showDataError()V

    goto/16 :goto_71

    .line 159
    .restart local v2    # "HTemp":Ljava/lang/String;
    .restart local v3    # "LTemp":Ljava/lang/String;
    .restart local v4    # "LocTemp":Ljava/lang/String;
    .restart local v9    # "length":I
    :pswitch_143
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mWeatherType:Lcom/htc/fusion/fx/FxTimelineControl;

    move-object v15, v0

    const-string v16, "position_1"

    invoke-virtual/range {v15 .. v16}, Lcom/htc/fusion/fx/FxTimelineControl;->playMarker(Ljava/lang/String;)V

    goto/16 :goto_c4

    .line 162
    :pswitch_14f
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mWeatherType:Lcom/htc/fusion/fx/FxTimelineControl;

    move-object v15, v0

    const-string v16, "position_2"

    invoke-virtual/range {v15 .. v16}, Lcom/htc/fusion/fx/FxTimelineControl;->playMarker(Ljava/lang/String;)V

    goto/16 :goto_c4

    .line 165
    :pswitch_15b
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mWeatherType:Lcom/htc/fusion/fx/FxTimelineControl;

    move-object v15, v0

    const-string v16, "position_3"

    invoke-virtual/range {v15 .. v16}, Lcom/htc/fusion/fx/FxTimelineControl;->playMarker(Ljava/lang/String;)V

    goto/16 :goto_c4

    .line 174
    .end local v2    # "HTemp":Ljava/lang/String;
    .end local v3    # "LTemp":Ljava/lang/String;
    .end local v4    # "LocTemp":Ljava/lang/String;
    .end local v5    # "conditionId":I
    .end local v6    # "conditionIdStr":Ljava/lang/String;
    .end local v9    # "length":I
    :cond_167
    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string v16, "weather not visible,LocState="

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v14}, Lcom/htc/clock/util/location/LocationCtrl;->getLocState()Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    move-result-object v16

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    invoke-static {v15}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 175
    sget-object v15, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->NO_DATA:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    invoke-virtual {v14}, Lcom/htc/clock/util/location/LocationCtrl;->getLocState()Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    move-result-object v16

    move-object v0, v15

    move-object/from16 v1, v16

    if-eq v0, v1, :cond_18e

    if-nez v8, :cond_1b9

    .line 177
    :cond_18e
    if-nez v8, :cond_19e

    .line 178
    const-string v10, ""

    .line 179
    const/4 v11, 0x1

    .line 190
    :goto_193
    const/4 v15, -0x1

    move v0, v15

    move-object/from16 v1, p0

    iput v0, v1, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mPreviousResId:I

    .line 191
    invoke-direct/range {p0 .. p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->showDataError()V

    goto/16 :goto_c7

    .line 180
    :cond_19e
    invoke-virtual {v14}, Lcom/htc/clock/util/location/LocationCtrl;->isLocServiceAvailable()Z

    move-result v15

    if-nez v15, :cond_1a8

    .line 181
    const-string v10, ""

    .line 182
    const/4 v12, 0x1

    goto :goto_193

    .line 184
    :cond_1a8
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mContext:Landroid/content/Context;

    move-object v15, v0

    invoke-virtual {v15}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v15

    const v16, 0x7f060017

    invoke-virtual/range {v15 .. v16}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v10

    goto :goto_193

    .line 188
    :cond_1b9
    invoke-virtual {v14}, Lcom/htc/clock/util/location/LocationCtrl;->getLocName()Ljava/lang/String;

    move-result-object v10

    goto :goto_193

    .line 203
    :cond_1be
    if-eqz v12, :cond_1f0

    .line 204
    const/4 v15, 0x0

    move-object/from16 v0, p0

    move v1, v15

    invoke-direct {v0, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->setWeatherViewVisibility(Z)V

    .line 205
    const/4 v15, 0x1

    move-object/from16 v0, p0

    move v1, v15

    invoke-direct {v0, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->setLocationInfoVisibility(Z)V

    .line 206
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mCityRestText:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move-object v15, v0

    if-eqz v15, :cond_129

    .line 207
    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mCityRestText:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move-object v15, v0

    move-object/from16 v0, p0

    iget-object v0, v0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mContext:Landroid/content/Context;

    move-object/from16 v16, v0

    invoke-virtual/range {v16 .. v16}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v16

    const v17, 0x7f06001d

    invoke-virtual/range {v16 .. v17}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v16

    invoke-virtual/range {v15 .. v16}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    goto/16 :goto_129

    .line 211
    :cond_1f0
    const/4 v15, 0x1

    move-object/from16 v0, p0

    move v1, v15

    invoke-direct {v0, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->setWeatherViewVisibility(Z)V

    .line 212
    const/4 v15, 0x0

    move-object/from16 v0, p0

    move v1, v15

    invoke-direct {v0, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->setLocationInfoVisibility(Z)V

    goto/16 :goto_129

    .line 156
    :pswitch_data_200
    .packed-switch 0x1
        :pswitch_143
        :pswitch_143
        :pswitch_14f
        :pswitch_15b
    .end packed-switch
.end method

.method public uiUpdateTempUnit()V
    .registers 4

    .prologue
    .line 281
    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mBNeedUpdateTemp:Z

    .line 282
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mParentWidget:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getWeatherCtrl()Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v0

    .line 283
    .local v0, "weatherCtrl":Lcom/htc/clock/util/location/LocationCtrl;
    sget-object v1, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->OK:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationCtrl;->getLocState()Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    move-result-object v2

    if-ne v1, v2, :cond_2f

    .line 285
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationCtrl;->getLocTemp()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 286
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mHTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationCtrl;->getHTemp()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 287
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mLTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationCtrl;->getLTemp()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 288
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->setIndicatorText()V

    .line 291
    :cond_2f
    return-void
.end method

.method public update()V
    .registers 6

    .prologue
    const/4 v3, 0x1

    .line 90
    const-string v1, "weatherView update~"

    invoke-static {v1}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 91
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mBNeedToUpdate:Z

    .line 92
    iget-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->flagUseWeatherAnimation:Z

    if-eqz v1, :cond_36

    .line 94
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mParentWidget:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getWeatherCtrl()Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v0

    .line 95
    .local v0, "weatherCtrl":Lcom/htc/clock/util/location/LocationCtrl;
    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationCtrl;->getLocConditionIdInt()I

    move-result v1

    iput v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mDfMode:I

    .line 96
    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mDfMode:I

    if-lez v1, :cond_2c

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mDfMode:I

    sget-object v2, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mMapToWeatherWallpaper:[I

    array-length v2, v2

    if-gt v1, v2, :cond_2c

    .line 97
    sget-object v1, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mMapToWeatherWallpaper:[I

    iget v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mDfMode:I

    sub-int/2addr v2, v3

    aget v1, v1, v2

    iput v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mMode:I

    .line 98
    :cond_2c
    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mPreviousMode:I

    iget v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mMode:I

    if-eq v1, v2, :cond_36

    .line 99
    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mMode:I

    iput v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mPreviousMode:I

    .line 102
    .end local v0    # "weatherCtrl":Lcom/htc/clock/util/location/LocationCtrl;
    :cond_36
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mParentWidget:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    const v2, 0x8014

    const-wide/16 v3, 0x0

    invoke-virtual {v1, v2, v3, v4}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->sendUiMessageDelayed(IJ)V

    .line 103
    return-void
.end method

.method public updateTempUnit()V
    .registers 5

    .prologue
    .line 276
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mBNeedUpdateTemp:Z

    .line 277
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mParentWidget:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    const v1, 0x8014

    const-wide/16 v2, 0x0

    invoke-virtual {v0, v1, v2, v3}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->sendUiMessageDelayed(IJ)V

    .line 278
    return-void
.end method
