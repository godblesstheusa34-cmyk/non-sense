.class public Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;
.super Lcom/htc/android/rosie/widget/Widget$Base;
.source "WeatherClockWidgetView.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$DbChangeObserver;,
        Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;
    }
.end annotation


# static fields
.field static final ACTION_HIDE_WEATHER_WALLPAPER:Ljava/lang/String; = "com.htc.weatherwallpaper.service.intent.action.HIDE_WEATHER_WALLPAPER"

.field static final ACTION_SHOW_WEATHER_WALLPAPER:Ljava/lang/String; = "com.htc.weatherwallpaper.service.intent.action.SHOW_WEATHER_WALLPAPER"

.field public static final DEF_CITY:Ljava/lang/String; = "defCityCode_"

.field public static final TAG:Ljava/lang/String; = "WeatherClockWidget"

.field private static mbPlayWWPAtRosieStart:Z


# instance fields
.field private mApplication:Landroid/content/Context;

.field private mBChangeTimeZone:Z

.field private mBackIntent:Landroid/content/Intent;

.field private mBoolAppDestroy:Z

.field private mBoolAppResume:Z

.field private mClockClickListener:Landroid/view/View$OnClickListener;

.field private mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

.field private mContentResolver:Landroid/content/ContentResolver;

.field private mFormatChangeObserver:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$DbChangeObserver;

.field private mFxControlsLand:Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;

.field private mFxControlsPort:Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;

.field private mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

.field private mInitCreate:Z

.field private mInitLock:Ljava/lang/Object;

.field private mInitPause:Z

.field private mInitResume:Z

.field private mLastResumeTime:J

.field private mLastUnLockTime:J

.field private mLock:Ljava/lang/Object;

.field private mLockScreenRec:Landroid/content/BroadcastReceiver;

.field private mLongClick:Z

.field private mLongClickListener:Landroid/view/View$OnLongClickListener;

.field private mOrientation:I

.field mPauseByAddToHome:Z

.field private mResContext:Landroid/content/Context;

.field private mResumeNotifyCaused:J

.field private mSceneLand:Lcom/htc/fusion/fx/FxScene;

.field private mScenePort:Lcom/htc/fusion/fx/FxScene;

.field private mSecureChangeObserver:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$DbChangeObserver;

.field private mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

.field private mUiState:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;

.field private mUiWorker:Landroid/os/Handler$Callback;

.field private mViewContext:Landroid/content/Context;

.field private mWeatherClockClick:Landroid/view/View$OnClickListener;

.field private mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

.field private mWeatherListener:Lcom/htc/clock/util/location/LocationListener;

.field private mWeatherPress:Landroid/view/View;

.field private mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

.field mWidgetId:I

.field private mWorker:Landroid/os/Handler$Callback;

.field private m_bPlayingWWP:Z

.field private m_floatView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

.field private mbPlayWWPAtAdd:Z

.field private uiView:Landroid/view/View;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .prologue
    .line 197
    const/4 v0, 0x1

    sput-boolean v0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mbPlayWWPAtRosieStart:Z

    return-void
.end method

.method public constructor <init>()V
    .registers 6

    .prologue
    const-wide/16 v3, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x0

    .line 49
    invoke-direct {p0}, Lcom/htc/android/rosie/widget/Widget$Base;-><init>()V

    .line 52
    iput v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWidgetId:I

    .line 58
    const/4 v0, 0x1

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mOrientation:I

    .line 61
    iput-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mInitCreate:Z

    .line 62
    iput-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mInitResume:Z

    .line 63
    iput-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mInitPause:Z

    .line 64
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mInitLock:Ljava/lang/Object;

    .line 65
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mLock:Ljava/lang/Object;

    .line 185
    iput-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBChangeTimeZone:Z

    .line 186
    iput-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBoolAppResume:Z

    .line 187
    iput-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBoolAppDestroy:Z

    .line 188
    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBackIntent:Landroid/content/Intent;

    .line 191
    iput-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mLongClick:Z

    .line 196
    iput-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mbPlayWWPAtAdd:Z

    .line 198
    sget-object v0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;->NONE:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiState:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;

    .line 200
    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mContentResolver:Landroid/content/ContentResolver;

    .line 221
    new-instance v0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$1;

    invoke-direct {v0, p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$1;-><init>(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)V

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockClickListener:Landroid/view/View$OnClickListener;

    .line 227
    new-instance v0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$2;

    invoke-direct {v0, p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$2;-><init>(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)V

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherClockClick:Landroid/view/View$OnClickListener;

    .line 767
    iput-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mPauseByAddToHome:Z

    .line 810
    new-instance v0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;

    invoke-direct {v0, p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;-><init>(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)V

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWorker:Landroid/os/Handler$Callback;

    .line 998
    new-instance v0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;

    invoke-direct {v0, p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;-><init>(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)V

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiWorker:Landroid/os/Handler$Callback;

    .line 1093
    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->m_floatView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    .line 1232
    iput-wide v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mResumeNotifyCaused:J

    .line 1233
    iput-wide v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mLastUnLockTime:J

    .line 1234
    iput-wide v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mLastResumeTime:J

    .line 1264
    iput-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->m_bPlayingWWP:Z

    .line 1336
    new-instance v0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$5;

    invoke-direct {v0, p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$5;-><init>(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)V

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mLongClickListener:Landroid/view/View$OnLongClickListener;

    .line 1348
    new-instance v0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$6;

    invoke-direct {v0, p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$6;-><init>(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)V

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherListener:Lcom/htc/clock/util/location/LocationListener;

    .line 1384
    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mFormatChangeObserver:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$DbChangeObserver;

    .line 1385
    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mSecureChangeObserver:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$DbChangeObserver;

    .line 1407
    return-void
.end method

.method static synthetic access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    .prologue
    .line 49
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    return-object v0
.end method

.method static synthetic access$100(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    .prologue
    .line 49
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    return-object v0
.end method

.method static synthetic access$1000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Z
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    .prologue
    .line 49
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mLongClick:Z

    return v0
.end method

.method static synthetic access$1002(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Z)Z
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;
    .param p1, "x1"    # Z

    .prologue
    .line 49
    iput-boolean p1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mLongClick:Z

    return p1
.end method

.method static synthetic access$1100(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Z
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    .prologue
    .line 49
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->checkToPlayWWP()Z

    move-result v0

    return v0
.end method

.method static synthetic access$1200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)V
    .registers 1
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    .prologue
    .line 49
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->stateToLog()V

    return-void
.end method

.method static synthetic access$1300(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;I)V
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;
    .param p1, "x1"    # I

    .prologue
    .line 49
    invoke-direct {p0, p1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->myOnNotifyWidgetPause(I)V

    return-void
.end method

.method static synthetic access$1400(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)V
    .registers 1
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    .prologue
    .line 49
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->initData()V

    return-void
.end method

.method static synthetic access$1500(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)V
    .registers 1
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    .prologue
    .line 49
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->playWWPAtFirstTime()V

    return-void
.end method

.method static synthetic access$1600(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Z
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    .prologue
    .line 49
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBChangeTimeZone:Z

    return v0
.end method

.method static synthetic access$1602(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Z)Z
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;
    .param p1, "x1"    # Z

    .prologue
    .line 49
    iput-boolean p1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBChangeTimeZone:Z

    return p1
.end method

.method static synthetic access$1700(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)V
    .registers 1
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    .prologue
    .line 49
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->doConfigurationChanged()V

    return-void
.end method

.method static synthetic access$1800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Landroid/content/Context;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    .prologue
    .line 49
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mApplication:Landroid/content/Context;

    return-object v0
.end method

.method static synthetic access$1900(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Ljava/lang/String;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    .prologue
    .line 49
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getCityCode()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method static synthetic access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    .prologue
    .line 49
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    return-object v0
.end method

.method static synthetic access$2000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)V
    .registers 1
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    .prologue
    .line 49
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->launchWeatherClockAp()V

    return-void
.end method

.method static synthetic access$2100(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Landroid/content/Intent;)V
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;
    .param p1, "x1"    # Landroid/content/Intent;

    .prologue
    .line 49
    invoke-direct {p0, p1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->doActivityResult(Landroid/content/Intent;)V

    return-void
.end method

.method static synthetic access$2200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)[I
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    .prologue
    .line 49
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getPosition()[I

    move-result-object v0

    return-object v0
.end method

.method static synthetic access$2302(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Z)Z
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;
    .param p1, "x1"    # Z

    .prologue
    .line 49
    iput-boolean p1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mbPlayWWPAtAdd:Z

    return p1
.end method

.method static synthetic access$2402(Z)Z
    .registers 1
    .param p0, "x0"    # Z

    .prologue
    .line 49
    sput-boolean p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mbPlayWWPAtRosieStart:Z

    return p0
.end method

.method static synthetic access$2500(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;ZLandroid/content/Intent;)V
    .registers 3
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;
    .param p1, "x1"    # Z
    .param p2, "x2"    # Landroid/content/Intent;

    .prologue
    .line 49
    invoke-direct {p0, p1, p2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->switchToNewCity(ZLandroid/content/Intent;)V

    return-void
.end method

.method static synthetic access$2600(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Landroid/view/View;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    .prologue
    .line 49
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->uiView:Landroid/view/View;

    return-object v0
.end method

.method static synthetic access$2700(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Z
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    .prologue
    .line 49
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBoolAppDestroy:Z

    return v0
.end method

.method static synthetic access$2800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Landroid/content/Context;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    .prologue
    .line 49
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mResContext:Landroid/content/Context;

    return-object v0
.end method

.method static synthetic access$302(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Z)Z
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;
    .param p1, "x1"    # Z

    .prologue
    .line 49
    iput-boolean p1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->m_bPlayingWWP:Z

    return p1
.end method

.method static synthetic access$402(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;)Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;
    .param p1, "x1"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;

    .prologue
    .line 49
    iput-object p1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiState:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;

    return-object p1
.end method

.method static synthetic access$502(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;J)J
    .registers 3
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;
    .param p1, "x1"    # J

    .prologue
    .line 49
    iput-wide p1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mResumeNotifyCaused:J

    return-wide p1
.end method

.method static synthetic access$602(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;J)J
    .registers 3
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;
    .param p1, "x1"    # J

    .prologue
    .line 49
    iput-wide p1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mLastResumeTime:J

    return-wide p1
.end method

.method static synthetic access$700(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Z
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    .prologue
    .line 49
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBoolAppResume:Z

    return v0
.end method

.method static synthetic access$702(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Z)Z
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;
    .param p1, "x1"    # Z

    .prologue
    .line 49
    iput-boolean p1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBoolAppResume:Z

    return p1
.end method

.method static synthetic access$800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationCtrl;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    .prologue
    .line 49
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    return-object v0
.end method

.method static synthetic access$900(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationListener;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    .prologue
    .line 49
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherListener:Lcom/htc/clock/util/location/LocationListener;

    return-object v0
.end method

.method private checkToPlayWWP()Z
    .registers 14

    .prologue
    const-wide/16 v11, 0x0

    const/4 v10, 0x0

    .line 1267
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->isWidgetOnResume()Z

    move-result v6

    if-eqz v6, :cond_17

    iget-wide v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mResumeNotifyCaused:J

    const-wide/16 v8, 0x1e

    cmp-long v6, v6, v8

    if-nez v6, :cond_17

    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiState:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;

    sget-object v7, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;->RESUME_DELAY:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;

    if-eq v6, v7, :cond_4b

    .line 1270
    :cond_17
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "checkToPlayWWP~ isWidgetOnResume:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->isWidgetOnResume()Z

    move-result v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " mResumeNotifyCaused:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget-wide v7, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mResumeNotifyCaused:J

    invoke-virtual {v6, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v6

    const-string v7, " mUiState:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget-object v7, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiState:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    move v6, v10

    .line 1295
    :goto_4a
    return v6

    .line 1275
    :cond_4b
    const-wide/16 v4, 0x1f4

    .line 1276
    .local v4, "timeThreshold":J
    const-wide/16 v2, 0x514

    .line 1277
    .local v2, "needDelayTime":J
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    if-eqz v6, :cond_5b

    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    iget-boolean v6, v6, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->mUseAnimation:Z

    if-nez v6, :cond_5b

    .line 1278
    const-wide/16 v2, 0x258

    .line 1281
    :cond_5b
    iget-boolean v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->m_bPlayingWWP:Z

    if-eqz v6, :cond_8a

    .line 1283
    move-wide v0, v2

    .line 1284
    .local v0, "delayTime":J
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v6

    iget-wide v8, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mLastResumeTime:J

    sub-long/2addr v6, v8

    sub-long/2addr v0, v6

    .line 1286
    cmp-long v6, v0, v2

    if-lez v6, :cond_8c

    .line 1287
    move-wide v0, v2

    .line 1291
    :cond_6d
    :goto_6d
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "checkToPlayWWP~ delayTime:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 1292
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v6, v11, v12}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->startWWPAnimation(J)Z

    .line 1293
    iput-boolean v10, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->m_bPlayingWWP:Z

    .end local v0    # "delayTime":J
    :cond_8a
    move v6, v10

    .line 1295
    goto :goto_4a

    .line 1288
    .restart local v0    # "delayTime":J
    :cond_8c
    cmp-long v6, v0, v11

    if-gez v6, :cond_6d

    .line 1289
    const-wide/16 v0, 0x0

    goto :goto_6d
.end method

.method private clear()V
    .registers 4

    .prologue
    .line 532
    monitor-enter p0

    .line 533
    :try_start_1
    const-string v0, "weather clock clear~"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 534
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->unInitReceiver()V

    .line 535
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    if-eqz v0, :cond_1b

    .line 536
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mFxControlsPort:Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;

    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mFxControlsLand:Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;

    invoke-virtual {v0, v1, v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->unbind(Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;)V

    .line 537
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->deInit()V

    .line 540
    :cond_1b
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    if-eqz v0, :cond_24

    .line 541
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationCtrl;->unRegister()V

    .line 543
    :cond_24
    monitor-exit p0

    .line 544
    return-void

    .line 543
    :catchall_26
    move-exception v0

    monitor-exit p0
    :try_end_28
    .catchall {:try_start_1 .. :try_end_28} :catchall_26

    throw v0
.end method

.method private correctResourcesLocale()V
    .registers 6

    .prologue
    .line 548
    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object v2

    .line 549
    .local v2, "res":Landroid/content/res/Resources;
    if-nez v2, :cond_c

    .line 550
    const-string v4, "Resources.getSystem() is null"

    invoke-static {v4}, Lcom/htc/clock/util/MyLog;->w(Ljava/lang/String;)V

    .line 572
    :cond_b
    :goto_b
    return-void

    .line 553
    :cond_c
    invoke-virtual {v2}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v4

    iget-object v4, v4, Landroid/content/res/Configuration;->locale:Ljava/util/Locale;

    invoke-virtual {v4}, Ljava/util/Locale;->getISO3Language()Ljava/lang/String;

    move-result-object v3

    .line 556
    .local v3, "resISO3Language":Ljava/lang/String;
    invoke-virtual {v2}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    .line 557
    .local v0, "config":Landroid/content/res/Configuration;
    if-nez v0, :cond_22

    .line 558
    const-string v4, "res.getConfiguration() is null"

    invoke-static {v4}, Lcom/htc/clock/util/MyLog;->w(Ljava/lang/String;)V

    goto :goto_b

    .line 561
    :cond_22
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v4

    invoke-virtual {v4}, Ljava/util/Locale;->getISO3Language()Ljava/lang/String;

    move-result-object v1

    .line 563
    .local v1, "currentISO3Language":Ljava/lang/String;
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_b

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_b

    .line 568
    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_b

    .line 569
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v4

    iput-object v4, v0, Landroid/content/res/Configuration;->locale:Ljava/util/Locale;

    .line 570
    const/4 v4, 0x0

    invoke-static {v0, v4}, Landroid/content/res/Resources;->updateSystemConfiguration(Landroid/content/res/Configuration;Landroid/util/DisplayMetrics;)V

    goto :goto_b
.end method

.method private doActivityResult(Landroid/content/Intent;)V
    .registers 5
    .param p1, "data"    # Landroid/content/Intent;

    .prologue
    .line 344
    if-nez p1, :cond_3

    .line 352
    :goto_2
    return-void

    .line 347
    :cond_3
    const-string v1, "currentLocation"

    const/4 v2, 0x0

    invoke-virtual {p1, v1, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v0

    .line 349
    .local v0, "bCurLocation":Z
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mbPlayWWPAtAdd:Z

    .line 350
    invoke-direct {p0, v0, p1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->switchToNewCity(ZLandroid/content/Intent;)V

    .line 351
    invoke-direct {p0, p1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->savePropertyData(Landroid/content/Intent;)V

    goto :goto_2
.end method

.method private doConfigurationChanged()V
    .registers 4

    .prologue
    .line 1510
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mFxControlsPort:Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;

    if-eqz v0, :cond_c

    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mFxControlsLand:Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;

    if-eqz v0, :cond_c

    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    if-nez v0, :cond_d

    .line 1516
    :cond_c
    :goto_c
    return-void

    .line 1512
    :cond_d
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mOrientation:I

    const/4 v2, 0x1

    if-ne v1, v2, :cond_2c

    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mFxControlsPort:Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;

    :goto_16
    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->init(Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;)V

    .line 1513
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    const/4 v1, -0x1

    iput v1, v0, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->mPreviousResId:I

    .line 1514
    const v0, 0x8020

    const-wide/16 v1, 0x0

    invoke-virtual {p0, v0, v1, v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->sendUiMessageDelayed(IJ)V

    .line 1515
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->update()V

    goto :goto_c

    .line 1512
    :cond_2c
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mFxControlsLand:Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;

    goto :goto_16
.end method

.method private doPause()V
    .registers 3

    .prologue
    .line 162
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removePauseMessage()V

    .line 164
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->obtainMessage()Landroid/os/Message;

    move-result-object v0

    .line 165
    .local v0, "msg":Landroid/os/Message;
    const/4 v1, 0x2

    iput v1, v0, Landroid/os/Message;->what:I

    .line 166
    const/16 v1, 0x1e

    iput v1, v0, Landroid/os/Message;->arg1:I

    .line 167
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v1, v0}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->send(Landroid/os/Message;)V

    .line 168
    return-void
.end method

.method private doResume()V
    .registers 3

    .prologue
    .line 126
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeResumeMessage()V

    .line 128
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->obtainMessage()Landroid/os/Message;

    move-result-object v0

    .line 129
    .local v0, "msg":Landroid/os/Message;
    const/4 v1, 0x1

    iput v1, v0, Landroid/os/Message;->what:I

    .line 130
    const/16 v1, 0x1e

    iput v1, v0, Landroid/os/Message;->arg1:I

    .line 131
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v1, v0}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->send(Landroid/os/Message;)V

    .line 132
    return-void
.end method

.method private doResumeInKeyguard()V
    .registers 3

    .prologue
    .line 405
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->obtainMessage()Landroid/os/Message;

    move-result-object v0

    .line 406
    .local v0, "msg":Landroid/os/Message;
    const v1, 0x9015

    iput v1, v0, Landroid/os/Message;->what:I

    .line 407
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v1, v0}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->send(Landroid/os/Message;)V

    .line 408
    return-void
.end method

.method private getCityCode()Ljava/lang/String;
    .registers 4

    .prologue
    .line 254
    const/4 v0, 0x0

    .line 256
    .local v0, "cityCode":Ljava/lang/String;
    :try_start_1
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v2}, Lcom/htc/clock/util/location/LocationCtrl;->getWeatherLocation()Lcom/htc/util/weather/WeatherLocation;

    move-result-object v2

    invoke-virtual {v2}, Lcom/htc/util/weather/WeatherLocation;->getCode()Ljava/lang/String;
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_a} :catch_c

    move-result-object v0

    .line 260
    :goto_b
    return-object v0

    .line 257
    :catch_c
    move-exception v2

    move-object v1, v2

    .line 258
    .local v1, "e":Ljava/lang/Exception;
    const-string v2, "get city code fail"

    invoke-static {v2}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    goto :goto_b
.end method

.method private getLocationFromCode(Ljava/lang/String;)Lcom/htc/util/weather/WeatherLocation;
    .registers 5
    .param p1, "code"    # Ljava/lang/String;

    .prologue
    .line 676
    const/4 v0, 0x0

    .line 677
    .local v0, "loc":Lcom/htc/util/weather/WeatherLocation;
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mApplication:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    invoke-static {v2, p1}, Lcom/htc/util/weather/WeatherUtility;->getLocationListByCode(Landroid/content/ContentResolver;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    .line 679
    .local v1, "locationListCursor":Landroid/database/Cursor;
    if-eqz v1, :cond_20

    .line 680
    invoke-interface {v1}, Landroid/database/Cursor;->getCount()I

    move-result v2

    if-lez v2, :cond_1d

    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v2

    if-eqz v2, :cond_1d

    .line 682
    invoke-static {v1}, Lcom/htc/util/weather/WeatherUtility;->CursorToWeatherLocation(Landroid/database/Cursor;)Lcom/htc/util/weather/WeatherLocation;

    move-result-object v0

    .line 685
    :cond_1d
    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    .line 687
    :cond_20
    return-object v0
.end method

.method private getLocationFromIntent(Landroid/content/Intent;)Lcom/htc/util/weather/WeatherLocation;
    .registers 6
    .param p1, "intent"    # Landroid/content/Intent;

    .prologue
    .line 660
    new-instance v1, Lcom/htc/util/weather/WeatherLocation;

    invoke-direct {v1}, Lcom/htc/util/weather/WeatherLocation;-><init>()V

    .line 662
    .local v1, "loc":Lcom/htc/util/weather/WeatherLocation;
    const-string v2, "code_"

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 663
    .local v0, "code":Ljava/lang/String;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Code:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/htc/clock/util/MyLog;->d(Ljava/lang/String;)V

    .line 664
    invoke-virtual {v1, v0}, Lcom/htc/util/weather/WeatherLocation;->setCode(Ljava/lang/String;)V

    .line 665
    const-string v2, "name_"

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/htc/util/weather/WeatherLocation;->setName(Ljava/lang/String;)V

    .line 666
    const-string v2, "timezone_"

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/htc/util/weather/WeatherLocation;->setTimezoneId(Ljava/lang/String;)V

    .line 667
    const-string v2, "state_"

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/htc/util/weather/WeatherLocation;->setState(Ljava/lang/String;)V

    .line 668
    const-string v2, "country_"

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/htc/util/weather/WeatherLocation;->setCountry(Ljava/lang/String;)V

    .line 669
    const-string v2, "app_"

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/htc/util/weather/WeatherLocation;->setApp(Ljava/lang/String;)V

    .line 670
    const-string v2, "latitude_"

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/htc/util/weather/WeatherLocation;->setLatitude(Ljava/lang/String;)V

    .line 671
    const-string v2, "longitude_"

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/htc/util/weather/WeatherLocation;->setLongitude(Ljava/lang/String;)V

    .line 672
    return-object v1
.end method

.method private hasNonUiMessage(I)Z
    .registers 3
    .param p1, "what"    # I

    .prologue
    .line 1178
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    if-eqz v0, :cond_b

    .line 1179
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, p1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->hasMessage(I)Z

    move-result v0

    .line 1181
    :goto_a
    return v0

    :cond_b
    const/4 v0, 0x0

    goto :goto_a
.end method

.method private initClock()V
    .registers 6

    .prologue
    .line 694
    const/4 v1, 0x0

    .line 695
    .local v1, "timezone":Ljava/lang/String;
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBackIntent:Landroid/content/Intent;

    if-eqz v2, :cond_20

    .line 696
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBackIntent:Landroid/content/Intent;

    const-string v3, "currentLocation"

    const/4 v4, 0x0

    invoke-virtual {v2, v3, v4}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v2

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    .line 698
    .local v0, "isCurrentLocation":Ljava/lang/Boolean;
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-nez v2, :cond_20

    .line 699
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBackIntent:Landroid/content/Intent;

    const-string v3, "timezone_"

    invoke-virtual {v2, v3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 702
    .end local v0    # "isCurrentLocation":Ljava/lang/Boolean;
    :cond_20
    invoke-direct {p0, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->initClock(Ljava/lang/String;)V

    .line 703
    return-void
.end method

.method private initClock(Ljava/lang/String;)V
    .registers 4
    .param p1, "timezone"    # Ljava/lang/String;

    .prologue
    .line 706
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "initClock~ timezone:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 708
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    .line 709
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    if-eqz v0, :cond_31

    .line 710
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v0, p1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->setTimeZone(Ljava/lang/String;)V

    .line 711
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->onTimeChanged(Z)V

    .line 712
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockClickListener:Landroid/view/View$OnClickListener;

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->setOnClockClickListener(Landroid/view/View$OnClickListener;)V

    .line 716
    :goto_30
    return-void

    .line 714
    :cond_31
    const-string v0, "initClock~ mClockView is null"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    goto :goto_30
.end method

.method private initData()V
    .registers 3

    .prologue
    .line 581
    const-string v1, "initData~"

    invoke-static {v1}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 582
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->correctResourcesLocale()V

    .line 584
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->loadInstanceData()Ljava/util/Properties;

    move-result-object v0

    .line 585
    .local v0, "props":Ljava/util/Properties;
    if-nez v0, :cond_2c

    .line 586
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mbPlayWWPAtAdd:Z

    .line 587
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBackIntent:Landroid/content/Intent;

    invoke-direct {p0, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->savePropertyData(Landroid/content/Intent;)V

    .line 591
    :goto_16
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->initAnimation()V

    .line 592
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->initReceiver()V

    .line 593
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->updateFormat()V

    .line 594
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->checkSystemAutoSynTimezone()V

    .line 595
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->checkClockTimeZone()V

    .line 597
    return-void

    .line 589
    :cond_2c
    invoke-direct {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->loadPropertyData(Ljava/util/Properties;)V

    goto :goto_16
.end method

.method private initReceiver()V
    .registers 1

    .prologue
    .line 1237
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->registerFormatObserver()V

    .line 1238
    return-void
.end method

.method private launchWeatherAp()V
    .registers 15

    .prologue
    const/4 v12, 0x0

    const-string v13, "com.htc.elroy.Weather"

    .line 264
    new-instance v5, Landroid/content/Intent;

    const-string v10, "com.htc.Weather.intent.action.LOCATE"

    invoke-direct {v5, v10}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 265
    .local v5, "intent":Landroid/content/Intent;
    if-eqz v5, :cond_101

    .line 266
    const-string v10, "com.htc.Weather"

    const-string v11, "com.htc.Weather.WeatherActivity"

    invoke-virtual {v5, v10, v11}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 269
    iget-object v10, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v10}, Lcom/htc/clock/util/location/LocationCtrl;->getWeatherLocation()Lcom/htc/util/weather/WeatherLocation;

    move-result-object v9

    .line 270
    .local v9, "weatherLoc":Lcom/htc/util/weather/WeatherLocation;
    if-eqz v9, :cond_80

    .line 271
    invoke-static {v9}, Lcom/htc/clock/util/location/LocationCtrl;->getWeatheApCityName(Lcom/htc/util/weather/WeatherLocation;)Ljava/lang/String;

    move-result-object v1

    .line 272
    .local v1, "cityName":Ljava/lang/String;
    const-string v10, "name_"

    invoke-virtual {v5, v10, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 273
    const-string v10, "code_"

    invoke-virtual {v9}, Lcom/htc/util/weather/WeatherLocation;->getCode()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v5, v10, v11}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 274
    const-string v10, "app_"

    invoke-virtual {v9}, Lcom/htc/util/weather/WeatherLocation;->getApp()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v5, v10, v11}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 276
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "launchWeatherAp~ name_:"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 277
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "launchWeatherAp~ code_:"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v9}, Lcom/htc/util/weather/WeatherLocation;->getCode()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 278
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "launchWeatherAp~ app_:"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v9}, Lcom/htc/util/weather/WeatherLocation;->getApp()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 280
    .end local v1    # "cityName":Ljava/lang/String;
    :cond_80
    iget-object v10, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v10}, Lcom/htc/clock/util/location/LocationCtrl;->isCurrentLocation()Z

    move-result v10

    if-nez v10, :cond_f2

    .line 281
    iget-object v10, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mViewContext:Landroid/content/Context;

    invoke-virtual {v10}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v10

    const-string v11, "com.htc.elroy.Weather"

    invoke-static {v10, v13}, Lcom/htc/util/weather/WeatherUtility;->loadLocations(Landroid/content/ContentResolver;Ljava/lang/String;)[Lcom/htc/util/weather/WeatherLocation;

    move-result-object v8

    .line 284
    .local v8, "locs":[Lcom/htc/util/weather/WeatherLocation;
    const/4 v4, 0x0

    .line 285
    .local v4, "inList":Z
    move-object v0, v8

    .local v0, "arr$":[Lcom/htc/util/weather/WeatherLocation;
    array-length v7, v0

    .local v7, "len$":I
    const/4 v3, 0x0

    .local v3, "i$":I
    :goto_98
    if-ge v3, v7, :cond_ab

    aget-object v6, v0, v3

    .line 286
    .local v6, "l":Lcom/htc/util/weather/WeatherLocation;
    invoke-virtual {v6}, Lcom/htc/util/weather/WeatherLocation;->getCode()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9}, Lcom/htc/util/weather/WeatherLocation;->getCode()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_102

    .line 287
    const/4 v4, 0x1

    .line 291
    .end local v6    # "l":Lcom/htc/util/weather/WeatherLocation;
    :cond_ab
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "launchWeatherAp~ inList:"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 292
    if-nez v4, :cond_f2

    .line 293
    array-length v10, v8

    const/16 v11, 0xf

    if-ge v10, v11, :cond_f2

    .line 294
    const/4 v10, 0x1

    new-array v8, v10, [Lcom/htc/util/weather/WeatherLocation;

    .line 295
    aput-object v9, v8, v12

    .line 296
    iget-object v10, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mViewContext:Landroid/content/Context;

    invoke-virtual {v10}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v10

    const-string v11, "com.htc.elroy.Weather"

    invoke-static {v10, v13, v8}, Lcom/htc/util/weather/WeatherUtility;->addLocation(Landroid/content/ContentResolver;Ljava/lang/String;[Lcom/htc/util/weather/WeatherLocation;)V

    .line 299
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, "launchWeatherAp~ add loc:"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v9}, Lcom/htc/util/weather/WeatherLocation;->getCode()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 304
    .end local v0    # "arr$":[Lcom/htc/util/weather/WeatherLocation;
    .end local v3    # "i$":I
    .end local v4    # "inList":Z
    .end local v7    # "len$":I
    .end local v8    # "locs":[Lcom/htc/util/weather/WeatherLocation;
    :cond_f2
    const/high16 v10, 0x10000000

    invoke-virtual {v5, v10}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 305
    const/high16 v10, 0x4000000

    invoke-virtual {v5, v10}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 307
    :try_start_fc
    iget-object v10, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mApplication:Landroid/content/Context;

    invoke-virtual {v10, v5}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_101
    .catch Landroid/content/ActivityNotFoundException; {:try_start_fc .. :try_end_101} :catch_105

    .line 315
    .end local v9    # "weatherLoc":Lcom/htc/util/weather/WeatherLocation;
    :cond_101
    :goto_101
    return-void

    .line 285
    .restart local v0    # "arr$":[Lcom/htc/util/weather/WeatherLocation;
    .restart local v3    # "i$":I
    .restart local v4    # "inList":Z
    .restart local v6    # "l":Lcom/htc/util/weather/WeatherLocation;
    .restart local v7    # "len$":I
    .restart local v8    # "locs":[Lcom/htc/util/weather/WeatherLocation;
    .restart local v9    # "weatherLoc":Lcom/htc/util/weather/WeatherLocation;
    :cond_102
    add-int/lit8 v3, v3, 0x1

    goto :goto_98

    .line 308
    .end local v0    # "arr$":[Lcom/htc/util/weather/WeatherLocation;
    .end local v3    # "i$":I
    .end local v4    # "inList":Z
    .end local v6    # "l":Lcom/htc/util/weather/WeatherLocation;
    .end local v7    # "len$":I
    .end local v8    # "locs":[Lcom/htc/util/weather/WeatherLocation;
    :catch_105
    move-exception v10

    move-object v2, v10

    .line 309
    .local v2, "e":Landroid/content/ActivityNotFoundException;
    iget-object v10, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mViewContext:Landroid/content/Context;

    const-string v11, "Activity is not ready to execute"

    invoke-static {v10, v11, v12}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v10

    invoke-virtual {v10}, Landroid/widget/Toast;->show()V

    goto :goto_101
.end method

.method private launchWeatherClockAp()V
    .registers 3

    .prologue
    .line 234
    invoke-static {}, Lcom/htc/clock3dwidget/util/MyProjectSetting;->hasWeatherAp()Z

    move-result v0

    if-eqz v0, :cond_1d

    .line 235
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    if-eqz v0, :cond_1d

    .line 237
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationCtrl;->isLocServiceEnable()Z

    move-result v0

    if-nez v0, :cond_1e

    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationCtrl;->isCurrentLocation()Z

    move-result v0

    if-eqz v0, :cond_1e

    .line 239
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->launchLocSetting()V

    .line 251
    :cond_1d
    :goto_1d
    return-void

    .line 241
    :cond_1e
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationCtrl;->getLocState()Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    move-result-object v0

    sget-object v1, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->NO_DATA:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    if-eq v0, v1, :cond_2c

    .line 242
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->launchWeatherAp()V

    goto :goto_1d

    .line 244
    :cond_2c
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v0}, Lcom/htc/clock/util/location/LocationCtrl;->isLocServiceAvailable()Z

    move-result v0

    if-nez v0, :cond_1d

    .line 245
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->launchResetCityActivity()V

    goto :goto_1d
.end method

.method private loadPropertyData(Ljava/util/Properties;)V
    .registers 10
    .param p1, "props"    # Ljava/util/Properties;

    .prologue
    .line 600
    const/4 v0, 0x0

    .line 601
    .local v0, "bCurLocation":Z
    const/4 v1, 0x0

    .line 602
    .local v1, "bPlayWWP":Z
    const/4 v2, 0x0

    .line 603
    .local v2, "code":Ljava/lang/String;
    invoke-static {}, Lcom/htc/clock3dwidget/util/MyProjectSetting;->hasWeatherWallpaper()Z

    move-result v6

    if-eqz v6, :cond_a

    .line 604
    const/4 v1, 0x1

    .line 606
    :cond_a
    invoke-static {}, Lcom/htc/clock3dwidget/util/MyProjectSetting;->hasCurrentLocation()Z

    move-result v6

    if-eqz v6, :cond_11

    .line 607
    const/4 v0, 0x1

    .line 611
    :cond_11
    :try_start_11
    const-string v6, "isCurLocation"

    invoke-virtual {p1, v6}, Ljava/util/Properties;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v0

    .line 613
    const-string v6, "wwp_play_"

    invoke-virtual {p1, v6}, Ljava/util/Properties;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v1

    .line 615
    if-nez v0, :cond_2d

    .line 616
    const-string v6, "code_"

    invoke-virtual {p1, v6}, Ljava/util/Properties;->getProperty(Ljava/lang/String;)Ljava/lang/String;
    :try_end_2c
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_2c} :catch_bf

    move-result-object v2

    .line 622
    :cond_2d
    :goto_2d
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "initData~ from prop bCurLocation:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 623
    if-nez v0, :cond_dd

    if-eqz v2, :cond_dd

    .line 624
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "Code:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->d(Ljava/lang/String;)V

    .line 625
    const/4 v5, 0x0

    .line 626
    .local v5, "loc":Lcom/htc/util/weather/WeatherLocation;
    invoke-direct {p0, v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getLocationFromCode(Ljava/lang/String;)Lcom/htc/util/weather/WeatherLocation;

    move-result-object v5

    .line 627
    if-nez v5, :cond_ab

    .line 628
    new-instance v5, Lcom/htc/util/weather/WeatherLocation;

    .end local v5    # "loc":Lcom/htc/util/weather/WeatherLocation;
    invoke-direct {v5}, Lcom/htc/util/weather/WeatherLocation;-><init>()V

    .line 629
    .restart local v5    # "loc":Lcom/htc/util/weather/WeatherLocation;
    invoke-virtual {v5, v2}, Lcom/htc/util/weather/WeatherLocation;->setCode(Ljava/lang/String;)V

    .line 630
    const-string v6, "name_"

    invoke-virtual {p1, v6}, Ljava/util/Properties;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/htc/util/weather/WeatherLocation;->setName(Ljava/lang/String;)V

    .line 631
    const-string v6, "state_"

    invoke-virtual {p1, v6}, Ljava/util/Properties;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/htc/util/weather/WeatherLocation;->setState(Ljava/lang/String;)V

    .line 632
    const-string v6, "country_"

    invoke-virtual {p1, v6}, Ljava/util/Properties;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/htc/util/weather/WeatherLocation;->setCountry(Ljava/lang/String;)V

    .line 633
    const-string v6, "timezone_"

    invoke-virtual {p1, v6}, Ljava/util/Properties;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/htc/util/weather/WeatherLocation;->setTimezoneId(Ljava/lang/String;)V

    .line 634
    const-string v6, "app_"

    invoke-virtual {p1, v6}, Ljava/util/Properties;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/htc/util/weather/WeatherLocation;->setApp(Ljava/lang/String;)V

    .line 635
    const-string v6, "latitude_"

    invoke-virtual {p1, v6}, Ljava/util/Properties;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/htc/util/weather/WeatherLocation;->setLatitude(Ljava/lang/String;)V

    .line 636
    const-string v6, "longitude_"

    invoke-virtual {p1, v6}, Ljava/util/Properties;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Lcom/htc/util/weather/WeatherLocation;->setLongitude(Ljava/lang/String;)V

    .line 638
    :cond_ab
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v6, v5}, Lcom/htc/clock/util/location/LocationCtrl;->addLoc(Lcom/htc/util/weather/WeatherLocation;)Z

    .line 639
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v5}, Lcom/htc/util/weather/WeatherLocation;->getCode()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Lcom/htc/clock/util/location/LocationCtrl;->setLocKey(Ljava/lang/String;)V

    .line 656
    .end local v5    # "loc":Lcom/htc/util/weather/WeatherLocation;
    :goto_b9
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v6, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->setPlayWWP(Z)V

    .line 657
    return-void

    .line 617
    :catch_bf
    move-exception v6

    move-object v4, v6

    .line 618
    .local v4, "e":Ljava/lang/Exception;
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "initData~ get isCurLocation property error:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v4}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    goto/16 :goto_2d

    .line 641
    .end local v4    # "e":Ljava/lang/Exception;
    :cond_dd
    const/4 v3, 0x0

    .line 642
    .local v3, "defCityCode":Ljava/lang/String;
    if-eqz p1, :cond_e6

    .line 643
    const-string v6, "defCityCode_"

    invoke-virtual {p1, v6}, Ljava/util/Properties;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 645
    :cond_e6
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "initData~ defCityCode:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 646
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_11a

    .line 647
    invoke-direct {p0, v3}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getLocationFromCode(Ljava/lang/String;)Lcom/htc/util/weather/WeatherLocation;

    move-result-object v5

    .line 648
    .restart local v5    # "loc":Lcom/htc/util/weather/WeatherLocation;
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v6, v5}, Lcom/htc/clock/util/location/LocationCtrl;->addLoc(Lcom/htc/util/weather/WeatherLocation;)Z

    .line 649
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v6}, Lcom/htc/clock/util/location/LocationCtrl;->addCurLoc()Z

    .line 650
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v5}, Lcom/htc/util/weather/WeatherLocation;->getCode()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Lcom/htc/clock/util/location/LocationCtrl;->setLocKey(Ljava/lang/String;)V

    goto :goto_b9

    .line 652
    .end local v5    # "loc":Lcom/htc/util/weather/WeatherLocation;
    :cond_11a
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v6}, Lcom/htc/clock/util/location/LocationCtrl;->addCurLoc()Z

    .line 653
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    const-string v7, "cur"

    invoke-virtual {v6, v7}, Lcom/htc/clock/util/location/LocationCtrl;->setLocKey(Ljava/lang/String;)V

    goto :goto_b9
.end method

.method private myOnNotifyWidgetPause(I)V
    .registers 6
    .param p1, "notifyCause"    # I

    .prologue
    const/4 v3, 0x1

    const/4 v2, 0x0

    .line 770
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->isWidgetDestroy()Z

    move-result v0

    if-eqz v0, :cond_9

    .line 808
    :cond_8
    :goto_8
    return-void

    .line 772
    :cond_9
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "myOnNotifyWidgetPause:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->d(Ljava/lang/String;)V

    .line 773
    const/16 v0, 0x28

    if-ne p1, v0, :cond_7b

    .line 774
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mPauseByAddToHome:Z

    .line 778
    :goto_25
    sget-object v0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;->PAUSED:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiState:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;

    .line 779
    iput-boolean v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBoolAppResume:Z

    .line 780
    iput-boolean v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mbPlayWWPAtAdd:Z

    .line 781
    sput-boolean v2, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mbPlayWWPAtRosieStart:Z

    .line 782
    const v0, 0x9004

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeNonUiMessages(I)V

    .line 783
    const v0, 0x9009

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeNonUiMessages(I)V

    .line 784
    const v0, 0x8009

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 785
    const v0, 0x8013

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 786
    const v0, 0x8001

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 789
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    if-eqz v0, :cond_7e

    .line 790
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v0, v3}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->setPause(Z)V

    .line 796
    :goto_56
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    if-eqz v0, :cond_84

    .line 797
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->uiStopTodayAnimation()V

    .line 798
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v0, v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->setNeedPlayWeatherWallpaper(Z)V

    .line 799
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->onPause()V

    .line 800
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->isUseWWPAnimation()Z

    move-result v0

    if-eqz v0, :cond_8

    .line 801
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mLongClick:Z

    if-eqz v0, :cond_8

    .line 802
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->detach3DObject()V

    goto :goto_8

    .line 776
    :cond_7b
    iput-boolean v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mPauseByAddToHome:Z

    goto :goto_25

    .line 792
    :cond_7e
    const-string v0, "onNotifyWidgetPause~ mClockView is null"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    goto :goto_56

    .line 806
    :cond_84
    const-string v0, "onNotifyWidgetPause~ mWeatherView is null"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    goto/16 :goto_8
.end method

.method private playWWPAtFirstTime()V
    .registers 4

    .prologue
    const-wide/16 v1, 0x0

    .line 1329
    sget-boolean v0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mbPlayWWPAtRosieStart:Z

    if-eqz v0, :cond_c

    .line 1330
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v0, v1, v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->startWWPAnimation(J)Z

    .line 1334
    :cond_b
    :goto_b
    return-void

    .line 1331
    :cond_c
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mbPlayWWPAtAdd:Z

    if-eqz v0, :cond_b

    .line 1332
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v0, v1, v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->startWWPAnimation(J)Z

    goto :goto_b
.end method

.method private registerFormatObserver()V
    .registers 7

    .prologue
    .line 1388
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mLock:Ljava/lang/Object;

    monitor-enter v1

    .line 1389
    :try_start_3
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mContentResolver:Landroid/content/ContentResolver;

    if-nez v2, :cond_f

    .line 1390
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mResContext:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mContentResolver:Landroid/content/ContentResolver;

    .line 1393
    :cond_f
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    .line 1394
    .local v0, "handler":Landroid/os/Handler;
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mFormatChangeObserver:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$DbChangeObserver;

    if-nez v2, :cond_29

    .line 1395
    new-instance v2, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$DbChangeObserver;

    invoke-direct {v2, p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$DbChangeObserver;-><init>(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Landroid/os/Handler;)V

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mFormatChangeObserver:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$DbChangeObserver;

    .line 1396
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mContentResolver:Landroid/content/ContentResolver;

    sget-object v3, Landroid/provider/Settings$System;->CONTENT_URI:Landroid/net/Uri;

    const/4 v4, 0x1

    iget-object v5, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mFormatChangeObserver:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$DbChangeObserver;

    invoke-virtual {v2, v3, v4, v5}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V

    .line 1399
    :cond_29
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mSecureChangeObserver:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$DbChangeObserver;

    if-nez v2, :cond_3e

    .line 1400
    new-instance v2, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$DbChangeObserver;

    invoke-direct {v2, p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$DbChangeObserver;-><init>(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Landroid/os/Handler;)V

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mSecureChangeObserver:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$DbChangeObserver;

    .line 1401
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mContentResolver:Landroid/content/ContentResolver;

    sget-object v3, Landroid/provider/Settings$Secure;->CONTENT_URI:Landroid/net/Uri;

    const/4 v4, 0x1

    iget-object v5, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mSecureChangeObserver:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$DbChangeObserver;

    invoke-virtual {v2, v3, v4, v5}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V

    .line 1404
    :cond_3e
    monitor-exit v1

    .line 1405
    return-void

    .line 1404
    .end local v0    # "handler":Landroid/os/Handler;
    :catchall_40
    move-exception v2

    monitor-exit v1
    :try_end_42
    .catchall {:try_start_3 .. :try_end_42} :catchall_40

    throw v2
.end method

.method private registerIntentReceivers()V
    .registers 1

    .prologue
    .line 1091
    return-void
.end method

.method private removeMessages()V
    .registers 2

    .prologue
    .line 500
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeNonUiMessages(I)V

    .line 501
    const v0, 0x9004

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeNonUiMessages(I)V

    .line 502
    const v0, 0x9009

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeNonUiMessages(I)V

    .line 503
    const/4 v0, 0x2

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeNonUiMessages(I)V

    .line 504
    const v0, 0x9001

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeNonUiMessages(I)V

    .line 505
    const v0, 0x9202

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeNonUiMessages(I)V

    .line 506
    const v0, 0x9201

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeNonUiMessages(I)V

    .line 507
    const v0, 0x9203

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeNonUiMessages(I)V

    .line 508
    const/4 v0, 0x4

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeNonUiMessages(I)V

    .line 509
    const v0, 0x9204

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeNonUiMessages(I)V

    .line 510
    const v0, 0x9205

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeNonUiMessages(I)V

    .line 511
    const v0, 0x9011

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeNonUiMessages(I)V

    .line 512
    const v0, 0x9012

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeNonUiMessages(I)V

    .line 513
    const v0, 0x9013

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeNonUiMessages(I)V

    .line 514
    const v0, 0x9014

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeNonUiMessages(I)V

    .line 516
    const v0, 0x9003

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 517
    const v0, 0x8016

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 518
    const v0, 0x8009

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 519
    const v0, 0x800a

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 520
    const v0, 0x8001

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 521
    const v0, 0x8020

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 522
    const v0, 0x8019

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 523
    const v0, 0x8014

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 524
    const v0, 0x8015

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 525
    const v0, 0x800c

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 526
    const v0, 0x8013

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 527
    const v0, 0x8012

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 528
    const v0, 0x8021

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 529
    return-void
.end method

.method private removePauseMessage()V
    .registers 3

    .prologue
    const/4 v1, 0x2

    .line 145
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, v1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->hasMessage(I)Z

    move-result v0

    if-eqz v0, :cond_e

    .line 146
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, v1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->recall(I)V

    .line 148
    :cond_e
    return-void
.end method

.method private removeResumeMessage()V
    .registers 4

    .prologue
    const v2, 0x9004

    const/4 v1, 0x1

    .line 135
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, v2}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->hasMessage(I)Z

    move-result v0

    if-eqz v0, :cond_11

    .line 136
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, v2}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->recall(I)V

    .line 139
    :cond_11
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, v1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->hasMessage(I)Z

    move-result v0

    if-eqz v0, :cond_1e

    .line 140
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, v1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->recall(I)V

    .line 142
    :cond_1e
    return-void
.end method

.method private saveInitProps(Lcom/htc/util/weather/WeatherLocation;Z)V
    .registers 7
    .param p1, "weatherLoc"    # Lcom/htc/util/weather/WeatherLocation;
    .param p2, "bPlayWWP"    # Z

    .prologue
    const-string v2, "isCurLocation"

    .line 721
    :try_start_2
    new-instance v1, Ljava/util/Properties;

    invoke-direct {v1}, Ljava/util/Properties;-><init>()V

    .line 723
    .local v1, "props":Ljava/util/Properties;
    const-string v2, "wwp_play_"

    invoke-static {p2}, Ljava/lang/Boolean;->toString(Z)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Ljava/util/Properties;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;

    .line 724
    if-eqz p1, :cond_78

    invoke-virtual {p1}, Lcom/htc/util/weather/WeatherLocation;->getName()Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_78

    invoke-virtual {p1}, Lcom/htc/util/weather/WeatherLocation;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_78

    .line 726
    const-string v2, "name_"

    invoke-virtual {p1}, Lcom/htc/util/weather/WeatherLocation;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Ljava/util/Properties;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;

    .line 727
    const-string v2, "state_"

    invoke-virtual {p1}, Lcom/htc/util/weather/WeatherLocation;->getState()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Ljava/util/Properties;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;

    .line 728
    const-string v2, "country_"

    invoke-virtual {p1}, Lcom/htc/util/weather/WeatherLocation;->getCountry()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Ljava/util/Properties;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;

    .line 729
    const-string v2, "code_"

    invoke-virtual {p1}, Lcom/htc/util/weather/WeatherLocation;->getCode()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Ljava/util/Properties;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;

    .line 730
    const-string v2, "latitude_"

    invoke-virtual {p1}, Lcom/htc/util/weather/WeatherLocation;->getLatitude()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Ljava/util/Properties;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;

    .line 731
    const-string v2, "longitude_"

    invoke-virtual {p1}, Lcom/htc/util/weather/WeatherLocation;->getLongitude()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Ljava/util/Properties;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;

    .line 732
    const-string v2, "app_"

    invoke-virtual {p1}, Lcom/htc/util/weather/WeatherLocation;->getApp()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Ljava/util/Properties;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;

    .line 733
    const-string v2, "timezone_"

    invoke-virtual {p1}, Lcom/htc/util/weather/WeatherLocation;->getTimezoneId()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Ljava/util/Properties;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;

    .line 734
    const-string v2, "isCurLocation"

    const/4 v3, 0x0

    invoke-static {v3}, Ljava/lang/Boolean;->toString(Z)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Ljava/util/Properties;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;
    :try_end_74
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_74} :catch_83

    .line 740
    :goto_74
    :try_start_74
    invoke-virtual {p0, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->storeInstanceData(Ljava/util/Properties;)V
    :try_end_77
    .catch Landroid/database/sqlite/SQLiteFullException; {:try_start_74 .. :try_end_77} :catch_89
    .catch Ljava/lang/Exception; {:try_start_74 .. :try_end_77} :catch_83

    .line 747
    .end local v1    # "props":Ljava/util/Properties;
    :goto_77
    return-void

    .line 737
    .restart local v1    # "props":Ljava/util/Properties;
    :cond_78
    :try_start_78
    const-string v2, "isCurLocation"

    const/4 v3, 0x1

    invoke-static {v3}, Ljava/lang/Boolean;->toString(Z)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v2, v3}, Ljava/util/Properties;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;
    :try_end_82
    .catch Ljava/lang/Exception; {:try_start_78 .. :try_end_82} :catch_83

    goto :goto_74

    .line 744
    .end local v1    # "props":Ljava/util/Properties;
    :catch_83
    move-exception v2

    move-object v0, v2

    .line 745
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    goto :goto_77

    .line 741
    .end local v0    # "e":Ljava/lang/Exception;
    .restart local v1    # "props":Ljava/util/Properties;
    :catch_89
    move-exception v0

    .line 742
    .local v0, "e":Landroid/database/sqlite/SQLiteFullException;
    :try_start_8a
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteFullException;->printStackTrace()V
    :try_end_8d
    .catch Ljava/lang/Exception; {:try_start_8a .. :try_end_8d} :catch_83

    goto :goto_77
.end method

.method private savePropertyData(Landroid/content/Intent;)V
    .registers 7
    .param p1, "intent"    # Landroid/content/Intent;

    .prologue
    const/4 v4, 0x1

    .line 355
    if-nez p1, :cond_4

    .line 375
    :goto_3
    return-void

    .line 357
    :cond_4
    const-string v3, "currentLocation"

    invoke-virtual {p1, v3, v4}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v0

    .line 359
    .local v0, "bCurLocation":Z
    const-string v3, "wwp_play_"

    invoke-virtual {p1, v3, v4}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v1

    .line 361
    .local v1, "bPlayWWP":Z
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v3, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->setPlayWWP(Z)V

    .line 362
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "initData~ from intent bCurLocation:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 363
    if-nez v0, :cond_43

    .line 365
    invoke-direct {p0, p1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getLocationFromIntent(Landroid/content/Intent;)Lcom/htc/util/weather/WeatherLocation;

    move-result-object v2

    .line 366
    .local v2, "loc":Lcom/htc/util/weather/WeatherLocation;
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v3, v2}, Lcom/htc/clock/util/location/LocationCtrl;->addLoc(Lcom/htc/util/weather/WeatherLocation;)Z

    .line 367
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v2}, Lcom/htc/util/weather/WeatherLocation;->getCode()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/htc/clock/util/location/LocationCtrl;->setLocKey(Ljava/lang/String;)V

    .line 369
    invoke-direct {p0, v2, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->saveInitProps(Lcom/htc/util/weather/WeatherLocation;Z)V

    goto :goto_3

    .line 371
    .end local v2    # "loc":Lcom/htc/util/weather/WeatherLocation;
    :cond_43
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v3}, Lcom/htc/clock/util/location/LocationCtrl;->addCurLoc()Z

    .line 372
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    const-string v4, "cur"

    invoke-virtual {v3, v4}, Lcom/htc/clock/util/location/LocationCtrl;->setLocKey(Ljava/lang/String;)V

    .line 373
    const/4 v3, 0x0

    invoke-direct {p0, v3, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->saveInitProps(Lcom/htc/util/weather/WeatherLocation;Z)V

    goto :goto_3
.end method

.method private startLocSettingActivity()V
    .registers 4

    .prologue
    .line 1443
    :try_start_0
    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.settings.LOCATION_SOURCE_SETTINGS"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 1445
    .local v1, "intent":Landroid/content/Intent;
    const/high16 v2, 0x10800000

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 1447
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mApplication:Landroid/content/Context;

    invoke-virtual {v2, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_11
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_11} :catch_12

    .line 1451
    .end local v1    # "intent":Landroid/content/Intent;
    :goto_11
    return-void

    .line 1448
    :catch_12
    move-exception v2

    move-object v0, v2

    .line 1449
    .local v0, "e":Ljava/lang/Exception;
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    goto :goto_11
.end method

.method private stateToLog()V
    .registers 10

    .prologue
    const-string v8, "\n"

    const-string v7, " "

    .line 1096
    invoke-static {}, Lcom/htc/clock/util/MyLog;->IsDebugLog()Z

    move-result v4

    if-nez v4, :cond_b

    .line 1146
    :cond_a
    :goto_a
    return-void

    .line 1100
    :cond_b
    new-instance v1, Ljava/lang/StringBuffer;

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    .line 1101
    .local v1, "log":Ljava/lang/StringBuffer;
    iget-object v4, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    if-eqz v4, :cond_ce

    .line 1102
    iget-object v4, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v4}, Lcom/htc/clock/util/location/LocationCtrl;->getLocState()Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    move-result-object v0

    .line 1103
    .local v0, "locState":Lcom/htc/clock/util/location/LocationCtrl$LocationState;
    iget-object v4, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v4}, Lcom/htc/clock/util/location/LocationCtrl;->getState()Lcom/htc/clock/util/location/LocationCtrl$State;

    move-result-object v2

    .line 1104
    .local v2, "state":Lcom/htc/clock/util/location/LocationCtrl$State;
    const-string v4, "stateToLog~ state:"

    invoke-virtual {v1, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/Object;)Ljava/lang/StringBuffer;

    move-result-object v4

    const-string v5, "\n"

    invoke-virtual {v4, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 1105
    const-string v4, "stateToLog~ locState:"

    invoke-virtual {v1, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/Object;)Ljava/lang/StringBuffer;

    move-result-object v4

    const-string v5, "\n"

    invoke-virtual {v4, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 1106
    sget-object v4, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->ONLY_LOC:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    invoke-virtual {v4, v0}, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_4e

    sget-object v4, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->OK:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    invoke-virtual {v4, v0}, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_ce

    .line 1108
    :cond_4e
    const-string v4, "stateToLog~ weather update time:"

    invoke-virtual {v1, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    iget-object v5, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v5}, Lcom/htc/clock/util/location/LocationCtrl;->getLastUpdateTime()J

    move-result-wide v5

    invoke-virtual {v4, v5, v6}, Ljava/lang/StringBuffer;->append(J)Ljava/lang/StringBuffer;

    move-result-object v4

    const-string v5, " "

    invoke-virtual {v4, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 1110
    const-string v4, "stateToLog~ weather locCode:"

    invoke-virtual {v1, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    iget-object v5, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v5}, Lcom/htc/clock/util/location/LocationCtrl;->getLocCode()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    const-string v5, " "

    invoke-virtual {v4, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 1112
    const-string v4, "locName:"

    invoke-virtual {v1, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    iget-object v5, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v5}, Lcom/htc/clock/util/location/LocationCtrl;->getLocName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    const-string v5, " "

    invoke-virtual {v4, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 1114
    const-string v4, "(lat,lng):("

    invoke-virtual {v1, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    iget-object v5, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v5}, Lcom/htc/clock/util/location/LocationCtrl;->getWeatherLocation()Lcom/htc/util/weather/WeatherLocation;

    move-result-object v5

    invoke-virtual {v5}, Lcom/htc/util/weather/WeatherLocation;->getLatitude()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    const-string v5, ","

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 1117
    iget-object v4, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v4}, Lcom/htc/clock/util/location/LocationCtrl;->getWeatherLocation()Lcom/htc/util/weather/WeatherLocation;

    move-result-object v4

    invoke-virtual {v4}, Lcom/htc/util/weather/WeatherLocation;->getLongitude()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    const-string v5, ") "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 1119
    const-string v4, "stateToLog~ LocConditionId:"

    invoke-virtual {v1, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    iget-object v5, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v5}, Lcom/htc/clock/util/location/LocationCtrl;->getLocConditionId()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    const-string v5, "\n"

    invoke-virtual {v4, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 1124
    .end local v0    # "locState":Lcom/htc/clock/util/location/LocationCtrl$LocationState;
    .end local v2    # "state":Lcom/htc/clock/util/location/LocationCtrl$State;
    :cond_ce
    iget-object v4, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    if-eqz v4, :cond_111

    .line 1125
    iget-object v4, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v4}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->getTimeZone()Ljava/util/TimeZone;

    move-result-object v3

    .line 1126
    .local v3, "tz":Ljava/util/TimeZone;
    const-string v4, "stateToLog~ listen timezone changed:"

    invoke-virtual {v1, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    iget-object v5, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v5}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->getListenTimeZoneChanged()Z

    move-result v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Z)Ljava/lang/StringBuffer;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, " mReceiverRegistered:"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    iget-boolean v6, v6, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->mReceiverRegistered:Z

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 1130
    if-eqz v3, :cond_148

    .line 1131
    const-string v4, " used timezone:"

    invoke-virtual {v1, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v3}, Ljava/util/TimeZone;->getID()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 1137
    .end local v3    # "tz":Ljava/util/TimeZone;
    :cond_111
    :goto_111
    const-string v4, "\n---start last weather receive log---\n"

    invoke-virtual {v1, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 1138
    const-string v4, "mBOnReceiveWeatherData:"

    invoke-virtual {v1, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    iget-object v5, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    iget-boolean v5, v5, Lcom/htc/clock/util/location/LocationCtrl;->mBOnReceiveWeatherData:Z

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Z)Ljava/lang/StringBuffer;

    .line 1140
    const-string v4, " "

    invoke-virtual {v1, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    iget-object v5, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    iget-object v5, v5, Lcom/htc/clock/util/location/LocationCtrl;->mSOnReceiveLog:Ljava/lang/StringBuffer;

    invoke-virtual {v5}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 1141
    const-string v4, "\n---end last weather receive log---"

    invoke-virtual {v1, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    .line 1142
    invoke-virtual {v1}, Ljava/lang/StringBuffer;->length()I

    move-result v4

    if-lez v4, :cond_a

    .line 1143
    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    goto/16 :goto_a

    .line 1133
    .restart local v3    # "tz":Ljava/util/TimeZone;
    :cond_148
    const-string v4, " tz null"

    invoke-virtual {v1, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    goto :goto_111
.end method

.method private switchToNewCity(ZLandroid/content/Intent;)V
    .registers 9
    .param p1, "bCurLocation"    # Z
    .param p2, "data"    # Landroid/content/Intent;

    .prologue
    .line 411
    monitor-enter p0

    .line 412
    :try_start_1
    iget-boolean v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBoolAppDestroy:Z

    if-eqz v3, :cond_7

    .line 413
    monitor-exit p0

    .line 446
    :goto_6
    return-void

    .line 415
    :cond_7
    if-eqz p2, :cond_15

    .line 416
    const-string v3, "wwp_play_"

    const/4 v4, 0x1

    invoke-virtual {p2, v3, v4}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v0

    .line 417
    .local v0, "bPlayWWP":Z
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v3, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->setPlayWWP(Z)V

    .line 420
    .end local v0    # "bPlayWWP":Z
    :cond_15
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    if-eqz v3, :cond_1e

    .line 421
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v3}, Lcom/htc/clock/util/location/LocationCtrl;->unRegister()V

    .line 423
    :cond_1e
    new-instance v3, Lcom/htc/clock/util/location/LocationCtrl;

    iget-object v4, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mResContext:Landroid/content/Context;

    invoke-direct {v3, v4}, Lcom/htc/clock/util/location/LocationCtrl;-><init>(Landroid/content/Context;)V

    iput-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    .line 424
    const/4 v2, 0x0

    .line 425
    .local v2, "loc":Lcom/htc/util/weather/WeatherLocation;
    if-nez p1, :cond_81

    .line 426
    invoke-direct {p0, p2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getLocationFromIntent(Landroid/content/Intent;)Lcom/htc/util/weather/WeatherLocation;

    move-result-object v2

    .line 427
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v3, v2}, Lcom/htc/clock/util/location/LocationCtrl;->addLoc(Lcom/htc/util/weather/WeatherLocation;)Z

    .line 431
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v2}, Lcom/htc/util/weather/WeatherLocation;->getCode()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/htc/clock/util/location/LocationCtrl;->setLocKey(Ljava/lang/String;)V

    .line 432
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "onActivityResult~ loc:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v2}, Lcom/htc/util/weather/WeatherLocation;->getCode()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 437
    :goto_56
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v3}, Lcom/htc/clock/util/location/LocationCtrl;->getState()Lcom/htc/clock/util/location/LocationCtrl$State;

    move-result-object v3

    sget-object v4, Lcom/htc/clock/util/location/LocationCtrl$State;->START:Lcom/htc/clock/util/location/LocationCtrl$State;

    if-eq v3, v4, :cond_71

    .line 438
    new-instance v1, Landroid/os/Handler;

    invoke-direct {v1}, Landroid/os/Handler;-><init>()V

    .line 439
    .local v1, "handler":Landroid/os/Handler;
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    iget-object v4, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherListener:Lcom/htc/clock/util/location/LocationListener;

    invoke-virtual {v3, v1, v4}, Lcom/htc/clock/util/location/LocationCtrl;->register(Landroid/os/Handler;Lcom/htc/clock/util/location/LocationListener;)V

    .line 440
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v3}, Lcom/htc/clock/util/location/LocationCtrl;->checkLocEnable()Z

    .line 443
    .end local v1    # "handler":Landroid/os/Handler;
    :cond_71
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->testWeatherCtrl()V

    .line 444
    const v3, 0x9203

    const-wide/16 v4, 0x0

    invoke-virtual {p0, v3, v4, v5}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->sendNonUiMessageDelayed(IJ)V

    .line 445
    monitor-exit p0

    goto :goto_6

    .end local v2    # "loc":Lcom/htc/util/weather/WeatherLocation;
    :catchall_7e
    move-exception v3

    monitor-exit p0
    :try_end_80
    .catchall {:try_start_1 .. :try_end_80} :catchall_7e

    throw v3

    .line 434
    .restart local v2    # "loc":Lcom/htc/util/weather/WeatherLocation;
    :cond_81
    :try_start_81
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v3}, Lcom/htc/clock/util/location/LocationCtrl;->addCurLoc()Z

    .line 435
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    const-string v4, "cur"

    invoke-virtual {v3, v4}, Lcom/htc/clock/util/location/LocationCtrl;->setLocKey(Ljava/lang/String;)V
    :try_end_8d
    .catchall {:try_start_81 .. :try_end_8d} :catchall_7e

    goto :goto_56
.end method

.method private unInitReceiver()V
    .registers 4

    .prologue
    .line 1241
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mLock:Ljava/lang/Object;

    monitor-enter v0

    .line 1242
    :try_start_3
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mLockScreenRec:Landroid/content/BroadcastReceiver;

    if-eqz v1, :cond_11

    .line 1243
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mResContext:Landroid/content/Context;

    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mLockScreenRec:Landroid/content/BroadcastReceiver;

    invoke-virtual {v1, v2}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 1244
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mLockScreenRec:Landroid/content/BroadcastReceiver;

    .line 1247
    :cond_11
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mContentResolver:Landroid/content/ContentResolver;

    if-eqz v1, :cond_34

    .line 1248
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mFormatChangeObserver:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$DbChangeObserver;

    if-eqz v1, :cond_23

    .line 1249
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mContentResolver:Landroid/content/ContentResolver;

    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mFormatChangeObserver:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$DbChangeObserver;

    invoke-virtual {v1, v2}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V

    .line 1251
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mFormatChangeObserver:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$DbChangeObserver;

    .line 1254
    :cond_23
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mSecureChangeObserver:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$DbChangeObserver;

    if-eqz v1, :cond_31

    .line 1255
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mContentResolver:Landroid/content/ContentResolver;

    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mSecureChangeObserver:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$DbChangeObserver;

    invoke-virtual {v1, v2}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V

    .line 1257
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mSecureChangeObserver:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$DbChangeObserver;

    .line 1259
    :cond_31
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mContentResolver:Landroid/content/ContentResolver;

    .line 1261
    :cond_34
    monitor-exit v0

    .line 1262
    return-void

    .line 1261
    :catchall_36
    move-exception v1

    monitor-exit v0
    :try_end_38
    .catchall {:try_start_3 .. :try_end_38} :catchall_36

    throw v1
.end method


# virtual methods
.method public buildCache()V
    .registers 1

    .prologue
    .line 1429
    return-void
.end method

.method public checkClockTimeZone()V
    .registers 8

    .prologue
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x0

    .line 1300
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    if-eqz v2, :cond_b

    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    if-nez v2, :cond_c

    .line 1326
    :cond_b
    :goto_b
    return-void

    .line 1303
    :cond_c
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v2}, Lcom/htc/clock/util/location/LocationCtrl;->getTimeZoneId()Ljava/lang/String;

    move-result-object v1

    .line 1304
    .local v1, "timezoneId":Ljava/lang/String;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "checkClockTimeZone~ timezoneId:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 1305
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "checkClockTimeZone~ isTimezoneAutoSyn:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v3}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->isTimezoneAutoSyn()Z

    move-result v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 1307
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v2}, Lcom/htc/clock/util/location/LocationCtrl;->isCurrentLocation()Z

    move-result v2

    if-nez v2, :cond_57

    .line 1308
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v2, v4}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->setListenTimeZoneChanged(Z)V

    .line 1309
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v2, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->setTimeZone(Ljava/lang/String;)V

    goto :goto_b

    .line 1311
    :cond_57
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->isTimezoneAutoSyn()Z

    move-result v2

    if-eqz v2, :cond_6a

    .line 1312
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v2, v5}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->setListenTimeZoneChanged(Z)V

    .line 1313
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v2, v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->setTimeZone(Ljava/lang/String;)V

    goto :goto_b

    .line 1315
    :cond_6a
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v2}, Lcom/htc/clock/util/location/LocationCtrl;->isLocServiceEnable()Z

    move-result v0

    .line 1316
    .local v0, "locEnable":Z
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v2}, Lcom/htc/clock/util/location/LocationCtrl;->getLocState()Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    move-result-object v2

    sget-object v3, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->NO_DATA:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    if-eq v2, v3, :cond_84

    if-eqz v1, :cond_84

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_84

    if-nez v0, :cond_90

    .line 1318
    :cond_84
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v2, v5}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->setListenTimeZoneChanged(Z)V

    .line 1319
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v2, v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->setTimeZone(Ljava/lang/String;)V

    goto/16 :goto_b

    .line 1321
    :cond_90
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v2, v4}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->setListenTimeZoneChanged(Z)V

    .line 1322
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v2, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->setTimeZone(Ljava/lang/String;)V

    goto/16 :goto_b
.end method

.method public getNotifyType()I
    .registers 2

    .prologue
    .line 319
    const/16 v0, 0x32

    return v0
.end method

.method protected getScene()Lcom/htc/fusion/fx/FxScene;
    .registers 3

    .prologue
    .line 1493
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mOrientation:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_8

    .line 1494
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mScenePort:Lcom/htc/fusion/fx/FxScene;

    .line 1496
    :goto_7
    return-object v0

    :cond_8
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mSceneLand:Lcom/htc/fusion/fx/FxScene;

    goto :goto_7
.end method

.method protected getScene(I)Lcom/htc/fusion/fx/FxScene;
    .registers 3
    .param p1, "orientation"    # I

    .prologue
    .line 1484
    const/4 v0, 0x1

    if-ne p1, v0, :cond_6

    .line 1485
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mScenePort:Lcom/htc/fusion/fx/FxScene;

    .line 1487
    :goto_5
    return-object v0

    :cond_6
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mSceneLand:Lcom/htc/fusion/fx/FxScene;

    goto :goto_5
.end method

.method public getSettingIntent()Ljava/lang/String;
    .registers 5

    .prologue
    .line 207
    new-instance v0, Landroid/content/Intent;

    const-string v2, "OpenSettings"

    invoke-direct {v0, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 208
    .local v0, "intent":Landroid/content/Intent;
    const-string v2, "com.htc.clock3dwidget"

    const-string v3, "com.htc.clock3dwidget.setting.HtcClockSetting"

    invoke-virtual {v0, v2, v3}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 210
    const-string v2, "index"

    const/4 v3, 0x3

    invoke-virtual {v0, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 212
    const/4 v1, 0x1

    .line 213
    .local v1, "wwpPlay":Z
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    if-eqz v2, :cond_1f

    .line 214
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->isUseWWPAnimation()Z

    move-result v1

    .line 216
    :cond_1f
    const-string v2, "wwp_play_"

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 217
    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/content/Intent;->toUri(I)Ljava/lang/String;

    move-result-object v2

    return-object v2
.end method

.method public getWeatherCtrl()Lcom/htc/clock/util/location/LocationCtrl;
    .registers 2

    .prologue
    .line 1209
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    return-object v0
.end method

.method public isAttach3DObject()Z
    .registers 2

    .prologue
    .line 1213
    const-string v0, "isAttach3DObject"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 1214
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    if-eqz v0, :cond_10

    .line 1215
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->isUseWWPAnimation()Z

    move-result v0

    .line 1217
    :goto_f
    return v0

    :cond_10
    const/4 v0, 0x0

    goto :goto_f
.end method

.method public isEditable()Z
    .registers 2

    .prologue
    .line 1469
    const/4 v0, 0x1

    return v0
.end method

.method protected isSharingHandlerThread()Z
    .registers 2

    .prologue
    .line 203
    const/4 v0, 0x0

    return v0
.end method

.method public isWidgetDestroy()Z
    .registers 2

    .prologue
    .line 1228
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBoolAppDestroy:Z

    return v0
.end method

.method public isWidgetOnResume()Z
    .registers 2

    .prologue
    .line 1221
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBoolAppDestroy:Z

    if-nez v0, :cond_8

    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBoolAppResume:Z

    if-nez v0, :cond_a

    .line 1222
    :cond_8
    const/4 v0, 0x0

    .line 1224
    :goto_9
    return v0

    :cond_a
    const/4 v0, 0x1

    goto :goto_9
.end method

.method public launchLocSetting()V
    .registers 2

    .prologue
    .line 1454
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->startLocSettingActivity()V

    .line 1455
    new-instance v0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$7;

    invoke-direct {v0, p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$7;-><init>(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)V

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$7;->start()V

    .line 1462
    return-void
.end method

.method public launchResetCityActivity()V
    .registers 5

    .prologue
    .line 1433
    :try_start_0
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getSettingIntent()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    invoke-static {v2, v3}, Landroid/content/Intent;->parseUri(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v1

    .line 1434
    .local v1, "intent":Landroid/content/Intent;
    const-string v2, "widget_city_reset"

    const/4 v3, 0x1

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 1435
    iget v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWidgetId:I

    invoke-virtual {p0, v1, v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->startActivityForResult(Landroid/content/Intent;I)V
    :try_end_14
    .catch Ljava/net/URISyntaxException; {:try_start_0 .. :try_end_14} :catch_15

    .line 1439
    .end local v1    # "intent":Landroid/content/Intent;
    :goto_14
    return-void

    .line 1436
    :catch_15
    move-exception v2

    move-object v0, v2

    .line 1437
    .local v0, "e":Ljava/net/URISyntaxException;
    invoke-virtual {v0}, Ljava/net/URISyntaxException;->printStackTrace()V

    goto :goto_14
.end method

.method public onActivityResult(IILandroid/content/Intent;)V
    .registers 7
    .param p1, "requestCode"    # I
    .param p2, "resultCode"    # I
    .param p3, "data"    # Landroid/content/Intent;

    .prologue
    .line 334
    invoke-super {p0, p1, p2, p3}, Lcom/htc/android/rosie/widget/Widget$Base;->onActivityResult(IILandroid/content/Intent;)V

    .line 335
    const/4 v1, -0x1

    if-ne p2, v1, :cond_18

    .line 336
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->obtainMessage()Landroid/os/Message;

    move-result-object v0

    .line 337
    .local v0, "msg":Landroid/os/Message;
    const v1, 0x9014

    iput v1, v0, Landroid/os/Message;->what:I

    .line 338
    iput-object p3, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 339
    const-wide/16 v1, 0x0

    invoke-virtual {p0, v0, v1, v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->sendNonUiMessageDelayed(Landroid/os/Message;J)V

    .line 341
    .end local v0    # "msg":Landroid/os/Message;
    :cond_18
    return-void
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .registers 4
    .param p1, "newConfiguration"    # Landroid/content/res/Configuration;

    .prologue
    const v1, 0x9011

    .line 1502
    invoke-super {p0, p1}, Lcom/htc/android/rosie/widget/Widget$Base;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 1503
    iget v0, p1, Landroid/content/res/Configuration;->orientation:I

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mOrientation:I

    .line 1504
    invoke-direct {p0, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->hasNonUiMessage(I)Z

    move-result v0

    if-eqz v0, :cond_13

    .line 1505
    invoke-virtual {p0, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeNonUiMessages(I)V

    .line 1507
    :cond_13
    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .registers 6
    .param p1, "saved"    # Landroid/os/Bundle;

    .prologue
    const/4 v3, 0x1

    .line 68
    invoke-super {p0, p1}, Lcom/htc/android/rosie/widget/Widget$Base;->onCreate(Landroid/os/Bundle;)V

    .line 69
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getHost()Lcom/htc/android/rosie/widget/Widget$Host;

    move-result-object v0

    sget-object v1, Lcom/htc/clock3dwidget/ClockUtils$ClockType;->CLOCK_WEATHER:Lcom/htc/clock3dwidget/ClockUtils$ClockType;

    invoke-static {v1, v3}, Lcom/htc/clock3dwidget/ClockUtils;->getClockPath(Lcom/htc/clock3dwidget/ClockUtils$ClockType;Z)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1, v3}, Lcom/htc/android/rosie/widget/Widget$Host;->createScene(Ljava/lang/String;Z)Lcom/htc/fusion/fx/FxScene;

    move-result-object v0

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mScenePort:Lcom/htc/fusion/fx/FxScene;

    .line 70
    sget-boolean v0, Lcom/htc/clock3dwidget/ClockUtils;->SUPPORT_LAND:Z

    if-nez v0, :cond_3b

    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mScenePort:Lcom/htc/fusion/fx/FxScene;

    :goto_1a
    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mSceneLand:Lcom/htc/fusion/fx/FxScene;

    .line 71
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getContext()Landroid/content/Context;

    move-result-object v0

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mResContext:Landroid/content/Context;

    .line 72
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getHost()Lcom/htc/android/rosie/widget/Widget$Host;

    move-result-object v0

    invoke-interface {v0}, Lcom/htc/android/rosie/widget/Widget$Host;->getContext()Landroid/content/Context;

    move-result-object v0

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mApplication:Landroid/content/Context;

    .line 73
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mApplication:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    iget v0, v0, Landroid/content/res/Configuration;->orientation:I

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mOrientation:I

    .line 74
    return-void

    .line 70
    :cond_3b
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getHost()Lcom/htc/android/rosie/widget/Widget$Host;

    move-result-object v0

    sget-object v1, Lcom/htc/clock3dwidget/ClockUtils$ClockType;->CLOCK_WEATHER:Lcom/htc/clock3dwidget/ClockUtils$ClockType;

    const/4 v2, 0x0

    invoke-static {v1, v2}, Lcom/htc/clock3dwidget/ClockUtils;->getClockPath(Lcom/htc/clock3dwidget/ClockUtils$ClockType;Z)Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1, v3}, Lcom/htc/android/rosie/widget/Widget$Host;->createScene(Ljava/lang/String;Z)Lcom/htc/fusion/fx/FxScene;

    move-result-object v0

    goto :goto_1a
.end method

.method public onDestroy()V
    .registers 2

    .prologue
    .line 486
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBoolAppDestroy:Z

    .line 487
    const-string v0, "weather clock onActivityDestroy~"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 488
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeMessages()V

    .line 490
    :try_start_b
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->clear()V
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_e} :catch_12

    .line 493
    :goto_e
    invoke-super {p0}, Lcom/htc/android/rosie/widget/Widget$Base;->onDestroy()V

    .line 494
    return-void

    .line 491
    :catch_12
    move-exception v0

    goto :goto_e
.end method

.method public onEdit()V
    .registers 5

    .prologue
    .line 1475
    :try_start_0
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getSettingIntent()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    invoke-static {v2, v3}, Landroid/content/Intent;->parseUri(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v1

    .line 1476
    .local v1, "intent":Landroid/content/Intent;
    const/4 v2, 0x0

    invoke-virtual {p0, v1, v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->startActivityForResult(Landroid/content/Intent;I)V
    :try_end_d
    .catch Ljava/net/URISyntaxException; {:try_start_0 .. :try_end_d} :catch_e

    .line 1480
    .end local v1    # "intent":Landroid/content/Intent;
    :goto_d
    return-void

    .line 1477
    :catch_e
    move-exception v2

    move-object v0, v2

    .line 1478
    .local v0, "e":Ljava/net/URISyntaxException;
    invoke-virtual {v0}, Ljava/net/URISyntaxException;->printStackTrace()V

    goto :goto_d
.end method

.method protected onHostMessage(Landroid/os/Message;)V
    .registers 7
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    .line 379
    invoke-super {p0, p1}, Lcom/htc/android/rosie/widget/Widget$Base;->onHostMessage(Landroid/os/Message;)V

    .line 380
    iget v2, p1, Landroid/os/Message;->what:I

    packed-switch v2, :pswitch_data_90

    .line 402
    :cond_8
    :goto_8
    return-void

    .line 382
    :pswitch_9
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    if-eqz v2, :cond_8

    iget v2, p1, Landroid/os/Message;->arg1:I

    and-int/lit8 v2, v2, 0x1

    if-eqz v2, :cond_8

    .line 384
    iget v2, p1, Landroid/os/Message;->arg2:I

    invoke-virtual {p0, v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getPositionX(I)I

    move-result v0

    .line 385
    .local v0, "x":I
    iget v2, p1, Landroid/os/Message;->arg2:I

    invoke-virtual {p0, v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getPositionY(I)I

    move-result v1

    .line 386
    .local v1, "y":I
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "HOST_RESUME_IN_KEYGUARD(x,y)=("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ","

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ")"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 387
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v2, v0, v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->setPosition(II)V

    goto :goto_8

    .line 391
    .end local v0    # "x":I
    .end local v1    # "y":I
    :pswitch_4b
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "HOST_USER_PRESENT,arg1= "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v3, p1, Landroid/os/Message;->arg1:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ", mUiState="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiState:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 392
    iget v2, p1, Landroid/os/Message;->arg1:I

    and-int/lit8 v2, v2, 0x1

    if-eqz v2, :cond_8

    .line 393
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiState:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;

    sget-object v3, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;->PAUSED:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;

    if-eq v2, v3, :cond_81

    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiState:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;

    sget-object v3, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;->NONE:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;

    if-ne v2, v3, :cond_8

    .line 394
    :cond_81
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->doResumeInKeyguard()V

    goto :goto_8

    .line 399
    :pswitch_85
    const v2, 0x9011

    const-wide/16 v3, 0x0

    invoke-virtual {p0, v2, v3, v4}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->sendNonUiMessageDelayed(IJ)V

    goto/16 :goto_8

    .line 380
    nop

    :pswitch_data_90
    .packed-switch 0x3
        :pswitch_85
        :pswitch_9
        :pswitch_4b
    .end packed-switch
.end method

.method public onNotifyWidgetPause(I)V
    .registers 4
    .param p1, "notifyCause"    # I

    .prologue
    .line 753
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "onNotifyWidgetPause notifyCause:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 754
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->isWidgetDestroy()Z

    move-result v0

    if-eqz v0, :cond_1d

    .line 765
    :cond_1c
    :goto_1c
    return-void

    .line 756
    :cond_1d
    const v0, 0x9004

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeNonUiMessages(I)V

    .line 757
    const v0, 0x8009

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 758
    const v0, 0x8013

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 759
    const v0, 0x8001

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 761
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    if-eqz v0, :cond_1c

    const/16 v0, 0x14

    if-ne p1, v0, :cond_1c

    goto :goto_1c
.end method

.method public onPause()V
    .registers 3

    .prologue
    .line 152
    invoke-super {p0}, Lcom/htc/android/rosie/widget/Widget$Base;->onPause()V

    .line 153
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mInitLock:Ljava/lang/Object;

    monitor-enter v0

    .line 154
    :try_start_6
    iget-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mInitCreate:Z

    if-eqz v1, :cond_d

    .line 155
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->doPause()V

    .line 157
    :cond_d
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mInitPause:Z

    .line 158
    monitor-exit v0

    .line 159
    return-void

    .line 158
    :catchall_12
    move-exception v1

    monitor-exit v0
    :try_end_14
    .catchall {:try_start_6 .. :try_end_14} :catchall_12

    throw v1
.end method

.method protected onPostCreate(Landroid/os/Bundle;)V
    .registers 7
    .param p1, "savedState"    # Landroid/os/Bundle;

    .prologue
    const/4 v3, 0x0

    const/4 v4, 0x1

    .line 78
    invoke-super {p0, p1}, Lcom/htc/android/rosie/widget/Widget$Base;->onPostCreate(Landroid/os/Bundle;)V

    .line 79
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getHost()Lcom/htc/android/rosie/widget/Widget$Host;

    move-result-object v1

    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWorker:Landroid/os/Handler$Callback;

    invoke-interface {v1, v2}, Lcom/htc/android/rosie/widget/Widget$Host;->getWorker(Landroid/os/Handler$Callback;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    move-result-object v1

    iput-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    .line 80
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getHost()Lcom/htc/android/rosie/widget/Widget$Host;

    move-result-object v1

    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiWorker:Landroid/os/Handler$Callback;

    invoke-interface {v1, v2}, Lcom/htc/android/rosie/widget/Widget$Host;->getWorker(Landroid/os/Handler$Callback;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    move-result-object v1

    iput-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    .line 81
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mResContext:Landroid/content/Context;

    iput-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mViewContext:Landroid/content/Context;

    .line 82
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getIntent()Landroid/content/Intent;

    move-result-object v1

    iput-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBackIntent:Landroid/content/Intent;

    .line 83
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBoolAppDestroy:Z

    .line 84
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mLongClick:Z

    .line 85
    new-instance v1, Lcom/htc/clock/util/location/LocationCtrl;

    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mResContext:Landroid/content/Context;

    invoke-direct {v1, v2}, Lcom/htc/clock/util/location/LocationCtrl;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    .line 86
    new-instance v1, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mResContext:Landroid/content/Context;

    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getHost()Lcom/htc/android/rosie/widget/Widget$Host;

    move-result-object v3

    invoke-direct {v1, v2, p0, v3}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;-><init>(Landroid/content/Context;Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Lcom/htc/android/rosie/widget/Widget$Host;)V

    iput-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    .line 87
    new-instance v1, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;

    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mScenePort:Lcom/htc/fusion/fx/FxScene;

    invoke-direct {v1, v2}, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;-><init>(Lcom/htc/fusion/fx/FxScene;)V

    iput-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mFxControlsPort:Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;

    .line 88
    sget-boolean v1, Lcom/htc/clock3dwidget/ClockUtils;->SUPPORT_LAND:Z

    if-nez v1, :cond_c5

    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mFxControlsPort:Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;

    :goto_50
    iput-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mFxControlsLand:Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;

    .line 89
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mFxControlsPort:Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;

    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mFxControlsLand:Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;

    invoke-virtual {v1, v2, v3}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->bind(Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;)V

    .line 90
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    iget v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mOrientation:I

    if-ne v2, v4, :cond_cd

    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mFxControlsPort:Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;

    :goto_63
    invoke-virtual {v1, v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->init(Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;)V

    .line 91
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->init()V

    .line 92
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherClockClick:Landroid/view/View$OnClickListener;

    invoke-virtual {v1, v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->setOnWeatherClickListener(Landroid/view/View$OnClickListener;)V

    .line 93
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mResContext:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f060005

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 94
    .local v0, "defaultCurName":Ljava/lang/String;
    invoke-static {v0}, Lcom/htc/clock/util/location/LocationUtil;->setDefaultLocName(Ljava/lang/String;)V

    .line 95
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->initClock()V

    .line 97
    iput-boolean v4, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBoolAppResume:Z

    .line 98
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->registerIntentReceivers()V

    .line 99
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    const v2, 0x9001

    invoke-interface {v1, v2}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->send(I)V

    .line 100
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->checkPlayAnimationTime()V

    .line 101
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "WeatherClock onPostCreate ~ mInitResume = "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-boolean v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mInitResume:Z

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 102
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mInitLock:Ljava/lang/Object;

    monitor-enter v1

    .line 103
    :try_start_b2
    iget-boolean v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mInitResume:Z

    if-eqz v2, :cond_b9

    .line 104
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->doResume()V

    .line 106
    :cond_b9
    iget-boolean v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mInitPause:Z

    if-eqz v2, :cond_c0

    .line 107
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->doPause()V

    .line 109
    :cond_c0
    const/4 v2, 0x1

    iput-boolean v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mInitCreate:Z

    .line 110
    monitor-exit v1
    :try_end_c4
    .catchall {:try_start_b2 .. :try_end_c4} :catchall_d0

    .line 111
    return-void

    .line 88
    .end local v0    # "defaultCurName":Ljava/lang/String;
    :cond_c5
    new-instance v1, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;

    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mSceneLand:Lcom/htc/fusion/fx/FxScene;

    invoke-direct {v1, v2}, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;-><init>(Lcom/htc/fusion/fx/FxScene;)V

    goto :goto_50

    .line 90
    :cond_cd
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mFxControlsLand:Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;

    goto :goto_63

    .line 110
    .restart local v0    # "defaultCurName":Ljava/lang/String;
    :catchall_d0
    move-exception v2

    :try_start_d1
    monitor-exit v1
    :try_end_d2
    .catchall {:try_start_d1 .. :try_end_d2} :catchall_d0

    throw v2
.end method

.method public onResume()V
    .registers 3

    .prologue
    .line 115
    invoke-super {p0}, Lcom/htc/android/rosie/widget/Widget$Base;->onResume()V

    .line 116
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "WeatherClock onResume ~ mInitCreate = "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mInitCreate:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 117
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mInitLock:Ljava/lang/Object;

    monitor-enter v0

    .line 118
    :try_start_1e
    iget-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mInitCreate:Z

    if-eqz v1, :cond_25

    .line 119
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->doResume()V

    .line 121
    :cond_25
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mInitResume:Z

    .line 122
    monitor-exit v0

    .line 123
    return-void

    .line 122
    :catchall_2a
    move-exception v1

    monitor-exit v0
    :try_end_2c
    .catchall {:try_start_1e .. :try_end_2c} :catchall_2a

    throw v1
.end method

.method public declared-synchronized onSettingChanged()V
    .registers 4

    .prologue
    .line 1420
    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBoolAppDestroy:Z
    :try_end_3
    .catchall {:try_start_1 .. :try_end_3} :catchall_1d

    if-eqz v0, :cond_7

    .line 1426
    :goto_5
    monitor-exit p0

    return-void

    .line 1423
    :cond_7
    :try_start_7
    const-string v0, "onSettingChanged"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 1424
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    const v1, 0x9205

    invoke-interface {v0, v1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->recall(I)V

    .line 1425
    const v0, 0x9205

    const-wide/16 v1, 0xbb8

    invoke-virtual {p0, v0, v1, v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->sendNonUiMessageDelayed(IJ)V
    :try_end_1c
    .catchall {:try_start_7 .. :try_end_1c} :catchall_1d

    goto :goto_5

    .line 1420
    :catchall_1d
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public onTiltChanged(F)V
    .registers 3
    .param p1, "tilt"    # F

    .prologue
    .line 324
    invoke-super {p0, p1}, Lcom/htc/android/rosie/widget/Widget$Base;->onTiltChanged(F)V

    .line 325
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBoolAppDestroy:Z

    if-eqz v0, :cond_8

    .line 330
    :cond_7
    :goto_7
    return-void

    .line 327
    :cond_8
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    if-eqz v0, :cond_7

    .line 328
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    invoke-virtual {v0, p1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->doTiltChanged(F)V

    goto :goto_7
.end method

.method protected removeNonUiMessages(I)V
    .registers 3
    .param p1, "what"    # I

    .prologue
    .line 1203
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    if-eqz v0, :cond_9

    .line 1204
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, p1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->recall(I)V

    .line 1206
    :cond_9
    return-void
.end method

.method protected removeUiMessages(I)V
    .registers 3
    .param p1, "what"    # I

    .prologue
    .line 1172
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    if-eqz v0, :cond_9

    .line 1173
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, p1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->recall(I)V

    .line 1175
    :cond_9
    return-void
.end method

.method protected sendNonUiMessageDelayed(IJ)V
    .registers 6
    .param p1, "what"    # I
    .param p2, "delayMillis"    # J

    .prologue
    .line 1185
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    if-eqz v0, :cond_f

    .line 1186
    const-wide/16 v0, 0x0

    cmp-long v0, p2, v0

    if-lez v0, :cond_10

    .line 1187
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, p1, p2, p3}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->sendDelayed(IJ)V

    .line 1191
    :cond_f
    :goto_f
    return-void

    .line 1189
    :cond_10
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, p1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->send(I)V

    goto :goto_f
.end method

.method protected sendNonUiMessageDelayed(Landroid/os/Message;J)V
    .registers 6
    .param p1, "msg"    # Landroid/os/Message;
    .param p2, "delayMillis"    # J

    .prologue
    .line 1194
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    if-eqz v0, :cond_f

    .line 1195
    const-wide/16 v0, 0x0

    cmp-long v0, p2, v0

    if-lez v0, :cond_10

    .line 1196
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, p1, p2, p3}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->sendDelayed(Landroid/os/Message;J)V

    .line 1200
    :cond_f
    :goto_f
    return-void

    .line 1198
    :cond_10
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, p1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->send(Landroid/os/Message;)V

    goto :goto_f
.end method

.method protected sendUiMessageDelayed(IJ)V
    .registers 6
    .param p1, "what"    # I
    .param p2, "delayMillis"    # J

    .prologue
    .line 1163
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    if-eqz v0, :cond_f

    .line 1164
    const-wide/16 v0, 0x0

    cmp-long v0, p2, v0

    if-lez v0, :cond_10

    .line 1165
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, p1, p2, p3}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->sendDelayed(IJ)V

    .line 1169
    :cond_f
    :goto_f
    return-void

    .line 1167
    :cond_10
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, p1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->send(I)V

    goto :goto_f
.end method

.method protected sendUiMessageDelayed(IJII)V
    .registers 9
    .param p1, "what"    # I
    .param p2, "delayMillis"    # J
    .param p4, "arg1"    # I
    .param p5, "arg2"    # I

    .prologue
    .line 1150
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    if-eqz v1, :cond_1b

    .line 1151
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->obtainMessage()Landroid/os/Message;

    move-result-object v0

    .line 1152
    .local v0, "msg":Landroid/os/Message;
    iput p1, v0, Landroid/os/Message;->what:I

    .line 1153
    iput p4, v0, Landroid/os/Message;->arg1:I

    .line 1154
    iput p5, v0, Landroid/os/Message;->arg2:I

    .line 1155
    const-wide/16 v1, 0x0

    cmp-long v1, p2, v1

    if-lez v1, :cond_1c

    .line 1156
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v1, v0, p2, p3}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->sendDelayed(Landroid/os/Message;J)V

    .line 1160
    .end local v0    # "msg":Landroid/os/Message;
    :cond_1b
    :goto_1b
    return-void

    .line 1158
    .restart local v0    # "msg":Landroid/os/Message;
    :cond_1c
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v1, v0}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->send(Landroid/os/Message;)V

    goto :goto_1b
.end method

.method public skinApply()V
    .registers 1

    .prologue
    .line 1465
    return-void
.end method

.method public testWeatherCtrl()V
    .registers 3

    .prologue
    .line 449
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "testWeatherCtrl~ getLocCode:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v1}, Lcom/htc/clock/util/location/LocationCtrl;->getLocCode()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 450
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "testWeatherCtrl~ getLocName:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v1}, Lcom/htc/clock/util/location/LocationCtrl;->getLocName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 451
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "testWeatherCtrl~ getLocConditionIdInt:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v1}, Lcom/htc/clock/util/location/LocationCtrl;->getLocConditionIdInt()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 453
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "testWeatherCtrl~ getState:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;

    invoke-virtual {v1}, Lcom/htc/clock/util/location/LocationCtrl;->getState()Lcom/htc/clock/util/location/LocationCtrl$State;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 454
    return-void
.end method

.method public updateScrollCache()V
    .registers 1

    .prologue
    .line 497
    return-void
.end method
