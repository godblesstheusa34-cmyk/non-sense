.class public Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;
.super Lcom/htc/clock3dwidget/weatherclock/WeatherView;
.source "HtcDigitalClock42View.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$UIHandler;
    }
.end annotation


# static fields
.field private static mB24hourFormat:Z


# instance fields
.field protected final ANIMATION_HOUR_COUNT:I

.field protected final ANIMATION_MINUTE_COUNT:I

.field protected final ClockFormats:[Ljava/lang/String;

.field protected mBListenTimeZoneChanged:Z

.field private mBUpdateFomate:Z

.field protected mCalendar:Ljava/util/Calendar;

.field private mDateFormat:Ljava/lang/String;

.field protected mDigital_Data:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field protected mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

.field protected mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

.field private mFlipAnimePrepared:Z

.field protected mHour:I

.field private mIntentReceiver:Landroid/content/BroadcastReceiver;

.field private mLogCount:I

.field protected mMinuteFlipCount:I

.field protected mMinutes:I

.field protected mOldHour:I

.field protected mOldMinutes:I

.field protected mPaused:Z

.field public mReceiverRegistered:Z

.field private mTimeZoneChangedLog:Ljava/lang/StringBuffer;

.field private mUIHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

.field public mUseAnimation:Z

.field private m_bAutoSyn:Z

.field private m_telephonyManager:Landroid/telephony/TelephonyManager;

.field protected tz:Ljava/util/TimeZone;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .prologue
    .line 420
    const/4 v0, 0x0

    sput-boolean v0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mB24hourFormat:Z

    return-void
.end method

.method constructor <init>(Landroid/content/Context;Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Lcom/htc/android/rosie/widget/Widget$Host;)V
    .registers 11
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "widget"    # Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;
    .param p3, "host"    # Lcom/htc/android/rosie/widget/Widget$Host;

    .prologue
    const/4 v2, 0x2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const-string v6, "EE, MM-dd"

    .line 28
    invoke-direct {p0, p1, p2, p3}, Lcom/htc/clock3dwidget/weatherclock/WeatherView;-><init>(Landroid/content/Context;Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Lcom/htc/android/rosie/widget/Widget$Host;)V

    .line 34
    iput v3, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldHour:I

    .line 35
    iput v3, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldMinutes:I

    .line 36
    iput v3, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mMinutes:I

    .line 37
    iput v3, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    .line 41
    iput-boolean v4, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mPaused:Z

    .line 47
    iput v4, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->ANIMATION_HOUR_COUNT:I

    .line 48
    iput v2, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->ANIMATION_MINUTE_COUNT:I

    .line 49
    const/4 v0, 0x6

    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "EE, MM-dd"

    aput-object v6, v0, v3

    const-string v1, "EE, dd-MM"

    aput-object v1, v0, v4

    const-string v1, "EE, MMM dd"

    aput-object v1, v0, v2

    const/4 v1, 0x3

    const-string v2, "EE, dd-MMM"

    aput-object v2, v0, v1

    const/4 v1, 0x4

    const-string v2, "EE, MM-dd"

    aput-object v6, v0, v1

    const/4 v1, 0x5

    const-string v2, "EE, MMM dd"

    aput-object v2, v0, v1

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->ClockFormats:[Ljava/lang/String;

    .line 51
    invoke-static {}, Lcom/htc/clock3dwidget/util/MyProjectSetting;->isFlipEnable()Z

    move-result v0

    iput-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mUseAnimation:Z

    .line 53
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mFlipAnimePrepared:Z

    .line 56
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mReceiverRegistered:Z

    .line 93
    new-instance v0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$1;

    invoke-direct {v0, p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$1;-><init>(Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;)V

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mIntentReceiver:Landroid/content/BroadcastReceiver;

    .line 375
    iput-boolean v4, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mBListenTimeZoneChanged:Z

    .line 385
    iput v3, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mLogCount:I

    .line 405
    iput-object v5, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDateFormat:Ljava/lang/String;

    .line 421
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mBUpdateFomate:Z

    .line 437
    iput-boolean v4, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->m_bAutoSyn:Z

    .line 457
    iput-object v5, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->m_telephonyManager:Landroid/telephony/TelephonyManager;

    .line 29
    new-instance v0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$UIHandler;

    invoke-direct {v0, p0, v5}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$UIHandler;-><init>(Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$1;)V

    invoke-interface {p3, v0}, Lcom/htc/android/rosie/widget/Widget$Host;->getWorker(Landroid/os/Handler$Callback;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    move-result-object v0

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mUIHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    .line 30
    return-void
.end method

.method static synthetic access$100(Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;)Z
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;

    .prologue
    .line 24
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mFlipAnimePrepared:Z

    return v0
.end method

.method static synthetic access$200(Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;

    .prologue
    .line 24
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mUIHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    return-object v0
.end method

.method private applyRotation()V
    .registers 4

    .prologue
    .line 262
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_17

    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_17

    .line 263
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setDestNumber(I)V

    .line 264
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mMinutes:I

    const/4 v2, 0x2

    invoke-virtual {v0, v1, v2}, Lcom/htc/clock3dwidget/util/DigitControl;->setDestNumber(II)V

    .line 266
    :cond_17
    return-void
.end method

.method private increaseHour()V
    .registers 3

    .prologue
    const/16 v1, 0xc

    .line 240
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    .line 241
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->is24HourFormat()Z

    move-result v0

    if-eqz v0, :cond_15

    .line 242
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    rem-int/lit8 v0, v0, 0x18

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    .line 245
    :cond_14
    :goto_14
    return-void

    .line 243
    :cond_15
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    if-le v0, v1, :cond_14

    .line 244
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    sub-int/2addr v0, v1

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    goto :goto_14
.end method


# virtual methods
.method protected applyRotationTest()V
    .registers 6

    .prologue
    const/16 v4, 0xc

    const/4 v3, 0x1

    .line 473
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Ljava/util/Calendar;->setTimeInMillis(J)V

    .line 475
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    invoke-virtual {v0, v4}, Ljava/util/Calendar;->get(I)I

    move-result v0

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mMinutes:I

    .line 476
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    const/16 v1, 0xa

    invoke-virtual {v0, v1}, Ljava/util/Calendar;->get(I)I

    move-result v0

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    .line 478
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->is24HourFormat()Z

    move-result v0

    if-eqz v0, :cond_58

    .line 479
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    const/16 v1, 0x9

    invoke-virtual {v0, v1}, Ljava/util/Calendar;->get(I)I

    move-result v0

    if-ne v0, v3, :cond_34

    .line 480
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    add-int/lit8 v0, v0, 0xc

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    .line 481
    :cond_34
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    add-int/lit8 v0, v0, 0x18

    sub-int/2addr v0, v3

    rem-int/lit8 v0, v0, 0x18

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldHour:I

    .line 490
    :cond_3d
    :goto_3d
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mPaused:Z

    if-nez v0, :cond_57

    .line 491
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_57

    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_57

    .line 492
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setDestNumber(I)V

    .line 493
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mMinutes:I

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setDestNumber(I)V

    .line 496
    :cond_57
    return-void

    .line 483
    :cond_58
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    if-nez v0, :cond_5e

    .line 484
    iput v4, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    .line 485
    :cond_5e
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    add-int/lit8 v0, v0, 0xc

    sub-int/2addr v0, v3

    rem-int/lit8 v0, v0, 0xc

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldHour:I

    .line 486
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldHour:I

    if-nez v0, :cond_3d

    .line 487
    iput v4, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldHour:I

    goto :goto_3d
.end method

.method public checkSystemAutoSynTimezone()V
    .registers 3

    .prologue
    .line 440
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->isTimeAutoState()Z

    move-result v0

    iput-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->m_bAutoSyn:Z

    .line 441
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "checkSystemAutoSynTimezone~ m_bAutoSyn:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->m_bAutoSyn:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 442
    return-void
.end method

.method public clear()V
    .registers 2

    .prologue
    .line 128
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mPaused:Z

    .line 129
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->deInit()V

    .line 133
    return-void
.end method

.method public clearAnimations()V
    .registers 3

    .prologue
    .line 174
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mMinutes:I

    invoke-virtual {p0, v0, v1}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->clearAnimations(II)V

    .line 175
    return-void
.end method

.method public clearAnimations(II)V
    .registers 4
    .param p1, "hour"    # I
    .param p2, "minutes"    # I

    .prologue
    .line 178
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mUseAnimation:Z

    if-nez v0, :cond_4

    .line 181
    :cond_4
    return-void
.end method

.method public deInit()V
    .registers 4

    .prologue
    .line 116
    iget-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mReceiverRegistered:Z

    if-eqz v1, :cond_11

    .line 118
    :try_start_4
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mContext:Landroid/content/Context;

    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mIntentReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v1, v2}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_b
    .catch Ljava/lang/NullPointerException; {:try_start_4 .. :try_end_b} :catch_12

    .line 122
    :goto_b
    const/4 v1, 0x0

    iput-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mIntentReceiver:Landroid/content/BroadcastReceiver;

    .line 123
    const/4 v1, 0x0

    iput-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mReceiverRegistered:Z

    .line 125
    :cond_11
    return-void

    .line 119
    :catch_12
    move-exception v1

    move-object v0, v1

    .line 120
    .local v0, "e":Ljava/lang/NullPointerException;
    invoke-virtual {v0}, Ljava/lang/NullPointerException;->getStackTrace()[Ljava/lang/StackTraceElement;

    goto :goto_b
.end method

.method public getCalendarNow()Ljava/util/Calendar;
    .registers 3

    .prologue
    .line 396
    const/4 v0, 0x0

    .line 397
    .local v0, "calendar":Ljava/util/Calendar;
    iget-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mBListenTimeZoneChanged:Z

    if-eqz v1, :cond_a

    .line 398
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v0

    .line 402
    :goto_9
    return-object v0

    .line 400
    :cond_a
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->tz:Ljava/util/TimeZone;

    invoke-static {v1}, Ljava/util/Calendar;->getInstance(Ljava/util/TimeZone;)Ljava/util/Calendar;

    move-result-object v0

    goto :goto_9
.end method

.method public getDateFormat()Ljava/lang/String;
    .registers 2

    .prologue
    .line 408
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDateFormat:Ljava/lang/String;

    return-object v0
.end method

.method public getListenTimeZoneChanged()Z
    .registers 2

    .prologue
    .line 382
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mBListenTimeZoneChanged:Z

    return v0
.end method

.method public getTimeZone()Ljava/util/TimeZone;
    .registers 2

    .prologue
    .line 372
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->tz:Ljava/util/TimeZone;

    return-object v0
.end method

.method public init()V
    .registers 4

    .prologue
    .line 103
    iget-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mReceiverRegistered:Z

    if-nez v1, :cond_27

    .line 105
    new-instance v0, Landroid/content/IntentFilter;

    invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V

    .line 106
    .local v0, "filter":Landroid/content/IntentFilter;
    const-string v1, "android.intent.action.TIME_SET"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 107
    const-string v1, "android.intent.action.TIMEZONE_CHANGED"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 108
    const-string v1, "android.intent.action.TIME_TICK"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 109
    const-string v1, "android.intent.action.SCREEN_ON"

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 110
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mContext:Landroid/content/Context;

    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mIntentReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v1, v2, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 111
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mReceiverRegistered:Z

    .line 113
    .end local v0    # "filter":Landroid/content/IntentFilter;
    :cond_27
    return-void
.end method

.method public is24HourFormat()Z
    .registers 2

    .prologue
    .line 424
    sget-boolean v0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mB24hourFormat:Z

    return v0
.end method

.method public isPaused()Z
    .registers 2

    .prologue
    .line 284
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mPaused:Z

    return v0
.end method

.method public isPreparedFlip()Z
    .registers 2

    .prologue
    .line 368
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mFlipAnimePrepared:Z

    return v0
.end method

.method public isSimExist()Z
    .registers 5

    .prologue
    const/4 v3, 0x1

    .line 460
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->m_telephonyManager:Landroid/telephony/TelephonyManager;

    if-nez v1, :cond_11

    .line 461
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mContext:Landroid/content/Context;

    const-string v2, "phone"

    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/telephony/TelephonyManager;

    iput-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->m_telephonyManager:Landroid/telephony/TelephonyManager;

    .line 464
    :cond_11
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->m_telephonyManager:Landroid/telephony/TelephonyManager;

    invoke-virtual {v1}, Landroid/telephony/TelephonyManager;->getSimState()I

    move-result v0

    .line 465
    .local v0, "simState":I
    if-eq v0, v3, :cond_1b

    if-nez v0, :cond_1d

    .line 467
    :cond_1b
    const/4 v1, 0x0

    .line 469
    :goto_1c
    return v1

    :cond_1d
    move v1, v3

    goto :goto_1c
.end method

.method public isTimeAutoState()Z
    .registers 5

    .prologue
    const/4 v3, 0x1

    .line 450
    :try_start_1
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mContext:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const-string v2, "auto_time"

    invoke-static {v1, v2}, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;)I
    :try_end_c
    .catch Landroid/provider/Settings$SettingNotFoundException; {:try_start_1 .. :try_end_c} :catch_13

    move-result v1

    if-lez v1, :cond_11

    move v1, v3

    .line 453
    :goto_10
    return v1

    .line 450
    :cond_11
    const/4 v1, 0x0

    goto :goto_10

    .line 452
    :catch_13
    move-exception v1

    move-object v0, v1

    .local v0, "snfe":Landroid/provider/Settings$SettingNotFoundException;
    move v1, v3

    .line 453
    goto :goto_10
.end method

.method public isTimezoneAutoSyn()Z
    .registers 2

    .prologue
    .line 445
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->m_bAutoSyn:Z

    return v0
.end method

.method public onTimeChanged()V
    .registers 2

    .prologue
    .line 184
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->onTimeChanged(Z)V

    .line 185
    return-void
.end method

.method public onTimeChanged(Z)V
    .registers 6
    .param p1, "bUseAnimation"    # Z

    .prologue
    const-string v3, "onTimeChanged~ mHour:"

    const-string v2, " mMinutes:"

    .line 188
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mPaused:Z

    if-eqz v0, :cond_d

    .line 189
    const-string v0, "onTimeChanged~ mPaused is true"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->w(Ljava/lang/String;)V

    .line 193
    :cond_d
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    if-nez v0, :cond_16

    .line 194
    const-string v0, "onTimeChanged mCalendar null"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->w(Ljava/lang/String;)V

    .line 199
    :cond_16
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->updateCurrentTime()V

    .line 200
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldHour:I

    if-ne v0, v1, :cond_25

    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mMinutes:I

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldMinutes:I

    if-eq v0, v1, :cond_2c

    .line 201
    :cond_25
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldHour:I

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldMinutes:I

    invoke-virtual {p0, v0, v1}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->clearAnimations(II)V

    .line 202
    :cond_2c
    const/4 v0, 0x1

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mMinuteFlipCount:I

    .line 203
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mUseAnimation:Z

    if-nez v0, :cond_6e

    .line 204
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "onTimeChanged~ mHour:"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " mMinutes:"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mMinutes:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 205
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_6d

    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_6d

    .line 206
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setCurrentNumber(I)V

    .line 207
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mMinutes:I

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setCurrentNumber(I)V

    .line 223
    :cond_6d
    :goto_6d
    return-void

    .line 211
    :cond_6e
    if-eqz p1, :cond_74

    .line 213
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->applyRotationTest()V

    goto :goto_6d

    .line 215
    :cond_74
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "onTimeChanged~ mHour:"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " mMinutes:"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mMinutes:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 217
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_6d

    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_6d

    .line 218
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setCurrentNumber(I)V

    .line 219
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mMinutes:I

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setCurrentNumber(I)V

    goto :goto_6d
.end method

.method public prepareAnimation()V
    .registers 6

    .prologue
    const/16 v4, 0x9

    const/16 v3, 0xc

    const/4 v2, 0x1

    .line 329
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mUseAnimation:Z

    if-nez v0, :cond_a

    .line 365
    :goto_9
    return-void

    .line 331
    :cond_a
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->clearAnimations()V

    .line 332
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->getCalendarNow()Ljava/util/Calendar;

    move-result-object v0

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    .line 334
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    invoke-virtual {v0, v3}, Ljava/util/Calendar;->get(I)I

    move-result v0

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mMinutes:I

    .line 335
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    const/16 v1, 0xa

    invoke-virtual {v0, v1}, Ljava/util/Calendar;->get(I)I

    move-result v0

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    .line 337
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->is24HourFormat()Z

    move-result v0

    if-eqz v0, :cond_97

    .line 338
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    invoke-virtual {v0, v4}, Ljava/util/Calendar;->get(I)I

    move-result v0

    if-ne v0, v2, :cond_39

    .line 339
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    add-int/lit8 v0, v0, 0xc

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    .line 340
    :cond_39
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_43

    .line 341
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setAmPm(I)V

    .line 343
    :cond_43
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    add-int/lit8 v0, v0, 0x18

    sub-int/2addr v0, v2

    rem-int/lit8 v0, v0, 0x18

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldHour:I

    .line 355
    :cond_4c
    :goto_4c
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->setData()V

    .line 357
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mMinutes:I

    add-int/lit8 v0, v0, 0x3c

    const/4 v1, 0x2

    sub-int/2addr v0, v1

    rem-int/lit8 v0, v0, 0x3c

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldMinutes:I

    .line 358
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_6f

    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_6f

    .line 359
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldHour:I

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setCurrentNumber(I)V

    .line 360
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldMinutes:I

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setCurrentNumber(I)V

    .line 362
    :cond_6f
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "prepareAnimation~ mOldHour:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldHour:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " mOldMinutes:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldMinutes:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 364
    iput-boolean v2, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mFlipAnimePrepared:Z

    goto/16 :goto_9

    .line 345
    :cond_97
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    if-nez v0, :cond_9d

    .line 346
    iput v3, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    .line 347
    :cond_9d
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_ac

    .line 348
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    invoke-virtual {v1, v4}, Ljava/util/Calendar;->get(I)I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setAmPm(I)V

    .line 350
    :cond_ac
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    add-int/lit8 v0, v0, 0xc

    sub-int/2addr v0, v2

    rem-int/lit8 v0, v0, 0xc

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldHour:I

    .line 351
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldHour:I

    if-nez v0, :cond_4c

    .line 352
    iput v3, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldHour:I

    goto :goto_4c
.end method

.method public printLog()V
    .registers 2

    .prologue
    .line 389
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mTimeZoneChangedLog:Ljava/lang/StringBuffer;

    if-eqz v0, :cond_d

    .line 390
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mTimeZoneChangedLog:Ljava/lang/StringBuffer;

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 392
    :cond_d
    return-void
.end method

.method public setData()V
    .registers 4

    .prologue
    .line 136
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Data:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v2, :cond_19

    .line 138
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->getDateFormat()Ljava/lang/String;

    move-result-object v0

    .line 139
    .local v0, "format":Ljava/lang/String;
    if-eqz v0, :cond_19

    .line 140
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    invoke-static {v0, v2}, Landroid/text/format/DateFormat;->format(Ljava/lang/CharSequence;Ljava/util/Calendar;)Ljava/lang/CharSequence;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    .line 141
    .local v1, "text":Ljava/lang/String;
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Data:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v2, v1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 144
    .end local v0    # "format":Ljava/lang/String;
    .end local v1    # "text":Ljava/lang/String;
    :cond_19
    return-void
.end method

.method public setListenTimeZoneChanged(Z)V
    .registers 2
    .param p1, "bListen"    # Z

    .prologue
    .line 378
    iput-boolean p1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mBListenTimeZoneChanged:Z

    .line 379
    return-void
.end method

.method public setPause(Z)V
    .registers 3
    .param p1, "value"    # Z

    .prologue
    .line 269
    const/4 v0, 0x1

    invoke-virtual {p0, p1, v0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->setPause(ZZ)V

    .line 270
    return-void
.end method

.method public setPause(ZZ)V
    .registers 5
    .param p1, "value"    # Z
    .param p2, "bTimeChanged"    # Z

    .prologue
    .line 273
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "setPause~ mPaused:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 274
    iput-boolean p1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mPaused:Z

    .line 275
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mPaused:Z

    if-eqz v0, :cond_1d

    .line 281
    :cond_1c
    :goto_1c
    return-void

    .line 277
    :cond_1d
    if-eqz p2, :cond_1c

    .line 278
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->onTimeChanged()V

    goto :goto_1c
.end method

.method public setTimeZone(Ljava/lang/String;)V
    .registers 4
    .param p1, "timezone"    # Ljava/lang/String;

    .prologue
    .line 227
    monitor-enter p0

    .line 228
    if-eqz p1, :cond_35

    :try_start_3
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_35

    .line 229
    invoke-static {p1}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v0

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->tz:Ljava/util/TimeZone;

    .line 230
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->tz:Ljava/util/TimeZone;

    invoke-static {v0}, Ljava/util/Calendar;->getInstance(Ljava/util/TimeZone;)Ljava/util/Calendar;

    move-result-object v0

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    .line 235
    :goto_17
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "setTimeZone~ time zone id="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->tz:Ljava/util/TimeZone;

    invoke-virtual {v1}, Ljava/util/TimeZone;->getID()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 236
    monitor-exit p0

    .line 237
    return-void

    .line 232
    :cond_35
    invoke-static {}, Ljava/util/TimeZone;->getDefault()Ljava/util/TimeZone;

    move-result-object v0

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->tz:Ljava/util/TimeZone;

    .line 233
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v0

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    goto :goto_17

    .line 236
    :catchall_42
    move-exception v0

    monitor-exit p0
    :try_end_44
    .catchall {:try_start_3 .. :try_end_44} :catchall_42

    throw v0
.end method

.method public skinApply()V
    .registers 1

    .prologue
    .line 499
    return-void
.end method

.method public startAnimation()V
    .registers 2

    .prologue
    .line 288
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->startAnimation(Z)V

    .line 289
    return-void
.end method

.method public startAnimation(Z)V
    .registers 6
    .param p1, "bPause"    # Z

    .prologue
    const/16 v3, 0xc

    const/16 v2, 0x9

    .line 292
    iput-boolean p1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mPaused:Z

    .line 293
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mUseAnimation:Z

    if-nez v0, :cond_b

    .line 326
    :goto_a
    return-void

    .line 295
    :cond_b
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mFlipAnimePrepared:Z

    if-nez v0, :cond_13

    .line 296
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->onTimeChanged()V

    goto :goto_a

    .line 299
    :cond_13
    const-string v0, "startAnimation~"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 301
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->getCalendarNow()Ljava/util/Calendar;

    move-result-object v0

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    .line 303
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    invoke-virtual {v0, v3}, Ljava/util/Calendar;->get(I)I

    move-result v0

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mMinutes:I

    .line 304
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    const/16 v1, 0xa

    invoke-virtual {v0, v1}, Ljava/util/Calendar;->get(I)I

    move-result v0

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    .line 306
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->is24HourFormat()Z

    move-result v0

    if-eqz v0, :cond_5c

    .line 307
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    invoke-virtual {v0, v2}, Ljava/util/Calendar;->get(I)I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_45

    .line 308
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    add-int/lit8 v0, v0, 0xc

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    .line 309
    :cond_45
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_4f

    .line 310
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setAmPm(I)V

    .line 319
    :cond_4f
    :goto_4f
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->setData()V

    .line 321
    const/4 v0, 0x2

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mMinuteFlipCount:I

    .line 324
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->applyRotation()V

    .line 325
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mFlipAnimePrepared:Z

    goto :goto_a

    .line 313
    :cond_5c
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    if-nez v0, :cond_62

    .line 314
    iput v3, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    .line 315
    :cond_62
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_4f

    .line 316
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    invoke-virtual {v1, v2}, Ljava/util/Calendar;->get(I)I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setAmPm(I)V

    goto :goto_4f
.end method

.method public testAnimation()V
    .registers 2

    .prologue
    .line 248
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->clearAnimations()V

    .line 249
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldHour:I

    .line 250
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mMinutes:I

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldMinutes:I

    .line 252
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mMinutes:I

    add-int/lit8 v0, v0, 0x1

    rem-int/lit8 v0, v0, 0x3c

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mMinutes:I

    .line 254
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mMinutes:I

    rem-int/lit8 v0, v0, 0x3

    if-nez v0, :cond_1c

    .line 255
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->increaseHour()V

    .line 258
    :cond_1c
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->applyRotation()V

    .line 259
    return-void
.end method

.method public update24HourFormat()V
    .registers 2

    .prologue
    .line 428
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mContext:Landroid/content/Context;

    invoke-static {v0}, Landroid/text/format/DateFormat;->is24HourFormat(Landroid/content/Context;)Z

    move-result v0

    sput-boolean v0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mB24hourFormat:Z

    .line 429
    return-void
.end method

.method updateCurrentTime()V
    .registers 6

    .prologue
    const/16 v4, 0xc

    const/16 v3, 0x9

    .line 147
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldHour:I

    .line 148
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mMinutes:I

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mOldMinutes:I

    .line 150
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->getCalendarNow()Ljava/util/Calendar;

    move-result-object v0

    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    .line 151
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Ljava/util/Calendar;->setTimeInMillis(J)V

    .line 153
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    invoke-virtual {v0, v4}, Ljava/util/Calendar;->get(I)I

    move-result v0

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mMinutes:I

    .line 154
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    const/16 v1, 0xa

    invoke-virtual {v0, v1}, Ljava/util/Calendar;->get(I)I

    move-result v0

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    .line 156
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->is24HourFormat()Z

    move-result v0

    if-eqz v0, :cond_50

    .line 157
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    invoke-virtual {v0, v3}, Ljava/util/Calendar;->get(I)I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_42

    .line 158
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    add-int/lit8 v0, v0, 0xc

    iput v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    .line 159
    :cond_42
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_4c

    .line 160
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setAmPm(I)V

    .line 170
    :cond_4c
    :goto_4c
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->setData()V

    .line 171
    return-void

    .line 163
    :cond_50
    iget v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    if-nez v0, :cond_56

    .line 164
    iput v4, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mHour:I

    .line 165
    :cond_56
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_4c

    .line 166
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mCalendar:Ljava/util/Calendar;

    invoke-virtual {v1, v3}, Ljava/util/Calendar;->get(I)I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setAmPm(I)V

    goto :goto_4c
.end method

.method public updateDateFormat()V
    .registers 4

    .prologue
    .line 412
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mContext:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const-string v2, "date_format_short"

    invoke-static {v1, v2}, Landroid/provider/Settings$System;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 415
    .local v0, "format":Ljava/lang/String;
    if-eqz v0, :cond_16

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_16

    .line 416
    iput-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mDateFormat:Ljava/lang/String;

    .line 418
    :cond_16
    return-void
.end method

.method public updateFormat()V
    .registers 2

    .prologue
    .line 432
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->updateDateFormat()V

    .line 433
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->update24HourFormat()V

    .line 434
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mBUpdateFomate:Z

    .line 435
    return-void
.end method
