.class Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$UIHandler;
.super Ljava/lang/Object;
.source "HtcDigitalClock42View.java"

# interfaces
.implements Landroid/os/Handler$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "UIHandler"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;


# direct methods
.method private constructor <init>(Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;)V
    .registers 2

    .prologue
    .line 58
    iput-object p1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$UIHandler;->this$0:Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$1;)V
    .registers 3
    .param p1, "x0"    # Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;
    .param p2, "x1"    # Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$1;

    .prologue
    .line 58
    invoke-direct {p0, p1}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$UIHandler;-><init>(Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;)V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)Z
    .registers 8
    .param p1, "m"    # Landroid/os/Message;

    .prologue
    const/4 v5, 0x0

    .line 60
    iget-object v1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v1, Landroid/content/Intent;

    .line 61
    .local v1, "intent":Landroid/content/Intent;
    if-nez v1, :cond_9

    move v3, v5

    .line 89
    :goto_8
    return v3

    .line 65
    :cond_9
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$UIHandler;->this$0:Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;

    iget-object v3, v3, Lcom/htc/clock3dwidget/weatherclock/WeatherView;->mContext:Landroid/content/Context;

    const-string v4, "power"

    invoke-virtual {v3, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/os/PowerManager;

    .line 66
    .local v2, "pm":Landroid/os/PowerManager;
    invoke-virtual {v1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v3

    const-string v4, "android.intent.action.TIME_TICK"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_29

    invoke-virtual {v2}, Landroid/os/PowerManager;->isScreenOn()Z

    move-result v3

    if-nez v3, :cond_29

    move v3, v5

    .line 67
    goto :goto_8

    .line 71
    :cond_29
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "weatherClock onReceive~ action:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " mPaused:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$UIHandler;->this$0:Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;

    iget-boolean v4, v4, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mPaused:Z

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 72
    invoke-virtual {v1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v3

    const-string v4, "android.intent.action.TIMEZONE_CHANGED"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_88

    .line 73
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "receive ACTION_TIMEZONE_CHANGED mBListenTimeZoneChanged:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$UIHandler;->this$0:Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;

    iget-boolean v4, v4, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mBListenTimeZoneChanged:Z

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 75
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$UIHandler;->this$0:Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;

    iget-boolean v3, v3, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mBListenTimeZoneChanged:Z

    if-eqz v3, :cond_88

    .line 76
    const-string v3, "time-zone"

    invoke-virtual {v1, v3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 77
    .local v0, "changeTz":Ljava/lang/String;
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$UIHandler;->this$0:Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;

    invoke-virtual {v3, v0}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->setTimeZone(Ljava/lang/String;)V

    .line 82
    .end local v0    # "changeTz":Ljava/lang/String;
    :cond_88
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$UIHandler;->this$0:Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;

    invoke-static {v3}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->access$100(Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;)Z

    move-result v3

    if-eqz v3, :cond_95

    .line 83
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$UIHandler;->this$0:Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;

    invoke-virtual {v3}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->prepareAnimation()V

    .line 86
    :cond_95
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$UIHandler;->this$0:Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;

    iget-boolean v3, v3, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mPaused:Z

    if-nez v3, :cond_a0

    .line 87
    iget-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$UIHandler;->this$0:Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;

    invoke-virtual {v3}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->onTimeChanged()V

    .line 89
    :cond_a0
    const/4 v3, 0x1

    goto/16 :goto_8
.end method
