.class Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$1;
.super Landroid/content/BroadcastReceiver;
.source "HtcDigitalClock42View.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;


# direct methods
.method constructor <init>(Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;)V
    .registers 2

    .prologue
    .line 93
    iput-object p1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$1;->this$0:Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 5
    .param p1, "context"    # Landroid/content/Context;
    .param p2, "intent"    # Landroid/content/Intent;

    .prologue
    .line 96
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$1;->this$0:Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mUIHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->access$200(Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    move-result-object v1

    invoke-interface {v1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->obtainMessage()Landroid/os/Message;

    move-result-object v0

    .line 97
    .local v0, "msg":Landroid/os/Message;
    iput-object p2, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 98
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View$1;->this$0:Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->mUIHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;->access$200(Lcom/htc/clock3dwidget/weatherclock/HtcDigitalClock42View;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    move-result-object v1

    invoke-interface {v1, v0}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->send(Landroid/os/Message;)V

    .line 99
    return-void
.end method
