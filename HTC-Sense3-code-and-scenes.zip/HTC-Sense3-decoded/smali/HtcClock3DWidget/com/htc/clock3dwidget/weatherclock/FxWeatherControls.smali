.class public Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;
.super Ljava/lang/Object;
.source "FxWeatherControls.java"


# static fields
.field private static final HOUR:Ljava/lang/String; = "timeline.flip_hour"

.field private static final MIN:Ljava/lang/String; = "timeline.flip_minute"

.field private static final TILT:Ljava/lang/String; = "timeline.tiltanim"


# instance fields
.field API_level:I

.field public mCityRest:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mCityRestText:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field public mCityView:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field public mConditionLength:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mConditionView:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field public mDigital_Data:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field public mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

.field public mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

.field public mFxHitboxClock:Lcom/htc/fusion/fx/controls/FxHitbox;

.field public mFxHitboxWeather:Lcom/htc/fusion/fx/controls/FxHitbox;

.field public mFxTextIndH:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field public mFxTextIndL:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field public mHTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field public mHourCap:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mImgToday:Lcom/htc/fusion/fx/controls/FxSceneContainer;

.field public mLTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field public mMarkerHour:Lcom/htc/fusion/fx/Marker;

.field public mMarkerMin:Lcom/htc/fusion/fx/Marker;

.field public mMinCap:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mNoWeatherView:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field public mTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field public mTileMark:Lcom/htc/fusion/fx/Marker;

.field public mTiltAnime:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mTodayAnimation:Lcom/htc/fusion/fx/FxScene;

.field public mWeatherType:Lcom/htc/fusion/fx/FxTimelineControl;


# direct methods
.method public constructor <init>(Lcom/htc/fusion/fx/FxScene;)V
    .registers 11
    .param p1, "scene"    # Lcom/htc/fusion/fx/FxScene;

    .prologue
    const/4 v8, 0x2

    const/16 v6, 0xb

    const/4 v5, 0x0

    const/4 v4, 0x1

    const-string v7, "tilt"

    .line 51
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 48
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    iput v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->API_level:I

    .line 52
    const/16 v2, 0x15

    new-array v0, v2, [Ljava/lang/String;

    const-string v2, "button.clock.hitbox"

    aput-object v2, v0, v5

    const-string v2, "button.weather.hitbox"

    aput-object v2, v0, v4

    const-string v2, "timeline.flip_minute"

    aput-object v2, v0, v8

    const/4 v2, 0x3

    const-string v3, "timeline.flip_hour"

    aput-object v3, v0, v2

    const/4 v2, 0x4

    const-string v3, "textlabel.weatherclock_cityname"

    aput-object v3, v0, v2

    const/4 v2, 0x5

    const-string v3, "textlabel.weatherclock_weather"

    aput-object v3, v0, v2

    const/4 v2, 0x6

    const-string v3, "textlabel.weatherclock_noweather"

    aput-object v3, v0, v2

    const/4 v2, 0x7

    const-string v3, "textlabel.weatherclock_date"

    aput-object v3, v0, v2

    const/16 v2, 0x8

    const-string v3, "textlabel.weatherclock_todaytemp"

    aput-object v3, v0, v2

    const/16 v2, 0x9

    const-string v3, "textlabel.weatherclock_H"

    aput-object v3, v0, v2

    const/16 v2, 0xa

    const-string v3, "textlabel.weatherclock_L"

    aput-object v3, v0, v2

    const-string v2, "textlabel.weatherclock_tempHi"

    aput-object v2, v0, v6

    const/16 v2, 0xc

    const-string v3, "textlabel.weatherclock_templow"

    aput-object v3, v0, v2

    const/16 v2, 0xd

    const-string v3, "scenecontainer.forecast_weather_state"

    aput-object v3, v0, v2

    const/16 v2, 0xe

    const-string v3, "timeline.tiltanim"

    aput-object v3, v0, v2

    const/16 v2, 0xf

    const-string v3, "timeline.flip_hour"

    aput-object v3, v0, v2

    const/16 v2, 0x10

    const-string v3, "timeline.flip_minute"

    aput-object v3, v0, v2

    const/16 v2, 0x11

    const-string v3, "timeline.info"

    aput-object v3, v0, v2

    const/16 v2, 0x12

    const-string v3, "textlabel.info"

    aput-object v3, v0, v2

    const/16 v2, 0x13

    const-string v3, "timeline.weather_type"

    aput-object v3, v0, v2

    const/16 v2, 0x14

    const-string v3, "timeline.city_name"

    aput-object v3, v0, v2

    .line 63
    .local v0, "controls":[Ljava/lang/String;
    invoke-virtual {p1, v0}, Lcom/htc/fusion/fx/FxScene;->getDescendants([Ljava/lang/String;)[Lcom/htc/fusion/fx/FxObject;

    move-result-object v1

    check-cast v1, [Lcom/htc/fusion/fx/FxObject;

    .line 65
    .local v1, "objs":[Lcom/htc/fusion/fx/FxObject;
    aget-object v2, v1, v5

    check-cast v2, Lcom/htc/fusion/fx/controls/FxHitbox;

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mFxHitboxClock:Lcom/htc/fusion/fx/controls/FxHitbox;

    .line 66
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mFxHitboxClock:Lcom/htc/fusion/fx/controls/FxHitbox;

    invoke-virtual {v2, v4}, Lcom/htc/fusion/fx/controls/FxHitbox;->setEnabled(Z)V

    .line 67
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mFxHitboxClock:Lcom/htc/fusion/fx/controls/FxHitbox;

    invoke-virtual {v2, v4}, Lcom/htc/fusion/fx/controls/FxHitbox;->setEnabledGestures(I)V

    .line 69
    aget-object v2, v1, v4

    check-cast v2, Lcom/htc/fusion/fx/controls/FxHitbox;

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mFxHitboxWeather:Lcom/htc/fusion/fx/controls/FxHitbox;

    .line 70
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mFxHitboxWeather:Lcom/htc/fusion/fx/controls/FxHitbox;

    invoke-virtual {v2, v4}, Lcom/htc/fusion/fx/controls/FxHitbox;->setEnabled(Z)V

    .line 71
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mFxHitboxWeather:Lcom/htc/fusion/fx/controls/FxHitbox;

    invoke-virtual {v2, v4}, Lcom/htc/fusion/fx/controls/FxHitbox;->setEnabledGestures(I)V

    .line 73
    new-instance v3, Lcom/htc/clock3dwidget/util/DigitControl;

    aget-object v2, v1, v8

    check-cast v2, Lcom/htc/fusion/fx/FxTimelineControl;

    const/16 v4, 0x3c

    invoke-direct {v3, v2, v4}, Lcom/htc/clock3dwidget/util/DigitControl;-><init>(Lcom/htc/fusion/fx/FxTimelineControl;I)V

    iput-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    .line 74
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    const/4 v3, -0x1

    invoke-virtual {v2, v3}, Lcom/htc/clock3dwidget/util/DigitControl;->setAmPm(I)V

    .line 75
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    invoke-virtual {v2, v5}, Lcom/htc/clock3dwidget/util/DigitControl;->setCurrentNumber(I)V

    .line 77
    new-instance v3, Lcom/htc/clock3dwidget/util/DigitControl;

    const/4 v2, 0x3

    aget-object v2, v1, v2

    check-cast v2, Lcom/htc/fusion/fx/FxTimelineControl;

    const/16 v4, 0x18

    invoke-direct {v3, v2, v4}, Lcom/htc/clock3dwidget/util/DigitControl;-><init>(Lcom/htc/fusion/fx/FxTimelineControl;I)V

    iput-object v3, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    .line 78
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    invoke-virtual {v2, v5}, Lcom/htc/clock3dwidget/util/DigitControl;->setCurrentNumber(I)V

    .line 80
    const/4 v2, 0x4

    aget-object v2, v1, v2

    check-cast v2, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mCityView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 82
    const/4 v2, 0x5

    aget-object v2, v1, v2

    check-cast v2, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mConditionView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 83
    const/4 v2, 0x6

    aget-object v2, v1, v2

    check-cast v2, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mNoWeatherView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 84
    const/4 v2, 0x7

    aget-object v2, v1, v2

    check-cast v2, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mDigital_Data:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 85
    const/16 v2, 0x8

    aget-object v2, v1, v2

    check-cast v2, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 86
    const/16 v2, 0x9

    aget-object v2, v1, v2

    check-cast v2, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mFxTextIndH:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 87
    const/16 v2, 0xa

    aget-object v2, v1, v2

    check-cast v2, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mFxTextIndL:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 88
    aget-object v2, v1, v6

    check-cast v2, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mHTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 89
    const/16 v2, 0xc

    aget-object v2, v1, v2

    check-cast v2, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mLTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 90
    const/16 v2, 0xd

    aget-object v2, v1, v2

    check-cast v2, Lcom/htc/fusion/fx/controls/FxSceneContainer;

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mImgToday:Lcom/htc/fusion/fx/controls/FxSceneContainer;

    .line 92
    const/16 v2, 0xe

    aget-object v2, v1, v2

    check-cast v2, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mTiltAnime:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 93
    iget v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->API_level:I

    if-lt v2, v6, :cond_12a

    .line 95
    :cond_12a
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mTiltAnime:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v2, :cond_138

    .line 96
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mTiltAnime:Lcom/htc/fusion/fx/FxTimelineControl;

    const-string v3, "tilt"

    invoke-virtual {v2, v7}, Lcom/htc/fusion/fx/FxTimelineControl;->getMarker(Ljava/lang/String;)Lcom/htc/fusion/fx/Marker;

    move-result-object v2

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mTileMark:Lcom/htc/fusion/fx/Marker;

    .line 99
    :cond_138
    const/16 v2, 0xf

    aget-object v2, v1, v2

    check-cast v2, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mHourCap:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 100
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mHourCap:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v2, :cond_14e

    .line 101
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mHourCap:Lcom/htc/fusion/fx/FxTimelineControl;

    const-string v3, "tilt"

    invoke-virtual {v2, v7}, Lcom/htc/fusion/fx/FxTimelineControl;->getMarker(Ljava/lang/String;)Lcom/htc/fusion/fx/Marker;

    move-result-object v2

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mMarkerHour:Lcom/htc/fusion/fx/Marker;

    .line 104
    :cond_14e
    const/16 v2, 0x10

    aget-object v2, v1, v2

    check-cast v2, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mMinCap:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 105
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mMinCap:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v2, :cond_164

    .line 106
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mMinCap:Lcom/htc/fusion/fx/FxTimelineControl;

    const-string v3, "tilt"

    invoke-virtual {v2, v7}, Lcom/htc/fusion/fx/FxTimelineControl;->getMarker(Ljava/lang/String;)Lcom/htc/fusion/fx/Marker;

    move-result-object v2

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mMarkerMin:Lcom/htc/fusion/fx/Marker;

    .line 109
    :cond_164
    const/16 v2, 0x11

    aget-object v2, v1, v2

    check-cast v2, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mCityRest:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 111
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mCityRest:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v2, :cond_175

    .line 112
    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mCityRest:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v2, v5}, Lcom/htc/fusion/fx/FxTimelineControl;->setVisibility(Z)Ljava/util/ArrayList;

    .line 114
    :cond_175
    const/16 v2, 0x12

    aget-object v2, v1, v2

    check-cast v2, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mCityRestText:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 116
    const/16 v2, 0x13

    aget-object v2, v1, v2

    check-cast v2, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mWeatherType:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 118
    invoke-direct {p0}, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->reset()V

    .line 119
    return-void
.end method

.method private reset()V
    .registers 4

    .prologue
    const-string v2, ""

    .line 122
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mConditionView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_d

    .line 123
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mConditionView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const-string v1, ""

    invoke-virtual {v0, v2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 126
    :cond_d
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mDigital_Data:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_18

    .line 127
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mDigital_Data:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const-string v1, ""

    invoke-virtual {v0, v2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 130
    :cond_18
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mFxTextIndH:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_23

    .line 131
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mFxTextIndH:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const-string v1, ""

    invoke-virtual {v0, v2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 134
    :cond_23
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mFxTextIndL:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_2e

    .line 135
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mFxTextIndL:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const-string v1, ""

    invoke-virtual {v0, v2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 138
    :cond_2e
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mHTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_39

    .line 139
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mHTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const-string v1, ""

    invoke-virtual {v0, v2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 142
    :cond_39
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mLTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_44

    .line 143
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mLTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const-string v1, ""

    invoke-virtual {v0, v2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 146
    :cond_44
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_4f

    .line 147
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mTempView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const-string v1, ""

    invoke-virtual {v0, v2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 150
    :cond_4f
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mCityView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_5a

    .line 151
    iget-object v0, p0, Lcom/htc/clock3dwidget/weatherclock/FxWeatherControls;->mCityView:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const-string v1, ""

    invoke-virtual {v0, v2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 153
    :cond_5a
    return-void
.end method
