.class Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;
.super Ljava/lang/Object;
.source "WeatherClockWidgetView.java"

# interfaces
.implements Landroid/os/Handler$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;


# direct methods
.method constructor <init>(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)V
    .registers 2

    .prologue
    .line 998
    iput-object p1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)Z
    .registers 9
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    const v6, 0x8020

    const/4 v5, 0x1

    const/4 v4, 0x0

    .line 1000
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->isWidgetOnResume()Z

    move-result v1

    if-nez v1, :cond_40

    iget v1, p1, Landroid/os/Message;->what:I

    const v2, 0x8019

    if-eq v1, v2, :cond_40

    iget v1, p1, Landroid/os/Message;->what:I

    if-eq v1, v6, :cond_40

    iget v1, p1, Landroid/os/Message;->what:I

    const v2, 0x8001

    if-eq v1, v2, :cond_40

    iget v1, p1, Landroid/os/Message;->what:I

    const v2, 0x8021

    if-eq v1, v2, :cond_40

    .line 1004
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "handleUiMessage~ in pause. msg:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p1, Landroid/os/Message;->what:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/htc/clock/util/MyLog;->w(Ljava/lang/String;)V

    move v1, v4

    .line 1085
    :goto_3f
    return v1

    .line 1008
    :cond_40
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->isWidgetDestroy()Z

    move-result v1

    if-eqz v1, :cond_4f

    .line 1009
    const-string v1, "weather clock handleMessage~ widget destroied"

    invoke-static {v1}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    move v1, v4

    .line 1010
    goto :goto_3f

    .line 1013
    :cond_4f
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v1

    if-eqz v1, :cond_5f

    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v1

    if-nez v1, :cond_61

    :cond_5f
    move v1, v4

    .line 1014
    goto :goto_3f

    .line 1017
    :cond_61
    iget v1, p1, Landroid/os/Message;->what:I

    sparse-switch v1, :sswitch_data_1a8

    :cond_66
    :goto_66
    move v1, v5

    .line 1085
    goto :goto_3f

    .line 1019
    :sswitch_68
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v1

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->onTimeChanged()V

    goto :goto_66

    .line 1022
    :sswitch_72
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v1

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->onTimeChanged()V

    goto :goto_66

    .line 1025
    :sswitch_7c
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v1

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->uiStartTodayAnimation()V

    goto :goto_66

    .line 1028
    :sswitch_86
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v1

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->clearAnimations()V

    .line 1029
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v1

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->uiStopTodayAnimation()V

    goto :goto_66

    .line 1032
    :sswitch_99
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBChangeTimeZone:Z
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$1600(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Z

    move-result v1

    if-eqz v1, :cond_ab

    .line 1033
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # setter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBChangeTimeZone:Z
    invoke-static {v1, v4}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$1602(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Z)Z

    .line 1034
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->checkClockTimeZone()V

    .line 1036
    :cond_ab
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v1

    iget-boolean v1, v1, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->mUseAnimation:Z

    if-eqz v1, :cond_d0

    .line 1037
    iget v1, p1, Landroid/os/Message;->arg2:I

    if-ne v1, v5, :cond_c6

    .line 1038
    const-string v1, "MSG_ON_RESUME~ need to delay"

    invoke-static {v1}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 1039
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    const-wide/16 v2, 0x3e8

    invoke-virtual {v1, v6, v2, v3}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->sendUiMessageDelayed(IJ)V

    goto :goto_66

    .line 1041
    :cond_c6
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v1

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->startAnimation()V

    goto :goto_66

    .line 1044
    :cond_d0
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v1

    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBoolAppResume:Z
    invoke-static {v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$700(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Z

    move-result v2

    if-nez v2, :cond_e3

    move v2, v5

    :goto_df
    invoke-virtual {v1, v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->setPause(Z)V

    goto :goto_66

    :cond_e3
    move v2, v4

    goto :goto_df

    .line 1048
    :sswitch_e5
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v1

    iget-boolean v1, v1, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->mUseAnimation:Z

    if-eqz v1, :cond_66

    .line 1049
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v1

    iget-object v2, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBoolAppResume:Z
    invoke-static {v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$700(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Z

    move-result v2

    if-nez v2, :cond_103

    move v2, v5

    :goto_fe
    invoke-virtual {v1, v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->startAnimation(Z)V

    goto/16 :goto_66

    :cond_103
    move v2, v4

    goto :goto_fe

    .line 1053
    :sswitch_105
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v1

    if-eqz v1, :cond_66

    .line 1054
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v1

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->prepareAnimation()V

    goto/16 :goto_66

    .line 1057
    :sswitch_118
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v1

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->uiUpdate()V

    goto/16 :goto_66

    .line 1060
    :sswitch_123
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v1

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->uiUpdateTempUnit()V

    goto/16 :goto_66

    .line 1063
    :sswitch_12e
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v1

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->startAnimation()V

    goto/16 :goto_66

    .line 1067
    :sswitch_139
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # invokes: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getPosition()[I
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$2200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)[I

    move-result-object v0

    .line 1068
    .local v0, "pos":[I
    if-eqz v0, :cond_178

    .line 1069
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "getPosition(x,y)= ("

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    aget v2, v0, v4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ","

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    aget v2, v0, v5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ")"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 1070
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v1

    aget v2, v0, v4

    aget v3, v0, v5

    invoke-virtual {v1, v2, v3}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->setPosition(II)V

    .line 1072
    :cond_178
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v1

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->uiStartWWPAnimation()V

    .line 1073
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # setter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mbPlayWWPAtAdd:Z
    invoke-static {v1, v4}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$2302(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Z)Z

    .line 1074
    # setter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mbPlayWWPAtRosieStart:Z
    invoke-static {v4}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$2402(Z)Z

    goto/16 :goto_66

    .line 1077
    .end local v0    # "pos":[I
    :sswitch_18b
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # setter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBChangeTimeZone:Z
    invoke-static {v1, v4}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$1602(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Z)Z

    .line 1078
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->checkClockTimeZone()V

    .line 1079
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v1

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->onTimeChanged()V

    goto/16 :goto_66

    .line 1082
    :sswitch_1a0
    iget-object v1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$4;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    const/4 v2, 0x0

    # invokes: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->switchToNewCity(ZLandroid/content/Intent;)V
    invoke-static {v1, v5, v2}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$2500(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;ZLandroid/content/Intent;)V

    goto/16 :goto_66

    .line 1017
    :sswitch_data_1a8
    .sparse-switch
        0x8001 -> :sswitch_99
        0x8009 -> :sswitch_7c
        0x800a -> :sswitch_86
        0x800c -> :sswitch_12e
        0x8012 -> :sswitch_18b
        0x8013 -> :sswitch_139
        0x8014 -> :sswitch_118
        0x8015 -> :sswitch_123
        0x8016 -> :sswitch_72
        0x8019 -> :sswitch_105
        0x8020 -> :sswitch_e5
        0x8021 -> :sswitch_1a0
        0x9003 -> :sswitch_68
    .end sparse-switch
.end method
