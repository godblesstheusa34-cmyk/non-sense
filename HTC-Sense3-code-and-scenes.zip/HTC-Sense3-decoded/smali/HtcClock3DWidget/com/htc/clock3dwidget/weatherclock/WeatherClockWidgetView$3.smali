.class Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;
.super Ljava/lang/Object;
.source "WeatherClockWidgetView.java"

# interfaces
.implements Landroid/os/Handler$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;


# direct methods
.method constructor <init>(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)V
    .registers 2

    .prologue
    .line 810
    iput-object p1, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)Z
    .registers 13
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    const/4 v8, 0x0

    const/4 v10, 0x1

    .line 812
    iget v6, p1, Landroid/os/Message;->what:I

    if-ne v6, v10, :cond_b

    .line 813
    const-string v6, "weatherClock handleMessage~ help to check lock"

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 815
    :cond_b
    monitor-enter p0

    .line 816
    :try_start_c
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    invoke-virtual {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->isWidgetDestroy()Z

    move-result v6

    if-eqz v6, :cond_1c

    .line 817
    const-string v6, "weather clock handleMessage~ widget destroied"

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    .line 818
    monitor-exit p0

    move v6, v8

    .line 993
    :goto_1b
    return v6

    .line 821
    :cond_1c
    iget v6, p1, Landroid/os/Message;->what:I

    sparse-switch v6, :sswitch_data_3aa

    .line 991
    :cond_21
    :goto_21
    monitor-exit p0

    move v6, v10

    .line 993
    goto :goto_1b

    .line 823
    :sswitch_24
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    if-eqz v6, :cond_35

    .line 824
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->updateFormat()V

    .line 825
    :cond_35
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    if-eqz v6, :cond_21

    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    iget-boolean v6, v6, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mPauseByAddToHome:Z

    if-nez v6, :cond_21

    .line 826
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    iget-boolean v6, v6, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->mUseAnimation:Z

    if-eqz v6, :cond_73

    .line 827
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$100(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    move-result-object v6

    const v7, 0x8019

    invoke-interface {v6, v7}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->recall(I)V

    .line 828
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$100(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    move-result-object v6

    invoke-interface {v6}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->obtainMessage()Landroid/os/Message;

    move-result-object v3

    .line 829
    .local v3, "message":Landroid/os/Message;
    const v6, 0x8019

    iput v6, v3, Landroid/os/Message;->what:I

    .line 830
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$100(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    move-result-object v6

    const-wide/16 v7, 0x0

    invoke-interface {v6, v3, v7, v8}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->sendDelayed(Landroid/os/Message;J)V

    .line 832
    .end local v3    # "message":Landroid/os/Message;
    :cond_73
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->isUseWWPAnimation()Z

    move-result v6

    if-eqz v6, :cond_21

    .line 833
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    const/4 v7, 0x1

    # setter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->m_bPlayingWWP:Z
    invoke-static {v6, v7}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$302(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Z)Z

    goto :goto_21

    .line 991
    :catchall_86
    move-exception v6

    monitor-exit p0
    :try_end_88
    .catchall {:try_start_c .. :try_end_88} :catchall_86

    throw v6

    .line 838
    :sswitch_89
    :try_start_89
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "WHAT_ON_RESUME~ notifyCause:"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    iget v7, p1, Landroid/os/Message;->arg1:I

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->d(Ljava/lang/String;)V

    .line 839
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    sget-object v7, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;->RESUME:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;

    # setter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiState:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;
    invoke-static {v6, v7}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$402(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;)Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;

    .line 840
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    iget v7, p1, Landroid/os/Message;->arg1:I

    int-to-long v7, v7

    # setter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mResumeNotifyCaused:J
    invoke-static {v6, v7, v8}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$502(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;J)J

    .line 841
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v7

    # setter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mLastResumeTime:J
    invoke-static {v6, v7, v8}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$602(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;J)J

    .line 842
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    if-eqz v6, :cond_11e

    .line 843
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->updateFormat()V

    .line 846
    :goto_ca
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    const/4 v7, 0x1

    # setter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBoolAppResume:Z
    invoke-static {v6, v7}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$702(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Z)Z

    .line 847
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$100(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    move-result-object v6

    invoke-interface {v6}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->obtainMessage()Landroid/os/Message;

    move-result-object v5

    .line 848
    .local v5, "uiMsg":Landroid/os/Message;
    const v6, 0x8001

    iput v6, v5, Landroid/os/Message;->what:I

    .line 849
    iget v6, p1, Landroid/os/Message;->arg1:I

    iput v6, v5, Landroid/os/Message;->arg1:I

    .line 850
    const/4 v6, 0x0

    iput v6, v5, Landroid/os/Message;->arg2:I

    .line 851
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock/util/location/LocationCtrl;->getState()Lcom/htc/clock/util/location/LocationCtrl$State;

    move-result-object v6

    sget-object v7, Lcom/htc/clock/util/location/LocationCtrl$State;->START:Lcom/htc/clock/util/location/LocationCtrl$State;

    if-eq v6, v7, :cond_124

    .line 853
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$100(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    move-result-object v6

    const-wide/16 v7, 0x0

    invoke-interface {v6, v5, v7, v8}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->sendDelayed(Landroid/os/Message;J)V

    .line 854
    new-instance v2, Landroid/os/Handler;

    invoke-direct {v2}, Landroid/os/Handler;-><init>()V

    .line 855
    .local v2, "handler":Landroid/os/Handler;
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v6

    iget-object v7, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherListener:Lcom/htc/clock/util/location/LocationListener;
    invoke-static {v7}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$900(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationListener;

    move-result-object v7

    invoke-virtual {v6, v2, v7}, Lcom/htc/clock/util/location/LocationCtrl;->register(Landroid/os/Handler;Lcom/htc/clock/util/location/LocationListener;)V

    .line 856
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock/util/location/LocationCtrl;->checkLocEnable()Z

    goto/16 :goto_21

    .line 845
    .end local v2    # "handler":Landroid/os/Handler;
    .end local v5    # "uiMsg":Landroid/os/Message;
    :cond_11e
    const-string v6, "WHAT_ON_RESUME~ mClockView is null"

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    goto :goto_ca

    .line 858
    .restart local v5    # "uiMsg":Landroid/os/Message;
    :cond_124
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$100(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    move-result-object v6

    const-wide/16 v7, 0x0

    invoke-interface {v6, v5, v7, v8}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->sendDelayed(Landroid/os/Message;J)V

    .line 859
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    const v7, 0x9004

    const-wide/16 v8, 0x12c

    invoke-virtual {v6, v7, v8, v9}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->sendNonUiMessageDelayed(IJ)V

    goto/16 :goto_21

    .line 865
    .end local v5    # "uiMsg":Landroid/os/Message;
    :sswitch_13b
    const-string v6, "WHAT_ON_RESUME_DELAY"

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->d(Ljava/lang/String;)V

    .line 866
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    sget-object v7, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;->RESUME_DELAY:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;

    # setter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mUiState:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;
    invoke-static {v6, v7}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$402(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;)Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$UiState;

    .line 867
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    const/4 v7, 0x1

    # setter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBoolAppResume:Z
    invoke-static {v6, v7}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$702(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Z)Z

    .line 868
    const/4 v1, 0x0

    .line 869
    .local v1, "bPlayWWP":Z
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v6

    if-eqz v6, :cond_21c

    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    if-eqz v6, :cond_21c

    .line 870
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock/util/location/LocationCtrl;->checkLocEnable()Z

    move-result v0

    .line 871
    .local v0, "bLocEnableChanged":Z
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock/util/location/LocationCtrl;->getState()Lcom/htc/clock/util/location/LocationCtrl$State;

    move-result-object v6

    sget-object v7, Lcom/htc/clock/util/location/LocationCtrl$State;->START:Lcom/htc/clock/util/location/LocationCtrl$State;

    if-eq v6, v7, :cond_197

    .line 872
    new-instance v2, Landroid/os/Handler;

    invoke-direct {v2}, Landroid/os/Handler;-><init>()V

    .line 873
    .restart local v2    # "handler":Landroid/os/Handler;
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v6

    iget-object v7, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherListener:Lcom/htc/clock/util/location/LocationListener;
    invoke-static {v7}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$900(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationListener;

    move-result-object v7

    invoke-virtual {v6, v2, v7}, Lcom/htc/clock/util/location/LocationCtrl;->register(Landroid/os/Handler;Lcom/htc/clock/util/location/LocationListener;)V

    .line 874
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock/util/location/LocationCtrl;->checkLocEnable()Z

    .line 875
    monitor-exit p0

    move v6, v8

    goto/16 :goto_1b

    .line 877
    .end local v2    # "handler":Landroid/os/Handler;
    :cond_197
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock/util/location/LocationCtrl;->checkTempUnit()Z

    move-result v6

    if-eqz v6, :cond_1b2

    .line 878
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherListener:Lcom/htc/clock/util/location/LocationListener;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$900(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationListener;

    move-result-object v6

    iget-object v7, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;
    invoke-static {v7}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v7

    invoke-interface {v6, v7}, Lcom/htc/clock/util/location/LocationListener;->onTempUnitChange(Lcom/htc/clock/util/location/LocationCtrl;)V

    .line 881
    :cond_1b2
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock/util/location/LocationCtrl;->updateDataByForeCast()Z

    move-result v6

    if-nez v6, :cond_1cc

    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->IsNeedUpdate()Z

    move-result v6

    if-nez v6, :cond_1cc

    if-eqz v0, :cond_1d5

    .line 884
    :cond_1cc
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->update()V

    .line 886
    :cond_1d5
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->isUseWWPAnimation()Z

    move-result v6

    if-eqz v6, :cond_207

    .line 887
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->checkPlayAnimationTime()V

    .line 888
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mLongClick:Z
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$1000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Z

    move-result v6

    if-eqz v6, :cond_201

    .line 889
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    const/4 v7, 0x0

    # setter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mLongClick:Z
    invoke-static {v6, v7}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$1002(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Z)Z

    .line 890
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->attach3DObject()V

    .line 892
    :cond_201
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # invokes: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->checkToPlayWWP()Z
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$1100(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Z

    move-result v1

    .line 894
    :cond_207
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock/util/location/LocationCtrl;->forceUpdateIfNoData()V

    .line 903
    .end local v0    # "bLocEnableChanged":Z
    :cond_210
    :goto_210
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    const v7, 0x9009

    const-wide/16 v8, 0xbb8

    invoke-virtual {v6, v7, v8, v9}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->sendNonUiMessageDelayed(IJ)V

    goto/16 :goto_21

    .line 896
    :cond_21c
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v6

    if-nez v6, :cond_229

    .line 897
    const-string v6, "WHAT_ON_RESUME_DELAY~ mWeatherCtrl is null"

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    .line 899
    :cond_229
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    if-nez v6, :cond_210

    .line 900
    const-string v6, "WHAT_ON_RESUME_DELAY~ mWeatherView is null"

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    goto :goto_210

    .line 906
    .end local v1    # "bPlayWWP":Z
    :sswitch_237
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # invokes: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->stateToLog()V
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$1200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)V

    goto/16 :goto_21

    .line 909
    :sswitch_23e
    iget v4, p1, Landroid/os/Message;->arg1:I

    .line 910
    .local v4, "notifyCause":I
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # invokes: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->myOnNotifyWidgetPause(I)V
    invoke-static {v6, v4}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$1300(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;I)V

    goto/16 :goto_21

    .line 913
    .end local v4    # "notifyCause":I
    :sswitch_247
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # invokes: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->initData()V
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$1400(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)V

    goto/16 :goto_21

    .line 916
    :sswitch_24e
    const-string v6, "WHAT_ON_TEMP_UNIT_CHANGED~"

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 917
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    if-eqz v6, :cond_266

    .line 918
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->updateTempUnit()V

    goto/16 :goto_21

    .line 920
    :cond_266
    const-string v6, "WHAT_ON_TEMP_UNIT_CHANGED~ mWeatherView is null"

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    goto/16 :goto_21

    .line 924
    :sswitch_26d
    const-string v6, "WHAT_ON_WEATHER_UPDATE~"

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 925
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    const v7, 0x9201

    invoke-virtual {v6, v7}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 926
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    if-eqz v6, :cond_292

    .line 927
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->update()V

    .line 928
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # invokes: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->playWWPAtFirstTime()V
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$1500(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)V

    goto/16 :goto_21

    .line 930
    :cond_292
    const-string v6, "WHAT_ON_WEATHER_UPDATE~ mWeatherView is null"

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    goto/16 :goto_21

    .line 934
    :sswitch_299
    const-string v6, "WHAT_ON_CITY_CHANGED~"

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 935
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    const v7, 0x9203

    invoke-virtual {v6, v7}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->removeUiMessages(I)V

    .line 936
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    if-eqz v6, :cond_2ce

    .line 937
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->update()V

    .line 938
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    const/4 v7, 0x1

    # setter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mBChangeTimeZone:Z
    invoke-static {v6, v7}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$1602(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Z)Z

    .line 939
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    const v7, 0x8012

    const-wide/16 v8, 0x0

    invoke-virtual {v6, v7, v8, v9}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->sendUiMessageDelayed(IJ)V

    .line 940
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # invokes: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->playWWPAtFirstTime()V
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$1500(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)V

    goto/16 :goto_21

    .line 942
    :cond_2ce
    const-string v6, "WHAT_ON_CITY_CHANGED~ mWeatherView is null"

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    goto/16 :goto_21

    .line 946
    :sswitch_2d5
    const-string v6, "WHAT_ON_GL_ANIMATION_STOP~"

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 947
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    if-eqz v6, :cond_2ed

    .line 948
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->animationEnd()V

    goto/16 :goto_21

    .line 950
    :cond_2ed
    const-string v6, "WHAT_ON_GL_ANIMATION_STOP~ mWeatherView is null"

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    goto/16 :goto_21

    .line 955
    :sswitch_2f4
    const-string v6, "WHAT_ON_TRY_UPDATE_WEATHER~"

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 956
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock/util/location/LocationCtrl;->getLocState()Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    move-result-object v6

    sget-object v7, Lcom/htc/clock/util/location/LocationCtrl$LocationState;->NO_DATA:Lcom/htc/clock/util/location/LocationCtrl$LocationState;

    if-ne v6, v7, :cond_21

    .line 957
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock/util/location/LocationCtrl;->updateWeatherData()V

    goto/16 :goto_21

    .line 960
    :sswitch_312
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    if-eqz v6, :cond_331

    .line 961
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->updateFormat()V

    .line 962
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mClockView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->checkSystemAutoSynTimezone()V

    .line 963
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    invoke-virtual {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->checkClockTimeZone()V

    .line 965
    :cond_331
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock/util/location/LocationCtrl;->checkTempUnit()Z

    move-result v6

    if-eqz v6, :cond_34c

    .line 966
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherListener:Lcom/htc/clock/util/location/LocationListener;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$900(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationListener;

    move-result-object v6

    iget-object v7, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;
    invoke-static {v7}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v7

    invoke-interface {v6, v7}, Lcom/htc/clock/util/location/LocationListener;->onTempUnitChange(Lcom/htc/clock/util/location/LocationCtrl;)V

    .line 968
    :cond_34c
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherCtrl:Lcom/htc/clock/util/location/LocationCtrl;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock/util/location/LocationCtrl;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock/util/location/LocationCtrl;->checkLocEnable()Z

    move-result v6

    if-eqz v6, :cond_369

    .line 969
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    if-eqz v6, :cond_369

    .line 970
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mWeatherView:Lcom/htc/clock3dwidget/weatherclock/WeatherClock;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$200(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Lcom/htc/clock3dwidget/weatherclock/WeatherClock;

    move-result-object v6

    invoke-virtual {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClock;->update()V

    .line 972
    :cond_369
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    const v7, 0x9003

    const-wide/16 v8, 0x0

    invoke-virtual {v6, v7, v8, v9}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->sendUiMessageDelayed(IJ)V

    .line 973
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    const v7, 0x8016

    const-wide/16 v8, 0x0

    invoke-virtual {v6, v7, v8, v9}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->sendUiMessageDelayed(IJ)V

    goto/16 :goto_21

    .line 979
    :sswitch_37f
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # invokes: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->doConfigurationChanged()V
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$1700(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)V

    goto/16 :goto_21

    .line 982
    :sswitch_386
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # getter for: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->mApplication:Landroid/content/Context;
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$1800(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Landroid/content/Context;

    move-result-object v6

    iget-object v7, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # invokes: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->getCityCode()Ljava/lang/String;
    invoke-static {v7}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$1900(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v6, v7}, Lcom/htc/clock/util/MyUtil;->launchWorldClockAp(Landroid/content/Context;Ljava/lang/String;)V

    goto/16 :goto_21

    .line 985
    :sswitch_397
    iget-object v6, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    # invokes: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->launchWeatherClockAp()V
    invoke-static {v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$2000(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;)V

    goto/16 :goto_21

    .line 988
    :sswitch_39e
    iget-object v7, p0, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView$3;->this$0:Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;

    iget-object v6, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    check-cast v6, Landroid/content/Intent;

    # invokes: Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->doActivityResult(Landroid/content/Intent;)V
    invoke-static {v7, v6}, Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;->access$2100(Lcom/htc/clock3dwidget/weatherclock/WeatherClockWidgetView;Landroid/content/Intent;)V
    :try_end_3a7
    .catchall {:try_start_89 .. :try_end_3a7} :catchall_86

    goto/16 :goto_21

    .line 821
    nop

    :sswitch_data_3aa
    .sparse-switch
        0x1 -> :sswitch_89
        0x2 -> :sswitch_23e
        0x4 -> :sswitch_2d5
        0x9001 -> :sswitch_247
        0x9004 -> :sswitch_13b
        0x9009 -> :sswitch_237
        0x9011 -> :sswitch_37f
        0x9012 -> :sswitch_386
        0x9013 -> :sswitch_397
        0x9014 -> :sswitch_39e
        0x9015 -> :sswitch_24
        0x9201 -> :sswitch_26d
        0x9202 -> :sswitch_24e
        0x9203 -> :sswitch_299
        0x9204 -> :sswitch_2f4
        0x9205 -> :sswitch_312
    .end sparse-switch
.end method
