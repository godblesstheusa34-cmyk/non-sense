.class public Lcom/htc/clock3dwidget/ResUtils;
.super Ljava/lang/Object;
.source "ResUtils.java"


# static fields
.field public static final CLOCK_LAYOUT_ID:I = 0x7f030000

.field public static final CLOCK_LISTVIEW_ID:I = 0x7f090002

.field public static final CLOCK_TITLE_ID:I = 0x7f060029

.field public static final DELETE_ADD_CITY:Z = false

.field public static final M10_CLOCK_03:Ljava/lang/String; = "Pyramid_Clock_03.m10"

.field public static final M10_CLOCK_04:Ljava/lang/String; = "Pyramid_Clock_04.m10"

.field public static final M10_CLOCK_05:Ljava/lang/String; = "Pyramid_Clock_05.m10"

.field public static final M10_CLOCK_06:Ljava/lang/String; = "Pyramid_Clock_06.m10"

.field public static final M10_CLOCK_07:Ljava/lang/String; = "Pyramid_Clock_07.m10"

.field public static final M10_CLOCK_08:Ljava/lang/String; = "Pyramid_Clock_08.m10"

.field public static final M10_CLOCK_09:Ljava/lang/String; = "Pyramid_Clock_09.m10"

.field public static final M10_CLOCK_10:Ljava/lang/String; = "Pyramid_Clock_10.m10"

.field public static final M10_CLOCK_1x1:Ljava/lang/String; = "Pyramid_Clock_Worldclock.m10"

.field public static final M10_CLOCK_2x2:Ljava/lang/String; = "Pyramid_Clock_2x2.m10"

.field public static final M10_CLOCK_BEAM:Ljava/lang/String; = "Pyramid_Clock_Beam.m10"

.field public static final M10_CLOCK_DIGITAL:Ljava/lang/String; = "Pyramid_Clock_Digital.m10"

.field public static final M10_CLOCK_DUAL:Ljava/lang/String; = "Pyramid_Clock_Dual.m10"

.field public static final M10_CLOCK_RING:Ljava/lang/String; = "Pyramid_Clock_Ring.m10"

.field public static final M10_CLOCK_SOCIAL:Ljava/lang/String; = "Pyramid_Clock_Weather_social_4x2.m10"

.field public static final M10_CLOCK_SPIN_CYCLE:Ljava/lang/String; = "Pyramid_Clock_SpinCycle.m10"

.field public static final M10_CLOCK_WEATHER:Ljava/lang/String; = "Pyramid_Clock_Weather_4x2.m10"

.field public static final M10_LOCKSCREEN_CONTAINER:Ljava/lang/String; = "Pyramid_Lockscreen_clock.m10"

.field public static final M10_LOCKSCREEN_RING_MOTION:Ljava/lang/String; = "Pyramid_Lock_ring_motion.m10"

.field public static final NO_TOP_ROUND:Z = false

.field public static final WIGGLE_LOOPING:Z = false

.field public static final WWP_LAYOUT_ID:I = 0x7f030001

.field public static final WWP_LISTVIEW_ID:I = 0x7f090004

.field public static final WWP_TITLE_ID:I = 0x7f060025


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static addHeaderView(Landroid/app/Activity;Lcom/htc/widget/HtcListView;Landroid/view/View$OnClickListener;)V
    .registers 8
    .param p0, "activity"    # Landroid/app/Activity;
    .param p1, "listview"    # Lcom/htc/widget/HtcListView;
    .param p2, "addClickListener"    # Landroid/view/View$OnClickListener;

    .prologue
    .line 85
    const v3, 0x7f090001

    :try_start_3
    invoke-virtual {p0, v3}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/htc/widget/Title1;

    .line 86
    .local v2, "title":Lcom/htc/widget/Title1;
    if-eqz v2, :cond_17

    .line 87
    const v3, 0x202022c

    invoke-virtual {v2, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    .line 88
    .local v0, "btnAdd":Landroid/widget/ImageButton;
    invoke-virtual {v0, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    :try_end_17
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_17} :catch_18

    .line 93
    .end local v0    # "btnAdd":Landroid/widget/ImageButton;
    .end local v2    # "title":Lcom/htc/widget/Title1;
    :cond_17
    :goto_17
    return-void

    .line 90
    :catch_18
    move-exception v3

    move-object v1, v3

    .line 91
    .local v1, "e":Ljava/lang/Exception;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "onCreate~ set title exception:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    goto :goto_17
.end method

.method public static setupButton(Landroid/app/Activity;Landroid/view/View$OnClickListener;)V
    .registers 6
    .param p0, "activity"    # Landroid/app/Activity;
    .param p1, "l"    # Landroid/view/View$OnClickListener;

    .prologue
    .line 97
    const v2, 0x2020001

    :try_start_3
    invoke-virtual {p0, v2}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    .line 98
    .local v0, "button":Landroid/widget/Button;
    if-eqz v0, :cond_14

    .line 99
    const v2, 0x7f060027

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(I)V

    .line 100
    invoke-virtual {v0, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_14} :catch_15

    .line 106
    .end local v0    # "button":Landroid/widget/Button;
    :cond_14
    :goto_14
    return-void

    .line 103
    :catch_15
    move-exception v2

    move-object v1, v2

    .line 104
    .local v1, "e":Ljava/lang/Exception;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "onCreate~ set button exception:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    goto :goto_14
.end method

.method public static setupView(Landroid/app/Activity;IIII)V
    .registers 9
    .param p0, "activity"    # Landroid/app/Activity;
    .param p1, "layoutId"    # I
    .param p2, "listViewId"    # I
    .param p3, "titleStringId"    # I
    .param p4, "type"    # I

    .prologue
    .line 46
    invoke-virtual {p0, p1}, Landroid/app/Activity;->setContentView(I)V

    .line 48
    const v2, 0x7f090001

    :try_start_6
    invoke-virtual {p0, v2}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Lcom/htc/widget/Title1;

    .line 49
    .local v1, "title":Lcom/htc/widget/Title1;
    if-eqz v1, :cond_20

    .line 50
    invoke-virtual {v1}, Lcom/htc/widget/Title1;->disablePulldownButton()V

    .line 51
    const v2, 0x20806e5

    invoke-virtual {v1, v2}, Lcom/htc/widget/Title1;->setRightButtonImage2(I)V

    .line 52
    const/4 v2, 0x4

    if-ne p4, v2, :cond_21

    .line 53
    const v2, 0x7f06002f

    invoke-virtual {v1, v2}, Lcom/htc/widget/Title1;->setLeftTitle(I)V

    .line 63
    .end local v1    # "title":Lcom/htc/widget/Title1;
    :cond_20
    :goto_20
    return-void

    .line 54
    .restart local v1    # "title":Lcom/htc/widget/Title1;
    :cond_21
    const/4 v2, 0x7

    if-ne p4, v2, :cond_48

    .line 55
    const v2, 0x7f060030

    invoke-virtual {v1, v2}, Lcom/htc/widget/Title1;->setLeftTitle(I)V
    :try_end_2a
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_2a} :catch_2b

    goto :goto_20

    .line 60
    .end local v1    # "title":Lcom/htc/widget/Title1;
    :catch_2b
    move-exception v2

    move-object v0, v2

    .line 61
    .local v0, "e":Ljava/lang/Exception;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "onCreate~ set title exception:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    goto :goto_20

    .line 57
    .end local v0    # "e":Ljava/lang/Exception;
    .restart local v1    # "title":Lcom/htc/widget/Title1;
    :cond_48
    :try_start_48
    invoke-virtual {v1, p3}, Lcom/htc/widget/Title1;->setLeftTitle(I)V
    :try_end_4b
    .catch Ljava/lang/Exception; {:try_start_48 .. :try_end_4b} :catch_2b

    goto :goto_20
.end method

.method public static setupWWPView(Landroid/app/Activity;IIII)V
    .registers 9
    .param p0, "activity"    # Landroid/app/Activity;
    .param p1, "layoutId"    # I
    .param p2, "listViewId"    # I
    .param p3, "titleStringId"    # I
    .param p4, "type"    # I

    .prologue
    .line 66
    invoke-virtual {p0, p1}, Landroid/app/Activity;->setContentView(I)V

    .line 68
    const v2, 0x7f090001

    :try_start_6
    invoke-virtual {p0, v2}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Lcom/htc/widget/Title1;

    .line 69
    .local v1, "title":Lcom/htc/widget/Title1;
    if-eqz v1, :cond_17

    .line 70
    const/4 v2, 0x4

    if-ne p4, v2, :cond_18

    .line 71
    const v2, 0x7f06002f

    invoke-virtual {v1, v2}, Lcom/htc/widget/Title1;->setTitle1(I)V

    .line 81
    .end local v1    # "title":Lcom/htc/widget/Title1;
    :cond_17
    :goto_17
    return-void

    .line 72
    .restart local v1    # "title":Lcom/htc/widget/Title1;
    :cond_18
    const/4 v2, 0x7

    if-ne p4, v2, :cond_3f

    .line 73
    const v2, 0x7f060030

    invoke-virtual {v1, v2}, Lcom/htc/widget/Title1;->setTitle1(I)V
    :try_end_21
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_21} :catch_22

    goto :goto_17

    .line 78
    .end local v1    # "title":Lcom/htc/widget/Title1;
    :catch_22
    move-exception v2

    move-object v0, v2

    .line 79
    .local v0, "e":Ljava/lang/Exception;
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "onCreate~ set title exception:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    goto :goto_17

    .line 75
    .end local v0    # "e":Ljava/lang/Exception;
    .restart local v1    # "title":Lcom/htc/widget/Title1;
    :cond_3f
    :try_start_3f
    invoke-virtual {v1, p3}, Lcom/htc/widget/Title1;->setTitle1(I)V
    :try_end_42
    .catch Ljava/lang/Exception; {:try_start_3f .. :try_end_42} :catch_22

    goto :goto_17
.end method
