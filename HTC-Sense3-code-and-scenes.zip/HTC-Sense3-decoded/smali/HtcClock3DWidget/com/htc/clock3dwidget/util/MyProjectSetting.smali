.class public Lcom/htc/clock3dwidget/util/MyProjectSetting;
.super Ljava/lang/Object;
.source "MyProjectSetting.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static hasCurrentLocation()Z
    .registers 2

    .prologue
    .line 51
    const/4 v0, 0x1

    .line 52
    .local v0, "bWithCurrentLocation":Z
    invoke-static {}, Lcom/htc/clock3dwidget/util/MyProjectSetting;->isChina()Z

    move-result v1

    if-eqz v1, :cond_e

    invoke-static {}, Lcom/htc/clock3dwidget/util/MyProjectSetting;->isChinaLocationService()Z

    move-result v1

    if-nez v1, :cond_e

    .line 53
    const/4 v0, 0x0

    .line 55
    :cond_e
    return v0
.end method

.method public static hasSeparateLine()Z
    .registers 4

    .prologue
    .line 76
    const-string v0, "3.0"

    invoke-static {v0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v0

    float-to-double v0, v0

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    cmpl-double v0, v0, v2

    if-ltz v0, :cond_f

    .line 79
    const/4 v0, 0x0

    .line 81
    :goto_e
    return v0

    :cond_f
    const/4 v0, 0x1

    goto :goto_e
.end method

.method public static hasSeparateLine2()Z
    .registers 1

    .prologue
    .line 89
    const/4 v0, 0x1

    return v0
.end method

.method public static hasTravelClock()Z
    .registers 1

    .prologue
    .line 10
    const/4 v0, 0x1

    return v0
.end method

.method public static hasWeatherAp()Z
    .registers 1

    .prologue
    .line 66
    const/4 v0, 0x1

    return v0
.end method

.method public static hasWeatherClock()Z
    .registers 1

    .prologue
    .line 14
    const/4 v0, 0x1

    return v0
.end method

.method public static hasWeatherWallpaper()Z
    .registers 4

    .prologue
    const/4 v3, 0x1

    const/4 v2, 0x0

    .line 30
    const-string v1, "persist.debug.testAP.WWP"

    invoke-static {v1, v2}, Landroid/os/SystemProperties;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    .line 31
    .local v0, "testWWP":Z
    if-eqz v0, :cond_c

    move v1, v3

    .line 45
    :goto_b
    return v1

    .line 34
    :cond_c
    invoke-static {}, Lcom/htc/clock3dwidget/util/MyProjectSetting;->hasWeatherAp()Z

    move-result v1

    if-nez v1, :cond_14

    move v1, v2

    .line 35
    goto :goto_b

    :cond_14
    move v1, v3

    .line 45
    goto :goto_b
.end method

.method public static isChina()Z
    .registers 1

    .prologue
    .line 93
    const-string v0, "isChina Language Flag = 0 Device Flag = 123 Project Flag = 52"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 109
    const/4 v0, 0x0

    return v0
.end method

.method public static isChinaLocationService()Z
    .registers 1

    .prologue
    .line 59
    invoke-static {}, Lcom/htc/clock3dwidget/util/MyProjectSetting;->isChina()Z

    move-result v0

    if-eqz v0, :cond_8

    .line 60
    const/4 v0, 0x1

    .line 62
    :goto_7
    return v0

    :cond_8
    const/4 v0, 0x0

    goto :goto_7
.end method

.method public static isFlipEnable()Z
    .registers 1

    .prologue
    .line 132
    const/4 v0, 0x1

    return v0
.end method

.method public static isHelpTurnOnLoc()Z
    .registers 1

    .prologue
    .line 113
    const/4 v0, 0x1

    return v0
.end method
