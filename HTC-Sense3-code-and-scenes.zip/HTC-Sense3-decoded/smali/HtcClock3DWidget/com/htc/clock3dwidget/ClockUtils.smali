.class public Lcom/htc/clock3dwidget/ClockUtils;
.super Ljava/lang/Object;
.source "ClockUtils.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/htc/clock3dwidget/ClockUtils$1;,
        Lcom/htc/clock3dwidget/ClockUtils$ClockType;
    }
.end annotation


# static fields
.field public static SUPPORT_LAND:Z

.field public static SUPPORT_TIMELINE:Z

.field private static USE_LOCAL_PATH:Z


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .prologue
    const/4 v1, 0x0

    .line 14
    const/4 v0, 0x1

    sput-boolean v0, Lcom/htc/clock3dwidget/ClockUtils;->USE_LOCAL_PATH:Z

    .line 15
    sput-boolean v1, Lcom/htc/clock3dwidget/ClockUtils;->SUPPORT_LAND:Z

    .line 16
    sput-boolean v1, Lcom/htc/clock3dwidget/ClockUtils;->SUPPORT_TIMELINE:Z

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .prologue
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    return-void
.end method

.method private static getClock03(Z)Lcom/htc/clock3dwidget/ClockRes;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 171
    new-instance v0, Lcom/htc/clock3dwidget/ClockRes;

    invoke-direct {v0}, Lcom/htc/clock3dwidget/ClockRes;-><init>()V

    .line 172
    .local v0, "res":Lcom/htc/clock3dwidget/ClockRes;
    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getClock03Path(Z)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->m10FilePath:Ljava/lang/String;

    .line 173
    const-string v1, "Clock_hitbox"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->hitboxClock:Ljava/lang/String;

    .line 174
    const-string v1, "progressbar.clock03.hour_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarHourHand:Ljava/lang/String;

    .line 175
    const-string v1, "progressbar.clock03.minute_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarMinuteHand:Ljava/lang/String;

    .line 176
    const-string v1, "progressbar.clock03.second_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarSecondHand:Ljava/lang/String;

    .line 177
    const-string v1, "textlabel.clock"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelCityName:Ljava/lang/String;

    .line 179
    const-string v1, "timeline.clock_base"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClockBase:Ljava/lang/String;

    .line 180
    const-string v1, "timeline.clock_date"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClockDate:Ljava/lang/String;

    .line 182
    const-string v1, "textlabel.date_day"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockDate:Ljava/lang/String;

    .line 183
    const-string v1, "textlabel.week_day"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockWeekDay:Ljava/lang/String;

    .line 184
    const-string v1, "textlabel.AM"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabalClockAmPm:Ljava/lang/String;

    .line 186
    const-string v1, "textlabel.date_night"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockDate_night:Ljava/lang/String;

    .line 187
    const-string v1, "textlabel.week_night"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockWeekDay_night:Ljava/lang/String;

    .line 188
    const-string v1, "textlabel.PM"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabalClockAmPm_night:Ljava/lang/String;

    .line 190
    const-string v1, "timeline.Clock_03"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClock:Ljava/lang/String;

    .line 191
    return-object v0
.end method

.method private static getClock03Path(Z)Ljava/lang/String;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 195
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getMode10Path(Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "Pyramid_Clock_03.m10"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static getClock04(Z)Lcom/htc/clock3dwidget/ClockRes;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 199
    new-instance v0, Lcom/htc/clock3dwidget/ClockRes;

    invoke-direct {v0}, Lcom/htc/clock3dwidget/ClockRes;-><init>()V

    .line 200
    .local v0, "res":Lcom/htc/clock3dwidget/ClockRes;
    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getClock04Path(Z)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->m10FilePath:Ljava/lang/String;

    .line 201
    const-string v1, "Clock_hitbox"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->hitboxClock:Ljava/lang/String;

    .line 202
    const-string v1, "progressbar.hour_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarHourHand:Ljava/lang/String;

    .line 203
    const-string v1, "progressbar.minute_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarMinuteHand:Ljava/lang/String;

    .line 204
    const-string v1, "progressbar.second_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarSecondHand:Ljava/lang/String;

    .line 205
    const-string v1, "textlabel.widget_clock_city"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelCityName:Ljava/lang/String;

    .line 206
    const-string v1, "textlabel.Clock_date"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockDate:Ljava/lang/String;

    .line 207
    const-string v1, "timeline.Clock_04"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClock:Ljava/lang/String;

    .line 208
    return-object v0
.end method

.method private static getClock04Path(Z)Ljava/lang/String;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 212
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getMode10Path(Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "Pyramid_Clock_04.m10"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static getClock05(Z)Lcom/htc/clock3dwidget/ClockRes;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 216
    new-instance v0, Lcom/htc/clock3dwidget/ClockRes;

    invoke-direct {v0}, Lcom/htc/clock3dwidget/ClockRes;-><init>()V

    .line 217
    .local v0, "res":Lcom/htc/clock3dwidget/ClockRes;
    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getClock05Path(Z)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->m10FilePath:Ljava/lang/String;

    .line 218
    const-string v1, "Clock_hitbox"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->hitboxClock:Ljava/lang/String;

    .line 219
    const-string v1, "progressbar.hour_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarHourHand:Ljava/lang/String;

    .line 220
    const-string v1, "progressbar.minute_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarMinuteHand:Ljava/lang/String;

    .line 221
    const-string v1, "progressbar.second_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarSecondHand:Ljava/lang/String;

    .line 222
    const-string v1, "textlabel.widget_clock_city"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelCityName:Ljava/lang/String;

    .line 223
    const-string v1, "textlabel.widget_clock_month"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockDate:Ljava/lang/String;

    .line 224
    const-string v1, "textlabel.widget_clock_am"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabalClockAmPm:Ljava/lang/String;

    .line 225
    const-string v1, "timeline.Clock_05"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClock:Ljava/lang/String;

    .line 226
    return-object v0
.end method

.method private static getClock05Path(Z)Ljava/lang/String;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 230
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getMode10Path(Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "Pyramid_Clock_05.m10"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static getClock06(Z)Lcom/htc/clock3dwidget/ClockRes;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 234
    new-instance v0, Lcom/htc/clock3dwidget/ClockRes;

    invoke-direct {v0}, Lcom/htc/clock3dwidget/ClockRes;-><init>()V

    .line 235
    .local v0, "res":Lcom/htc/clock3dwidget/ClockRes;
    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getClock06Path(Z)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->m10FilePath:Ljava/lang/String;

    .line 236
    const-string v1, "Clock_hitbox"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->hitboxClock:Ljava/lang/String;

    .line 237
    const-string v1, "progressbar.clock06.hour_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarHourHand:Ljava/lang/String;

    .line 238
    const-string v1, "progressbar.clock06.minute_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarMinuteHand:Ljava/lang/String;

    .line 239
    const-string v1, "progressbar.clock06.second_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarSecondHand:Ljava/lang/String;

    .line 240
    const-string v1, "textlabel.clock"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelCityName:Ljava/lang/String;

    .line 241
    const-string v1, "timeline.Clock_06"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClock:Ljava/lang/String;

    .line 242
    const-string v1, "timeline.gear_01"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineGear01:Ljava/lang/String;

    .line 243
    const-string v1, "timeline.gear_02"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineGear02:Ljava/lang/String;

    .line 244
    const-string v1, "timeline.gear_03"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineGear03:Ljava/lang/String;

    .line 245
    const-string v1, "timeline.gear_04"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineGear04:Ljava/lang/String;

    .line 246
    const-string v1, "timeline.gear_02_1"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineGear05:Ljava/lang/String;

    .line 247
    return-object v0
.end method

.method private static getClock06Path(Z)Ljava/lang/String;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 251
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getMode10Path(Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "Pyramid_Clock_06.m10"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static getClock07(Z)Lcom/htc/clock3dwidget/ClockRes;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 255
    new-instance v0, Lcom/htc/clock3dwidget/ClockRes;

    invoke-direct {v0}, Lcom/htc/clock3dwidget/ClockRes;-><init>()V

    .line 256
    .local v0, "res":Lcom/htc/clock3dwidget/ClockRes;
    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getClock07Path(Z)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->m10FilePath:Ljava/lang/String;

    .line 257
    const-string v1, "Clock_hitbox"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->hitboxClock:Ljava/lang/String;

    .line 258
    const-string v1, "progressbar.clock07.hour_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarHourHand:Ljava/lang/String;

    .line 259
    const-string v1, "progressbar.clock07.minute_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarMinuteHand:Ljava/lang/String;

    .line 260
    const-string v1, "progressbar.clock07.second_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarSecondHand:Ljava/lang/String;

    .line 261
    const-string v1, "textlabel.widget_clock_city"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelCityName:Ljava/lang/String;

    .line 262
    const-string v1, "timeline.Clock_07"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClock:Ljava/lang/String;

    .line 263
    return-object v0
.end method

.method private static getClock07Path(Z)Ljava/lang/String;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 267
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getMode10Path(Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "Pyramid_Clock_07.m10"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static getClock08(Z)Lcom/htc/clock3dwidget/ClockRes;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 271
    new-instance v0, Lcom/htc/clock3dwidget/ClockRes;

    invoke-direct {v0}, Lcom/htc/clock3dwidget/ClockRes;-><init>()V

    .line 272
    .local v0, "res":Lcom/htc/clock3dwidget/ClockRes;
    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getClock08Path(Z)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->m10FilePath:Ljava/lang/String;

    .line 273
    const-string v1, "Clock.hitbox"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->hitboxClock:Ljava/lang/String;

    .line 274
    const-string v1, "progressbar.hour_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarHourHand:Ljava/lang/String;

    .line 275
    const-string v1, "progressbar.minute_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarMinuteHand:Ljava/lang/String;

    .line 276
    const-string v1, "progressbar.second_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarSecondHand:Ljava/lang/String;

    .line 277
    const-string v1, "textlabel.widget_clock_city"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelCityName:Ljava/lang/String;

    .line 278
    const-string v1, "timeline.am_pm"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineAmPm:Ljava/lang/String;

    .line 279
    const-string v1, "timeline.Clock_08"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClock:Ljava/lang/String;

    .line 280
    return-object v0
.end method

.method private static getClock08Path(Z)Ljava/lang/String;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 284
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getMode10Path(Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "Pyramid_Clock_08.m10"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static getClock09(Z)Lcom/htc/clock3dwidget/ClockRes;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 288
    new-instance v0, Lcom/htc/clock3dwidget/ClockRes;

    invoke-direct {v0}, Lcom/htc/clock3dwidget/ClockRes;-><init>()V

    .line 289
    .local v0, "res":Lcom/htc/clock3dwidget/ClockRes;
    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getClock09Path(Z)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->m10FilePath:Ljava/lang/String;

    .line 290
    const-string v1, "Clock_hitbox"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->hitboxClock:Ljava/lang/String;

    .line 291
    const-string v1, "progressbar.hour_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarHourHand:Ljava/lang/String;

    .line 292
    const-string v1, "progressbar.minute_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarMinuteHand:Ljava/lang/String;

    .line 293
    const-string v1, "progressbar.second_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarSecondHand:Ljava/lang/String;

    .line 294
    const-string v1, "textlabel.widget_clock_city"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelCityName:Ljava/lang/String;

    .line 295
    const-string v1, "timeline.Clock_09"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClock:Ljava/lang/String;

    .line 296
    return-object v0
.end method

.method private static getClock09Path(Z)Ljava/lang/String;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 300
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getMode10Path(Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "Pyramid_Clock_09.m10"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static getClock10(Z)Lcom/htc/clock3dwidget/ClockRes;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 304
    new-instance v0, Lcom/htc/clock3dwidget/ClockRes;

    invoke-direct {v0}, Lcom/htc/clock3dwidget/ClockRes;-><init>()V

    .line 305
    .local v0, "res":Lcom/htc/clock3dwidget/ClockRes;
    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getClock10Path(Z)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->m10FilePath:Ljava/lang/String;

    .line 306
    const-string v1, "Clock_hitbox"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->hitboxClock:Ljava/lang/String;

    .line 307
    const-string v1, "progressbar.hour_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarHourHand:Ljava/lang/String;

    .line 308
    const-string v1, "progressbar.minute_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarMinuteHand:Ljava/lang/String;

    .line 309
    const-string v1, "progressbar.second_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarSecondHand:Ljava/lang/String;

    .line 310
    const-string v1, "textlabel.widget_clock_city"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelCityName:Ljava/lang/String;

    .line 311
    const-string v1, "timeline.Clock_10"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClock:Ljava/lang/String;

    .line 312
    return-object v0
.end method

.method private static getClock10Path(Z)Ljava/lang/String;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 316
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getMode10Path(Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "Pyramid_Clock_10.m10"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static getClock1x1(Z)Lcom/htc/clock3dwidget/ClockRes;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 366
    new-instance v0, Lcom/htc/clock3dwidget/ClockRes;

    invoke-direct {v0}, Lcom/htc/clock3dwidget/ClockRes;-><init>()V

    .line 367
    .local v0, "res":Lcom/htc/clock3dwidget/ClockRes;
    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getClock1x1Path(Z)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->m10FilePath:Ljava/lang/String;

    .line 368
    const-string v1, "Clock_hitbox"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->hitboxClock:Ljava/lang/String;

    .line 369
    const-string v1, "progressbar.hour_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarHourHand:Ljava/lang/String;

    .line 370
    const-string v1, "progressbar.minute_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarMinuteHand:Ljava/lang/String;

    .line 371
    const-string v1, "progressbar.second_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarSecondHand:Ljava/lang/String;

    .line 372
    const-string v1, "textlabel.widget_clock_city"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelCityName:Ljava/lang/String;

    .line 373
    const-string v1, "timeline.clock_base"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineWiggle:Ljava/lang/String;

    .line 374
    const-string v1, "timeline.clock_base_day_night"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClockBase:Ljava/lang/String;

    .line 375
    const-string v1, "timeline.clock_hour"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClockHour:Ljava/lang/String;

    .line 376
    const-string v1, "timeline.clock_minute"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClockMinute:Ljava/lang/String;

    .line 377
    return-object v0
.end method

.method private static getClock1x1Path(Z)Ljava/lang/String;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 381
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getMode10Path(Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "Pyramid_Clock_Worldclock.m10"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static getClock2x2(Z)Lcom/htc/clock3dwidget/ClockRes;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 338
    new-instance v0, Lcom/htc/clock3dwidget/ClockRes;

    invoke-direct {v0}, Lcom/htc/clock3dwidget/ClockRes;-><init>()V

    .line 339
    .local v0, "res":Lcom/htc/clock3dwidget/ClockRes;
    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getClock2x2Path(Z)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->m10FilePath:Ljava/lang/String;

    .line 340
    const-string v1, "Clock_hitbox"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->hitboxClock:Ljava/lang/String;

    .line 342
    const-string v1, "timeline.clock_day_night"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClockBase:Ljava/lang/String;

    .line 343
    const-string v1, "timeline.clock_date"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClockDate:Ljava/lang/String;

    .line 345
    const-string v1, "progressbar.hour_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarHourHand:Ljava/lang/String;

    .line 346
    const-string v1, "progressbar.minute_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarMinuteHand:Ljava/lang/String;

    .line 347
    const-string v1, "progressbar.second_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarSecondHand:Ljava/lang/String;

    .line 349
    const-string v1, "textlabel.date_day"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockDate:Ljava/lang/String;

    .line 350
    const-string v1, "textlabel.clock_week_day"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockWeekDay:Ljava/lang/String;

    .line 351
    const-string v1, "textlabel.AM_day"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabalClockAmPm:Ljava/lang/String;

    .line 353
    const-string v1, "textlabel.date_night"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockDate_night:Ljava/lang/String;

    .line 354
    const-string v1, "textlabel.clock_week_night"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockWeekDay_night:Ljava/lang/String;

    .line 355
    const-string v1, "textlabel.PM_night"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabalClockAmPm_night:Ljava/lang/String;

    .line 357
    const-string v1, "textlabel.clock"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelCityName:Ljava/lang/String;

    .line 358
    return-object v0
.end method

.method private static getClock2x2Path(Z)Ljava/lang/String;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 362
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getMode10Path(Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "Pyramid_Clock_2x2.m10"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static getClockBeam(Z)Lcom/htc/clock3dwidget/ClockRes;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 423
    new-instance v0, Lcom/htc/clock3dwidget/ClockRes;

    invoke-direct {v0}, Lcom/htc/clock3dwidget/ClockRes;-><init>()V

    .line 424
    .local v0, "res":Lcom/htc/clock3dwidget/ClockRes;
    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getClockBeamPath(Z)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->m10FilePath:Ljava/lang/String;

    .line 425
    const-string v1, "Clock_hitbox"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->hitboxClock:Ljava/lang/String;

    .line 426
    const-string v1, "progressbar.hour_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarHourHand:Ljava/lang/String;

    .line 427
    const-string v1, "progressbar.minute_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarMinuteHand:Ljava/lang/String;

    .line 428
    const-string v1, "progressbar.second_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarSecondHand:Ljava/lang/String;

    .line 429
    const-string v1, "textlabel.widget_clock_city"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelCityName:Ljava/lang/String;

    .line 430
    const-string v1, "timeline.Clock_Beam"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClock:Ljava/lang/String;

    .line 431
    return-object v0
.end method

.method private static getClockBeamPath(Z)Ljava/lang/String;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 435
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getMode10Path(Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "Pyramid_Clock_Beam.m10"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static getClockDigital(Z)Lcom/htc/clock3dwidget/ClockRes;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 320
    new-instance v0, Lcom/htc/clock3dwidget/ClockRes;

    invoke-direct {v0}, Lcom/htc/clock3dwidget/ClockRes;-><init>()V

    .line 321
    .local v0, "res":Lcom/htc/clock3dwidget/ClockRes;
    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getClockDigitalPath(Z)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->m10FilePath:Ljava/lang/String;

    .line 322
    const-string v1, "Clock_hitbox"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->hitboxClock:Ljava/lang/String;

    .line 323
    const-string v1, "timeline.digital_numbers_01"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineHourTen:Ljava/lang/String;

    .line 324
    const-string v1, "timeline.digital_numbers_02"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineHourUnit:Ljava/lang/String;

    .line 325
    const-string v1, "timeline.digital_numbers_03"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineMinuteTen:Ljava/lang/String;

    .line 326
    const-string v1, "timeline.digital_numbers_04"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineMinuteUinit:Ljava/lang/String;

    .line 327
    const-string v1, "timeline.am_pm"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineAmPmOpp:Ljava/lang/String;

    .line 328
    const-string v1, "textlabel.city"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelCityName:Ljava/lang/String;

    .line 329
    const-string v1, "textlabel.digital_clock_01"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockLongDate:Ljava/lang/String;

    .line 330
    return-object v0
.end method

.method private static getClockDigitalPath(Z)Ljava/lang/String;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 334
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getMode10Path(Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "Pyramid_Clock_Digital.m10"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static getClockDualL(Z)Lcom/htc/clock3dwidget/ClockRes;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 385
    new-instance v0, Lcom/htc/clock3dwidget/ClockRes;

    invoke-direct {v0}, Lcom/htc/clock3dwidget/ClockRes;-><init>()V

    .line 386
    .local v0, "res":Lcom/htc/clock3dwidget/ClockRes;
    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getClockDualLPath(Z)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->m10FilePath:Ljava/lang/String;

    .line 387
    const-string v1, "Clock_hitbox"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->hitboxClock:Ljava/lang/String;

    .line 388
    const-string v1, "progressbar.hour_hand_right"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarHourHand:Ljava/lang/String;

    .line 389
    const-string v1, "progressbar.minute_hand_right"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarMinuteHand:Ljava/lang/String;

    .line 390
    const-string v1, "progressbar.second_hand_right"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarSecondHand:Ljava/lang/String;

    .line 392
    const-string v1, "timeline.clock_base_right"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClockBase:Ljava/lang/String;

    .line 393
    const-string v1, "timeline.clock_numbers_right"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClockNumbers:Ljava/lang/String;

    .line 395
    const-string v1, "textlabel.clock_left"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelCityName:Ljava/lang/String;

    .line 396
    return-object v0
.end method

.method private static getClockDualLPath(Z)Ljava/lang/String;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 400
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getMode10Path(Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "Pyramid_Clock_Dual.m10"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static getClockDualR(Z)Lcom/htc/clock3dwidget/ClockRes;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 404
    new-instance v0, Lcom/htc/clock3dwidget/ClockRes;

    invoke-direct {v0}, Lcom/htc/clock3dwidget/ClockRes;-><init>()V

    .line 405
    .local v0, "res":Lcom/htc/clock3dwidget/ClockRes;
    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getClockDualRPath(Z)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->m10FilePath:Ljava/lang/String;

    .line 406
    const-string v1, "Clock_hitbox"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->hitboxClock:Ljava/lang/String;

    .line 407
    const-string v1, "progressbar.hour_hand_left"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarHourHand:Ljava/lang/String;

    .line 408
    const-string v1, "progressbarl.minute_hand_left"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarMinuteHand:Ljava/lang/String;

    .line 409
    const-string v1, "progressbar.second_hand_left"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarSecondHand:Ljava/lang/String;

    .line 411
    const-string v1, "timeline.clock_base_left"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClockBase:Ljava/lang/String;

    .line 412
    const-string v1, "timeline.clock_numbers_left"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClockNumbers:Ljava/lang/String;

    .line 414
    const-string v1, "textlabel.clock_right"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelCityName:Ljava/lang/String;

    .line 415
    return-object v0
.end method

.method private static getClockDualRPath(Z)Ljava/lang/String;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 419
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getMode10Path(Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "Pyramid_Clock_Dual.m10"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static getClockPath(Lcom/htc/clock3dwidget/ClockUtils$ClockType;Landroid/content/Context;)Ljava/lang/String;
    .registers 5
    .param p0, "type"    # Lcom/htc/clock3dwidget/ClockUtils$ClockType;
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    const/4 v2, 0x1

    .line 105
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v1

    iget v1, v1, Landroid/content/res/Configuration;->orientation:I

    if-ne v1, v2, :cond_13

    move v0, v2

    .line 106
    .local v0, "isPortrait":Z
    :goto_e
    invoke-static {p0, v0}, Lcom/htc/clock3dwidget/ClockUtils;->getClockPath(Lcom/htc/clock3dwidget/ClockUtils$ClockType;Z)Ljava/lang/String;

    move-result-object v1

    return-object v1

    .line 105
    .end local v0    # "isPortrait":Z
    :cond_13
    const/4 v1, 0x0

    move v0, v1

    goto :goto_e
.end method

.method public static getClockPath(Lcom/htc/clock3dwidget/ClockUtils$ClockType;Z)Ljava/lang/String;
    .registers 5
    .param p0, "type"    # Lcom/htc/clock3dwidget/ClockUtils$ClockType;
    .param p1, "isPortrait"    # Z

    .prologue
    .line 110
    const/4 v0, 0x0

    .line 111
    .local v0, "path":Ljava/lang/String;
    sget-object v1, Lcom/htc/clock3dwidget/ClockUtils$1;->$SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType:[I

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    aget v1, v1, v2

    packed-switch v1, :pswitch_data_68

    .line 167
    :goto_c
    return-object v0

    .line 113
    :pswitch_d
    invoke-static {p1}, Lcom/htc/clock3dwidget/ClockUtils;->getClock03Path(Z)Ljava/lang/String;

    move-result-object v0

    .line 114
    goto :goto_c

    .line 116
    :pswitch_12
    invoke-static {p1}, Lcom/htc/clock3dwidget/ClockUtils;->getClock04Path(Z)Ljava/lang/String;

    move-result-object v0

    .line 117
    goto :goto_c

    .line 119
    :pswitch_17
    invoke-static {p1}, Lcom/htc/clock3dwidget/ClockUtils;->getClock05Path(Z)Ljava/lang/String;

    move-result-object v0

    .line 120
    goto :goto_c

    .line 122
    :pswitch_1c
    invoke-static {p1}, Lcom/htc/clock3dwidget/ClockUtils;->getClock06Path(Z)Ljava/lang/String;

    move-result-object v0

    .line 123
    goto :goto_c

    .line 125
    :pswitch_21
    invoke-static {p1}, Lcom/htc/clock3dwidget/ClockUtils;->getClock07Path(Z)Ljava/lang/String;

    move-result-object v0

    .line 126
    goto :goto_c

    .line 128
    :pswitch_26
    invoke-static {p1}, Lcom/htc/clock3dwidget/ClockUtils;->getClock08Path(Z)Ljava/lang/String;

    move-result-object v0

    .line 129
    goto :goto_c

    .line 131
    :pswitch_2b
    invoke-static {p1}, Lcom/htc/clock3dwidget/ClockUtils;->getClock09Path(Z)Ljava/lang/String;

    move-result-object v0

    .line 132
    goto :goto_c

    .line 134
    :pswitch_30
    invoke-static {p1}, Lcom/htc/clock3dwidget/ClockUtils;->getClock10Path(Z)Ljava/lang/String;

    move-result-object v0

    .line 135
    goto :goto_c

    .line 137
    :pswitch_35
    invoke-static {p1}, Lcom/htc/clock3dwidget/ClockUtils;->getClock2x2Path(Z)Ljava/lang/String;

    move-result-object v0

    .line 138
    goto :goto_c

    .line 140
    :pswitch_3a
    invoke-static {p1}, Lcom/htc/clock3dwidget/ClockUtils;->getClock1x1Path(Z)Ljava/lang/String;

    move-result-object v0

    .line 141
    goto :goto_c

    .line 143
    :pswitch_3f
    invoke-static {p1}, Lcom/htc/clock3dwidget/ClockUtils;->getClockDigitalPath(Z)Ljava/lang/String;

    move-result-object v0

    .line 144
    goto :goto_c

    .line 146
    :pswitch_44
    invoke-static {p1}, Lcom/htc/clock3dwidget/ClockUtils;->getClockDualLPath(Z)Ljava/lang/String;

    move-result-object v0

    .line 147
    goto :goto_c

    .line 149
    :pswitch_49
    invoke-static {p1}, Lcom/htc/clock3dwidget/ClockUtils;->getClockDualRPath(Z)Ljava/lang/String;

    move-result-object v0

    .line 150
    goto :goto_c

    .line 152
    :pswitch_4e
    invoke-static {p1}, Lcom/htc/clock3dwidget/ClockUtils;->getClockBeamPath(Z)Ljava/lang/String;

    move-result-object v0

    .line 153
    goto :goto_c

    .line 155
    :pswitch_53
    invoke-static {p1}, Lcom/htc/clock3dwidget/ClockUtils;->getClockRingPath(Z)Ljava/lang/String;

    move-result-object v0

    .line 156
    goto :goto_c

    .line 158
    :pswitch_58
    invoke-static {p1}, Lcom/htc/clock3dwidget/ClockUtils;->getClockSpinCyclePath(Z)Ljava/lang/String;

    move-result-object v0

    .line 159
    goto :goto_c

    .line 161
    :pswitch_5d
    invoke-static {p1}, Lcom/htc/clock3dwidget/ClockUtils;->getClockWeatherPath(Z)Ljava/lang/String;

    move-result-object v0

    .line 162
    goto :goto_c

    .line 164
    :pswitch_62
    invoke-static {p1}, Lcom/htc/clock3dwidget/ClockUtils;->getClockSocialPath(Z)Ljava/lang/String;

    move-result-object v0

    goto :goto_c

    .line 111
    nop

    :pswitch_data_68
    .packed-switch 0x1
        :pswitch_d
        :pswitch_12
        :pswitch_17
        :pswitch_1c
        :pswitch_21
        :pswitch_26
        :pswitch_2b
        :pswitch_30
        :pswitch_35
        :pswitch_3a
        :pswitch_3f
        :pswitch_44
        :pswitch_49
        :pswitch_4e
        :pswitch_53
        :pswitch_58
        :pswitch_62
        :pswitch_5d
    .end packed-switch
.end method

.method public static getClockRes(Lcom/htc/clock3dwidget/ClockUtils$ClockType;Landroid/content/Context;)Lcom/htc/clock3dwidget/ClockRes;
    .registers 6
    .param p0, "type"    # Lcom/htc/clock3dwidget/ClockUtils$ClockType;
    .param p1, "context"    # Landroid/content/Context;

    .prologue
    const/4 v3, 0x1

    .line 46
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v2

    iget v2, v2, Landroid/content/res/Configuration;->orientation:I

    if-ne v2, v3, :cond_1b

    move v0, v3

    .line 47
    .local v0, "isPortrait":Z
    :goto_e
    const/4 v1, 0x0

    .line 48
    .local v1, "res":Lcom/htc/clock3dwidget/ClockRes;
    sget-object v2, Lcom/htc/clock3dwidget/ClockUtils$1;->$SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType:[I

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    aget v2, v2, v3

    packed-switch v2, :pswitch_data_74

    .line 101
    :goto_1a
    return-object v1

    .line 46
    .end local v0    # "isPortrait":Z
    .end local v1    # "res":Lcom/htc/clock3dwidget/ClockRes;
    :cond_1b
    const/4 v2, 0x0

    move v0, v2

    goto :goto_e

    .line 50
    .restart local v0    # "isPortrait":Z
    .restart local v1    # "res":Lcom/htc/clock3dwidget/ClockRes;
    :pswitch_1e
    invoke-static {v0}, Lcom/htc/clock3dwidget/ClockUtils;->getClock03(Z)Lcom/htc/clock3dwidget/ClockRes;

    move-result-object v1

    .line 51
    goto :goto_1a

    .line 53
    :pswitch_23
    invoke-static {v0}, Lcom/htc/clock3dwidget/ClockUtils;->getClock04(Z)Lcom/htc/clock3dwidget/ClockRes;

    move-result-object v1

    .line 54
    goto :goto_1a

    .line 56
    :pswitch_28
    invoke-static {v0}, Lcom/htc/clock3dwidget/ClockUtils;->getClock05(Z)Lcom/htc/clock3dwidget/ClockRes;

    move-result-object v1

    .line 57
    goto :goto_1a

    .line 59
    :pswitch_2d
    invoke-static {v0}, Lcom/htc/clock3dwidget/ClockUtils;->getClock06(Z)Lcom/htc/clock3dwidget/ClockRes;

    move-result-object v1

    .line 60
    goto :goto_1a

    .line 62
    :pswitch_32
    invoke-static {v0}, Lcom/htc/clock3dwidget/ClockUtils;->getClock07(Z)Lcom/htc/clock3dwidget/ClockRes;

    move-result-object v1

    .line 63
    goto :goto_1a

    .line 65
    :pswitch_37
    invoke-static {v0}, Lcom/htc/clock3dwidget/ClockUtils;->getClock08(Z)Lcom/htc/clock3dwidget/ClockRes;

    move-result-object v1

    .line 66
    goto :goto_1a

    .line 68
    :pswitch_3c
    invoke-static {v0}, Lcom/htc/clock3dwidget/ClockUtils;->getClock09(Z)Lcom/htc/clock3dwidget/ClockRes;

    move-result-object v1

    .line 69
    goto :goto_1a

    .line 71
    :pswitch_41
    invoke-static {v0}, Lcom/htc/clock3dwidget/ClockUtils;->getClock10(Z)Lcom/htc/clock3dwidget/ClockRes;

    move-result-object v1

    .line 72
    goto :goto_1a

    .line 74
    :pswitch_46
    invoke-static {v0}, Lcom/htc/clock3dwidget/ClockUtils;->getClock2x2(Z)Lcom/htc/clock3dwidget/ClockRes;

    move-result-object v1

    .line 75
    goto :goto_1a

    .line 77
    :pswitch_4b
    invoke-static {v0}, Lcom/htc/clock3dwidget/ClockUtils;->getClock1x1(Z)Lcom/htc/clock3dwidget/ClockRes;

    move-result-object v1

    .line 78
    goto :goto_1a

    .line 80
    :pswitch_50
    invoke-static {v0}, Lcom/htc/clock3dwidget/ClockUtils;->getClockDigital(Z)Lcom/htc/clock3dwidget/ClockRes;

    move-result-object v1

    .line 81
    goto :goto_1a

    .line 83
    :pswitch_55
    invoke-static {v0}, Lcom/htc/clock3dwidget/ClockUtils;->getClockDualL(Z)Lcom/htc/clock3dwidget/ClockRes;

    move-result-object v1

    .line 84
    goto :goto_1a

    .line 86
    :pswitch_5a
    invoke-static {v0}, Lcom/htc/clock3dwidget/ClockUtils;->getClockDualR(Z)Lcom/htc/clock3dwidget/ClockRes;

    move-result-object v1

    .line 87
    goto :goto_1a

    .line 89
    :pswitch_5f
    invoke-static {v0}, Lcom/htc/clock3dwidget/ClockUtils;->getClockBeam(Z)Lcom/htc/clock3dwidget/ClockRes;

    move-result-object v1

    .line 90
    goto :goto_1a

    .line 92
    :pswitch_64
    invoke-static {v0}, Lcom/htc/clock3dwidget/ClockUtils;->getClockRing(Z)Lcom/htc/clock3dwidget/ClockRes;

    move-result-object v1

    .line 93
    goto :goto_1a

    .line 95
    :pswitch_69
    invoke-static {v0}, Lcom/htc/clock3dwidget/ClockUtils;->getClockSpinCycle(Z)Lcom/htc/clock3dwidget/ClockRes;

    move-result-object v1

    .line 96
    goto :goto_1a

    .line 98
    :pswitch_6e
    invoke-static {v0}, Lcom/htc/clock3dwidget/ClockUtils;->getClockSocial(Z)Lcom/htc/clock3dwidget/ClockRes;

    move-result-object v1

    goto :goto_1a

    .line 48
    nop

    :pswitch_data_74
    .packed-switch 0x1
        :pswitch_1e
        :pswitch_23
        :pswitch_28
        :pswitch_2d
        :pswitch_32
        :pswitch_37
        :pswitch_3c
        :pswitch_41
        :pswitch_46
        :pswitch_4b
        :pswitch_50
        :pswitch_55
        :pswitch_5a
        :pswitch_5f
        :pswitch_64
        :pswitch_69
        :pswitch_6e
    .end packed-switch
.end method

.method private static getClockRing(Z)Lcom/htc/clock3dwidget/ClockRes;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 439
    new-instance v0, Lcom/htc/clock3dwidget/ClockRes;

    invoke-direct {v0}, Lcom/htc/clock3dwidget/ClockRes;-><init>()V

    .line 440
    .local v0, "res":Lcom/htc/clock3dwidget/ClockRes;
    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getClockRingPath(Z)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->m10FilePath:Ljava/lang/String;

    .line 441
    const-string v1, "Clock_hitbox"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->hitboxClock:Ljava/lang/String;

    .line 442
    const-string v1, "progressbar.hour_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarUnitHourHand:Ljava/lang/String;

    .line 443
    const-string v1, "progressbar.minute_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarUnitMinuteHand:Ljava/lang/String;

    .line 444
    const-string v1, "progressbar.second_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarSecondHand:Ljava/lang/String;

    .line 445
    const-string v1, "textlabel.widget_clock_city"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelCityName:Ljava/lang/String;

    .line 446
    const-string v1, "timeline.Clock_Ring"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClock:Ljava/lang/String;

    .line 448
    const-string v1, "textlabel.clock_hour"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelHour:Ljava/lang/String;

    .line 449
    const-string v1, "textlabel.clock_minute"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelMinute:Ljava/lang/String;

    .line 450
    const-string v1, "textlabel.clock_second"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelSecond:Ljava/lang/String;

    .line 451
    return-object v0
.end method

.method private static getClockRingPath(Z)Ljava/lang/String;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 455
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getMode10Path(Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "Pyramid_Clock_Ring.m10"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static getClockSocial(Z)Lcom/htc/clock3dwidget/ClockRes;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 488
    new-instance v0, Lcom/htc/clock3dwidget/ClockRes;

    invoke-direct {v0}, Lcom/htc/clock3dwidget/ClockRes;-><init>()V

    .line 489
    .local v0, "res":Lcom/htc/clock3dwidget/ClockRes;
    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getClockSocialPath(Z)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->m10FilePath:Ljava/lang/String;

    .line 490
    const-string v1, "button.clock.hitbox"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->hitboxClock:Ljava/lang/String;

    .line 491
    const-string v1, "timeline.flip_hour"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineFlipHour:Ljava/lang/String;

    .line 492
    const-string v1, "timeline.flip_minute"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineFlipMinute:Ljava/lang/String;

    .line 493
    return-object v0
.end method

.method public static getClockSocialPath(Z)Ljava/lang/String;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 497
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getMode10Path(Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "Pyramid_Clock_Weather_social_4x2.m10"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static getClockSpinCycle(Z)Lcom/htc/clock3dwidget/ClockRes;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 459
    new-instance v0, Lcom/htc/clock3dwidget/ClockRes;

    invoke-direct {v0}, Lcom/htc/clock3dwidget/ClockRes;-><init>()V

    .line 460
    .local v0, "res":Lcom/htc/clock3dwidget/ClockRes;
    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getClockSpinCyclePath(Z)Ljava/lang/String;

    move-result-object v1

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->m10FilePath:Ljava/lang/String;

    .line 461
    const-string v1, "Clock_hitbox"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->hitboxClock:Ljava/lang/String;

    .line 462
    const-string v1, "progressbar.hour_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarUnitHourHand:Ljava/lang/String;

    .line 463
    const-string v1, "progressbar.minute_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarUnitMinuteHand:Ljava/lang/String;

    .line 464
    const-string v1, "progressbar.second_hand"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->progressBarSecondHand:Ljava/lang/String;

    .line 465
    const-string v1, "textlabel.widget_clock_city"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelCityName:Ljava/lang/String;

    .line 466
    const-string v1, "textlabel.clock_week"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockWeekDay:Ljava/lang/String;

    .line 467
    const-string v1, "textlabel.clock_date"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockDate:Ljava/lang/String;

    .line 469
    const-string v1, "timeline.Clock_04"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClock:Ljava/lang/String;

    .line 471
    const-string v1, "timeline.clock_ampm"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineClockAmPm:Ljava/lang/String;

    .line 472
    const-string v1, "timeline.clock_number_01"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineHourTen:Ljava/lang/String;

    .line 473
    const-string v1, "timeline.clock_number_02"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineHourUnit:Ljava/lang/String;

    .line 474
    const-string v1, "timeline.clock_number_03"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineMinuteTen:Ljava/lang/String;

    .line 475
    const-string v1, "timeline.clock_number_04"

    iput-object v1, v0, Lcom/htc/clock3dwidget/ClockRes;->timelineMinuteUinit:Ljava/lang/String;

    .line 476
    return-object v0
.end method

.method private static getClockSpinCyclePath(Z)Ljava/lang/String;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 480
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getMode10Path(Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "Pyramid_Clock_SpinCycle.m10"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static getClockWeatherPath(Z)Ljava/lang/String;
    .registers 3
    .param p0, "portrait"    # Z

    .prologue
    .line 484
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-static {p0}, Lcom/htc/clock3dwidget/ClockUtils;->getMode10Path(Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "Pyramid_Clock_Weather_4x2.m10"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static getMode10Path(Landroid/content/Context;)Ljava/lang/String;
    .registers 4
    .param p0, "context"    # Landroid/content/Context;

    .prologue
    const/4 v2, 0x1

    .line 41
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v1

    iget v1, v1, Landroid/content/res/Configuration;->orientation:I

    if-ne v1, v2, :cond_13

    move v0, v2

    .line 42
    .local v0, "isPortrait":Z
    :goto_e
    invoke-static {v0}, Lcom/htc/clock3dwidget/ClockUtils;->getMode10Path(Z)Ljava/lang/String;

    move-result-object v1

    return-object v1

    .line 41
    .end local v0    # "isPortrait":Z
    :cond_13
    const/4 v1, 0x0

    move v0, v1

    goto :goto_e
.end method

.method public static getMode10Path(Z)Ljava/lang/String;
    .registers 2
    .param p0, "portrait"    # Z

    .prologue
    .line 37
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lcom/htc/clock3dwidget/ClockUtils;->getMode10Path(ZZ)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static getMode10Path(ZZ)Ljava/lang/String;
    .registers 5
    .param p0, "portrait"    # Z
    .param p1, "supportLand"    # Z

    .prologue
    .line 19
    const-string v0, ""

    .line 20
    .local v0, "modePath":Ljava/lang/String;
    sget-boolean v1, Lcom/htc/clock3dwidget/ClockUtils;->USE_LOCAL_PATH:Z

    if-eqz v1, :cond_32

    .line 21
    if-nez p0, :cond_1e

    if-eqz p1, :cond_1e

    .line 22
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "land/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 33
    :goto_1d
    return-object v0

    .line 24
    :cond_1e
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ""

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_1d

    .line 27
    :cond_32
    if-nez p0, :cond_4a

    if-eqz p1, :cond_4a

    .line 28
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/sdcard/data/mode10/scenes/land/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_1d

    .line 30
    :cond_4a
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "/sdcard/data/mode10/scenes/"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_1d
.end method
