.class Lcom/htc/clock3dwidget/setting/HtcWWPSetting$EmptyAdapter;
.super Landroid/widget/BaseAdapter;
.source "HtcWWPSetting.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock3dwidget/setting/HtcWWPSetting;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "EmptyAdapter"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/clock3dwidget/setting/HtcWWPSetting;


# direct methods
.method private constructor <init>(Lcom/htc/clock3dwidget/setting/HtcWWPSetting;)V
    .registers 2

    .prologue
    .line 30
    iput-object p1, p0, Lcom/htc/clock3dwidget/setting/HtcWWPSetting$EmptyAdapter;->this$0:Lcom/htc/clock3dwidget/setting/HtcWWPSetting;

    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/htc/clock3dwidget/setting/HtcWWPSetting;Lcom/htc/clock3dwidget/setting/HtcWWPSetting$1;)V
    .registers 3
    .param p1, "x0"    # Lcom/htc/clock3dwidget/setting/HtcWWPSetting;
    .param p2, "x1"    # Lcom/htc/clock3dwidget/setting/HtcWWPSetting$1;

    .prologue
    .line 30
    invoke-direct {p0, p1}, Lcom/htc/clock3dwidget/setting/HtcWWPSetting$EmptyAdapter;-><init>(Lcom/htc/clock3dwidget/setting/HtcWWPSetting;)V

    return-void
.end method


# virtual methods
.method public getCount()I
    .registers 2

    .prologue
    .line 34
    const/4 v0, 0x0

    return v0
.end method

.method public getItem(I)Ljava/lang/Object;
    .registers 3
    .param p1, "arg0"    # I

    .prologue
    .line 39
    const/4 v0, 0x0

    return-object v0
.end method

.method public getItemId(I)J
    .registers 4
    .param p1, "arg0"    # I

    .prologue
    .line 44
    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .registers 5
    .param p1, "arg0"    # I
    .param p2, "arg1"    # Landroid/view/View;
    .param p3, "arg2"    # Landroid/view/ViewGroup;

    .prologue
    .line 49
    const/4 v0, 0x0

    return-object v0
.end method
