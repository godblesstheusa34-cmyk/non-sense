.class Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;
.super Ljava/lang/Object;
.source "HtcClockSetting.java"

# interfaces
.implements Lcom/htc/widget/HtcAdapterView$OnItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock3dwidget/setting/HtcClockSetting;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;


# direct methods
.method constructor <init>(Lcom/htc/clock3dwidget/setting/HtcClockSetting;)V
    .registers 2

    .prologue
    .line 74
    iput-object p1, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onItemClick(Lcom/htc/widget/HtcAdapterView;Landroid/view/View;IJ)V
    .registers 21
    .param p2, "view"    # Landroid/view/View;
    .param p3, "position"    # I
    .param p4, "id"    # J
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/htc/widget/HtcAdapterView",
            "<*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .prologue
    .line 78
    .local p1, "parent":Lcom/htc/widget/HtcAdapterView;, "Lcom/htc/widget/HtcAdapterView<*>;"
    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-static {v13}, Lcom/htc/clock3dwidget/setting/HtcClockSetting;->access$000(Lcom/htc/clock3dwidget/setting/HtcClockSetting;)Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;

    move-result-object v13

    move-object v0, v13

    move/from16 v1, p3

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->getItemId(I)J

    move-result-wide v13

    long-to-int v7, v13

    .line 79
    .local v7, "index":I
    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    const-string v14, "onItemClick~ index:"

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v13, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v13

    const-string v14, " position:"

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    move-object v0, v13

    move/from16 v1, p3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v13

    const-string v14, " id:"

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v13

    move-object v0, v13

    move-wide/from16 v1, p4

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-static {v13}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 80
    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-static {v13}, Lcom/htc/clock3dwidget/setting/HtcClockSetting;->access$100(Lcom/htc/clock3dwidget/setting/HtcClockSetting;)Landroid/view/View;

    move-result-object v13

    invoke-virtual {v13}, Landroid/view/View;->getVisibility()I

    move-result v13

    if-nez v13, :cond_72

    .line 81
    const/4 v4, 0x0

    .line 82
    .local v4, "checkIndex":I
    if-ne v7, v4, :cond_72

    .line 83
    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    iget-object v14, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-static {v14}, Lcom/htc/clock3dwidget/setting/HtcClockSetting;->access$200(Lcom/htc/clock3dwidget/setting/HtcClockSetting;)Z

    move-result v14

    if-nez v14, :cond_70

    const/4 v14, 0x1

    :goto_58
    invoke-static {v13, v14}, Lcom/htc/clock3dwidget/setting/HtcClockSetting;->access$202(Lcom/htc/clock3dwidget/setting/HtcClockSetting;Z)Z

    .line 84
    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-static {v13}, Lcom/htc/clock3dwidget/setting/HtcClockSetting;->access$300(Lcom/htc/clock3dwidget/setting/HtcClockSetting;)Landroid/widget/CheckBox;

    move-result-object v13

    iget-object v14, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-static {v14}, Lcom/htc/clock3dwidget/setting/HtcClockSetting;->access$200(Lcom/htc/clock3dwidget/setting/HtcClockSetting;)Z

    move-result v14

    invoke-virtual {v13, v14}, Landroid/widget/CompoundButton;->setChecked(Z)V

    .line 85
    const-string v13, "onItemClick~ mShowCurrentCity"

    invoke-static {v13}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 192
    .end local v4    # "checkIndex":I
    :cond_6f
    :goto_6f
    return-void

    .line 83
    .restart local v4    # "checkIndex":I
    :cond_70
    const/4 v14, 0x0

    goto :goto_58

    .line 94
    .end local v4    # "checkIndex":I
    :cond_72
    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-static {v13}, Lcom/htc/clock3dwidget/setting/HtcClockSetting;->access$100(Lcom/htc/clock3dwidget/setting/HtcClockSetting;)Landroid/view/View;

    move-result-object v13

    invoke-virtual {v13}, Landroid/view/View;->getVisibility()I

    move-result v13

    if-nez v13, :cond_80

    .line 95
    add-int/lit8 v7, v7, -0x1

    .line 96
    :cond_80
    if-ltz v7, :cond_6f

    .line 97
    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-virtual {v13}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v8

    .line 98
    .local v8, "intent":Landroid/content/Intent;
    const-string v13, "widget_city_reset"

    const/4 v14, 0x0

    invoke-virtual {v8, v13, v14}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v3

    .line 99
    .local v3, "bCityReset":Z
    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-static {v13}, Lcom/htc/clock3dwidget/setting/HtcClockSetting;->access$400(Lcom/htc/clock3dwidget/setting/HtcClockSetting;)Ljava/util/List;

    move-result-object v13

    invoke-interface {v13, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/HashMap;

    .line 100
    .local v10, "map":Ljava/util/HashMap;, "Ljava/util/HashMap<Ljava/lang/String;Ljava/lang/String;>;"
    move v11, v7

    .line 101
    .local v11, "tmpindex":I
    invoke-static {}, Lcom/htc/clock3dwidget/util/MyProjectSetting;->hasCurrentLocation()Z

    move-result v13

    if-eqz v13, :cond_a6

    if-nez v3, :cond_a6

    .line 102
    add-int/lit8 v11, v11, -0x1

    .line 104
    :cond_a6
    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-static {v13}, Lcom/htc/clock3dwidget/setting/HtcClockSetting;->access$500(Lcom/htc/clock3dwidget/setting/HtcClockSetting;)I

    move-result v13

    const/4 v14, 0x4

    if-eq v13, v14, :cond_b8

    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-static {v13}, Lcom/htc/clock3dwidget/setting/HtcClockSetting;->access$500(Lcom/htc/clock3dwidget/setting/HtcClockSetting;)I

    move-result v13

    const/4 v14, 0x7

    if-ne v13, v14, :cond_ba

    .line 106
    :cond_b8
    add-int/lit8 v11, v11, -0x1

    .line 108
    :cond_ba
    const/4 v5, 0x0

    .line 113
    .local v5, "cityname":Ljava/lang/String;
    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-virtual {v13}, Landroid/content/ContextWrapper;->getResources()Landroid/content/res/Resources;

    move-result-object v13

    const v14, 0x7f060005

    invoke-virtual {v13, v14}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v13

    const-string v14, "name"

    invoke-virtual {v10, v14}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    invoke-virtual {v13, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_10c

    .line 114
    const-string v5, "Current City"

    .line 125
    :goto_d6
    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-static {v13}, Lcom/htc/clock3dwidget/setting/HtcClockSetting;->access$500(Lcom/htc/clock3dwidget/setting/HtcClockSetting;)I

    move-result v13

    const/4 v14, 0x7

    if-ne v13, v14, :cond_152

    .line 126
    const-string v13, "code2_"

    invoke-virtual {v8, v13, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 134
    :goto_e4
    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-static {v13}, Lcom/htc/clock3dwidget/setting/HtcClockSetting;->access$500(Lcom/htc/clock3dwidget/setting/HtcClockSetting;)I

    move-result v13

    const/4 v14, 0x4

    if-ne v13, v14, :cond_163

    .line 135
    new-instance v6, Landroid/content/Intent;

    const-string v13, "OpenSettings"

    invoke-direct {v6, v13}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 136
    .local v6, "dualIntent":Landroid/content/Intent;
    const-string v13, "com.htc.clock3dwidget"

    const-string v14, "com.htc.clock3dwidget.setting.HtcClockSetting"

    invoke-virtual {v6, v13, v14}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 137
    invoke-virtual {v6, v8}, Landroid/content/Intent;->putExtras(Landroid/content/Intent;)Landroid/content/Intent;

    .line 138
    const-string v13, "index"

    const/4 v14, 0x7

    invoke-virtual {v6, v13, v14}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 139
    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    const/4 v14, 0x3

    invoke-virtual {v13, v6, v14}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    goto/16 :goto_6f

    .line 115
    .end local v6    # "dualIntent":Landroid/content/Intent;
    :cond_10c
    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-virtual {v13}, Landroid/content/ContextWrapper;->getResources()Landroid/content/res/Resources;

    move-result-object v13

    const v14, 0x7f06002e

    invoke-virtual {v13, v14}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v13

    const-string v14, "name"

    invoke-virtual {v10, v14}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    invoke-virtual {v13, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_130

    const-string v13, "id"

    invoke-virtual {v10, v13}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    if-nez v13, :cond_130

    .line 117
    const-string v5, "Home City"

    goto :goto_d6

    .line 119
    :cond_130
    const/4 v13, -0x1

    if-le v11, v13, :cond_149

    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-static {v13}, Lcom/htc/clock3dwidget/setting/HtcClockSetting;->access$600(Lcom/htc/clock3dwidget/setting/HtcClockSetting;)[Lcom/htc/util/weather/WeatherLocation;

    move-result-object v13

    array-length v13, v13

    if-ge v11, v13, :cond_149

    .line 120
    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-static {v13}, Lcom/htc/clock3dwidget/setting/HtcClockSetting;->access$600(Lcom/htc/clock3dwidget/setting/HtcClockSetting;)[Lcom/htc/util/weather/WeatherLocation;

    move-result-object v13

    aget-object v13, v13, v11

    invoke-virtual {v13}, Lcom/htc/util/weather/WeatherLocation;->getCode()Ljava/lang/String;

    move-result-object v5

    goto :goto_d6

    .line 122
    :cond_149
    const-string v13, "name"

    invoke-virtual {v10, v13}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    .end local v5    # "cityname":Ljava/lang/String;
    check-cast v5, Ljava/lang/String;

    .restart local v5    # "cityname":Ljava/lang/String;
    goto :goto_d6

    .line 129
    :cond_152
    const-string v13, "code_"

    invoke-virtual {v8, v13, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 130
    const-string v13, "show_"

    iget-object v14, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-static {v14}, Lcom/htc/clock3dwidget/setting/HtcClockSetting;->access$200(Lcom/htc/clock3dwidget/setting/HtcClockSetting;)Z

    move-result v14

    invoke-virtual {v8, v13, v14}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    goto :goto_e4

    .line 142
    :cond_163
    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-static {v13}, Lcom/htc/clock3dwidget/setting/HtcClockSetting;->access$500(Lcom/htc/clock3dwidget/setting/HtcClockSetting;)I

    move-result v13

    const/4 v14, 0x3

    if-ne v13, v14, :cond_1f9

    .line 145
    const/4 v13, -0x1

    if-le v11, v13, :cond_1ec

    .line 146
    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-static {v13}, Lcom/htc/clock3dwidget/setting/HtcClockSetting;->access$600(Lcom/htc/clock3dwidget/setting/HtcClockSetting;)[Lcom/htc/util/weather/WeatherLocation;

    move-result-object v13

    aget-object v9, v13, v11

    .line 149
    .local v9, "loc":Lcom/htc/util/weather/WeatherLocation;
    const-string v13, "Unit"

    const/4 v14, 0x0

    invoke-virtual {v8, v13, v14}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 150
    const-string v13, "name_"

    invoke-virtual {v9}, Lcom/htc/util/weather/WeatherLocation;->getName()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v8, v13, v14}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 151
    const-string v13, "state_"

    invoke-virtual {v9}, Lcom/htc/util/weather/WeatherLocation;->getState()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v8, v13, v14}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 152
    const-string v13, "country_"

    invoke-virtual {v9}, Lcom/htc/util/weather/WeatherLocation;->getCountry()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v8, v13, v14}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 153
    const-string v13, "code_"

    invoke-virtual {v9}, Lcom/htc/util/weather/WeatherLocation;->getCode()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v8, v13, v14}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 154
    const-string v13, "latitude_"

    invoke-virtual {v9}, Lcom/htc/util/weather/WeatherLocation;->getLatitude()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v8, v13, v14}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 155
    const-string v13, "longitude_"

    invoke-virtual {v9}, Lcom/htc/util/weather/WeatherLocation;->getLongitude()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v8, v13, v14}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 156
    const-string v13, "timezone_"

    invoke-virtual {v9}, Lcom/htc/util/weather/WeatherLocation;->getTimezoneId()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v8, v13, v14}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 157
    const-string v13, "app_"

    invoke-virtual {v9}, Lcom/htc/util/weather/WeatherLocation;->getApp()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v8, v13, v14}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 158
    const-string v13, "currentLocation"

    const/4 v14, 0x0

    invoke-virtual {v8, v13, v14}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 167
    .end local v9    # "loc":Lcom/htc/util/weather/WeatherLocation;
    :goto_1cb
    if-nez v3, :cond_1f9

    .line 168
    invoke-static {}, Lcom/htc/clock3dwidget/util/MyProjectSetting;->hasWeatherWallpaper()Z

    move-result v13

    if-eqz v13, :cond_1f3

    .line 169
    new-instance v12, Landroid/content/Intent;

    const-string v13, "OpenWWPSettings"

    invoke-direct {v12, v13}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 170
    .local v12, "wwpIntent":Landroid/content/Intent;
    const-string v13, "com.htc.clock3dwidget"

    const-string v14, "com.htc.clock3dwidget.setting.HtcWWPSetting"

    invoke-virtual {v12, v13, v14}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 171
    invoke-virtual {v12, v8}, Landroid/content/Intent;->putExtras(Landroid/content/Intent;)Landroid/content/Intent;

    .line 172
    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    const/4 v14, 0x2

    invoke-virtual {v13, v12, v14}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    goto/16 :goto_6f

    .line 160
    .end local v12    # "wwpIntent":Landroid/content/Intent;
    :cond_1ec
    const-string v13, "currentLocation"

    const/4 v14, 0x1

    invoke-virtual {v8, v13, v14}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    goto :goto_1cb

    .line 176
    :cond_1f3
    const-string v13, "wwp_play_"

    const/4 v14, 0x0

    invoke-virtual {v8, v13, v14}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 180
    :cond_1f9
    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-static {v13}, Lcom/htc/clock3dwidget/setting/HtcClockSetting;->access$700(Lcom/htc/clock3dwidget/setting/HtcClockSetting;)Z

    move-result v13

    if-eqz v13, :cond_217

    .line 181
    const-string v13, "folder"

    iget-object v14, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-static {v14}, Lcom/htc/clock3dwidget/setting/HtcClockSetting;->access$800(Lcom/htc/clock3dwidget/setting/HtcClockSetting;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v8, v13, v14}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 182
    const-string v13, "parent folder id"

    iget-object v14, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-static {v14}, Lcom/htc/clock3dwidget/setting/HtcClockSetting;->access$900(Lcom/htc/clock3dwidget/setting/HtcClockSetting;)I

    move-result v14

    invoke-virtual {v8, v13, v14}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 185
    :cond_217
    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    const/4 v14, -0x1

    invoke-virtual {v13, v14, v8}, Landroid/app/Activity;->setResult(ILandroid/content/Intent;)V

    .line 186
    iget-object v13, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$1;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-virtual {v13}, Landroid/app/Activity;->finish()V

    goto/16 :goto_6f
.end method
