.class public Lcom/htc/clock3dwidget/setting/HtcCitySeparable;
.super Ljava/lang/Object;
.source "HtcCitySeparable.java"

# interfaces
.implements Lcom/htc/widget/HtcListItemSeparable;


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public shouldDrawOnThis()Z
    .registers 2

    .prologue
    .line 9
    const/4 v0, 0x1

    return v0
.end method

.method public shouldSeparate(Ljava/lang/Object;)Z
    .registers 3
    .param p1, "arg0"    # Ljava/lang/Object;

    .prologue
    .line 14
    const/4 v0, 0x1

    return v0
.end method
