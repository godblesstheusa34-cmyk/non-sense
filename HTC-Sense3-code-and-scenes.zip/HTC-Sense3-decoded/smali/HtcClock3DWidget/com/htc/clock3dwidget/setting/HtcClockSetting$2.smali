.class Lcom/htc/clock3dwidget/setting/HtcClockSetting$2;
.super Ljava/lang/Object;
.source "HtcClockSetting.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/htc/clock3dwidget/setting/HtcClockSetting;->onCreateDialog(I)Landroid/app/Dialog;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;


# direct methods
.method constructor <init>(Lcom/htc/clock3dwidget/setting/HtcClockSetting;)V
    .registers 2

    .prologue
    .line 203
    iput-object p1, p0, Lcom/htc/clock3dwidget/setting/HtcClockSetting$2;->this$0:Lcom/htc/clock3dwidget/setting/HtcClockSetting;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .registers 3
    .param p1, "dialog"    # Landroid/content/DialogInterface;
    .param p2, "whichButton"    # I

    .prologue
    .line 206
    return-void
.end method
