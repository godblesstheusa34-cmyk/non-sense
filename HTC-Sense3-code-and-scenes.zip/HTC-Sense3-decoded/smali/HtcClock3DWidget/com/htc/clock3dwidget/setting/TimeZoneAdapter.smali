.class public Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;
.super Landroid/widget/BaseAdapter;
.source "TimeZoneAdapter.java"


# instance fields
.field private final KEY_CITY:Ljava/lang/String;

.field private final KEY_NAME:Ljava/lang/String;

.field private mContext:Landroid/content/Context;

.field private mDataList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ljava/util/HashMap",
            "<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation
.end field

.field private mFilterIndexArray:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList",
            "<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private mIndexArray:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList",
            "<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private mInflater:Landroid/view/LayoutInflater;

.field private showAll:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/util/List;)V
    .registers 4
    .param p1, "context"    # Landroid/content/Context;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List",
            "<",
            "Ljava/util/HashMap",
            "<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;>;)V"
        }
    .end annotation

    .prologue
    .line 39
    .local p2, "data":Ljava/util/List;, "Ljava/util/List<Ljava/util/HashMap<Ljava/lang/String;Ljava/lang/String;>;>;"
    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 31
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->showAll:Z

    .line 32
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mIndexArray:Ljava/util/ArrayList;

    .line 33
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mFilterIndexArray:Ljava/util/ArrayList;

    .line 36
    const-string v0, "name"

    iput-object v0, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->KEY_NAME:Ljava/lang/String;

    .line 37
    const-string v0, "second_city"

    iput-object v0, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->KEY_CITY:Ljava/lang/String;

    .line 41
    iput-object p1, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mContext:Landroid/content/Context;

    .line 42
    const-string v0, "layout_inflater"

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/LayoutInflater;

    check-cast v0, Landroid/view/LayoutInflater;

    iput-object v0, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mInflater:Landroid/view/LayoutInflater;

    .line 44
    iput-object p2, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mDataList:Ljava/util/List;

    .line 45
    return-void
.end method


# virtual methods
.method public final getCount()I
    .registers 2

    .prologue
    .line 102
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->showAll:Z

    if-eqz v0, :cond_b

    iget-object v0, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mDataList:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    :goto_a
    return v0

    :cond_b
    iget-object v0, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mIndexArray:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    goto :goto_a
.end method

.method public final getCurrentFirstLetter(I)C
    .registers 6
    .param p1, "firstVisibleItem"    # I

    .prologue
    .line 107
    iget-boolean v3, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->showAll:Z

    if-nez v3, :cond_25

    iget-object v3, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mIndexArray:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    if-lez v3, :cond_25

    .line 108
    iget-object v3, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mIndexArray:Ljava/util/ArrayList;

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v0

    .line 111
    .local v0, "index":I
    :goto_18
    iget-object v3, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mDataList:Ljava/util/List;

    invoke-interface {v3, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/HashMap;

    .line 112
    .local v1, "map":Ljava/util/HashMap;, "Ljava/util/HashMap<Ljava/lang/String;Ljava/lang/String;>;"
    if-nez v1, :cond_27

    .line 113
    const/16 v3, 0x20

    .line 117
    :goto_24
    return v3

    .line 109
    .end local v0    # "index":I
    .end local v1    # "map":Ljava/util/HashMap;, "Ljava/util/HashMap<Ljava/lang/String;Ljava/lang/String;>;"
    :cond_25
    move v0, p1

    .restart local v0    # "index":I
    goto :goto_18

    .line 115
    .restart local v1    # "map":Ljava/util/HashMap;, "Ljava/util/HashMap<Ljava/lang/String;Ljava/lang/String;>;"
    :cond_27
    const-string v3, "name"

    invoke-virtual {v1, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 117
    .local v2, "name":Ljava/lang/String;
    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    goto :goto_24
.end method

.method public final getItem(I)Ljava/lang/Object;
    .registers 4
    .param p1, "position"    # I

    .prologue
    .line 96
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->showAll:Z

    if-nez v0, :cond_1f

    iget-object v0, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mIndexArray:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_1f

    .line 97
    iget-object v0, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mDataList:Ljava/util/List;

    iget-object v1, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mIndexArray:Ljava/util/ArrayList;

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    .end local p0    # "this":Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;
    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    .line 98
    :goto_1e
    return-object v0

    .restart local p0    # "this":Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;
    :cond_1f
    iget-object v0, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mDataList:Ljava/util/List;

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    goto :goto_1e
.end method

.method public final getItemId(I)J
    .registers 4
    .param p1, "position"    # I

    .prologue
    .line 90
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->showAll:Z

    if-nez v0, :cond_1a

    iget-object v0, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mIndexArray:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lez v0, :cond_1a

    .line 91
    iget-object v0, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mIndexArray:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    .end local p0    # "this":Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;
    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    int-to-long v0, v0

    .line 92
    :goto_19
    return-wide v0

    .restart local p0    # "this":Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;
    :cond_1a
    int-to-long v0, p1

    goto :goto_19
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .registers 12
    .param p1, "position"    # I
    .param p2, "convertView"    # Landroid/view/View;
    .param p3, "parent"    # Landroid/view/ViewGroup;

    .prologue
    const/4 v7, -0x1

    .line 55
    if-nez p2, :cond_43

    .line 56
    iget-object v4, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mInflater:Landroid/view/LayoutInflater;

    const v5, 0x2090007

    const/4 v6, 0x0

    invoke-virtual {v4, v5, p3, v6}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v2

    .line 65
    .local v2, "v":Landroid/view/View;
    :goto_d
    const v4, 0x2020010

    invoke-virtual {v2, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/TextView;

    .line 67
    .local v3, "vCity":Landroid/widget/TextView;
    iget-boolean v4, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->showAll:Z

    if-eqz v4, :cond_45

    move v0, p1

    .line 69
    .local v0, "index":I
    :goto_1b
    invoke-static {}, Lcom/htc/clock3dwidget/util/MyProjectSetting;->hasSeparateLine2()Z

    move-result v4

    if-eqz v4, :cond_2b

    .line 70
    if-nez v0, :cond_5d

    .line 71
    new-instance v4, Lcom/htc/clock3dwidget/setting/HtcCitySeparable;

    invoke-direct {v4}, Lcom/htc/clock3dwidget/setting/HtcCitySeparable;-><init>()V

    invoke-virtual {v2, v4}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    .line 77
    :cond_2b
    :goto_2b
    if-eq v0, v7, :cond_42

    .line 78
    iget-object v4, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mDataList:Ljava/util/List;

    invoke-interface {v4, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/HashMap;

    .line 80
    .local v1, "map":Ljava/util/HashMap;, "Ljava/util/HashMap<Ljava/lang/String;Ljava/lang/String;>;"
    if-eqz v1, :cond_42

    .line 81
    const-string v4, "name"

    invoke-virtual {v1, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    .end local p0    # "this":Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;
    check-cast p0, Ljava/lang/CharSequence;

    invoke-virtual {v3, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 86
    .end local v1    # "map":Ljava/util/HashMap;, "Ljava/util/HashMap<Ljava/lang/String;Ljava/lang/String;>;"
    :cond_42
    return-object v2

    .line 58
    .end local v0    # "index":I
    .end local v2    # "v":Landroid/view/View;
    .end local v3    # "vCity":Landroid/widget/TextView;
    .restart local p0    # "this":Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;
    :cond_43
    move-object v2, p2

    .restart local v2    # "v":Landroid/view/View;
    goto :goto_d

    .line 67
    .restart local v3    # "vCity":Landroid/widget/TextView;
    :cond_45
    iget-object v4, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mIndexArray:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    if-lez v4, :cond_5b

    iget-object v4, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mIndexArray:Ljava/util/ArrayList;

    invoke-virtual {v4, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    move v0, v4

    goto :goto_1b

    :cond_5b
    move v0, v7

    goto :goto_1b

    .line 74
    .restart local v0    # "index":I
    :cond_5d
    const/4 v4, 0x0

    invoke-virtual {v2, v4}, Landroid/view/View;->setTag(Ljava/lang/Object;)V

    goto :goto_2b
.end method

.method public setDataList(Ljava/util/List;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List",
            "<",
            "Ljava/util/HashMap",
            "<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;>;)V"
        }
    .end annotation

    .prologue
    .line 48
    .local p1, "data":Ljava/util/List;, "Ljava/util/List<Ljava/util/HashMap<Ljava/lang/String;Ljava/lang/String;>;>;"
    iput-object p1, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mDataList:Ljava/util/List;

    .line 49
    invoke-virtual {p0}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    .line 50
    return-void
.end method

.method public updateList(Ljava/lang/String;)I
    .registers 16
    .param p1, "prefix"    # Ljava/lang/String;

    .prologue
    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v10, 0x1

    const-string v13, "name"

    const-string v9, "second_city"

    .line 121
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v4

    .line 123
    .local v4, "len":I
    if-nez v4, :cond_20

    .line 124
    iput-boolean v10, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->showAll:Z

    .line 125
    iget-object v7, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mIndexArray:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->clear()V

    .line 126
    iget-object v7, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mFilterIndexArray:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->clear()V

    .line 162
    :cond_19
    :goto_19
    iget-object v7, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mIndexArray:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    return v7

    .line 127
    :cond_20
    if-ne v4, v10, :cond_7e

    .line 128
    iget-boolean v7, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->showAll:Z

    if-eqz v7, :cond_79

    .line 129
    iput-boolean v11, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->showAll:Z

    .line 131
    invoke-virtual {p1}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object p1

    .line 132
    const/4 v2, 0x0

    .local v2, "i":I
    :goto_2d
    iget-object v7, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mDataList:Ljava/util/List;

    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v7

    if-ge v2, v7, :cond_79

    .line 133
    iget-object v7, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mDataList:Ljava/util/List;

    invoke-interface {v7, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/HashMap;

    .line 134
    .local v5, "map":Ljava/util/HashMap;, "Ljava/util/HashMap<Ljava/lang/String;Ljava/lang/String;>;"
    if-nez v5, :cond_42

    .line 132
    :cond_3f
    :goto_3f
    add-int/lit8 v2, v2, 0x1

    goto :goto_2d

    .line 136
    :cond_42
    const-string v7, "name"

    invoke-virtual {v5, v13}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    .line 137
    .local v6, "name":Ljava/lang/String;
    const-string v7, "second_city"

    invoke-virtual {v5, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    if-eqz v7, :cond_77

    const-string v7, "second_city"

    invoke-virtual {v5, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-virtual {v7}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v7

    move-object v0, v7

    .line 139
    .local v0, "city":Ljava/lang/String;
    :goto_5f
    invoke-virtual {v6, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    if-nez v7, :cond_6d

    if-eqz v0, :cond_3f

    invoke-virtual {v0, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_3f

    .line 140
    :cond_6d
    iget-object v7, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mFilterIndexArray:Ljava/util/ArrayList;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_3f

    .end local v0    # "city":Ljava/lang/String;
    :cond_77
    move-object v0, v12

    .line 137
    goto :goto_5f

    .line 143
    .end local v2    # "i":I
    .end local v5    # "map":Ljava/util/HashMap;, "Ljava/util/HashMap<Ljava/lang/String;Ljava/lang/String;>;"
    .end local v6    # "name":Ljava/lang/String;
    :cond_79
    iget-object v7, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mFilterIndexArray:Ljava/util/ArrayList;

    iput-object v7, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mIndexArray:Ljava/util/ArrayList;

    goto :goto_19

    .line 146
    :cond_7e
    iget-object v7, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mIndexArray:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->clear()V

    .line 147
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, ""

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {p1, v11}, Ljava/lang/String;->charAt(I)C

    move-result v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 148
    .local v1, "firstCh":Ljava/lang/String;
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {p1, v10}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 150
    const/4 v2, 0x0

    .restart local v2    # "i":I
    :goto_b4
    iget-object v7, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mFilterIndexArray:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-ge v2, v7, :cond_19

    .line 151
    iget-object v7, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mFilterIndexArray:Ljava/util/ArrayList;

    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Integer;

    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v3

    .line 152
    .local v3, "index":I
    iget-object v7, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mDataList:Ljava/util/List;

    invoke-interface {v7, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/util/HashMap;

    .line 153
    .restart local v5    # "map":Ljava/util/HashMap;, "Ljava/util/HashMap<Ljava/lang/String;Ljava/lang/String;>;"
    if-nez v5, :cond_d5

    .line 150
    :cond_d2
    :goto_d2
    add-int/lit8 v2, v2, 0x1

    goto :goto_b4

    .line 155
    :cond_d5
    const-string v7, "name"

    invoke-virtual {v5, v13}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    .line 156
    .restart local v6    # "name":Ljava/lang/String;
    const-string v7, "second_city"

    invoke-virtual {v5, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    if-eqz v7, :cond_106

    const-string v7, "second_city"

    invoke-virtual {v5, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    move-object v0, v7

    .line 157
    .restart local v0    # "city":Ljava/lang/String;
    :goto_ee
    invoke-virtual {v6, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    if-nez v7, :cond_fc

    if-eqz v0, :cond_d2

    invoke-virtual {v0, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_d2

    .line 158
    :cond_fc
    iget-object v7, p0, Lcom/htc/clock3dwidget/setting/TimeZoneAdapter;->mIndexArray:Ljava/util/ArrayList;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_d2

    .end local v0    # "city":Ljava/lang/String;
    :cond_106
    move-object v0, v12

    .line 156
    goto :goto_ee
.end method
