.class public Lcom/htc/clock3dwidget/idlescreen/IdleScreenSettings;
.super Landroid/app/Activity;
.source "IdleScreenSettings.java"


# static fields
.field private static final DEFAULT_CLOCK_TYPE:Ljava/lang/String; = "0"

.field public static final EXTRA_KEY_PREFIX:Ljava/lang/String; = "com.htc.launcher.intent"

.field public static final EXTRA_KEY_WIDGET_PROVIDER_ARRAY:Ljava/lang/String; = "com.htc.launcher.intent.EXTRA_KEY_WIDGET_PROVIDER_ARRAY"

.field public static final EXTRA_KEY_WIDGET_PROVIDER_ARRAY_INDEX_FILTER:Ljava/lang/String; = "com.htc.launcher.intent.EXTRA_KEY_WIDGET_PROVIDER_ARRAY_INDEX_FILTER"

.field public static final EXTRA_KEY_WIDGET_PROVIDER_ARRAY_INDEX_SELECT:Ljava/lang/String; = "com.htc.launcher.intent.EXTRA_KEY_WIDGET_PROVIDER_ARRAY_INDEX_SELECT"

.field public static final FIRST_SET:Ljava/lang/String; = "first_set"

.field public static final IS_APPLY:Ljava/lang/String; = "is_apply"

.field private static final KEY_CLOCK_TYPE:Ljava/lang/String; = "clock_type"


# instance fields
.field private mFirstSet:Z


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 17
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private getApply()Z
    .registers 5

    .prologue
    const/4 v2, 0x0

    const-string v3, "is_apply"

    .line 74
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    .line 75
    .local v0, "intent":Landroid/content/Intent;
    if-eqz v0, :cond_1b

    .line 76
    const-string v1, "is_apply"

    invoke-virtual {v0, v3}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_1b

    .line 77
    const-string v1, "is_apply"

    invoke-virtual {v0, v3, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_1b

    .line 78
    const/4 v1, 0x1

    .line 82
    :goto_1a
    return v1

    :cond_1b
    move v1, v2

    goto :goto_1a
.end method

.method public static getClockType(Landroid/content/Context;)I
    .registers 5
    .param p0, "context"    # Landroid/content/Context;

    .prologue
    .line 67
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v1

    const-string v2, "clock_type"

    const-string v3, "0"

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 70
    .local v0, "type":Ljava/lang/String;
    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    return v1
.end method

.method private getFirstSet()Z
    .registers 4

    .prologue
    .line 86
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 88
    .local v0, "settings":Landroid/content/SharedPreferences;
    const-string v1, "first_set"

    const/4 v2, 0x0

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    iput-boolean v1, p0, Lcom/htc/clock3dwidget/idlescreen/IdleScreenSettings;->mFirstSet:Z

    .line 89
    iget-boolean v1, p0, Lcom/htc/clock3dwidget/idlescreen/IdleScreenSettings;->mFirstSet:Z

    return v1
.end method


# virtual methods
.method protected onActivityResult(IILandroid/content/Intent;)V
    .registers 9
    .param p1, "requestCode"    # I
    .param p2, "resultCode"    # I
    .param p3, "data"    # Landroid/content/Intent;

    .prologue
    .line 94
    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    .line 95
    if-eqz p3, :cond_37

    .line 96
    const-string v2, "com.htc.launcher.intent.EXTRA_KEY_WIDGET_PROVIDER_ARRAY_INDEX_SELECT"

    const/4 v3, 0x0

    invoke-virtual {p3, v2, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    .line 98
    .local v0, "index":I
    invoke-static {p0}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v1

    .line 100
    .local v1, "settings":Landroid/content/SharedPreferences;
    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "clock_type"

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 102
    iget-boolean v2, p0, Lcom/htc/clock3dwidget/idlescreen/IdleScreenSettings;->mFirstSet:Z

    if-nez v2, :cond_33

    .line 103
    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v3, "first_set"

    const/4 v4, 0x1

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 105
    :cond_33
    const/4 v2, -0x1

    invoke-virtual {p0, v2}, Landroid/app/Activity;->setResult(I)V

    .line 107
    .end local v0    # "index":I
    .end local v1    # "settings":Landroid/content/SharedPreferences;
    :cond_37
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 108
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 13
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .prologue
    const/4 v9, 0x0

    const-string v10, ".fusionwidget.StyleChooser"

    .line 32
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 33
    invoke-direct {p0}, Lcom/htc/clock3dwidget/idlescreen/IdleScreenSettings;->getApply()Z

    move-result v6

    if-eqz v6, :cond_1a

    invoke-direct {p0}, Lcom/htc/clock3dwidget/idlescreen/IdleScreenSettings;->getFirstSet()Z

    move-result v6

    if-eqz v6, :cond_1a

    .line 34
    const/4 v6, -0x1

    invoke-virtual {p0, v6}, Landroid/app/Activity;->setResult(I)V

    .line 35
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 59
    :goto_19
    return-void

    .line 39
    :cond_1a
    const-string v1, "com.htc.AddProgramWidget"

    .line 40
    .local v1, "PKG":Ljava/lang/String;
    const-string v0, ".fusionwidget.StyleChooser"

    .line 41
    .local v0, "CLASS":Ljava/lang/String;
    new-instance v3, Landroid/content/Intent;

    invoke-direct {v3}, Landroid/content/Intent;-><init>()V

    .line 42
    .local v3, "intent":Landroid/content/Intent;
    new-instance v6, Landroid/content/ComponentName;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, ".fusionwidget.StyleChooser"

    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v1, v7}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v3, v6}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 43
    invoke-virtual {p0}, Landroid/content/ContextWrapper;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v6

    invoke-virtual {v6, v3, v9}, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;

    move-result-object v6

    if-nez v6, :cond_65

    .line 44
    const-string v1, "com.htc.home.personalize"

    .line 45
    new-instance v6, Landroid/content/ComponentName;

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, ".fusionwidget.StyleChooser"

    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v1, v7}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v3, v6}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 47
    :cond_65
    const/4 v6, 0x1

    new-array v4, v6, [Landroid/content/ComponentName;

    .line 48
    .local v4, "p":[Landroid/content/ComponentName;
    new-instance v6, Landroid/content/ComponentName;

    const-string v7, "com.htc.clock3dwidget"

    const-string v8, "com.htc.clock3dwidget.ClockWidgetProvider"

    invoke-direct {v6, v7, v8}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    aput-object v6, v4, v9

    .line 50
    const/16 v6, 0xb

    new-array v5, v6, [I

    fill-array-data v5, :array_a8

    .line 53
    .local v5, "value":[I
    :try_start_7a
    const-string v6, "com.htc.launcher.intent.EXTRA_KEY_WIDGET_PROVIDER_ARRAY"

    invoke-virtual {v3, v6, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 54
    const-string v6, "com.htc.launcher.intent.EXTRA_KEY_WIDGET_PROVIDER_ARRAY_INDEX_FILTER"

    invoke-virtual {v3, v6, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[I)Landroid/content/Intent;

    .line 55
    const/4 v6, 0x0

    invoke-virtual {p0, v3, v6}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V
    :try_end_88
    .catch Ljava/lang/Exception; {:try_start_7a .. :try_end_88} :catch_89

    goto :goto_19

    .line 56
    :catch_89
    move-exception v6

    move-object v2, v6

    .line 57
    .local v2, "ex":Ljava/lang/Exception;
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "exception"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v2}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    goto/16 :goto_19

    .line 50
    nop

    :array_a8
    .array-data 4
        0x4
        0x6
        0x7
        0x8
        0x9
        0xa
        0xb
        0xc
        0xd
        0xe
        0xf
    .end array-data
.end method

.method protected onResume()V
    .registers 1

    .prologue
    .line 63
    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    .line 64
    return-void
.end method
