.class public Lcom/htc/clock3dwidget/Clock05;
.super Lcom/htc/clock3dwidget/analogclock/AnalogClockWidgetView;
.source "Clock05.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 8
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidgetView;-><init>()V

    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .registers 3
    .param p1, "saved"    # Landroid/os/Bundle;

    .prologue
    .line 10
    sget-object v0, Lcom/htc/clock3dwidget/ClockUtils$ClockType;->CLOCK_05:Lcom/htc/clock3dwidget/ClockUtils$ClockType;

    iput-object v0, p0, Lcom/htc/clock3dwidget/Clock05;->mClockType:Lcom/htc/clock3dwidget/ClockUtils$ClockType;

    .line 11
    invoke-super {p0, p1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidgetView;->onCreate(Landroid/os/Bundle;)V

    .line 12
    return-void
.end method
