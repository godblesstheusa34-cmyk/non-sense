.class public final Lcom/htc/clock3dwidget/R$xml;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock3dwidget/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "xml"
.end annotation


# static fields
.field public static final clock_widget:I = 0x7f040000

.field public static final idle_screen_clock:I = 0x7f040001


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 3842
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
