.class Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$1;
.super Ljava/lang/Object;
.source "AnalogClockWidget.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;


# direct methods
.method constructor <init>(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)V
    .registers 2

    .prologue
    .line 198
    iput-object p1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$1;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 6
    .param p1, "arg0"    # Landroid/view/View;

    .prologue
    .line 200
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$1;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    const v1, 0x9012

    const-wide/16 v2, 0x0

    invoke-virtual {v0, v1, v2, v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->sendNonUiMessageDelayed(IJ)V

    .line 201
    return-void
.end method
