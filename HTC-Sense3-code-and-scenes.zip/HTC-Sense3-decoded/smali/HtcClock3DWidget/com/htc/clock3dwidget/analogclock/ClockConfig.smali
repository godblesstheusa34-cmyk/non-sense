.class public Lcom/htc/clock3dwidget/analogclock/ClockConfig;
.super Ljava/lang/Object;
.source "ClockConfig.java"


# instance fields
.field bShowCityLabel:Z

.field citnameCode:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    return-void
.end method
