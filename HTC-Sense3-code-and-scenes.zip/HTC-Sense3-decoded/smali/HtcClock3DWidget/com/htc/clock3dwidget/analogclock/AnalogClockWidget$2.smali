.class Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;
.super Ljava/lang/Object;
.source "AnalogClockWidget.java"

# interfaces
.implements Landroid/os/Handler$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;


# direct methods
.method constructor <init>(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)V
    .registers 2

    .prologue
    .line 285
    iput-object p1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)Z
    .registers 11
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    const/4 v8, 0x0

    const v5, 0x9002

    const v7, 0x8019

    const v6, 0x8001

    const/4 v4, 0x0

    .line 287
    iget v3, p1, Landroid/os/Message;->what:I

    sparse-switch v3, :sswitch_data_1c6

    .line 373
    .end local p0    # "this":Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;
    :cond_10
    :goto_10
    const/4 v3, 0x1

    return v3

    .line 289
    .restart local p0    # "this":Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;
    :sswitch_12
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mInstanceCallback:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$InstanceCallback;
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$100(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$InstanceCallback;

    move-result-object v3

    if-eqz v3, :cond_36

    .line 290
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mInstanceCallback:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$InstanceCallback;
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$100(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$InstanceCallback;

    move-result-object v3

    invoke-interface {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$InstanceCallback;->loadPropertyData()Lcom/htc/clock3dwidget/analogclock/ClockConfig;

    move-result-object v0

    .line 291
    .local v0, "config":Lcom/htc/clock3dwidget/analogclock/ClockConfig;
    if-eqz v0, :cond_30

    .line 292
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    iget-object v4, v0, Lcom/htc/clock3dwidget/analogclock/ClockConfig;->citnameCode:Ljava/lang/String;

    iget-boolean v5, v0, Lcom/htc/clock3dwidget/analogclock/ClockConfig;->bShowCityLabel:Z

    # invokes: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->initData(Ljava/lang/String;Z)V
    invoke-static {v3, v4, v5}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$200(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;Ljava/lang/String;Z)V

    goto :goto_10

    .line 294
    :cond_30
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # invokes: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->initData(Ljava/lang/String;Z)V
    invoke-static {v3, v8, v4}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$200(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;Ljava/lang/String;Z)V

    goto :goto_10

    .line 297
    .end local v0    # "config":Lcom/htc/clock3dwidget/analogclock/ClockConfig;
    :cond_36
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # invokes: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->initData(Ljava/lang/String;Z)V
    invoke-static {v3, v8, v4}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$200(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;Ljava/lang/String;Z)V

    goto :goto_10

    .line 301
    :sswitch_3c
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-virtual {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->what_Is_Paused()V

    goto :goto_10

    .line 304
    :sswitch_42
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-virtual {v3, v5}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeNonUiMessages(I)V

    .line 305
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$300(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    move-result-object v3

    if-eqz v3, :cond_87

    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$400(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock/util/time/TimeCtrl;

    move-result-object v3

    if-eqz v3, :cond_87

    .line 306
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$400(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock/util/time/TimeCtrl;

    move-result-object v3

    invoke-virtual {v3}, Lcom/htc/clock/util/time/TimeCtrl;->updateFormat()Z

    .line 307
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$300(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    move-result-object v3

    iget-object v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;
    invoke-static {v4}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$400(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock/util/time/TimeCtrl;

    move-result-object v4

    invoke-virtual {v4}, Lcom/htc/clock/util/time/TimeCtrl;->is24HourFormat()Z

    move-result v4

    iget-object v5, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;
    invoke-static {v5}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$400(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock/util/time/TimeCtrl;

    move-result-object v5

    invoke-virtual {v5}, Lcom/htc/clock/util/time/TimeCtrl;->getDateFormat()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v4, v5}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->setDateFormat(ZLjava/lang/String;)V

    .line 310
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-virtual {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->updateTimeZone()V

    .line 311
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-virtual {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->updateCityName()V

    .line 313
    :cond_87
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$300(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    move-result-object v3

    if-eqz v3, :cond_10

    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    iget-boolean v3, v3, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mPauseByAddToHome:Z

    if-nez v3, :cond_10

    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$500(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    move-result-object v3

    if-eqz v3, :cond_10

    .line 316
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$300(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    move-result-object v3

    if-eqz v3, :cond_10

    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$300(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    move-result-object v3

    iget-boolean v3, v3, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUseAnimation:Z

    if-eqz v3, :cond_10

    .line 317
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-virtual {v3, v7}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeUiMessages(I)V

    .line 318
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$500(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    move-result-object v3

    invoke-interface {v3}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->obtainMessage()Landroid/os/Message;

    move-result-object v1

    .line 319
    .local v1, "message":Landroid/os/Message;
    iput v7, v1, Landroid/os/Message;->what:I

    .line 320
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    const-wide/16 v4, 0x0

    invoke-virtual {v3, v1, v4, v5}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->sendUiMessageDelayed(Landroid/os/Message;J)V

    goto/16 :goto_10

    .line 325
    .end local v1    # "message":Landroid/os/Message;
    :sswitch_c9
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    sget-object v4, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;->RESUME:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;

    # setter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiState:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;
    invoke-static {v3, v4}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$602(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;)Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;

    .line 326
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-virtual {v3, v5}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeNonUiMessages(I)V

    .line 327
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$300(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    move-result-object v3

    if-eqz v3, :cond_115

    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$400(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock/util/time/TimeCtrl;

    move-result-object v3

    if-eqz v3, :cond_115

    .line 328
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$400(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock/util/time/TimeCtrl;

    move-result-object v3

    invoke-virtual {v3}, Lcom/htc/clock/util/time/TimeCtrl;->updateFormat()Z

    .line 329
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$300(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    move-result-object v3

    iget-object v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;
    invoke-static {v4}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$400(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock/util/time/TimeCtrl;

    move-result-object v4

    invoke-virtual {v4}, Lcom/htc/clock/util/time/TimeCtrl;->is24HourFormat()Z

    move-result v4

    iget-object v5, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;
    invoke-static {v5}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$400(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock/util/time/TimeCtrl;

    move-result-object v5

    invoke-virtual {v5}, Lcom/htc/clock/util/time/TimeCtrl;->getDateFormat()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v4, v5}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->setDateFormat(ZLjava/lang/String;)V

    .line 332
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-virtual {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->updateTimeZone()V

    .line 333
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-virtual {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->updateCityName()V

    .line 335
    :cond_115
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "WHAT_ON_RESUME~ notifyCause:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget v4, p1, Landroid/os/Message;->arg1:I

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/htc/clock/util/MyLog;->d(Ljava/lang/String;)V

    .line 337
    const/4 v1, 0x0

    .line 338
    .restart local v1    # "message":Landroid/os/Message;
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$500(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    move-result-object v3

    if-eqz v3, :cond_167

    .line 339
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$500(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    move-result-object v3

    invoke-interface {v3}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->obtainMessage()Landroid/os/Message;

    move-result-object v1

    .line 340
    iput v6, v1, Landroid/os/Message;->what:I

    .line 341
    iget v3, p1, Landroid/os/Message;->arg1:I

    iput v3, v1, Landroid/os/Message;->arg1:I

    .line 342
    iget v3, p1, Landroid/os/Message;->arg2:I

    iput v3, v1, Landroid/os/Message;->arg2:I

    .line 349
    :cond_14a
    :goto_14a
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    const-wide/16 v4, 0x0

    invoke-virtual {v3, v1, v4, v5}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->sendUiMessageDelayed(Landroid/os/Message;J)V

    .line 350
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    const v4, 0x8022

    invoke-static {}, Ljava/lang/Math;->random()D

    move-result-wide v5

    const-wide v7, 0x409f400000000000L    # 2000.0

    mul-double/2addr v5, v7

    double-to-int v5, v5

    int-to-long v5, v5

    invoke-virtual {v3, v4, v5, v6}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->sendUiMessageDelayed(IJ)V

    goto/16 :goto_10

    .line 343
    :cond_167
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhUiHandler:Landroid/os/Handler;
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$700(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Landroid/os/Handler;

    move-result-object v3

    if-eqz v3, :cond_14a

    .line 344
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhUiHandler:Landroid/os/Handler;
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$700(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Landroid/os/Handler;

    move-result-object v3

    invoke-virtual {v3}, Landroid/os/Handler;->obtainMessage()Landroid/os/Message;

    move-result-object v1

    .line 345
    iput v6, v1, Landroid/os/Message;->what:I

    .line 346
    iget v3, p1, Landroid/os/Message;->arg1:I

    iput v3, v1, Landroid/os/Message;->arg1:I

    .line 347
    iget v3, p1, Landroid/os/Message;->arg2:I

    iput v3, v1, Landroid/os/Message;->arg2:I

    goto :goto_14a

    .line 353
    .end local v1    # "message":Landroid/os/Message;
    :sswitch_184
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    sget-object v4, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;->PAUSED:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;

    # setter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiState:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;
    invoke-static {v3, v4}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$602(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;)Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;

    .line 354
    iget v2, p1, Landroid/os/Message;->arg1:I

    .line 355
    .local v2, "notifyCause":I
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-virtual {v3, v2}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->onNotifyWidgetPause(I)V

    goto/16 :goto_10

    .line 358
    .end local v2    # "notifyCause":I
    :sswitch_194
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # invokes: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->doTimeChanged()V
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$800(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)V

    goto/16 :goto_10

    .line 361
    :sswitch_19b
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # invokes: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->doFormatChanged()V
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$900(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)V

    goto/16 :goto_10

    .line 364
    :sswitch_1a2
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # invokes: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->doConfigurationChanged()V
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$1000(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)V

    goto/16 :goto_10

    .line 367
    :sswitch_1a9
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mApplication:Landroid/content/Context;
    invoke-static {v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$1100(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Landroid/content/Context;

    move-result-object v3

    iget-object v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mCityCode:Ljava/lang/String;
    invoke-static {v4}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$1200(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lcom/htc/clock/util/MyUtil;->launchWorldClockAp(Landroid/content/Context;Ljava/lang/String;)V

    goto/16 :goto_10

    .line 370
    :sswitch_1ba
    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    iget-object p0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    .end local p0    # "this":Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;
    check-cast p0, Landroid/content/Intent;

    # invokes: Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->doActivityResult(Landroid/content/Intent;)V
    invoke-static {v3, p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$1300(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;Landroid/content/Intent;)V

    goto/16 :goto_10

    .line 287
    nop

    :sswitch_data_1c6
    .sparse-switch
        0x1 -> :sswitch_c9
        0x2 -> :sswitch_184
        0x9001 -> :sswitch_12
        0x9002 -> :sswitch_3c
        0x9003 -> :sswitch_194
        0x9011 -> :sswitch_1a2
        0x9012 -> :sswitch_1a9
        0x9014 -> :sswitch_1ba
        0x9015 -> :sswitch_42
        0x9205 -> :sswitch_19b
    .end sparse-switch
.end method
