.class Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$MyTimeListener;
.super Ljava/lang/Object;
.source "AnalogClockWidget.java"

# interfaces
.implements Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "MyTimeListener"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;


# direct methods
.method private constructor <init>(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)V
    .registers 2

    .prologue
    .line 257
    iput-object p1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$MyTimeListener;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$1;)V
    .registers 3
    .param p1, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;
    .param p2, "x1"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$1;

    .prologue
    .line 257
    invoke-direct {p0, p1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$MyTimeListener;-><init>(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)V

    return-void
.end method


# virtual methods
.method public onFormatChanged()V
    .registers 5

    .prologue
    .line 265
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$MyTimeListener;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    const v1, 0x9205

    const-wide/16 v2, 0x0

    invoke-virtual {v0, v1, v2, v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->sendNonUiMessageDelayed(IJ)V

    .line 266
    return-void
.end method

.method public onMinute()V
    .registers 5

    .prologue
    .line 259
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$MyTimeListener;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    const v1, 0x9003

    const-wide/16 v2, 0x0

    invoke-virtual {v0, v1, v2, v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->sendNonUiMessageDelayed(IJ)V

    .line 260
    return-void
.end method

.method public onSecond()V
    .registers 1

    .prologue
    .line 262
    return-void
.end method

.method public onTimeChanged()V
    .registers 5

    .prologue
    .line 269
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$MyTimeListener;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    const v1, 0x9003

    const-wide/16 v2, 0x0

    invoke-virtual {v0, v1, v2, v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->sendNonUiMessageDelayed(IJ)V

    .line 270
    return-void
.end method

.method public onTimeZoneChanged()V
    .registers 5

    .prologue
    .line 273
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$MyTimeListener;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    const v1, 0x8005

    const-wide/16 v2, 0x0

    invoke-virtual {v0, v1, v2, v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->sendUiMessageDelayed(IJ)V

    .line 274
    return-void
.end method
