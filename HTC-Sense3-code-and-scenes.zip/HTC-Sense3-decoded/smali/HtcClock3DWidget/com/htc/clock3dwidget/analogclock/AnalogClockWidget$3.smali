.class Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$3;
.super Ljava/lang/Object;
.source "AnalogClockWidget.java"

# interfaces
.implements Landroid/os/Handler$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;


# direct methods
.method constructor <init>(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)V
    .registers 2

    .prologue
    .line 383
    iput-object p1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$3;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)Z
    .registers 4
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    const/4 v1, 0x0

    .line 385
    iget v0, p1, Landroid/os/Message;->what:I

    sparse-switch v0, :sswitch_data_72

    .line 416
    :cond_6
    :goto_6
    const/4 v0, 0x1

    return v0

    .line 387
    :sswitch_8
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$3;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-static {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$300(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    move-result-object v0

    if-eqz v0, :cond_6

    .line 388
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$3;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-static {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$300(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    move-result-object v0

    iget-boolean v0, v0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUseAnimation:Z

    if-eqz v0, :cond_24

    .line 389
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$3;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-static {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$300(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    move-result-object v0

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->startAnimation()V

    goto :goto_6

    .line 391
    :cond_24
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$3;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-static {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$300(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->setPause(Z)V

    goto :goto_6

    .line 396
    :sswitch_2e
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$3;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-static {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$300(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    move-result-object v0

    if-eqz v0, :cond_6

    .line 397
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$3;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-static {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$300(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    move-result-object v0

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->playWiggle()V

    goto :goto_6

    .line 401
    :sswitch_40
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$3;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-static {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$300(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    move-result-object v0

    if-eqz v0, :cond_6

    .line 402
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$3;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-static {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$300(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    move-result-object v0

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->prepareAnimation()V

    goto :goto_6

    .line 405
    :sswitch_52
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$3;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->updateCityName()V

    goto :goto_6

    .line 408
    :sswitch_58
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$3;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->updateTimeZone()V

    .line 409
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$3;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->updateCityName()V

    .line 410
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$3;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->updateTime()V

    goto :goto_6

    .line 413
    :sswitch_68
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$3;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    invoke-static {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->access$300(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    move-result-object v0

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->invalidate(Z)V

    goto :goto_6

    .line 385
    :sswitch_data_72
    .sparse-switch
        0x8001 -> :sswitch_8
        0x8004 -> :sswitch_52
        0x8005 -> :sswitch_58
        0x8011 -> :sswitch_68
        0x8019 -> :sswitch_40
        0x8022 -> :sswitch_2e
    .end sparse-switch
.end method
