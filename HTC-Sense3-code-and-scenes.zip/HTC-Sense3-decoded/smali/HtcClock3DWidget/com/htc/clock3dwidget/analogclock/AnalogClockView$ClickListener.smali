.class Lcom/htc/clock3dwidget/analogclock/AnalogClockView$ClickListener;
.super Lcom/htc/fusion/fx/MessageListener;
.source "AnalogClockView.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock3dwidget/analogclock/AnalogClockView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "ClickListener"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/htc/fusion/fx/MessageListener",
        "<",
        "Lcom/htc/fusion/fx/controls/FxHitbox$TapParameters;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;


# direct methods
.method private constructor <init>(Lcom/htc/clock3dwidget/analogclock/AnalogClockView;)V
    .registers 2

    .prologue
    .line 624
    iput-object p1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView$ClickListener;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    invoke-direct {p0}, Lcom/htc/fusion/fx/MessageListener;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/htc/clock3dwidget/analogclock/AnalogClockView;Lcom/htc/clock3dwidget/analogclock/AnalogClockView$1;)V
    .registers 3
    .param p1, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockView;
    .param p2, "x1"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockView$1;

    .prologue
    .line 624
    invoke-direct {p0, p1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView$ClickListener;-><init>(Lcom/htc/clock3dwidget/analogclock/AnalogClockView;)V

    return-void
.end method


# virtual methods
.method public onMessageReceived(Lcom/htc/fusion/fx/controls/FxHitbox$TapParameters;)V
    .registers 4
    .param p1, "message"    # Lcom/htc/fusion/fx/controls/FxHitbox$TapParameters;

    .prologue
    .line 626
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView$ClickListener;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mClickListener:Landroid/view/View$OnClickListener;
    invoke-static {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->access$100(Lcom/htc/clock3dwidget/analogclock/AnalogClockView;)Landroid/view/View$OnClickListener;

    move-result-object v0

    if-eqz v0, :cond_12

    .line 627
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView$ClickListener;->this$0:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    # getter for: Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mClickListener:Landroid/view/View$OnClickListener;
    invoke-static {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->access$100(Lcom/htc/clock3dwidget/analogclock/AnalogClockView;)Landroid/view/View$OnClickListener;

    move-result-object v0

    const/4 v1, 0x0

    invoke-interface {v0, v1}, Landroid/view/View$OnClickListener;->onClick(Landroid/view/View;)V

    .line 629
    :cond_12
    return-void
.end method

.method public bridge synthetic onMessageReceived(Ljava/lang/Object;)V
    .registers 2
    .param p1, "x0"    # Ljava/lang/Object;

    .prologue
    .line 624
    check-cast p1, Lcom/htc/fusion/fx/controls/FxHitbox$TapParameters;

    .end local p1    # "x0":Ljava/lang/Object;
    invoke-virtual {p0, p1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView$ClickListener;->onMessageReceived(Lcom/htc/fusion/fx/controls/FxHitbox$TapParameters;)V

    return-void
.end method
