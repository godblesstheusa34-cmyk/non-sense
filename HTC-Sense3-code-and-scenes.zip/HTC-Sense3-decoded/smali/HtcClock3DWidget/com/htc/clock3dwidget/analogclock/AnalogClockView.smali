.class public Lcom/htc/clock3dwidget/analogclock/AnalogClockView;
.super Ljava/lang/Object;
.source "AnalogClockView.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/htc/clock3dwidget/analogclock/AnalogClockView$ClickListener;
    }
.end annotation


# instance fields
.field protected final ANIMATION_HOUR_COUNT:I

.field protected final ANIMATION_MINUTE_COUNT:I

.field protected isAnimation:Z

.field private m24HourFormat:Z

.field public mAMPM:I

.field private mAmPmInit:Z

.field private mAmPmType:I

.field protected mAm_Pm:[Ljava/lang/CharSequence;

.field protected mAnimStart:J

.field protected mCalendar:Ljava/util/Calendar;

.field public mCityName:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field private mClickListener:Landroid/view/View$OnClickListener;

.field private mClockClickLand:Lcom/htc/clock3dwidget/analogclock/AnalogClockView$ClickListener;

.field private mClockClickPort:Lcom/htc/clock3dwidget/analogclock/AnalogClockView$ClickListener;

.field protected mClockStyle:I

.field protected mContext:Landroid/content/Context;

.field private mDateFormat:Ljava/lang/String;

.field protected mDay:Ljava/lang/String;

.field private mDayPanel:Z

.field private mDayPanelInit:Z

.field protected mDaysOfWeek:[Ljava/lang/CharSequence;

.field protected mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

.field protected mDigital_Hour_ten:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mDigital_Hour_unit:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

.field protected mDigital_Minute_ten:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mDigital_Minute_unit:Lcom/htc/fusion/fx/FxTimelineControl;

.field private mFlipAnimePrepared:Z

.field protected mFxClockBase:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mFxClockDate:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mFxClockHour:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mFxClockMinute:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mFxClockNumbers:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mFxHitbox:Lcom/htc/fusion/fx/controls/FxHitbox;

.field protected mFxPBHour:Lcom/htc/fusion/fx/controls/FxProgressBar;

.field protected mFxPBMin:Lcom/htc/fusion/fx/controls/FxProgressBar;

.field protected mFxPBSec:Lcom/htc/fusion/fx/controls/FxProgressBar;

.field protected mFxPBUintHour:Lcom/htc/fusion/fx/controls/FxProgressBar;

.field protected mFxPBUnitMin:Lcom/htc/fusion/fx/controls/FxProgressBar;

.field protected mFxTextAMPM:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field protected mFxTextAMPM_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field protected mFxTextDate:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field protected mFxTextDate_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field protected mFxTextHour:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field protected mFxTextLongDate:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field protected mFxTextMinute:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field protected mFxTextSecond:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field protected mFxTextWeekDay:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field protected mFxTextWeekDay_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field protected mFxTimeLineGear01:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mFxTimeLineGear02:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mFxTimeLineGear03:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mFxTimeLineGear04:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mFxTimeLineGear05:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mFxTimeLineWiggle:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mFxTimelineAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mFxTimelineAmPmOpp:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mFxTimelineClock:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mFxTimelineClockAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mHour:I

.field protected mHourCap:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mMarkerHour:Lcom/htc/fusion/fx/Marker;

.field protected mMarkerMin:Lcom/htc/fusion/fx/Marker;

.field protected mMinCap:Lcom/htc/fusion/fx/FxTimelineControl;

.field protected mMinuteFlipCount:I

.field public mMinutes:I

.field protected mMonth:[Ljava/lang/CharSequence;

.field protected mOldHour:I

.field protected mOldMinutes:I

.field private mPaused:Z

.field protected mRadius:I

.field protected mResContext:Landroid/content/Context;

.field public mSeconds:I

.field protected mTextHeight:I

.field protected mTextWidth:I

.field private mTicker:Ljava/lang/Runnable;

.field private mTickerStopped:Z

.field protected mTileMark:Lcom/htc/fusion/fx/Marker;

.field protected mTiltAnime:Lcom/htc/fusion/fx/FxTimelineControl;

.field private mTimePBInit:Z

.field private mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

.field private mUnitHourValue:F

.field private mUnitMinValue:F

.field private mUpdateIntervals:I

.field public mUseAnimation:Z

.field protected mWeek:Ljava/lang/String;

.field private mhUiHandler:Landroid/os/Handler;


# direct methods
.method constructor <init>(Landroid/content/Context;Landroid/content/Context;)V
    .registers 9
    .param p1, "resContext"    # Landroid/content/Context;
    .param p2, "context"    # Landroid/content/Context;

    .prologue
    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const-string v2, ""

    .line 148
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 90
    iput v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUnitMinValue:F

    .line 91
    iput v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUnitHourValue:F

    .line 93
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDayPanel:Z

    .line 94
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDayPanelInit:Z

    .line 98
    const-string v1, ""

    iput-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDay:Ljava/lang/String;

    .line 99
    const-string v1, ""

    iput-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mWeek:Ljava/lang/String;

    .line 108
    iput v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mClockStyle:I

    .line 116
    iput v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmType:I

    .line 117
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    .line 118
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTimePBInit:Z

    .line 123
    iput-boolean v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mPaused:Z

    .line 124
    iput-boolean v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTickerStopped:Z

    .line 126
    const-wide/16 v1, -0x1

    iput-wide v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAnimStart:J

    .line 131
    new-instance v1, Lcom/htc/clock3dwidget/analogclock/AnalogClockView$ClickListener;

    invoke-direct {v1, p0, v5}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView$ClickListener;-><init>(Lcom/htc/clock3dwidget/analogclock/AnalogClockView;Lcom/htc/clock3dwidget/analogclock/AnalogClockView$1;)V

    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mClockClickPort:Lcom/htc/clock3dwidget/analogclock/AnalogClockView$ClickListener;

    .line 132
    new-instance v1, Lcom/htc/clock3dwidget/analogclock/AnalogClockView$ClickListener;

    invoke-direct {v1, p0, v5}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView$ClickListener;-><init>(Lcom/htc/clock3dwidget/analogclock/AnalogClockView;Lcom/htc/clock3dwidget/analogclock/AnalogClockView$1;)V

    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mClockClickLand:Lcom/htc/clock3dwidget/analogclock/AnalogClockView$ClickListener;

    .line 134
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->m24HourFormat:Z

    .line 136
    const/16 v1, 0x3e8

    iput v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUpdateIntervals:I

    .line 137
    invoke-static {}, Lcom/htc/clock3dwidget/util/MyProjectSetting;->isFlipEnable()Z

    move-result v1

    iput-boolean v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUseAnimation:Z

    .line 138
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFlipAnimePrepared:Z

    .line 140
    iput v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mOldHour:I

    .line 141
    iput v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mOldMinutes:I

    .line 142
    iput v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->ANIMATION_HOUR_COUNT:I

    .line 143
    const/4 v1, 0x2

    iput v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->ANIMATION_MINUTE_COUNT:I

    .line 760
    new-instance v1, Lcom/htc/clock3dwidget/analogclock/AnalogClockView$1;

    invoke-direct {v1, p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView$1;-><init>(Lcom/htc/clock3dwidget/analogclock/AnalogClockView;)V

    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTicker:Ljava/lang/Runnable;

    .line 149
    iput-object p1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mResContext:Landroid/content/Context;

    .line 150
    iput-object p2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mContext:Landroid/content/Context;

    .line 151
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mResContext:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    .line 152
    .local v0, "r":Landroid/content/res/Resources;
    const/high16 v1, 0x7f070000

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getTextArray(I)[Ljava/lang/CharSequence;

    move-result-object v1

    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDaysOfWeek:[Ljava/lang/CharSequence;

    .line 153
    const v1, 0x7f070001

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getTextArray(I)[Ljava/lang/CharSequence;

    move-result-object v1

    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMonth:[Ljava/lang/CharSequence;

    .line 154
    const v1, 0x7f070002

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getTextArray(I)[Ljava/lang/CharSequence;

    move-result-object v1

    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAm_Pm:[Ljava/lang/CharSequence;

    .line 155
    return-void
.end method

.method static synthetic access$100(Lcom/htc/clock3dwidget/analogclock/AnalogClockView;)Landroid/view/View$OnClickListener;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    .prologue
    .line 30
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mClickListener:Landroid/view/View$OnClickListener;

    return-object v0
.end method

.method static synthetic access$200(Lcom/htc/clock3dwidget/analogclock/AnalogClockView;)Z
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    .prologue
    .line 30
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTickerStopped:Z

    return v0
.end method

.method static synthetic access$300(Lcom/htc/clock3dwidget/analogclock/AnalogClockView;)V
    .registers 1
    .param p0, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    .prologue
    .line 30
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->updateTime()V

    return-void
.end method

.method static synthetic access$400(Lcom/htc/clock3dwidget/analogclock/AnalogClockView;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    .prologue
    .line 30
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    return-object v0
.end method

.method static synthetic access$500(Lcom/htc/clock3dwidget/analogclock/AnalogClockView;)Ljava/lang/Runnable;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    .prologue
    .line 30
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTicker:Ljava/lang/Runnable;

    return-object v0
.end method

.method static synthetic access$600(Lcom/htc/clock3dwidget/analogclock/AnalogClockView;)I
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    .prologue
    .line 30
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUpdateIntervals:I

    return v0
.end method

.method static synthetic access$700(Lcom/htc/clock3dwidget/analogclock/AnalogClockView;)Landroid/os/Handler;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    .prologue
    .line 30
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mhUiHandler:Landroid/os/Handler;

    return-object v0
.end method

.method private applyRotation()V
    .registers 4

    .prologue
    .line 911
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_17

    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_17

    .line 912
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setDestNumber(I)V

    .line 913
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMinutes:I

    const/4 v2, 0x2

    invoke-virtual {v0, v1, v2}, Lcom/htc/clock3dwidget/util/DigitControl;->setDestNumber(II)V

    .line 915
    :cond_17
    return-void
.end method

.method private calcHourPBValue(FIII)F
    .registers 9
    .param p1, "max"    # F
    .param p2, "nHour"    # I
    .param p3, "nMin"    # I
    .param p4, "nSec"    # I

    .prologue
    .line 263
    const/high16 v2, 0x3f800000    # 1.0f

    add-float v0, p1, v2

    .line 264
    .local v0, "nPBMax":F
    mul-int/lit16 v2, p2, 0xe10

    mul-int/lit8 v3, p3, 0x3c

    add-int/2addr v2, v3

    add-int/2addr v2, p4

    int-to-float v1, v2

    .line 266
    .local v1, "nSeconds":F
    mul-float v2, v1, v0

    const v3, 0x4728c000    # 43200.0f

    div-float/2addr v2, v3

    return v2
.end method

.method private calcMinPBValue(FII)F
    .registers 8
    .param p1, "max"    # F
    .param p2, "nMin"    # I
    .param p3, "nSec"    # I

    .prologue
    .line 270
    const/high16 v2, 0x3f800000    # 1.0f

    add-float v0, p1, v2

    .line 271
    .local v0, "nPBMax":F
    mul-int/lit8 v2, p2, 0x3c

    add-int/2addr v2, p3

    int-to-float v1, v2

    .line 273
    .local v1, "nSeconds":F
    mul-float v2, v1, v0

    const/high16 v3, 0x45610000    # 3600.0f

    div-float/2addr v2, v3

    return v2
.end method

.method private calcSecPBValue(FI)F
    .registers 6
    .param p1, "max"    # F
    .param p2, "nSec"    # I

    .prologue
    .line 277
    const/high16 v1, 0x3f800000    # 1.0f

    add-float v0, p1, v1

    .line 278
    .local v0, "nPBMax":F
    int-to-float v1, p2

    mul-float/2addr v1, v0

    const/high16 v2, 0x42700000    # 60.0f

    div-float/2addr v1, v2

    return v1
.end method

.method private setData()V
    .registers 5

    .prologue
    .line 919
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    invoke-virtual {v1, v2, v3}, Ljava/util/Calendar;->setTimeInMillis(J)V

    .line 920
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    const/16 v2, 0xa

    invoke-virtual {v1, v2}, Ljava/util/Calendar;->get(I)I

    move-result v1

    iput v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    .line 921
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    const/16 v2, 0xc

    invoke-virtual {v1, v2}, Ljava/util/Calendar;->get(I)I

    move-result v1

    iput v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMinutes:I

    .line 922
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    const/16 v2, 0xd

    invoke-virtual {v1, v2}, Ljava/util/Calendar;->get(I)I

    move-result v1

    iput v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mSeconds:I

    .line 923
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    const/16 v2, 0x9

    invoke-virtual {v1, v2}, Ljava/util/Calendar;->get(I)I

    move-result v1

    iput v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    .line 925
    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    iput v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mOldHour:I

    .line 926
    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMinutes:I

    iput v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mOldMinutes:I

    .line 927
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    const/4 v2, 0x7

    invoke-virtual {v1, v2}, Ljava/util/Calendar;->get(I)I

    move-result v0

    .line 928
    .local v0, "dayOfWeek":I
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDaysOfWeek:[Ljava/lang/CharSequence;

    aget-object v1, v1, v0

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mWeek:Ljava/lang/String;

    .line 929
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMonth:[Ljava/lang/CharSequence;

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    invoke-static {v1, v2}, Lcom/htc/clock/util/MyTimeUtil;->getDateString([Ljava/lang/CharSequence;Ljava/util/Calendar;)Ljava/lang/String;

    move-result-object v1

    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDay:Ljava/lang/String;

    .line 930
    return-void
.end method

.method private setHourMinute(II)V
    .registers 5
    .param p1, "hour"    # I
    .param p2, "minute"    # I

    .prologue
    const/4 v1, 0x1

    .line 599
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour_ten:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_f

    .line 600
    div-int/lit8 v0, p1, 0xa

    if-ge v0, v1, :cond_34

    .line 601
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour_ten:Lcom/htc/fusion/fx/FxTimelineControl;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/FxTimelineControl;->setVisibility(Z)Ljava/util/ArrayList;

    .line 608
    :cond_f
    :goto_f
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour_unit:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_1b

    .line 609
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour_unit:Lcom/htc/fusion/fx/FxTimelineControl;

    rem-int/lit8 v1, p1, 0xa

    int-to-float v1, v1

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/FxTimelineControl;->setFrame(F)V

    .line 612
    :cond_1b
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Minute_ten:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_27

    .line 613
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Minute_ten:Lcom/htc/fusion/fx/FxTimelineControl;

    div-int/lit8 v1, p2, 0xa

    int-to-float v1, v1

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/FxTimelineControl;->setFrame(F)V

    .line 616
    :cond_27
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Minute_unit:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_33

    .line 617
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Minute_unit:Lcom/htc/fusion/fx/FxTimelineControl;

    rem-int/lit8 v1, p2, 0xa

    int-to-float v1, v1

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/FxTimelineControl;->setFrame(F)V

    .line 619
    :cond_33
    return-void

    .line 603
    :cond_34
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour_ten:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/FxTimelineControl;->setVisibility(Z)Ljava/util/ArrayList;

    .line 604
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour_ten:Lcom/htc/fusion/fx/FxTimelineControl;

    div-int/lit8 v1, p1, 0xa

    int-to-float v1, v1

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/FxTimelineControl;->setFrame(F)V

    goto :goto_f
.end method

.method private showAMInfo()V
    .registers 7

    .prologue
    const/16 v5, 0xa

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x1

    .line 462
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextAMPM:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_16

    .line 463
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextAMPM:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAm_Pm:[Ljava/lang/CharSequence;

    aget-object v1, v1, v3

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 466
    :cond_16
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextAMPM_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_27

    .line 467
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextAMPM_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAm_Pm:[Ljava/lang/CharSequence;

    aget-object v1, v1, v3

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 470
    :cond_27
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_42

    .line 471
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmType:I

    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    if-ne v0, v1, :cond_35

    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    if-nez v0, :cond_42

    .line 472
    :cond_35
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmType:I

    .line 473
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    if-eqz v0, :cond_79

    .line 474
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v5, v3}, Lcom/htc/fusion/fx/FxTimelineControl;->playFrames(II)V

    .line 482
    :cond_42
    :goto_42
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->m24HourFormat:Z

    if-eqz v0, :cond_81

    .line 484
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineAmPmOpp:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_5f

    .line 485
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmType:I

    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    if-ne v0, v1, :cond_54

    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    if-nez v0, :cond_5a

    .line 486
    :cond_54
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmType:I

    .line 487
    iput-boolean v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    .line 489
    :cond_5a
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineAmPmOpp:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v3}, Lcom/htc/fusion/fx/FxTimelineControl;->setVisibility(Z)Ljava/util/ArrayList;

    .line 492
    :cond_5f
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineClockAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_78

    .line 493
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmType:I

    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    if-ne v0, v1, :cond_6d

    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    if-nez v0, :cond_73

    .line 494
    :cond_6d
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmType:I

    .line 495
    iput-boolean v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    .line 497
    :cond_73
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineClockAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v3}, Lcom/htc/fusion/fx/FxTimelineControl;->setVisibility(Z)Ljava/util/ArrayList;

    .line 527
    :cond_78
    :goto_78
    return-void

    .line 476
    :cond_79
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v4}, Lcom/htc/fusion/fx/FxTimelineControl;->setFrame(F)V

    .line 477
    iput-boolean v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    goto :goto_42

    .line 501
    :cond_81
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineAmPmOpp:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_a1

    .line 502
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmType:I

    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    if-ne v0, v1, :cond_8f

    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    if-nez v0, :cond_9c

    .line 503
    :cond_8f
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmType:I

    .line 504
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    if-eqz v0, :cond_c2

    .line 505
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineAmPmOpp:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v3, v5}, Lcom/htc/fusion/fx/FxTimelineControl;->playFrames(II)V

    .line 511
    :cond_9c
    :goto_9c
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineAmPmOpp:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v2}, Lcom/htc/fusion/fx/FxTimelineControl;->setVisibility(Z)Ljava/util/ArrayList;

    .line 514
    :cond_a1
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineClockAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_78

    .line 515
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmType:I

    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    if-ne v0, v1, :cond_af

    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    if-nez v0, :cond_bc

    .line 516
    :cond_af
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmType:I

    .line 517
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    if-eqz v0, :cond_cc

    .line 518
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineClockAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v2, v3}, Lcom/htc/fusion/fx/FxTimelineControl;->playFrames(II)V

    .line 524
    :cond_bc
    :goto_bc
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineClockAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v2}, Lcom/htc/fusion/fx/FxTimelineControl;->setVisibility(Z)Ljava/util/ArrayList;

    goto :goto_78

    .line 507
    :cond_c2
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineAmPmOpp:Lcom/htc/fusion/fx/FxTimelineControl;

    const/high16 v1, 0x41200000    # 10.0f

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/FxTimelineControl;->setFrame(F)V

    .line 508
    iput-boolean v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    goto :goto_9c

    .line 520
    :cond_cc
    iput-boolean v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    .line 521
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineClockAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v4}, Lcom/htc/fusion/fx/FxTimelineControl;->setFrame(F)V

    goto :goto_bc
.end method

.method private showDateWeekText()V
    .registers 4

    .prologue
    .line 373
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextDate:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v1, :cond_b

    .line 374
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextDate:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDay:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 377
    :cond_b
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextDate_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v1, :cond_16

    .line 378
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextDate_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDay:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 381
    :cond_16
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextLongDate:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v1, :cond_2f

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDateFormat:Ljava/lang/String;

    if-eqz v1, :cond_2f

    .line 382
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDateFormat:Ljava/lang/String;

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    invoke-static {v1, v2}, Landroid/text/format/DateFormat;->format(Ljava/lang/CharSequence;Ljava/util/Calendar;)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    .line 383
    .local v0, "text":Ljava/lang/String;
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextLongDate:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v1, v0}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 387
    .end local v0    # "text":Ljava/lang/String;
    :cond_2f
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextWeekDay:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v1, :cond_3a

    .line 388
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextWeekDay:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mWeek:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 391
    :cond_3a
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextWeekDay_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v1, :cond_45

    .line 392
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextWeekDay_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mWeek:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 394
    :cond_45
    return-void
.end method

.method private showHourMinuteInfo(Z)V
    .registers 6
    .param p1, "useAnimation"    # Z

    .prologue
    const/16 v3, 0x9

    .line 340
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    .line 341
    .local v0, "hour":I
    iget-boolean v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->m24HourFormat:Z

    if-eqz v1, :cond_39

    .line 342
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    invoke-virtual {v1, v3}, Ljava/util/Calendar;->get(I)I

    move-result v1

    const/4 v2, 0x1

    if-ne v1, v2, :cond_13

    .line 343
    add-int/lit8 v0, v0, 0xc

    .line 345
    :cond_13
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v1, :cond_1d

    .line 346
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    const/4 v2, -0x1

    invoke-virtual {v1, v2}, Lcom/htc/clock3dwidget/util/DigitControl;->setAmPm(I)V

    .line 356
    :cond_1d
    :goto_1d
    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMinutes:I

    invoke-direct {p0, v0, v1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->setHourMinute(II)V

    .line 357
    if-eqz p1, :cond_4d

    .line 358
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v1, :cond_38

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v1, :cond_38

    .line 359
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    invoke-virtual {v1, v0}, Lcom/htc/clock3dwidget/util/DigitControl;->setDestNumber(I)V

    .line 360
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    iget v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMinutes:I

    invoke-virtual {v1, v2}, Lcom/htc/clock3dwidget/util/DigitControl;->setDestNumber(I)V

    .line 368
    :cond_38
    :goto_38
    return-void

    .line 349
    :cond_39
    if-nez v0, :cond_3d

    .line 350
    const/16 v0, 0xc

    .line 351
    :cond_3d
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v1, :cond_1d

    .line 352
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    invoke-virtual {v2, v3}, Ljava/util/Calendar;->get(I)I

    move-result v2

    invoke-virtual {v1, v2}, Lcom/htc/clock3dwidget/util/DigitControl;->setAmPm(I)V

    goto :goto_1d

    .line 363
    :cond_4d
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v1, :cond_38

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v1, :cond_38

    .line 364
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    invoke-virtual {v1, v0}, Lcom/htc/clock3dwidget/util/DigitControl;->setCurrentNumber(I)V

    .line 365
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    iget v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMinutes:I

    invoke-virtual {v1, v2}, Lcom/htc/clock3dwidget/util/DigitControl;->setCurrentNumber(I)V

    goto :goto_38
.end method

.method private showPMInfo()V
    .registers 6

    .prologue
    const/16 v4, 0xa

    const/4 v3, 0x0

    const/4 v2, 0x1

    .line 530
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextAMPM:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_15

    .line 531
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextAMPM:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAm_Pm:[Ljava/lang/CharSequence;

    aget-object v1, v1, v2

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 534
    :cond_15
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextAMPM_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_26

    .line 535
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextAMPM_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAm_Pm:[Ljava/lang/CharSequence;

    aget-object v1, v1, v2

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 538
    :cond_26
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_41

    .line 539
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmType:I

    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    if-ne v0, v1, :cond_34

    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    if-nez v0, :cond_41

    .line 540
    :cond_34
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmType:I

    .line 541
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    if-eqz v0, :cond_78

    .line 542
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v3, v4}, Lcom/htc/fusion/fx/FxTimelineControl;->playFrames(II)V

    .line 551
    :cond_41
    :goto_41
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->m24HourFormat:Z

    if-eqz v0, :cond_82

    .line 553
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineAmPmOpp:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_5e

    .line 554
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmType:I

    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    if-ne v0, v1, :cond_53

    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    if-nez v0, :cond_59

    .line 555
    :cond_53
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmType:I

    .line 556
    iput-boolean v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    .line 558
    :cond_59
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineAmPmOpp:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v3}, Lcom/htc/fusion/fx/FxTimelineControl;->setVisibility(Z)Ljava/util/ArrayList;

    .line 561
    :cond_5e
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineClockAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_77

    .line 562
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmType:I

    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    if-ne v0, v1, :cond_6c

    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    if-nez v0, :cond_72

    .line 563
    :cond_6c
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmType:I

    .line 564
    iput-boolean v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    .line 566
    :cond_72
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineClockAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v3}, Lcom/htc/fusion/fx/FxTimelineControl;->setVisibility(Z)Ljava/util/ArrayList;

    .line 596
    :cond_77
    :goto_77
    return-void

    .line 544
    :cond_78
    iput-boolean v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    .line 545
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    const/high16 v1, 0x41200000    # 10.0f

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/FxTimelineControl;->setFrame(F)V

    goto :goto_41

    .line 570
    :cond_82
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineAmPmOpp:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_a2

    .line 571
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmType:I

    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    if-ne v0, v1, :cond_90

    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    if-nez v0, :cond_9d

    .line 572
    :cond_90
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmType:I

    .line 573
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    if-eqz v0, :cond_c3

    .line 574
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineAmPmOpp:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v4, v3}, Lcom/htc/fusion/fx/FxTimelineControl;->playFrames(II)V

    .line 580
    :cond_9d
    :goto_9d
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineAmPmOpp:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v2}, Lcom/htc/fusion/fx/FxTimelineControl;->setVisibility(Z)Ljava/util/ArrayList;

    .line 583
    :cond_a2
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineClockAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_77

    .line 584
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmType:I

    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    if-ne v0, v1, :cond_b0

    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    if-nez v0, :cond_bd

    .line 585
    :cond_b0
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmType:I

    .line 586
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    if-eqz v0, :cond_cc

    .line 587
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineClockAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v3, v2}, Lcom/htc/fusion/fx/FxTimelineControl;->playFrames(II)V

    .line 593
    :cond_bd
    :goto_bd
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineClockAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v2}, Lcom/htc/fusion/fx/FxTimelineControl;->setVisibility(Z)Ljava/util/ArrayList;

    goto :goto_77

    .line 576
    :cond_c3
    iput-boolean v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    .line 577
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineAmPmOpp:Lcom/htc/fusion/fx/FxTimelineControl;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/FxTimelineControl;->setFrame(F)V

    goto :goto_9d

    .line 589
    :cond_cc
    iput-boolean v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    .line 590
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineClockAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/FxTimelineControl;->setFrame(F)V

    goto :goto_bd
.end method

.method private showRingText()V
    .registers 6

    .prologue
    .line 397
    iget-object v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextHour:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v4, :cond_22

    .line 398
    iget v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    if-nez v4, :cond_59

    iget v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    add-int/lit8 v4, v4, 0xc

    move v0, v4

    .line 399
    .local v0, "hour":I
    :goto_d
    invoke-static {v0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v1

    .line 400
    .local v1, "hourStr":Ljava/lang/String;
    iget-object v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextHour:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v4}, Lcom/htc/fusion/fx/controls/FxTextLabel;->getString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_22

    .line 401
    iget-object v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextHour:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v4, v1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 405
    .end local v0    # "hour":I
    .end local v1    # "hourStr":Ljava/lang/String;
    :cond_22
    iget-object v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextMinute:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v4, :cond_3d

    .line 406
    iget v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMinutes:I

    invoke-static {v4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    .line 407
    .local v2, "minuteStr":Ljava/lang/String;
    iget-object v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextMinute:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v4}, Lcom/htc/fusion/fx/controls/FxTextLabel;->getString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_3d

    .line 408
    iget-object v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextMinute:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v4, v2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 412
    .end local v2    # "minuteStr":Ljava/lang/String;
    :cond_3d
    iget-object v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextSecond:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v4, :cond_58

    .line 413
    iget v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mSeconds:I

    invoke-static {v4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v3

    .line 414
    .local v3, "secondStr":Ljava/lang/String;
    iget-object v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextSecond:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v4}, Lcom/htc/fusion/fx/controls/FxTextLabel;->getString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_58

    .line 415
    iget-object v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextSecond:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v4, v3}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 418
    .end local v3    # "secondStr":Ljava/lang/String;
    :cond_58
    return-void

    .line 398
    :cond_59
    iget v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    move v0, v4

    goto :goto_d
.end method

.method private showTimePB()V
    .registers 8

    .prologue
    const/4 v6, 0x0

    .line 422
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBHour:Lcom/htc/fusion/fx/controls/FxProgressBar;

    if-eqz v1, :cond_1a

    .line 423
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBHour:Lcom/htc/fusion/fx/controls/FxProgressBar;

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBHour:Lcom/htc/fusion/fx/controls/FxProgressBar;

    invoke-virtual {v2}, Lcom/htc/fusion/fx/controls/FxProgressBar;->getValueMax()F

    move-result v2

    iget v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    iget v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMinutes:I

    iget v5, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mSeconds:I

    invoke-direct {p0, v2, v3, v4, v5}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->calcHourPBValue(FIII)F

    move-result v2

    invoke-virtual {v1, v2}, Lcom/htc/fusion/fx/controls/FxProgressBar;->setValue(F)V

    .line 425
    :cond_1a
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBMin:Lcom/htc/fusion/fx/controls/FxProgressBar;

    if-eqz v1, :cond_31

    .line 426
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBMin:Lcom/htc/fusion/fx/controls/FxProgressBar;

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBMin:Lcom/htc/fusion/fx/controls/FxProgressBar;

    invoke-virtual {v2}, Lcom/htc/fusion/fx/controls/FxProgressBar;->getValueMax()F

    move-result v2

    iget v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMinutes:I

    iget v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mSeconds:I

    invoke-direct {p0, v2, v3, v4}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->calcMinPBValue(FII)F

    move-result v2

    invoke-virtual {v1, v2}, Lcom/htc/fusion/fx/controls/FxProgressBar;->setValue(F)V

    .line 428
    :cond_31
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBSec:Lcom/htc/fusion/fx/controls/FxProgressBar;

    if-eqz v1, :cond_46

    .line 429
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBSec:Lcom/htc/fusion/fx/controls/FxProgressBar;

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBSec:Lcom/htc/fusion/fx/controls/FxProgressBar;

    invoke-virtual {v2}, Lcom/htc/fusion/fx/controls/FxProgressBar;->getValueMax()F

    move-result v2

    iget v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mSeconds:I

    invoke-direct {p0, v2, v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->calcSecPBValue(FI)F

    move-result v2

    invoke-virtual {v1, v2}, Lcom/htc/fusion/fx/controls/FxProgressBar;->setValue(F)V

    .line 433
    :cond_46
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBUintHour:Lcom/htc/fusion/fx/controls/FxProgressBar;

    if-eqz v1, :cond_7c

    .line 434
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBUintHour:Lcom/htc/fusion/fx/controls/FxProgressBar;

    invoke-virtual {v1}, Lcom/htc/fusion/fx/controls/FxProgressBar;->getValueMax()F

    move-result v1

    iget v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    invoke-direct {p0, v1, v2, v6, v6}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->calcHourPBValue(FIII)F

    move-result v0

    .line 435
    .local v0, "current":F
    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUnitHourValue:F

    cmpl-float v1, v0, v1

    if-nez v1, :cond_60

    iget-boolean v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTimePBInit:Z

    if-nez v1, :cond_7c

    .line 436
    :cond_60
    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUnitHourValue:F

    sub-float/2addr v1, v0

    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    move-result v1

    const/high16 v2, 0x41f80000    # 31.0f

    cmpg-float v1, v1, v2

    if-gez v1, :cond_ba

    iget-boolean v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTimePBInit:Z

    if-eqz v1, :cond_ba

    .line 437
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBUintHour:Lcom/htc/fusion/fx/controls/FxProgressBar;

    iget v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUnitHourValue:F

    float-to-int v2, v2

    float-to-int v3, v0

    invoke-virtual {v1, v2, v3}, Lcom/htc/fusion/fx/controls/FxProgressBar;->playFrames(II)V

    .line 441
    :goto_7a
    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUnitHourValue:F

    .line 445
    .end local v0    # "current":F
    :cond_7c
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBUnitMin:Lcom/htc/fusion/fx/controls/FxProgressBar;

    if-eqz v1, :cond_b2

    .line 446
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBUnitMin:Lcom/htc/fusion/fx/controls/FxProgressBar;

    invoke-virtual {v1}, Lcom/htc/fusion/fx/controls/FxProgressBar;->getValueMax()F

    move-result v1

    iget v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMinutes:I

    invoke-direct {p0, v1, v2, v6}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->calcMinPBValue(FII)F

    move-result v0

    .line 447
    .restart local v0    # "current":F
    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUnitMinValue:F

    cmpl-float v1, v0, v1

    if-nez v1, :cond_96

    iget-boolean v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTimePBInit:Z

    if-nez v1, :cond_b2

    .line 448
    :cond_96
    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUnitMinValue:F

    sub-float/2addr v1, v0

    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    move-result v1

    const/high16 v2, 0x40400000    # 3.0f

    cmpg-float v1, v1, v2

    if-gez v1, :cond_c0

    iget-boolean v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTimePBInit:Z

    if-eqz v1, :cond_c0

    .line 449
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBUnitMin:Lcom/htc/fusion/fx/controls/FxProgressBar;

    iget v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUnitMinValue:F

    float-to-int v2, v2

    float-to-int v3, v0

    invoke-virtual {v1, v2, v3}, Lcom/htc/fusion/fx/controls/FxProgressBar;->playFrames(II)V

    .line 453
    :goto_b0
    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUnitMinValue:F

    .line 456
    .end local v0    # "current":F
    :cond_b2
    iget-boolean v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTimePBInit:Z

    if-nez v1, :cond_b9

    .line 457
    const/4 v1, 0x1

    iput-boolean v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTimePBInit:Z

    .line 459
    :cond_b9
    return-void

    .line 439
    .restart local v0    # "current":F
    :cond_ba
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBUintHour:Lcom/htc/fusion/fx/controls/FxProgressBar;

    invoke-virtual {v1, v0}, Lcom/htc/fusion/fx/controls/FxProgressBar;->setFrame(F)V

    goto :goto_7a

    .line 451
    :cond_c0
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBUnitMin:Lcom/htc/fusion/fx/controls/FxProgressBar;

    invoke-virtual {v1, v0}, Lcom/htc/fusion/fx/controls/FxProgressBar;->setFrame(F)V

    goto :goto_b0
.end method

.method private startTickers()V
    .registers 11

    .prologue
    .line 887
    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTicker:Ljava/lang/Runnable;

    if-eqz v2, :cond_27

    iget-boolean v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTickerStopped:Z

    if-eqz v2, :cond_27

    .line 888
    const/4 v2, 0x0

    iput-boolean v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTickerStopped:Z

    .line 889
    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    if-eqz v2, :cond_28

    .line 890
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    .line 891
    .local v0, "now":J
    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTicker:Ljava/lang/Runnable;

    iget v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUpdateIntervals:I

    int-to-long v4, v4

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    iget v8, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUpdateIntervals:I

    int-to-long v8, v8

    rem-long/2addr v6, v8

    sub-long/2addr v4, v6

    add-long/2addr v4, v0

    invoke-interface {v2, v3, v4, v5}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->postAtTime(Ljava/lang/Runnable;J)V

    .line 897
    .end local v0    # "now":J
    :cond_27
    :goto_27
    return-void

    .line 892
    :cond_28
    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mhUiHandler:Landroid/os/Handler;

    if-eqz v2, :cond_27

    .line 893
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    .line 894
    .restart local v0    # "now":J
    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mhUiHandler:Landroid/os/Handler;

    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTicker:Ljava/lang/Runnable;

    iget v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUpdateIntervals:I

    int-to-long v4, v4

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    iget v8, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUpdateIntervals:I

    int-to-long v8, v8

    rem-long/2addr v6, v8

    sub-long/2addr v4, v6

    add-long/2addr v4, v0

    invoke-virtual {v2, v3, v4, v5}, Landroid/os/Handler;->postAtTime(Ljava/lang/Runnable;J)Z

    goto :goto_27
.end method

.method private stopGears()V
    .registers 2

    .prologue
    .line 721
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear01:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_9

    .line 723
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear01:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0}, Lcom/htc/fusion/fx/FxTimelineControl;->stop()V

    .line 726
    :cond_9
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear02:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_12

    .line 728
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear02:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0}, Lcom/htc/fusion/fx/FxTimelineControl;->stop()V

    .line 731
    :cond_12
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear03:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_1b

    .line 733
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear03:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0}, Lcom/htc/fusion/fx/FxTimelineControl;->stop()V

    .line 736
    :cond_1b
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear04:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_24

    .line 738
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear04:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0}, Lcom/htc/fusion/fx/FxTimelineControl;->stop()V

    .line 741
    :cond_24
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear05:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_2d

    .line 743
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear05:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0}, Lcom/htc/fusion/fx/FxTimelineControl;->stop()V

    .line 745
    :cond_2d
    return-void
.end method

.method private stopTickers()V
    .registers 3

    .prologue
    .line 900
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTicker:Ljava/lang/Runnable;

    if-eqz v0, :cond_12

    .line 901
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTickerStopped:Z

    .line 902
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    if-eqz v0, :cond_13

    .line 903
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTicker:Ljava/lang/Runnable;

    invoke-interface {v0, v1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->cancel(Ljava/lang/Runnable;)V

    .line 908
    :cond_12
    :goto_12
    return-void

    .line 904
    :cond_13
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mhUiHandler:Landroid/os/Handler;

    if-eqz v0, :cond_12

    .line 905
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mhUiHandler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTicker:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    goto :goto_12
.end method

.method private updateTime()V
    .registers 2

    .prologue
    .line 776
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mPaused:Z

    if-eqz v0, :cond_a

    .line 777
    const-string v0, "onTimeChanged~ mPaused is true"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->w(Ljava/lang/String;)V

    .line 787
    :goto_9
    return-void

    .line 781
    :cond_a
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    if-nez v0, :cond_14

    .line 782
    const-string v0, "onTimeChanged mCalendar null"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->w(Ljava/lang/String;)V

    goto :goto_9

    .line 785
    :cond_14
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->setData()V

    .line 786
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->invalidate(Z)V

    goto :goto_9
.end method


# virtual methods
.method public bind(Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;)V
    .registers 5
    .param p1, "controlsPort"    # Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;
    .param p2, "controlsLand"    # Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;

    .prologue
    .line 245
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxHitbox:Lcom/htc/fusion/fx/controls/FxHitbox;

    invoke-virtual {v0}, Lcom/htc/fusion/fx/controls/FxHitbox;->getTapSource()Lcom/htc/fusion/fx/IMessageSource;

    move-result-object v0

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mClockClickPort:Lcom/htc/clock3dwidget/analogclock/AnalogClockView$ClickListener;

    invoke-interface {v0, v1}, Lcom/htc/fusion/fx/IMessageSource;->bind(Lcom/htc/fusion/fx/IMessageListener;)V

    .line 246
    invoke-virtual {p1}, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->bind()V

    .line 247
    invoke-virtual {p1, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_22

    .line 248
    iget-object v0, p2, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxHitbox:Lcom/htc/fusion/fx/controls/FxHitbox;

    invoke-virtual {v0}, Lcom/htc/fusion/fx/controls/FxHitbox;->getTapSource()Lcom/htc/fusion/fx/IMessageSource;

    move-result-object v0

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mClockClickLand:Lcom/htc/clock3dwidget/analogclock/AnalogClockView$ClickListener;

    invoke-interface {v0, v1}, Lcom/htc/fusion/fx/IMessageSource;->bind(Lcom/htc/fusion/fx/IMessageListener;)V

    .line 249
    invoke-virtual {p2}, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->bind()V

    .line 251
    :cond_22
    return-void
.end method

.method public clear()V
    .registers 2

    .prologue
    .line 661
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mPaused:Z

    .line 662
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->stopGears()V

    .line 663
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->stopWiggle()V

    .line 664
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->stopTickers()V

    .line 665
    return-void
.end method

.method public doTiltChanged(F)V
    .registers 5
    .param p1, "tilt"    # F

    .prologue
    .line 933
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTiltAnime:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v1, :cond_19

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTileMark:Lcom/htc/fusion/fx/Marker;

    if-eqz v1, :cond_19

    .line 934
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTileMark:Lcom/htc/fusion/fx/Marker;

    iget v1, v1, Lcom/htc/fusion/fx/Marker;->StartFrame:I

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTileMark:Lcom/htc/fusion/fx/Marker;

    iget v2, v2, Lcom/htc/fusion/fx/Marker;->EndFrame:I

    invoke-static {p1, v1, v2}, Lcom/htc/android/rosie/widget/WidgetHelper;->convertTiltAngleToFrame(FII)F

    move-result v0

    .line 935
    .local v0, "frame":F
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTiltAnime:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v1, v0}, Lcom/htc/fusion/fx/FxTimelineControl;->setFrame(F)V

    .line 937
    .end local v0    # "frame":F
    :cond_19
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHourCap:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v1, :cond_32

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMarkerHour:Lcom/htc/fusion/fx/Marker;

    if-eqz v1, :cond_32

    .line 938
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMarkerHour:Lcom/htc/fusion/fx/Marker;

    iget v1, v1, Lcom/htc/fusion/fx/Marker;->StartFrame:I

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMarkerHour:Lcom/htc/fusion/fx/Marker;

    iget v2, v2, Lcom/htc/fusion/fx/Marker;->EndFrame:I

    invoke-static {p1, v1, v2}, Lcom/htc/android/rosie/widget/WidgetHelper;->convertTiltAngleToFrame(FII)F

    move-result v0

    .line 939
    .restart local v0    # "frame":F
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHourCap:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v1, v0}, Lcom/htc/fusion/fx/FxTimelineControl;->setFrame(F)V

    .line 941
    .end local v0    # "frame":F
    :cond_32
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMinCap:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v1, :cond_4b

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMarkerMin:Lcom/htc/fusion/fx/Marker;

    if-eqz v1, :cond_4b

    .line 942
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMarkerMin:Lcom/htc/fusion/fx/Marker;

    iget v1, v1, Lcom/htc/fusion/fx/Marker;->StartFrame:I

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMarkerMin:Lcom/htc/fusion/fx/Marker;

    iget v2, v2, Lcom/htc/fusion/fx/Marker;->EndFrame:I

    invoke-static {p1, v1, v2}, Lcom/htc/android/rosie/widget/WidgetHelper;->convertTiltAngleToFrame(FII)F

    move-result v0

    .line 943
    .restart local v0    # "frame":F
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMinCap:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v1, v0}, Lcom/htc/fusion/fx/FxTimelineControl;->setFrame(F)V

    .line 946
    .end local v0    # "frame":F
    :cond_4b
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v1, :cond_54

    .line 947
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    invoke-virtual {v1, p1}, Lcom/htc/clock3dwidget/util/DigitControl;->doTiltChanged(F)V

    .line 949
    :cond_54
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v1, :cond_5d

    .line 950
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    invoke-virtual {v1, p1}, Lcom/htc/clock3dwidget/util/DigitControl;->doTiltChanged(F)V

    .line 952
    :cond_5d
    return-void
.end method

.method protected getContext()Landroid/content/Context;
    .registers 2

    .prologue
    .line 315
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mContext:Landroid/content/Context;

    return-object v0
.end method

.method public getTimeZoneId()Ljava/lang/String;
    .registers 3

    .prologue
    .line 643
    const-string v0, ""

    .line 644
    .local v0, "timezoneId":Ljava/lang/String;
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    if-eqz v1, :cond_10

    .line 645
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    invoke-virtual {v1}, Ljava/util/Calendar;->getTimeZone()Ljava/util/TimeZone;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/TimeZone;->getID()Ljava/lang/String;

    move-result-object v0

    .line 647
    :cond_10
    return-object v0
.end method

.method public init(Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;)V
    .registers 4
    .param p1, "controls"    # Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;

    .prologue
    const/4 v1, 0x0

    .line 158
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxHitbox:Lcom/htc/fusion/fx/controls/FxHitbox;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxHitbox:Lcom/htc/fusion/fx/controls/FxHitbox;

    .line 161
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxPBHour:Lcom/htc/fusion/fx/controls/FxProgressBar;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBHour:Lcom/htc/fusion/fx/controls/FxProgressBar;

    .line 162
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxPBMin:Lcom/htc/fusion/fx/controls/FxProgressBar;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBMin:Lcom/htc/fusion/fx/controls/FxProgressBar;

    .line 163
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxPBSec:Lcom/htc/fusion/fx/controls/FxProgressBar;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBSec:Lcom/htc/fusion/fx/controls/FxProgressBar;

    .line 166
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxPBUintHour:Lcom/htc/fusion/fx/controls/FxProgressBar;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBUintHour:Lcom/htc/fusion/fx/controls/FxProgressBar;

    .line 167
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxPBUnitMin:Lcom/htc/fusion/fx/controls/FxProgressBar;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBUnitMin:Lcom/htc/fusion/fx/controls/FxProgressBar;

    .line 169
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mCityName:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCityName:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 172
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Hour_ten:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour_ten:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 173
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Hour_unit:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour_unit:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 174
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Minute_ten:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Minute_ten:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 175
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Minute_unit:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Minute_unit:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 177
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimeLineGear01:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear01:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 178
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimeLineGear02:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear02:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 179
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimeLineGear03:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear03:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 180
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimeLineGear04:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear04:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 181
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimeLineGear05:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear05:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 182
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimelineWiggle:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineWiggle:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 184
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextHour:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextHour:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 185
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextMinute:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextMinute:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 186
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextSecond:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextSecond:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 189
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxClockBase:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockBase:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 190
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxClockNumbers:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockNumbers:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 191
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxClockDate:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockDate:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 192
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxClockHour:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockHour:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 193
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxClockMinute:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockMinute:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 197
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimelineClock:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineClock:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 199
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimelineAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 200
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimelineAmPmOpp:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineAmPmOpp:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 201
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimelineClockAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimelineClockAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 204
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextDate:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextDate:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 205
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextLongDate:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextLongDate:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 206
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextWeekDay:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextWeekDay:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 207
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextAMPM:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextAMPM:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 210
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextDate_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextDate_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 211
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextWeekDay_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextWeekDay_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 212
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextAMPM_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTextAMPM_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 214
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxPBSec:Lcom/htc/fusion/fx/controls/FxProgressBar;

    if-eqz v0, :cond_d1

    .line 215
    const/16 v0, 0x3e8

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUpdateIntervals:I

    .line 220
    :goto_99
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    .line 221
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    .line 223
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_d7

    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_d7

    invoke-static {}, Lcom/htc/clock3dwidget/util/MyProjectSetting;->isFlipEnable()Z

    move-result v0

    if-eqz v0, :cond_d7

    .line 225
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUseAnimation:Z

    .line 231
    :goto_b2
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mTiltAnime:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTiltAnime:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 232
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mTileMark:Lcom/htc/fusion/fx/Marker;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTileMark:Lcom/htc/fusion/fx/Marker;

    .line 233
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mHourCap:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHourCap:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 234
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mMarkerHour:Lcom/htc/fusion/fx/Marker;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMarkerHour:Lcom/htc/fusion/fx/Marker;

    .line 235
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mMinCap:Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMinCap:Lcom/htc/fusion/fx/FxTimelineControl;

    .line 236
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mMarkerMin:Lcom/htc/fusion/fx/Marker;

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMarkerMin:Lcom/htc/fusion/fx/Marker;

    .line 239
    iput-boolean v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDayPanelInit:Z

    .line 240
    iput-boolean v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    .line 241
    iput-boolean v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTimePBInit:Z

    .line 242
    return-void

    .line 217
    :cond_d1
    const v0, 0xea60

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUpdateIntervals:I

    goto :goto_99

    .line 227
    :cond_d7
    iput-boolean v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUseAnimation:Z

    goto :goto_b2
.end method

.method public invalidate(Z)V
    .registers 5
    .param p1, "useAnimation"    # Z

    .prologue
    const/4 v2, 0x6

    const/4 v1, 0x1

    .line 319
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    if-nez v0, :cond_a

    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    if-lt v0, v2, :cond_12

    :cond_a
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    if-ne v0, v1, :cond_2a

    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    if-lt v0, v2, :cond_2a

    .line 321
    :cond_12
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->switchDayNightPanel(Z)V

    .line 325
    :goto_16
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->showRingText()V

    .line 326
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->showTimePB()V

    .line 327
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->showDateWeekText()V

    .line 330
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAMPM:I

    if-nez v0, :cond_2e

    .line 331
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->showAMInfo()V

    .line 336
    :goto_26
    invoke-direct {p0, p1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->showHourMinuteInfo(Z)V

    .line 337
    return-void

    .line 323
    :cond_2a
    invoke-virtual {p0, v1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->switchDayNightPanel(Z)V

    goto :goto_16

    .line 333
    :cond_2e
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->showPMInfo()V

    goto :goto_26
.end method

.method public isPaused()Z
    .registers 2

    .prologue
    .line 684
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mPaused:Z

    return v0
.end method

.method public onTimeChanged()V
    .registers 3

    .prologue
    const/4 v1, 0x1

    .line 790
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mPaused:Z

    if-eqz v0, :cond_b

    .line 791
    const-string v0, "onTimeChanged~ mPaused is true"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->w(Ljava/lang/String;)V

    .line 804
    :goto_a
    return-void

    .line 795
    :cond_b
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    if-nez v0, :cond_15

    .line 796
    const-string v0, "onTimeChanged mCalendar null"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->w(Ljava/lang/String;)V

    goto :goto_a

    .line 800
    :cond_15
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->setData()V

    .line 802
    iput v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMinuteFlipCount:I

    .line 803
    invoke-virtual {p0, v1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->invalidate(Z)V

    goto :goto_a
.end method

.method public playGears()V
    .registers 7

    .prologue
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/high16 v2, 0x3f800000    # 1.0f

    const-string v5, "walk"

    .line 688
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear01:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_11

    .line 690
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear01:Lcom/htc/fusion/fx/FxTimelineControl;

    const-string v1, "walk"

    invoke-virtual {v0, v5, v4, v2, v3}, Lcom/htc/fusion/fx/FxTimelineControl;->playMarker(Ljava/lang/String;IFZ)V

    .line 693
    :cond_11
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear02:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_1c

    .line 695
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear02:Lcom/htc/fusion/fx/FxTimelineControl;

    const-string v1, "walk"

    invoke-virtual {v0, v5, v4, v2, v3}, Lcom/htc/fusion/fx/FxTimelineControl;->playMarker(Ljava/lang/String;IFZ)V

    .line 698
    :cond_1c
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear03:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_27

    .line 700
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear03:Lcom/htc/fusion/fx/FxTimelineControl;

    const-string v1, "walk"

    invoke-virtual {v0, v5, v4, v2, v3}, Lcom/htc/fusion/fx/FxTimelineControl;->playMarker(Ljava/lang/String;IFZ)V

    .line 703
    :cond_27
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear04:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_32

    .line 705
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear04:Lcom/htc/fusion/fx/FxTimelineControl;

    const-string v1, "walk"

    invoke-virtual {v0, v5, v4, v2, v3}, Lcom/htc/fusion/fx/FxTimelineControl;->playMarker(Ljava/lang/String;IFZ)V

    .line 708
    :cond_32
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear05:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_3d

    .line 710
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineGear05:Lcom/htc/fusion/fx/FxTimelineControl;

    const-string v1, "walk"

    invoke-virtual {v0, v5, v4, v2, v3}, Lcom/htc/fusion/fx/FxTimelineControl;->playMarker(Ljava/lang/String;IFZ)V

    .line 712
    :cond_3d
    return-void
.end method

.method public playWiggle()V
    .registers 5

    .prologue
    const/4 v3, 0x0

    .line 715
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineWiggle:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_e

    .line 716
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineWiggle:Lcom/htc/fusion/fx/FxTimelineControl;

    const-string v1, "start_wiggle"

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-virtual {v0, v1, v3, v2, v3}, Lcom/htc/fusion/fx/FxTimelineControl;->playMarker(Ljava/lang/String;IFZ)V

    .line 718
    :cond_e
    return-void
.end method

.method public prepareAnimation()V
    .registers 7

    .prologue
    const/16 v5, 0x9

    const/16 v4, 0xc

    const/4 v3, 0x1

    .line 808
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUseAnimation:Z

    if-nez v0, :cond_a

    .line 843
    :goto_9
    return-void

    .line 810
    :cond_a
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Ljava/util/Calendar;->setTimeInMillis(J)V

    .line 811
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    invoke-virtual {v0, v4}, Ljava/util/Calendar;->get(I)I

    move-result v0

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMinutes:I

    .line 812
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    const/16 v1, 0xa

    invoke-virtual {v0, v1}, Ljava/util/Calendar;->get(I)I

    move-result v0

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    .line 814
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->m24HourFormat:Z

    if-eqz v0, :cond_92

    .line 815
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    invoke-virtual {v0, v5}, Ljava/util/Calendar;->get(I)I

    move-result v0

    if-ne v0, v3, :cond_37

    .line 816
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    add-int/lit8 v0, v0, 0xc

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    .line 817
    :cond_37
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_41

    .line 818
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setAmPm(I)V

    .line 820
    :cond_41
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    add-int/lit8 v0, v0, 0x18

    sub-int/2addr v0, v3

    rem-int/lit8 v0, v0, 0x18

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mOldHour:I

    .line 834
    :cond_4a
    :goto_4a
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMinutes:I

    add-int/lit8 v0, v0, 0x3c

    const/4 v1, 0x2

    sub-int/2addr v0, v1

    rem-int/lit8 v0, v0, 0x3c

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mOldMinutes:I

    .line 836
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_6a

    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_6a

    .line 837
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mOldHour:I

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setCurrentNumber(I)V

    .line 838
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mOldMinutes:I

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setCurrentNumber(I)V

    .line 840
    :cond_6a
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "prepareAnimation~ mOldHour:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mOldHour:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " mOldMinutes:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mOldMinutes:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 842
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFlipAnimePrepared:Z

    goto/16 :goto_9

    .line 822
    :cond_92
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    if-nez v0, :cond_98

    .line 823
    iput v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    .line 825
    :cond_98
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_a7

    .line 826
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    invoke-virtual {v1, v5}, Ljava/util/Calendar;->get(I)I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setAmPm(I)V

    .line 828
    :cond_a7
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    add-int/lit8 v0, v0, 0xc

    sub-int/2addr v0, v3

    rem-int/lit8 v0, v0, 0xc

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mOldHour:I

    .line 829
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mOldHour:I

    if-nez v0, :cond_4a

    .line 830
    iput v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mOldHour:I

    goto :goto_4a
.end method

.method public setAnimationFeedback(ZLcom/htc/android/rosie/widget/Widget$Host$Worker;Landroid/os/Handler;)V
    .registers 4
    .param p1, "ani"    # Z
    .param p2, "uiHandler"    # Lcom/htc/android/rosie/widget/Widget$Host$Worker;
    .param p3, "uihHandler"    # Landroid/os/Handler;

    .prologue
    .line 755
    iput-boolean p1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->isAnimation:Z

    .line 756
    iput-object p2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    .line 757
    iput-object p3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mhUiHandler:Landroid/os/Handler;

    .line 758
    return-void
.end method

.method public setDateFormat(ZLjava/lang/String;)V
    .registers 4
    .param p1, "is24HourFormat"    # Z
    .param p2, "dateFormat"    # Ljava/lang/String;

    .prologue
    .line 633
    iput-boolean p1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->m24HourFormat:Z

    .line 634
    iput-object p2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDateFormat:Ljava/lang/String;

    .line 635
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mAmPmInit:Z

    .line 636
    return-void
.end method

.method public setOnClickListener(Landroid/view/View$OnClickListener;)V
    .registers 2
    .param p1, "l"    # Landroid/view/View$OnClickListener;

    .prologue
    .line 639
    iput-object p1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mClickListener:Landroid/view/View$OnClickListener;

    .line 640
    return-void
.end method

.method public setPause(Z)V
    .registers 3
    .param p1, "value"    # Z

    .prologue
    .line 668
    monitor-enter p0

    .line 669
    :try_start_1
    iput-boolean p1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mPaused:Z

    .line 670
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mPaused:Z

    if-eqz v0, :cond_15

    .line 671
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mTickerStopped:Z

    .line 672
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->stopTickers()V

    .line 673
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->stopGears()V

    .line 674
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->stopWiggle()V

    .line 680
    :goto_13
    monitor-exit p0

    .line 681
    return-void

    .line 676
    :cond_15
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->startTickers()V

    .line 677
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->playGears()V

    .line 678
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->onTimeChanged()V

    goto :goto_13

    .line 680
    :catchall_1f
    move-exception v0

    monitor-exit p0
    :try_end_21
    .catchall {:try_start_1 .. :try_end_21} :catchall_1f

    throw v0
.end method

.method public setTimeZone(Ljava/lang/String;)V
    .registers 4
    .param p1, "timezone"    # Ljava/lang/String;

    .prologue
    .line 652
    if-eqz p1, :cond_8

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    if-gtz v1, :cond_13

    .line 653
    :cond_8
    invoke-static {}, Ljava/util/TimeZone;->getDefault()Ljava/util/TimeZone;

    move-result-object v0

    .line 657
    .local v0, "tz":Ljava/util/TimeZone;
    :goto_c
    invoke-static {v0}, Ljava/util/Calendar;->getInstance(Ljava/util/TimeZone;)Ljava/util/Calendar;

    move-result-object v1

    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    .line 658
    return-void

    .line 655
    .end local v0    # "tz":Ljava/util/TimeZone;
    :cond_13
    invoke-static {p1}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v0

    .restart local v0    # "tz":Ljava/util/TimeZone;
    goto :goto_c
.end method

.method public startAnimation()V
    .registers 2

    .prologue
    .line 846
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->startAnimation(Z)V

    .line 847
    return-void
.end method

.method public startAnimation(Z)V
    .registers 7
    .param p1, "bPause"    # Z

    .prologue
    const/16 v4, 0xc

    const/16 v3, 0x9

    .line 850
    iput-boolean p1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mPaused:Z

    .line 851
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mUseAnimation:Z

    if-nez v0, :cond_b

    .line 883
    :goto_a
    return-void

    .line 853
    :cond_b
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFlipAnimePrepared:Z

    if-nez v0, :cond_13

    .line 854
    invoke-virtual {p0, p1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->setPause(Z)V

    goto :goto_a

    .line 857
    :cond_13
    const-string v0, "startAnimation~"

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 859
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Ljava/util/Calendar;->setTimeInMillis(J)V

    .line 861
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    invoke-virtual {v0, v4}, Ljava/util/Calendar;->get(I)I

    move-result v0

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMinutes:I

    .line 862
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    const/16 v1, 0xa

    invoke-virtual {v0, v1}, Ljava/util/Calendar;->get(I)I

    move-result v0

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    .line 864
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->m24HourFormat:Z

    if-eqz v0, :cond_60

    .line 865
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    invoke-virtual {v0, v3}, Ljava/util/Calendar;->get(I)I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_46

    .line 866
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    add-int/lit8 v0, v0, 0xc

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    .line 867
    :cond_46
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_50

    .line 868
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setAmPm(I)V

    .line 877
    :cond_50
    :goto_50
    const/4 v0, 0x2

    iput v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mMinuteFlipCount:I

    .line 878
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->applyRotation()V

    .line 879
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFlipAnimePrepared:Z

    .line 881
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->startTickers()V

    .line 882
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->playGears()V

    goto :goto_a

    .line 871
    :cond_60
    iget v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    if-nez v0, :cond_66

    .line 872
    iput v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mHour:I

    .line 873
    :cond_66
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_50

    .line 874
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCalendar:Ljava/util/Calendar;

    invoke-virtual {v1, v3}, Ljava/util/Calendar;->get(I)I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setAmPm(I)V

    goto :goto_50
.end method

.method public stopWiggle()V
    .registers 2

    .prologue
    .line 748
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineWiggle:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_9

    .line 749
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxTimeLineWiggle:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0}, Lcom/htc/fusion/fx/FxTimelineControl;->stop()V

    .line 751
    :cond_9
    return-void
.end method

.method protected switchDayNightPanel(Z)V
    .registers 6
    .param p1, "bDayPanel"    # Z

    .prologue
    const/4 v3, 0x1

    const/16 v2, 0x1e

    const/4 v1, 0x0

    .line 282
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDayPanel:Z

    if-ne v0, p1, :cond_c

    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDayPanelInit:Z

    if-nez v0, :cond_10

    :cond_c
    move v0, v3

    :goto_d
    if-nez v0, :cond_12

    .line 312
    :cond_f
    :goto_f
    return-void

    :cond_10
    move v0, v1

    .line 282
    goto :goto_d

    .line 286
    :cond_12
    iput-boolean p1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDayPanel:Z

    .line 287
    iput-boolean v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDayPanelInit:Z

    .line 289
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mDayPanel:Z

    if-eqz v0, :cond_48

    .line 290
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockBase:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_23

    .line 291
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockBase:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v2, v1}, Lcom/htc/fusion/fx/FxTimelineControl;->playFrames(II)V

    .line 292
    :cond_23
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockNumbers:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_2c

    .line 293
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockNumbers:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v2, v1}, Lcom/htc/fusion/fx/FxTimelineControl;->playFrames(II)V

    .line 294
    :cond_2c
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockDate:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_35

    .line 295
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockDate:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v2, v1}, Lcom/htc/fusion/fx/FxTimelineControl;->playFrames(II)V

    .line 296
    :cond_35
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockHour:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_3e

    .line 297
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockHour:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v2, v1}, Lcom/htc/fusion/fx/FxTimelineControl;->playFrames(II)V

    .line 298
    :cond_3e
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockMinute:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_f

    .line 299
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockMinute:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v2, v1}, Lcom/htc/fusion/fx/FxTimelineControl;->playFrames(II)V

    goto :goto_f

    .line 301
    :cond_48
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockBase:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_51

    .line 302
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockBase:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v1, v2}, Lcom/htc/fusion/fx/FxTimelineControl;->playFrames(II)V

    .line 303
    :cond_51
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockNumbers:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_5a

    .line 304
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockNumbers:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v1, v2}, Lcom/htc/fusion/fx/FxTimelineControl;->playFrames(II)V

    .line 305
    :cond_5a
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockDate:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_63

    .line 306
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockDate:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v1, v2}, Lcom/htc/fusion/fx/FxTimelineControl;->playFrames(II)V

    .line 307
    :cond_63
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockHour:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_6c

    .line 308
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockHour:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v1, v2}, Lcom/htc/fusion/fx/FxTimelineControl;->playFrames(II)V

    .line 309
    :cond_6c
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockMinute:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_f

    .line 310
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mFxClockMinute:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v1, v2}, Lcom/htc/fusion/fx/FxTimelineControl;->playFrames(II)V

    goto :goto_f
.end method

.method public unbind(Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;)V
    .registers 5
    .param p1, "controlsPort"    # Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;
    .param p2, "controlsLand"    # Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;

    .prologue
    .line 254
    iget-object v0, p1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxHitbox:Lcom/htc/fusion/fx/controls/FxHitbox;

    invoke-virtual {v0}, Lcom/htc/fusion/fx/controls/FxHitbox;->getTapSource()Lcom/htc/fusion/fx/IMessageSource;

    move-result-object v0

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mClockClickPort:Lcom/htc/clock3dwidget/analogclock/AnalogClockView$ClickListener;

    invoke-interface {v0, v1}, Lcom/htc/fusion/fx/IMessageSource;->unbind(Lcom/htc/fusion/fx/IMessageListener;)V

    .line 255
    invoke-virtual {p1}, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->unbind()V

    .line 256
    invoke-virtual {p1, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_22

    .line 257
    iget-object v0, p2, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxHitbox:Lcom/htc/fusion/fx/controls/FxHitbox;

    invoke-virtual {v0}, Lcom/htc/fusion/fx/controls/FxHitbox;->getTapSource()Lcom/htc/fusion/fx/IMessageSource;

    move-result-object v0

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mClockClickLand:Lcom/htc/clock3dwidget/analogclock/AnalogClockView$ClickListener;

    invoke-interface {v0, v1}, Lcom/htc/fusion/fx/IMessageSource;->unbind(Lcom/htc/fusion/fx/IMessageListener;)V

    .line 258
    invoke-virtual {p2}, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->unbind()V

    .line 260
    :cond_22
    return-void
.end method
