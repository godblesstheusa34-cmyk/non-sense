.class public Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;
.super Ljava/lang/Object;
.source "AnalogClockWidget.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$MyTimeListener;,
        Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$InstanceCallback;,
        Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;
    }
.end annotation


# static fields
.field public static final WHAT_ON_INIT:I = 0x2329


# instance fields
.field private mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

.field private mApplication:Landroid/content/Context;

.field private mBShowCityLabel:Z

.field private mBoolAppDestroy:Z

.field private mCityCode:Ljava/lang/String;

.field private mCityName:Ljava/lang/String;

.field private mClockClick:Landroid/view/View$OnClickListener;

.field private mFxControlsLand:Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;

.field private mFxControlsPort:Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;

.field private mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

.field private mInstanceCallback:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$InstanceCallback;

.field protected mIsHomeClock:Z

.field private mOrientation:I

.field mPauseByAddToHome:Z

.field private mResContext:Landroid/content/Context;

.field private mSceneLand:Lcom/htc/fusion/fx/FxScene;

.field private mScenePort:Lcom/htc/fusion/fx/FxScene;

.field private mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;

.field private mTimeCtrlLock:Ljava/lang/Object;

.field private mTimeListener:Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;

.field protected mTimeZoneChanged:Z

.field protected mTimeZoneStr:Ljava/lang/String;

.field private mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

.field private mUiState:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;

.field private mUiWorker:Landroid/os/Handler$Callback;

.field protected mUseCurrentLocation:Z

.field private mWorker:Landroid/os/Handler$Callback;

.field private mhHandler:Landroid/os/Handler;

.field private mhUiHandler:Landroid/os/Handler;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/content/Context;Lcom/htc/android/rosie/widget/Widget$Host;Lcom/htc/fusion/fx/FxScene;Lcom/htc/fusion/fx/FxScene;ILcom/htc/clock3dwidget/analogclock/AnalogClockWidget$InstanceCallback;Lcom/htc/clock3dwidget/ClockRes;)V
    .registers 14
    .param p1, "resContext"    # Landroid/content/Context;
    .param p2, "appContext"    # Landroid/content/Context;
    .param p3, "host"    # Lcom/htc/android/rosie/widget/Widget$Host;
    .param p4, "scenePort"    # Lcom/htc/fusion/fx/FxScene;
    .param p5, "sceneLand"    # Lcom/htc/fusion/fx/FxScene;
    .param p6, "orientation"    # I
    .param p7, "callback"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$InstanceCallback;
    .param p8, "res"    # Lcom/htc/clock3dwidget/ClockRes;

    .prologue
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x0

    .line 70
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 43
    iput v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mOrientation:I

    .line 47
    iput-boolean v4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mBShowCityLabel:Z

    .line 49
    new-instance v1, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$MyTimeListener;

    invoke-direct {v1, p0, v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$MyTimeListener;-><init>(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$1;)V

    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeListener:Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;

    .line 50
    iput-boolean v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUseCurrentLocation:Z

    .line 51
    iput-boolean v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mIsHomeClock:Z

    .line 52
    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mCityCode:Ljava/lang/String;

    .line 53
    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mCityName:Ljava/lang/String;

    .line 54
    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeZoneStr:Ljava/lang/String;

    .line 55
    iput-boolean v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeZoneChanged:Z

    .line 56
    new-instance v1, Ljava/lang/Object;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrlLock:Ljava/lang/Object;

    .line 57
    iput-boolean v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mPauseByAddToHome:Z

    .line 58
    iput-boolean v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mBoolAppDestroy:Z

    .line 59
    sget-object v1, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;->NONE:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;

    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiState:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;

    .line 198
    new-instance v1, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$1;

    invoke-direct {v1, p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$1;-><init>(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)V

    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mClockClick:Landroid/view/View$OnClickListener;

    .line 285
    new-instance v1, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;

    invoke-direct {v1, p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$2;-><init>(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)V

    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mWorker:Landroid/os/Handler$Callback;

    .line 383
    new-instance v1, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$3;

    invoke-direct {v1, p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$3;-><init>(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)V

    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiWorker:Landroid/os/Handler$Callback;

    .line 72
    iput-object p1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mResContext:Landroid/content/Context;

    .line 73
    iput-object p2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mApplication:Landroid/content/Context;

    .line 74
    if-eqz p3, :cond_b4

    .line 75
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mWorker:Landroid/os/Handler$Callback;

    invoke-interface {p3, v1}, Lcom/htc/android/rosie/widget/Widget$Host;->getWorker(Landroid/os/Handler$Callback;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    move-result-object v1

    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    .line 76
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiWorker:Landroid/os/Handler$Callback;

    invoke-interface {p3, v1}, Lcom/htc/android/rosie/widget/Widget$Host;->getWorker(Landroid/os/Handler$Callback;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    move-result-object v1

    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    .line 82
    :goto_57
    iput-object p4, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mScenePort:Lcom/htc/fusion/fx/FxScene;

    .line 83
    iput-object p5, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mSceneLand:Lcom/htc/fusion/fx/FxScene;

    .line 84
    iput p6, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mOrientation:I

    .line 86
    iput-object p7, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mInstanceCallback:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$InstanceCallback;

    .line 87
    new-instance v1, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mResContext:Landroid/content/Context;

    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mApplication:Landroid/content/Context;

    invoke-direct {v1, v2, v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;-><init>(Landroid/content/Context;Landroid/content/Context;)V

    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    .line 89
    new-instance v1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mScenePort:Lcom/htc/fusion/fx/FxScene;

    invoke-direct {v1, v2, p8}, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;-><init>(Lcom/htc/fusion/fx/FxScene;Lcom/htc/clock3dwidget/ClockRes;)V

    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mFxControlsPort:Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;

    .line 90
    sget-boolean v1, Lcom/htc/clock3dwidget/ClockUtils;->SUPPORT_LAND:Z

    if-nez v1, :cond_c7

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mFxControlsPort:Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;

    :goto_79
    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mFxControlsLand:Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;

    .line 91
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mFxControlsPort:Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;

    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mFxControlsLand:Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;

    invoke-virtual {v1, v2, v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->bind(Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;)V

    .line 92
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    iget v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mOrientation:I

    if-ne v2, v4, :cond_cf

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mFxControlsPort:Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;

    :goto_8c
    invoke-virtual {v1, v2}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->init(Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;)V

    .line 94
    if-eqz p3, :cond_98

    .line 95
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mClockClick:Landroid/view/View$OnClickListener;

    invoke-virtual {v1, v2}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 98
    :cond_98
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mResContext:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x7f060005

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    .line 100
    .local v0, "defaultCurName":Ljava/lang/String;
    invoke-static {v0}, Lcom/htc/clock/util/location/LocationUtil;->setDefaultLocName(Ljava/lang/String;)V

    .line 101
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->initView()V

    .line 102
    const v1, 0x9001

    const-wide/16 v2, 0x0

    invoke-virtual {p0, v1, v2, v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->sendNonUiMessageDelayed(IJ)V

    .line 103
    return-void

    .line 78
    .end local v0    # "defaultCurName":Ljava/lang/String;
    :cond_b4
    new-instance v1, Landroid/os/Handler;

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mWorker:Landroid/os/Handler$Callback;

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Handler$Callback;)V

    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhHandler:Landroid/os/Handler;

    .line 79
    new-instance v1, Landroid/os/Handler;

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiWorker:Landroid/os/Handler$Callback;

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Handler$Callback;)V

    iput-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhUiHandler:Landroid/os/Handler;

    goto :goto_57

    .line 90
    :cond_c7
    new-instance v1, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mSceneLand:Lcom/htc/fusion/fx/FxScene;

    invoke-direct {v1, v2, p8}, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;-><init>(Lcom/htc/fusion/fx/FxScene;Lcom/htc/clock3dwidget/ClockRes;)V

    goto :goto_79

    .line 92
    :cond_cf
    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mFxControlsLand:Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;

    goto :goto_8c
.end method

.method static synthetic access$100(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$InstanceCallback;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    .prologue
    .line 29
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mInstanceCallback:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$InstanceCallback;

    return-object v0
.end method

.method static synthetic access$1000(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)V
    .registers 1
    .param p0, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    .prologue
    .line 29
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->doConfigurationChanged()V

    return-void
.end method

.method static synthetic access$1100(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Landroid/content/Context;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    .prologue
    .line 29
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mApplication:Landroid/content/Context;

    return-object v0
.end method

.method static synthetic access$1200(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Ljava/lang/String;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    .prologue
    .line 29
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mCityCode:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$1300(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;Landroid/content/Intent;)V
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;
    .param p1, "x1"    # Landroid/content/Intent;

    .prologue
    .line 29
    invoke-direct {p0, p1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->doActivityResult(Landroid/content/Intent;)V

    return-void
.end method

.method static synthetic access$200(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;Ljava/lang/String;Z)V
    .registers 3
    .param p0, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;
    .param p1, "x1"    # Ljava/lang/String;
    .param p2, "x2"    # Z

    .prologue
    .line 29
    invoke-direct {p0, p1, p2}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->initData(Ljava/lang/String;Z)V

    return-void
.end method

.method static synthetic access$300(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock3dwidget/analogclock/AnalogClockView;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    .prologue
    .line 29
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    return-object v0
.end method

.method static synthetic access$400(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/clock/util/time/TimeCtrl;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    .prologue
    .line 29
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;

    return-object v0
.end method

.method static synthetic access$500(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    .prologue
    .line 29
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    return-object v0
.end method

.method static synthetic access$602(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;)Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;
    .param p1, "x1"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;

    .prologue
    .line 29
    iput-object p1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiState:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;

    return-object p1
.end method

.method static synthetic access$700(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)Landroid/os/Handler;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    .prologue
    .line 29
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhUiHandler:Landroid/os/Handler;

    return-object v0
.end method

.method static synthetic access$800(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)V
    .registers 1
    .param p0, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    .prologue
    .line 29
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->doTimeChanged()V

    return-void
.end method

.method static synthetic access$900(Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;)V
    .registers 1
    .param p0, "x0"    # Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;

    .prologue
    .line 29
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->doFormatChanged()V

    return-void
.end method

.method private clear()V
    .registers 4

    .prologue
    .line 185
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->unInitTimeCtrl()V

    .line 186
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    if-eqz v0, :cond_15

    .line 187
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mFxControlsPort:Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mFxControlsLand:Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;

    invoke-virtual {v0, v1, v2}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->unbind(Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;)V

    .line 188
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->clear()V

    .line 190
    :cond_15
    return-void
.end method

.method private doActivityResult(Landroid/content/Intent;)V
    .registers 2
    .param p1, "data"    # Landroid/content/Intent;

    .prologue
    .line 553
    if-nez p1, :cond_3

    .line 557
    :goto_2
    return-void

    .line 556
    :cond_3
    invoke-direct {p0, p1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->switchToNewCity(Landroid/content/Intent;)V

    goto :goto_2
.end method

.method private doConfigurationChanged()V
    .registers 4

    .prologue
    .line 594
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    iget v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mOrientation:I

    const/4 v2, 0x1

    if-ne v1, v2, :cond_10

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mFxControlsPort:Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;

    :goto_9
    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->init(Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;)V

    .line 595
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->doResume()V

    .line 596
    return-void

    .line 594
    :cond_10
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mFxControlsLand:Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;

    goto :goto_9
.end method

.method private doFormatChanged()V
    .registers 4

    .prologue
    .line 574
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    if-eqz v0, :cond_1e

    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;

    if-eqz v0, :cond_1e

    .line 575
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;

    invoke-virtual {v1}, Lcom/htc/clock/util/time/TimeCtrl;->is24HourFormat()Z

    move-result v1

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;

    invoke-virtual {v2}, Lcom/htc/clock/util/time/TimeCtrl;->getDateFormat()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->setDateFormat(ZLjava/lang/String;)V

    .line 577
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->onTimeChanged()V

    .line 579
    :cond_1e
    return-void
.end method

.method private doResumeInKeyguard()V
    .registers 3

    .prologue
    .line 193
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->obtainMessage()Landroid/os/Message;

    move-result-object v0

    .line 194
    .local v0, "msg":Landroid/os/Message;
    const v1, 0x9015

    iput v1, v0, Landroid/os/Message;->what:I

    .line 195
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v1, v0}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->send(Landroid/os/Message;)V

    .line 196
    return-void
.end method

.method private doTimeChanged()V
    .registers 2

    .prologue
    .line 569
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    if-eqz v0, :cond_9

    .line 570
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->onTimeChanged()V

    .line 571
    :cond_9
    return-void
.end method

.method private hasNonUiMessage(I)Z
    .registers 3
    .param p1, "what"    # I

    .prologue
    .line 457
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    if-eqz v0, :cond_b

    .line 458
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, p1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->hasMessage(I)Z

    move-result v0

    .line 462
    :goto_a
    return v0

    .line 459
    :cond_b
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhHandler:Landroid/os/Handler;

    if-eqz v0, :cond_16

    .line 460
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhHandler:Landroid/os/Handler;

    invoke-virtual {v0, p1}, Landroid/os/Handler;->hasMessages(I)Z

    move-result v0

    goto :goto_a

    .line 462
    :cond_16
    const/4 v0, 0x0

    goto :goto_a
.end method

.method private initData(Ljava/lang/String;Z)V
    .registers 6
    .param p1, "citnameCode"    # Ljava/lang/String;
    .param p2, "bShowCityLabel"    # Z

    .prologue
    const/4 v2, 0x1

    const/4 v1, 0x0

    .line 205
    if-eqz p1, :cond_39

    const-string v0, "Home City"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_39

    .line 206
    iput-boolean v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mIsHomeClock:Z

    .line 207
    iput-boolean v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUseCurrentLocation:Z

    .line 216
    :cond_10
    :goto_10
    iput-object p1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mCityCode:Ljava/lang/String;

    .line 217
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->unInitTimeCtrl()V

    .line 218
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->initTimeCtrl()V

    .line 219
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;

    invoke-virtual {v0}, Lcom/htc/clock/util/time/TimeCtrl;->updateFormat()Z

    .line 220
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;

    invoke-virtual {v1}, Lcom/htc/clock/util/time/TimeCtrl;->is24HourFormat()Z

    move-result v1

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;

    invoke-virtual {v2}, Lcom/htc/clock/util/time/TimeCtrl;->getDateFormat()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->setDateFormat(ZLjava/lang/String;)V

    .line 222
    iput-boolean p2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mBShowCityLabel:Z

    .line 223
    const v0, 0x8005

    const-wide/16 v1, 0x0

    invoke-virtual {p0, v0, v1, v2}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->sendUiMessageDelayed(IJ)V

    .line 224
    return-void

    .line 209
    :cond_39
    iput-boolean v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mIsHomeClock:Z

    .line 210
    if-eqz p1, :cond_45

    const-string v0, "Current City"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_47

    :cond_45
    if-nez p1, :cond_53

    :cond_47
    move v0, v2

    :goto_48
    iput-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUseCurrentLocation:Z

    .line 212
    invoke-static {}, Lcom/htc/clock3dwidget/util/MyProjectSetting;->hasCurrentLocation()Z

    move-result v0

    if-nez v0, :cond_10

    .line 213
    iput-boolean v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUseCurrentLocation:Z

    goto :goto_10

    :cond_53
    move v0, v1

    .line 210
    goto :goto_48
.end method

.method private initTimeCtrl()V
    .registers 8

    .prologue
    .line 227
    iget-object v6, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrlLock:Ljava/lang/Object;

    monitor-enter v6

    .line 228
    :try_start_3
    new-instance v4, Landroid/os/Handler;

    invoke-direct {v4}, Landroid/os/Handler;-><init>()V

    .line 229
    .local v4, "handler":Landroid/os/Handler;
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mInstanceCallback:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$InstanceCallback;

    if-eqz v0, :cond_3c

    .line 231
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUseCurrentLocation:Z

    if-eqz v0, :cond_25

    .line 232
    new-instance v0, Lcom/htc/clock/util/time/CurLocationTimeCtrl;

    invoke-direct {v0}, Lcom/htc/clock/util/time/CurLocationTimeCtrl;-><init>()V

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;

    .line 238
    :goto_17
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mResContext:Landroid/content/Context;

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeListener:Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;

    const/4 v3, 0x2

    iget-object v5, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mCityCode:Ljava/lang/String;

    invoke-virtual/range {v0 .. v5}, Lcom/htc/clock/util/time/TimeCtrl;->init(Landroid/content/Context;Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;ILandroid/os/Handler;Ljava/lang/String;)V

    .line 246
    :goto_23
    monitor-exit v6

    .line 247
    return-void

    .line 233
    :cond_25
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mIsHomeClock:Z

    if-eqz v0, :cond_34

    .line 234
    new-instance v0, Lcom/htc/clock/util/time/HomeTimeCtrl;

    invoke-direct {v0}, Lcom/htc/clock/util/time/HomeTimeCtrl;-><init>()V

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;

    goto :goto_17

    .line 246
    .end local v4    # "handler":Landroid/os/Handler;
    :catchall_31
    move-exception v0

    monitor-exit v6
    :try_end_33
    .catchall {:try_start_3 .. :try_end_33} :catchall_31

    throw v0

    .line 236
    .restart local v4    # "handler":Landroid/os/Handler;
    :cond_34
    :try_start_34
    new-instance v0, Lcom/htc/clock/util/time/TimeCtrl;

    invoke-direct {v0}, Lcom/htc/clock/util/time/TimeCtrl;-><init>()V

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;

    goto :goto_17

    .line 241
    :cond_3c
    new-instance v0, Lcom/htc/clock/util/time/TimeCtrl;

    invoke-direct {v0}, Lcom/htc/clock/util/time/TimeCtrl;-><init>()V

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;

    .line 242
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mResContext:Landroid/content/Context;

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeListener:Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;

    const/4 v3, 0x6

    iget-object v5, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mCityCode:Ljava/lang/String;

    invoke-virtual/range {v0 .. v5}, Lcom/htc/clock/util/time/TimeCtrl;->init(Landroid/content/Context;Lcom/htc/clock/util/time/TimeCtrl$OnTimeListener;ILandroid/os/Handler;Ljava/lang/String;)V
    :try_end_4f
    .catchall {:try_start_34 .. :try_end_4f} :catchall_31

    goto :goto_23
.end method

.method private obtainNonUiMessage()Landroid/os/Message;
    .registers 3

    .prologue
    .line 494
    const/4 v0, 0x0

    .line 496
    .local v0, "msg":Landroid/os/Message;
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    if-eqz v1, :cond_c

    .line 497
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->obtainMessage()Landroid/os/Message;

    move-result-object v0

    .line 501
    :cond_b
    :goto_b
    return-object v0

    .line 498
    :cond_c
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhHandler:Landroid/os/Handler;

    if-eqz v1, :cond_b

    .line 499
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhHandler:Landroid/os/Handler;

    invoke-virtual {v1}, Landroid/os/Handler;->obtainMessage()Landroid/os/Message;

    move-result-object v0

    goto :goto_b
.end method

.method private removeMessages()V
    .registers 2

    .prologue
    .line 164
    const v0, 0x9001

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeNonUiMessages(I)V

    .line 165
    const v0, 0x9002

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeNonUiMessages(I)V

    .line 166
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeNonUiMessages(I)V

    .line 167
    const/4 v0, 0x2

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeNonUiMessages(I)V

    .line 168
    const v0, 0x9003

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeNonUiMessages(I)V

    .line 169
    const v0, 0x9205

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeNonUiMessages(I)V

    .line 170
    const v0, 0x9011

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeNonUiMessages(I)V

    .line 171
    const v0, 0x9012

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeNonUiMessages(I)V

    .line 172
    const v0, 0x9014

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeNonUiMessages(I)V

    .line 175
    const v0, 0x8001

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeUiMessages(I)V

    .line 176
    const v0, 0x8022

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeUiMessages(I)V

    .line 177
    const v0, 0x8019

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeUiMessages(I)V

    .line 178
    const v0, 0x8004

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeUiMessages(I)V

    .line 179
    const v0, 0x8005

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeUiMessages(I)V

    .line 180
    const v0, 0x8011

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeUiMessages(I)V

    .line 181
    return-void
.end method

.method private switchToNewCity(Landroid/content/Intent;)V
    .registers 5
    .param p1, "data"    # Landroid/content/Intent;

    .prologue
    .line 582
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mInstanceCallback:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$InstanceCallback;

    invoke-interface {v0, p1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$InstanceCallback;->savePropertyData(Landroid/content/Intent;)V

    .line 583
    const v0, 0x9001

    const-wide/16 v1, 0x0

    invoke-virtual {p0, v0, v1, v2}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->sendNonUiMessageDelayed(IJ)V

    .line 584
    return-void
.end method

.method private unInitTimeCtrl()V
    .registers 3

    .prologue
    .line 250
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrlLock:Ljava/lang/Object;

    monitor-enter v0

    .line 251
    :try_start_3
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;

    if-eqz v1, :cond_c

    .line 252
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;

    invoke-virtual {v1}, Lcom/htc/clock/util/time/TimeCtrl;->uninit()V

    .line 254
    :cond_c
    monitor-exit v0

    .line 255
    return-void

    .line 254
    :catchall_e
    move-exception v1

    monitor-exit v0
    :try_end_10
    .catchall {:try_start_3 .. :try_end_10} :catchall_e

    throw v1
.end method


# virtual methods
.method public doActivityResult(IILandroid/content/Intent;)V
    .registers 7
    .param p1, "requestCode"    # I
    .param p2, "resultCode"    # I
    .param p3, "data"    # Landroid/content/Intent;

    .prologue
    .line 148
    const/4 v1, -0x1

    if-ne p2, v1, :cond_13

    .line 149
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->obtainNonUiMessage()Landroid/os/Message;

    move-result-object v0

    .line 150
    .local v0, "msg":Landroid/os/Message;
    const v1, 0x9014

    iput v1, v0, Landroid/os/Message;->what:I

    .line 151
    iput-object p3, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 152
    const-wide/16 v1, 0x0

    invoke-virtual {p0, v0, v1, v2}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->sendNonUiMessageDelayed(Landroid/os/Message;J)V

    .line 154
    .end local v0    # "msg":Landroid/os/Message;
    :cond_13
    return-void
.end method

.method public doDestroy()V
    .registers 2

    .prologue
    .line 157
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mBoolAppDestroy:Z

    .line 158
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeMessages()V

    .line 159
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->clear()V

    .line 160
    return-void
.end method

.method public doHostMessage(Landroid/os/Message;)V
    .registers 5
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    .line 130
    iget v0, p1, Landroid/os/Message;->what:I

    packed-switch v0, :pswitch_data_4a

    .line 145
    :cond_5
    :goto_5
    :pswitch_5
    return-void

    .line 134
    :pswitch_6
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "HOST_USER_PRESENT,arg1= "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p1, Landroid/os/Message;->arg1:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", mUiState="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiState:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 135
    iget v0, p1, Landroid/os/Message;->arg1:I

    and-int/lit8 v0, v0, 0x1

    if-eqz v0, :cond_5

    .line 136
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiState:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;

    sget-object v1, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;->PAUSED:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;

    if-eq v0, v1, :cond_3c

    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiState:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;

    sget-object v1, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;->NONE:Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget$UiState;

    if-ne v0, v1, :cond_5

    .line 137
    :cond_3c
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->doResumeInKeyguard()V

    goto :goto_5

    .line 142
    :pswitch_40
    const v0, 0x9011

    const-wide/16 v1, 0x0

    invoke-virtual {p0, v0, v1, v2}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->sendNonUiMessageDelayed(IJ)V

    goto :goto_5

    .line 130
    nop

    :pswitch_data_4a
    .packed-switch 0x3
        :pswitch_40
        :pswitch_5
        :pswitch_6
    .end packed-switch
.end method

.method public doPause()V
    .registers 5

    .prologue
    const/16 v3, 0x1e

    const/4 v2, 0x2

    .line 113
    const v1, 0x8022

    invoke-virtual {p0, v1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeUiMessages(I)V

    .line 114
    invoke-virtual {p0, v2}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeNonUiMessages(I)V

    .line 116
    const/4 v0, 0x0

    .line 117
    .local v0, "msg":Landroid/os/Message;
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    if-eqz v1, :cond_21

    .line 118
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->obtainMessage()Landroid/os/Message;

    move-result-object v0

    .line 119
    iput v2, v0, Landroid/os/Message;->what:I

    .line 120
    iput v3, v0, Landroid/os/Message;->arg1:I

    .line 126
    :cond_1b
    :goto_1b
    const-wide/16 v1, 0x0

    invoke-virtual {p0, v0, v1, v2}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->sendNonUiMessageDelayed(Landroid/os/Message;J)V

    .line 127
    return-void

    .line 121
    :cond_21
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhHandler:Landroid/os/Handler;

    if-eqz v1, :cond_1b

    .line 122
    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhHandler:Landroid/os/Handler;

    invoke-virtual {v1}, Landroid/os/Handler;->obtainMessage()Landroid/os/Message;

    move-result-object v0

    .line 123
    iput v2, v0, Landroid/os/Message;->what:I

    .line 124
    iput v3, v0, Landroid/os/Message;->arg1:I

    goto :goto_1b
.end method

.method public doResume()V
    .registers 4

    .prologue
    const/4 v2, 0x1

    .line 106
    const v0, 0x8022

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeUiMessages(I)V

    .line 107
    invoke-virtual {p0, v2}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeNonUiMessages(I)V

    .line 109
    const-wide/16 v0, 0x0

    invoke-virtual {p0, v2, v0, v1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->sendNonUiMessageDelayed(IJ)V

    .line 110
    return-void
.end method

.method public doTiltChanged(F)V
    .registers 3
    .param p1, "tilt"    # F

    .prologue
    .line 560
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mBoolAppDestroy:Z

    if-eqz v0, :cond_5

    .line 566
    :cond_4
    :goto_4
    return-void

    .line 563
    :cond_5
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    if-eqz v0, :cond_4

    .line 564
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    invoke-virtual {v0, p1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->doTiltChanged(F)V

    goto :goto_4
.end method

.method protected initView()V
    .registers 5

    .prologue
    .line 548
    invoke-virtual {p0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->updateCityName()V

    .line 549
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    const/4 v1, 0x0

    iget-object v2, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    iget-object v3, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhUiHandler:Landroid/os/Handler;

    invoke-virtual {v0, v1, v2, v3}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->setAnimationFeedback(ZLcom/htc/android/rosie/widget/Widget$Host$Worker;Landroid/os/Handler;)V

    .line 550
    return-void
.end method

.method public onConfigurationChanged(I)V
    .registers 4
    .param p1, "orientation"    # I

    .prologue
    const v1, 0x9011

    .line 587
    iput p1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mOrientation:I

    .line 588
    invoke-direct {p0, v1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->hasNonUiMessage(I)Z

    move-result v0

    if-eqz v0, :cond_e

    .line 589
    invoke-virtual {p0, v1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeNonUiMessages(I)V

    .line 591
    :cond_e
    return-void
.end method

.method public onNotifyWidgetPause(I)V
    .registers 5
    .param p1, "notifyCause"    # I

    .prologue
    .line 278
    const v0, 0x8001

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->removeUiMessages(I)V

    .line 279
    const/16 v0, 0x1e

    if-ne p1, v0, :cond_13

    .line 280
    const v0, 0x9002

    const-wide/16 v1, 0x0

    invoke-virtual {p0, v0, v1, v2}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->sendNonUiMessageDelayed(IJ)V

    .line 283
    :goto_12
    return-void

    .line 282
    :cond_13
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->setPause(Z)V

    goto :goto_12
.end method

.method protected removeNonUiMessages(I)V
    .registers 3
    .param p1, "what"    # I

    .prologue
    .line 505
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    if-eqz v0, :cond_a

    .line 506
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, p1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->recall(I)V

    .line 510
    :cond_9
    :goto_9
    return-void

    .line 507
    :cond_a
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhHandler:Landroid/os/Handler;

    if-eqz v0, :cond_9

    .line 508
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhHandler:Landroid/os/Handler;

    invoke-virtual {v0, p1}, Landroid/os/Handler;->removeMessages(I)V

    goto :goto_9
.end method

.method protected removeUiMessages(I)V
    .registers 3
    .param p1, "what"    # I

    .prologue
    .line 449
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    if-eqz v0, :cond_a

    .line 450
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, p1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->recall(I)V

    .line 454
    :cond_9
    :goto_9
    return-void

    .line 451
    :cond_a
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhUiHandler:Landroid/os/Handler;

    if-eqz v0, :cond_9

    .line 452
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhUiHandler:Landroid/os/Handler;

    invoke-virtual {v0, p1}, Landroid/os/Handler;->removeMessages(I)V

    goto :goto_9
.end method

.method protected sendNonUiMessageDelayed(IJ)V
    .registers 7
    .param p1, "what"    # I
    .param p2, "delayMillis"    # J

    .prologue
    const-wide/16 v1, 0x0

    .line 466
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    if-eqz v0, :cond_16

    .line 467
    cmp-long v0, p2, v1

    if-lez v0, :cond_10

    .line 468
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, p1, p2, p3}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->sendDelayed(IJ)V

    .line 477
    :cond_f
    :goto_f
    return-void

    .line 470
    :cond_10
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, p1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->send(I)V

    goto :goto_f

    .line 471
    :cond_16
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhHandler:Landroid/os/Handler;

    if-eqz v0, :cond_f

    .line 472
    cmp-long v0, p2, v1

    if-lez v0, :cond_24

    .line 473
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhHandler:Landroid/os/Handler;

    invoke-virtual {v0, p1, p2, p3}, Landroid/os/Handler;->sendEmptyMessageDelayed(IJ)Z

    goto :goto_f

    .line 475
    :cond_24
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhHandler:Landroid/os/Handler;

    invoke-virtual {v0, p1}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    goto :goto_f
.end method

.method protected sendNonUiMessageDelayed(Landroid/os/Message;J)V
    .registers 7
    .param p1, "msg"    # Landroid/os/Message;
    .param p2, "delayMillis"    # J

    .prologue
    const-wide/16 v1, 0x0

    .line 480
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    if-eqz v0, :cond_16

    .line 481
    cmp-long v0, p2, v1

    if-lez v0, :cond_10

    .line 482
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, p1, p2, p3}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->sendDelayed(Landroid/os/Message;J)V

    .line 491
    :cond_f
    :goto_f
    return-void

    .line 484
    :cond_10
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, p1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->send(Landroid/os/Message;)V

    goto :goto_f

    .line 485
    :cond_16
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhHandler:Landroid/os/Handler;

    if-eqz v0, :cond_f

    .line 486
    cmp-long v0, p2, v1

    if-lez v0, :cond_24

    .line 487
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhHandler:Landroid/os/Handler;

    invoke-virtual {v0, p1, p2, p3}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    goto :goto_f

    .line 489
    :cond_24
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhHandler:Landroid/os/Handler;

    invoke-virtual {v0, p1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto :goto_f
.end method

.method protected sendUiMessageDelayed(IJ)V
    .registers 7
    .param p1, "what"    # I
    .param p2, "delayMillis"    # J

    .prologue
    const-wide/16 v1, 0x0

    .line 421
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    if-eqz v0, :cond_16

    .line 422
    cmp-long v0, p2, v1

    if-lez v0, :cond_10

    .line 423
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, p1, p2, p3}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->sendDelayed(IJ)V

    .line 432
    :cond_f
    :goto_f
    return-void

    .line 425
    :cond_10
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, p1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->send(I)V

    goto :goto_f

    .line 426
    :cond_16
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhUiHandler:Landroid/os/Handler;

    if-eqz v0, :cond_f

    .line 427
    cmp-long v0, p2, v1

    if-lez v0, :cond_24

    .line 428
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhUiHandler:Landroid/os/Handler;

    invoke-virtual {v0, p1, p2, p3}, Landroid/os/Handler;->sendEmptyMessageDelayed(IJ)Z

    goto :goto_f

    .line 430
    :cond_24
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhUiHandler:Landroid/os/Handler;

    invoke-virtual {v0, p1}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    goto :goto_f
.end method

.method protected sendUiMessageDelayed(Landroid/os/Message;J)V
    .registers 7
    .param p1, "msg"    # Landroid/os/Message;
    .param p2, "delayMillis"    # J

    .prologue
    const-wide/16 v1, 0x0

    .line 435
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    if-eqz v0, :cond_16

    .line 436
    cmp-long v0, p2, v1

    if-lez v0, :cond_10

    .line 437
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, p1, p2, p3}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->sendDelayed(Landroid/os/Message;J)V

    .line 446
    :cond_f
    :goto_f
    return-void

    .line 439
    :cond_10
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    invoke-interface {v0, p1}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->send(Landroid/os/Message;)V

    goto :goto_f

    .line 440
    :cond_16
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhUiHandler:Landroid/os/Handler;

    if-eqz v0, :cond_f

    .line 441
    cmp-long v0, p2, v1

    if-lez v0, :cond_24

    .line 442
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhUiHandler:Landroid/os/Handler;

    invoke-virtual {v0, p1, p2, p3}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    goto :goto_f

    .line 444
    :cond_24
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mhUiHandler:Landroid/os/Handler;

    invoke-virtual {v0, p1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    goto :goto_f
.end method

.method protected setCityName(Ljava/lang/String;)V
    .registers 4
    .param p1, "cityName"    # Ljava/lang/String;

    .prologue
    .line 536
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    iget-object v0, v0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCityName:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_19

    .line 537
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mBShowCityLabel:Z

    if-eqz v0, :cond_1a

    .line 538
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    iget-object v0, v0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCityName:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setVisibility(Z)Ljava/util/ArrayList;

    .line 539
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    iget-object v0, v0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCityName:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v0, p1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 545
    :cond_19
    :goto_19
    return-void

    .line 542
    :cond_1a
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    iget-object v0, v0, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->mCityName:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setVisibility(Z)Ljava/util/ArrayList;

    goto :goto_19
.end method

.method protected updateCityName()V
    .registers 2

    .prologue
    .line 513
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;

    if-eqz v0, :cond_8

    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    if-nez v0, :cond_9

    .line 518
    :cond_8
    :goto_8
    return-void

    .line 516
    :cond_9
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;

    invoke-virtual {v0}, Lcom/htc/clock/util/time/TimeCtrl;->getTimeZoneCity()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mCityName:Ljava/lang/String;

    .line 517
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mCityName:Ljava/lang/String;

    invoke-virtual {p0, v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->setCityName(Ljava/lang/String;)V

    goto :goto_8
.end method

.method public updateTime()V
    .registers 2

    .prologue
    .line 530
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    if-eqz v0, :cond_9

    .line 531
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->onTimeChanged()V

    .line 533
    :cond_9
    return-void
.end method

.method public updateTimeZone()V
    .registers 3

    .prologue
    .line 521
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeCtrl:Lcom/htc/clock/util/time/TimeCtrl;

    invoke-virtual {v0}, Lcom/htc/clock/util/time/TimeCtrl;->getCalendar()Ljava/util/Calendar;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/Calendar;->getTimeZone()Ljava/util/TimeZone;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/TimeZone;->getID()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeZoneStr:Ljava/lang/String;

    .line 522
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "TimeCtrl~ getCalendar mTimeZoneStr:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeZoneStr:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 523
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    if-eqz v0, :cond_33

    .line 524
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mTimeZoneStr:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->setTimeZone(Ljava/lang/String;)V

    .line 527
    :cond_33
    return-void
.end method

.method protected what_Is_Paused()V
    .registers 3

    .prologue
    .line 378
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    if-eqz v0, :cond_a

    .line 379
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/AnalogClockWidget;->mAnalogClockView:Lcom/htc/clock3dwidget/analogclock/AnalogClockView;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/analogclock/AnalogClockView;->setPause(Z)V

    .line 381
    :cond_a
    return-void
.end method
