.class public Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;
.super Ljava/lang/Object;
.source "FxAnalogControls.java"


# static fields
.field private static final HOUR:Ljava/lang/String; = "timeline.flip_hour"

.field private static final MIN:Ljava/lang/String; = "timeline.flip_minute"

.field private static final TILT:Ljava/lang/String; = "timeline.tiltanim"


# instance fields
.field public mCityName:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field public mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

.field public mDigital_Hour_ten:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mDigital_Hour_unit:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

.field public mDigital_Minute_ten:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mDigital_Minute_unit:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mFxClockBase:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mFxClockDate:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mFxClockHour:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mFxClockMinute:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mFxClockNumbers:Lcom/htc/fusion/fx/FxTimelineControl;

.field private mFxDigitalHour:Lcom/htc/fusion/fx/FxTimelineControl;

.field private mFxDigitalMinute:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mFxHitbox:Lcom/htc/fusion/fx/controls/FxHitbox;

.field public mFxPBHour:Lcom/htc/fusion/fx/controls/FxProgressBar;

.field public mFxPBMin:Lcom/htc/fusion/fx/controls/FxProgressBar;

.field public mFxPBSec:Lcom/htc/fusion/fx/controls/FxProgressBar;

.field public mFxPBUintHour:Lcom/htc/fusion/fx/controls/FxProgressBar;

.field public mFxPBUnitMin:Lcom/htc/fusion/fx/controls/FxProgressBar;

.field public mFxTextAMPM:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field public mFxTextAMPM_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field public mFxTextDate:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field public mFxTextDate_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field public mFxTextHour:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field public mFxTextLongDate:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field public mFxTextMinute:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field public mFxTextSecond:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field public mFxTextWeekDay:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field public mFxTextWeekDay_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field public mFxTimeLineGear01:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mFxTimeLineGear02:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mFxTimeLineGear03:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mFxTimeLineGear04:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mFxTimeLineGear05:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mFxTimelineAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mFxTimelineAmPmOpp:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mFxTimelineClock:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mFxTimelineClockAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mFxTimelineWiggle:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mHourCap:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mMarkerHour:Lcom/htc/fusion/fx/Marker;

.field public mMarkerMin:Lcom/htc/fusion/fx/Marker;

.field public mMinCap:Lcom/htc/fusion/fx/FxTimelineControl;

.field public mTileMark:Lcom/htc/fusion/fx/Marker;

.field public mTiltAnime:Lcom/htc/fusion/fx/FxTimelineControl;


# direct methods
.method public constructor <init>(Lcom/htc/fusion/fx/FxScene;Lcom/htc/clock3dwidget/ClockRes;)V
    .registers 7
    .param p1, "scene"    # Lcom/htc/fusion/fx/FxScene;
    .param p2, "res"    # Lcom/htc/clock3dwidget/ClockRes;

    .prologue
    const/4 v3, 0x0

    .line 81
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 83
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 84
    .local v0, "nameList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/String;>;"
    invoke-direct {p0, p1, p2, v0, v3}, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->getFxControls(Lcom/htc/fusion/fx/FxScene;Lcom/htc/clock3dwidget/ClockRes;Ljava/util/ArrayList;[Lcom/htc/fusion/fx/FxObject;)V

    .line 86
    const/4 v2, 0x0

    new-array v2, v2, [Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [Ljava/lang/String;

    invoke-virtual {p1, v2}, Lcom/htc/fusion/fx/FxScene;->getDescendants([Ljava/lang/String;)[Lcom/htc/fusion/fx/FxObject;

    move-result-object v1

    .line 87
    .local v1, "objs":[Lcom/htc/fusion/fx/FxObject;
    invoke-direct {p0, p1, p2, v3, v1}, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->getFxControls(Lcom/htc/fusion/fx/FxScene;Lcom/htc/clock3dwidget/ClockRes;Ljava/util/ArrayList;[Lcom/htc/fusion/fx/FxObject;)V

    .line 89
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->setupControls()V

    .line 90
    invoke-direct {p0}, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->reset()V

    .line 91
    return-void
.end method

.method private getFxControls(Lcom/htc/fusion/fx/FxScene;Lcom/htc/clock3dwidget/ClockRes;Ljava/util/ArrayList;[Lcom/htc/fusion/fx/FxObject;)V
    .registers 9
    .param p1, "scene"    # Lcom/htc/fusion/fx/FxScene;
    .param p2, "res"    # Lcom/htc/clock3dwidget/ClockRes;
    .param p4, "objs"    # [Lcom/htc/fusion/fx/FxObject;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/htc/fusion/fx/FxScene;",
            "Lcom/htc/clock3dwidget/ClockRes;",
            "Ljava/util/ArrayList",
            "<",
            "Ljava/lang/String;",
            ">;[",
            "Lcom/htc/fusion/fx/FxObject;",
            ")V"
        }
    .end annotation

    .prologue
    .line 94
    .local p3, "nameList":Ljava/util/ArrayList;, "Ljava/util/ArrayList<Ljava/lang/String;>;"
    if-eqz p3, :cond_1bf

    const/4 v3, 0x1

    move v2, v3

    .line 95
    .local v2, "name":Z
    :goto_4
    const/4 v0, 0x0

    .line 96
    .local v0, "index":I
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->hitboxClock:Ljava/lang/String;

    if-eqz v3, :cond_10

    .line 97
    if-eqz v2, :cond_1c3

    .line 98
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->hitboxClock:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 104
    :cond_10
    :goto_10
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->progressBarHourHand:Ljava/lang/String;

    if-eqz v3, :cond_1b

    .line 105
    if-eqz v2, :cond_1ce

    .line 106
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->progressBarHourHand:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 111
    :cond_1b
    :goto_1b
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->progressBarMinuteHand:Ljava/lang/String;

    if-eqz v3, :cond_26

    .line 112
    if-eqz v2, :cond_1d9

    .line 113
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->progressBarMinuteHand:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 118
    :cond_26
    :goto_26
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->progressBarSecondHand:Ljava/lang/String;

    if-eqz v3, :cond_31

    .line 119
    if-eqz v2, :cond_1e4

    .line 120
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->progressBarSecondHand:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 126
    :cond_31
    :goto_31
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->progressBarUnitHourHand:Ljava/lang/String;

    if-eqz v3, :cond_3c

    .line 127
    if-eqz v2, :cond_1ef

    .line 128
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->progressBarUnitHourHand:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 133
    :cond_3c
    :goto_3c
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->progressBarUnitMinuteHand:Ljava/lang/String;

    if-eqz v3, :cond_47

    .line 134
    if-eqz v2, :cond_1fa

    .line 135
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->progressBarUnitMinuteHand:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 141
    :cond_47
    :goto_47
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabelCityName:Ljava/lang/String;

    if-eqz v3, :cond_52

    .line 142
    if-eqz v2, :cond_205

    .line 143
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabelCityName:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 148
    :cond_52
    :goto_52
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineHourTen:Ljava/lang/String;

    if-eqz v3, :cond_5d

    .line 149
    if-eqz v2, :cond_210

    .line 150
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineHourTen:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 157
    :cond_5d
    :goto_5d
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineHourUnit:Ljava/lang/String;

    if-eqz v3, :cond_68

    .line 158
    if-eqz v2, :cond_21b

    .line 159
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineHourUnit:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 164
    :cond_68
    :goto_68
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineMinuteTen:Ljava/lang/String;

    if-eqz v3, :cond_73

    .line 165
    if-eqz v2, :cond_226

    .line 166
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineMinuteTen:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 171
    :cond_73
    :goto_73
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineMinuteUinit:Ljava/lang/String;

    if-eqz v3, :cond_7e

    .line 172
    if-eqz v2, :cond_231

    .line 173
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineMinuteUinit:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 178
    :cond_7e
    :goto_7e
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineGear01:Ljava/lang/String;

    if-eqz v3, :cond_89

    .line 179
    if-eqz v2, :cond_23c

    .line 180
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineGear01:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 185
    :cond_89
    :goto_89
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineGear02:Ljava/lang/String;

    if-eqz v3, :cond_94

    .line 186
    if-eqz v2, :cond_247

    .line 187
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineGear02:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 192
    :cond_94
    :goto_94
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineGear03:Ljava/lang/String;

    if-eqz v3, :cond_9f

    .line 193
    if-eqz v2, :cond_252

    .line 194
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineGear03:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 199
    :cond_9f
    :goto_9f
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineGear04:Ljava/lang/String;

    if-eqz v3, :cond_aa

    .line 200
    if-eqz v2, :cond_25d

    .line 201
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineGear04:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 206
    :cond_aa
    :goto_aa
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineGear05:Ljava/lang/String;

    if-eqz v3, :cond_b5

    .line 207
    if-eqz v2, :cond_268

    .line 208
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineGear05:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 213
    :cond_b5
    :goto_b5
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineWiggle:Ljava/lang/String;

    if-eqz v3, :cond_c0

    .line 214
    if-eqz v2, :cond_273

    .line 215
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineWiggle:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 220
    :cond_c0
    :goto_c0
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabelHour:Ljava/lang/String;

    if-eqz v3, :cond_cb

    .line 221
    if-eqz v2, :cond_27e

    .line 222
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabelHour:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 227
    :cond_cb
    :goto_cb
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabelMinute:Ljava/lang/String;

    if-eqz v3, :cond_d6

    .line 228
    if-eqz v2, :cond_289

    .line 229
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabelMinute:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 234
    :cond_d6
    :goto_d6
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabelSecond:Ljava/lang/String;

    if-eqz v3, :cond_e1

    .line 235
    if-eqz v2, :cond_294

    .line 236
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabelSecond:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 242
    :cond_e1
    :goto_e1
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineClockBase:Ljava/lang/String;

    if-eqz v3, :cond_ec

    .line 243
    if-eqz v2, :cond_29f

    .line 244
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineClockBase:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 249
    :cond_ec
    :goto_ec
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineClockNumbers:Ljava/lang/String;

    if-eqz v3, :cond_f7

    .line 251
    if-eqz v2, :cond_2aa

    .line 252
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineClockNumbers:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 257
    :cond_f7
    :goto_f7
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineClockDate:Ljava/lang/String;

    if-eqz v3, :cond_102

    .line 258
    if-eqz v2, :cond_2b5

    .line 259
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineClockDate:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 264
    :cond_102
    :goto_102
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineClockHour:Ljava/lang/String;

    if-eqz v3, :cond_10d

    .line 265
    if-eqz v2, :cond_2c0

    .line 266
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineClockHour:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 271
    :cond_10d
    :goto_10d
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineClockMinute:Ljava/lang/String;

    if-eqz v3, :cond_118

    .line 272
    if-eqz v2, :cond_2cb

    .line 273
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineClockMinute:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 280
    :cond_118
    :goto_118
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineClock:Ljava/lang/String;

    if-eqz v3, :cond_123

    .line 281
    if-eqz v2, :cond_2d6

    .line 282
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineClock:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 287
    :cond_123
    :goto_123
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineAmPm:Ljava/lang/String;

    if-eqz v3, :cond_12e

    .line 288
    if-eqz v2, :cond_2e1

    .line 289
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineAmPm:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 294
    :cond_12e
    :goto_12e
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineAmPmOpp:Ljava/lang/String;

    if-eqz v3, :cond_139

    .line 295
    if-eqz v2, :cond_2ec

    .line 296
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineAmPmOpp:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 302
    :cond_139
    :goto_139
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineClockAmPm:Ljava/lang/String;

    if-eqz v3, :cond_144

    .line 303
    if-eqz v2, :cond_2f7

    .line 304
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineClockAmPm:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 310
    :cond_144
    :goto_144
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockDate:Ljava/lang/String;

    if-eqz v3, :cond_14f

    .line 311
    if-eqz v2, :cond_302

    .line 312
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockDate:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 317
    :cond_14f
    :goto_14f
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockLongDate:Ljava/lang/String;

    if-eqz v3, :cond_15a

    .line 318
    if-eqz v2, :cond_30d

    .line 319
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockLongDate:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 324
    :cond_15a
    :goto_15a
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockWeekDay:Ljava/lang/String;

    if-eqz v3, :cond_165

    .line 325
    if-eqz v2, :cond_318

    .line 326
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockWeekDay:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 331
    :cond_165
    :goto_165
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabalClockAmPm:Ljava/lang/String;

    if-eqz v3, :cond_170

    .line 332
    if-eqz v2, :cond_323

    .line 333
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabalClockAmPm:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 339
    :cond_170
    :goto_170
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockDate_night:Ljava/lang/String;

    if-eqz v3, :cond_17b

    .line 340
    if-eqz v2, :cond_32e

    .line 341
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockDate_night:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 346
    :cond_17b
    :goto_17b
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockWeekDay_night:Ljava/lang/String;

    if-eqz v3, :cond_186

    .line 347
    if-eqz v2, :cond_339

    .line 348
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabelClockWeekDay_night:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 353
    :cond_186
    :goto_186
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabalClockAmPm_night:Ljava/lang/String;

    if-eqz v3, :cond_191

    .line 354
    if-eqz v2, :cond_344

    .line 355
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->textLabalClockAmPm_night:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 360
    :cond_191
    :goto_191
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineFlipHour:Ljava/lang/String;

    if-eqz v3, :cond_19c

    .line 361
    if-eqz v2, :cond_34f

    .line 362
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineFlipHour:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 367
    :cond_19c
    :goto_19c
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineFlipMinute:Ljava/lang/String;

    if-eqz v3, :cond_384

    .line 368
    if-eqz v2, :cond_35a

    .line 369
    iget-object v3, p2, Lcom/htc/clock3dwidget/ClockRes;->timelineFlipMinute:Ljava/lang/String;

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move v1, v0

    .line 375
    .end local v0    # "index":I
    .local v1, "index":I
    :goto_1a8
    if-eqz v2, :cond_364

    .line 376
    const-string v3, "timeline.tiltanim"

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 381
    :goto_1af
    if-eqz v2, :cond_36f

    .line 382
    const-string v3, "timeline.flip_hour"

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 387
    :goto_1b6
    if-eqz v2, :cond_37a

    .line 388
    const-string v3, "timeline.flip_minute"

    invoke-virtual {p3, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move v0, v1

    .line 392
    .end local v1    # "index":I
    .restart local v0    # "index":I
    :goto_1be
    return-void

    .line 94
    .end local v0    # "index":I
    .end local v2    # "name":Z
    :cond_1bf
    const/4 v3, 0x0

    move v2, v3

    goto/16 :goto_4

    .line 100
    .restart local v0    # "index":I
    .restart local v2    # "name":Z
    :cond_1c3
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/controls/FxHitbox;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxHitbox:Lcom/htc/fusion/fx/controls/FxHitbox;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_10

    .line 108
    :cond_1ce
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/controls/FxProgressBar;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxPBHour:Lcom/htc/fusion/fx/controls/FxProgressBar;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_1b

    .line 115
    :cond_1d9
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/controls/FxProgressBar;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxPBMin:Lcom/htc/fusion/fx/controls/FxProgressBar;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_26

    .line 122
    :cond_1e4
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/controls/FxProgressBar;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxPBSec:Lcom/htc/fusion/fx/controls/FxProgressBar;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_31

    .line 130
    :cond_1ef
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/controls/FxProgressBar;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxPBUintHour:Lcom/htc/fusion/fx/controls/FxProgressBar;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_3c

    .line 137
    :cond_1fa
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/controls/FxProgressBar;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxPBUnitMin:Lcom/htc/fusion/fx/controls/FxProgressBar;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_47

    .line 145
    :cond_205
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mCityName:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_52

    .line 152
    :cond_210
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Hour_ten:Lcom/htc/fusion/fx/FxTimelineControl;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_5d

    .line 161
    :cond_21b
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Hour_unit:Lcom/htc/fusion/fx/FxTimelineControl;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_68

    .line 168
    :cond_226
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Minute_ten:Lcom/htc/fusion/fx/FxTimelineControl;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_73

    .line 175
    :cond_231
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Minute_unit:Lcom/htc/fusion/fx/FxTimelineControl;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_7e

    .line 182
    :cond_23c
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimeLineGear01:Lcom/htc/fusion/fx/FxTimelineControl;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_89

    .line 189
    :cond_247
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimeLineGear02:Lcom/htc/fusion/fx/FxTimelineControl;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_94

    .line 196
    :cond_252
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimeLineGear03:Lcom/htc/fusion/fx/FxTimelineControl;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_9f

    .line 203
    :cond_25d
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimeLineGear04:Lcom/htc/fusion/fx/FxTimelineControl;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_aa

    .line 210
    :cond_268
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimeLineGear05:Lcom/htc/fusion/fx/FxTimelineControl;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_b5

    .line 217
    :cond_273
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimelineWiggle:Lcom/htc/fusion/fx/FxTimelineControl;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_c0

    .line 224
    :cond_27e
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextHour:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_cb

    .line 231
    :cond_289
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextMinute:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_d6

    .line 238
    :cond_294
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextSecond:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_e1

    .line 246
    :cond_29f
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxClockBase:Lcom/htc/fusion/fx/FxTimelineControl;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_ec

    .line 254
    :cond_2aa
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxClockNumbers:Lcom/htc/fusion/fx/FxTimelineControl;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_f7

    .line 261
    :cond_2b5
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxClockDate:Lcom/htc/fusion/fx/FxTimelineControl;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_102

    .line 268
    :cond_2c0
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxClockHour:Lcom/htc/fusion/fx/FxTimelineControl;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_10d

    .line 275
    :cond_2cb
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxClockMinute:Lcom/htc/fusion/fx/FxTimelineControl;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_118

    .line 284
    :cond_2d6
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimelineClock:Lcom/htc/fusion/fx/FxTimelineControl;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_123

    .line 291
    :cond_2e1
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimelineAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_12e

    .line 298
    :cond_2ec
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimelineAmPmOpp:Lcom/htc/fusion/fx/FxTimelineControl;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_139

    .line 306
    :cond_2f7
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimelineClockAmPm:Lcom/htc/fusion/fx/FxTimelineControl;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_144

    .line 314
    :cond_302
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextDate:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_14f

    .line 321
    :cond_30d
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextLongDate:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_15a

    .line 328
    :cond_318
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextWeekDay:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_165

    .line 335
    :cond_323
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextAMPM:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_170

    .line 343
    :cond_32e
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextDate_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_17b

    .line 350
    :cond_339
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextWeekDay_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_186

    .line 357
    :cond_344
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextAMPM_night:Lcom/htc/fusion/fx/controls/FxTextLabel;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_191

    .line 364
    :cond_34f
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxDigitalHour:Lcom/htc/fusion/fx/FxTimelineControl;

    move v0, v1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    goto/16 :goto_19c

    .line 371
    :cond_35a
    add-int/lit8 v1, v0, 0x1

    .end local v0    # "index":I
    .restart local v1    # "index":I
    aget-object v3, p4, v0

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxDigitalMinute:Lcom/htc/fusion/fx/FxTimelineControl;

    goto/16 :goto_1a8

    .line 378
    :cond_364
    add-int/lit8 v0, v1, 0x1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    aget-object v3, p4, v1

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mTiltAnime:Lcom/htc/fusion/fx/FxTimelineControl;

    move v1, v0

    .end local v0    # "index":I
    .restart local v1    # "index":I
    goto/16 :goto_1af

    .line 384
    :cond_36f
    add-int/lit8 v0, v1, 0x1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    aget-object v3, p4, v1

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mHourCap:Lcom/htc/fusion/fx/FxTimelineControl;

    move v1, v0

    .end local v0    # "index":I
    .restart local v1    # "index":I
    goto/16 :goto_1b6

    .line 390
    :cond_37a
    add-int/lit8 v0, v1, 0x1

    .end local v1    # "index":I
    .restart local v0    # "index":I
    aget-object v3, p4, v1

    check-cast v3, Lcom/htc/fusion/fx/FxTimelineControl;

    iput-object v3, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mMinCap:Lcom/htc/fusion/fx/FxTimelineControl;

    goto/16 :goto_1be

    :cond_384
    move v1, v0

    .end local v0    # "index":I
    .restart local v1    # "index":I
    goto/16 :goto_1a8
.end method

.method private reset()V
    .registers 4

    .prologue
    const-string v2, ""

    .line 431
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mCityName:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_d

    .line 432
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mCityName:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const-string v1, ""

    invoke-virtual {v0, v2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 435
    :cond_d
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextDate:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_18

    .line 436
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextDate:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const-string v1, ""

    invoke-virtual {v0, v2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 439
    :cond_18
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextAMPM:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_23

    .line 440
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextAMPM:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const-string v1, ""

    invoke-virtual {v0, v2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 443
    :cond_23
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextLongDate:Lcom/htc/fusion/fx/controls/FxTextLabel;

    if-eqz v0, :cond_2e

    .line 444
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTextLongDate:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const-string v1, ""

    invoke-virtual {v0, v2}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 446
    :cond_2e
    return-void
.end method

.method private setupControls()V
    .registers 6

    .prologue
    const/16 v2, 0x19

    const/4 v1, 0x1

    const/4 v4, 0x0

    const-string v3, "tilt"

    .line 395
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxHitbox:Lcom/htc/fusion/fx/controls/FxHitbox;

    if-eqz v0, :cond_14

    .line 396
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxHitbox:Lcom/htc/fusion/fx/controls/FxHitbox;

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/controls/FxHitbox;->setEnabled(Z)V

    .line 397
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxHitbox:Lcom/htc/fusion/fx/controls/FxHitbox;

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/controls/FxHitbox;->setEnabledGestures(I)V

    .line 400
    :cond_14
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimelineClock:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_1d

    .line 401
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxTimelineClock:Lcom/htc/fusion/fx/FxTimelineControl;

    invoke-virtual {v0, v2, v2}, Lcom/htc/fusion/fx/FxTimelineControl;->playFrames(II)V

    .line 404
    :cond_1d
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxDigitalHour:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_31

    .line 405
    new-instance v0, Lcom/htc/clock3dwidget/util/DigitControl;

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxDigitalHour:Lcom/htc/fusion/fx/FxTimelineControl;

    const/16 v2, 0x18

    invoke-direct {v0, v1, v2}, Lcom/htc/clock3dwidget/util/DigitControl;-><init>(Lcom/htc/fusion/fx/FxTimelineControl;I)V

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    .line 406
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    invoke-virtual {v0, v4}, Lcom/htc/clock3dwidget/util/DigitControl;->setCurrentNumber(I)V

    .line 408
    :cond_31
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxDigitalMinute:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_4b

    .line 409
    new-instance v0, Lcom/htc/clock3dwidget/util/DigitControl;

    iget-object v1, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mFxDigitalMinute:Lcom/htc/fusion/fx/FxTimelineControl;

    const/16 v2, 0x3c

    invoke-direct {v0, v1, v2}, Lcom/htc/clock3dwidget/util/DigitControl;-><init>(Lcom/htc/fusion/fx/FxTimelineControl;I)V

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    .line 410
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Lcom/htc/clock3dwidget/util/DigitControl;->setAmPm(I)V

    .line 411
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    invoke-virtual {v0, v4}, Lcom/htc/clock3dwidget/util/DigitControl;->setCurrentNumber(I)V

    .line 415
    :cond_4b
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mTiltAnime:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_59

    .line 416
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mTiltAnime:Lcom/htc/fusion/fx/FxTimelineControl;

    const-string v1, "tilt"

    invoke-virtual {v0, v3}, Lcom/htc/fusion/fx/FxTimelineControl;->getMarker(Ljava/lang/String;)Lcom/htc/fusion/fx/Marker;

    move-result-object v0

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mTileMark:Lcom/htc/fusion/fx/Marker;

    .line 420
    :cond_59
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mHourCap:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_67

    .line 421
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mHourCap:Lcom/htc/fusion/fx/FxTimelineControl;

    const-string v1, "tilt"

    invoke-virtual {v0, v3}, Lcom/htc/fusion/fx/FxTimelineControl;->getMarker(Ljava/lang/String;)Lcom/htc/fusion/fx/Marker;

    move-result-object v0

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mMarkerHour:Lcom/htc/fusion/fx/Marker;

    .line 425
    :cond_67
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mMinCap:Lcom/htc/fusion/fx/FxTimelineControl;

    if-eqz v0, :cond_75

    .line 426
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mMinCap:Lcom/htc/fusion/fx/FxTimelineControl;

    const-string v1, "tilt"

    invoke-virtual {v0, v3}, Lcom/htc/fusion/fx/FxTimelineControl;->getMarker(Ljava/lang/String;)Lcom/htc/fusion/fx/Marker;

    move-result-object v0

    iput-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mMarkerMin:Lcom/htc/fusion/fx/Marker;

    .line 428
    :cond_75
    return-void
.end method


# virtual methods
.method public bind()V
    .registers 2

    .prologue
    .line 449
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_9

    .line 450
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/util/DigitControl;->bind()V

    .line 452
    :cond_9
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_12

    .line 453
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/util/DigitControl;->bind()V

    .line 455
    :cond_12
    return-void
.end method

.method public unbind()V
    .registers 2

    .prologue
    .line 458
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_9

    .line 459
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Hour:Lcom/htc/clock3dwidget/util/DigitControl;

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/util/DigitControl;->unbind()V

    .line 461
    :cond_9
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    if-eqz v0, :cond_12

    .line 462
    iget-object v0, p0, Lcom/htc/clock3dwidget/analogclock/FxAnalogControls;->mDigital_Minute:Lcom/htc/clock3dwidget/util/DigitControl;

    invoke-virtual {v0}, Lcom/htc/clock3dwidget/util/DigitControl;->unbind()V

    .line 464
    :cond_12
    return-void
.end method
