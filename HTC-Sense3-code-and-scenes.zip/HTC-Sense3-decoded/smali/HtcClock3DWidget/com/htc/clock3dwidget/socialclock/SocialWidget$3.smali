.class Lcom/htc/clock3dwidget/socialclock/SocialWidget$3;
.super Ljava/lang/Object;
.source "SocialWidget.java"

# interfaces
.implements Landroid/os/Handler$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock3dwidget/socialclock/SocialWidget;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;


# direct methods
.method constructor <init>(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)V
    .registers 2

    .prologue
    .line 213
    iput-object p1, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$3;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)Z
    .registers 6
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    const/4 v3, 0x0

    .line 215
    iget-object v1, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$3;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    invoke-virtual {v1}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->isWidgetDestroy()Z

    move-result v1

    if-eqz v1, :cond_23

    .line 216
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "SocialNetworkWidget handleMessage~ widget destroied msg.what:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget v2, p1, Landroid/os/Message;->what:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    move v1, v3

    .line 232
    :goto_22
    return v1

    .line 219
    :cond_23
    iget v1, p1, Landroid/os/Message;->what:I

    packed-switch v1, :pswitch_data_7c

    .line 232
    :cond_28
    :goto_28
    const/4 v1, 0x1

    goto :goto_22

    .line 221
    :pswitch_2a
    iget-object v1, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$3;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    invoke-static {v1}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$300(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)Lcom/htc/clock/util/social/SocialNetworkCtrl;

    move-result-object v1

    if-eqz v1, :cond_28

    iget-object v1, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$3;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    invoke-static {v1}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$300(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)Lcom/htc/clock/util/social/SocialNetworkCtrl;

    move-result-object v1

    invoke-virtual {v1}, Lcom/htc/clock/util/social/SocialNetworkCtrl;->getState()Lcom/htc/clock/util/social/SocialNetworkCtrl$State;

    move-result-object v1

    sget-object v2, Lcom/htc/clock/util/social/SocialNetworkCtrl$State;->START:Lcom/htc/clock/util/social/SocialNetworkCtrl$State;

    if-ne v1, v2, :cond_28

    iget-object v1, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$3;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    invoke-static {v1}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$200(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)Z

    move-result v1

    if-eqz v1, :cond_28

    .line 224
    iget-object v1, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$3;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    invoke-static {v1}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$300(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)Lcom/htc/clock/util/social/SocialNetworkCtrl;

    move-result-object v1

    invoke-virtual {v1}, Lcom/htc/clock/util/social/SocialNetworkCtrl;->getLastSocialData()Lcom/htc/clock/util/social/SocialData;

    move-result-object v0

    .line 225
    .local v0, "data":Lcom/htc/clock/util/social/SocialData;
    iget-object v1, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$3;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    invoke-static {v1, v0}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$802(Lcom/htc/clock3dwidget/socialclock/SocialWidget;Lcom/htc/clock/util/social/SocialData;)Lcom/htc/clock/util/social/SocialData;

    .line 226
    iget-object v1, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$3;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    iget-object v2, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$3;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    invoke-static {v2}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$300(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)Lcom/htc/clock/util/social/SocialNetworkCtrl;

    move-result-object v2

    invoke-virtual {v2}, Lcom/htc/clock/util/social/SocialNetworkCtrl;->isLoggedIn()Z

    move-result v2

    invoke-static {v1, v2}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$902(Lcom/htc/clock3dwidget/socialclock/SocialWidget;Z)Z

    .line 227
    iget-object v1, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$3;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    invoke-static {v1}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$1000(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)Lcom/htc/clock3dwidget/socialclock/SocialView;

    move-result-object v1

    iget-object v2, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$3;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    invoke-static {v2}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$900(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)Z

    move-result v2

    invoke-virtual {v1, v2, v0}, Lcom/htc/clock3dwidget/socialclock/SocialView;->updateUI(ZLcom/htc/clock/util/social/SocialData;)V

    .line 228
    iget-object v1, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$3;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    invoke-static {v1, v3}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$1102(Lcom/htc/clock3dwidget/socialclock/SocialWidget;Z)Z

    goto :goto_28

    .line 219
    nop

    :pswitch_data_7c
    .packed-switch 0x238d
        :pswitch_2a
    .end packed-switch
.end method
