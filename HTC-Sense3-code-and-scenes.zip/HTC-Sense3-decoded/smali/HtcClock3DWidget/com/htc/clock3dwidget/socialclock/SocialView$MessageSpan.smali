.class public Lcom/htc/clock3dwidget/socialclock/SocialView$MessageSpan;
.super Landroid/text/style/CharacterStyle;
.source "SocialView.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock3dwidget/socialclock/SocialView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "MessageSpan"
.end annotation


# instance fields
.field private mBold:Z

.field final synthetic this$0:Lcom/htc/clock3dwidget/socialclock/SocialView;


# direct methods
.method public constructor <init>(Lcom/htc/clock3dwidget/socialclock/SocialView;Z)V
    .registers 4
    .param p2, "bold"    # Z

    .prologue
    .line 59
    iput-object p1, p0, Lcom/htc/clock3dwidget/socialclock/SocialView$MessageSpan;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialView;

    .line 60
    invoke-direct {p0}, Landroid/text/style/CharacterStyle;-><init>()V

    .line 57
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/htc/clock3dwidget/socialclock/SocialView$MessageSpan;->mBold:Z

    .line 61
    iput-boolean p2, p0, Lcom/htc/clock3dwidget/socialclock/SocialView$MessageSpan;->mBold:Z

    .line 62
    return-void
.end method


# virtual methods
.method public updateDrawState(Landroid/text/TextPaint;)V
    .registers 3
    .param p1, "ds"    # Landroid/text/TextPaint;

    .prologue
    .line 66
    iget-boolean v0, p0, Lcom/htc/clock3dwidget/socialclock/SocialView$MessageSpan;->mBold:Z

    if-eqz v0, :cond_9

    .line 67
    sget-object v0, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    .line 69
    :cond_9
    return-void
.end method
