.class public Lcom/htc/clock3dwidget/socialclock/SocialView;
.super Ljava/lang/Object;
.source "SocialView.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/htc/clock3dwidget/socialclock/SocialView$SocialClickListener;,
        Lcom/htc/clock3dwidget/socialclock/SocialView$MessageSpan;
    }
.end annotation


# instance fields
.field private mApContext:Landroid/content/Context;

.field private mClickListener:Landroid/view/View$OnClickListener;

.field private mContentStringBuilder:Landroid/text/SpannableStringBuilder;

.field protected mFxHitboxSocial:Lcom/htc/fusion/fx/controls/FxHitbox;

.field private mIcon:Lcom/htc/fusion/fx/controls/FxDynamicImage;

.field private mImageSpanLike:Landroid/text/style/ImageSpan;

.field private mImageSpanReplay:Landroid/text/style/ImageSpan;

.field private mIndicator:Lcom/htc/fusion/fx/controls/FxDynamicImage;

.field private mInflatedCallback:Lcom/htc/clock/util/social/SocialData$InflatedCallback;

.field private mInfo:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field private mLoggedInTap:Ljava/lang/String;

.field private mMessage:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field private mReply:Lcom/htc/fusion/fx/controls/FxTextLabel;

.field private mResContext:Landroid/content/Context;

.field private mSocialClickLand:Lcom/htc/clock3dwidget/socialclock/SocialView$SocialClickListener;

.field private mSocialClickPort:Lcom/htc/clock3dwidget/socialclock/SocialView$SocialClickListener;

.field private mSocialEmpty:Ljava/lang/String;

.field private mTime:Lcom/htc/fusion/fx/controls/FxTextLabel;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/content/Context;Landroid/view/View;)V
    .registers 9
    .param p1, "apContext"    # Landroid/content/Context;
    .param p2, "resContext"    # Landroid/content/Context;
    .param p3, "parent"    # Landroid/view/View;

    .prologue
    const/4 v3, 0x0

    const/4 v4, 0x0

    .line 97
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 44
    new-instance v2, Lcom/htc/clock3dwidget/socialclock/SocialView$SocialClickListener;

    invoke-direct {v2, p0, v3}, Lcom/htc/clock3dwidget/socialclock/SocialView$SocialClickListener;-><init>(Lcom/htc/clock3dwidget/socialclock/SocialView;Lcom/htc/clock3dwidget/socialclock/SocialView$1;)V

    iput-object v2, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mSocialClickPort:Lcom/htc/clock3dwidget/socialclock/SocialView$SocialClickListener;

    .line 45
    new-instance v2, Lcom/htc/clock3dwidget/socialclock/SocialView$SocialClickListener;

    invoke-direct {v2, p0, v3}, Lcom/htc/clock3dwidget/socialclock/SocialView$SocialClickListener;-><init>(Lcom/htc/clock3dwidget/socialclock/SocialView;Lcom/htc/clock3dwidget/socialclock/SocialView$1;)V

    iput-object v2, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mSocialClickLand:Lcom/htc/clock3dwidget/socialclock/SocialView$SocialClickListener;

    .line 54
    new-instance v2, Landroid/text/SpannableStringBuilder;

    invoke-direct {v2}, Landroid/text/SpannableStringBuilder;-><init>()V

    iput-object v2, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mContentStringBuilder:Landroid/text/SpannableStringBuilder;

    .line 281
    new-instance v2, Lcom/htc/clock3dwidget/socialclock/SocialView$1;

    invoke-direct {v2, p0}, Lcom/htc/clock3dwidget/socialclock/SocialView$1;-><init>(Lcom/htc/clock3dwidget/socialclock/SocialView;)V

    iput-object v2, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mInflatedCallback:Lcom/htc/clock/util/social/SocialData$InflatedCallback;

    .line 99
    iput-object p1, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mApContext:Landroid/content/Context;

    .line 100
    iput-object p2, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mResContext:Landroid/content/Context;

    .line 101
    iget-object v2, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mApContext:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const v3, 0x7f06001b

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mLoggedInTap:Ljava/lang/String;

    .line 102
    iget-object v2, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mApContext:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const v3, 0x7f06001c

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v2

    iput-object v2, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mSocialEmpty:Ljava/lang/String;

    .line 104
    iget-object v2, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mApContext:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const v3, 0x7f020001

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    .line 105
    .local v0, "dLike":Landroid/graphics/drawable/Drawable;
    invoke-virtual {v0, v4, v4, v4, v4}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 106
    new-instance v2, Landroid/text/style/ImageSpan;

    invoke-direct {v2, v0, v4}, Landroid/text/style/ImageSpan;-><init>(Landroid/graphics/drawable/Drawable;I)V

    iput-object v2, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mImageSpanLike:Landroid/text/style/ImageSpan;

    .line 108
    iget-object v2, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mApContext:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const v3, 0x7f020002

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    .line 109
    .local v1, "dReplay":Landroid/graphics/drawable/Drawable;
    invoke-virtual {v1, v4, v4, v4, v4}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 110
    new-instance v2, Landroid/text/style/ImageSpan;

    invoke-direct {v2, v1, v4}, Landroid/text/style/ImageSpan;-><init>(Landroid/graphics/drawable/Drawable;I)V

    iput-object v2, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mImageSpanReplay:Landroid/text/style/ImageSpan;

    .line 123
    return-void
.end method

.method static synthetic access$100(Lcom/htc/clock3dwidget/socialclock/SocialView;)Landroid/view/View$OnClickListener;
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/socialclock/SocialView;

    .prologue
    .line 27
    iget-object v0, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mClickListener:Landroid/view/View$OnClickListener;

    return-object v0
.end method

.method static synthetic access$200(Lcom/htc/clock3dwidget/socialclock/SocialView;Landroid/graphics/Bitmap;)V
    .registers 2
    .param p0, "x0"    # Lcom/htc/clock3dwidget/socialclock/SocialView;
    .param p1, "x1"    # Landroid/graphics/Bitmap;

    .prologue
    .line 27
    invoke-direct {p0, p1}, Lcom/htc/clock3dwidget/socialclock/SocialView;->updateIcon(Landroid/graphics/Bitmap;)V

    return-void
.end method

.method private formatStr(Lcom/htc/clock/util/social/SocialData;)Ljava/lang/CharSequence;
    .registers 11
    .param p1, "data"    # Lcom/htc/clock/util/social/SocialData;

    .prologue
    const/4 v8, 0x0

    .line 219
    invoke-virtual {p1}, Lcom/htc/clock/util/social/SocialData;->getName()Ljava/lang/String;

    move-result-object v3

    .line 220
    .local v3, "name":Ljava/lang/String;
    const/4 v2, 0x0

    .line 222
    .local v2, "message":Ljava/lang/String;
    invoke-virtual {p1}, Lcom/htc/clock/util/social/SocialData;->isFlicker()Z

    move-result v5

    if-eqz v5, :cond_49

    .line 223
    invoke-direct {p0, p1}, Lcom/htc/clock3dwidget/socialclock/SocialView;->getFlickrMessage(Lcom/htc/clock/util/social/SocialData;)Ljava/lang/String;

    move-result-object v2

    .line 227
    :goto_10
    new-instance v0, Landroid/text/SpannableStringBuilder;

    invoke-direct {v0}, Landroid/text/SpannableStringBuilder;-><init>()V

    .line 228
    .local v0, "builder":Landroid/text/SpannableStringBuilder;
    new-instance v4, Lcom/htc/clock3dwidget/socialclock/SocialView$MessageSpan;

    const/4 v5, 0x1

    invoke-direct {v4, p0, v5}, Lcom/htc/clock3dwidget/socialclock/SocialView$MessageSpan;-><init>(Lcom/htc/clock3dwidget/socialclock/SocialView;Z)V

    .line 229
    .local v4, "userSpan":Lcom/htc/clock3dwidget/socialclock/SocialView$MessageSpan;
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, " "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    move-result-object v5

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v6

    const/16 v7, 0x21

    invoke-virtual {v5, v4, v8, v6, v7}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    .line 231
    if-eqz v2, :cond_40

    .line 232
    invoke-virtual {v0, v2}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    .line 234
    :cond_40
    invoke-virtual {v0}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v5

    invoke-virtual {v0, v8, v5}, Landroid/text/SpannableStringBuilder;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object v1

    .line 235
    .local v1, "content":Ljava/lang/CharSequence;
    return-object v1

    .line 225
    .end local v0    # "builder":Landroid/text/SpannableStringBuilder;
    .end local v1    # "content":Ljava/lang/CharSequence;
    .end local v4    # "userSpan":Lcom/htc/clock3dwidget/socialclock/SocialView$MessageSpan;
    :cond_49
    invoke-virtual {p1}, Lcom/htc/clock/util/social/SocialData;->getMessage()Ljava/lang/String;

    move-result-object v2

    goto :goto_10
.end method

.method private getFlickrMessage(Lcom/htc/clock/util/social/SocialData;)Ljava/lang/String;
    .registers 14
    .param p1, "data"    # Lcom/htc/clock/util/social/SocialData;

    .prologue
    const/4 v10, 0x0

    const/4 v9, 0x1

    const-string v11, " "

    .line 239
    iget-object v4, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mApContext:Landroid/content/Context;

    invoke-virtual {p1, v4}, Lcom/htc/clock/util/social/SocialData;->getUploaded(Landroid/content/Context;)[I

    move-result-object v2

    .line 240
    .local v2, "uploaded":[I
    aget v1, v2, v10

    .line 241
    .local v1, "photos":I
    aget v3, v2, v9

    .line 242
    .local v3, "videos":I
    const-string v0, "\n"

    .line 243
    .local v0, "message":Ljava/lang/String;
    if-gtz v1, :cond_14

    if-lez v3, :cond_45

    .line 244
    :cond_14
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mApContext:Landroid/content/Context;

    invoke-virtual {v5}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f06001f

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 245
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " "

    invoke-virtual {v4, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 247
    :cond_45
    if-lez v1, :cond_6f

    .line 248
    if-ne v1, v9, :cond_e0

    .line 249
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mApContext:Landroid/content/Context;

    invoke-virtual {v5}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f060022

    new-array v7, v9, [Ljava/lang/Object;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v7, v10

    invoke-virtual {v5, v6, v7}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 254
    :cond_6f
    :goto_6f
    if-lez v3, :cond_df

    .line 255
    if-lez v1, :cond_b7

    .line 256
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " "

    invoke-virtual {v4, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 257
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mApContext:Landroid/content/Context;

    invoke-virtual {v5}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f060020

    invoke-virtual {v5, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 258
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v5, " "

    invoke-virtual {v4, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 260
    :cond_b7
    if-ne v3, v9, :cond_108

    .line 261
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mApContext:Landroid/content/Context;

    invoke-virtual {v5}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f060024

    new-array v7, v9, [Ljava/lang/Object;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v7, v10

    invoke-virtual {v5, v6, v7}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 266
    :cond_df
    :goto_df
    return-object v0

    .line 251
    :cond_e0
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mApContext:Landroid/content/Context;

    invoke-virtual {v5}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f060021

    new-array v7, v9, [Ljava/lang/Object;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v7, v10

    invoke-virtual {v5, v6, v7}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto/16 :goto_6f

    .line 263
    :cond_108
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    iget-object v5, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mApContext:Landroid/content/Context;

    invoke-virtual {v5}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const v6, 0x7f060023

    new-array v7, v9, [Ljava/lang/Object;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v7, v10

    invoke-virtual {v5, v6, v7}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_df
.end method

.method private showEmptyText(Ljava/lang/String;)V
    .registers 4
    .param p1, "text"    # Ljava/lang/String;

    .prologue
    const/4 v1, 0x0

    .line 209
    iget-object v0, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mIcon:Lcom/htc/fusion/fx/controls/FxDynamicImage;

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/controls/FxDynamicImage;->setVisibility(Z)Ljava/util/ArrayList;

    .line 210
    iget-object v0, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mMessage:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setVisibility(Z)Ljava/util/ArrayList;

    .line 211
    iget-object v0, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mReply:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setVisibility(Z)Ljava/util/ArrayList;

    .line 212
    iget-object v0, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mTime:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setVisibility(Z)Ljava/util/ArrayList;

    .line 213
    iget-object v0, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mIndicator:Lcom/htc/fusion/fx/controls/FxDynamicImage;

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/controls/FxDynamicImage;->setVisibility(Z)Ljava/util/ArrayList;

    .line 214
    iget-object v0, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mInfo:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v0, p1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 215
    iget-object v0, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mInfo:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setVisibility(Z)Ljava/util/ArrayList;

    .line 216
    return-void
.end method

.method private updateIcon(Landroid/graphics/Bitmap;)V
    .registers 5
    .param p1, "icon"    # Landroid/graphics/Bitmap;

    .prologue
    .line 198
    invoke-static {p1}, Lcom/htc/graphics/drawable/UrlDrawable;->isValidBitmap(Landroid/graphics/Bitmap;)Z

    move-result v1

    if-nez v1, :cond_1f

    .line 199
    iget-object v1, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mResContext:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const v2, 0x20800c2

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    check-cast v0, Landroid/graphics/drawable/BitmapDrawable;

    .line 201
    .local v0, "defaultIcon":Landroid/graphics/drawable/BitmapDrawable;
    iget-object v1, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mIcon:Lcom/htc/fusion/fx/controls/FxDynamicImage;

    invoke-virtual {v0}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/htc/fusion/fx/controls/FxDynamicImage;->setImage(Landroid/graphics/Bitmap;)V

    .line 206
    .end local v0    # "defaultIcon":Landroid/graphics/drawable/BitmapDrawable;
    :goto_1e
    return-void

    .line 204
    :cond_1f
    iget-object v1, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mIcon:Lcom/htc/fusion/fx/controls/FxDynamicImage;

    invoke-virtual {v1, p1}, Lcom/htc/fusion/fx/controls/FxDynamicImage;->setImage(Landroid/graphics/Bitmap;)V

    goto :goto_1e
.end method


# virtual methods
.method public bind(Lcom/htc/clock3dwidget/socialclock/FxSocialControls;Lcom/htc/clock3dwidget/socialclock/FxSocialControls;)V
    .registers 5
    .param p1, "controlsPort"    # Lcom/htc/clock3dwidget/socialclock/FxSocialControls;
    .param p2, "controlsLand"    # Lcom/htc/clock3dwidget/socialclock/FxSocialControls;

    .prologue
    .line 84
    iget-object v0, p1, Lcom/htc/clock3dwidget/socialclock/FxSocialControls;->mFxHitboxSocial:Lcom/htc/fusion/fx/controls/FxHitbox;

    invoke-virtual {v0}, Lcom/htc/fusion/fx/controls/FxHitbox;->getTapSource()Lcom/htc/fusion/fx/IMessageSource;

    move-result-object v0

    iget-object v1, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mSocialClickPort:Lcom/htc/clock3dwidget/socialclock/SocialView$SocialClickListener;

    invoke-interface {v0, v1}, Lcom/htc/fusion/fx/IMessageSource;->bind(Lcom/htc/fusion/fx/IMessageListener;)V

    .line 85
    invoke-virtual {p1, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1c

    .line 86
    iget-object v0, p2, Lcom/htc/clock3dwidget/socialclock/FxSocialControls;->mFxHitboxSocial:Lcom/htc/fusion/fx/controls/FxHitbox;

    invoke-virtual {v0}, Lcom/htc/fusion/fx/controls/FxHitbox;->getTapSource()Lcom/htc/fusion/fx/IMessageSource;

    move-result-object v0

    iget-object v1, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mSocialClickLand:Lcom/htc/clock3dwidget/socialclock/SocialView$SocialClickListener;

    invoke-interface {v0, v1}, Lcom/htc/fusion/fx/IMessageSource;->bind(Lcom/htc/fusion/fx/IMessageListener;)V

    .line 88
    :cond_1c
    return-void
.end method

.method public init(Lcom/htc/clock3dwidget/socialclock/FxSocialControls;)V
    .registers 3
    .param p1, "controls"    # Lcom/htc/clock3dwidget/socialclock/FxSocialControls;

    .prologue
    .line 73
    iget-object v0, p1, Lcom/htc/clock3dwidget/socialclock/FxSocialControls;->mMessage:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v0, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mMessage:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 74
    iget-object v0, p1, Lcom/htc/clock3dwidget/socialclock/FxSocialControls;->mTime:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v0, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mTime:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 75
    iget-object v0, p1, Lcom/htc/clock3dwidget/socialclock/FxSocialControls;->mReply:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v0, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mReply:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 76
    iget-object v0, p1, Lcom/htc/clock3dwidget/socialclock/FxSocialControls;->mIcon:Lcom/htc/fusion/fx/controls/FxDynamicImage;

    iput-object v0, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mIcon:Lcom/htc/fusion/fx/controls/FxDynamicImage;

    .line 77
    iget-object v0, p1, Lcom/htc/clock3dwidget/socialclock/FxSocialControls;->mIndicator:Lcom/htc/fusion/fx/controls/FxDynamicImage;

    iput-object v0, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mIndicator:Lcom/htc/fusion/fx/controls/FxDynamicImage;

    .line 79
    iget-object v0, p1, Lcom/htc/clock3dwidget/socialclock/FxSocialControls;->mFxHitboxSocial:Lcom/htc/fusion/fx/controls/FxHitbox;

    iput-object v0, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mFxHitboxSocial:Lcom/htc/fusion/fx/controls/FxHitbox;

    .line 80
    iget-object v0, p1, Lcom/htc/clock3dwidget/socialclock/FxSocialControls;->mInfo:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iput-object v0, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mInfo:Lcom/htc/fusion/fx/controls/FxTextLabel;

    .line 81
    return-void
.end method

.method public setOnClickListener(Landroid/view/View$OnClickListener;)V
    .registers 2
    .param p1, "l"    # Landroid/view/View$OnClickListener;

    .prologue
    .line 278
    iput-object p1, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mClickListener:Landroid/view/View$OnClickListener;

    .line 279
    return-void
.end method

.method public unbind(Lcom/htc/clock3dwidget/socialclock/FxSocialControls;Lcom/htc/clock3dwidget/socialclock/FxSocialControls;)V
    .registers 5
    .param p1, "controlsPort"    # Lcom/htc/clock3dwidget/socialclock/FxSocialControls;
    .param p2, "controlsLand"    # Lcom/htc/clock3dwidget/socialclock/FxSocialControls;

    .prologue
    .line 91
    iget-object v0, p1, Lcom/htc/clock3dwidget/socialclock/FxSocialControls;->mFxHitboxSocial:Lcom/htc/fusion/fx/controls/FxHitbox;

    invoke-virtual {v0}, Lcom/htc/fusion/fx/controls/FxHitbox;->getTapSource()Lcom/htc/fusion/fx/IMessageSource;

    move-result-object v0

    iget-object v1, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mSocialClickPort:Lcom/htc/clock3dwidget/socialclock/SocialView$SocialClickListener;

    invoke-interface {v0, v1}, Lcom/htc/fusion/fx/IMessageSource;->unbind(Lcom/htc/fusion/fx/IMessageListener;)V

    .line 92
    invoke-virtual {p1, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1c

    .line 93
    iget-object v0, p2, Lcom/htc/clock3dwidget/socialclock/FxSocialControls;->mFxHitboxSocial:Lcom/htc/fusion/fx/controls/FxHitbox;

    invoke-virtual {v0}, Lcom/htc/fusion/fx/controls/FxHitbox;->getTapSource()Lcom/htc/fusion/fx/IMessageSource;

    move-result-object v0

    iget-object v1, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mSocialClickLand:Lcom/htc/clock3dwidget/socialclock/SocialView$SocialClickListener;

    invoke-interface {v0, v1}, Lcom/htc/fusion/fx/IMessageSource;->unbind(Lcom/htc/fusion/fx/IMessageListener;)V

    .line 95
    :cond_1c
    return-void
.end method

.method public updateUI(ZLcom/htc/clock/util/social/SocialData;)V
    .registers 15
    .param p1, "isLoggedIn"    # Z
    .param p2, "data"    # Lcom/htc/clock/util/social/SocialData;

    .prologue
    .line 126
    if-nez p1, :cond_d

    .line 127
    const-string v7, "SocialNetworkView~ updateUI not login"

    invoke-static {v7}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 129
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mLoggedInTap:Ljava/lang/String;

    invoke-direct {p0, v7}, Lcom/htc/clock3dwidget/socialclock/SocialView;->showEmptyText(Ljava/lang/String;)V

    .line 195
    :goto_c
    return-void

    .line 130
    :cond_d
    if-eqz p2, :cond_135

    .line 131
    const-string v7, "SocialNetworkView~ updateUI normal"

    invoke-static {v7}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 134
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mInfo:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const/4 v8, 0x0

    invoke-virtual {v7, v8}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setVisibility(Z)Ljava/util/ArrayList;

    .line 135
    invoke-direct {p0, p2}, Lcom/htc/clock3dwidget/socialclock/SocialView;->formatStr(Lcom/htc/clock/util/social/SocialData;)Ljava/lang/CharSequence;

    move-result-object v2

    .line 136
    .local v2, "content":Ljava/lang/CharSequence;
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mMessage:Lcom/htc/fusion/fx/controls/FxTextLabel;

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 138
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mMessage:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const/4 v8, 0x1

    invoke-virtual {v7, v8}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setVisibility(Z)Ljava/util/ArrayList;

    .line 140
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mResContext:Landroid/content/Context;

    invoke-virtual {p2, v7}, Lcom/htc/clock/util/social/SocialData;->getIcon(Landroid/content/Context;)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    check-cast v6, Lcom/htc/clock/util/social/SocialData$RemoteUrlDrawable;

    .line 141
    .local v6, "remoteIcon":Lcom/htc/clock/util/social/SocialData$RemoteUrlDrawable;
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mInflatedCallback:Lcom/htc/clock/util/social/SocialData$InflatedCallback;

    invoke-virtual {v6, v7}, Lcom/htc/clock/util/social/SocialData$RemoteUrlDrawable;->setInflatedCallback(Lcom/htc/clock/util/social/SocialData$InflatedCallback;)V

    .line 142
    invoke-virtual {v6}, Lcom/htc/clock/util/social/SocialData$RemoteUrlDrawable;->getBitmap()Landroid/graphics/Bitmap;

    move-result-object v7

    invoke-direct {p0, v7}, Lcom/htc/clock3dwidget/socialclock/SocialView;->updateIcon(Landroid/graphics/Bitmap;)V

    .line 143
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mIcon:Lcom/htc/fusion/fx/controls/FxDynamicImage;

    const/4 v8, 0x1

    invoke-virtual {v7, v8}, Lcom/htc/fusion/fx/controls/FxDynamicImage;->setVisibility(Z)Ljava/util/ArrayList;

    .line 146
    const/4 v3, 0x0

    .line 147
    .local v3, "indicator":Landroid/graphics/Bitmap;
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mApContext:Landroid/content/Context;

    invoke-virtual {p2, v7}, Lcom/htc/clock/util/social/SocialData;->getIconIndicator(Landroid/content/Context;)Landroid/graphics/Bitmap;

    move-result-object v3

    .line 148
    if-eqz v3, :cond_125

    .line 149
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mIndicator:Lcom/htc/fusion/fx/controls/FxDynamicImage;

    invoke-virtual {v7, v3}, Lcom/htc/fusion/fx/controls/FxDynamicImage;->setImage(Landroid/graphics/Bitmap;)V

    .line 150
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mIndicator:Lcom/htc/fusion/fx/controls/FxDynamicImage;

    const/4 v8, 0x1

    invoke-virtual {v7, v8}, Lcom/htc/fusion/fx/controls/FxDynamicImage;->setVisibility(Z)Ljava/util/ArrayList;

    .line 156
    :goto_5b
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mTime:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iget-object v8, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mApContext:Landroid/content/Context;

    invoke-virtual {p2, v8}, Lcom/htc/clock/util/social/SocialData;->getPastTimeString(Landroid/content/Context;)Ljava/lang/CharSequence;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setString(Ljava/lang/String;)V

    .line 157
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mTime:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const/4 v8, 0x1

    invoke-virtual {v7, v8}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setVisibility(Z)Ljava/util/ArrayList;

    .line 159
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mContentStringBuilder:Landroid/text/SpannableStringBuilder;

    invoke-virtual {v7}, Landroid/text/SpannableStringBuilder;->clear()V

    .line 161
    invoke-virtual {p2}, Lcom/htc/clock/util/social/SocialData;->getLikeCnt()I

    move-result v7

    int-to-long v4, v7

    .line 162
    .local v4, "like":J
    invoke-virtual {p2}, Lcom/htc/clock/util/social/SocialData;->getCommentCnt()I

    move-result v7

    int-to-long v0, v7

    .line 165
    .local v0, "comment":J
    const-wide/16 v7, 0x0

    cmp-long v7, v4, v7

    if-lez v7, :cond_cb

    .line 166
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mContentStringBuilder:Landroid/text/SpannableStringBuilder;

    const-string v8, " "

    invoke-virtual {v7, v8}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    move-result-object v7

    iget-object v8, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mImageSpanLike:Landroid/text/style/ImageSpan;

    iget-object v9, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mContentStringBuilder:Landroid/text/SpannableStringBuilder;

    invoke-virtual {v9}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v9

    const/4 v10, 0x1

    sub-int/2addr v9, v10

    iget-object v10, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mContentStringBuilder:Landroid/text/SpannableStringBuilder;

    invoke-virtual {v10}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v10

    const/16 v11, 0x21

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    .line 170
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mContentStringBuilder:Landroid/text/SpannableStringBuilder;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, " "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-static {v4, v5}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    .line 171
    const-wide/16 v7, 0x0

    cmp-long v7, v0, v7

    if-lez v7, :cond_cb

    .line 172
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mContentStringBuilder:Landroid/text/SpannableStringBuilder;

    const-string v8, " "

    invoke-virtual {v7, v8}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    .line 176
    :cond_cb
    const-wide/16 v7, 0x0

    cmp-long v7, v0, v7

    if-lez v7, :cond_10a

    .line 177
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mContentStringBuilder:Landroid/text/SpannableStringBuilder;

    const-string v8, " "

    invoke-virtual {v7, v8}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    move-result-object v7

    iget-object v8, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mImageSpanReplay:Landroid/text/style/ImageSpan;

    iget-object v9, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mContentStringBuilder:Landroid/text/SpannableStringBuilder;

    invoke-virtual {v9}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v9

    const/4 v10, 0x1

    sub-int/2addr v9, v10

    iget-object v10, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mContentStringBuilder:Landroid/text/SpannableStringBuilder;

    invoke-virtual {v10}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v10

    const/16 v11, 0x21

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    .line 181
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mContentStringBuilder:Landroid/text/SpannableStringBuilder;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, " "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-static {v0, v1}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    .line 184
    :cond_10a
    const-wide/16 v7, 0x0

    cmp-long v7, v4, v7

    if-gtz v7, :cond_116

    const-wide/16 v7, 0x0

    cmp-long v7, v0, v7

    if-lez v7, :cond_12d

    .line 185
    :cond_116
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mReply:Lcom/htc/fusion/fx/controls/FxTextLabel;

    iget-object v8, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mContentStringBuilder:Landroid/text/SpannableStringBuilder;

    invoke-virtual {v7, v8}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setContent(Ljava/lang/CharSequence;)V

    .line 186
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mReply:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const/4 v8, 0x1

    invoke-virtual {v7, v8}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setVisibility(Z)Ljava/util/ArrayList;

    goto/16 :goto_c

    .line 152
    .end local v0    # "comment":J
    .end local v4    # "like":J
    :cond_125
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mIndicator:Lcom/htc/fusion/fx/controls/FxDynamicImage;

    const/4 v8, 0x0

    invoke-virtual {v7, v8}, Lcom/htc/fusion/fx/controls/FxDynamicImage;->setVisibility(Z)Ljava/util/ArrayList;

    goto/16 :goto_5b

    .line 188
    .restart local v0    # "comment":J
    .restart local v4    # "like":J
    :cond_12d
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mReply:Lcom/htc/fusion/fx/controls/FxTextLabel;

    const/4 v8, 0x0

    invoke-virtual {v7, v8}, Lcom/htc/fusion/fx/controls/FxTextLabel;->setVisibility(Z)Ljava/util/ArrayList;

    goto/16 :goto_c

    .line 192
    .end local v0    # "comment":J
    .end local v2    # "content":Ljava/lang/CharSequence;
    .end local v3    # "indicator":Landroid/graphics/Bitmap;
    .end local v4    # "like":J
    .end local v6    # "remoteIcon":Lcom/htc/clock/util/social/SocialData$RemoteUrlDrawable;
    :cond_135
    const-string v7, "SocialNetworkView~ updateUI no data"

    invoke-static {v7}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 193
    iget-object v7, p0, Lcom/htc/clock3dwidget/socialclock/SocialView;->mSocialEmpty:Ljava/lang/String;

    invoke-direct {p0, v7}, Lcom/htc/clock3dwidget/socialclock/SocialView;->showEmptyText(Ljava/lang/String;)V

    goto/16 :goto_c
.end method
