.class Lcom/htc/clock3dwidget/socialclock/SocialWidget$4;
.super Ljava/lang/Object;
.source "SocialWidget.java"

# interfaces
.implements Lcom/htc/clock/util/social/SocialNetworkCtrl$OnUpdateListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock3dwidget/socialclock/SocialWidget;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;


# direct methods
.method constructor <init>(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)V
    .registers 2

    .prologue
    .line 286
    iput-object p1, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$4;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onUpdate(Lcom/htc/clock/util/social/SocialData;)V
    .registers 5
    .param p1, "data"    # Lcom/htc/clock/util/social/SocialData;

    .prologue
    .line 289
    iget-object v1, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$4;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    invoke-static {v1}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$200(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)Z

    move-result v1

    if-eqz v1, :cond_21

    .line 290
    iget-object v1, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$4;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    invoke-static {v1}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$300(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)Lcom/htc/clock/util/social/SocialNetworkCtrl;

    move-result-object v1

    invoke-virtual {v1}, Lcom/htc/clock/util/social/SocialNetworkCtrl;->isLoggedIn()Z

    move-result v0

    .line 291
    .local v0, "isLoggedIn":Z
    iget-object v1, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$4;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    invoke-static {v1, p1}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$802(Lcom/htc/clock3dwidget/socialclock/SocialWidget;Lcom/htc/clock/util/social/SocialData;)Lcom/htc/clock/util/social/SocialData;

    .line 292
    iget-object v1, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$4;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    invoke-static {v1}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$1000(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)Lcom/htc/clock3dwidget/socialclock/SocialView;

    move-result-object v1

    invoke-virtual {v1, v0, p1}, Lcom/htc/clock3dwidget/socialclock/SocialView;->updateUI(ZLcom/htc/clock/util/social/SocialData;)V

    .line 297
    .end local v0    # "isLoggedIn":Z
    :goto_20
    return-void

    .line 295
    :cond_21
    iget-object v1, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$4;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    const/4 v2, 0x1

    invoke-static {v1, v2}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$1102(Lcom/htc/clock3dwidget/socialclock/SocialWidget;Z)Z

    goto :goto_20
.end method
