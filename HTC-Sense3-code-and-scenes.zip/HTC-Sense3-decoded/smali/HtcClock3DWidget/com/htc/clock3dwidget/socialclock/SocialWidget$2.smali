.class Lcom/htc/clock3dwidget/socialclock/SocialWidget$2;
.super Ljava/lang/Object;
.source "SocialWidget.java"

# interfaces
.implements Landroid/os/Handler$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock3dwidget/socialclock/SocialWidget;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;


# direct methods
.method constructor <init>(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)V
    .registers 2

    .prologue
    .line 159
    iput-object p1, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$2;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)Z
    .registers 10
    .param p1, "msg"    # Landroid/os/Message;

    .prologue
    const/4 v5, 0x0

    const/4 v7, 0x1

    .line 161
    iget-object v3, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$2;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    invoke-virtual {v3}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->isWidgetDestroy()Z

    move-result v3

    if-eqz v3, :cond_24

    .line 162
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "SocialNetworkWidget handleMessage~ widget destroied msg.what:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget v4, p1, Landroid/os/Message;->what:I

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/htc/clock/util/MyLog;->e(Ljava/lang/String;)V

    move v3, v5

    .line 210
    :goto_23
    return v3

    .line 165
    :cond_24
    iget v3, p1, Landroid/os/Message;->what:I

    sparse-switch v3, :sswitch_data_d4

    :goto_29
    :sswitch_29
    move v3, v7

    .line 210
    goto :goto_23

    .line 168
    :sswitch_2b
    iget-object v3, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$2;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    # getter for: Lcom/htc/clock3dwidget/socialclock/SocialWidget;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;
    invoke-static {v3}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$100(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    move-result-object v3

    const v4, 0x8019

    invoke-interface {v3, v4}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->recall(I)V

    .line 169
    iget v2, p1, Landroid/os/Message;->arg1:I

    .line 170
    .local v2, "notifyCause":I
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "SocialNetworkWidget WHAT_ON_RESUME~ notifyCause:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/htc/clock/util/MyLog;->d(Ljava/lang/String;)V

    .line 172
    iget-object v3, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$2;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    # setter for: Lcom/htc/clock3dwidget/socialclock/SocialWidget;->mResume:Z
    invoke-static {v3, v7}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$202(Lcom/htc/clock3dwidget/socialclock/SocialWidget;Z)Z

    .line 173
    const/16 v0, 0x1f4

    .line 174
    .local v0, "delay":I
    const/16 v3, 0x1e

    if-ne v2, v3, :cond_61

    .line 175
    const-string v3, "SocialNetworkWidget WHAT_ON_RESUME~ NOTIFY_CAUSE_ACTIVITY"

    invoke-static {v3}, Lcom/htc/clock/util/MyLog;->i(Ljava/lang/String;)V

    .line 176
    const/16 v0, 0x12c

    .line 178
    :cond_61
    iget-object v3, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$2;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    # getter for: Lcom/htc/clock3dwidget/socialclock/SocialWidget;->mHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;
    invoke-static {v3}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$000(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    move-result-object v3

    const/16 v4, 0x232a

    int-to-long v5, v0

    invoke-interface {v3, v4, v5, v6}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->sendDelayed(IJ)V

    goto :goto_29

    .line 181
    .end local v0    # "delay":I
    .end local v2    # "notifyCause":I
    :sswitch_6e
    const-string v3, "SocialNetworkWidget WHAT_ON_RESUME_DELAY"

    invoke-static {v3}, Lcom/htc/clock/util/MyLog;->d(Ljava/lang/String;)V

    .line 182
    iget-object v3, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$2;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    # setter for: Lcom/htc/clock3dwidget/socialclock/SocialWidget;->mResume:Z
    invoke-static {v3, v7}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$202(Lcom/htc/clock3dwidget/socialclock/SocialWidget;Z)Z

    .line 183
    iget-object v3, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$2;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    # getter for: Lcom/htc/clock3dwidget/socialclock/SocialWidget;->mCtrl:Lcom/htc/clock/util/social/SocialNetworkCtrl;
    invoke-static {v3}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$300(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)Lcom/htc/clock/util/social/SocialNetworkCtrl;

    move-result-object v3

    invoke-virtual {v3}, Lcom/htc/clock/util/social/SocialNetworkCtrl;->getState()Lcom/htc/clock/util/social/SocialNetworkCtrl$State;

    move-result-object v3

    sget-object v4, Lcom/htc/clock/util/social/SocialNetworkCtrl$State;->START:Lcom/htc/clock/util/social/SocialNetworkCtrl$State;

    if-eq v3, v4, :cond_a1

    .line 184
    new-instance v1, Landroid/os/Handler;

    invoke-direct {v1}, Landroid/os/Handler;-><init>()V

    .line 185
    .local v1, "handler":Landroid/os/Handler;
    iget-object v3, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$2;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    # getter for: Lcom/htc/clock3dwidget/socialclock/SocialWidget;->mCtrl:Lcom/htc/clock/util/social/SocialNetworkCtrl;
    invoke-static {v3}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$300(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)Lcom/htc/clock/util/social/SocialNetworkCtrl;

    move-result-object v3

    iget-object v4, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$2;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    # getter for: Lcom/htc/clock3dwidget/socialclock/SocialWidget;->mResContext:Landroid/content/Context;
    invoke-static {v4}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$400(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)Landroid/content/Context;

    move-result-object v4

    iget-object v5, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$2;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    # getter for: Lcom/htc/clock3dwidget/socialclock/SocialWidget;->mOnUpdateListener:Lcom/htc/clock/util/social/SocialNetworkCtrl$OnUpdateListener;
    invoke-static {v5}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$500(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)Lcom/htc/clock/util/social/SocialNetworkCtrl$OnUpdateListener;

    move-result-object v5

    invoke-virtual {v3, v4, v5, v1, v1}, Lcom/htc/clock/util/social/SocialNetworkCtrl;->init(Landroid/content/Context;Lcom/htc/clock/util/social/SocialNetworkCtrl$OnUpdateListener;Landroid/os/Handler;Landroid/os/Handler;)V

    goto :goto_29

    .line 188
    .end local v1    # "handler":Landroid/os/Handler;
    :cond_a1
    iget-object v3, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$2;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    # getter for: Lcom/htc/clock3dwidget/socialclock/SocialWidget;->mCtrl:Lcom/htc/clock/util/social/SocialNetworkCtrl;
    invoke-static {v3}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$300(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)Lcom/htc/clock/util/social/SocialNetworkCtrl;

    move-result-object v3

    invoke-virtual {v3}, Lcom/htc/clock/util/social/SocialNetworkCtrl;->updateIsLoggedIn()Z

    .line 191
    iget-object v3, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$2;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    # getter for: Lcom/htc/clock3dwidget/socialclock/SocialWidget;->mUiHandler:Lcom/htc/android/rosie/widget/Widget$Host$Worker;
    invoke-static {v3}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$100(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)Lcom/htc/android/rosie/widget/Widget$Host$Worker;

    move-result-object v3

    const/16 v4, 0x238d

    const-wide/16 v5, 0x0

    invoke-interface {v3, v4, v5, v6}, Lcom/htc/android/rosie/widget/Widget$Host$Worker;->sendDelayed(IJ)V

    goto/16 :goto_29

    .line 196
    :sswitch_b9
    const-string v3, "SocialNetworkWidget WHAT_ON_PAUSE"

    invoke-static {v3}, Lcom/htc/clock/util/MyLog;->d(Ljava/lang/String;)V

    .line 197
    iget-object v3, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$2;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    # setter for: Lcom/htc/clock3dwidget/socialclock/SocialWidget;->mResume:Z
    invoke-static {v3, v5}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$202(Lcom/htc/clock3dwidget/socialclock/SocialWidget;Z)Z

    goto/16 :goto_29

    .line 204
    :sswitch_c5
    iget-object v3, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$2;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    # invokes: Lcom/htc/clock3dwidget/socialclock/SocialWidget;->doConfigurationChanged()V
    invoke-static {v3}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$600(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)V

    goto/16 :goto_29

    .line 207
    :sswitch_cc
    iget-object v3, p0, Lcom/htc/clock3dwidget/socialclock/SocialWidget$2;->this$0:Lcom/htc/clock3dwidget/socialclock/SocialWidget;

    # invokes: Lcom/htc/clock3dwidget/socialclock/SocialWidget;->launchSocialAp()V
    invoke-static {v3}, Lcom/htc/clock3dwidget/socialclock/SocialWidget;->access$700(Lcom/htc/clock3dwidget/socialclock/SocialWidget;)V

    goto/16 :goto_29

    .line 165
    nop

    :sswitch_data_d4
    .sparse-switch
        0x1 -> :sswitch_2b
        0x2 -> :sswitch_b9
        0x2329 -> :sswitch_29
        0x232a -> :sswitch_6e
        0x9011 -> :sswitch_c5
        0x9012 -> :sswitch_cc
    .end sparse-switch
.end method
