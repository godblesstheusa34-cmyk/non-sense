.class public final Lcom/htc/clock3dwidget/R$id;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/htc/clock3dwidget/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final LL_list_cities:I = 0x7f090000

.field public static final command_bar:I = 0x7f090005

.field public static final list_cities:I = 0x7f090002

.field public static final setting_list:I = 0x7f090004

.field public static final title:I = 0x7f090001

.field public static final wwp_setting_layout:I = 0x7f090003


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 452
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
