package com.htc.widget3d.weather;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import com.htc.util.skin.HtcSkinUtil;
import com.htc.util.weather.WeatherLocation;
import com.htc.util.weather.WeatherUtility;
import com.htc.widget.HtcAdapterView;
import com.htc.widget.HtcListView;
import com.htc.widget.Title1;
import com.htc.widget3d.weather.data.CityInfo;
import com.htc.widget3d.weather.data.WeatherIntent;
import com.htc.widget3d.weather.data.WeatherModel;
import java.util.ArrayList;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcWeather3DWidget.dex */
public class OptionActivity extends Activity {
    private static final int DIALOG_WAIT = 1;
    private static final int MAX_CITY = 15;
    private static final int MSG_DATA_INIT_READY = 1;
    public static final String TAG = "WeatherWidget";
    private Activity mActivity;
    private ArrayAdapter<String> mAdapter;
    private TextView mAddCityText;
    private int mCityIndex;
    private CityInfo mCityInfo;
    private ArrayList<CityInfo> mCurrentCityList;
    private Handler mHandler;
    private ViewGroup mLayoutAddCity;
    private HtcListView mListView;
    private ArrayList<String> mStrings;
    private ProgressDialog mProgressDlg = null;
    private int mMaxCityCount = 15;
    private int mMaxCityCountFromSetting = 15;
    private int mMaxCityCountFromProvider = 0;
    private boolean bListInitialized = false;

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(1);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_city);
        showWaitCursor(true);
        int bgId = HtcSkinUtil.getDrawableResIdentifier(this, "common_app_bkg", 34080439);
        getWindow().setBackgroundDrawableResource(bgId);
        Title1 title = findViewById(R.id.title_block);
        if (title != null) {
            title.disablePulldownButton();
            title.setLeftTitle(R.string.select_city);
            title.setRightButtonImage2(34080485);
            ImageButton btnAdd = (ImageButton) title.findViewById(33686060);
            btnAdd.setOnClickListener(new AddButtonListener());
        }
        this.mListView = findViewById(R.id.list);
        this.mListView.setRoundedCornerEnabled(true);
        this.mActivity = this;
        this.mStrings = new ArrayList<>();
        this.mCurrentCityList = new ArrayList<>();
        this.mHandler = new UIHandler();
        this.bListInitialized = false;
        BuildCityList data_process = new BuildCityList();
        data_process.start();
    }

    public class UIHandler extends Handler {
        public UIHandler() {
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    OptionActivity.this.initListView();
                    OptionActivity.this.showWaitCursor(false);
                    break;
                default:
                    super.handleMessage(msg);
                    break;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void initListView() {
        this.bListInitialized = true;
        this.mAdapter = new ArrayAdapter<>(this.mActivity, R.layout.city_list_item, this.mStrings);
        if (this.mListView != null) {
            this.mListView.setAdapter(this.mAdapter);
            this.mListView.requestFocus();
            this.mListView.setOnItemClickListener(new HtcAdapterView.OnItemClickListener() { // from class: com.htc.widget3d.weather.OptionActivity.1
                public void onItemClick(HtcAdapterView parent, View v, int position, long id) {
                    OptionActivity.this.mCityIndex = (int) id;
                    if (id < 0) {
                        OptionActivity.this.mCityInfo = null;
                        if (position == 0) {
                        }
                    } else {
                        OptionActivity.this.mCityInfo = (CityInfo) OptionActivity.this.mCurrentCityList.get((int) id);
                        OptionActivity.this.backtoLauncher();
                    }
                }
            });
        }
    }

    public void showWaitCursor(boolean bShow) {
        if (bShow) {
            showDialog(1);
        } else if (this.mProgressDlg != null) {
            this.mProgressDlg.setCancelable(true);
            this.mProgressDlg.cancel();
            this.mProgressDlg.setCancelable(false);
        }
    }

    @Override // android.app.Activity
    protected Dialog onCreateDialog(int id) {
        if (id != 1) {
            return null;
        }
        if (this.mProgressDlg == null) {
            this.mProgressDlg = new ProgressDialog(this);
            this.mProgressDlg.setMessage(getResources().getString(R.string.wait_message));
            this.mProgressDlg.setIndeterminate(true);
            this.mProgressDlg.setCancelable(false);
        }
        return this.mProgressDlg;
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        if (this.bListInitialized) {
            BuildCityList data_process = new BuildCityList();
            data_process.start();
        }
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        if (this.mProgressDlg != null) {
            this.mProgressDlg.dismiss();
            this.mProgressDlg = null;
        }
        if (this.mLayoutAddCity != null) {
            this.mLayoutAddCity.setOnClickListener(null);
        }
        this.mStrings.clear();
        this.mCurrentCityList.clear();
        this.mHandler = null;
        super.onDestroy();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void launchAddCityActivity() {
        if (this.mCurrentCityList.size() >= this.mMaxCityCount) {
            Toast.makeText(getApplicationContext(), R.string.maximum_location_msg, 500).show();
            return;
        }
        Intent intent = new Intent(WeatherIntent.ACTION_INTENT_SEARCH);
        if (intent != null) {
            intent.setClassName(WeatherIntent.WEATHER_PACKAGENAME, WeatherIntent.ADDCITY_CLASSNAME);
            try {
                startActivityForResult(intent, WeatherIntent.REQUEST_ADD_LOCATION);
            } catch (ActivityNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    public class AddButtonListener implements View.OnClickListener {
        public AddButtonListener() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View v) {
            OptionActivity.this.launchAddCityActivity();
        }
    }

    public class ItemClickListener implements AdapterView.OnItemClickListener {
        public ItemClickListener() {
        }

        @Override // android.widget.AdapterView.OnItemClickListener
        public void onItemClick(AdapterView a, View v, int position, long id) {
            OptionActivity.this.mCityIndex = (int) id;
            if (id < 0) {
                OptionActivity.this.mCityInfo = null;
                if (position == 0) {
                    OptionActivity.this.launchAddCityActivity();
                    return;
                }
                return;
            }
            OptionActivity.this.mCityInfo = (CityInfo) OptionActivity.this.mCurrentCityList.get((int) id);
            OptionActivity.this.backtoLauncher();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void backtoLauncher() {
        if (this.mCityInfo != null && this.mCityInfo.getLocationInfo() != null) {
            WeatherLocation loc = this.mCityInfo.getLocationInfo();
            Intent intent = this.mActivity.getIntent();
            if (intent != null) {
                intent.putExtra(WeatherIntent.KEY_SELECT_CITY, Integer.toString(this.mCityIndex));
                intent.putExtra("name_", loc.getName());
                intent.putExtra("state_", loc.getState());
                intent.putExtra("country_", loc.getCountry());
                intent.putExtra("code_", loc.getCode());
                intent.putExtra("timezone_", loc.getTimezone());
                intent.putExtra("timezoneid_", loc.getTimezoneId());
                intent.putExtra("latitude_", loc.getLatitude());
                intent.putExtra("longitude_", loc.getLongitude());
                intent.putExtra("app_", loc.getApp());
                intent.putExtra("index_", this.mCityIndex);
                setResult(-1, intent);
                finish();
            }
        }
    }

    @Override // android.app.Activity
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (data != null) {
            switch (requestCode) {
                case WeatherIntent.REQUEST_ADD_LOCATION /* 4097 */:
                    if (resultCode == 1) {
                        if (data.getBooleanExtra("status", false)) {
                            Toast.makeText(this, R.string.city_duplicate, 500).show();
                            break;
                        } else {
                            this.bListInitialized = false;
                            BuildCityList data_process = new BuildCityList();
                            data_process.start();
                        }
                    } else if (resultCode == 2) {
                        WeatherLocation[] loc = {new WeatherLocation()};
                        loc[0].setLatitude(data.getStringExtra("latitude"));
                        loc[0].setLongitude(data.getStringExtra("longitude"));
                        loc[0].setName(data.getStringExtra("name"));
                        loc[0].setState(data.getStringExtra("state"));
                        loc[0].setCountry(data.getStringExtra("country"));
                        loc[0].setApp(WeatherIntent.WEATHER_PROVIDER_KEYNAME);
                        CityInfo info = new CityInfo();
                        info.setLocationInfo(loc[0]);
                        info.type_ = WeatherModel.QUERY_TYPE.GOOGLE_GEOCODE;
                        if (isCityViewExist(info.getDisplayName())) {
                            Toast.makeText(this, R.string.city_duplicate, 500).show();
                            break;
                        } else {
                            WeatherUtility.addLocation(getContentResolver(), WeatherIntent.WEATHER_PROVIDER_KEYNAME, loc);
                            this.bListInitialized = false;
                            BuildCityList data_process2 = new BuildCityList();
                            data_process2.start();
                        }
                    }
                    Intent intent = new Intent(WeatherIntent.ADD_LOCATION_CHANGED);
                    intent.putExtra(WeatherIntent.ADD_LOCATION_CHANGED, true);
                    sendBroadcast(intent);
                    break;
                default:
                    super.onActivityResult(requestCode, resultCode, data);
                    break;
            }
        }
    }

    private boolean isCityViewExist(String name) {
        if (name != null && this.mCurrentCityList != null) {
            int size = this.mCurrentCityList.size();
            for (int i = 0; i < size; i++) {
                if (name.equals(this.mCurrentCityList.get(i).getDisplayName())) {
                    return true;
                }
            }
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean prepareWeatherProvider() {
        String[] pkgname = {WeatherIntent.APP_LOCATION_SERVICE, WeatherIntent.WEATHER_PROVIDER_KEYNAME};
        WeatherLocation[] locs = WeatherUtility.loadMultiAppLocationsFilterByApp(getContentResolver(), pkgname);
        if (locs.length <= 0) {
            return false;
        }
        if (locs[0].getApp() != null && locs[0].getApp().equals(WeatherIntent.APP_LOCATION_SERVICE)) {
            this.mMaxCityCount = this.mMaxCityCountFromSetting + 1;
        } else {
            this.mMaxCityCount = this.mMaxCityCountFromSetting;
        }
        int size = locs.length;
        this.mMaxCityCountFromProvider = size;
        this.mCurrentCityList.clear();
        this.mStrings.clear();
        for (WeatherLocation loc : locs) {
            if (loc != null) {
                CityInfo cityinfo = new CityInfo();
                cityinfo.setLocationInfo(loc);
                if (loc.getApp() != null && loc.getApp().equals(WeatherIntent.APP_LOCATION_SERVICE)) {
                    this.mStrings.add(getString(R.string.current_location));
                } else if (loc.getState() == null || loc.getState().length() == 0) {
                    if (loc.getCountry() != null && loc.getCountry().length() > 0) {
                        this.mStrings.add(loc.getName() + ", " + loc.getCountry());
                    } else {
                        this.mStrings.add(cityinfo.getDisplayName());
                    }
                } else {
                    this.mStrings.add(cityinfo.getDisplayName());
                }
                if (loc.getCode() == null || loc.getCode().length() == 0) {
                    cityinfo.type_ = WeatherModel.QUERY_TYPE.GOOGLE_GEOCODE;
                } else {
                    cityinfo.type_ = WeatherModel.QUERY_TYPE.QUERY_CODE_ACCU_WEATHER;
                }
                this.mCurrentCityList.add(cityinfo);
            }
        }
        return true;
    }

    private final class BuildCityList extends Thread {
        private BuildCityList() {
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            OptionActivity.this.prepareWeatherProvider();
            if (OptionActivity.this.mHandler != null) {
                OptionActivity.this.mHandler.sendEmptyMessage(1);
            }
        }
    }
}
