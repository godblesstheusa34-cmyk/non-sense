package com.htc.widget3d.weather.data;

import android.os.Bundle;
import com.htc.util.weather.WSPPData;
import com.htc.widget3d.weather.data.City;
import com.htc.widget3d.weather.util.RefreshUtil;
import java.util.ArrayList;
import java.util.Date;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcWeather3DWidget.dex */
public class DCSResult {
    private Bundle bundle = null;
    private String checkCode;
    private String cityCode;
    private String country;
    private String currentCondition;
    private String currentIcon;
    private int currentTempCValue;
    private int currentTempFValue;
    private String currentTime;
    private String currentUvi;
    private String[] forecastCondition;
    private String[] forecastDate;
    private String[] forecastHighTempC;
    private String[] forecastHighTempF;
    private String[] forecastIcon;
    private String[] forecastLowTempC;
    private String[] forecastLowTempF;
    private String[] forecastName;
    private String[] forecastUvi;
    private String[] forecastWindDir;
    private String[] forecastWindSpeedkph;
    private String[] forecastWindSpeedmph;
    private String latitude;
    private String location;
    private String longitude;
    private int status;
    private int totalForecast;
    private long updateTime;

    public DCSResult(WSPPData data) {
        if (data != null) {
            this.status = 1;
            this.updateTime = data.getLastUpdate();
            this.checkCode = null;
            this.cityCode = data.getLocCode();
            this.latitude = data.getLatitude();
            this.longitude = data.getLongitude();
            this.location = String.valueOf(data.getType());
            this.country = "";
            this.currentTempFValue = data.getCurTempF();
            this.currentTempCValue = data.getCurTempC();
            this.currentIcon = data.getCurConditionId();
            this.currentCondition = data.getCurConditionId();
            this.totalForecast = 0;
            this.forecastDate = getStringFromArrayList(data.getFstDate());
            this.forecastName = getStringFromArrayList(data.getFstName());
            this.forecastIcon = getStringFromArrayList(data.getFstConditionId());
            this.forecastCondition = getStringFromArrayList(data.getFstConditionId());
            this.forecastHighTempF = getStringFromArrayList(data.getFstHighTempF());
            this.forecastLowTempF = getStringFromArrayList(data.getFstLowTempF());
            this.forecastHighTempC = getStringFromArrayList(data.getFstHighTempC());
            this.forecastLowTempC = getStringFromArrayList(data.getFstLowTempC());
            this.forecastUvi = null;
            if (this.forecastUvi == null || this.forecastUvi.length <= 0) {
                this.currentUvi = "1";
            } else {
                this.currentUvi = this.forecastUvi[0];
            }
            this.totalForecast = this.forecastDate.length;
        }
    }

    private String[] getStringFromArrayList(ArrayList<String> ary) {
        if (ary == null) {
            return null;
        }
        int num = ary.size();
        String[] s_ary = new String[num];
        return (String[]) ary.toArray(s_ary);
    }

    private int[] getIntFromArrayList(ArrayList<String> ary) {
        if (ary == null) {
            return null;
        }
        int num = ary.size();
        int[] i_ary = new int[num];
        for (int i = 0; i < num; i++) {
            i_ary[i] = RefreshUtil.safe_parseInt(ary.get(i));
        }
        return i_ary;
    }

    public final Bundle getBundle() {
        return this.bundle;
    }

    public int getStatus() {
        return this.status;
    }

    public long getUpdateTime() {
        return this.updateTime;
    }

    public String getCheckCode() {
        return this.checkCode;
    }

    public String getCityCode() {
        return this.cityCode;
    }

    public String getLatitude() {
        return this.latitude;
    }

    public String getLongitude() {
        return this.longitude;
    }

    public Date getUpdateTimeInDate() {
        return new Date(this.updateTime);
    }

    public String getLocation() {
        return this.location + ", " + this.country;
    }

    public int getCurrentTempF() {
        return this.currentTempFValue;
    }

    public int getCurrentTempC() {
        return this.currentTempCValue;
    }

    public int getCurrentTemp() {
        return WeatherModel.default_unit == City.UNIT._C ? this.currentTempCValue : this.currentTempFValue;
    }

    public String getCurrentIcon() {
        return this.currentIcon;
    }

    public String getCurrentCondition() {
        return this.currentCondition;
    }

    public String getCurrentTime() {
        return this.currentTime;
    }

    public String getCurrentUvi() {
        return this.currentUvi;
    }

    public int getTotalForecast() {
        return this.totalForecast;
    }

    public String[] getForecastDate() {
        return this.forecastDate;
    }

    public String[] getForecastName() {
        return this.forecastName;
    }

    public String[] getForecastIcon() {
        return this.forecastIcon;
    }

    public String[] getForecastCondition() {
        return this.forecastCondition;
    }

    public String[] getForecastHighTempF() {
        return this.forecastHighTempF;
    }

    public String[] getForecastHighTempC() {
        return this.forecastHighTempC;
    }

    public String[] getForecastHighTemp() {
        return WeatherModel.default_unit == City.UNIT._C ? this.forecastHighTempC : this.forecastHighTempF;
    }

    public String[] getForecastLowTempF() {
        return this.forecastLowTempF;
    }

    public String[] getForecastLowTempC() {
        return this.forecastLowTempC;
    }

    public String[] getForecastLowTemp() {
        return WeatherModel.default_unit == City.UNIT._C ? this.forecastLowTempC : this.forecastLowTempF;
    }

    public String[] getForecastUvi() {
        return this.forecastUvi;
    }

    public String getForecastDate(int day) {
        return getForecastDate()[day];
    }

    public String getForecastName(int day) {
        return getForecastName()[day];
    }

    public String getForecastIcon(int day) {
        return getForecastIcon()[day];
    }

    public String getForecastCondition(int day) {
        return getForecastCondition()[day];
    }

    public String getForecastHighTemp(int day) {
        return getForecastHighTemp()[day];
    }

    public String getForecastHighTempC(int day) {
        return getForecastHighTempC()[day];
    }

    public String getForecastLowTemp(int day) {
        return getForecastLowTemp()[day];
    }

    public String getForecastLowTempC(int day) {
        return getForecastLowTempC()[day];
    }

    public String getForecastUvi(int day) {
        return getForecastUvi()[day];
    }
}
