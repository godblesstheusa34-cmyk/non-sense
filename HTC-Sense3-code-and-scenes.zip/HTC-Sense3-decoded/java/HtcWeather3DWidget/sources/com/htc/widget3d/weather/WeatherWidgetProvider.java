package com.htc.widget3d.weather;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcWeather3DWidget.dex */
public class WeatherWidgetProvider extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context arg0, Intent arg1) {
    }
}
