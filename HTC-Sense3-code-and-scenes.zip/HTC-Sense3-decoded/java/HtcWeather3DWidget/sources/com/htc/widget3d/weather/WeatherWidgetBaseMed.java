package com.htc.widget3d.weather;

import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteFullException;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import com.htc.android.rosie.widget.Widget;
import com.htc.consts.WeatherConsts;
import com.htc.util.weather.WSPPData;
import com.htc.util.weather.WSPPUtility;
import com.htc.util.weather.WSPRequest;
import com.htc.util.weather.WeatherLocation;
import com.htc.util.weather.WeatherUtility;
import com.htc.widget3d.weather.data.City;
import com.htc.widget3d.weather.data.CityInfo;
import com.htc.widget3d.weather.data.DCSResult;
import com.htc.widget3d.weather.data.DayForecast;
import com.htc.widget3d.weather.data.WeatherIntent;
import com.htc.widget3d.weather.data.WeatherModel;
import com.htc.widget3d.weather.util.IconPicker;
import com.htc.widget3d.weather.util.LOG;
import com.htc.widget3d.weather.util.RefreshUtil;
import com.htc.widget3d.weather.util.WeatherUtil;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcWeather3DWidget.dex */
public class WeatherWidgetBaseMed extends Widget.Base {
    static final int GET_INTENT_FROM_WSP = 1002;
    public static final int MAXIMUN_CITY_COUNT = 1;
    public static final int MSG_INIT_DCS = -268431347;
    public static final int MSG_INIT_SETTING = -268435200;
    private static final int RESULT_CITY = 20;
    public static final String SYNC_DATA_CATEGORY = "sync_data_category";
    protected static final String TAG = "WeatherWidgetBaseMed";
    private static final int WEATHER_GET_INTENT_FROM_SERVER = 8;
    private static final int WEATHER_UPDATE_DATA_BY_BUNDLE = 7;
    public static final int WHAT_ON_ACTIVITY_RESULT = 36866;
    public static final int WHAT_ON_INIT = 36865;
    public static City.UNIT default_unit;
    public static boolean isPortrait = true;
    public static boolean isWidgetOnScreen = false;
    public static City.UNIT mUnit;
    private long lastUpdateTime;
    public CityInfo mCityInfo;
    private Widget.Host.Worker mDataHandler;
    private Context mResContext;
    private Context mWidgetContext;
    private Intent mBackIntent = null;
    private City mCity = null;
    private boolean mIsCurLocation = false;
    private boolean mBoolLostLocation = false;
    private boolean mBoolAppFirstResume = false;
    private boolean mBoolAppResume = false;
    private boolean mBoolAppDestroy = false;
    private boolean mBoolServiceBinded = false;
    private boolean mBoolUpdataUI = false;
    private boolean mGetDateFromServerButNotUpdate = false;
    private boolean mBoolReceiverRegistered = false;
    private boolean mBoolWSPReceiverRegistered = false;
    private boolean mBoolLocReceiverRegistered = false;
    private boolean mBoolRefreshUnit = false;
    private Handler.Callback mWorker = new Handler.Callback() { // from class: com.htc.widget3d.weather.WeatherWidgetBaseMed.1
        @Override // android.os.Handler.Callback
        public boolean handleMessage(Message msg) {
            switch (msg.what) {
                case -268435200:
                    WeatherWidgetBaseMed.this.initSetting();
                    return true;
                case WeatherIntent.MSG_UPDATE_TEMPERATURE_SCALE /* -268431357 */:
                    break;
                case -268431347:
                    Log.v(WeatherWidgetBaseMed.TAG, "MSG_INIT_DCS");
                    WeatherWidgetBaseMed.this.initWidget();
                    WeatherWidgetBaseMed.this.initWSPReceiver();
                    return true;
                case 7:
                    Log.v(WeatherWidgetBaseMed.TAG, "WEATHER_UPDATE_DATA_BY_BUNDLE");
                    if (WeatherWidgetBaseMed.this.mCityInfo != null && WeatherWidgetBaseMed.this.mCityInfo.getState() != -1) {
                        WeatherWidgetBaseMed.this.updateUIByServiceResult(WeatherWidgetBaseMed.this.mCityInfo.getBundle());
                        return true;
                    }
                    Log.d(WeatherWidgetBaseMed.TAG, "CITYINFO_STATE_NO_DATA");
                    if (WeatherWidgetBaseMed.this.mCityInfo == null || WeatherWidgetBaseMed.this.mCityInfo.getDisplayName() == null) {
                        WeatherWidgetBaseMed.this.playEmptyPage("", WeatherWidgetBaseMed.this.mResContext.getString(R.string.data_error));
                        return true;
                    }
                    WeatherWidgetBaseMed.this.playEmptyPage(WeatherWidgetBaseMed.this.mCityInfo.getDisplayName(), WeatherWidgetBaseMed.this.mResContext.getString(R.string.data_error));
                    return true;
                case 8:
                    Intent data = (Intent) msg.obj;
                    WeatherWidgetBaseMed.this.decodeReciver(data);
                    break;
                case WeatherWidgetBaseMed.WHAT_ON_INIT /* 36865 */:
                    WeatherWidgetBaseMed.this.createData();
                    return true;
                case WeatherWidgetBaseMed.WHAT_ON_ACTIVITY_RESULT /* 36866 */:
                    WeatherWidgetBaseMed.this.doActivityResult((Intent) msg.obj);
                    return true;
                default:
                    return true;
            }
            if (WeatherWidgetBaseMed.this.mBoolRefreshUnit) {
                WeatherWidgetBaseMed.this.updateData();
                WeatherWidgetBaseMed.this.mBoolRefreshUnit = false;
                return true;
            }
            return true;
        }
    };
    private BroadcastReceiver mWeatherDataReceiver = null;
    private BroadcastReceiver mReceiver = null;
    private BroadcastReceiver mLocReceiver = null;

    public void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        LOG.i(TAG, "onCreate");
        isPortrait = 1 == getContext().getResources().getConfiguration().orientation;
        this.mBackIntent = getIntent();
        this.mWidgetContext = getHost().getContext();
        this.mResContext = getContext();
        this.mDataHandler = getHost().getWorker(this.mWorker);
        this.mBoolAppFirstResume = true;
    }

    protected void onPostCreate(Bundle savedState) {
        super.onPostCreate(savedState);
        Log.v(TAG, "onPostCreate");
        if (this.mDataHandler != null) {
            this.mDataHandler.send(WHAT_ON_INIT);
        }
    }

    protected void onResume() {
        super.onResume();
        Log.v(TAG, "onResume");
        this.mBoolAppResume = true;
        if (!this.mBoolAppFirstResume) {
            Date today = new Date();
            SimpleDateFormat formatter = new SimpleDateFormat("M/d/yyyy");
            String today_string = formatter.format(today);
            if (this.mCityInfo != null && this.mCityInfo.hasWeatherData) {
                String city_date = this.mCityInfo.getCity().current.today().getDate();
                if (!today_string.equals(city_date)) {
                    LOG.d(TAG, "city date Not match, today =" + today_string + ",City date =" + city_date);
                    if (this.mCityInfo != null && this.mCityInfo.hasWeatherData) {
                        this.mCityInfo.changeOffsetOfToday(getContext());
                    }
                } else {
                    LOG.d(TAG, "city date match, today =" + today_string + ",City date =" + city_date);
                    return;
                }
            } else {
                return;
            }
        }
        this.mBoolAppFirstResume = false;
        this.mDataHandler.send(-268435200);
    }

    protected void onPause() {
        super.onPause();
        this.mBoolAppResume = false;
    }

    protected void onDestroy() {
        super.onDestroy();
        this.mBoolAppDestroy = true;
        clearRegister();
    }

    public boolean isEditable() {
        return true;
    }

    public void onEdit() {
        Log.v(TAG, "onEdit");
        Intent intent = new Intent();
        intent.setClassName("com.htc.widget3d.weather", "com.htc.widget3d.weather.OptionActivity");
        try {
            Log.d(TAG, "startActivity");
            startActivityForResult(intent, RESULT_CITY);
        } catch (ActivityNotFoundException e) {
            Log.e(TAG, "startActivity error");
            e.printStackTrace();
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.e(TAG, "onActivityResult");
        if (resultCode == -1 && requestCode == RESULT_CITY) {
            if (this.mDataHandler != null) {
                Message msg = this.mDataHandler.obtainMessage();
                msg.what = WHAT_ON_ACTIVITY_RESULT;
                msg.obj = data;
                this.mDataHandler.send(msg);
            } else {
                return;
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doActivityResult(Intent intent) {
        if (intent != null) {
            clearWSPPRegister();
            Log.v(TAG, "get City from back intent");
            String name = intent.getStringExtra("name_");
            String app = intent.getStringExtra("app_");
            this.mIsCurLocation = false;
            this.mBoolLostLocation = false;
            if (this.mCity == null) {
                this.mCity = new City();
            }
            if (name == null || (app != null && app.equals(WeatherIntent.APP_LOCATION_SERVICE))) {
                Log.v(TAG, "current");
                this.mIsCurLocation = true;
                if (!getDefaultLocation()) {
                    Log.v(TAG, "LostLocation");
                    this.mBoolLostLocation = true;
                    playEmptyPage(this.mResContext.getString(R.string.current_location), this.mResContext.getString(R.string.data_error));
                }
            } else {
                CityInfo ci = new CityInfo();
                WeatherLocation loc = new WeatherLocation();
                String code = intent.getStringExtra("code_");
                Log.d(TAG, "City Code:" + code);
                loc.setCode(code);
                loc.setName(intent.getStringExtra("name_"));
                loc.setState(intent.getStringExtra("state_"));
                loc.setCountry(intent.getStringExtra("country_"));
                loc.setApp(intent.getStringExtra("app_"));
                loc.setTimezone(intent.getStringExtra("timezone_"));
                loc.setTimezoneId(intent.getStringExtra("timezoneid_"));
                loc.setLatitude(intent.getStringExtra("latitude_"));
                loc.setLongitude(intent.getStringExtra("longitude_"));
                ci.setLocationInfo(loc);
                ci.type_ = (code == null || code.length() == 0) ? WeatherModel.QUERY_TYPE.GOOGLE_GEOCODE : WeatherModel.QUERY_TYPE.QUERY_CODE_ACCU_WEATHER;
                this.mCityInfo = ci;
                saveInitProps(this.mCityInfo);
            }
            if (this.mDataHandler != null) {
                this.mDataHandler.send(-268431347);
            }
        }
    }

    protected void initWidget() {
        LOG.i(TAG, "initWidget");
    }

    protected void initData() {
        LOG.i(TAG, "initData");
    }

    protected void playEmptyPage(String city, String error_msg) {
        Log.i(TAG, "playEmptyPage");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void createData() {
        LOG.i(TAG, "createData");
        this.mIsCurLocation = false;
        this.mBoolLostLocation = false;
        if (this.mCity == null) {
            this.mCity = new City();
        }
        Properties props = loadInstanceData();
        if (props == null) {
            if (this.mBackIntent != null) {
                Log.v(TAG, "get City from back intent");
                String name = this.mBackIntent.getStringExtra("name_");
                String app = this.mBackIntent.getStringExtra("app_");
                if (name == null || (app != null && app.equals(WeatherIntent.APP_LOCATION_SERVICE))) {
                    Log.v(TAG, "current");
                    this.mIsCurLocation = true;
                    if (!getDefaultLocation()) {
                        Log.v(TAG, "LostLocation");
                        this.mBoolLostLocation = true;
                        playEmptyPage(this.mResContext.getString(R.string.current_location), this.mResContext.getString(R.string.data_error));
                        return;
                    }
                    return;
                }
                CityInfo ci = new CityInfo();
                WeatherLocation loc = new WeatherLocation();
                String code = this.mBackIntent.getStringExtra("code_");
                Log.d(TAG, "City Code:" + code);
                loc.setCode(code);
                loc.setName(this.mBackIntent.getStringExtra("name_"));
                loc.setState(this.mBackIntent.getStringExtra("state_"));
                loc.setCountry(this.mBackIntent.getStringExtra("country_"));
                loc.setApp(this.mBackIntent.getStringExtra("app_"));
                loc.setTimezone(this.mBackIntent.getStringExtra("timezone_"));
                loc.setTimezoneId(this.mBackIntent.getStringExtra("timezoneid_"));
                loc.setLatitude(this.mBackIntent.getStringExtra("latitude_"));
                loc.setLongitude(this.mBackIntent.getStringExtra("longitude_"));
                ci.setLocationInfo(loc);
                ci.type_ = (code == null || code.length() == 0) ? WeatherModel.QUERY_TYPE.GOOGLE_GEOCODE : WeatherModel.QUERY_TYPE.QUERY_CODE_ACCU_WEATHER;
                this.mCityInfo = ci;
                saveInitProps(this.mCityInfo);
                return;
            }
            return;
        }
        if (props != null) {
            Log.d(TAG, "Property exist");
            CityInfo ci2 = new CityInfo();
            WeatherLocation loc2 = new WeatherLocation();
            String code2 = props.getProperty("code_");
            if (code2 != null) {
                Log.d(TAG, "Code:" + code2);
                loc2.setCode(code2);
            }
            loc2.setName(props.getProperty("name_"));
            loc2.setState(props.getProperty("state_"));
            loc2.setCountry(props.getProperty("country_"));
            loc2.setApp(props.getProperty("app_"));
            loc2.setLatitude(props.getProperty("latitude_"));
            Log.d(TAG, "Latitude:" + loc2.getLatitude());
            loc2.setLongitude(props.getProperty("longitude_"));
            Log.d(TAG, "Longitude:" + loc2.getLongitude());
            ci2.setLocationInfo(loc2);
            ci2.type_ = (code2 == null || code2.length() == 0) ? WeatherModel.QUERY_TYPE.GOOGLE_GEOCODE : WeatherModel.QUERY_TYPE.QUERY_CODE_ACCU_WEATHER;
            this.mCityInfo = ci2;
            if (ci2.type_ == WeatherModel.QUERY_TYPE.QUERY_CODE_ACCU_WEATHER) {
                saveInitProps(ci2);
            }
        }
    }

    private boolean getDefaultLocation() {
        if (this.mResContext == null) {
            return false;
        }
        WeatherLocation[] locs = WeatherUtility.loadLocations(this.mResContext.getContentResolver(), WeatherIntent.APP_LOCATION_SERVICE);
        CityInfo ci_no = new CityInfo();
        ci_no.cityName = null;
        if (locs.length == 0) {
            Log.e(TAG, "Can not get current location");
            this.mCityInfo = ci_no;
            return false;
        }
        if (locs[0].getApp() == null || !locs[0].getApp().equals(WeatherIntent.APP_LOCATION_SERVICE)) {
            Log.e(TAG, "Can not get current location");
            this.mCityInfo = ci_no;
            return false;
        }
        CityInfo ci = new CityInfo();
        if (locs[0].getName() == null || locs[0].getName().length() == 0) {
            locs[0].setName(this.mResContext.getResources().getString(R.string.current_location));
        }
        ci.setLocationInfo(locs[0]);
        ci.type_ = WeatherModel.QUERY_TYPE.GOOGLE_GEOCODE;
        if (ci.getCityName() == null) {
            Log.e(TAG, "current location info is not correct");
            return false;
        }
        Log.e(TAG, "get default city name return true :" + ci.getCityName());
        this.mCityInfo = ci;
        return true;
    }

    private void saveInitProps(CityInfo ci) {
        WeatherLocation loc = ci.getLocationInfo();
        if (loc != null) {
            if (ci.type_ == WeatherModel.QUERY_TYPE.QUERY_CODE_ACCU_WEATHER) {
                try {
                    WeatherLocation dbloc = queryLocationInfo(this.mResContext, loc.getCode());
                    if (dbloc != null) {
                        loc = dbloc;
                        ci.setLocationInfo(loc);
                    }
                } catch (Exception e) {
                }
            }
            Log.v(TAG, "saveInitProps");
            try {
                Properties props = new Properties();
                if (ci.getCityName() != null) {
                    props.setProperty("name_", safeString(loc.getName()));
                    props.setProperty("state_", safeString(loc.getState()));
                    props.setProperty("country_", safeString(loc.getCountry()));
                    props.setProperty("code_", safeString(loc.getCode()));
                    props.setProperty("latitude_", safeString(loc.getLatitude()));
                    props.setProperty("longitude_", safeString(loc.getLongitude()));
                    props.setProperty("app_", safeString(loc.getApp()));
                    try {
                        storeInstanceData(props);
                        Log.v(TAG, "saveData code:" + safeString(loc.getCode()));
                    } catch (SQLiteFullException e2) {
                        Log.e(TAG, "property save error");
                        e2.printStackTrace();
                    }
                }
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        }
    }

    private WeatherLocation queryLocationInfo(Context context, String code) {
        WeatherUtility.SearchCondition searchCondition = new WeatherUtility.SearchCondition(code, WeatherConsts.LOCATION_LIST_COLUMN_NAME.code.name(), WeatherUtility.SEARCH_TYPE.MATCH_IGONE_CASE);
        Cursor cursor = null;
        WeatherLocation wl = null;
        try {
            cursor = WeatherUtility.getLocationListBySearchCondition(context.getContentResolver(), WeatherConsts.LOCATION_LIST_COLUMN_NAME.name.name(), new WeatherUtility.SearchCondition[]{searchCondition});
            if (cursor != null) {
                if (cursor.getCount() == 1 && cursor.moveToFirst()) {
                    wl = WeatherUtility.CursorToWeatherLocation(cursor);
                } else {
                    Log.w(TAG, cursor.getCount() == 0 ? "no match data" : "data is incorrect");
                }
            } else {
                Log.w(TAG, "******** cursor is null");
            }
            if (wl == null) {
                Log.e(TAG, "can not find location info of " + code);
            }
            return wl;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateUIByServiceResult(WSPPData data) {
        Log.d(TAG, "updateUIByServiceResult");
        if (data != null && this.mCity != null) {
            if (data != null && data.hasWeatherData() && this.mCity != null) {
                DCSResult ret = new DCSResult(data);
                this.mCity.update_time = ret.getUpdateTime();
                this.mCity.unit = mUnit;
                this.mCity.current.reset();
                int count = ret.getTotalForecast();
                for (int i = 0; i < count; i++) {
                    DayForecast dayF = new DayForecast();
                    if (i == 0) {
                        int nCurTemp = ret.getCurrentTempF();
                        int nHiTemp = RefreshUtil.safe_parseInt(ret.getForecastHighTemp()[i]);
                        int nLoTemp = RefreshUtil.safe_parseInt(ret.getForecastLowTemp()[i]);
                        dayF.setCurrentF(nCurTemp);
                        if (nCurTemp > nHiTemp) {
                            dayF.setHighF(nCurTemp);
                        } else {
                            dayF.setHighF(nHiTemp);
                        }
                        if (nCurTemp < nLoTemp) {
                            dayF.setLowF(nCurTemp);
                        } else {
                            dayF.setLowF(nLoTemp);
                        }
                        int nCurTemp2 = ret.getCurrentTempC();
                        int nHiTemp2 = RefreshUtil.safe_parseInt(ret.getForecastHighTempC(i));
                        int nLoTemp2 = RefreshUtil.safe_parseInt(ret.getForecastLowTempC(i));
                        dayF.setCurrentC(nCurTemp2);
                        if (nCurTemp2 > nHiTemp2) {
                            dayF.setHighC(nCurTemp2);
                        } else {
                            dayF.setHighC(nHiTemp2);
                        }
                        if (nCurTemp2 < nLoTemp2) {
                            dayF.setLowC(nCurTemp2);
                        } else {
                            dayF.setLowC(nLoTemp2);
                        }
                        dayF.setCondition(IconPicker.getConditionText(getContext(), ret.getCurrentIcon()));
                        dayF.setForecastIcon(ret.getCurrentIcon());
                    } else {
                        int nHiTempF = RefreshUtil.safe_parseInt(ret.getForecastHighTempF()[i]);
                        int nHiTempC = RefreshUtil.safe_parseInt(ret.getForecastHighTempC()[i]);
                        int nLoTempF = RefreshUtil.safe_parseInt(ret.getForecastLowTempF()[i]);
                        int nLoTempC = RefreshUtil.safe_parseInt(ret.getForecastLowTempC()[i]);
                        dayF.setCurrentF((nHiTempF + nLoTempF) / 2);
                        dayF.setCurrentC((nHiTempC + nLoTempC) / 2);
                        dayF.setHighF(nHiTempF);
                        dayF.setHighC(nHiTempC);
                        dayF.setLowF(nLoTempF);
                        dayF.setLowC(nLoTempC);
                        dayF.setCondition(IconPicker.getConditionText(getContext(), ret.getForecastIcon(i)));
                        dayF.setForecastIcon(ret.getForecastIcon(i));
                    }
                    dayF.setWeekDay(WeatherUtil.getDateString(getContext(), ret.getForecastName(i)));
                    dayF.setDate(ret.getForecastDate(i));
                    this.mCity.current.add(dayF);
                }
                this.mCityInfo.setState(0);
                this.mCityInfo.setCity(this.mCity);
                this.mCityInfo.changeOffsetOfToday(this.mResContext);
                this.mBoolUpdataUI = true;
                if (this.mIsCurLocation && this.mCityInfo.getLocationInfo() != null) {
                    updateCurrentLocationName(data);
                }
                Log.v(TAG, "refreshData");
                initData();
                return;
            }
            Log.v(TAG, "updateCurrentLocationName");
            updateCurrentLocationName(data);
            if (this.mCityInfo.getDisplayName() != null) {
                playEmptyPage(this.mCityInfo.getDisplayName(), this.mResContext.getString(R.string.data_error));
            } else {
                playEmptyPage(this.mResContext.getString(R.string.current_location), this.mResContext.getString(R.string.data_error));
            }
        }
    }

    private boolean updateCurrentLocationName(WSPPData data) {
        if (data == null || data.getType() != 1) {
            return false;
        }
        if (this.mCityInfo == null) {
            this.mCityInfo = new CityInfo();
        }
        CityInfo ci = this.mCityInfo;
        WeatherLocation loc = new WeatherLocation();
        loc.setCode("");
        loc.setName(data.getCurLocName());
        loc.setState(data.getCurLocState());
        loc.setCountry(data.getCurLocCountry());
        loc.setApp(WeatherIntent.APP_LOCATION_SERVICE);
        loc.setTimezone("");
        loc.setTimezoneId(data.getCurLocTimezoneId());
        loc.setLatitude(data.getCurLocLat());
        loc.setLongitude(data.getCurLocLng());
        ci.setLocationInfo(loc);
        ci.type_ = WeatherModel.QUERY_TYPE.GOOGLE_GEOCODE;
        Log.d(TAG, "updateCurLocationName - " + ci.getDisplayName());
        return true;
    }

    private void startFetchData() {
        LOG.i(TAG, "startFetchData");
        getDataWhenConnectedService();
        initData();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void initWSPReceiver() {
        Log.v(TAG, "initWSPReceiver");
        if (this.mIsCurLocation) {
            initLocReceiver();
            if (!this.mBoolLocReceiverRegistered && this.mLocReceiver != null) {
                IntentFilter intentfilter = new IntentFilter(WeatherIntent.CURRENT_LOCATION_DELETED);
                this.mWidgetContext.registerReceiver(this.mLocReceiver, intentfilter);
                this.mBoolLocReceiverRegistered = true;
            }
        }
        if (this.mBoolWSPReceiverRegistered || this.mWidgetContext == null) {
            Log.e(TAG, "No initialWSP");
        } else if (this.mIsCurLocation || this.mCityInfo != null) {
            IntentFilter statusIntentFilter = new IntentFilter();
            statusIntentFilter.addAction("com.htc.sync.provider.weather.result");
            if (this.mIsCurLocation) {
                Log.v(TAG, "add intentfilter Current");
                statusIntentFilter.addCategory(WSPPUtility.generateWSPReqestForCurrentLocation().toString());
            } else if (this.mCityInfo != null) {
                Log.v(TAG, "add intentfilter" + this.mCityInfo.genCode());
                statusIntentFilter.addCategory(this.mCityInfo.genCode());
            }
            if (this.mWeatherDataReceiver == null) {
                this.mWeatherDataReceiver = new BroadcastReceiver() { // from class: com.htc.widget3d.weather.WeatherWidgetBaseMed.2
                    @Override // android.content.BroadcastReceiver
                    public void onReceive(Context context, Intent intent) {
                        Log.d(WeatherWidgetBaseMed.TAG, "SilderReceiver received: " + intent.getAction());
                        if (WeatherWidgetBaseMed.this.mDataHandler != null) {
                            Message msg = WeatherWidgetBaseMed.this.mDataHandler.obtainMessage();
                            msg.what = 8;
                            msg.obj = intent;
                            WeatherWidgetBaseMed.this.mDataHandler.send(msg);
                        }
                    }
                };
            }
            this.mWidgetContext.registerReceiver(this.mWeatherDataReceiver, statusIntentFilter);
            this.mBoolWSPReceiverRegistered = true;
        } else {
            return;
        }
        getDataWhenConnectedService();
    }

    private void getDataWhenConnectedService() {
        Log.e(TAG, "getDataWhenConnectedService");
        WSPRequest req = makeRequest(this.mCityInfo);
        if (req != null) {
            Log.w(TAG, "getDataWhenConnectedService, code = " + req.toString());
            try {
                WSPPData data = WSPPUtility.request(this.mResContext, req);
                if (data != null) {
                    this.mCityInfo.setBundle(data);
                    this.mDataHandler.send(7);
                    Log.w(TAG, "cache data:\ncurrentTempC: " + data.getLastUpdate());
                } else {
                    Log.w(TAG, "no cache data ");
                    if (this.mCityInfo.getDisplayName() != null) {
                        playEmptyPage(this.mCityInfo.getDisplayName(), this.mResContext.getString(R.string.data_error));
                    } else {
                        playEmptyPage("", this.mResContext.getString(R.string.data_error));
                    }
                }
                return;
            } catch (Exception e) {
                Log.w(TAG, " " + e.getMessage());
                return;
            }
        }
        Log.e(TAG, "getRequest Null");
        playEmptyPage("", this.mResContext.getString(R.string.data_error));
    }

    private WSPRequest makeRequest(CityInfo cityinfo) {
        WeatherLocation loc;
        if (cityinfo != null && (loc = cityinfo.getLocationInfo()) != null) {
            if (loc.getApp() != null && loc.getApp().equals(WeatherIntent.APP_LOCATION_SERVICE)) {
                Log.v(TAG, "Request current");
                return WSPPUtility.generateWSPReqestForCurrentLocation();
            }
            if (loc.getCode() != null && loc.getCode().length() > 0) {
                Log.v(TAG, "Request code:" + loc.getCode());
                return WSPPUtility.generateWSPRequestForLocCode(loc.getCode());
            }
            if (loc.getLatitude() == null || loc.getLatitude().length() <= 0) {
                return null;
            }
            Log.v(TAG, "Request getLongitude():" + loc.getLongitude());
            return WSPPUtility.generateWSPRequestForLatitude(loc.getLatitude(), loc.getLongitude());
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void decodeReciver(Intent intent) {
        Log.d(TAG, "SilderReceiver received: " + intent.getAction());
        if (intent.getCategories().size() == 1) {
            String category = null;
            for (String c : intent.getCategories()) {
                category = c;
            }
            if (category != null) {
                try {
                    WSPPData data = (WSPPData) intent.getParcelableExtra("data");
                    Log.d(TAG, "receive data intent: " + (data == null ? "null" : data.toString()));
                    if (data != null) {
                        if (data.getType() == 1) {
                            updateCurrentLocationName(data);
                            if (!data.hasWeatherData()) {
                                Log.d(TAG, "curloc change but no weather data");
                                if (this.mCityInfo != null) {
                                    this.mCity = new City();
                                    this.mCityInfo.setCity(this.mCity);
                                    playEmptyPage(this.mCityInfo.getDisplayName(), this.mResContext.getString(R.string.data_error));
                                    return;
                                }
                                playEmptyPage(this.mResContext.getString(R.string.current_location), this.mResContext.getString(R.string.data_error));
                                return;
                            }
                        }
                        if (this.mCityInfo != null) {
                            this.mGetDateFromServerButNotUpdate = true;
                            this.mCityInfo.setBundle(data);
                            this.mDataHandler.send(7);
                            return;
                        }
                        return;
                    }
                    return;
                } catch (Exception e) {
                    Log.e(TAG, "error occurred when parseDataPacket");
                    return;
                }
            }
            return;
        }
        Log.d(TAG, "receive status intent: incorrect category");
    }

    private void decodeIntent(Intent intent) {
        Log.d(TAG, "decode intent: " + intent.toString());
        if (intent.getCategories().size() == 1) {
            String category = null;
            for (String c : intent.getCategories()) {
                category = c;
            }
            if (category != null) {
                try {
                    WSPPData data = intent.getParcelableExtra("data");
                    Log.d(TAG, "receive data intent: " + (data == null ? "null" : data.toString()));
                    if (data != null) {
                        if (data.getType() == 1) {
                            Log.d(TAG, "current location name:" + data.getCurLocName());
                            Log.d(TAG, "current location weather condition:" + data.getCurConditionId());
                            if (!data.hasWeatherData()) {
                                Log.d(TAG, "curloc change but no weather data");
                                return;
                            }
                            return;
                        }
                        Log.d(TAG, "city name:" + data.getCurLocName());
                        Log.d(TAG, "city weather condition:" + data.getCurConditionId());
                        return;
                    }
                    return;
                } catch (Exception e) {
                    Log.e(TAG, "error occurred when parseDataPacket");
                    return;
                }
            }
            return;
        }
        Log.d(TAG, "receive status intent: incorrect category");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void initSetting() {
        Log.d(TAG, "initSetting...");
        mUnit = WSPPUtility.isTemperatureCelsius(getHost().getContext()) ? City.UNIT._C : City.UNIT._F;
        initAppReceiver();
        if (!this.mBoolReceiverRegistered && this.mReceiver != null) {
            Log.d(TAG, "Register App Receiver");
            IntentFilter intentfilter = new IntentFilter("com.htc.sync.provider.weather.SETTINGS_UPDATED");
            intentfilter.addCategory("com.htc.sync.provider.weather.setting.temperatureunit");
            this.mWidgetContext.registerReceiver(this.mReceiver, intentfilter);
            this.mBoolReceiverRegistered = true;
        }
        this.mDataHandler.send(-268431347);
    }

    private void initAppReceiver() {
        if (this.mReceiver == null) {
            this.mReceiver = new BroadcastReceiver() { // from class: com.htc.widget3d.weather.WeatherWidgetBaseMed.3
                @Override // android.content.BroadcastReceiver
                public void onReceive(Context context, Intent intent) {
                    String temperatureUnit;
                    Log.d(WeatherWidgetBaseMed.TAG, "Receivered broadcast intent info from WSPPUtility: " + intent.getAction());
                    if (!WeatherWidgetBaseMed.this.mBoolAppDestroy) {
                        if (intent.getAction().equals("com.htc.sync.provider.weather.SETTINGS_UPDATED") && (temperatureUnit = intent.getStringExtra("settingData")) != null && temperatureUnit.length() != 0) {
                            if (temperatureUnit.equals("c")) {
                                Log.d(WeatherWidgetBaseMed.TAG, "mUnit = UNIT._C");
                                WeatherWidgetBaseMed.mUnit = City.UNIT._C;
                            } else {
                                Log.d(WeatherWidgetBaseMed.TAG, "mUnit = UNIT._F");
                                WeatherWidgetBaseMed.mUnit = City.UNIT._F;
                            }
                            WeatherWidgetBaseMed.this.mBoolRefreshUnit = true;
                            WeatherWidgetBaseMed.this.mDataHandler.send(WeatherIntent.MSG_UPDATE_TEMPERATURE_SCALE);
                            return;
                        }
                        return;
                    }
                    Log.d(WeatherWidgetBaseMed.TAG, "discard the broadcast info: ");
                }
            };
        }
    }

    private void initLocReceiver() {
        if (this.mLocReceiver == null) {
            this.mLocReceiver = new BroadcastReceiver() { // from class: com.htc.widget3d.weather.WeatherWidgetBaseMed.4
                @Override // android.content.BroadcastReceiver
                public void onReceive(Context context, Intent intent) {
                    Log.d(WeatherWidgetBaseMed.TAG, "Receivered broadcast intent info from Weather app: " + intent.getAction());
                    if (!WeatherWidgetBaseMed.this.mBoolAppDestroy) {
                        if (intent.getAction().equals(WeatherIntent.CURRENT_LOCATION_DELETED) && WeatherWidgetBaseMed.this.mIsCurLocation) {
                            WeatherWidgetBaseMed.this.clearCurrentLocation();
                            WeatherWidgetBaseMed.this.mBoolUpdataUI = true;
                            WeatherWidgetBaseMed.this.updateData();
                            return;
                        }
                        return;
                    }
                    Log.d(WeatherWidgetBaseMed.TAG, "discard the broadcast info: ");
                }
            };
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void clearCurrentLocation() {
        this.mCityInfo = null;
        this.mCity = new City();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateData() {
        DayForecast df = this.mCity.current.today();
        if (df == null) {
            if (this.mCityInfo != null && this.mCityInfo.getDisplayName() != null) {
                playEmptyPage(this.mCityInfo.getDisplayName(), this.mResContext.getString(R.string.data_error));
                return;
            } else {
                playEmptyPage("", this.mResContext.getString(R.string.data_error));
                return;
            }
        }
        this.mCityInfo.setCity(this.mCity);
        initData();
    }

    private String safeString(String str) {
        return (str == null || str.length() == 0) ? "" : str;
    }

    private void clearRegister() {
        if (this.mBoolReceiverRegistered && this.mWidgetContext != null) {
            this.mWidgetContext.unregisterReceiver(this.mReceiver);
            this.mBoolReceiverRegistered = false;
            Log.v(TAG, "clear : unregisterReceiver mReceiver");
        }
        if (this.mBoolLocReceiverRegistered && this.mWidgetContext != null) {
            this.mWidgetContext.unregisterReceiver(this.mLocReceiver);
            this.mBoolLocReceiverRegistered = false;
            Log.v(TAG, "clear : unregisterReceiver mLocReceiver");
        }
        if (this.mBoolWSPReceiverRegistered && this.mWidgetContext != null) {
            this.mWidgetContext.unregisterReceiver(this.mWeatherDataReceiver);
            this.mBoolWSPReceiverRegistered = false;
            Log.v(TAG, "clear : unregisterReceiver mWeatherDataReceiver");
        }
    }

    private void clearWSPPRegister() {
        if (this.mBoolLocReceiverRegistered && this.mWidgetContext != null) {
            this.mWidgetContext.unregisterReceiver(this.mLocReceiver);
            this.mBoolLocReceiverRegistered = false;
            Log.v(TAG, "clear : unregisterReceiver mLocReceiver");
        }
        if (this.mBoolWSPReceiverRegistered && this.mWidgetContext != null) {
            this.mWidgetContext.unregisterReceiver(this.mWeatherDataReceiver);
            this.mBoolWSPReceiverRegistered = false;
            Log.v(TAG, "clear : unregisterReceiver mWeatherDataReceiver");
        }
    }
}
