package com.htc.widget3d.weather;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;
import com.htc.android.rosie.widget.Widget;
import com.htc.android.rosie.widget.WidgetHelper;
import com.htc.fusion.fx.FxScene;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.Marker;
import com.htc.fusion.fx.MessageListener;
import com.htc.fusion.fx.controls.FxHitbox;
import com.htc.fusion.fx.controls.FxSceneContainer;
import com.htc.fusion.fx.controls.FxTextLabel;
import com.htc.widget3d.weather.data.CityInfo;
import com.htc.widget3d.weather.data.DayForecast;
import com.htc.widget3d.weather.data.WeatherIntent;
import com.htc.widget3d.weather.util.LOG;
import com.htc.widget3d.weather.util.WeatherUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcWeather3DWidget.dex */
public class Weather2x2Widget extends WeatherWidgetBaseMed {
    private static final String ASSET_FORECAST_M10PATH = "scenes/forecast_state/";
    private static final String TAG = "WeatherWidget2x2";
    private FxHitbox fx_HitBox;
    private FxScene fx_Status;
    private FxSceneContainer fxsc_Status;
    private FxTimelineControl fxtc_Status;
    private FxTimelineControl fxtc_Weather;
    private FxTextLabel fxtl_City;
    private FxTextLabel fxtl_Empty;
    private FxTextLabel fxtl_EmptyCity;
    private FxTextLabel fxtl_HL;
    private FxTextLabel fxtl_Temp;
    private FxScene landScene;
    private GetFxControls mGetFxControls;
    private MessageListener<FxHitbox.TapParameters> mTapListener;
    protected Widget.Host.Worker mWorker;
    private WeatherInfo2x2 m_WeaInfo;
    private boolean m_bInitial;
    private FxScene m_fxScene;
    private FxScene portScene;
    protected String SZ_DEFAULT_M10PATH = "scenes/Weather_2x2.m10";
    protected String SZ_DEFAULT_M10PATH_LAND = "scenes/Weather_2x2_land.m10";
    private int WEATHER_COUNT = 1;
    private boolean isWeatherDataAvalible = false;
    private boolean isNeedInitState = false;
    private int mCityIndex = 0;
    protected int mWidgetID = 2;
    private FxTextLabel fxtl_Condition = null;
    private FxTimelineControl m_timelineTilt = null;
    private int m_nTiltStartFrame = 0;
    private int m_nTiltEndFrame = 0;

    @Override // com.htc.widget3d.weather.WeatherWidgetBaseMed
    public void onCreate(Bundle saved) {
        super.onCreate(saved);
        LOG.d(TAG, "onCreate");
        this.mWorker = getHost().getWorker();
        this.portScene = getHost().createScene(this.SZ_DEFAULT_M10PATH, true);
        this.landScene = getHost().createScene(this.SZ_DEFAULT_M10PATH_LAND, true);
        this.mGetFxControls = new GetFxControls();
    }

    protected void finalize() throws Throwable {
        super/*java.lang.Object*/.finalize();
        LOG.d(TAG, "mem : finalize called");
    }

    protected FxScene getScene() {
        LOG.d(TAG, "getScene() , isPortrait==" + isPortrait);
        return isPortrait ? this.portScene : this.landScene;
    }

    public void onConfigurationChanged(Configuration newConfiguration) {
        super.onConfigurationChanged(newConfiguration);
        LOG.d(TAG, "onConfigurationChanged");
        isPortrait = 1 == newConfiguration.orientation;
        if (this.mWorker != null) {
            this.mWorker.cancel(this.mGetFxControls);
        }
    }

    protected void onHostMessage(Message msg) {
        switch (msg.what) {
            case 3:
                if (this.mWorker != null) {
                    LOG.d(TAG, "HOST_ORIENTATION_CHANGE_COMPLETE");
                    this.mWorker.post(this.mGetFxControls);
                    break;
                } else {
                    this.mGetFxControls.run();
                    break;
                }
        }
        super.onHostMessage(msg);
    }

    @Override // com.htc.widget3d.weather.WeatherWidgetBaseMed
    protected void initWidget() {
        super.initWidget();
        if (this.m_WeaInfo == null) {
            initWeatherInfo();
        }
        if (this.mGetFxControls != null) {
            initWeatherControl();
        }
    }

    @Override // com.htc.widget3d.weather.WeatherWidgetBaseMed
    protected void initData() {
        super.initData();
        LOG.i(TAG, "updateData");
        updateWeatherInfo();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void initWeatherState() {
        Log.v(TAG, "condition:" + this.m_WeaInfo.szDescription);
        setInfoToControl(this.m_WeaInfo);
        playWeatherUpdate();
    }

    private void initWeatherInfo() {
        LOG.d(TAG, "initWeatherInfo");
        this.m_WeaInfo = new WeatherInfo2x2();
        this.m_WeaInfo.szCity = "";
        this.m_WeaInfo.szDescription = "";
        this.m_WeaInfo.szCurTemp = "";
        this.m_WeaInfo.curHitemp = "";
        this.m_WeaInfo.curLowTemp = "";
    }

    private void updateWeatherInfo() {
        LOG.d(TAG, "updateWeatherInfo");
        if (this.mCityInfo != null) {
            CityInfo cityinfo = this.mCityInfo;
            DayForecast today = cityinfo.getCity().current.today();
            this.m_WeaInfo.szCity = cityinfo.displayName;
            if (cityinfo.hasWeatherData) {
                LOG.d(TAG, "cityinfo.hasWeatherData");
                this.isWeatherDataAvalible = true;
                this.isNeedInitState = this.isWeatherDataAvalible;
                this.m_WeaInfo.szDescription = today.getCondition();
                this.m_WeaInfo.szCurTemp = today.getCurrent(mUnit) + "°";
                this.m_WeaInfo.curHitemp = today.getHigh(mUnit) + "°";
                this.m_WeaInfo.curLowTemp = today.getLow(mUnit) + "°";
                this.m_WeaInfo.condition = today.getForecastIcon();
                initWeatherState();
                return;
            }
            return;
        }
        LOG.d(TAG, "mCityInfo == null");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void initWeatherControl() {
        Marker marker;
        LOG.d(TAG, "InitWeatherControl");
        this.m_fxScene = getScene();
        if (this.m_fxScene != null) {
            if (this.mWidgetID == 2 || this.mWidgetID == 3) {
                String[] szArrary = {"timeline.weather", "panel.hitbox", "textlabel.empty_city", "textlabel.empty_page", "timeline.tilt_weather", "scenecontainer.weather_state", "textlabel.city", "textlabel.temp", "textlabel.H_L", "textlabel.weather"};
                FxTextLabel[] descendants = this.m_fxScene.getDescendants(szArrary);
                this.fxtc_Weather = (FxTimelineControl) descendants[0];
                this.fx_HitBox = (FxHitbox) descendants[1];
                this.fxtl_EmptyCity = descendants[2];
                this.fxtl_Empty = descendants[3];
                this.m_timelineTilt = (FxTimelineControl) descendants[4];
                this.fxsc_Status = (FxSceneContainer) descendants[5];
                this.fxtl_City = descendants[6];
                this.fxtl_Temp = descendants[7];
                this.fxtl_HL = descendants[8];
                this.fxtl_Condition = descendants[9];
                if (this.m_timelineTilt != null && (marker = this.m_timelineTilt.getMarker("tilt")) != null) {
                    this.m_nTiltStartFrame = marker.StartFrame;
                    this.m_nTiltEndFrame = marker.EndFrame;
                }
            } else {
                Log.e(TAG, "invalid widgetID");
            }
            setHitBox();
        }
    }

    private void setHitBox() {
        if (this.fx_HitBox == null) {
            LOG.d(TAG, "Control Hitbox.weather == null !!");
            return;
        }
        this.fx_HitBox.setEnabledGestures(1);
        this.fx_HitBox.setEnabled(true);
        if (this.mTapListener == null) {
            this.mTapListener = new MessageListener<FxHitbox.TapParameters>() { // from class: com.htc.widget3d.weather.Weather2x2Widget.1
                public void onMessageReceived(FxHitbox.TapParameters message) {
                    LOG.d(Weather2x2Widget.TAG, "hitBox on Tap");
                    Intent intent = new Intent(WeatherIntent.ACTION_INTENT_LOCATE);
                    if (intent != null) {
                        intent.setClassName(WeatherIntent.WEATHER_PACKAGENAME, WeatherIntent.LAUNCHAP_CLASSNAME);
                        if (Weather2x2Widget.this.mCityInfo != null) {
                            intent.putExtra("name_", Weather2x2Widget.this.mCityInfo.getCityName());
                            if (Weather2x2Widget.this.mCityInfo.getLocationInfo() != null) {
                                intent.putExtra("code_", Weather2x2Widget.this.mCityInfo.getLocationInfo().getCode());
                                intent.putExtra("app_", Weather2x2Widget.this.mCityInfo.getLocationInfo().getApp());
                            }
                        }
                        intent.addFlags(268435456);
                        intent.addFlags(67108864);
                        try {
                            Weather2x2Widget.this.getHost().getContext().startActivity(intent);
                        } catch (ActivityNotFoundException e) {
                            Toast.makeText(Weather2x2Widget.this.getContext(), R.string.weather_activity_not_ready, 0).show();
                        }
                    }
                }
            };
        }
        if (this.fx_HitBox.getTapSource() != null) {
            this.fx_HitBox.getTapSource().unbindAll();
        }
        this.fx_HitBox.getTapSource().bind(this.mTapListener);
    }

    public void onTiltChanged(float fTilt) {
        if (this.m_timelineTilt != null) {
            this.m_timelineTilt.setFrame(WidgetHelper.convertTiltAngleToFrame(fTilt, this.m_nTiltStartFrame, this.m_nTiltEndFrame));
        }
    }

    public void playWeatherUpdate() {
        if (this.fx_Status != null) {
            this.fx_Status.playMarker("In");
        }
        if (this.fxtc_Weather != null) {
            this.fxtc_Weather.playMarker("weather_update");
        }
    }

    @Override // com.htc.widget3d.weather.WeatherWidgetBaseMed
    protected void playEmptyPage(String city, String error_msg) {
        if (this.fxtl_Empty != null) {
            this.fxtl_Empty.setString(error_msg);
        }
        if (this.fxtl_EmptyCity != null) {
            this.fxtl_EmptyCity.setString(city);
        }
        if (this.fxtc_Weather != null) {
            this.fxtc_Weather.playMarker("empty_page");
        } else {
            Log.e(TAG, "fxtc_Weather=null");
        }
    }

    public void setInfoToControl(WeatherInfo2x2 info) {
        if (this.fxtl_City != null) {
            this.fxtl_City.setString(info.szCity);
        }
        if (this.fxtl_Condition != null) {
            this.fxtl_Condition.setString(info.szDescription);
        }
        if (this.fxtl_Temp != null) {
            this.fxtl_Temp.setString(info.szCurTemp);
        }
        if (this.fxtl_HL != null) {
            this.fxtl_HL.setString(info.curHitemp + " / " + info.curLowTemp);
        }
        setStatusControl(info.condition);
    }

    public void setStatusControl(int condition) {
        String m10Path = ASSET_FORECAST_M10PATH + WeatherUtil.getForecastScenePath(condition);
        Log.v(TAG, "m10path :" + m10Path);
        this.fx_Status = FxScene.create(m10Path, true);
        if (this.fxsc_Status != null) {
            this.fxsc_Status.setScene(this.fx_Status);
        }
    }

    class GetFxControls implements Runnable {
        GetFxControls() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Weather2x2Widget.this.initWeatherControl();
            if (Weather2x2Widget.this.isWeatherDataAvalible) {
                Weather2x2Widget.this.initWeatherState();
                return;
            }
            Log.v(Weather2x2Widget.TAG, "No weather data");
            if (Weather2x2Widget.this.mCityInfo.getDisplayName() != null) {
                Weather2x2Widget.this.playEmptyPage(Weather2x2Widget.this.mCityInfo.getDisplayName(), Weather2x2Widget.this.getContext().getString(R.string.data_error));
            } else {
                Weather2x2Widget.this.playEmptyPage("", Weather2x2Widget.this.getContext().getString(R.string.data_error));
            }
        }
    }
}
