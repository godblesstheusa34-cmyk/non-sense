package com.htc.widget3d.weather.data;

import android.content.Context;
import android.util.Log;
import com.htc.util.weather.WSPUtility;
import com.htc.util.weather.WeatherLocation;
import com.htc.util.weather.WeatherUtility;
import com.htc.widget3d.weather.R;
import com.htc.widget3d.weather.data.City;
import com.htc.widget3d.weather.util.LOG;
import com.htc.widget3d.weather.util.WeatherUtil;
import java.util.ArrayList;
import java.util.Date;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcWeather3DWidget.dex */
public class WeatherModel {
    private static final String TAG = "WeatherModel";
    public static City.UNIT default_unit;
    private Context mContext;
    private WeatherModelListener mModelListener;
    private int mTotalCityCount;
    private Context mWidgetContext;
    private Date updateTime;
    private ArrayList<CityInfo> mCurrentCityList = new ArrayList<>();
    private boolean mDataRoamingChecked = false;
    private boolean mBoolGeocodeCorrected = false;
    private boolean mTerminated = false;

    public enum QUERY_TYPE {
        QUERY_CODE_ACCU_WEATHER,
        GOOGLE_GEOCODE
    }

    public interface WeatherModelListener {
        void onModelInitialized();

        void onModelUpdated();

        void onNetworkNonActive();

        void onNetworkRoaming();
    }

    public WeatherModel(Context context, Context widgetContext, int totalcity) {
        this.mTotalCityCount = 15;
        this.mContext = context;
        this.mWidgetContext = widgetContext;
        this.mTotalCityCount = totalcity;
    }

    public void initialModel() {
        if (!this.mTerminated) {
            prepareWeatherProviderRunnable newRunnable = new prepareWeatherProviderRunnable();
            newRunnable.run();
            if (this.updateTime == null) {
                this.updateTime = new Date();
            }
        }
    }

    public void setCityList(ArrayList<CityInfo> list) {
        this.mCurrentCityList = list;
    }

    public void terminate() {
        this.mTerminated = true;
    }

    public ArrayList<CityInfo> getCityList() {
        return this.mCurrentCityList;
    }

    public CityInfo get(int position) {
        if (position < 0 || position >= this.mCurrentCityList.size()) {
            return null;
        }
        return this.mCurrentCityList.get(position);
    }

    public int size() {
        return this.mCurrentCityList.size();
    }

    public void clear() {
        this.mCurrentCityList.clear();
    }

    public void reset() {
        int size = this.mCurrentCityList.size();
        for (int i = 0; i < size; i++) {
            this.mCurrentCityList.get(i).removeCity();
        }
    }

    public int add(int index, CityInfo info) {
        try {
            this.mCurrentCityList.add(index, info);
            return index;
        } catch (IndexOutOfBoundsException e) {
            return -1;
        }
    }

    public void add(CityInfo info) {
        this.mCurrentCityList.add(info);
    }

    public void remove(int position) {
        WeatherLocation weatherLocation = this.mCurrentCityList.get(position).getLocationInfo();
        Log.i(TAG, "mCurrentCityLsit.remove(" + position + ")");
        this.mCurrentCityList.remove(position);
        Log.i(TAG, "initial remove data from DB");
        RemoveDataRunnable removeData = new RemoveDataRunnable(weatherLocation.getName(), weatherLocation.getState(), weatherLocation.getCountry());
        Log.i(TAG, "start remove data from DB");
        removeData.run();
        Log.i(TAG, "After start remove data from DB");
    }

    public boolean updateWeatherCityList() {
        int extra = 0;
        this.mCurrentCityList.clear();
        boolean status = false;
        String[] pkgname = {WeatherIntent.APP_LOCATION_SERVICE, WeatherIntent.WEATHER_PROVIDER_KEYNAME};
        WeatherLocation[] locs = WeatherUtility.loadMultiAppLocationsFilterByApp(this.mContext.getContentResolver(), pkgname);
        if (locs.length > 0) {
            if (locs[0].getApp() != null && locs[0].getApp().equals(WeatherIntent.APP_LOCATION_SERVICE)) {
                extra = 1;
            }
            for (WeatherLocation loc : locs) {
                if (this.mTerminated) {
                }
                if (this.mCurrentCityList.size() >= this.mTotalCityCount + extra) {
                    break;
                }
                CityInfo cityinfo = new CityInfo();
                cityinfo.index = this.mCurrentCityList.size() + 1;
                if (loc.getState() == null) {
                    loc.setState("");
                }
                if (loc.getCountry() == null) {
                    loc.setCountry("");
                }
                if (loc.getCode() == null || loc.getCode().length() == 0) {
                    cityinfo.type_ = QUERY_TYPE.GOOGLE_GEOCODE;
                    if (this.mBoolGeocodeCorrected && loc.getApp() != null && loc.getApp().equals(WeatherIntent.APP_LOCATION_SERVICE)) {
                        WeatherUtility.deleteLocation(this.mContext.getContentResolver(), loc.getApp(), Double.valueOf(loc.getLatitude()).doubleValue(), Double.valueOf(loc.getLongitude()).doubleValue());
                        WeatherLocation[] tloc = {new WeatherLocation()};
                        tloc[0] = loc;
                        tloc[0].setLatitude(correctGeocode(loc.getLatitude()));
                        tloc[0].setLongitude(correctGeocode(loc.getLongitude()));
                        WeatherUtility.insertOBLocations(this.mContext.getContentResolver(), WeatherIntent.APP_LOCATION_SERVICE, tloc);
                    }
                    loc.setLatitude(correctGeocode(loc.getLatitude()));
                    loc.setLongitude(correctGeocode(loc.getLongitude()));
                } else {
                    cityinfo.type_ = QUERY_TYPE.QUERY_CODE_ACCU_WEATHER;
                }
                cityinfo.setLocationInfo(loc);
                this.mCurrentCityList.add(cityinfo);
            }
            status = true;
        }
        if (this.mModelListener != null) {
            this.mModelListener.onModelUpdated();
        }
        return status;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean prepareWeatherProvider() {
        LOG.v(TAG, "WeatherActivity prepareWeatherProvider");
        this.mBoolGeocodeCorrected = false;
        int extra = 0;
        this.mCurrentCityList.clear();
        String[] pkgname = {WeatherIntent.APP_LOCATION_SERVICE, WeatherIntent.WEATHER_PROVIDER_KEYNAME};
        WeatherLocation[] locs = WeatherUtility.loadMultiAppLocationsFilterByApp(this.mContext.getContentResolver(), pkgname);
        if (WeatherUtil.isLocationSettingChecked(this.mContext) && locs != null && locs.length > 0 && locs[0] != null && !locs[0].getApp().equals(WeatherIntent.APP_LOCATION_SERVICE)) {
            LOG.w(TAG, "not CHS, Current location flag on but no weather data avalible");
            WeatherLocation wl = new WeatherLocation();
            wl.setApp(WeatherIntent.APP_LOCATION_SERVICE);
            wl.setCode(WSPUtility.generateWSPReqestForCurrentLocation().toString());
            wl.setName(this.mWidgetContext.getString(R.string.current_location));
            CityInfo cityinfo = new CityInfo();
            cityinfo.index = 0;
            cityinfo.setLocationInfo(wl);
            this.mCurrentCityList.add(cityinfo);
        }
        if (locs != null && locs.length > 0) {
            if (locs[0].getApp() != null && locs[0].getApp().equals(WeatherIntent.APP_LOCATION_SERVICE)) {
                extra = 1;
            }
            for (WeatherLocation loc : locs) {
                if (this.mTerminated) {
                    return false;
                }
                if (this.mCurrentCityList.size() >= this.mTotalCityCount + extra) {
                    break;
                }
                CityInfo cityinfo2 = new CityInfo();
                cityinfo2.index = this.mCurrentCityList.size();
                if (loc.getState() == null) {
                    loc.setState("");
                }
                if (loc.getCountry() == null) {
                    loc.setCountry("");
                }
                if (loc.getCode() == null || loc.getCode().length() == 0) {
                    cityinfo2.type_ = QUERY_TYPE.GOOGLE_GEOCODE;
                    if (this.mBoolGeocodeCorrected && loc.getApp() != null && loc.getApp().equals(WeatherIntent.APP_LOCATION_SERVICE)) {
                        WeatherUtility.deleteLocation(this.mContext.getContentResolver(), loc.getApp(), Double.valueOf(loc.getLatitude()).doubleValue(), Double.valueOf(loc.getLongitude()).doubleValue());
                        WeatherLocation[] tloc = {new WeatherLocation()};
                        tloc[0] = loc;
                        tloc[0].setLatitude(correctGeocode(loc.getLatitude()));
                        tloc[0].setLongitude(correctGeocode(loc.getLongitude()));
                        WeatherUtility.insertOBLocations(this.mContext.getContentResolver(), WeatherIntent.APP_LOCATION_SERVICE, tloc);
                    }
                    loc.setLatitude(correctGeocode(loc.getLatitude()));
                    loc.setLongitude(correctGeocode(loc.getLongitude()));
                } else {
                    cityinfo2.type_ = QUERY_TYPE.QUERY_CODE_ACCU_WEATHER;
                }
                cityinfo2.setLocationInfo(loc);
                this.mCurrentCityList.add(cityinfo2);
            }
            LOG.d(TAG, "WeatherActivity prepareWeatherProvider(), mCurrentCityList is ready now, mCurrentCityList.size() = " + this.mCurrentCityList.size());
            if (this.mModelListener != null) {
                this.mModelListener.onModelInitialized();
            }
            return true;
        }
        if (this.mModelListener != null) {
            this.mModelListener.onModelInitialized();
        }
        return false;
    }

    public void setModelListener(WeatherModelListener modelListener) {
        this.mModelListener = modelListener;
    }

    private String correctGeocode(String code) {
        int pos = code.indexOf(".");
        if (pos > 0 && code.length() > pos + 7) {
            String str = code.substring(0, pos + 7);
            this.mBoolGeocodeCorrected = true;
            return str;
        }
        return code;
    }

    private class RemoveDataRunnable implements Runnable {
        private String mCountry;
        private String mName;
        private String mState;

        public RemoveDataRunnable(String name, String state, String country) {
            this.mName = name;
            this.mState = state;
            this.mCountry = country;
        }

        @Override // java.lang.Runnable
        public void run() {
            WeatherUtility.deleteLocation(WeatherModel.this.mContext.getContentResolver(), WeatherIntent.WEATHER_PROVIDER_KEYNAME, this.mName, this.mState, this.mCountry);
            Log.i(WeatherModel.TAG, "Complete remove data from DB");
        }
    }

    private class prepareWeatherProviderRunnable implements Runnable {
        public prepareWeatherProviderRunnable() {
        }

        @Override // java.lang.Runnable
        public void run() {
            if (!WeatherModel.this.mTerminated) {
                WeatherModel.this.prepareWeatherProvider();
            }
        }
    }
}
