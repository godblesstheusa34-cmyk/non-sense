package com.htc.widget3d.weather;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.util.Log;
import com.htc.Weather.SoundEffect;
import com.htc.android.rosie.widget.Widget;
import com.htc.util.weather.WSPPData;
import com.htc.util.weather.WSPPUtility;
import com.htc.util.weather.WSPRequest;
import com.htc.util.weather.WSPUtility;
import com.htc.util.weather.WeatherLocation;
import com.htc.util.weather.WeatherUtility;
import com.htc.widget3d.weather.data.City;
import com.htc.widget3d.weather.data.CityInfo;
import com.htc.widget3d.weather.data.DCSResult;
import com.htc.widget3d.weather.data.DayForecast;
import com.htc.widget3d.weather.data.WeatherIntent;
import com.htc.widget3d.weather.data.WeatherModel;
import com.htc.widget3d.weather.util.IconPicker;
import com.htc.widget3d.weather.util.LOG;
import com.htc.widget3d.weather.util.RefreshUtil;
import com.htc.widget3d.weather.util.WeatherUtil;
import java.util.HashMap;
import java.util.Set;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcWeather3DWidget.dex */
public class WeatherWidgetBase extends Widget.Base implements WeatherModel.WeatherModelListener {
    public static final int DO_LOADING_ANIMATION = 2;
    public static final int MAXIMUN_CITY_COUNT = 15;
    public static final String SHARE_PREF_SOUND_EFFECT = "sharepref_sound_effect";
    public static final String SYNC_DATA_CATEGORY = "sync_data_category";
    protected static final String TAG = "WeatherWidgetBase";
    public static final int WHAT_PLAY_SOUND = 0;
    public static final int WHAT_UPDATE_UI = 1;
    public static City.UNIT default_unit;
    public static boolean isPortrait = true;
    public static boolean isSoundEffectEnabled = true;
    public static boolean isWidgetOnScreen = false;
    private HashMap<String, Integer> mCityIndexMap;
    public WeatherModel mModel;
    protected SoundEffect mSoundEffect;
    private DataBroadcastReceiver mDataReceiver = null;
    private Widget.Host.Worker mBaseWorker = null;
    private Handler mainHandler = new Handler() { // from class: com.htc.widget3d.weather.WeatherWidgetBase.1
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0:
                    LOG.i(WeatherWidgetBase.TAG, "MainHandler - WHAT_PLAY_SOUND");
                    WeatherWidgetBase.this.playSound(msg.arg1);
                    break;
                case 1:
                    WeatherWidgetBase.this.updateCityData(msg.arg1);
                    break;
                case 2:
                    LOG.i(WeatherWidgetBase.TAG, "MainHandler - DO_LOADING_ANIMATION");
                    WeatherWidgetBase.this.doLoading(msg.arg1);
                    break;
            }
        }
    };
    private String[] ary = {" .  ", " .. ", " ...", "    "};
    private int arr_index = 0;

    public void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        LOG.i(TAG, "onCreate");
        this.mBaseWorker = getHost().getWorker();
        isPortrait = 1 == getContext().getResources().getConfiguration().orientation;
        DataRunnable dr = new DataRunnable();
        if (this.mBaseWorker != null) {
            this.mBaseWorker.post(dr);
        }
    }

    protected void onDestroy() {
        super.onDestroy();
        if (this.mDataReceiver != null) {
            getHost().getContext().unregisterReceiver(this.mDataReceiver);
            this.mDataReceiver = null;
        }
    }

    protected void createData() {
        LOG.i(TAG, "createData");
        this.mModel = new WeatherModel(getHost().getContext(), getContext(), 15);
        this.mModel.setModelListener(this);
        this.mModel.initialModel();
    }

    protected void initWidget() {
        LOG.i(TAG, "initWidget");
    }

    protected void initData() {
        LOG.i(TAG, "initData");
    }

    protected final void startLoading(int city_idx) {
        LOG.i(TAG, "startLoading,city index =" + city_idx);
        this.arr_index = 0;
        if (this.mainHandler != null) {
            this.mainHandler.removeMessages(2);
            Message msg = this.mainHandler.obtainMessage(2, city_idx, 0);
            this.mainHandler.sendMessageDelayed(msg, 1500L);
        }
    }

    protected final void stopLoading(int city_idx, boolean must_restore) {
        LOG.i(TAG, "stopLoading, city idx=" + city_idx);
        if (this.mainHandler != null) {
            this.mainHandler.removeMessages(2);
            if (must_restore) {
                setRefreshTime(city_idx);
            }
        }
    }

    protected void updateTaskBarInfo(int city_idx, String post_string) {
        LOG.i(TAG, "updateTaskBarInfo parent");
    }

    protected void setRefreshTime(int city_idx) {
        LOG.i(TAG, "setRefreshTime parent");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doLoading(int city_idx) {
        if (this.arr_index >= this.ary.length) {
            this.arr_index = 0;
        }
        if (this.mainHandler != null) {
            Message msg = this.mainHandler.obtainMessage(2, this.ary[this.arr_index]);
            updateTaskBarInfo(city_idx, this.ary[this.arr_index]);
            this.mainHandler.sendMessageDelayed(msg, 1500L);
            this.arr_index++;
        }
    }

    protected void updateCityData(int index) {
        LOG.i(TAG, "updateCurrCity index:" + index);
    }

    protected void startFetchData() {
        LOG.i(TAG, "startFetchData");
        int count = this.mModel.size();
        for (int i = 0; i < count; i++) {
            getCityDataFromAgent(i, false);
        }
        initData();
    }

    private void updateData(int index) {
        getCityDataFromAgent(index, false);
        updateCityData(index);
    }

    public void initDataReceiver() {
        LOG.d(TAG, "initDataReceiver, Add current");
        IntentFilter statusIntentFilter = new IntentFilter();
        statusIntentFilter.addAction("com.htc.sync.provider.weather.result");
        statusIntentFilter.addCategory(TAG);
        if (this.mCityIndexMap == null) {
            this.mCityIndexMap = new HashMap<>();
        }
        this.mCityIndexMap.clear();
        int size = this.mModel == null ? 0 : this.mModel.size();
        LOG.i(TAG, "mModel.size() = " + size);
        for (int i = 0; i < size; i++) {
            String code = this.mModel.get(i).genCode();
            statusIntentFilter.addCategory(code);
            this.mCityIndexMap.put(code, Integer.valueOf(i));
            LOG.w(TAG, " register code, " + i + " = " + code);
        }
        statusIntentFilter.addCategory("1__");
        if (this.mDataReceiver != null) {
            getHost().getContext().unregisterReceiver(this.mDataReceiver);
            this.mDataReceiver = null;
        }
        if (this.mDataReceiver == null) {
            this.mDataReceiver = new DataBroadcastReceiver();
        }
        getHost().getContext().registerReceiver(this.mDataReceiver, statusIntentFilter);
    }

    public void releaseSoundEffect() {
        if (this.mainHandler != null) {
            this.mainHandler.removeMessages(0);
        }
        if (this.mSoundEffect != null) {
            this.mSoundEffect.releaseMediaPalyer();
        }
    }

    protected void playSoundEffect(int id) {
        if (isWidgetOnScreen) {
            if (this.mSoundEffect == null) {
                this.mSoundEffect = new SoundEffect(getHost().getContext());
                try {
                    isSoundEffectEnabled = Settings.System.getBoolean(getHost().getContext().getContentResolver(), SoundEffect.SETTING_KEY_SYNC_SOUND);
                } catch (Settings.SettingNotFoundException e) {
                    e.printStackTrace();
                }
                this.mSoundEffect.setSoundOn(isSoundEffectEnabled);
            }
            this.mainHandler.removeMessages(0);
            this.mainHandler.sendMessageDelayed(this.mainHandler.obtainMessage(0, id, 0), 600L);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void playSound(int id) {
        if (isSoundEffectEnabled && this.mSoundEffect != null) {
            this.mSoundEffect.releaseMediaPalyer();
            this.mSoundEffect.startMediaPlayer(id);
        }
    }

    protected void getCityDataFromAgent(int index, boolean bForceUpdate) {
        LOG.d(TAG, "getCityDataFromAgent");
        CityInfo cityinfo = this.mModel.get(index);
        boolean isNetworkActive = WeatherUtil.isNetworkActive(getHost().getContext());
        try {
            WSPRequest req = WeatherUtil.makeRequest(cityinfo);
            if (req != null) {
                if (bForceUpdate) {
                    if (!isNetworkActive) {
                        stopLoading(index, true);
                        return;
                    } else {
                        WSPUtility.triggerSyncService(getContext(), "sync_data_category", new WSPRequest[]{req});
                        return;
                    }
                }
                LOG.d(TAG, "bForceUpdate=" + bForceUpdate + " WSPPUtility.request()");
                WSPPData data = WSPPUtility.request(getContext(), req);
                if (data != null) {
                    DCSResult ret = new DCSResult(data);
                    if (cityinfo.getCity().update_time != ret.getUpdateTime()) {
                        cityinfo.setUpdateTime(ret.getUpdateTime());
                        if (cityinfo.getLocationInfo().getApp().equals(WeatherIntent.APP_LOCATION_SERVICE)) {
                            LOG.d(TAG, "update Current location city name");
                            String[] pkgname = {WeatherIntent.APP_LOCATION_SERVICE, WeatherIntent.WEATHER_PROVIDER_KEYNAME};
                            WeatherLocation[] locs = WeatherUtility.loadMultiAppLocationsFilterByApp(getHost().getContext().getContentResolver(), pkgname);
                            if (locs[0] != null && locs[0].getApp().equals(WeatherIntent.APP_LOCATION_SERVICE)) {
                                cityinfo.displayName = locs[0].getName();
                            }
                        }
                        getCityCache(ret, index);
                        return;
                    }
                    return;
                }
                LOG.d(TAG, "no cache data in Agent for index " + index);
            }
        } catch (Exception e) {
            e.printStackTrace();
            LOG.w(TAG, "above exception has been catched");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void parseDataPacket(Intent intent, int index) {
        if (this.mModel != null && this.mModel.size() > 0 && intent != null) {
            LOG.d(TAG, "parseDataPacket , index = " + index);
            CityInfo cityinfo = this.mModel.get(index);
            try {
                WSPPData data = intent.getParcelableExtra("data");
                if (data != null) {
                    DCSResult ret = new DCSResult(data);
                    if (cityinfo == null || ret == null) {
                        Log.e(TAG, "parseDataPacket, cinfo=" + cityinfo + ", ret=" + ret);
                        return;
                    }
                    if (cityinfo.getCity() == null) {
                        Log.e(TAG, "parseDataPacket, cityinfo.getCity()= null");
                        return;
                    }
                    if (cityinfo.getCity().update_time != ret.getUpdateTime()) {
                        cityinfo.setUpdateTime(ret.getUpdateTime());
                        if (cityinfo.getLocationInfo().getApp().equals(WeatherIntent.APP_LOCATION_SERVICE)) {
                            LOG.d(TAG, "update Current location city name");
                            String[] pkgname = {WeatherIntent.APP_LOCATION_SERVICE, WeatherIntent.WEATHER_PROVIDER_KEYNAME};
                            WeatherLocation[] locs = WeatherUtility.loadMultiAppLocationsFilterByApp(getHost().getContext().getContentResolver(), pkgname);
                            if (locs[0] != null && locs[0].getApp().equals(WeatherIntent.APP_LOCATION_SERVICE)) {
                                cityinfo.displayName = locs[0].getName();
                            }
                        }
                        getCityCache(ret, index);
                        this.mainHandler.sendMessage(this.mainHandler.obtainMessage(1, index, 0));
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "error occurred when parseDataPacket");
            }
        }
    }

    private boolean getCityCache(DCSResult ret, int index) {
        if (ret == null || index < 0 || index > this.mModel.size() - 1 || this.mModel.get(index) == null) {
            return false;
        }
        City city = getForecastData(ret);
        if (this.mModel == null || this.mModel.get(index) == null) {
            return false;
        }
        CityInfo ci = this.mModel.get(index);
        ci.setCity(city);
        ci.changeOffsetOfToday(getContext());
        return true;
    }

    private City getForecastData(DCSResult ret) {
        City city = new City();
        city.overdue = false;
        city.update_time = ret.getUpdateTime();
        city.unit = default_unit;
        int count = ret.getTotalForecast();
        for (int i = 0; i < count; i++) {
            DayForecast dayF = new DayForecast();
            if (i == 0) {
                int nCurTemp = ret.getCurrentTempF();
                int nHiTemp = RefreshUtil.safe_parseInt(ret.getForecastHighTemp()[i]);
                int nLoTemp = RefreshUtil.safe_parseInt(ret.getForecastLowTemp()[i]);
                dayF.setCurrentF(nCurTemp);
                if (nCurTemp > nHiTemp) {
                    dayF.setHighF(nCurTemp);
                } else {
                    dayF.setHighF(nHiTemp);
                }
                if (nCurTemp < nLoTemp) {
                    dayF.setLowF(nCurTemp);
                } else {
                    dayF.setLowF(nLoTemp);
                }
                int nCurTemp2 = ret.getCurrentTempC();
                int nHiTemp2 = RefreshUtil.safe_parseInt(ret.getForecastHighTempC(i));
                int nLoTemp2 = RefreshUtil.safe_parseInt(ret.getForecastLowTempC(i));
                dayF.setCurrentC(nCurTemp2);
                if (nCurTemp2 > nHiTemp2) {
                    dayF.setHighC(nCurTemp2);
                } else {
                    dayF.setHighC(nHiTemp2);
                }
                if (nCurTemp2 < nLoTemp2) {
                    dayF.setLowC(nCurTemp2);
                } else {
                    dayF.setLowC(nLoTemp2);
                }
                dayF.setCondition(IconPicker.getConditionText(getContext(), ret.getCurrentIcon()));
                dayF.setForecastIcon(ret.getCurrentIcon());
            } else {
                int nHiTempF = RefreshUtil.safe_parseInt(ret.getForecastHighTempF()[i]);
                int nHiTempC = RefreshUtil.safe_parseInt(ret.getForecastHighTempC()[i]);
                int nLoTempF = RefreshUtil.safe_parseInt(ret.getForecastLowTempF()[i]);
                int nLoTempC = RefreshUtil.safe_parseInt(ret.getForecastLowTempC()[i]);
                dayF.setCurrentF((nHiTempF + nLoTempF) / 2);
                dayF.setCurrentC((nHiTempC + nLoTempC) / 2);
                dayF.setHighF(nHiTempF);
                dayF.setHighC(nHiTempC);
                dayF.setLowF(nLoTempF);
                dayF.setLowC(nLoTempC);
                dayF.setCondition(IconPicker.getConditionText(getContext(), ret.getForecastIcon(i)));
                dayF.setForecastIcon(ret.getForecastIcon(i));
            }
            dayF.setWeekDay(WeatherUtil.getDateString(getContext(), ret.getForecastName(i)));
            dayF.setDate(ret.getForecastDate(i));
            city.current.add(dayF);
        }
        return city;
    }

    protected void onReceiveCurrentCityData() {
    }

    protected void onUpdateCityModelList() {
        LOG.i(TAG, "onUpdateCityList");
    }

    @Override // com.htc.widget3d.weather.data.WeatherModel.WeatherModelListener
    public void onModelInitialized() {
        LOG.i(TAG, "onModelInitialized");
        if (WSPUtility.isTemperatureCelsius(getHost().getContext())) {
            default_unit = City.UNIT._C;
        } else {
            default_unit = City.UNIT._F;
        }
        LOG.d(TAG, "mModel.size()==" + this.mModel.size());
        initDataReceiver();
        initWidget();
        startFetchData();
    }

    public void onModelUpdated() {
        LOG.i(TAG, "onModelUpdated mModel.size()==" + this.mModel.size());
    }

    @Override // com.htc.widget3d.weather.data.WeatherModel.WeatherModelListener
    public void onNetworkNonActive() {
    }

    @Override // com.htc.widget3d.weather.data.WeatherModel.WeatherModelListener
    public void onNetworkRoaming() {
    }

    public class DataBroadcastReceiver extends BroadcastReceiver {
        public DataBroadcastReceiver() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context arg0, Intent intent) {
            LOG.d(WeatherWidgetBase.TAG, "onReceive action:" + intent.getAction());
            String action = intent.getAction();
            if (action.equals("com.htc.sync.provider.weather.result")) {
                LOG.d(WeatherWidgetBase.TAG, "DataBroadcastReceiver onReceive - SYNC_SERVICE_RESULT_INTENT_ACTION_NAME");
                Set<String> categories = intent.getCategories();
                if (categories != null && categories.size() != 0) {
                    String[] s = new String[categories.size()];
                    categories.toArray(s);
                    String category = s[0];
                    Integer index = (Integer) WeatherWidgetBase.this.mCityIndexMap.get(category);
                    LOG.d(WeatherWidgetBase.TAG, "category: " + category + " index: " + index);
                    if (index != null) {
                        ParseDataPacket pd = WeatherWidgetBase.this.new ParseDataPacket(intent, index.intValue());
                        if (WeatherWidgetBase.this.mBaseWorker != null) {
                            WeatherWidgetBase.this.mBaseWorker.post(pd);
                            return;
                        } else {
                            LOG.e(WeatherWidgetBase.TAG, "mBaseWorker null, can't post.");
                            return;
                        }
                    }
                    if (category != null && category.equals("1__")) {
                        LOG.d(WeatherWidgetBase.TAG, "Receive TYPE_CURRENT_LOCATION data intent");
                        WeatherWidgetBase.this.onUpdateCityModelList();
                    } else {
                        LOG.e(WeatherWidgetBase.TAG, "mCityIndexMap.get(category) ==null");
                    }
                }
            }
        }
    }

    class ParseDataPacket implements Runnable {
        int idx;
        Intent mIntent;

        public ParseDataPacket(Intent intent, int index) {
            this.mIntent = intent;
            this.idx = index;
        }

        @Override // java.lang.Runnable
        public void run() {
            WeatherWidgetBase.this.parseDataPacket(this.mIntent, this.idx);
        }
    }

    class DataRunnable implements Runnable {
        DataRunnable() {
        }

        @Override // java.lang.Runnable
        public void run() {
            WeatherWidgetBase.this.createData();
        }
    }
}
