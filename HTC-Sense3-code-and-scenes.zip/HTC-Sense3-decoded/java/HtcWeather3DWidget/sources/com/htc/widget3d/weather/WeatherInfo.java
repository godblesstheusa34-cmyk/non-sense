package com.htc.widget3d.weather;

import com.htc.fusion.fx.FxScene;

/* compiled from: Weather4x4Widget.java */
/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcWeather3DWidget.dex */
class WeatherInfo {
    public String[] arrControlName;
    public String[] arrHLTemperature;
    public FxScene[] arrSceneWeather;
    public String[] arrWeekDay;
    public boolean hasData;
    public String mCity;
    public String mCurControlName;
    public String mCurHitemp;
    public String mCurLowtemp;
    public FxScene mCurSceneWeather;
    public String mCurTemp;
    public String mDescription;
    public int[] mForecastIcon;
    public int mIndex;
    public int mMainIcon;
    public String mPageNumber;
    public String mUpdateTime;

    WeatherInfo() {
    }
}
