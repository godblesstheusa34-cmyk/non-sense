package com.htc.widget3d.weather.data;

import android.content.Context;
import android.text.format.Time;
import com.htc.widget3d.weather.util.LOG;
import com.htc.widget3d.weather.util.RefreshUtil;
import java.util.ArrayList;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcWeather3DWidget.dex */
public class City {
    private static final long ONE_DAY_MILLIS = 86400000;
    private static final String TAG = "City";
    public long update_time = 0;
    public UNIT unit = UNIT._F;
    public MODE mode = MODE.DayLight;
    public boolean overdue = false;
    public int todayIndex = 0;
    public Condition current = new Condition();
    public Condition updated = new Condition();

    public enum MODE {
        DayLight,
        Night
    }

    public enum UNIT {
        _F,
        _C
    }

    public class Condition {
        private ArrayList<DayForecast> days = new ArrayList<>();

        public Condition() {
            reset();
        }

        public int size() {
            return this.days.size();
        }

        public DayForecast get(int index) {
            int size = size();
            if (index < 0 || index >= size) {
                return null;
            }
            return this.days.get(index);
        }

        public DayForecast today() {
            int size = size();
            if (size == 0) {
                return null;
            }
            if (City.this.todayIndex < 0) {
                City.this.todayIndex = 0;
            } else if (City.this.todayIndex >= size) {
                City.this.todayIndex = size - 1;
            }
            LOG.d(City.TAG, "today index:" + City.this.todayIndex + " total:" + size);
            return this.days.get(City.this.todayIndex);
        }

        public void reset() {
            this.days.clear();
        }

        public void add(DayForecast forecast) {
            this.days.add(forecast);
        }
    }

    public boolean changeTodayIndex(Context context, String timezoneId) {
        if (this.current == null) {
            return false;
        }
        int nCount = this.current.size();
        if (nCount == 0) {
            return false;
        }
        DayForecast forecast = this.current.get(0);
        if (forecast != null) {
            int nOffset = 0;
            if (RefreshUtil.isOverdue(context, this.update_time)) {
                int nOffset2 = beforeToday(forecast.getDate(), timezoneId);
                nOffset = Math.min(nOffset2, this.current.size() - 1);
            }
            if (this.todayIndex != nOffset) {
                this.todayIndex = nOffset;
                return true;
            }
        }
        return false;
    }

    private static Time getTimeObject(String date, String timezoneId) {
        int y = 1900;
        int m = 1;
        int d = 1;
        ArrayList<String> keywords = new ArrayList<>();
        String[] arr$ = date.split("/");
        for (String k : arr$) {
            if (!k.equals("")) {
                keywords.add(k);
            }
        }
        try {
            if (keywords.size() > 0) {
                m = Integer.valueOf(keywords.get(0)).intValue();
            }
            if (keywords.size() > 1) {
                d = Integer.valueOf(keywords.get(1)).intValue();
            }
            if (keywords.size() > 2) {
                y = Integer.valueOf(keywords.get(2)).intValue();
            }
        } catch (Exception e) {
            LOG.e(TAG, "the format of date is not mm/dd/yy..." + date);
        }
        keywords.clear();
        Time t = new Time();
        if (timezoneId != null && timezoneId.length() > 0) {
            t.switchTimezone(timezoneId);
        }
        t.set(d, m - 1, y);
        return t;
    }

    public static int beforeToday(String date, String timezoneId) {
        try {
            Time tObject = getTimeObject(date, timezoneId);
            Time tNow = new Time();
            tNow.setToNow();
            if (timezoneId != null && timezoneId.length() > 0) {
                tNow.switchTimezone(timezoneId);
            }
            LOG.d(TAG, "now is " + tNow.hour + "h:" + tNow.minute + "m:" + tNow.second + "s, timezone:" + timezoneId);
            long t = tObject.toMillis(false);
            long tn = tNow.toMillis(false);
            long r = ((((tNow.hour * 60) + tNow.minute) * 60) + tNow.second) * 1000;
            long today = tn - r;
            int daysBetween = (int) ((today - t) / ONE_DAY_MILLIS);
            if (daysBetween < 0) {
                return 0;
            }
            return daysBetween;
        } catch (Exception e) {
            e.printStackTrace();
            LOG.e(TAG, "some error in compare2Today with " + date);
            return 0;
        }
    }
}
