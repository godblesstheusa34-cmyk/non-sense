package com.htc.widget3d.weather.util;

import android.content.Context;
import android.provider.Settings;
import android.text.format.DateFormat;
import android.text.format.Time;
import com.htc.util.weather.WSPUtility;
import com.htc.widget3d.weather.R;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcWeather3DWidget.dex */
public class RefreshUtil {
    private static String timeString_;

    public RefreshUtil(Context c) {
    }

    public static String getUpdateString(Context c, long time) {
        calculate(c, time);
        return timeString_;
    }

    private static String getDateString(Context c, long time) {
        CharSequence currentFormat = Settings.System.getString(c.getContentResolver(), "date_format_short");
        if (currentFormat == null || currentFormat.length() == 0) {
            currentFormat = "MM/dd/yy";
        }
        CharSequence dateFormat = DateFormat.format(currentFormat, time);
        if (dateFormat == null) {
            return "";
        }
        String date = dateFormat.toString();
        return date;
    }

    private static String getTimeString(Context c, long time) {
        String str = getDateString(c, time) + " " + getTimeStringHM(c, time);
        return str;
    }

    public static String getTimeStringHM(Context c, long time) {
        return DateFormat.getTimeFormat(c).format(Long.valueOf(time));
    }

    public static boolean needAutoUpdate(long time) {
        long current_time = System.currentTimeMillis();
        long diff_time = current_time - time;
        long j = diff_time % 3600000;
        long quotient = (long) (diff_time / 3600000.0f);
        return quotient >= 3;
    }

    public static long getReminderTime(long time) {
        long current_time = System.currentTimeMillis();
        long diff_time = current_time - time;
        long remainder = 10800000 - diff_time;
        return remainder;
    }

    private static void calculate(Context c, long time) {
        Time tNow = new Time();
        tNow.setToNow();
        long tn = tNow.toMillis(false);
        long r = (((((tNow.hour * 60) + tNow.minute) * 60) + tNow.second) * 1000) + (tn % 1000);
        long today_00 = tn - r;
        if (time < today_00 && time >= today_00 - 86400000) {
            timeString_ = c.getString(R.string.yesterday_ago) + " " + getTimeStringHM(c, time);
        } else if (time >= today_00 && time < today_00 + 86400000) {
            timeString_ = getTimeStringHM(c, time);
        } else {
            timeString_ = getTimeString(c, time);
        }
    }

    public static int safe_parseInt(String str) {
        int val = 0;
        if (str == null) {
            return 0;
        }
        try {
            val = Integer.parseInt(str);
        } catch (NumberFormatException e) {
        }
        return val;
    }

    public static boolean isOverdue(Context context, long lastUpdateTime) {
        long interval = 10800000;
        boolean bAutoSync = WSPUtility.isSyncAutomatically(context);
        if (bAutoSync) {
            interval = safe_parseInt(Settings.System.getString(context.getContentResolver(), "com.htc.sync.provider.weather.setting.autosyncfrequency"));
        }
        long current_time = System.currentTimeMillis();
        return current_time < lastUpdateTime || current_time - lastUpdateTime >= interval;
    }

    public static boolean isAutoOverdue(Context context, long lastUpdateTime) {
        boolean bAutoSync = WSPUtility.isSyncAutomatically(context);
        if (!bAutoSync) {
            return false;
        }
        if (lastUpdateTime == 0) {
            return true;
        }
        long interval = safe_parseInt(Settings.System.getString(context.getContentResolver(), "com.htc.sync.provider.weather.setting.autosyncfrequency"));
        long current_time = System.currentTimeMillis();
        return current_time - lastUpdateTime >= interval;
    }
}
