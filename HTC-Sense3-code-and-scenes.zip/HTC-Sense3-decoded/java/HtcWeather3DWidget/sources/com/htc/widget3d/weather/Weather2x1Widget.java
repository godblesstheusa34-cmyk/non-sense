package com.htc.widget3d.weather;

import android.os.Bundle;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcWeather3DWidget.dex */
public class Weather2x1Widget extends Weather2x2Widget {
    @Override // com.htc.widget3d.weather.Weather2x2Widget, com.htc.widget3d.weather.WeatherWidgetBaseMed
    public void onCreate(Bundle savedState) {
        this.SZ_DEFAULT_M10PATH = "scenes/Weather_2x1.m10";
        this.SZ_DEFAULT_M10PATH_LAND = "scenes/Weather_2x1_land.m10";
        this.mWidgetID = 3;
        super.onCreate(savedState);
    }
}
