package com.htc.widget3d.weather.util;

import android.util.Log;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcWeather3DWidget.dex */
public class LOG {
    public static boolean DEBUG = false;

    public static void v(String TAG, String Info) {
        if (DEBUG) {
            Log.v(TAG, Info);
        }
    }

    public static void w(String TAG, String Info) {
        if (DEBUG) {
            Log.w(TAG, Info);
        }
    }

    public static void i(String TAG, String Info) {
        if (DEBUG) {
            Log.i(TAG, Info);
        }
    }

    public static void d(String TAG, String Info) {
        if (DEBUG) {
            Log.d(TAG, Info);
        }
    }

    public static void e(String TAG, String Info) {
        Log.e(TAG, Info);
    }
}
