package com.htc.widget3d.weather;

/* compiled from: Weather2x2Widget.java */
/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcWeather3DWidget.dex */
class WeatherInfo2x2 {
    public int condition;
    public String curHitemp;
    public String curLowTemp;
    public String szCity;
    public String szCurTemp;
    public String szDescription;

    WeatherInfo2x2() {
    }
}
