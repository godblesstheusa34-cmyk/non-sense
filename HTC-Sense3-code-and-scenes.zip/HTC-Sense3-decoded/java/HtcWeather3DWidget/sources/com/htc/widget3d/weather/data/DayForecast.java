package com.htc.widget3d.weather.data;

import com.htc.widget3d.weather.WeatherWidgetBase;
import com.htc.widget3d.weather.data.City;
import com.htc.widget3d.weather.util.LOG;
import com.htc.widget3d.weather.util.RefreshUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcWeather3DWidget.dex */
public class DayForecast {
    private String cityLocalTime_;
    private String date_;
    private String[] hourlyIcon_;
    private int[] hourlyPrecipPercent_;
    private String[] hourlyPrecip_;
    private String[] hourlyTime_;
    private int[] hourlytempC_;
    private int[] hourlytempF_;
    private String humi_;
    private String nightCondition_;
    private String nightForecaseIcon_;
    private String nightPrecip_;
    private int nightRealfeelTempC_;
    private int nightRealfeelTempF_;
    private int nightTempC_;
    private int nightTempF_;
    private String precip_;
    private int realFeelC_;
    private int realFeelF_;
    private String sunrise_;
    private String sunset_;
    private String visibility_;
    private String windspeed_;
    private int currentF_ = 0;
    private int highF_ = 0;
    private int lowF_ = 0;
    private int currentC_ = 0;
    private int highC_ = 0;
    private int lowC_ = 0;
    private String condition_ = null;
    private String day_ = null;
    private String forecastIcon_ = null;

    public void setHourlyTempF(int[] temp) {
        this.hourlytempF_ = temp;
    }

    public void setHourlyTempC(int[] temp) {
        this.hourlytempC_ = temp;
    }

    public int[] getHourlyTemp() {
        return WeatherWidgetBase.default_unit == City.UNIT._C ? this.hourlytempC_ : this.hourlytempF_;
    }

    public String[] getHourlyIcon() {
        return this.hourlyIcon_;
    }

    public void setHourlyIcon(String[] hourlyIcon) {
        this.hourlyIcon_ = hourlyIcon;
    }

    public String[] getHourlyTime() {
        return this.hourlyTime_;
    }

    public void setHourlyTime(String[] hourlyTime) {
        this.hourlyTime_ = hourlyTime;
    }

    public String[] getHourlyPrecip() {
        return this.hourlyPrecip_;
    }

    public int[] getHourlyPrecipPercent() {
        return this.hourlyPrecipPercent_;
    }

    public void setHourlyPrecip(String[] hourlyPrecip) {
        this.hourlyPrecip_ = hourlyPrecip;
        this.hourlyPrecipPercent_ = new int[this.hourlyPrecip_.length];
        for (int i = 0; i < this.hourlyPrecipPercent_.length; i++) {
            float precip = Float.parseFloat(this.hourlyPrecip_[i]);
            int percent = (int) (100.0f * precip);
            this.hourlyPrecipPercent_[i] = percent;
        }
    }

    public int getMaxHourTemp() {
        int maxT = 0;
        int[] arr$ = getHourlyTemp();
        for (int t : arr$) {
            if (t > maxT) {
                maxT = t;
            }
        }
        return maxT;
    }

    public int getMaxHourPrecip() {
        int maxP = 0;
        int[] arr$ = getHourlyPrecipPercent();
        for (int t : arr$) {
            if (t > maxP) {
                maxP = t;
            }
        }
        return maxP;
    }

    public int getMinHourTemp() {
        int minT = getHourlyTemp()[0];
        int[] arr$ = getHourlyTemp();
        for (int t : arr$) {
            if (t < minT) {
                minT = t;
            }
        }
        return minT;
    }

    public int getMinHourPrecip() {
        int minP = getHourlyPrecipPercent()[0];
        int[] arr$ = getHourlyPrecipPercent();
        for (int t : arr$) {
            if (t < minP) {
                minP = t;
            }
        }
        return minP;
    }

    public void setCurrentF(int val) {
        this.currentF_ = val;
    }

    public void setCurrentC(int val) {
        this.currentC_ = val;
    }

    public int getCurrent() {
        LOG.d("WeatherWidgetBase", "(WeatherModel.default_unit == UNIT._C) = " + (WeatherModel.default_unit == City.UNIT._C));
        LOG.d("WeatherWidgetBase", "getCurrent() currentC_=" + this.currentC_ + "  currentF_=" + this.currentF_);
        if (WeatherWidgetBase.default_unit == City.UNIT._C) {
            return this.currentC_;
        }
        return this.currentF_;
    }

    public int getCurrent(City.UNIT unit) {
        return unit == City.UNIT._C ? this.currentC_ : this.currentF_;
    }

    private int calculateTemperature(int val) {
        return Math.round(((val - 32.0f) * 5.0f) / 9.0f);
    }

    public void setHighF(int val) {
        this.highF_ = val;
    }

    public void setHighC(int val) {
        this.highC_ = val;
    }

    public int getHigh() {
        return WeatherWidgetBase.default_unit == City.UNIT._C ? this.highC_ : this.highF_;
    }

    public int getHigh(City.UNIT unit) {
        return unit == City.UNIT._C ? this.highC_ : this.highF_;
    }

    public void setLowF(int val) {
        this.lowF_ = val;
    }

    public void setLowC(int val) {
        this.lowC_ = val;
    }

    public int getLow() {
        return WeatherWidgetBase.default_unit == City.UNIT._C ? this.lowC_ : this.lowF_;
    }

    public int getLow(City.UNIT unit) {
        return unit == City.UNIT._C ? this.lowC_ : this.lowF_;
    }

    public void setWeekDay(String day) {
        this.day_ = day;
    }

    public String getWeekDay() {
        return this.day_;
    }

    public void setDate(String date) {
        this.date_ = date;
    }

    public String getDate() {
        return this.date_;
    }

    public void setCondition(String condition) {
        this.condition_ = condition;
    }

    public String getCondition() {
        return this.condition_;
    }

    public void setForecastIcon(String icon) {
        this.forecastIcon_ = icon;
    }

    public int getForecastIcon() {
        return RefreshUtil.safe_parseInt(this.forecastIcon_);
    }

    public String getForecastIconStr() {
        return this.forecastIcon_;
    }

    public String getCityLocalTime() {
        if (this.cityLocalTime_ == null) {
            return "";
        }
        String h = this.cityLocalTime_.split(":")[0];
        String m = this.cityLocalTime_.split(":")[1];
        String ap = Integer.parseInt(h) > 12 ? "PM" : "AM";
        String ftime = (Integer.parseInt(h) % 12) + ":" + m + ap;
        return ftime;
    }

    public void setCityLocalTime(String cityLocalTime_) {
        this.cityLocalTime_ = cityLocalTime_;
    }

    public String getHumi() {
        return this.humi_;
    }

    public String getWindspeed() {
        return this.windspeed_;
    }

    public String getVisibility() {
        return this.visibility_;
    }

    public String getSunrise() {
        return this.sunrise_;
    }

    public String getPrecip() {
        return this.precip_;
    }

    public String getSunset() {
        return this.sunset_;
    }

    public void setPrecip(String precip_) {
        this.precip_ = precip_;
    }

    public void setRealFeelF(int temp) {
        this.realFeelF_ = temp;
    }

    public void setRealFeelC(int temp) {
        this.realFeelC_ = temp;
    }

    public int getRealFeel() {
        return WeatherWidgetBase.default_unit == City.UNIT._C ? this.realFeelC_ : this.realFeelF_;
    }

    public void setHumi(String humi_) {
        this.humi_ = humi_;
    }

    public void setWindspeed(String windspeed_) {
        this.windspeed_ = windspeed_;
    }

    public void setVisibility(String visibility_) {
        this.visibility_ = visibility_;
    }

    public void setSunrise(String sunrise_) {
        this.sunrise_ = sunrise_;
    }

    public void setSunset(String sunset_) {
        this.sunset_ = sunset_;
    }

    public int getNightForecaseIcon() {
        return RefreshUtil.safe_parseInt(this.nightForecaseIcon_);
    }

    public String getNightCondition() {
        return this.nightCondition_;
    }

    public String getNightPrecip() {
        return this.nightPrecip_;
    }

    public void setNightTempF(int temp) {
        this.nightTempF_ = temp;
    }

    public void setNightTempC(int temp) {
        this.nightTempC_ = temp;
    }

    public int getNightTemp() {
        return WeatherWidgetBase.default_unit == City.UNIT._C ? this.nightTempC_ : this.nightTempF_;
    }

    public void setNightRealfeelTempF(int nightRealfeelTemp_) {
        this.nightRealfeelTempF_ = nightRealfeelTemp_;
    }

    public void setNightRealfeelTempC(int nightRealfeelTemp_) {
        this.nightRealfeelTempC_ = nightRealfeelTemp_;
    }

    public int getNightRealfeelTemp() {
        return WeatherWidgetBase.default_unit == City.UNIT._C ? this.nightRealfeelTempC_ : this.nightRealfeelTempF_;
    }

    public void setNightForecaseIcon(String nightForecaseIcon_) {
        this.nightForecaseIcon_ = nightForecaseIcon_;
    }

    public void setNightCondition(String nightCondition_) {
        this.nightCondition_ = nightCondition_;
    }

    public void setNightPrecip(String nightPrecip_) {
        this.nightPrecip_ = nightPrecip_;
    }
}
