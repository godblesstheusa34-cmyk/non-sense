package com.htc.widget3d.weather.util;

import android.R;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.LocationManager;
import android.telephony.TelephonyManager;
import com.htc.util.http.NetworkUtil;
import com.htc.util.weather.WSPRequest;
import com.htc.util.weather.WSPUtility;
import com.htc.util.weather.WeatherLocation;
import com.htc.widget3d.weather.WeatherWidgetBase;
import com.htc.widget3d.weather.data.CityInfo;
import com.htc.widget3d.weather.data.WeatherIntent;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcWeather3DWidget.dex */
public class WeatherUtil {
    private static String PREFS_NAME = WeatherIntent.WEATHER_PACKAGENAME;
    private static final int[] sDaysMedium = {R.string.CndMmi, R.string.CnipMmi, R.string.CnirMmi, R.string.ColpMmi, R.string.ColrMmi, R.string.CwMmi, R.string.DndMmi};
    public static int totalVideoCount = 3;
    public static int count = 0;

    public static void sendBroadcaseIntent(Context context, String action, String extras, int value) {
        Intent intent = new Intent(action);
        intent.putExtra(extras, value);
        context.sendBroadcast(intent);
    }

    public static WSPRequest makeRequest(CityInfo cityinfo) {
        WeatherLocation loc;
        if (cityinfo != null && (loc = cityinfo.getLocationInfo()) != null) {
            if (loc.getApp() != null && loc.getApp().equals(WeatherIntent.APP_LOCATION_SERVICE)) {
                return WSPUtility.generateWSPReqestForCurrentLocation();
            }
            if (loc.getCode() != null && loc.getCode().length() > 0) {
                return WSPUtility.generateWSPRequestForLocCode(loc.getCode());
            }
            if (loc.getLatitude() == null || loc.getLatitude().length() <= 0) {
                return null;
            }
            return WSPUtility.generateWSPRequestForLatitude(loc.getLatitude(), loc.getLongitude());
        }
        return null;
    }

    public static int[] getForecastIconResId(Context context, String[] id) {
        int count2 = id.length;
        int[] ret = new int[count2];
        for (int i = 0; i < count2; i++) {
            ret[i] = IconPicker.getForecastIconId(context, RefreshUtil.safe_parseInt(id[i]));
        }
        return ret;
    }

    public static void saveSharePref(Context context, String key, String value) {
        SharedPreferences.Editor prefs = context.getSharedPreferences(PREFS_NAME, 1).edit();
        prefs.putString(key, value);
        prefs.commit();
    }

    public static String loadSharePref(Context context, String key, String defaultvalue) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, 0);
        String prefix = prefs.getString(key, defaultvalue);
        return prefix;
    }

    public static boolean isCurrentLocation(CityInfo ci) {
        if (ci == null) {
            return false;
        }
        WeatherLocation loc = ci.getLocationInfo();
        return loc != null && loc.getApp().equals(WeatherIntent.APP_LOCATION_SERVICE);
    }

    public static boolean isLocationSettingChecked(Context context) {
        try {
            LocationManager service = (LocationManager) context.getSystemService("location");
            if (!service.isProviderEnabled("network")) {
                if (!service.isProviderEnabled("gps")) {
                    return false;
                }
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean isNetworkActive(Context context) {
        boolean isNetworkAvalible = NetworkUtil.isActiveNetwork(context);
        return isNetworkAvalible;
    }

    public static boolean isNetworkRoaming(Context context) {
        TelephonyManager tm = (TelephonyManager) context.getSystemService("phone");
        if (tm == null) {
            return false;
        }
        boolean isRoaming = tm.isNetworkRoaming();
        return isRoaming;
    }

    public static String getDateString(Context context, String dat) {
        if (dat == null || dat.equals("")) {
            return "";
        }
        int diff = 0;
        if (dat.equalsIgnoreCase("MON") || dat.equalsIgnoreCase("Monday")) {
            diff = 1;
        } else if (dat.equalsIgnoreCase("TUE") || dat.equalsIgnoreCase("Tuesday")) {
            diff = 2;
        } else if (dat.equalsIgnoreCase("WED") || dat.equalsIgnoreCase("Wednesday")) {
            diff = 3;
        } else if (dat.equalsIgnoreCase("THU") || dat.equalsIgnoreCase("Thursday")) {
            diff = 4;
        } else if (dat.equalsIgnoreCase("FRI") || dat.equalsIgnoreCase("Friday")) {
            diff = 5;
        } else if (dat.equalsIgnoreCase("SAT") || dat.equalsIgnoreCase("Saturday")) {
            diff = 6;
        } else if (dat.equalsIgnoreCase("SUN") || dat.equalsIgnoreCase("Sunday")) {
            diff = 0;
        }
        String dayStr = context.getString(sDaysMedium[diff]);
        return dayStr;
    }

    public static String getMainScenePath(int id, boolean isPortrait) {
        if (!isPortrait) {
            switch (id) {
                case 18:
                    break;
                case 31:
                    break;
                case 39:
                    break;
                case 40:
                    break;
            }
            return "01.m10";
        }
        switch (id) {
        }
        return "01.m10";
    }

    public static String getForecastScenePath(int id) {
        switch (id) {
        }
        return "s_01.m10";
    }

    public static String getTimelineControlNameMain(int id) {
        switch (id) {
            case 1:
                return "timeline.01";
            case 2:
                return "timeline.02";
            case 3:
                return "timeline.03";
            case WeatherIntent.RET_SETTING /* 4 */:
                return "timeline.04";
            case WeatherIntent.RET_REARRANGE /* 5 */:
                return "timeline.05";
            case WeatherIntent.RET_WIFISETTING /* 6 */:
                return "timeline.06";
            case WeatherIntent.RET_SETTING_AUTOSYNC /* 7 */:
                return "timeline.07";
            case WeatherIntent.RET_SETTING_TEMPERATURE_SCALE /* 8 */:
                return "timeline.08";
            case WeatherIntent.RET_LOCATION_SETTING /* 9 */:
            case WeatherIntent.RET_DEL_LOCATION /* 10 */:
            case 27:
            case 28:
            default:
                return "";
            case WeatherIntent.RET_DEL_REARRANGE /* 11 */:
                return "timeline.11";
            case 12:
                return "timeline.12";
            case 13:
                return "timeline.13";
            case 14:
                return "timeline.14";
            case WeatherWidgetBase.MAXIMUN_CITY_COUNT /* 15 */:
                return "timeline.15";
            case 16:
                return "timeline.16";
            case 17:
                return "timeline.17";
            case 18:
                return "timeline.18";
            case 19:
                return "timeline.19";
            case 20:
                return "timeline.20";
            case 21:
                return "timeline.21";
            case 22:
                return "timeline.22";
            case 23:
                return "timeline.23";
            case 24:
                return "timeline.24";
            case 25:
                return "timeline.25";
            case 26:
                return "timeline.26";
            case 29:
                return "timeline.29";
            case 30:
                return "timeline.30";
            case 31:
                return "timeline.31";
            case 32:
                return "timeline.32";
            case 33:
                return "timeline.33";
            case 34:
                return "timeline.34";
            case 35:
                return "timeline.35";
            case 36:
                return "timeline.36";
            case 37:
                return "timeline.37";
            case 38:
                return "timeline.38";
            case 39:
                return "timeline.39";
            case 40:
                return "timeline.40";
            case 41:
                return "timeline.41";
            case 42:
                return "timeline.42";
            case 43:
                return "timeline.43";
            case 44:
                return "timeline.44";
        }
    }

    public static String getTimelineControlNameFs(int id) {
        switch (id) {
            case 1:
                return "timeline.s_01";
            case 2:
                return "timeline.s_02";
            case 3:
                return "timeline.s_03";
            case WeatherIntent.RET_SETTING /* 4 */:
                return "timeline.s_04";
            case WeatherIntent.RET_REARRANGE /* 5 */:
                return "timeline.s_05";
            case WeatherIntent.RET_WIFISETTING /* 6 */:
                return "timeline.s_06";
            case WeatherIntent.RET_SETTING_AUTOSYNC /* 7 */:
                return "timeline.s_07";
            case WeatherIntent.RET_SETTING_TEMPERATURE_SCALE /* 8 */:
                return "timeline.s_08";
            case WeatherIntent.RET_LOCATION_SETTING /* 9 */:
            case WeatherIntent.RET_DEL_LOCATION /* 10 */:
            case 27:
            case 28:
            default:
                return "";
            case WeatherIntent.RET_DEL_REARRANGE /* 11 */:
                return "timeline.s_11";
            case 12:
                return "timeline.s_12";
            case 13:
                return "timeline.s_13";
            case 14:
                return "timeline.s_14";
            case WeatherWidgetBase.MAXIMUN_CITY_COUNT /* 15 */:
                return "timeline.s_15";
            case 16:
                return "timeline.s_16";
            case 17:
                return "timeline.s_17";
            case 18:
                return "timeline.s_18";
            case 19:
                return "timeline.s_19";
            case 20:
                return "timeline.s_20";
            case 21:
                return "timeline.s_21";
            case 22:
                return "timeline.s_22";
            case 23:
                return "timeline.s_23";
            case 24:
                return "timeline.s_24";
            case 25:
                return "timeline.s_25";
            case 26:
                return "timeline.s_26";
            case 29:
                return "timeline.s_29";
            case 30:
                return "timeline.s_30";
            case 31:
                return "timeline.s_31";
            case 32:
                return "timeline.s_32";
            case 33:
                return "timeline.s_33";
            case 34:
                return "timeline.s_34";
            case 35:
                return "timeline.s_35";
            case 36:
                return "timeline.s_36";
            case 37:
                return "timeline.s_37";
            case 38:
                return "timeline.s_38";
            case 39:
                return "timeline.s_39";
            case 40:
                return "timeline.s_40";
            case 41:
                return "timeline.s_41";
            case 42:
                return "timeline.s_42";
            case 43:
                return "timeline.s_43";
            case 44:
                return "timeline.s_44";
        }
    }
}
