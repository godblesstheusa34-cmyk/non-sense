package com.htc.widget3d.weather.util;

import android.content.Context;
import com.htc.weather.StateResources;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcWeather3DWidget.dex */
public class IconPicker {
    public static StateResources stateRes = null;

    public static void setResources(Context context) {
        if (stateRes == null) {
            stateRes = new StateResources();
            stateRes.init(context);
        }
    }

    public static int getForecastIconId(Context context, int icon) {
        setResources(context);
        if (stateRes != null) {
            return stateRes.getSmallConditionResourceId(icon);
        }
        return 0;
    }

    public static int getForecastLargeIconId(Context context, int icon) {
        setResources(context);
        if (stateRes != null) {
            return stateRes.getLargeConditionResourceId(icon);
        }
        return 0;
    }

    public static String getConditionText(Context context, String strId) {
        setResources(context);
        return stateRes != null ? stateRes.getConditionText(strId) : "";
    }

    public static void releaseResources() {
        if (stateRes != null) {
            stateRes.clear();
        }
        stateRes = null;
    }
}
