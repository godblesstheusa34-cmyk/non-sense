package com.htc.widget3d.weather;

import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.SpannableString;
import android.text.style.ImageSpan;
import android.util.Log;
import com.htc.android.rosie.widget.Widget;
import com.htc.android.rosie.widget.WidgetHelper;
import com.htc.fusion.fx.FxObject;
import com.htc.fusion.fx.FxPlaybackInfo;
import com.htc.fusion.fx.FxScene;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.IMessageSource;
import com.htc.fusion.fx.Marker;
import com.htc.fusion.fx.MessageListener;
import com.htc.fusion.fx.controls.FxButton;
import com.htc.fusion.fx.controls.FxDynamicImage;
import com.htc.fusion.fx.controls.FxHitbox;
import com.htc.fusion.fx.controls.FxSceneContainer;
import com.htc.fusion.fx.controls.FxTextLabel;
import com.htc.widget3d.weather.data.City;
import com.htc.widget3d.weather.data.CityInfo;
import com.htc.widget3d.weather.data.DayForecast;
import com.htc.widget3d.weather.data.WeatherIntent;
import com.htc.widget3d.weather.util.LOG;
import com.htc.widget3d.weather.util.RefreshUtil;
import com.htc.widget3d.weather.util.WeatherUtil;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Set;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcWeather3DWidget.dex */
public class Weather4x4Widget extends WeatherWidgetBase {
    private static final String ASSET_FORECAST_M10PATH = "scenes/forecast_state/";
    private static final String ASSET_MAIN_M10PATH = "scenes/main_state/";
    private static final String SDCARD_FORECAST_M10PATH = "/sdcard/fusion_m10/forecast_state/";
    private static final String SDCARD_MAIN_M10PATH = "/sdcard/fusion_m10/main_state/";
    private static final String SZ_DEFAULT_M10PATH = "scenes/";
    private static final String TAG = Weather4x4Widget.class.getSimpleName();
    private FxScene landScene;
    private FxTimelineControl mBackground;
    private FxTimelineControl mBackgroundInOut;
    private FxTimelineControl mCouldyFly;
    public int mCurrIndex;
    private WeatherControl mFxCurWeatherCtr;
    private WeatherControl mFxNextWeatherCtr;
    private GetFxControls mGetFxControls;
    private InitModel mInitModelRunnable;
    private InitWeatherInfo mInitWeatherInfoRunnable;
    private int mNextIndex;
    private MessageListener<FxPlaybackInfo> mPlaybackListener;
    private MessageListener<FxHitbox.SwipeParameters> mSwipeListener;
    private MessageListener<FxHitbox.TapParameters> mTapListener;
    private UpdatePlayWeatherInfo mUpdatePlayWeatherInfoRunnable;
    private UpdateWeatherInfo mUpdateWeatherInfoRunnable;
    private UpdatedCurrentCity mUpdatedCurrentCityRunnable;
    private ArrayList<WeatherInfo> mWeatherInfoList;
    protected Widget.Host.Worker mWorker;
    private FxTimelineControl m_TimelineTilt;
    private boolean m_bSwipeCity;
    private FxScene m_fxScene;
    private FxHitbox m_hitBox;
    private int m_nTiltEndFrame;
    private int m_nTiltStartFrame;
    private FxScene portScene;
    private int WEATHER_COUNT = 3;
    private int numberOfForecaseDay = 4;
    private final int DayToNight = 0;
    private final int NightToDay = 1;
    private final int RainToDay = 2;
    private final int DayToRain = 3;
    private final int NightToRain = 4;
    private final int RainToNight = 5;
    private final int _day = 1;
    private final int _night = 2;
    private final int _rain = 3;
    private final Point bg_day_night = new Point(1, 2);
    private final Point bg_day_rain = new Point(1, 3);
    private final Point bg_night_day = new Point(2, 1);
    private final Point bg_night_rain = new Point(2, 3);
    private final Point bg_rain_day = new Point(3, 1);
    private final Point bg_rain_night = new Point(3, 2);
    private final Point bg_night_night = new Point(2, 2);
    private boolean m_bInitial = true;
    private boolean isWeatherDataAvalible = false;
    private boolean isNeedInitState = false;
    private boolean mIsCityChanged = false;
    private boolean m_bAddCity = false;
    private Handler mUIHandler = new Handler();
    private BroadcastReceiver mDataReceiver = new BroadcastReceiver() { // from class: com.htc.widget3d.weather.Weather4x4Widget.4
        @Override // android.content.BroadcastReceiver
        public void onReceive(Context arg0, Intent intent) {
            LOG.d(Weather4x4Widget.TAG, "mDatareceiver received action = " + intent.getAction());
            String action = intent.getAction();
            if (action.equals("com.htc.sync.provider.weather.SETTINGS_UPDATED")) {
                LOG.d(Weather4x4Widget.TAG, "received weather setting changed");
                Set<String> categories = intent.getCategories();
                if (categories.contains("com.htc.sync.provider.weather.setting.temperatureunit")) {
                    String scale = intent.getStringExtra("settingData");
                    WeatherWidgetBase.default_unit = scale.equals("c") ? City.UNIT._C : City.UNIT._F;
                    Weather4x4Widget.this.startFetchData();
                    LOG.d(Weather4x4Widget.TAG, "Temperature cal = " + scale);
                }
                if (categories.contains("com.htc.sync.provider.weather.setting.soundeffect")) {
                    String isPlay = intent.getStringExtra("settingData");
                    WeatherWidgetBase.isSoundEffectEnabled = isPlay.equals("true");
                    if (Weather4x4Widget.this.mSoundEffect != null) {
                        Weather4x4Widget.this.mSoundEffect.setSoundOn(WeatherWidgetBase.isSoundEffectEnabled);
                    }
                    LOG.d(Weather4x4Widget.TAG, "isSoundEffectEnabled == " + WeatherWidgetBase.isSoundEffectEnabled);
                    return;
                }
                return;
            }
            if (action.equals("android.intent.action.TIME_SET")) {
                Log.d(Weather4x4Widget.TAG, "OnReceive -Time format Change");
                Weather4x4Widget.this.resetUpdateTime();
                return;
            }
            LOG.d(Weather4x4Widget.TAG, "set mIsCityChanged = true");
            Weather4x4Widget.this.mIsCityChanged = true;
            if (action.equals(WeatherIntent.ADD_LOCATION_CHANGED)) {
                Weather4x4Widget.this.m_bAddCity = true;
            } else {
                Weather4x4Widget.this.m_bAddCity = false;
            }
        }
    };

    @Override // com.htc.widget3d.weather.WeatherWidgetBase
    public void onCreate(Bundle saved) {
        super.onCreate(saved);
        LOG.d(TAG, "onCreate");
        this.mWorker = getHost().getWorker();
        this.portScene = getHost().createScene("scenes/Weather_4x4.m10", true);
        this.landScene = getHost().createScene("scenes/Weather_4x4_land.m10", true);
        this.mGetFxControls = new GetFxControls();
        postToWorkerThread(this.mGetFxControls);
        this.mInitModelRunnable = new InitModel();
        this.mUpdatedCurrentCityRunnable = new UpdatedCurrentCity();
        IntentFilter dataIntentFilter = new IntentFilter();
        dataIntentFilter.addAction(WeatherIntent.ADD_LOCATION_CHANGED);
        dataIntentFilter.addAction(WeatherIntent.DELETE_LOCATION_CHANGED);
        dataIntentFilter.addAction(WeatherIntent.REARRANGE_LIST_CHANGED);
        dataIntentFilter.addAction("com.htc.sync.provider.weather.SETTINGS_UPDATED");
        dataIntentFilter.addAction("android.intent.action.TIME_SET");
        dataIntentFilter.addCategory("com.htc.sync.provider.weather.setting.soundeffect");
        dataIntentFilter.addCategory("com.htc.sync.provider.weather.setting.temperatureunit");
        getHost().getContext().registerReceiver(this.mDataReceiver, dataIntentFilter);
        LOG.d(TAG, "registerReceiver : mDataReceiver");
    }

    protected void onPause() {
        super.onPause();
        LOG.i(TAG, "onPause");
        isWidgetOnScreen = false;
        if (this.mFxCurWeatherCtr != null && this.mFxCurWeatherCtr.mMainScene != null) {
            this.mFxCurWeatherCtr.mMainScene.stop();
            if (this.mFxCurWeatherCtr.m_TimelineRain != null) {
                this.mFxCurWeatherCtr.m_TimelineRain.stop();
            }
            LOG.i(TAG, "stop Current mMainScene");
        }
        if (this.m_bSwipeCity) {
            if (this.mFxCurWeatherCtr != null && this.mFxNextWeatherCtr != null) {
                this.mFxCurWeatherCtr.stop();
                this.mFxNextWeatherCtr.stop();
                this.mCurrIndex = this.mNextIndex;
                WeatherControl temp = this.mFxCurWeatherCtr;
                this.mFxCurWeatherCtr = this.mFxNextWeatherCtr;
                this.mFxNextWeatherCtr = temp;
                this.mFxNextWeatherCtr.setVisilbe(false);
                this.m_bSwipeCity = false;
                this.mFxCurWeatherCtr.setToIdleState();
                LOG.d(TAG, "Change current and next when pause");
            } else {
                return;
            }
        }
        releaseSoundEffect();
    }

    protected void onResume() {
        CityInfo cityinfo_first;
        super.onResume();
        LOG.i(TAG, "onResume");
        isWidgetOnScreen = true;
        if (this.m_bSwipeCity && this.mFxCurWeatherCtr != null && this.mFxNextWeatherCtr != null) {
            this.mCurrIndex = this.mNextIndex;
            WeatherControl temp = this.mFxCurWeatherCtr;
            this.mFxCurWeatherCtr = this.mFxNextWeatherCtr;
            this.mFxNextWeatherCtr = temp;
            this.mFxCurWeatherCtr.setVisilbe(true);
            this.mFxNextWeatherCtr.setVisilbe(false);
            this.mFxNextWeatherCtr.stop();
            this.m_bSwipeCity = false;
            LOG.d(TAG, "Change current and next when resume ");
        }
        if (this.mFxCurWeatherCtr != null && this.mFxCurWeatherCtr.m_fxTimelineControl != null) {
            this.mFxCurWeatherCtr.m_fxTimelineControl.setVisibility(true);
        }
        if (this.mFxCurWeatherCtr != null && this.mFxCurWeatherCtr.mMainScene != null) {
            LOG.d(TAG, "Resume, Current mainScene isPlaying :" + this.mFxCurWeatherCtr.mMainScene.isPlaying());
            if (!this.mFxCurWeatherCtr.mMainScene.isPlaying()) {
                this.mFxCurWeatherCtr.mMainScene.playMarker(getResString(R.string.marker_LoopIn), 2, 1.0f, true);
                Log.d(TAG, "visibility :" + this.mFxCurWeatherCtr.mMainScene.getVisibility());
                if (this.mFxCurWeatherCtr.m_TimelineRain != null) {
                    this.mFxCurWeatherCtr.m_TimelineRain.setAsync(true);
                    this.mFxCurWeatherCtr.m_TimelineRain.playMarker(getResString(R.string.marker_LoopIn), 1, 1.0f, true);
                }
                LOG.i(TAG, "play Current mMainScene");
            }
        }
        if (this.mIsCityChanged) {
            LOG.d(TAG, "city changed - update citylist , m_bAddCity=" + this.m_bAddCity);
            UpdatedCityList updatedCityListRunnable = new UpdatedCityList(this.m_bAddCity);
            if (this.mUIHandler != null) {
                this.mUIHandler.post(updatedCityListRunnable);
            } else {
                LOG.e(TAG, "mUIHandler null");
            }
            this.mIsCityChanged = false;
            return;
        }
        Date today = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("M/d/yyyy");
        String today_string = formatter.format(today);
        if (this.mModel != null && this.mModel.size() > 0 && (cityinfo_first = this.mModel.get(0)) != null && cityinfo_first.hasWeatherData) {
            String city_date = cityinfo_first.getCity().current.today().getDate();
            if (today_string.equals(city_date)) {
                LOG.d(TAG, "city date match, today =" + today_string + ",City date =" + city_date);
                return;
            }
            LOG.d(TAG, "city date Not match, today =" + today_string + ",City date =" + city_date);
            for (int idx = 0; idx < this.mModel.size(); idx++) {
                CityInfo cityinfo = this.mModel.get(idx);
                if (cityinfo != null && cityinfo.hasWeatherData) {
                    cityinfo.changeOffsetOfToday(getContext());
                }
            }
            if (this.mInitWeatherInfoRunnable == null) {
                this.mInitWeatherInfoRunnable = new InitWeatherInfo();
            }
            postToWorkerThread(this.mInitWeatherInfoRunnable);
            if (this.mUpdatePlayWeatherInfoRunnable == null) {
                this.mUpdatePlayWeatherInfoRunnable = new UpdatePlayWeatherInfo();
            }
            postToWorkerThread(this.mUpdatePlayWeatherInfoRunnable);
        }
    }

    @Override // com.htc.widget3d.weather.WeatherWidgetBase
    protected void onDestroy() {
        super.onDestroy();
        this.mInitModelRunnable = null;
        this.mInitWeatherInfoRunnable = null;
        this.mUpdateWeatherInfoRunnable = null;
        this.mUpdatePlayWeatherInfoRunnable = null;
        this.mUpdatedCurrentCityRunnable = null;
        this.portScene = null;
        this.landScene = null;
        this.mWorker = null;
        getHost().getContext().unregisterReceiver(this.mDataReceiver);
        System.gc();
        LOG.d(TAG, "mem : onDestroy");
    }

    protected void finalize() throws Throwable {
        super.finalize();
        LOG.d(TAG, "mem : finalize called");
    }

    protected FxScene getScene() {
        LOG.d(TAG, "getScene() , isPortrait=" + isPortrait);
        return isPortrait ? this.portScene : this.landScene;
    }

    public void onConfigurationChanged(Configuration newConfiguration) {
        super.onConfigurationChanged(newConfiguration);
        LOG.d(TAG, "onConfigurationChanged");
        isPortrait = 1 == newConfiguration.orientation;
        if (this.mWorker != null) {
            this.mWorker.cancel(this.mGetFxControls);
        } else {
            LOG.d(TAG, "cancel fail cause mWorker null");
        }
    }

    protected void onHostMessage(Message msg) {
        switch (msg.what) {
            case 3:
                if (this.m_bSwipeCity) {
                    if (this.mFxCurWeatherCtr != null && this.mFxNextWeatherCtr != null) {
                        this.mFxCurWeatherCtr.stop();
                        this.mFxNextWeatherCtr.stop();
                        this.mCurrIndex = this.mNextIndex;
                        WeatherControl temp = this.mFxCurWeatherCtr;
                        this.mFxCurWeatherCtr = this.mFxNextWeatherCtr;
                        this.mFxNextWeatherCtr = temp;
                        this.mFxNextWeatherCtr.setVisilbe(false);
                        this.m_bSwipeCity = false;
                        LOG.d(TAG, "Change current and next when switch orientation");
                    } else {
                        return;
                    }
                } else {
                    if (this.mFxCurWeatherCtr != null) {
                        this.mFxCurWeatherCtr.stop();
                    }
                    if (this.mFxNextWeatherCtr != null) {
                        this.mFxNextWeatherCtr.stop();
                    }
                }
                postToWorkerThread(this.mGetFxControls);
                break;
        }
        super.onHostMessage(msg);
    }

    @Override // com.htc.widget3d.weather.WeatherWidgetBase
    protected void initWidget() {
        super.initWidget();
        if (this.mInitWeatherInfoRunnable == null) {
            this.mInitWeatherInfoRunnable = new InitWeatherInfo();
        }
        postToWorkerThread(this.mInitWeatherInfoRunnable);
    }

    @Override // com.htc.widget3d.weather.WeatherWidgetBase
    protected void initData() {
        super.initData();
        LOG.i(TAG, "initData");
        if (this.mModel.size() <= 0) {
            if (this.mModel.size() == 0 && this.mFxCurWeatherCtr != null) {
                this.mFxCurWeatherCtr.setNoCityView();
                getClass();
                playBgTransition(1);
                LOG.i(TAG, "setNoCityView finished and play default background.");
                return;
            }
            return;
        }
        if (this.mUpdatePlayWeatherInfoRunnable == null) {
            this.mUpdatePlayWeatherInfoRunnable = new UpdatePlayWeatherInfo();
        }
        postToWorkerThread(this.mUpdatePlayWeatherInfoRunnable);
    }

    @Override // com.htc.widget3d.weather.WeatherWidgetBase
    protected void onReceiveCurrentCityData() {
        LOG.d(TAG, "onReceiveCurrentCityData");
        if (this.mInitWeatherInfoRunnable == null) {
            this.mInitWeatherInfoRunnable = new InitWeatherInfo();
        }
        postToWorkerThread(this.mInitWeatherInfoRunnable);
        if (this.mUpdateWeatherInfoRunnable == null) {
            this.mUpdateWeatherInfoRunnable = new UpdateWeatherInfo();
        }
        postToWorkerThread(this.mUpdateWeatherInfoRunnable);
        this.mCurrIndex = 0;
        this.mFxCurWeatherCtr.setWeatherInfo(this.mWeatherInfoList.get(this.mCurrIndex));
    }

    @Override // com.htc.widget3d.weather.WeatherWidgetBase
    protected void onUpdateCityModelList() {
        LOG.d(TAG, "onUpdateCityModelList");
        if (isWidgetOnScreen) {
            UpdatedCityList updatedCityListRunnable = new UpdatedCityList(false);
            if (this.mUIHandler != null) {
                this.mUIHandler.post(updatedCityListRunnable);
                return;
            } else {
                LOG.e(TAG, "onUpdateCityModelList - mUIHandler null");
                return;
            }
        }
        this.mIsCityChanged = true;
        LOG.i(TAG, "onUpdateCityModelList - not on Screen.");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void initWeatherInfo() {
        LOG.d(TAG, "initWeatherInfo");
        this.WEATHER_COUNT = this.mModel.size();
        if (this.mWeatherInfoList == null) {
            this.mWeatherInfoList = new ArrayList<>();
        } else {
            this.mWeatherInfoList.clear();
        }
        if (this.WEATHER_COUNT > 0) {
            for (int i = 0; i < this.WEATHER_COUNT; i++) {
                WeatherInfo info = new WeatherInfo();
                info.mIndex = 0;
                info.mCity = "";
                info.mPageNumber = "";
                info.mDescription = "";
                info.mCurTemp = "";
                info.arrWeekDay = new String[this.numberOfForecaseDay];
                info.arrHLTemperature = new String[this.numberOfForecaseDay];
                info.arrSceneWeather = new FxScene[this.numberOfForecaseDay];
                info.arrControlName = new String[this.numberOfForecaseDay];
                info.mCurHitemp = "";
                info.mCurLowtemp = "";
                info.mUpdateTime = "";
                info.mMainIcon = 0;
                info.mForecastIcon = new int[this.numberOfForecaseDay];
                info.mCurSceneWeather = null;
                info.mCurControlName = "";
                info.hasData = false;
                for (int j = 0; j < this.numberOfForecaseDay; j++) {
                    info.arrWeekDay[j] = "";
                    info.arrHLTemperature[j] = "";
                    info.arrSceneWeather[j] = null;
                    info.arrControlName[j] = "";
                }
                this.mWeatherInfoList.add(info);
            }
        }
    }

    public void onTiltChanged(float fTilt) {
        if (this.m_TimelineTilt != null) {
            this.m_TimelineTilt.setFrame(WidgetHelper.convertTiltAngleToFrame(fTilt, this.m_nTiltStartFrame, this.m_nTiltEndFrame));
        }
        if (this.mFxCurWeatherCtr != null) {
            this.mFxCurWeatherCtr.HandleTiltChange(fTilt);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void initWeatherControl() {
        Marker tiltMarker;
        LOG.d(TAG, "InitWeatherControl");
        this.m_fxScene = getScene();
        if (this.m_fxScene == null) {
            LOG.d(TAG, "getScene()==null!");
            return;
        }
        if (this.mFxCurWeatherCtr == null) {
            this.mFxCurWeatherCtr = new WeatherControl();
        }
        if (this.mFxNextWeatherCtr == null) {
            this.mFxNextWeatherCtr = new WeatherControl();
        }
        String[] szArray = {getResString(R.string.timeline_weather_composition_first), getResString(R.string.timeline_weather_composition_sec), getResString(R.string.timeline_weather_bg), getResString(R.string.timeline_weather_bg_inout), getResString(R.string.Cloud_flyThru), getResString(R.string.app_hitbox), "timeline.tilt_footer"};
        FxTimelineControl[] descendants = this.m_fxScene.getDescendants(szArray);
        this.mFxCurWeatherCtr.Init(descendants[0]);
        this.mFxNextWeatherCtr.Init(descendants[1]);
        this.mFxCurWeatherCtr.setVisilbe(true);
        this.mFxNextWeatherCtr.setVisilbe(false);
        this.mBackground = descendants[2];
        this.mBackgroundInOut = descendants[3];
        this.mCouldyFly = descendants[4];
        this.m_hitBox = (FxHitbox) descendants[5];
        this.m_TimelineTilt = descendants[6];
        this.m_nTiltStartFrame = 0;
        this.m_nTiltEndFrame = 0;
        if (this.m_TimelineTilt != null && (tiltMarker = this.m_TimelineTilt.getMarker("tilt")) != null) {
            this.m_nTiltStartFrame = tiltMarker.StartFrame;
            this.m_nTiltEndFrame = tiltMarker.EndFrame;
        }
        playInit();
        if (this.mModel.size() > 0) {
            this.mFxCurWeatherCtr.setWarningMessage(getResString(R.string.nodatamsg));
            this.mFxNextWeatherCtr.setWarningMessage(getResString(R.string.nodatamsg));
        } else {
            String nocity_msg = getResString(R.string.nodatamsg) + "\n" + getResString(R.string.data_request);
            this.mFxCurWeatherCtr.setWarningMessage(nocity_msg);
            this.mFxNextWeatherCtr.setWarningMessage(nocity_msg);
        }
        if (!this.isWeatherDataAvalible) {
            this.mFxCurWeatherCtr.setWarningMsgVisbile(true);
            this.mFxNextWeatherCtr.setWarningMsgVisbile(true);
        }
        if (this.mPlaybackListener == null) {
            this.mPlaybackListener = new MessageListener<FxPlaybackInfo>() { // from class: com.htc.widget3d.weather.Weather4x4Widget.1
                public void onMessageReceived(FxPlaybackInfo message) {
                    LOG.d(Weather4x4Widget.TAG, " NextWeatherControl FxPlaybackInfo.onMessageReceived");
                    if (Weather4x4Widget.this.m_bSwipeCity) {
                        LOG.d(Weather4x4Widget.TAG, " need to do next-current scene switch");
                        Weather4x4Widget.this.mCurrIndex = Weather4x4Widget.this.mNextIndex;
                        WeatherControl temp = Weather4x4Widget.this.mFxCurWeatherCtr;
                        Weather4x4Widget.this.mFxCurWeatherCtr = Weather4x4Widget.this.mFxNextWeatherCtr;
                        Weather4x4Widget.this.mFxNextWeatherCtr = temp;
                        Weather4x4Widget.this.mFxCurWeatherCtr.setVisilbe(true);
                        Weather4x4Widget.this.mFxNextWeatherCtr.setVisilbe(false);
                        Weather4x4Widget.this.mFxNextWeatherCtr.stop();
                        Weather4x4Widget.this.m_bSwipeCity = false;
                    }
                }
            };
        }
        if (this.mFxNextWeatherCtr.getPlaybackCompleteSource() != null) {
            this.mFxNextWeatherCtr.getPlaybackCompleteSource().unbindAll();
        }
        this.mFxNextWeatherCtr.getPlaybackCompleteSource().bind(this.mPlaybackListener);
        setHitBox();
        this.mFxCurWeatherCtr.setRefreshListener();
        this.mFxNextWeatherCtr.setRefreshListener();
        LOG.d(TAG, "InitWeatherControl finished");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String getResString(int id) {
        return getContext().getResources().getString(id);
    }

    private void setHitBox() {
        if (this.m_hitBox == null) {
            LOG.d(TAG, "Control Hitbox.weather == null !!");
            return;
        }
        this.m_hitBox.setEnabledGestures(5);
        this.m_hitBox.setEnabled(true);
        if (this.mSwipeListener == null) {
            this.mSwipeListener = new MessageListener<FxHitbox.SwipeParameters>() { // from class: com.htc.widget3d.weather.Weather4x4Widget.2
                public void onMessageReceived(FxHitbox.SwipeParameters message) {
                    LOG.d(Weather4x4Widget.TAG, "hitBox on Swipe");
                    SwitchWeatherCtl switch_runnable = Weather4x4Widget.this.new SwitchWeatherCtl(message);
                    if (Weather4x4Widget.this.mUIHandler != null) {
                        Weather4x4Widget.this.mUIHandler.post(switch_runnable);
                    } else {
                        Log.e(Weather4x4Widget.TAG, "mUIHandler get null");
                        Weather4x4Widget.this.switchWeatherCtl(message);
                    }
                    LOG.d(Weather4x4Widget.TAG, "post and leave Swipe callback");
                }
            };
        }
        if (this.m_hitBox.getSwipeSource() != null) {
            this.m_hitBox.getSwipeSource().unbindAll();
        }
        this.m_hitBox.getSwipeSource().bind(this.mSwipeListener);
        if (this.mTapListener == null) {
            this.mTapListener = new MessageListener<FxHitbox.TapParameters>() { // from class: com.htc.widget3d.weather.Weather4x4Widget.3
                public void onMessageReceived(FxHitbox.TapParameters message) {
                    LOG.d(Weather4x4Widget.TAG, "hitBox on Tap");
                    Intent intent = new Intent(WeatherIntent.ACTION_INTENT_LOCATE);
                    if (intent != null) {
                        intent.setClassName(WeatherIntent.WEATHER_PACKAGENAME, WeatherIntent.LAUNCHAP_CLASSNAME);
                        intent.putExtra("_city_index", Weather4x4Widget.this.mCurrIndex);
                        CityInfo mCityInfo = Weather4x4Widget.this.mModel.get(Weather4x4Widget.this.mCurrIndex);
                        if (mCityInfo != null) {
                            intent.putExtra("name_", mCityInfo.getCityName());
                            if (mCityInfo.getLocationInfo() != null) {
                                intent.putExtra("app_", mCityInfo.getLocationInfo().getApp());
                            }
                        }
                        intent.addFlags(268435456);
                        intent.addFlags(67108864);
                        try {
                            Weather4x4Widget.this.getContext().startActivity(intent);
                        } catch (ActivityNotFoundException e) {
                            LOG.e(Weather4x4Widget.TAG, "Weather Activity not found");
                        }
                    }
                }
            };
        }
        if (this.m_hitBox.getTapSource() != null) {
            this.m_hitBox.getTapSource().unbindAll();
        }
        this.m_hitBox.getTapSource().bind(this.mTapListener);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void switchWeatherCtl(FxHitbox.SwipeParameters message) {
        LOG.d(TAG, "FxHitbox.SwipeParameters.onMessageReceived");
        if (this.mModel.size() > 0 && this.mWeatherInfoList.size() > 0) {
            if (this.mFxNextWeatherCtr.isPlaying() || this.mFxCurWeatherCtr.isPlaying()) {
                this.mFxCurWeatherCtr.stop();
                this.mFxNextWeatherCtr.stop();
                this.mCurrIndex = this.mNextIndex;
                WeatherControl temp = this.mFxCurWeatherCtr;
                this.mFxCurWeatherCtr = this.mFxNextWeatherCtr;
                this.mFxNextWeatherCtr = temp;
                this.m_bSwipeCity = false;
                LOG.d(TAG, "switch current and next directly.");
            }
            if (message.endPosition.y > message.startPosition.y) {
                this.mNextIndex = ((this.mCurrIndex + this.WEATHER_COUNT) - 1) % this.WEATHER_COUNT;
            } else {
                this.mNextIndex = (this.mCurrIndex + 1) % this.WEATHER_COUNT;
            }
            LOG.d(TAG, "mCurrIndex: " + this.mCurrIndex + " mNextIndex: " + this.mNextIndex + " ,next city: " + this.mWeatherInfoList.get(this.mNextIndex).mCity);
            playSwitchCity();
        }
    }

    private void initBgTrinsition(int id) {
        switch (getWeatherType(id)) {
            case 1:
                getClass();
                playBgTransition(1);
                break;
            case 2:
                getClass();
                playBgTransition(0);
                break;
            case 3:
                getClass();
                playBgTransition(3);
                break;
        }
    }

    private int getWeatherType(int id) {
        LOG.i(TAG, "getWeatherType id: " + id);
        if (id == 12 || id == 13 || id == 14 || id == 18 || id == 36 || id == 19) {
            getClass();
            return 3;
        }
        if (id == 33 || id == 34 || id == 35 || id == 37 || id == 38 || id == 39 || id == 40 || id == 41 || id == 42 || id == 43 || id == 44) {
            getClass();
            return 2;
        }
        getClass();
        return 1;
    }

    private void playBgTransition(int prevId, int currId) {
        int type1 = getWeatherType(prevId);
        int type2 = getWeatherType(currId);
        LOG.d(TAG, "Type1 : " + type1 + " , Type2 : " + type2);
        if (this.bg_day_night.equals(type1, type2)) {
            getClass();
            playBgTransition(0);
            return;
        }
        if (this.bg_day_rain.equals(type1, type2)) {
            getClass();
            playBgTransition(3);
            return;
        }
        if (this.bg_night_day.equals(type1, type2)) {
            getClass();
            playBgTransition(1);
            return;
        }
        if (this.bg_night_rain.equals(type1, type2)) {
            getClass();
            playBgTransition(4);
            return;
        }
        if (this.bg_rain_day.equals(type1, type2)) {
            getClass();
            playBgTransition(2);
            return;
        }
        if (this.bg_rain_night.equals(type1, type2)) {
            getClass();
            playBgTransition(5);
        } else if (this.bg_night_night.equals(type1, type2)) {
            getClass();
            playBgTransition(0);
        } else {
            LOG.d(TAG, "playBgTransition mapping to default!");
            getClass();
            playBgTransition(1);
        }
    }

    private void playBgTransition(int type) {
        switch (type) {
            case 0:
                LOG.i(TAG, "playBg : (1) DayToNight");
                if (this.mBackground != null) {
                    this.mBackground.playMarker(getResString(R.string.marker_DayToNight));
                    break;
                }
                break;
            case 1:
                LOG.i(TAG, "playBg : (3) NightToDay");
                if (this.mBackground != null) {
                    this.mBackground.playMarker(getResString(R.string.marker_NightToDay));
                    break;
                }
                break;
            case 2:
                LOG.i(TAG, "playBg : (5) RainToDay");
                if (this.mBackground != null) {
                    this.mBackground.playMarker(getResString(R.string.marker_RainToDay));
                    break;
                }
                break;
            case 3:
                LOG.i(TAG, "playBg : (2) DayToRain");
                if (this.mBackground != null) {
                    this.mBackground.playMarker(getResString(R.string.marker_DayToRain));
                    break;
                }
                break;
            case WeatherIntent.RET_SETTING /* 4 */:
                LOG.i(TAG, "playBg : (4) NightToRain");
                if (this.mBackground != null) {
                    this.mBackground.playMarker(getResString(R.string.marker_NightToRain));
                    break;
                }
                break;
            case WeatherIntent.RET_REARRANGE /* 5 */:
                LOG.i(TAG, "playBg : (6) RainToNight");
                if (this.mBackground != null) {
                    this.mBackground.playMarker(getResString(R.string.marker_RainToNight));
                    break;
                }
                break;
        }
    }

    private void playInit() {
        if (this.mCouldyFly != null) {
            if (this.mBackgroundInOut != null) {
                this.mBackgroundInOut.playMarker("In");
            }
            if (isWidgetOnScreen) {
                this.mCouldyFly.playMarker(getResString(R.string.marker_Transition));
            }
            if (this.mFxCurWeatherCtr != null) {
                this.mFxCurWeatherCtr.playMarker(getResString(R.string.marker_Build));
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void playCurrUI() {
        if (this.mWeatherInfoList != null && this.mWeatherInfoList.size() > 0 && this.mFxCurWeatherCtr != null && this.mFxNextWeatherCtr != null) {
            LOG.d(TAG, "playCurrUI(), mCurrIndex=" + this.mCurrIndex);
            initBgTrinsition(this.mWeatherInfoList.get(this.mCurrIndex).mMainIcon);
            this.mFxCurWeatherCtr.setVisilbe(true);
            this.mFxNextWeatherCtr.setVisilbe(false);
            this.mFxCurWeatherCtr.setWeatherInfo(this.mWeatherInfoList.get(this.mCurrIndex));
            this.mFxCurWeatherCtr.playMainInAnimation();
            this.mFxCurWeatherCtr.playForecastInAnimation();
        }
    }

    @Override // com.htc.widget3d.weather.WeatherWidgetBase
    protected void updateCityData(int index) {
        if (this.mCurrIndex != index || this.mCurrIndex != this.mNextIndex) {
            if (this.mUpdateWeatherInfoRunnable == null) {
                this.mUpdateWeatherInfoRunnable = new UpdateWeatherInfo();
            }
            postToWorkerThread(this.mUpdateWeatherInfoRunnable);
            LOG.d(TAG, "updateCityData(" + index + "), mCurrIndex=" + this.mCurrIndex);
            if (this.mCurrIndex != this.mNextIndex) {
                LOG.d(TAG, "mCurrIndex not equal mNextIndex=" + this.mNextIndex);
                return;
            }
            return;
        }
        if (this.mUpdatePlayWeatherInfoRunnable == null) {
            this.mUpdatePlayWeatherInfoRunnable = new UpdatePlayWeatherInfo();
        }
        if (this.mUpdatePlayWeatherInfoRunnable != null) {
            Log.i(TAG, "before mUpdatePlayWeatherInfoRunnable.run");
            this.mUpdatePlayWeatherInfoRunnable.run();
        } else {
            LOG.d(TAG, "updateCityData, mUpdatePlayWeatherInfoThread null");
        }
        LOG.d(TAG, "Current:updateCityData(" + index + "), mCurrIndex=" + this.mCurrIndex);
    }

    private void playSwitchCity() {
        if (this.mWeatherInfoList != null && this.mWeatherInfoList.size() > 0 && this.mFxCurWeatherCtr != null && this.mFxNextWeatherCtr != null) {
            this.mFxNextWeatherCtr.setVisilbe(true);
            this.mFxNextWeatherCtr.setWeatherInfo(this.mWeatherInfoList.get(this.mNextIndex));
            this.mFxCurWeatherCtr.playMarker(getResString(R.string.marker_Exit));
            this.mCouldyFly.playMarker(getResString(R.string.marker_Transition));
            this.mFxNextWeatherCtr.playMarker(getResString(R.string.marker_Build));
            this.mFxNextWeatherCtr.playMainInAnimation();
            this.mFxNextWeatherCtr.playForecastInAnimation();
            playBgTransition(this.mWeatherInfoList.get(this.mCurrIndex).mMainIcon, this.mWeatherInfoList.get(this.mNextIndex).mMainIcon);
            this.m_bSwipeCity = true;
        }
    }

    private void updateWeatherInfo(int index) {
        CityInfo cityinfo = this.mModel.get(index);
        if (cityinfo != null) {
            this.mWeatherInfoList.get(index).mIndex = index;
            this.mWeatherInfoList.get(index).mCity = cityinfo.displayName;
            this.mWeatherInfoList.get(index).mPageNumber = (index + 1) + "/" + this.WEATHER_COUNT;
            if (cityinfo.getLocationInfo() != null && cityinfo.getLocationInfo().getApp() != null && cityinfo.getLocationInfo().getApp().equals(WeatherIntent.APP_LOCATION_SERVICE)) {
                String display_name = cityinfo.displayName + "(" + getResString(R.string.current) + ")";
                this.mWeatherInfoList.get(index).mCity = display_name;
            }
            if (cityinfo.hasWeatherData) {
                this.isWeatherDataAvalible = true;
                DayForecast today = cityinfo.getCity().current.today();
                this.mWeatherInfoList.get(index).mDescription = today.getCondition();
                this.mWeatherInfoList.get(index).mCurTemp = today.getCurrent() + "°";
                this.mWeatherInfoList.get(index).mCurHitemp = today.getHigh() + "°";
                this.mWeatherInfoList.get(index).mCurLowtemp = today.getLow() + "°";
                this.mWeatherInfoList.get(index).mUpdateTime = RefreshUtil.getUpdateString(getContext(), cityinfo.getUpdateTime());
                this.mWeatherInfoList.get(index).mMainIcon = today.getForecastIcon();
                this.mWeatherInfoList.get(index).mCurControlName = WeatherUtil.getTimelineControlNameMain(today.getForecastIcon());
                for (int j = 0; j < this.numberOfForecaseDay; j++) {
                    int day_idx = cityinfo.getCity().todayIndex + j + 1;
                    if (day_idx >= 0 && day_idx < cityinfo.getCity().current.size()) {
                        DayForecast forecast = cityinfo.getCity().current.get(day_idx);
                        if (forecast == null) {
                            LOG.d(TAG, "index - forecast null, j= " + j);
                        } else {
                            this.mWeatherInfoList.get(index).arrWeekDay[j] = forecast.getWeekDay();
                            this.mWeatherInfoList.get(index).arrHLTemperature[j] = forecast.getHigh() + "°/" + forecast.getLow() + "°";
                            this.mWeatherInfoList.get(index).mForecastIcon[j] = forecast.getForecastIcon();
                            this.mWeatherInfoList.get(index).arrControlName[j] = WeatherUtil.getTimelineControlNameFs(forecast.getForecastIcon());
                            LOG.d(TAG, "index:Total:" + cityinfo.getCity().current.size() + " Day index:" + day_idx);
                        }
                    } else {
                        LOG.d(TAG, "OutOfDate - index:Total:" + cityinfo.getCity().current.size() + " Day index:" + day_idx);
                        this.mWeatherInfoList.get(index).mForecastIcon[j] = 0;
                    }
                }
                this.mWeatherInfoList.get(index).hasData = true;
                return;
            }
            LOG.w(TAG, "cityinfo.hasWeatherData == false");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void resetUpdateTime() {
        if (this.mWeatherInfoList != null && this.mWeatherInfoList.size() > 0 && this.mModel != null && this.mModel.size() > 0) {
            for (int i = 0; i < this.mWeatherInfoList.size(); i++) {
                CityInfo cityinfo = this.mModel.get(i);
                if (cityinfo != null && cityinfo.getUpdateTime() != 0) {
                    this.mWeatherInfoList.get(i).mUpdateTime = RefreshUtil.getUpdateString(getContext(), cityinfo.getUpdateTime());
                } else {
                    this.mWeatherInfoList.get(i).mUpdateTime = "";
                }
            }
            if (this.mFxCurWeatherCtr != null && this.mFxCurWeatherCtr.tlUpdateTime != null) {
                setRefreshTime(this.mCurrIndex);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void updateWeatherInfo() {
        CityInfo cityinfo;
        LOG.d(TAG, "updateWeatherInfo");
        if (this.mWeatherInfoList != null) {
            for (int i = 0; i < this.mWeatherInfoList.size() && (cityinfo = this.mModel.get(i)) != null; i++) {
                this.mWeatherInfoList.get(i).mIndex = i;
                this.mWeatherInfoList.get(i).mCity = cityinfo.displayName;
                this.mWeatherInfoList.get(i).mPageNumber = (i + 1) + "/" + this.WEATHER_COUNT;
                if (cityinfo.getLocationInfo() != null && cityinfo.getLocationInfo().getApp() != null && cityinfo.getLocationInfo().getApp().equals(WeatherIntent.APP_LOCATION_SERVICE)) {
                    String display_name = cityinfo.displayName + "(" + getResString(R.string.current) + ")";
                    this.mWeatherInfoList.get(i).mCity = display_name;
                }
                if (cityinfo.hasWeatherData) {
                    this.isWeatherDataAvalible = true;
                    this.isNeedInitState = this.isWeatherDataAvalible;
                    DayForecast today = cityinfo.getCity().current.today();
                    this.mWeatherInfoList.get(i).mDescription = today.getCondition();
                    this.mWeatherInfoList.get(i).mCurTemp = today.getCurrent() + "°";
                    this.mWeatherInfoList.get(i).mCurHitemp = today.getHigh() + "°";
                    this.mWeatherInfoList.get(i).mCurLowtemp = today.getLow() + "°";
                    this.mWeatherInfoList.get(i).mUpdateTime = RefreshUtil.getUpdateString(getContext(), cityinfo.getUpdateTime());
                    this.mWeatherInfoList.get(i).mMainIcon = today.getForecastIcon();
                    this.mWeatherInfoList.get(i).mCurControlName = WeatherUtil.getTimelineControlNameMain(today.getForecastIcon());
                    for (int j = 0; j < this.numberOfForecaseDay; j++) {
                        int day_idx = cityinfo.getCity().todayIndex + j + 1;
                        if (day_idx >= 0 && day_idx < cityinfo.getCity().current.size()) {
                            DayForecast forecast = cityinfo.getCity().current.get(day_idx);
                            if (forecast == null) {
                                LOG.d(TAG, "forecast null, i = " + i + ", j= " + j);
                            } else {
                                this.mWeatherInfoList.get(i).arrWeekDay[j] = forecast.getWeekDay();
                                this.mWeatherInfoList.get(i).arrHLTemperature[j] = forecast.getHigh() + "°/" + forecast.getLow() + "°";
                                this.mWeatherInfoList.get(i).mForecastIcon[j] = forecast.getForecastIcon();
                                this.mWeatherInfoList.get(i).arrControlName[j] = WeatherUtil.getTimelineControlNameFs(forecast.getForecastIcon());
                            }
                        } else {
                            LOG.d(TAG, "OutOfDate:Total:" + cityinfo.getCity().current.size() + " Day index:" + day_idx);
                            this.mWeatherInfoList.get(i).mForecastIcon[j] = 0;
                        }
                    }
                    this.mWeatherInfoList.get(i).hasData = true;
                } else {
                    LOG.w(TAG, "cityinfo.hasWeatherData == false");
                }
            }
        }
    }

    @Override // com.htc.widget3d.weather.WeatherWidgetBase
    protected void updateTaskBarInfo(int city_idx, String post_string) {
        if (this.mFxCurWeatherCtr.tlUpdateTime != null) {
            String updating_msg = getResString(R.string.update_label) + post_string;
            SpannableString update = getRefreshString(updating_msg);
            this.mFxCurWeatherCtr.tlUpdateTime.setContent(update);
        }
    }

    @Override // com.htc.widget3d.weather.WeatherWidgetBase
    protected void setRefreshTime(int city_idx) {
        if (this.mFxCurWeatherCtr.tlUpdateTime != null) {
            if (this.mCurrIndex != city_idx) {
                LOG.d(TAG, "setRefreshTime not current, mCurrIndex=" + this.mCurrIndex + ", updated idx=" + city_idx);
                return;
            }
            if (this.mWeatherInfoList == null || city_idx >= this.mWeatherInfoList.size()) {
                LOG.d(TAG, "setRefreshTime:mWeatherInfoList , city_idx=" + city_idx + ", total=" + this.mWeatherInfoList.size());
                return;
            }
            WeatherInfo info = this.mWeatherInfoList.get(city_idx);
            if (info != null) {
                this.mFxCurWeatherCtr.tlUpdateTime.setContent(getRefreshString(info.mUpdateTime));
            }
        }
    }

    public SpannableString getRefreshString(String info_string) {
        SpannableString update = new SpannableString(" " + info_string);
        Drawable d = getContext().getResources().getDrawable(R.drawable.common_widget_icon_refresh);
        d.setBounds(0, 0, 0, 0);
        ImageSpan span = new ImageSpan(d, 0);
        update.setSpan(span, 0, 0, 17);
        return update;
    }

    private void playBgOnPause() {
        if (isPortrait) {
            if (this.mBackgroundInOut != null) {
                Marker out = this.mBackgroundInOut.getMarker("Out");
                if (out != null) {
                    this.mBackgroundInOut.playMarker("Out");
                    return;
                } else {
                    LOG.d(TAG, "getMarker(Out)==null !");
                    return;
                }
            }
            LOG.d(TAG, "mBackgroundInOut==null !");
        }
    }

    private void playBgOnResume() {
        if (isPortrait) {
            if (this.mBackgroundInOut != null) {
                this.mBackgroundInOut.playMarker("In");
            } else {
                LOG.d(TAG, "mBackgroundInOut==null !");
            }
        }
    }

    class WeatherControl {
        FxButton btnFooter;
        FxSceneContainer mMainSC;
        FxScene mMainScene;
        FxDynamicImage[] m_ArrfxImg;
        FxTimelineControl m_TimelineRain;
        FxTimelineControl m_fxTimelineControl;
        int m_nForcastIdleFrame;
        int m_nMainIdleFrame;
        int m_nMainSceneIdleFrame;
        int m_nTiltEndFrame;
        int m_nTiltStartFrame;
        FxTextLabel tlCity;
        FxTextLabel tlCurTemp;
        FxTextLabel tlCurTemp_small;
        FxTextLabel tlCurrHi;
        FxTextLabel tlCurrLow;
        FxTextLabel tlDescription;
        FxTextLabel[] tlFCurrTemp;
        FxTextLabel[] tlFTempHL;
        FxTimelineControl[] tlForecast;
        FxTextLabel tlIndex;
        FxTextLabel tlNoData;
        FxTextLabel tlUpdateTime;
        int mWeatherIndex = 0;
        MessageListener<FxPlaybackInfo> mMainStatePlaybackListener = new MessageListener<FxPlaybackInfo>() { // from class: com.htc.widget3d.weather.Weather4x4Widget.WeatherControl.1
            public void onMessageReceived(FxPlaybackInfo message) {
                LOG.i(Weather4x4Widget.TAG, "MainScene PlaybackComplete");
                if (WeatherControl.this.mMainScene != null && message.name.equals("Build") && WeatherWidgetBase.isWidgetOnScreen) {
                    WeatherControl.this.mMainScene.playMarker(Weather4x4Widget.this.getResString(R.string.marker_LoopIn), 2, 1.0f, true);
                    if (WeatherControl.this.m_TimelineRain != null) {
                        WeatherControl.this.m_TimelineRain.setAsync(true);
                        WeatherControl.this.m_TimelineRain.playMarker(Weather4x4Widget.this.getResString(R.string.marker_LoopIn), 1, 1.0f, true);
                    }
                }
            }
        };
        MessageListener<FxButton.ClickParameters> mRefreshClickListener = new MessageListener<FxButton.ClickParameters>() { // from class: com.htc.widget3d.weather.Weather4x4Widget.WeatherControl.2
            public void onMessageReceived(FxButton.ClickParameters arg0) {
                LOG.d(Weather4x4Widget.TAG, "Refresh on Click,index = " + Weather4x4Widget.this.mCurrIndex);
                if (Weather4x4Widget.this.mModel != null && Weather4x4Widget.this.mModel.size() > 0) {
                    if (Weather4x4Widget.this.mFxCurWeatherCtr.tlUpdateTime != null) {
                        SpannableString update = Weather4x4Widget.this.getRefreshString(Weather4x4Widget.this.getResString(R.string.update_label));
                        Weather4x4Widget.this.mFxCurWeatherCtr.tlUpdateTime.setContent(update);
                        Weather4x4Widget.this.startLoading(Weather4x4Widget.this.mCurrIndex);
                    }
                    Weather4x4Widget.this.postToWorkerThread(Weather4x4Widget.this.mUpdatedCurrentCityRunnable);
                    return;
                }
                if (Weather4x4Widget.this.mModel == null) {
                    LOG.d(Weather4x4Widget.TAG, "mModel null.");
                } else {
                    LOG.d(Weather4x4Widget.TAG, "mModel.size()=" + Weather4x4Widget.this.mModel.size());
                }
            }
        };

        public WeatherControl() {
            this.m_ArrfxImg = new FxDynamicImage[Weather4x4Widget.this.numberOfForecaseDay];
            this.tlForecast = new FxTimelineControl[Weather4x4Widget.this.numberOfForecaseDay];
            this.tlFCurrTemp = new FxTextLabel[Weather4x4Widget.this.numberOfForecaseDay];
            this.tlFTempHL = new FxTextLabel[Weather4x4Widget.this.numberOfForecaseDay];
        }

        public boolean Init(FxTimelineControl fxParent) {
            Marker marker;
            if (fxParent == null) {
                return false;
            }
            this.m_fxTimelineControl = fxParent;
            String[] szChild = {Weather4x4Widget.this.getResString(R.string.scenecontainer_main_weather_state), "timeline.forecast_01_first", "timeline.forecast_02_first", "timeline.forecast_03_first", "timeline.forecast_04_first", "dynamicimage.weather_s_01", "dynamicimage.weather_s_02", "dynamicimage.weather_s_03", "dynamicimage.weather_s_04", Weather4x4Widget.this.getResString(R.string.textlabel_cityname), Weather4x4Widget.this.getResString(R.string.textlabel_condition), Weather4x4Widget.this.getResString(R.string.textlabel_citytemp), Weather4x4Widget.this.getResString(R.string.textlabel_pagenumber), Weather4x4Widget.this.getResString(R.string.textlabel_footer_update), "button.footer", Weather4x4Widget.this.getResString(R.string.textlabel_citytemphi), Weather4x4Widget.this.getResString(R.string.textlabel_citytemplow), Weather4x4Widget.this.getResString(R.string.textlabel_tem01), Weather4x4Widget.this.getResString(R.string.textlabel_tem01hilow), Weather4x4Widget.this.getResString(R.string.textlabel_tem02), Weather4x4Widget.this.getResString(R.string.textlabel_tem02hilow), Weather4x4Widget.this.getResString(R.string.textlabel_tem03), Weather4x4Widget.this.getResString(R.string.textlabel_tem03hilow), Weather4x4Widget.this.getResString(R.string.textlabel_temp04), Weather4x4Widget.this.getResString(R.string.textlabel_tem04hilow), Weather4x4Widget.this.getResString(R.string.textlabel_empty_page), "textlabel.citytemp_02"};
            FxTextLabel[] descendants = this.m_fxTimelineControl.getDescendants(szChild);
            this.mMainSC = (FxSceneContainer) descendants[0];
            this.tlForecast[0] = (FxTimelineControl) descendants[1];
            this.tlForecast[1] = (FxTimelineControl) descendants[2];
            this.tlForecast[2] = (FxTimelineControl) descendants[3];
            this.tlForecast[3] = (FxTimelineControl) descendants[4];
            this.m_ArrfxImg[0] = (FxDynamicImage) descendants[5];
            this.m_ArrfxImg[1] = (FxDynamicImage) descendants[6];
            this.m_ArrfxImg[2] = (FxDynamicImage) descendants[7];
            this.m_ArrfxImg[3] = (FxDynamicImage) descendants[8];
            this.tlCity = descendants[9];
            this.tlDescription = descendants[10];
            this.tlCurTemp = descendants[11];
            this.tlIndex = descendants[12];
            this.tlUpdateTime = descendants[13];
            this.btnFooter = (FxButton) descendants[14];
            this.tlCurrHi = descendants[15];
            this.tlCurrLow = descendants[16];
            this.tlFCurrTemp[0] = descendants[17];
            this.tlFTempHL[0] = descendants[18];
            this.tlFCurrTemp[1] = descendants[19];
            this.tlFTempHL[1] = descendants[20];
            this.tlFCurrTemp[2] = descendants[21];
            this.tlFTempHL[2] = descendants[22];
            this.tlFCurrTemp[3] = descendants[23];
            this.tlFTempHL[3] = descendants[24];
            this.tlNoData = descendants[25];
            this.tlCurTemp_small = descendants[26];
            if (this.tlCity != null) {
                this.tlCity.setString("");
            }
            if (this.tlDescription != null) {
                this.tlDescription.setString("");
            }
            if (this.tlCurTemp != null) {
                this.tlCurTemp.setString("");
            }
            if (this.tlCurTemp_small != null) {
                this.tlCurTemp_small.setString("");
            }
            if (this.tlIndex != null) {
                this.tlIndex.setString("");
            }
            if (this.tlUpdateTime != null) {
                this.tlUpdateTime.setString("");
            }
            if (this.tlCurrHi != null) {
                this.tlCurrHi.setString("");
            }
            if (this.tlCurrLow != null) {
                this.tlCurrLow.setString("");
            }
            if (this.tlNoData != null) {
                this.tlNoData.setString("");
            }
            for (int i = 0; i < Weather4x4Widget.this.numberOfForecaseDay; i++) {
                if (this.tlFCurrTemp[i] != null) {
                    this.tlFCurrTemp[i].setString("");
                }
                if (this.tlFTempHL[i] != null) {
                    this.tlFTempHL[i].setString("");
                }
            }
            Marker marker2 = this.m_fxTimelineControl.getMarker("LoopIn");
            if (marker2 != null) {
                this.m_nMainIdleFrame = marker2.StartFrame;
            }
            if (this.tlForecast[0] != null && (marker = this.tlForecast[0].getMarker("Idle")) != null) {
                this.m_nForcastIdleFrame = marker.StartFrame;
            }
            Marker marker3 = this.m_fxTimelineControl.getMarker("tilt");
            if (marker3 != null) {
                this.m_nTiltStartFrame = marker3.StartFrame;
                this.m_nTiltEndFrame = marker3.EndFrame;
            }
            return true;
        }

        public void HandleTiltChange(float fTilt) {
            if (this.m_fxTimelineControl != null) {
                this.m_fxTimelineControl.setFrame(WidgetHelper.convertTiltAngleToFrame(fTilt, this.m_nTiltStartFrame, this.m_nTiltEndFrame));
            }
        }

        public void setWarningMessage(String szMsg) {
            if (this.tlNoData != null) {
                this.tlNoData.setString("");
                this.tlNoData.setString(szMsg);
            }
        }

        public void setWarningMsgVisbile(boolean bVisible) {
            if (this.tlNoData != null) {
                this.tlNoData.setVisibility(bVisible);
            }
        }

        public void setRefreshListener() {
            if (this.btnFooter == null) {
                LOG.d(Weather4x4Widget.TAG, "registerRefreshListener - btnFooter null");
                return;
            }
            this.btnFooter.getClickEventSource().unbindAll();
            if (this.mRefreshClickListener == null) {
                LOG.d(Weather4x4Widget.TAG, "registerRefreshListener - mRefreshClickListener null");
            } else {
                this.btnFooter.getClickEventSource().bind(this.mRefreshClickListener);
            }
        }

        public void setVisilbe(boolean bVisible) {
            if (this.m_fxTimelineControl != null) {
                this.m_fxTimelineControl.setVisibility(bVisible);
            }
        }

        public void playFadeOutMarker() {
            if (this.m_fxTimelineControl != null) {
                this.m_fxTimelineControl.playMarker("Exit");
            }
            if (this.mMainScene != null) {
                this.mMainScene.playMarker("Exit");
            }
            playForecastOutAnimation();
        }

        public void playMarker(String szMarker) {
            if (this.m_fxTimelineControl != null) {
                this.m_fxTimelineControl.playMarker(szMarker);
            }
            if (this.mMainScene != null) {
                this.mMainScene.playMarker(szMarker);
            }
        }

        public void playForecastOutAnimation() {
            for (int i = 0; i < this.tlForecast.length; i++) {
                if (this.tlForecast[i] != null) {
                    this.tlForecast[i].playMarker("Exit");
                }
            }
        }

        public void playMainInAnimation() {
            synchronized (Weather4x4Widget.this) {
                if (this.mMainScene != null && !this.mMainScene.isPlaying()) {
                    this.mMainScene.playMarker(Weather4x4Widget.this.getResString(R.string.marker_Build));
                }
            }
            Weather4x4Widget.this.playSoundEffect(((WeatherInfo) Weather4x4Widget.this.mWeatherInfoList.get(this.mWeatherIndex)).mMainIcon);
        }

        public void playForecastInAnimation() {
            for (int i = 0; i < this.tlForecast.length; i++) {
                if (this.tlForecast[i] == null || this.tlForecast[i].isPlaying()) {
                    LOG.d(Weather4x4Widget.TAG, "tlForecast[" + i + "] == null ");
                } else {
                    this.tlForecast[i].playMarker("Build");
                }
            }
        }

        public void stop() {
            this.m_fxTimelineControl.stop();
            if (this.mMainScene != null) {
                this.mMainScene.stop();
            }
            if (this.m_TimelineRain != null) {
                this.m_TimelineRain.stop();
            }
        }

        public boolean isPlaying() {
            return this.m_fxTimelineControl.isPlaying();
        }

        public void playMarker(String szMarker, int nPlaybackMode, float fPlaybackSpeed, boolean bTriggerEvent) {
            this.m_fxTimelineControl.playMarker(szMarker, nPlaybackMode, fPlaybackSpeed, bTriggerEvent);
        }

        public IMessageSource<FxPlaybackInfo> getPlaybackCompleteSource() {
            return this.m_fxTimelineControl.getPlaybackCompleteSource();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setToIdleState() {
            if (this.m_fxTimelineControl != null) {
                this.m_fxTimelineControl.stop();
                this.m_fxTimelineControl.setFrame(this.m_nMainIdleFrame);
            }
            if (this.mMainScene != null) {
                this.mMainScene.stop();
                this.mMainScene.setFrame(this.m_nMainSceneIdleFrame);
            }
            for (int i = 0; i < this.tlForecast.length; i++) {
                if (this.tlForecast[i] != null) {
                    this.tlForecast[i].stop();
                    this.tlForecast[i].setFrame(this.m_nForcastIdleFrame);
                }
            }
        }

        public void setNoCityView() {
            LOG.d(Weather4x4Widget.TAG, "setNoCityView");
            if (this.tlNoData != null) {
                String nocity_msg = Weather4x4Widget.this.getResString(R.string.nodatamsg) + "\n" + Weather4x4Widget.this.getResString(R.string.data_request);
                setWarningMessage(nocity_msg);
                this.tlNoData.setVisibility(true);
            }
            if (this.mMainSC != null) {
                this.mMainSC.removeScene((FxObject) null);
            }
            for (int i = 0; i < Weather4x4Widget.this.numberOfForecaseDay; i++) {
                if (this.m_ArrfxImg[i] != null) {
                    this.m_ArrfxImg[i].setVisibility(false);
                }
            }
            if (this.tlCity != null) {
                this.tlCity.setString("");
            }
            if (this.tlIndex != null) {
                this.tlIndex.setString("");
            }
            if (this.tlDescription != null) {
                this.tlDescription.setString("");
            }
            if (this.tlCurTemp != null && this.tlCurTemp_small != null) {
                this.tlCurTemp.setVisibility(false);
                this.tlCurTemp_small.setVisibility(false);
            }
            if (this.tlCurrHi != null) {
                this.tlCurrHi.setString("");
            }
            if (this.tlCurrLow != null) {
                this.tlCurrLow.setString("");
            }
            for (int i2 = 0; i2 < this.tlFTempHL.length; i2++) {
                if (this.tlFTempHL[i2] != null) {
                    this.tlFTempHL[i2].setString("");
                }
                if (this.tlFCurrTemp[i2] != null) {
                    this.tlFCurrTemp[i2].setString("");
                }
            }
            if (this.tlUpdateTime != null) {
                SpannableString update = Weather4x4Widget.this.getRefreshString("");
                this.tlUpdateTime.setContent(update);
            }
        }

        public synchronized void setWeatherInfo(WeatherInfo info) {
            LOG.d(Weather4x4Widget.TAG, "setWeatherInfo");
            if (info == null) {
                LOG.d(Weather4x4Widget.TAG, "setWeatherInfo info == null!!");
            } else {
                LOG.v(Weather4x4Widget.TAG, "setWeatherInfo start");
                this.mWeatherIndex = info.mIndex;
                if (info.hasData && info.mDescription.equals("")) {
                    Log.v(Weather4x4Widget.TAG, "Cur=" + info.mCurTemp + ", Hi=" + info.mCurHitemp + ", Lo=" + info.mCurLowtemp);
                    info.hasData = false;
                    info.mCurHitemp = "";
                    info.mCurLowtemp = "";
                    info.mCurTemp = "";
                    info.mUpdateTime = "";
                    Log.d(Weather4x4Widget.TAG, "No weather condition, City = " + info.mCity);
                }
                if (info.hasData) {
                    if (this.tlNoData != null) {
                        this.tlNoData.setVisibility(false);
                    }
                } else {
                    synchronized (Weather4x4Widget.this) {
                        if (this.tlNoData != null) {
                            this.tlNoData.setVisibility(true);
                        }
                        if (this.mMainSC != null) {
                            Log.i(Weather4x4Widget.TAG, "enter removeScene");
                            this.mMainSC.removeScene((FxObject) null);
                            Log.i(Weather4x4Widget.TAG, "leave removeScene");
                        }
                        for (int i = 0; i < Weather4x4Widget.this.numberOfForecaseDay; i++) {
                            if (this.m_ArrfxImg[i] != null) {
                                this.m_ArrfxImg[i].setVisibility(false);
                            }
                        }
                    }
                }
                if (this.tlCity != null) {
                    this.tlCity.setString(info.mCity);
                }
                if (this.tlIndex != null) {
                    this.tlIndex.setString(info.mPageNumber);
                }
                if (this.tlDescription != null) {
                    this.tlDescription.setString(info.mDescription);
                }
                if (this.tlCurTemp != null && this.tlCurTemp_small != null) {
                    if (info.mCurTemp.length() > 3) {
                        this.tlCurTemp_small.setVisibility(true);
                        this.tlCurTemp_small.setString(info.mCurTemp);
                        this.tlCurTemp.setVisibility(false);
                    } else {
                        this.tlCurTemp.setVisibility(true);
                        this.tlCurTemp.setString(info.mCurTemp);
                        this.tlCurTemp_small.setVisibility(false);
                    }
                }
                if (this.tlCurrHi != null) {
                    this.tlCurrHi.setString(info.mCurHitemp);
                }
                if (this.tlCurrLow != null) {
                    this.tlCurrLow.setString(info.mCurLowtemp);
                }
                for (int i2 = 0; i2 < this.tlFTempHL.length; i2++) {
                    if (this.tlFTempHL[i2] != null) {
                        this.tlFTempHL[i2].setString(info.arrHLTemperature[i2]);
                    }
                    if (this.tlFCurrTemp[i2] != null) {
                        this.tlFCurrTemp[i2].setString(info.arrWeekDay[i2]);
                    }
                }
                if (!info.hasData) {
                    LOG.d(Weather4x4Widget.TAG, "info.hasData = false!!");
                } else {
                    synchronized (Weather4x4Widget.this) {
                        Log.i(Weather4x4Widget.TAG, "setWeatherInfo enter(4x4), mFxCurWeatherCtr = " + equals(Weather4x4Widget.this.mFxCurWeatherCtr));
                        LOG.i(Weather4x4Widget.TAG, "Main scene: " + WeatherUtil.getMainScenePath(info.mMainIcon, WeatherWidgetBase.isPortrait));
                        this.mMainScene = FxScene.create(Weather4x4Widget.ASSET_MAIN_M10PATH + WeatherUtil.getMainScenePath(info.mMainIcon, WeatherWidgetBase.isPortrait), true);
                        if (this.mMainSC != null) {
                            this.mMainSC.setScene(this.mMainScene);
                        }
                        if (this.mMainScene == null) {
                            LOG.d(Weather4x4Widget.TAG, "mMainScene null , can't set playback complete listener.");
                        } else {
                            this.mMainScene.getPlaybackCompleteSource().bind(this.mMainStatePlaybackListener);
                            this.m_TimelineRain = this.mMainScene.findControl("timeline.rain");
                            if (this.m_TimelineRain != null) {
                                this.m_TimelineRain.setAsync(false);
                            }
                            Marker marker = this.mMainScene.getMarker("LoopIn");
                            if (marker != null) {
                                this.m_nMainSceneIdleFrame = marker.StartFrame;
                            }
                        }
                        Log.i(Weather4x4Widget.TAG, "setWeatherInfo leave(4x4), mFxCurWeatherCtr = " + equals(Weather4x4Widget.this.mFxCurWeatherCtr));
                    }
                }
                if (info.hasData) {
                    for (int i3 = 0; i3 < this.m_ArrfxImg.length; i3++) {
                        int nImgID = Weather4x4Widget.this.getForecastImg(info.mForecastIcon[i3]);
                        if (this.m_ArrfxImg[i3] != null) {
                            if (info.mForecastIcon[i3] != 0) {
                                this.m_ArrfxImg[i3].setVisibility(true);
                                Bitmap bmp = BitmapFactory.decodeResource(Weather4x4Widget.this.getContext().getResources(), nImgID);
                                if (bmp != null) {
                                    this.m_ArrfxImg[i3].setImage(bmp);
                                }
                            } else {
                                this.m_ArrfxImg[i3].setVisibility(false);
                            }
                        }
                    }
                }
                if (this.tlUpdateTime == null) {
                    LOG.d(Weather4x4Widget.TAG, "tlUpdateTime == null ! isPortrait=" + WeatherWidgetBase.isPortrait);
                } else {
                    SpannableString update = Weather4x4Widget.this.getRefreshString(info.mUpdateTime);
                    this.tlUpdateTime.setContent(update);
                }
                LOG.v(Weather4x4Widget.TAG, "setWeatherInfo end");
            }
        }
    }

    protected void postToWorkerThread(Runnable thread) {
        LOG.d(TAG, "postToWorkerThread on thread=" + thread.toString());
        if (this.mWorker != null) {
            this.mWorker.post(thread);
        } else {
            LOG.d(TAG, "postToWorkerThread FAIL on thread=" + thread.toString());
            thread.run();
        }
    }

    class InitWeatherInfo implements Runnable {
        InitWeatherInfo() {
        }

        @Override // java.lang.Runnable
        public void run() {
            LOG.i(Weather4x4Widget.TAG, "Runnable : InitWeatherInfo start");
            Weather4x4Widget.this.initWeatherInfo();
            LOG.i(Weather4x4Widget.TAG, "Runnable : InitWeatherInfo finished");
        }
    }

    class UpdateWeatherInfo implements Runnable {
        UpdateWeatherInfo() {
        }

        @Override // java.lang.Runnable
        public void run() {
            LOG.i(Weather4x4Widget.TAG, "Runnable : UpdateWeatherInfo start");
            Weather4x4Widget.this.updateWeatherInfo();
            LOG.i(Weather4x4Widget.TAG, "Runnable : UpdateWeatherInfo finished");
        }
    }

    class UpdatePlayWeatherInfo implements Runnable {
        UpdatePlayWeatherInfo() {
        }

        @Override // java.lang.Runnable
        public void run() {
            LOG.i(Weather4x4Widget.TAG, "Runnable : UpdatePlayWeatherInfo start");
            Weather4x4Widget.this.updateWeatherInfo();
            Weather4x4Widget.this.playCurrUI();
            LOG.i(Weather4x4Widget.TAG, "Runnable : UpdatePlayWeatherInfo finished");
        }
    }

    class GetFxControls implements Runnable {
        GetFxControls() {
        }

        @Override // java.lang.Runnable
        public void run() {
            LOG.i(Weather4x4Widget.TAG, "Runnable : GetFxControls start");
            Weather4x4Widget.this.initWeatherControl();
            Weather4x4Widget.this.playCurrUI();
            LOG.i(Weather4x4Widget.TAG, "Runnable : GetFxControls finished");
        }
    }

    class InitModel implements Runnable {
        InitModel() {
        }

        @Override // java.lang.Runnable
        public void run() {
            LOG.i(Weather4x4Widget.TAG, "Runnable : InitModel start");
            Weather4x4Widget.this.mModel.initialModel();
            LOG.i(Weather4x4Widget.TAG, "Runnable : InitModel finished");
        }
    }

    class UpdatedCityList implements Runnable {
        private boolean mIsAddCity;

        UpdatedCityList(boolean isAddCity) {
            this.mIsAddCity = false;
            this.mIsAddCity = isAddCity;
        }

        @Override // java.lang.Runnable
        public void run() {
            LOG.i(Weather4x4Widget.TAG, "Runnable : UpdatedCityList start, mIsAddCity=" + this.mIsAddCity);
            Weather4x4Widget.this.mModel.updateWeatherCityList();
            LOG.d(Weather4x4Widget.TAG, "After update city size = " + Weather4x4Widget.this.mModel.size());
            if (Weather4x4Widget.this.mCurrIndex != Weather4x4Widget.this.mNextIndex) {
                LOG.d(Weather4x4Widget.TAG, "mCurrIndex =" + Weather4x4Widget.this.mCurrIndex + ", mNextIndex =" + Weather4x4Widget.this.mNextIndex);
            }
            if (!this.mIsAddCity) {
                Weather4x4Widget.this.mCurrIndex = 0;
                Weather4x4Widget.this.mNextIndex = 0;
                Log.d(Weather4x4Widget.TAG, "reset mCurrIndex = 0");
            } else {
                Weather4x4Widget.this.mCurrIndex = Weather4x4Widget.this.mModel.size() - 1;
                Weather4x4Widget.this.mNextIndex = Weather4x4Widget.this.mCurrIndex;
                Log.d(Weather4x4Widget.TAG, "reset mCurrIndex to " + Weather4x4Widget.this.mCurrIndex);
            }
            LOG.i(Weather4x4Widget.TAG, "Runnable : UpdatedCityList finished");
        }
    }

    class UpdatedCurrentCity implements Runnable {
        UpdatedCurrentCity() {
        }

        @Override // java.lang.Runnable
        public void run() {
            LOG.i(Weather4x4Widget.TAG, "Runnable : UpdatedCurrentCity start");
            int count = Weather4x4Widget.this.mModel.size();
            for (int i = 0; i < count; i++) {
                Weather4x4Widget.this.getCityDataFromAgent(i, true);
            }
            Weather4x4Widget.this.stopLoading(Weather4x4Widget.this.mCurrIndex, false);
            LOG.i(Weather4x4Widget.TAG, "Runnable : UpdatedCurrentCity finished");
        }
    }

    class SwitchWeatherCtl implements Runnable {
        private FxHitbox.SwipeParameters mMessage;

        public SwitchWeatherCtl(FxHitbox.SwipeParameters message) {
            this.mMessage = null;
            this.mMessage = message;
        }

        @Override // java.lang.Runnable
        public void run() {
            LOG.i(Weather4x4Widget.TAG, "Runnable : SwitchWeatherCtl start");
            Weather4x4Widget.this.switchWeatherCtl(this.mMessage);
            LOG.i(Weather4x4Widget.TAG, "Runnable : SwitchWeatherCtl finished");
        }
    }

    @Override // com.htc.widget3d.weather.WeatherWidgetBase, com.htc.widget3d.weather.data.WeatherModel.WeatherModelListener
    public void onModelUpdated() {
        super.onModelUpdated();
        if (isWidgetOnScreen) {
            LOG.d(TAG, "onModelUpdated Widget state - resume(use Run) ");
            this.mInitModelRunnable.run();
        } else {
            LOG.d(TAG, "onModelUpdated , not on screen");
        }
    }

    public int getForecastImg(int nID) {
        return (R.drawable.weather_forecast_01 + nID) - 1;
    }
}
