package com.htc.widget3d.weather;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcWeather3DWidget.dex */
public final class R {

    public static final class attr {
    }

    public static final class color {
        public static final int black = 0x7f050001;
        public static final int grey = 0x7f050004;
        public static final int large_widget_footer_text_color = 0x7f05000d;
        public static final int large_widget_message_text_color = 0x7f05000c;
        public static final int light_grey = 0x7f050005;
        public static final int ltgrey = 0x7f050003;
        public static final int red = 0x7f050006;
        public static final int transparent = 0x7f050000;
        public static final int transparent_grey = 0x7f050007;
        public static final int white = 0x7f050002;
        public static final int widget_deep_color = 0x7f050009;
        public static final int widget_index_color = 0x7f05000a;
        public static final int widget_text_color = 0x7f050008;
        public static final int widget_text_shadow = 0x7f05000b;
    }

    public static final class drawable {
        public static final int common_widget_icon_refresh = 0x7f020000;
        public static final int icon = 0x7f020001;
        public static final int my_common_divider_items = 0x7f020002;
        public static final int preview_weather_2x1 = 0x7f020003;
        public static final int preview_weather_2x2 = 0x7f020004;
        public static final int preview_weather_4x4 = 0x7f020005;
        public static final int weather_forecast_01 = 0x7f020006;
        public static final int weather_forecast_02 = 0x7f020007;
        public static final int weather_forecast_03 = 0x7f020008;
        public static final int weather_forecast_04 = 0x7f020009;
        public static final int weather_forecast_05 = 0x7f02000a;
        public static final int weather_forecast_06 = 0x7f02000b;
        public static final int weather_forecast_07 = 0x7f02000c;
        public static final int weather_forecast_08 = 0x7f02000d;
        public static final int weather_forecast_09 = 0x7f02000e;
        public static final int weather_forecast_10 = 0x7f02000f;
        public static final int weather_forecast_11 = 0x7f020010;
        public static final int weather_forecast_12 = 0x7f020011;
        public static final int weather_forecast_13 = 0x7f020012;
        public static final int weather_forecast_14 = 0x7f020013;
        public static final int weather_forecast_15 = 0x7f020014;
        public static final int weather_forecast_16 = 0x7f020015;
        public static final int weather_forecast_17 = 0x7f020016;
        public static final int weather_forecast_18 = 0x7f020017;
        public static final int weather_forecast_19 = 0x7f020018;
        public static final int weather_forecast_20 = 0x7f020019;
        public static final int weather_forecast_21 = 0x7f02001a;
        public static final int weather_forecast_22 = 0x7f02001b;
        public static final int weather_forecast_23 = 0x7f02001c;
        public static final int weather_forecast_24 = 0x7f02001d;
        public static final int weather_forecast_25 = 0x7f02001e;
        public static final int weather_forecast_26 = 0x7f02001f;
        public static final int weather_forecast_27 = 0x7f020020;
        public static final int weather_forecast_28 = 0x7f020021;
        public static final int weather_forecast_29 = 0x7f020022;
        public static final int weather_forecast_30 = 0x7f020023;
        public static final int weather_forecast_31 = 0x7f020024;
        public static final int weather_forecast_32 = 0x7f020025;
        public static final int weather_forecast_33 = 0x7f020026;
        public static final int weather_forecast_34 = 0x7f020027;
        public static final int weather_forecast_35 = 0x7f020028;
        public static final int weather_forecast_36 = 0x7f020029;
        public static final int weather_forecast_37 = 0x7f02002a;
        public static final int weather_forecast_38 = 0x7f02002b;
        public static final int weather_forecast_39 = 0x7f02002c;
        public static final int weather_forecast_40 = 0x7f02002d;
        public static final int weather_forecast_41 = 0x7f02002e;
        public static final int weather_forecast_42 = 0x7f02002f;
        public static final int weather_forecast_43 = 0x7f020030;
        public static final int weather_forecast_44 = 0x7f020031;
    }

    public static final class id {
        public static final int item_text = 0x7f080000;
        public static final int list = 0x7f080003;
        public static final int title_block = 0x7f080002;
        public static final int weatherView = 0x7f080001;
    }

    public static final class layout {
        public static final int city_list_item = 0x7f030000;
        public static final int main = 0x7f030001;
        public static final int select_city = 0x7f030002;
    }

    public static final class string {
        public static final int Arrow_comp = 0x7f060005;
        public static final int Arrow_comp_02 = 0x7f060023;
        public static final int Cloud_flyThru = 0x7f060002;
        public static final int Weather_4X4 = 0x7f060000;
        public static final int add_city = 0x7f060058;
        public static final int ap_version_id = 0x7f06004d;
        public static final int app_hitbox = 0x7f060001;
        public static final int app_name = 0x7f06004c;
        public static final int auto_update = 0x7f060061;
        public static final int auto_update_bottommsg = 0x7f060063;
        public static final int auto_update_topmsg = 0x7f060062;
        public static final int btn_no = 0x7f060065;
        public static final int btn_yes = 0x7f060064;
        public static final int button_footer = 0x7f06000b;
        public static final int button_footer_02 = 0x7f060029;
        public static final int button_footer_02_hitbox = 0x7f06002a;
        public static final int button_footer_hitbox = 0x7f06000c;
        public static final int city_duplicate = 0x7f06006a;
        public static final int current = 0x7f060067;
        public static final int current_location = 0x7f060068;
        public static final int data_error = 0x7f06005b;
        public static final int data_request = 0x7f06005a;
        public static final int home_widget_plugins = 0x7f060053;
        public static final int last_update = 0x7f06005f;
        public static final int license = 0x7f060066;
        public static final int marker_Build = 0x7f060043;
        public static final int marker_DayToNight = 0x7f060046;
        public static final int marker_DayToRain = 0x7f060049;
        public static final int marker_Exit = 0x7f060045;
        public static final int marker_Intro = 0x7f060041;
        public static final int marker_LoopIn = 0x7f060044;
        public static final int marker_NightToDay = 0x7f060047;
        public static final int marker_NightToRain = 0x7f06004a;
        public static final int marker_RainToDay = 0x7f060048;
        public static final int marker_RainToNight = 0x7f06004b;
        public static final int marker_Transition = 0x7f060042;
        public static final int maximum_location_msg = 0x7f06006b;
        public static final int no_data = 0x7f06005c;
        public static final int nodatamsg = 0x7f060052;
        public static final int release_date = 0x7f06004e;
        public static final int rosie_widget_description = 0x7f06006c;
        public static final int scenecontainer_main_weather_state = 0x7f06000a;
        public static final int scenecontainer_main_weather_state_2 = 0x7f060028;
        public static final int scenecontainer_weather_state01 = 0x7f060014;
        public static final int scenecontainer_weather_state01_2 = 0x7f060032;
        public static final int scenecontainer_weather_state02 = 0x7f060018;
        public static final int scenecontainer_weather_state02_2 = 0x7f060036;
        public static final int scenecontainer_weather_state03 = 0x7f06001c;
        public static final int scenecontainer_weather_state03_2 = 0x7f06003a;
        public static final int scenecontainer_weather_state04 = 0x7f060020;
        public static final int scenecontainer_weather_state04_2 = 0x7f06003e;
        public static final int select_city = 0x7f060057;
        public static final int textlabel_cityname = 0x7f06000f;
        public static final int textlabel_cityname_02 = 0x7f06002d;
        public static final int textlabel_citytemp = 0x7f060009;
        public static final int textlabel_citytemp_02 = 0x7f060027;
        public static final int textlabel_citytemphi = 0x7f060007;
        public static final int textlabel_citytemphi_02 = 0x7f060025;
        public static final int textlabel_citytemplow = 0x7f060008;
        public static final int textlabel_citytemplow_02 = 0x7f060026;
        public static final int textlabel_condition = 0x7f060010;
        public static final int textlabel_condition_02 = 0x7f06002e;
        public static final int textlabel_empty_page = 0x7f060004;
        public static final int textlabel_empty_page_02 = 0x7f060022;
        public static final int textlabel_footer_update = 0x7f06000e;
        public static final int textlabel_footer_update_02 = 0x7f06002c;
        public static final int textlabel_pagenumber = 0x7f060006;
        public static final int textlabel_pagenumber_02 = 0x7f060024;
        public static final int textlabel_tem01 = 0x7f060012;
        public static final int textlabel_tem01_02 = 0x7f060030;
        public static final int textlabel_tem01hilow = 0x7f060013;
        public static final int textlabel_tem01hilow_02 = 0x7f060031;
        public static final int textlabel_tem02 = 0x7f060016;
        public static final int textlabel_tem02_02 = 0x7f060034;
        public static final int textlabel_tem02hilow = 0x7f060017;
        public static final int textlabel_tem02hilow_02 = 0x7f060035;
        public static final int textlabel_tem03 = 0x7f06001b;
        public static final int textlabel_tem03_02 = 0x7f060039;
        public static final int textlabel_tem03hilow = 0x7f06001a;
        public static final int textlabel_tem03hilow_02 = 0x7f060038;
        public static final int textlabel_tem04hilow = 0x7f06001f;
        public static final int textlabel_tem04hilow_02 = 0x7f06003d;
        public static final int textlabel_temp04 = 0x7f06001e;
        public static final int textlabel_temp04_02 = 0x7f06003c;
        public static final int timeline_footer_update = 0x7f06000d;
        public static final int timeline_footer_update_02 = 0x7f06002b;
        public static final int timeline_forecast_01_first = 0x7f060011;
        public static final int timeline_forecast_01_sec = 0x7f06002f;
        public static final int timeline_forecast_02_frist = 0x7f060015;
        public static final int timeline_forecast_02_sec = 0x7f060033;
        public static final int timeline_forecast_03_frist = 0x7f060019;
        public static final int timeline_forecast_03_sec = 0x7f060037;
        public static final int timeline_forecast_04_frist = 0x7f06001d;
        public static final int timeline_forecast_04_sec = 0x7f06003b;
        public static final int timeline_weather_bg = 0x7f060040;
        public static final int timeline_weather_bg_inout = 0x7f06003f;
        public static final int timeline_weather_composition_first = 0x7f060003;
        public static final int timeline_weather_composition_sec = 0x7f060021;
        public static final int update_label = 0x7f060060;
        public static final int wait_message = 0x7f060059;
        public static final int weather_activity_not_ready = 0x7f060069;
        public static final int weather_big_item = 0x7f060054;
        public static final int weather_large_item = 0x7f060056;
        public static final int weather_small_item = 0x7f060055;
        public static final int widget_2x1_name = 0x7f060051;
        public static final int widget_2x2_name = 0x7f060050;
        public static final int widget_4x4_name = 0x7f06004f;
        public static final int widget_name = 0x7f06005e;
        public static final int yesterday_ago = 0x7f06005d;
    }

    public static final class style {
        public static final int EditWindow = 0x7f070000;
    }

    public static final class xml {
        public static final int weather_widget = 0x7f040000;
    }
}
