package com.htc.widget3d.weather.data;

import android.content.Context;
import com.htc.util.weather.WSPPData;
import com.htc.util.weather.WSPPUtility;
import com.htc.util.weather.WeatherLocation;
import com.htc.widget3d.weather.data.WeatherModel;
import java.util.Date;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcWeather3DWidget.dex */
public class CityInfo {
    public static final int CITYINFO_STATE_NOT_UPDATE = 0;
    public static final int CITYINFO_STATE_NO_DATA = -1;
    public static final int CITYINFO_STATE_UPDATE_BY_BUNDLE = 1;
    private static final String TAG = "cityInfo";
    private static final boolean localLOGV = true;
    WSPPData bundle;
    private String formatUpdateTime;
    public String cityName = "";
    public String displayName = "";
    private long UpdateTime = 0;
    String geoCodeName = "";
    String agentCode = "";
    public int mState = -1;
    boolean needUpdate = localLOGV;
    public boolean hasWeatherData = false;
    public int index = -1;
    private WeatherLocation locationInfo = null;
    public WeatherModel.QUERY_TYPE type_ = WeatherModel.QUERY_TYPE.QUERY_CODE_ACCU_WEATHER;
    public City city_ = new City();

    public void setCity(City city) {
        this.city_ = city;
        this.bundle = null;
        if (this.city_.current.size() > 0) {
            this.hasWeatherData = localLOGV;
            this.needUpdate = false;
        } else {
            this.hasWeatherData = false;
            this.needUpdate = localLOGV;
        }
    }

    public City getCity() {
        return this.city_;
    }

    public void setUpdateTime(long time) {
        this.UpdateTime = time;
        Date date = new Date(time);
        int m = date.getMinutes();
        String minute = m < 10 ? "0" + m : "" + m;
        String ap = date.getHours() >= 12 ? "PM" : "AM";
        this.formatUpdateTime = date.getHours() + ":" + minute + ap;
    }

    public String getFormatUpdateTime() {
        return this.formatUpdateTime;
    }

    public void setLocationInfo(WeatherLocation locationInfo) {
        this.locationInfo = locationInfo;
        String code = locationInfo.getCode();
        if (code.equals("")) {
            this.agentCode = "1_" + locationInfo.getCode() + "_";
        } else {
            this.agentCode = "2_" + locationInfo.getCode() + "_";
        }
        resetCityName();
        resetDisplayName();
        resetGeoCodeName();
        this.needUpdate = localLOGV;
    }

    public WeatherLocation getLocationInfo() {
        return this.locationInfo;
    }

    public long getUpdateTime() {
        return this.UpdateTime;
    }

    public void setBundle(WSPPData data) {
        this.mState = 1;
        this.bundle = data;
    }

    public final WSPPData getBundle() {
        return this.bundle;
    }

    public void setState(int state) {
        this.mState = state;
    }

    public int getState() {
        return this.mState;
    }

    public void removeCity() {
        this.city_ = new City();
        this.bundle = null;
        this.hasWeatherData = false;
        this.needUpdate = localLOGV;
    }

    public String getDisplayName() {
        return this.displayName;
    }

    private void resetDisplayName() {
        this.displayName = "";
        if (this.locationInfo != null) {
            if (this.locationInfo.getName() != null && this.locationInfo.getName().length() > 0) {
                this.displayName = this.locationInfo.getName();
            }
            if (this.locationInfo.getState() != null && this.locationInfo.getState().length() > 0) {
                this.displayName += ", " + this.locationInfo.getState();
            }
        }
    }

    public String getCityName() {
        return this.cityName;
    }

    private void resetCityName() {
        this.cityName = "";
        if (this.locationInfo != null) {
            if (this.locationInfo.getName() != null && this.locationInfo.getName().length() > 0) {
                this.cityName = this.locationInfo.getName();
            }
            if (this.locationInfo.getState() != null && this.locationInfo.getState().length() > 0) {
                this.cityName += ", " + this.locationInfo.getState();
            } else if (this.locationInfo.getCountry() != null && this.locationInfo.getCountry().length() > 0) {
                this.cityName += ", " + this.locationInfo.getCountry();
            }
        }
    }

    public String getGeoCodeName() {
        return this.geoCodeName;
    }

    private void resetGeoCodeName() {
        this.geoCodeName = "";
        if (this.locationInfo != null) {
            if (this.locationInfo.getLatitude() != null && this.locationInfo.getLatitude().length() > 0) {
                this.geoCodeName = this.locationInfo.getLatitude();
            }
            if (this.locationInfo.getLongitude() != null && this.locationInfo.getLongitude().length() > 0) {
                this.geoCodeName += "_" + this.locationInfo.getLongitude();
            }
        }
    }

    public String getAgentCode() {
        return this.agentCode;
    }

    public void setAgentCode(String _code) {
        this.agentCode = _code;
    }

    public boolean changeOffsetOfToday(Context context) {
        if (this.city_ == null) {
            return false;
        }
        String timezoneId = this.locationInfo == null ? "" : this.locationInfo.getTimezoneId();
        return this.city_.changeTodayIndex(context, timezoneId);
    }

    public void requestUpdate() {
        this.needUpdate = localLOGV;
    }

    public String genCode() {
        WeatherLocation loc = getLocationInfo();
        if (loc == null) {
            return null;
        }
        if (loc.getApp() != null && loc.getApp().equals(WeatherIntent.APP_LOCATION_SERVICE)) {
            return WSPPUtility.generateWSPReqestForCurrentLocation().toString();
        }
        if (loc.getCode() != null && loc.getCode().length() > 0) {
            return WSPPUtility.generateWSPRequestForLocCode(loc.getCode()).toString();
        }
        if (loc.getLatitude() == null || loc.getLatitude().length() <= 0) {
            return null;
        }
        return WSPPUtility.generateWSPRequestForLatitude(loc.getLatitude(), loc.getLongitude()).toString();
    }
}
