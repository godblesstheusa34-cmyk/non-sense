package com.htc.android.rosie.widget;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.android.rosie.dex */
public class WidgetHelper {
    public static float convertTiltAngleToFrame(float tiltAngle, int startFrame, int endFrame) {
        return endFrame > startFrame ? startFrame + ((endFrame - startFrame) * tiltAngle) : startFrame;
    }
}
