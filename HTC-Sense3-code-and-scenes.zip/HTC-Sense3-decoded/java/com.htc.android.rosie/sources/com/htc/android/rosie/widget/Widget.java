package com.htc.android.rosie.widget;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.ContentObserver;
import android.hardware.Sensor;
import android.hardware.SensorEventListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import com.htc.fusion.fx.FxScene;
import java.util.Properties;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.android.rosie.dex */
public abstract class Widget {
    public static final int HOST_MSG_ARG1_VISIBLE = 1;
    public static final int HOST_ORIENTATION_CHANGE_COMPLETE = 3;

    @Deprecated
    public static final int HOST_PLAY_ANIMATION = 0;

    @Deprecated
    public static final int HOST_PLAY_ANIMATION_COMPLETE = 1;
    public static final int HOST_RESUME_IN_KEYGUARD = 4;
    public static final int HOST_USER_ACTION = 2;
    public static final int HOST_USER_PRESENT = 5;

    public interface ConfigurationChange {

        public interface Callback {
            void onConfigurationChanged(Configuration configuration);

            Object onRetainNonConfigurationObject();

            void onSizeChanged(int i, int i2);
        }

        Object getLastNonConfigurationObject();
    }

    public abstract ComponentName getComponentName();

    protected abstract String getContent();

    protected abstract Context getContext();

    protected abstract Host getHost();

    protected abstract Intent getIntent();

    protected abstract FxScene getScene();

    public abstract void onActivityResult(int i, int i2, Intent intent);

    protected abstract void onCreate(Bundle bundle);

    protected abstract void onDestroy();

    protected abstract void onHostMessage(Message message);

    protected abstract void onLowMemory();

    protected abstract void onPause();

    protected abstract void onPostCreate(Bundle bundle);

    protected abstract void onRestart();

    protected abstract void onRestoreState(Bundle bundle);

    protected abstract void onResume();

    protected abstract void onSaveState(Bundle bundle);

    protected abstract void onStart();

    protected abstract void onStop();

    protected abstract void onTiltChanged(float f);

    protected abstract void onVisibilityChanged(boolean z);

    protected abstract void setContent(String str);

    public interface Host {
        FxScene createScene(String str, boolean z);

        void destroyScene(FxScene fxScene);

        Context getContext();

        Worker getWorker();

        Worker getWorker(Handler.Callback callback);

        Sensor registerSensorListener(SensorEventListener sensorEventListener, int i, int i2);

        void startActivity(Intent intent);

        void startActivityForResult(int i, Intent intent, int i2);

        void storeInstanceData(int i, Properties properties);

        void surpressLongClick(boolean z);

        void surpressSlide(boolean z);

        void unregisterSensorListener(SensorEventListener sensorEventListener, Sensor sensor);

        public interface Worker {
            void cancel(Runnable runnable);

            void cancelAll();

            ContentObserver getContentObserver(ContentChangeCallback contentChangeCallback);

            boolean hasMessage(int i);

            boolean hasMessage(int i, Object obj);

            Message obtainMessage();

            void post(Runnable runnable);

            void postAtTime(Runnable runnable, long j);

            void postDelayed(Runnable runnable, long j);

            void recall(int i);

            void recall(int i, Object obj);

            void send(int i);

            void send(Message message);

            void sendAtTime(int i, long j);

            void sendAtTime(Message message, long j);

            void sendDelayed(int i, long j);

            void sendDelayed(Message message, long j);

            public static abstract class ContentChangeCallback {
                public void onChanged(boolean selfChange) {
                }

                public boolean deliverSelfNotifications() {
                    return false;
                }
            }
        }

        public static final class AttachInfo {
            private final FxScene parent;

            public AttachInfo(FxScene parent) {
                this.parent = parent;
            }
        }
    }

    public static class Base extends Widget implements ConfigurationChange, ConfigurationChange.Callback {
        private static final boolean DEBUG_LIFECYCLE = false;
        private static final boolean DEBUG_SAVE_STATE = false;
        private static final boolean DEBUG_SUPRESS = false;
        private static final String LOG_TAG = Base.class.getName();
        private boolean mCalled;
        private boolean mCreated;
        private Intent mIntent;
        private String mMyContent;
        private FxScene mMyScene;
        private WidgetProvider mProvider;
        private Properties mSavedData;
        private boolean mVisible;
        private Host.Worker mWorker;

        protected Base() {
        }

        final Widget init(WidgetProvider p, Intent intent, Bundle savedState, Properties savedData) {
            this.mProvider = p;
            if (p.mHost == null) {
                throw new IllegalArgumentException("an widget cannot live without host");
            }
            this.mIntent = intent;
            this.mSavedData = savedData;
            performCreate(savedState);
            return this;
        }

        @Override // com.htc.android.rosie.widget.Widget
        protected final Host getHost() {
            return this.mProvider.mHost;
        }

        @Override // com.htc.android.rosie.widget.Widget
        public final String getContent() {
            return this.mMyContent;
        }

        @Override // com.htc.android.rosie.widget.Widget
        protected final void setContent(String path) {
            this.mMyContent = path;
            loadContent();
        }

        private final void loadContent() {
            this.mMyScene = this.mProvider.mHost.createScene(this.mMyContent, true);
        }

        @Override // com.htc.android.rosie.widget.Widget
        protected final Intent getIntent() {
            return this.mIntent;
        }

        final void setIntent(Intent intent) {
            this.mIntent = intent;
        }

        @Override // com.htc.android.rosie.widget.Widget
        protected FxScene getScene() {
            return this.mMyScene;
        }

        private void performCreate(Bundle savedState) {
            this.mCalled = false;
            onCreate(savedState);
            if (!this.mCalled) {
                throw new SuperNotCalledException("Widget " + this + " did not call through to super.onCreate()");
            }
            this.mCreated = true;
        }

        void performRestoreState(Bundle savedState) {
            if (!this.mCreated) {
                Log.w(LOG_TAG, "Widget was not created yet or had been destroyed");
            } else {
                onRestoreState(savedState);
            }
        }

        void performPostCreate(Bundle savedState) {
            if (!this.mCreated) {
                Log.w(LOG_TAG, "Widget was not created yet or had been destroyed");
                return;
            }
            this.mCalled = false;
            onPostCreate(savedState);
            if (!this.mCalled) {
                throw new SuperNotCalledException("Widget " + this + "did not call through to super.onPostCreate()");
            }
        }

        void performDestroy() {
            if (!this.mCreated) {
                Log.w(LOG_TAG, "Widget was not created or had been destroyed");
                return;
            }
            this.mCalled = false;
            onDestroy();
            if (!this.mCalled) {
                throw new SuperNotCalledException("Widget " + this + "did not call through to super.onDestroy()");
            }
            if (this.mMyScene != null) {
                this.mProvider.mHost.destroyScene(this.mMyScene);
                this.mMyScene = null;
            }
            this.mCreated = false;
        }

        void performStart() {
            this.mCalled = false;
            onStart();
            if (!this.mCalled) {
                throw new SuperNotCalledException("Widget " + this + "did not call through to super.onStart()");
            }
            this.mWorker = getHost().getWorker();
        }

        void performStop() {
            if (this.mWorker != null) {
                this.mWorker.cancel(null);
                this.mWorker = null;
            }
            this.mCalled = false;
            onStop();
            if (!this.mCalled) {
                throw new SuperNotCalledException("Widget " + this + "did not call through to super.onStop()");
            }
        }

        void performRestart() {
            this.mCalled = false;
            onRestart();
            if (!this.mCalled) {
                throw new SuperNotCalledException("Widget " + this + "did not call through to super.onRestart()");
            }
        }

        void performResume(Bundle state) {
            if (state != null) {
                onRestoreState(state);
            }
            this.mCalled = false;
            onResume();
            if (!this.mCalled) {
                throw new SuperNotCalledException("Widget " + this + "did not call through to super.onResume()");
            }
        }

        void performPause(Bundle state) {
            if (state != null) {
                onSaveState(state);
            }
            this.mCalled = false;
            onPause();
            if (!this.mCalled) {
                throw new SuperNotCalledException("Widget " + this + "did not call through to super.onPause()");
            }
        }

        void performConfigurationChanged(Configuration newConfiguration) {
            this.mCalled = false;
            onConfigurationChanged(newConfiguration);
            if (!this.mCalled) {
                throw new SuperNotCalledException("Widget " + this + "did not call through to super.onConfigurationChanged()");
            }
        }

        void dispatchActivityResult(int requestCode, int resultCode, Intent data) {
            onActivityResult(requestCode, resultCode, data);
        }

        @Override // com.htc.android.rosie.widget.Widget
        protected void onCreate(Bundle savedState) {
            this.mCalled = true;
        }

        @Override // com.htc.android.rosie.widget.Widget
        protected void onPostCreate(Bundle savedState) {
            this.mCalled = true;
        }

        @Override // com.htc.android.rosie.widget.Widget
        protected void onDestroy() {
            this.mCalled = true;
        }

        @Override // com.htc.android.rosie.widget.Widget
        protected void onLowMemory() {
        }

        @Override // com.htc.android.rosie.widget.Widget
        protected void onHostMessage(Message msg) {
        }

        @Override // com.htc.android.rosie.widget.Widget
        protected void onPause() {
            this.mCalled = true;
        }

        @Override // com.htc.android.rosie.widget.Widget
        protected void onRestart() {
            this.mCalled = true;
        }

        @Override // com.htc.android.rosie.widget.Widget
        protected void onRestoreState(Bundle state) {
        }

        @Override // com.htc.android.rosie.widget.Widget
        protected void onResume() {
            this.mCalled = true;
        }

        @Override // com.htc.android.rosie.widget.Widget
        protected void onSaveState(Bundle state) {
        }

        @Override // com.htc.android.rosie.widget.Widget
        protected void onStart() {
            this.mCalled = true;
        }

        @Override // com.htc.android.rosie.widget.Widget
        protected void onStop() {
            this.mCalled = true;
        }

        @Override // com.htc.android.rosie.widget.Widget
        protected void onVisibilityChanged(boolean visible) {
            this.mVisible = visible;
            if (this.mMyScene != null) {
                this.mMyScene.setVisibility(this.mVisible);
            }
        }

        @Override // com.htc.android.rosie.widget.Widget.ConfigurationChange
        public Object getLastNonConfigurationObject() {
            return null;
        }

        @Override // com.htc.android.rosie.widget.Widget.ConfigurationChange.Callback
        public void onConfigurationChanged(Configuration newConfiguration) {
            this.mCalled = true;
        }

        @Override // com.htc.android.rosie.widget.Widget.ConfigurationChange.Callback
        public Object onRetainNonConfigurationObject() {
            return null;
        }

        @Override // com.htc.android.rosie.widget.Widget.ConfigurationChange.Callback
        public void onSizeChanged(int newWidth, int newHeight) {
        }

        @Override // com.htc.android.rosie.widget.Widget
        public void onTiltChanged(float tilt) {
        }

        protected final void surpressHostSlide(boolean suppress) {
            getHost().surpressSlide(suppress);
        }

        protected final void surpressHostLongClick(boolean suppress) {
            getHost().surpressLongClick(suppress);
        }

        public boolean isEditable() {
            return false;
        }

        public void onEdit() {
        }

        @Override // com.htc.android.rosie.widget.Widget
        public final ComponentName getComponentName() {
            return this.mIntent.getComponent();
        }

        @Override // com.htc.android.rosie.widget.Widget
        protected final Context getContext() {
            return this.mProvider.getPackageContext();
        }

        protected final boolean getVisibility() {
            return this.mVisible;
        }

        protected FxScene getSceneRoot() {
            return this.mMyScene;
        }

        protected void storeInstanceData(Properties data) {
            if (!this.mCreated) {
                throw new IllegalWidgetStateException("Widget.storeInstanceData() must not be called before or during Widget.onCreate(): [widget=" + this + "]");
            }
            getHost().storeInstanceData(getMyId(), data);
            this.mSavedData = data;
        }

        protected Properties loadInstanceData() {
            return this.mSavedData;
        }

        protected void startActivityForResult(Intent intent, int requestCode) {
            if (!this.mCreated) {
                throw new IllegalWidgetStateException("Widget.startActivityForResult() must not be called before or during Widget.onCreate(): [widget=" + this + "]");
            }
            getHost().startActivityForResult(getMyId(), intent, requestCode);
        }

        @Override // com.htc.android.rosie.widget.Widget
        public void onActivityResult(int requestCode, int resultCode, Intent data) {
        }

        private int getMyId() {
            WidgetManager wm = WidgetManager.getInstance();
            int id = wm.getWidgetId(this);
            if (id == -1) {
                throw new IllegalWidgetStateException("widget:" + this + " not bounded yet or had been removed.");
            }
            return id;
        }

        protected int[] getPosition() {
            if (!this.mCreated) {
                throw new IllegalWidgetStateException("Widget.startActivityForResult() must not be called before or during Widget.onCreate(): [widget=" + this + "]");
            }
            WidgetManager wm = WidgetManager.getInstance();
            return wm.getWidgetPosition(this);
        }

        public int getPositionX(int arg) {
            return arg & 7;
        }

        public int getPositionY(int arg) {
            return (arg & 56) >> 3;
        }
    }

    public static class WidgetRuntimeException extends RuntimeException {
        protected WidgetRuntimeException(String message) {
            super(message);
        }
    }

    public static final class SuperNotCalledException extends WidgetRuntimeException {
        SuperNotCalledException(String message) {
            super(message);
        }
    }

    public static final class IllegalWidgetStateException extends WidgetRuntimeException {
        public IllegalWidgetStateException(String message) {
            super(message);
        }
    }
}
