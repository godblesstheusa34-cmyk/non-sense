package com.htc.android.rosie.widget;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import com.htc.android.rosie.widget.Widget;
import dalvik.system.PathClassLoader;
import java.util.Properties;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.android.rosie.dex */
public class WidgetProvider {
    private static final String LOG_TAG = WidgetProvider.class.getSimpleName();
    private ClassLoader mClzLoader;
    private final ComponentName mComponent;
    final Widget.Host mHost;
    private final Context mMyContext;

    public WidgetProvider(Widget.Host host, ComponentName component) {
        this.mHost = host;
        this.mComponent = component;
        Context c = null;
        try {
            c = this.mHost.getContext().createPackageContext(this.mComponent.getPackageName(), 3);
        } catch (PackageManager.NameNotFoundException e) {
            Log.e(LOG_TAG, e.getMessage() + e.getStackTrace());
        }
        this.mMyContext = c;
    }

    private ClassLoader getClassLoader() {
        if (this.mClzLoader == null) {
            this.mClzLoader = new PathClassLoader(this.mMyContext.getPackageCodePath(), this.mHost.getContext().getClassLoader());
        }
        return this.mClzLoader;
    }

    public final Context getPackageContext() {
        return this.mMyContext;
    }

    Widget loadWidgetWithIntent(Intent intent, Bundle savedState, Properties savedData) throws ClassNotFoundException {
        ClassLoader loader = getClassLoader();
        if (loader == null) {
            throw new ClassNotFoundException(LOG_TAG + ": package class loader unavailable");
        }
        if (intent == null) {
            throw new IllegalArgumentException(LOG_TAG + ": widget intent not provided");
        }
        ComponentName name = intent.getComponent();
        Widget w = null;
        try {
            w = (Widget) loader.loadClass(name.getClassName()).newInstance();
        } catch (IllegalAccessException iae) {
            Log.e(LOG_TAG, iae.getMessage());
        } catch (InstantiationException ie) {
            Log.e(LOG_TAG, ie.getMessage());
        }
        if (!(w instanceof Widget.Base)) {
            throw new ClassCastException("widget should be subclass of " + Widget.Base.class.getName());
        }
        Widget.Base b = (Widget.Base) w;
        b.init(this, intent, savedState, savedData);
        return w;
    }

    public static final class MetaData {
        static final String NAME = "com.htc.android.rosie.widget.provider";
        static final String NAME_CAT = "com.htc.android.rosie.widget.category";
        static final String XML_ROOT = "rosie-widget";
        static final String XML_STYLE = "style";

        private MetaData() {
        }
    }

    public static final class Info {
        public final String category;
        public final Drawable icon;
        public final CharSequence label;
        private final Style[] mStyles;
        public final ComponentName provider;
        public final String version;
        public final int versionCode;

        public static final class Style implements Parcelable {
            public static final Parcelable.Creator<Style> CREATOR = new Parcelable.Creator<Style>() { // from class: com.htc.android.rosie.widget.WidgetProvider.Info.Style.1
                /* JADX WARN: Can't rename method to resolve collision */
                @Override // android.os.Parcelable.Creator
                public Style createFromParcel(Parcel in) {
                    return new Style(in);
                }

                /* JADX WARN: Can't rename method to resolve collision */
                @Override // android.os.Parcelable.Creator
                public Style[] newArray(int size) {
                    return new Style[size];
                }
            };
            public final ComponentName component;
            private CharSequence date;
            private final int descRes;
            private CharSequence description;
            private final String id;
            private final int imgRes;
            private CharSequence label;
            private final int labelRes;
            public final ComponentName settings;
            public final ViewInfo view;

            public static final class ViewInfo {
                public final String scene;
                public final int sx;
                public final int sy;

                ViewInfo(int sx, int sy, String scene) {
                    this.sx = sx;
                    this.sy = sy;
                    this.scene = scene;
                }

                public ViewInfo(ViewInfo source) {
                    this.sx = source.sx;
                    this.sy = source.sy;
                    if (source.scene != null) {
                        this.scene = new String(source.scene);
                    } else {
                        this.scene = null;
                    }
                }
            }

            public String toString() {
                StringBuilder sb = new StringBuilder();
                sb.append("widget style: label=").append(this.label).append(", id=").append(this.id).append(", description=\"").append(this.description).append('\"').append(", img=").append(this.imgRes).append(", component/component=\"").append(this.component).append('\"').append(", span=").append(this.view.sx).append(',').append(this.view.sy).append(", scene=").append(this.view.scene);
                return sb.toString();
            }

            Style(String id, int labelRes, CharSequence label, int descRes, CharSequence desc, CharSequence date, int imgRes, ComponentName component, ComponentName settings, ViewInfo view) {
                this.labelRes = labelRes;
                this.descRes = descRes;
                this.imgRes = imgRes;
                this.label = label;
                this.description = desc;
                this.date = date;
                this.id = id;
                this.component = component;
                this.settings = settings;
                this.view = view;
            }

            public String getPackageName() {
                if (this.component == null) {
                    return "";
                }
                String ret = this.component.getPackageName();
                return ret;
            }

            public String getID() {
                return this.id;
            }

            public int getLabelRes() {
                return this.labelRes;
            }

            public int getDescriptionRes() {
                return this.descRes;
            }

            public int getPreviewRes() {
                return this.imgRes;
            }

            public CharSequence getLabel() {
                return this.label;
            }

            public CharSequence getDescription() {
                return this.description;
            }

            public CharSequence getDate() {
                return this.date;
            }

            @Override // android.os.Parcelable
            public int describeContents() {
                return 0;
            }

            @Override // android.os.Parcelable
            public void writeToParcel(Parcel dest, int flags) {
                dest.writeInt(this.labelRes);
                dest.writeInt(this.descRes);
                dest.writeInt(this.imgRes);
                dest.writeString(this.id);
                this.component.writeToParcel(dest, flags);
                dest.writeParcelable(this.settings, flags);
                dest.writeInt(this.view.sx);
                dest.writeInt(this.view.sy);
                dest.writeString(this.view.scene);
            }

            private Style(Parcel in) {
                this.labelRes = in.readInt();
                this.descRes = in.readInt();
                this.imgRes = in.readInt();
                this.id = in.readString();
                this.component = ComponentName.readFromParcel(in);
                this.settings = ComponentName.readFromParcel(in);
                int sx = in.readInt();
                int sy = in.readInt();
                String scene = in.readString();
                this.view = new ViewInfo(sx, sy, scene);
            }
        }

        public Style[] getStyles() {
            return this.mStyles;
        }

        Info(int verCode, String ver, ComponentName provider, CharSequence label, Drawable icon, Style[] styles, String category) {
            this.versionCode = verCode;
            this.version = ver;
            this.provider = provider;
            this.label = label;
            this.icon = icon;
            this.mStyles = styles;
            this.category = category;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("widget provider: label=").append(this.label);
            if (this.mStyles != null && this.mStyles.length > 0) {
                sb.append("\n[\n");
                Style[] arr$ = this.mStyles;
                for (Style s : arr$) {
                    sb.append(s).append('\n');
                }
                sb.append(']');
            }
            return sb.toString();
        }
    }
}
