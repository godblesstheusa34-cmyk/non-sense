package com.htc.android.rosie.widget;

import android.content.ComponentName;
import android.content.ContentValues;
import android.content.pm.ActivityInfo;
import android.content.pm.ComponentInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.util.Xml;
import com.htc.android.rosie.widget.WidgetProvider;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.android.rosie.dex */
public final class ProviderInfoHelper {
    private static final String LOG_TAG = "Rosie 3D Widget Info";
    private static final boolean localLOGD = false;
    public static final DbColumn[] DB_COLUMNS = {DbColumn.PROVIDER, DbColumn.CATEGORY, DbColumn.PKG_VERSION, DbColumn.STYLE_TYPE_ID, DbColumn.STYLE_NAME_RES, DbColumn.STYLE_PREVIEW_RES, DbColumn.STYLE_DESC_RES, DbColumn.STYLE_REL_DATE, DbColumn.STYLE_COMP_NAME, DbColumn.STYLE_SETTINGS_ACTIVITY, DbColumn.STYLE_SPAN_X, DbColumn.STYLE_SPAN_Y, DbColumn.STYLE_SCENE};
    private static final String[] INFO_PRJ = {DbColumn.PROVIDER.name, DbColumn.CATEGORY.name};
    private static final String[] STYLE_PRJ = {DbColumn.PROVIDER.name, DbColumn.PKG_VERSION.name, DbColumn.STYLE_TYPE_ID.name, DbColumn.STYLE_NAME_RES.name, DbColumn.STYLE_PREVIEW_RES.name, DbColumn.STYLE_DESC_RES.name, DbColumn.STYLE_REL_DATE.name, DbColumn.STYLE_COMP_NAME.name, DbColumn.STYLE_SETTINGS_ACTIVITY.name, DbColumn.STYLE_SPAN_X.name, DbColumn.STYLE_SPAN_Y.name, DbColumn.STYLE_SCENE.name};

    public static WidgetProvider.Info load(PackageManager pm, ComponentName provider) {
        try {
            ActivityInfo ai = pm.getReceiverInfo(provider, 128);
            WidgetProvider.Info info = load(pm, ai, true);
            return info;
        } catch (PackageManager.NameNotFoundException e) {
            return null;
        }
    }

    public static final WidgetProvider.Info load(PackageManager pm, ActivityInfo ai, boolean withStyles) {
        PackageInfo pi;
        PackageInfo pi2;
        ComponentName c = new ComponentName(((PackageItemInfo) ai).packageName, ((PackageItemInfo) ai).name);
        CharSequence l = ai.loadLabel(pm);
        Drawable ic = ai.loadIcon(pm);
        WidgetProvider.Info.Style[] s = null;
        if (withStyles) {
            XmlResourceParser parser = ai.loadXmlMetaData(pm, "com.htc.android.rosie.widget.provider");
            if (parser == null) {
                return null;
            }
            try {
                Resources res = pm.getResourcesForApplication(((ComponentInfo) ai).applicationInfo);
                s = loadStyles(res, parser);
            } catch (Exception e) {
                return null;
            } finally {
                parser.close();
            }
        }
        String cat = ((PackageItemInfo) ai).metaData.getString("com.htc.android.rosie.widget.category");
        if (cat == null) {
            cat = "default";
        }
        int verCode = -1;
        String ver = null;
        try {
            pi2 = pm.getPackageInfo(((PackageItemInfo) ai).packageName, 0);
        } catch (PackageManager.NameNotFoundException e2) {
            e = e2;
            pi = null;
        }
        try {
            verCode = pi2.versionCode;
            ver = pi2.versionName;
        } catch (PackageManager.NameNotFoundException e3) {
            pi = pi2;
            e = e3;
            e.printStackTrace();
            return new WidgetProvider.Info(verCode, ver, c, l, ic, s, cat);
        }
        return new WidgetProvider.Info(verCode, ver, c, l, ic, s, cat);
    }

    private static WidgetProvider.Info.Style[] loadStyles(Resources res, XmlResourceParser parser) throws Exception {
        int type;
        do {
            type = parser.next();
            if (type == 1) {
                break;
            }
        } while (type != 2);
        String node = parser.getName();
        if (!node.equals("rosie-widget")) {
            String err = "XML parser: Expect rosie-widget; Actual " + node;
            Log.e(LOG_TAG, err);
            throw new XmlPullParserException(err);
        }
        Xml.asAttributeSet(parser);
        List<WidgetProvider.Info.Style> s = null;
        while (true) {
            int type2 = parser.next();
            if (type2 == 1) {
                break;
            }
            if (type2 == 2 && "style".equals(parser.getName())) {
                if (s == null) {
                    s = new ArrayList<>();
                }
                s.add(parseStyle(parser, res));
            }
        }
        if (s == null || s.isEmpty()) {
            return null;
        }
        WidgetProvider.Info.Style[] styles = new WidgetProvider.Info.Style[s.size()];
        s.toArray(styles);
        return styles;
    }

    private static WidgetProvider.Info.Style parseStyle(XmlPullParser parser, Resources res) {
        int dateRes;
        int N = parser.getAttributeCount();
        String id = null;
        String comp = null;
        String config = null;
        int labelRes = 0;
        int descRes = 0;
        int previewRes = 0;
        int spanY = 0;
        int spanX = 0;
        String scene = null;
        int i = 0;
        int i2 = 0;
        while (i < N) {
            String name = parser.getAttributeName(i);
            if ("id".equals(name)) {
                id = parser.getAttributeValue(i);
                dateRes = i2;
            } else if ("name".equals(name)) {
                comp = parser.getAttributeValue(i);
                dateRes = i2;
            } else if ("label".equals(name)) {
                try {
                    labelRes = Integer.valueOf(parser.getAttributeValue(i).substring(1)).intValue();
                    dateRes = i2;
                } catch (NumberFormatException e) {
                    labelRes = 0;
                    dateRes = i2;
                }
            } else if ("description".equals(name)) {
                try {
                    descRes = Integer.valueOf(parser.getAttributeValue(i).substring(1)).intValue();
                    dateRes = i2;
                } catch (NumberFormatException e2) {
                    descRes = 0;
                    dateRes = i2;
                }
            } else if ("preview".equals(name)) {
                try {
                    previewRes = Integer.valueOf(parser.getAttributeValue(i).substring(1)).intValue();
                    dateRes = i2;
                } catch (NumberFormatException e3) {
                    previewRes = 0;
                    dateRes = i2;
                }
            } else if ("date".equals(name)) {
                String dateR = parser.getAttributeValue(i);
                try {
                    dateRes = Integer.valueOf(dateR.substring(1)).intValue();
                } catch (NumberFormatException e4) {
                    dateRes = 0;
                }
            } else if ("configure".equals(name)) {
                config = parser.getAttributeValue(i);
                dateRes = i2;
            } else if ("span_x".equals(name)) {
                int spanX2 = Integer.valueOf(parser.getAttributeValue(i)).intValue();
                spanX = spanX2;
                dateRes = i2;
            } else if ("span_y".equals(name)) {
                int spanY2 = Integer.valueOf(parser.getAttributeValue(i)).intValue();
                spanY = spanY2;
                dateRes = i2;
            } else if ("scene".equals(name)) {
                String scene2 = parser.getAttributeValue(i);
                scene = scene2;
                dateRes = i2;
            } else {
                dateRes = i2;
            }
            int dateRes2 = i + 1;
            i = dateRes2;
            i2 = dateRes;
        }
        ComponentName clz = null;
        ComponentName p = null;
        if (comp != null) {
            if (comp.startsWith(".")) {
                clz = new ComponentName(res.getResourcePackageName(labelRes), comp);
            } else {
                clz = ComponentName.unflattenFromString(comp);
            }
        }
        if (clz == null) {
            Log.w(LOG_TAG, "parse style: component name is null!");
        }
        if (config != null) {
            if (config.startsWith(".")) {
                p = new ComponentName(res.getResourcePackageName(labelRes), config);
            } else {
                p = ComponentName.unflattenFromString(config);
            }
        }
        CharSequence label = labelRes == 0 ? "" : res.getText(labelRes);
        CharSequence desc = descRes == 0 ? "" : res.getText(descRes);
        CharSequence date = i2 == 0 ? "" : res.getText(i2);
        WidgetProvider.Info.Style.ViewInfo view = new WidgetProvider.Info.Style.ViewInfo(spanX, spanY, scene);
        return new WidgetProvider.Info.Style(id, labelRes, label, descRes, desc, date, previewRes, clz, p, view);
    }

    public enum DbColumn {
        PROVIDER("provider", "TEXT"),
        CATEGORY("category", "TEXT"),
        PKG_VERSION("package_version", "TEXT"),
        STYLE_TYPE_ID("style_type_id", "TEXT"),
        STYLE_NAME_RES("style_name_res", "INTEGER"),
        STYLE_DESC_RES("style_desc_res", "INTEGER"),
        STYLE_PREVIEW_RES("style_preview_res", "INTEGER"),
        STYLE_REL_DATE("style_release_date", "TEXT"),
        STYLE_COMP_NAME("style_component_name", "TEXT"),
        STYLE_SETTINGS_ACTIVITY("style_settings_activity", "TEXT"),
        STYLE_SPAN_X("style_span_x", "INTEGER"),
        STYLE_SPAN_Y("style_span_y", "INTEGER"),
        STYLE_SCENE("style_scene", "TEXT");

        public final String name;
        public final String type;

        DbColumn(String name, String type) {
            this.name = name;
            this.type = type;
        }
    }

    public enum DbProjection {
        INFO(ProviderInfoHelper.INFO_PRJ),
        STYLE(ProviderInfoHelper.STYLE_PRJ);

        public final String[] strings;

        DbProjection(String[] s) {
            this.strings = s;
        }
    }

    public static List<WidgetProvider.Info> fromCusor(PackageManager pm, Cursor c) {
        List<WidgetProvider.Info> list = new ArrayList<>();
        HashMap<ComponentName, Object> knowns = new HashMap<>();
        if (c.moveToFirst()) {
            do {
                int index = c.getColumnIndex(DbColumn.PROVIDER.name);
                String p = c.getString(index);
                ComponentName provider = ComponentName.unflattenFromString(p);
                if (!knowns.containsKey(provider)) {
                    ActivityInfo ai = null;
                    try {
                        ai = pm.getReceiverInfo(provider, 0);
                    } catch (PackageManager.NameNotFoundException e) {
                        Log.e(LOG_TAG, "getReceiverInfo error: " + p);
                        e.printStackTrace();
                    }
                    Drawable icon = ai.loadIcon(pm);
                    CharSequence label = ai.loadLabel(pm);
                    int index2 = c.getColumnIndex(DbColumn.CATEGORY.name);
                    String cat = c.getString(index2);
                    if (cat == null) {
                        cat = "default";
                    }
                    int verCode = -1;
                    String ver = null;
                    try {
                        PackageInfo pi = pm.getPackageInfo(((PackageItemInfo) ai).packageName, 0);
                        verCode = pi.versionCode;
                        ver = pi.versionName;
                    } catch (PackageManager.NameNotFoundException e2) {
                        Log.e(LOG_TAG, "getPackageInfo error: " + p);
                        e2.printStackTrace();
                    }
                    list.add(new WidgetProvider.Info(verCode, ver, provider, label, icon, null, cat));
                    knowns.put(provider, null);
                }
            } while (c.moveToNext());
        }
        if (list.isEmpty()) {
            return null;
        }
        return list;
    }

    public static List<ContentValues> toContentValuesList(WidgetProvider.Info info) {
        List<ContentValues> list = new ArrayList<>();
        WidgetProvider.Info.Style[] styles = info.getStyles();
        for (WidgetProvider.Info.Style s : styles) {
            ContentValues cv = new ContentValues();
            cv.put(DbColumn.PROVIDER.name, info.provider.flattenToShortString());
            if (info.category != null) {
                cv.put(DbColumn.CATEGORY.name, info.category);
            }
            if (info.version != null) {
                cv.put(DbColumn.PKG_VERSION.name, info.version);
            }
            cv.put(DbColumn.STYLE_TYPE_ID.name, s.getID());
            cv.put(DbColumn.STYLE_NAME_RES.name, Integer.valueOf(s.getLabelRes()));
            cv.put(DbColumn.STYLE_DESC_RES.name, Integer.valueOf(s.getDescriptionRes()));
            cv.put(DbColumn.STYLE_PREVIEW_RES.name, Integer.valueOf(s.getPreviewRes()));
            if (s.getDate() != null) {
                cv.put(DbColumn.STYLE_REL_DATE.name, s.getDate().toString());
            }
            if (s.component != null) {
                cv.put(DbColumn.STYLE_COMP_NAME.name, s.component.flattenToShortString());
            }
            if (s.settings != null) {
                cv.put(DbColumn.STYLE_SETTINGS_ACTIVITY.name, s.settings.flattenToShortString());
            }
            cv.put(DbColumn.STYLE_SPAN_X.name, Integer.valueOf(s.view.sx));
            cv.put(DbColumn.STYLE_SPAN_Y.name, Integer.valueOf(s.view.sy));
            if (s.view.scene != null) {
                cv.put(DbColumn.STYLE_SCENE.name, s.view.scene);
            }
            list.add(cv);
        }
        if (list.isEmpty()) {
            return null;
        }
        return list;
    }

    public static String[] getProjection(DbProjection p) {
        return p.strings;
    }

    public static WidgetProvider.Info.Style styleAtCursor(PackageManager pm, Cursor c) {
        int index;
        int index2 = c.getColumnIndex(DbColumn.PROVIDER.name);
        String providerName = c.getString(index2);
        ComponentName provider = ComponentName.unflattenFromString(providerName);
        try {
            Resources res = pm.getResourcesForApplication(provider.getPackageName());
            try {
                int index3 = c.getColumnIndex(DbColumn.STYLE_TYPE_ID.name);
                try {
                    String id = c.getString(index3);
                    int nameRes = c.getInt(c.getColumnIndex(DbColumn.STYLE_NAME_RES.name));
                    CharSequence name = nameRes > 0 ? res.getText(nameRes) : null;
                    int imgRes = c.getInt(c.getColumnIndex(DbColumn.STYLE_PREVIEW_RES.name));
                    int descRes = c.getInt(c.getColumnIndex(DbColumn.STYLE_DESC_RES.name));
                    CharSequence desc = descRes > 0 ? res.getText(descRes) : null;
                    CharSequence date = c.getString(c.getColumnIndex(DbColumn.STYLE_REL_DATE.name));
                    index2 = c.getColumnIndex(DbColumn.STYLE_COMP_NAME.name);
                    String compStr = c.getString(index2);
                    ComponentName comp = null;
                    if (compStr != null) {
                        comp = ComponentName.unflattenFromString(compStr);
                    }
                    String settingsStr = c.getString(c.getColumnIndex(DbColumn.STYLE_SETTINGS_ACTIVITY.name));
                    ComponentName settings = null;
                    if (settingsStr != null) {
                        settings = ComponentName.unflattenFromString(settingsStr);
                    }
                    int sx = c.getInt(c.getColumnIndex(DbColumn.STYLE_SPAN_X.name));
                    int sy = c.getInt(c.getColumnIndex(DbColumn.STYLE_SPAN_Y.name));
                    index3 = c.getColumnIndex(DbColumn.STYLE_SCENE.name);
                    String scene = c.getString(index3);
                    return new WidgetProvider.Info.Style(id, nameRes, name, descRes, desc, date, imgRes, comp, settings, new WidgetProvider.Info.Style.ViewInfo(sx, sy, scene));
                } catch (Resources.NotFoundException e) {
                    index = index3;
                    Log.e(LOG_TAG, "error caused by cannot found out resource files");
                    return null;
                }
            } catch (Resources.NotFoundException e2) {
                index = index2;
            }
        } catch (PackageManager.NameNotFoundException e3) {
            e3.printStackTrace();
            return null;
        }
    }
}
