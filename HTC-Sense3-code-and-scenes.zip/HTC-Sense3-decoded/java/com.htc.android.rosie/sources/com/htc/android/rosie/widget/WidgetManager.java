package com.htc.android.rosie.widget;

import android.content.ComponentName;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import com.htc.android.rosie.widget.Widget;
import com.htc.fusion.fx.FxScene;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.android.rosie.dex */
public final class WidgetManager {
    public static final String EXTRA_STYLE_ID = "com.htc.android.rosie.intent.extra.STYLE_ID";
    public static final String EXTRA_STYLE_SCENE = "com.htc.android.rosie.intent.extra.STYLE_SCENE";
    public static final int INVALID_WIDGET_ID = -1;
    private static final String LOG_TAG = WidgetManager.class.getSimpleName();
    private static final boolean localLOGD = false;
    private static WidgetManager sInstance;
    private Map<ComponentName, WidgetProvider> mProviders = new HashMap();
    private List<WidgetRecord> mWidgets = new ArrayList();

    public interface Host extends Widget.Host {
        int[] getWidgetPosition(int i);
    }

    private WidgetManager() {
    }

    public static WidgetManager getInstance() {
        if (sInstance == null) {
            sInstance = new WidgetManager();
        }
        return sInstance;
    }

    public boolean bindWidgetId(int id, WidgetProvider provider, Intent intent, Widget.Host host, Properties data) throws ClassNotFoundException {
        WidgetRecord wr = findWidgetRecord(host, id);
        Bundle saved = null;
        boolean bound = false;
        if (wr != null) {
            saved = wr.mSavedState;
            bound = true;
        }
        Widget w = provider.loadWidgetWithIntent(intent, saved, data);
        if (w == null) {
            return false;
        }
        if (wr == null) {
            WidgetRecord wr2 = new WidgetRecord(id, w, host);
            bound = addWidget(wr2) == wr2;
        } else {
            wr.widget = w;
        }
        return bound;
    }

    private WidgetRecord addWidget(WidgetRecord widget) {
        synchronized (this.mWidgets) {
            for (WidgetRecord w : this.mWidgets) {
                if (w == widget) {
                    return w;
                }
                if (w.host == widget.host && w.id == widget.id) {
                    Log.w(LOG_TAG, "There is already a widget with same host and ID.");
                    return w;
                }
            }
            return this.mWidgets.add(widget) ? widget : null;
        }
    }

    private void removeWidget(WidgetRecord widget) {
        synchronized (this.mWidgets) {
            this.mWidgets.remove(widget);
        }
    }

    public WidgetRecord findWidgetRecord(Widget.Host host, int id) {
        synchronized (this.mWidgets) {
            for (WidgetRecord w : this.mWidgets) {
                if (w.host == host && w.id == id) {
                    return w;
                }
            }
            return null;
        }
    }

    public void unbindWidgetId(Widget.Host host, int id) {
        synchronized (this.mWidgets) {
            WidgetRecord w = findWidgetRecord(host, id);
            if (w != null) {
                removeWidget(w);
            }
        }
    }

    public WidgetProvider registerProvider(Widget.Host host, ComponentName provider) {
        synchronized (this.mProviders) {
            try {
                WidgetProvider p = this.mProviders.get(provider);
                if (p == null) {
                    WidgetProvider p2 = new WidgetProvider(host, provider);
                    try {
                        this.mProviders.put(provider, p2);
                        p = p2;
                    } catch (Throwable th) {
                        th = th;
                        throw th;
                    }
                }
                return p;
            } catch (Throwable th2) {
                th = th2;
            }
        }
    }

    public FxScene getWidgetScene(Widget.Host host, int id) {
        WidgetRecord wr = findWidgetRecord(host, id);
        if (wr == null) {
            return null;
        }
        return wr.widget.getScene();
    }

    public boolean startWidget(Widget.Host host, int id) {
        WidgetRecord wr = findWidgetRecord(host, id);
        if (wr == null || !wr.mPaused || !wr.mStopped) {
            return false;
        }
        Widget.Base b = (Widget.Base) wr.widget;
        if (wr.mNeedsRestart) {
            b.performRestart();
            wr.mNeedsRestart = false;
        }
        b.performStart();
        wr.mStopped = false;
        return true;
    }

    public boolean restoreWidgetState(Widget.Host host, int id) {
        WidgetRecord wr = findWidgetRecord(host, id);
        if (wr == null || wr.mStopped) {
            return false;
        }
        Widget.Base b = (Widget.Base) wr.widget;
        b.performRestoreState(wr.mSavedState);
        return true;
    }

    public boolean callWidgetOnPostCreate(Widget.Host host, int id) {
        WidgetRecord wr = findWidgetRecord(host, id);
        if (wr == null || wr.mStopped) {
            return false;
        }
        Widget.Base b = (Widget.Base) wr.widget;
        b.performPostCreate(wr.mSavedState);
        return true;
    }

    public boolean callWidgetOnConfigurationChanged(Widget.Host host, int id, Configuration newConfiguration) {
        WidgetRecord wr = findWidgetRecord(host, id);
        if (wr == null || wr.mStopped) {
            return false;
        }
        Widget.Base b = (Widget.Base) wr.widget;
        b.performConfigurationChanged(newConfiguration);
        return true;
    }

    public boolean callWidgetOnHostMessage(Widget.Host host, int id, Message msg) {
        WidgetRecord wr = findWidgetRecord(host, id);
        if (wr == null || wr.mStopped) {
            return false;
        }
        wr.widget.onHostMessage(msg);
        return true;
    }

    public boolean resumeWidget(Widget.Host host, int id) {
        WidgetRecord wr = findWidgetRecord(host, id);
        if (wr == null || !wr.mPaused || wr.mStopped) {
            return false;
        }
        ((Widget.Base) wr.widget).performResume(wr.mSavedState);
        wr.mPaused = false;
        return true;
    }

    public boolean pauseWidget(Widget.Host host, int id, boolean saveState) {
        WidgetRecord wr = findWidgetRecord(host, id);
        if (wr == null || wr.mPaused || wr.mStopped) {
            return false;
        }
        Bundle saved = null;
        if (saveState) {
            saved = new Bundle();
            wr.mSavedState = saved;
        }
        ((Widget.Base) wr.widget).performPause(saved);
        wr.mPaused = true;
        return true;
    }

    public boolean stopWidget(Widget.Host host, int id) {
        WidgetRecord wr = findWidgetRecord(host, id);
        if (wr == null || !wr.mPaused || wr.mStopped) {
            return false;
        }
        ((Widget.Base) wr.widget).performStop();
        wr.mStopped = true;
        wr.mNeedsRestart = true;
        return true;
    }

    public boolean destroyWidget(Widget.Host host, int id) {
        WidgetRecord wr = findWidgetRecord(host, id);
        if (wr == null) {
            Log.w(LOG_TAG, "widget(" + host + "," + id + ") not bound or already destroyed.");
            return false;
        }
        ((Widget.Base) wr.widget).performDestroy();
        return true;
    }

    int getWidgetId(Widget widget) {
        for (WidgetRecord wr : this.mWidgets) {
            if (wr.widget == widget) {
                return wr.id;
            }
        }
        return -1;
    }

    int[] getWidgetPosition(Widget widget) {
        int[] pos = null;
        for (WidgetRecord wr : this.mWidgets) {
            if (wr.widget == widget) {
                if (wr.host instanceof Host) {
                    pos = ((Host) wr.host).getWidgetPosition(wr.id);
                } else {
                    Log.w(LOG_TAG, "widget(" + wr.host + "," + wr.id + ") called getWidgetPosition() but the host does not implement it.");
                }
            }
        }
        return pos;
    }

    public boolean dispatchActivityResult(Widget.Host host, int id, int requestCode, int resultCode, Intent data) {
        WidgetRecord wr = findWidgetRecord(host, id);
        if (wr == null) {
            Log.w(LOG_TAG, "widget(" + host + "," + id + ") not bound or already destroyed.");
            return false;
        }
        ((Widget.Base) wr.widget).dispatchActivityResult(requestCode, resultCode, data);
        return true;
    }

    public boolean isEditable(Widget.Host host, int id) {
        WidgetRecord wr = findWidgetRecord(host, id);
        if (wr == null) {
            return false;
        }
        boolean isEditable = ((Widget.Base) wr.widget).isEditable();
        return isEditable;
    }

    public boolean editWidget(Widget.Host host, int id) {
        WidgetRecord wr = findWidgetRecord(host, id);
        if (wr == null) {
            return false;
        }
        ((Widget.Base) wr.widget).onEdit();
        return true;
    }

    public boolean setWidgetVisibility(Widget.Host host, int id, boolean visible) {
        WidgetRecord wr = findWidgetRecord(host, id);
        if (wr == null) {
            return false;
        }
        wr.widget.onVisibilityChanged(visible);
        return true;
    }

    public boolean setWidgetTilt(Widget.Host host, int id, float tilt) {
        WidgetRecord wr = findWidgetRecord(host, id);
        if (wr == null) {
            return false;
        }
        wr.widget.onTiltChanged(tilt);
        return true;
    }

    private static final class WidgetRecord {
        private final Widget.Host host;
        public final int id;
        private boolean mNeedsRestart;
        private boolean mPaused;
        private Bundle mSavedState;
        private boolean mStopped;
        private Widget widget;

        private WidgetRecord(int id, Widget widget, Widget.Host host) {
            this.mPaused = true;
            this.mStopped = true;
            this.mNeedsRestart = false;
            this.id = id;
            this.widget = widget;
            this.host = host;
        }
    }
}
