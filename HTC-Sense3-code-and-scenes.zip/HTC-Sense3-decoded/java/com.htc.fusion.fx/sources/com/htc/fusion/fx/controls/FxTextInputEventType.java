package com.htc.fusion.fx.controls;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public final class FxTextInputEventType {
    public static final int ENTERINPUTMODE = 1;
    public static final int EXITINPUTMODE = 2;
}
