package com.htc.fusion.fx;

import android.app.Activity;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public abstract class MessageActivityListener<T> extends MessageListener<T> {
    private MessageActivityListener<T>.InnerListener mInnerListener;

    public MessageActivityListener(Activity activity) {
        this.mInnerListener = new InnerListener(activity);
    }

    @Override // com.htc.fusion.fx.MessageListener, com.htc.fusion.fx.IMessageListener
    public void setSource_ONLY_THE_SOURCE_SHOULD_CALL_THIS(IMessageSource<T> source) {
        if (source != null) {
            source.unbind(this);
            source.bind(this.mInnerListener);
        } else {
            unbind();
        }
    }

    @Override // com.htc.fusion.fx.MessageListener, com.htc.fusion.fx.IMessageListener
    public void unbind() {
        this.mInnerListener.unbind();
    }

    private class InnerListener extends MessageListener<T> {
        private Activity mActivity;

        public InnerListener(Activity activity) {
            this.mActivity = activity;
        }

        @Override // com.htc.fusion.fx.IMessageListener
        public void onMessageReceived(T message) {
            MessageActivityListener<T>.InnerListener.OuterCaller outerCaller = new OuterCaller(message);
            this.mActivity.runOnUiThread(outerCaller);
        }

        private class OuterCaller implements Runnable {
            private T mMessageParam;

            public OuterCaller(T message) {
                this.mMessageParam = message;
            }

            @Override // java.lang.Runnable
            public void run() {
                MessageActivityListener.this.onMessageReceived(this.mMessageParam);
            }
        }
    }
}
