package com.htc.fusion.fx;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxTimelineControl extends FxNodeControl {
    private native void freezeNative();

    /* JADX INFO: Access modifiers changed from: private */
    public native boolean waitForPendingFreezes(long j);

    public native boolean containsMarker(String str);

    public native float getFrame();

    public native Marker getMarker(String str);

    public native IMessageSource<FxPlaybackInfo> getPlaybackCompleteSource();

    public native boolean isPlaying();

    public native void playFrames(int i, int i2, int i3, float f, boolean z, int i4, int i5);

    public native void playMarker(String str, int i, float f, boolean z, int i2, int i3);

    public native void playWithName(String str, int i, int i2, int i3, float f, boolean z, int i4, int i5);

    public native void pulseFreeze();

    public native void setAsync(boolean z);

    public native void setFrame(float f);

    public native void stop();

    public native void thaw(boolean z);

    protected FxTimelineControl(int handle) {
        super(handle);
    }

    public void playMarker(String name) {
        playMarker(name, 0, 1.0f, true);
    }

    public void playMarker(String name, int playbackMode, float playbackSpeed, boolean triggerEvent) {
        playMarker(name, playbackMode, playbackSpeed, triggerEvent, 0);
    }

    public void playMarker(String name, int playbackMode, float playbackSpeed, boolean triggerEvent, int delayFrames) {
        playMarker(name, playbackMode, playbackSpeed, triggerEvent, delayFrames, 0);
    }

    public void playFrames(int start, int end) {
        playFrames(start, end, 0, 1.0f, true);
    }

    public void playFrames(int start, int end, int playbackMode, float playbackSpeed, boolean triggerEvent) {
        playFrames(start, end, playbackMode, playbackSpeed, triggerEvent, 0);
    }

    public void playFrames(int start, int end, int playbackMode, float playbackSpeed, boolean triggerEvent, int delayFrames) {
        playFrames(start, end, playbackMode, playbackSpeed, triggerEvent, delayFrames, 0);
    }

    public void playWithName(String name, int start, int end) {
        playWithName(name, start, end, 0, 1.0f, true, 0);
    }

    public void playWithName(String name, int start, int end, int playbackMode, float playbackSpeed, boolean triggerEvent) {
        playWithName(name, start, end, playbackMode, playbackSpeed, triggerEvent, 0);
    }

    public void playWithName(String name, int start, int end, int playbackMode, float playbackSpeed, boolean triggerEvent, int delayFrames) {
        playWithName(name, start, end, playbackMode, playbackSpeed, triggerEvent, delayFrames, 0);
    }

    public Future<Boolean> freeze() {
        freezeNative();
        return new FreezeFuture();
    }

    public void thaw() {
        thaw(false);
    }

    private class FreezeFuture implements Future<Boolean> {
        private FreezeFuture() {
        }

        @Override // java.util.concurrent.Future
        public boolean cancel(boolean mayInterruptIfRunning) {
            return false;
        }

        @Override // java.util.concurrent.Future
        public boolean isCancelled() {
            return false;
        }

        @Override // java.util.concurrent.Future
        public boolean isDone() {
            return FxTimelineControl.this.waitForPendingFreezes(0L);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // java.util.concurrent.Future
        public Boolean get() throws InterruptedException, ExecutionException {
            FxTimelineControl.this.waitForPendingFreezes(-1L);
            return true;
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // java.util.concurrent.Future
        public Boolean get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
            if (!FxTimelineControl.this.waitForPendingFreezes(TimeUnit.MILLISECONDS.convert(timeout, unit))) {
                throw new TimeoutException();
            }
            return true;
        }
    }
}
