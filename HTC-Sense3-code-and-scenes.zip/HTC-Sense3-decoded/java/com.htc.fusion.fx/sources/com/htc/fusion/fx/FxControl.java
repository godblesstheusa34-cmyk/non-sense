package com.htc.fusion.fx;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxControl extends FxObject {
    public native FxViewObject getViewObject();

    protected FxControl(int handle) {
        super(handle);
    }
}
