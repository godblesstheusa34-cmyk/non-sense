package com.htc.fusion.fx;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public final class FxPlaybackMode {
    public static final int LOOPING = 1;
    public static final int NOT_SET = -1;
    public static final int PING_PONG = 2;
    public static final int STOP_AT_END = 0;
}
