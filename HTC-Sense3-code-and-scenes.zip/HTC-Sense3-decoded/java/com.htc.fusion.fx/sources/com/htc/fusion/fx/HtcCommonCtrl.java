package com.htc.fusion.fx;

import android.util.Log;
import dalvik.system.PathClassLoader;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public final class HtcCommonCtrl {
    private static PathClassLoader mLoader = new PathClassLoader("/system/framework/com.htc.commonctrl.jar", ClassLoader.getSystemClassLoader());

    private HtcCommonCtrl() {
        throw new AssertionError();
    }

    public static Class<?> loadClass(String className) {
        if (mLoader == null) {
            return null;
        }
        try {
            return mLoader.loadClass(className);
        } catch (Exception e) {
            Log.e("mode10", "Unable to load class " + className);
            e.printStackTrace();
            return null;
        }
    }
}
