package com.htc.fusion.fx.controls;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import com.htc.fusion.fx.FxTimelineControl;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxDynamicImage extends FxTimelineControl {
    private native void setImageNativeFromPath(AssetManager assetManager, String str);

    @Override // com.htc.fusion.fx.FxNodeControl
    public native PointF getSize();

    public native void setFailed();

    public native void setImage(Bitmap bitmap);

    public native void setImage(Drawable drawable);

    public native void setLoading();

    public FxDynamicImage(int handle) {
        super(handle);
    }

    public void setImage(Context context, String path) {
        if (context == null || path == null) {
            throw new IllegalArgumentException("Context or path cannot be null");
        }
        setImageNativeFromPath(context.getAssets(), path);
    }
}
