package com.htc.fusion.fx;

import android.graphics.Bitmap;
import android.view.Surface;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxViewObject extends FxObject {

    private interface FutureBase<T> extends Future<T> {
        void set(T t);
    }

    private native void clearJavaView();

    public static native FxViewObject create(FxView fxView);

    private native void nativeCaptureBackBuffer(FutureBase<Bitmap> futureBase);

    public native void addScene(FxScene fxScene);

    public native Bitmap captureBackBuffer();

    public native FxScene createScene(FxSceneLoader fxSceneLoader, boolean z);

    public native boolean initLivePreviewHost(boolean z, int i, boolean z2);

    public native boolean loadLibraries(String str);

    public native boolean onTouchEvent(int i, int i2, float f, float f2);

    public native void pauseRendering();

    public native boolean perfReportsEnabled();

    public native void removeScene(FxScene fxScene);

    public native void resumeRendering();

    public native void setClearColor(int i);

    public native void setJavaView(FxView fxView);

    public native void setLivePreviewDescription(String str);

    public native void setPackageResourcePath(String str);

    public native void setSurface(Surface surface, int i, int i2, int i3);

    public native void shutdownLivePreviewHost();

    public native void waitForLivePreviewConnected();

    public native boolean writePerfReport(String str);

    protected FxViewObject(int handle) {
        super(handle);
    }

    public void dispose() {
        clearJavaView();
        clearHandle();
    }

    public FxScene createScene(String fileName, boolean initialVisibility) {
        return createScene(FxSceneLoader.create(fileName), initialVisibility);
    }

    public Future<Bitmap> captureBackBufferEx() {
        BasicFuture<Bitmap> backbufferFuture = new BasicFuture<>();
        nativeCaptureBackBuffer(backbufferFuture);
        return backbufferFuture;
    }

    private class BasicFuture<T> implements FutureBase<T> {
        private boolean m_fIsSet;
        private Object m_lock;
        private T m_value;

        private BasicFuture() {
            this.m_lock = new Object();
            this.m_value = null;
            this.m_fIsSet = false;
        }

        @Override // java.util.concurrent.Future
        public boolean cancel(boolean mayInterruptIfRunning) {
            return false;
        }

        @Override // java.util.concurrent.Future
        public boolean isCancelled() {
            return false;
        }

        @Override // java.util.concurrent.Future
        public boolean isDone() {
            boolean z;
            synchronized (this.m_lock) {
                z = this.m_fIsSet;
            }
            return z;
        }

        @Override // java.util.concurrent.Future
        public T get() throws InterruptedException, ExecutionException {
            synchronized (this.m_lock) {
                if (!this.m_fIsSet) {
                    this.m_lock.wait();
                    if (!this.m_fIsSet) {
                        return null;
                    }
                }
                return this.m_value;
            }
        }

        @Override // java.util.concurrent.Future
        public T get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
            T t;
            synchronized (this.m_lock) {
                if (!this.m_fIsSet) {
                    this.m_lock.wait(unit.toMillis(timeout));
                    if (!this.m_fIsSet) {
                        throw new TimeoutException();
                    }
                }
                t = this.m_value;
            }
            return t;
        }

        @Override // com.htc.fusion.fx.FxViewObject.FutureBase
        public void set(T value) {
            synchronized (this.m_lock) {
                this.m_fIsSet = true;
                this.m_value = value;
                this.m_lock.notifyAll();
            }
        }
    }
}
