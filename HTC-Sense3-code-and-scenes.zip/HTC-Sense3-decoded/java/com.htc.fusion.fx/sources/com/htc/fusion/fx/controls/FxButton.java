package com.htc.fusion.fx.controls;

import android.view.View;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.IMessageListener;
import com.htc.fusion.fx.IMessageSource;
import com.htc.fusion.fx.MessageListener;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxButton extends FxTimelineControl {
    private IMessageListener<Void> onClickListenerCompatibleListener;

    public native IMessageSource<ClickParameters> getClickEventSource();

    public native IMessageSource<Void> getClickSource();

    public native boolean getEnabled();

    public native void setEnabled(boolean z);

    protected FxButton(int handle) {
        super(handle);
    }

    public static class ClickParameters {
        public FxButton object;

        public ClickParameters(FxButton obj) {
            this.object = obj;
        }
    }

    public void bindClick(IMessageListener<Void> listener) {
        getClickSource().bind(listener);
    }

    public void unbindClick(IMessageListener<Void> listener) {
        getClickSource().unbind(listener);
    }

    public void setOnClickListener(final View.OnClickListener l) {
        IMessageSource<Void> clickSource = getClickSource();
        if (this.onClickListenerCompatibleListener != null) {
            clickSource.unbind(this.onClickListenerCompatibleListener);
        }
        this.onClickListenerCompatibleListener = l == null ? null : new MessageListener<Void>() { // from class: com.htc.fusion.fx.controls.FxButton.1
            @Override // com.htc.fusion.fx.IMessageListener
            public void onMessageReceived(Void message) {
                l.onClick(null);
            }
        };
        if (this.onClickListenerCompatibleListener != null) {
            clickSource.bind(this.onClickListenerCompatibleListener);
        }
    }
}
