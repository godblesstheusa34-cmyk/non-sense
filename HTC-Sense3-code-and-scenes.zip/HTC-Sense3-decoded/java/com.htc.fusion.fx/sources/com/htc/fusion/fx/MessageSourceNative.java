package com.htc.fusion.fx;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
class MessageSourceNative<T> extends MessageSource<T> {
    private int nativeHandle;

    private native void deleteNative();

    MessageSourceNative() {
    }

    static {
        FxObject.loadNativeLibrary();
    }

    protected void finalize() throws Throwable {
        try {
            deleteNative();
        } finally {
            super.finalize();
        }
    }
}
