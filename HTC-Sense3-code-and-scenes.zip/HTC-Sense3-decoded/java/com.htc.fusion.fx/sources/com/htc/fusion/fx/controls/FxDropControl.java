package com.htc.fusion.fx.controls;

import com.htc.fusion.fx.FxDraggable;
import com.htc.fusion.fx.FxDroppable;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.IMessageSource;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxDropControl extends FxTimelineControl implements FxDroppable {
    @Override // com.htc.fusion.fx.FxDroppable
    public native void drop(FxDraggable fxDraggable);

    @Override // com.htc.fusion.fx.FxDroppable
    public native void dropActivate(FxDraggable fxDraggable);

    @Override // com.htc.fusion.fx.FxDroppable
    public native void dropDeactivate(FxDraggable fxDraggable);

    @Override // com.htc.fusion.fx.FxDroppable
    public native String[] getDragScope();

    @Override // com.htc.fusion.fx.FxDroppable
    public native IMessageSource<FxDraggable> getDropActivateSource();

    @Override // com.htc.fusion.fx.FxDroppable
    public native IMessageSource<FxDraggable> getDropDeactivateSource();

    @Override // com.htc.fusion.fx.FxDroppable
    public native IMessageSource<FxDraggable> getDropOutSource();

    @Override // com.htc.fusion.fx.FxDroppable
    public native IMessageSource<FxDraggable> getDropOverSource();

    @Override // com.htc.fusion.fx.FxDroppable
    public native IMessageSource<FxDraggable> getDropSource();

    @Override // com.htc.fusion.fx.FxDroppable
    public native boolean isEnabled();

    @Override // com.htc.fusion.fx.FxDroppable
    public native void setDragScope(String[] strArr);

    @Override // com.htc.fusion.fx.FxDroppable
    public native void setEnabled(boolean z);

    public FxDropControl(int handle) {
        super(handle);
    }

    @Override // com.htc.fusion.fx.FxDroppable
    public void setOnDropActivateListener(FxDroppable.OnDragEventListener listener) {
        getDropActivateSource().bind(listener);
    }

    @Override // com.htc.fusion.fx.FxDroppable
    public void setOnDropDeactivateListener(FxDroppable.OnDragEventListener listener) {
        getDropDeactivateSource().bind(listener);
    }

    @Override // com.htc.fusion.fx.FxDroppable
    public void setOnDropListener(FxDroppable.OnDragEventListener listener) {
        getDropSource().bind(listener);
    }

    @Override // com.htc.fusion.fx.FxDroppable
    public void setOnDropOverListener(FxDroppable.OnDragEventListener listener) {
        getDropOverSource().bind(listener);
    }

    @Override // com.htc.fusion.fx.FxDroppable
    public void setOnDropOutListener(FxDroppable.OnDragEventListener listener) {
        getDropOutSource().bind(listener);
    }

    public String toString() {
        return "FxDropControl [name=" + getName() + "]";
    }
}
