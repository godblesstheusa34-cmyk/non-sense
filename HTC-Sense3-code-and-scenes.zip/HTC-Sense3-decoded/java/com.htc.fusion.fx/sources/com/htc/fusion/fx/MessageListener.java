package com.htc.fusion.fx;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public abstract class MessageListener<T> implements IMessageListener<T> {
    private IMessageSource<T> source;

    @Override // com.htc.fusion.fx.IMessageListener
    public void setSource_ONLY_THE_SOURCE_SHOULD_CALL_THIS(IMessageSource<T> source) {
        this.source = source;
    }

    @Override // com.htc.fusion.fx.IMessageListener
    public void unbind() {
        if (this.source != null) {
            this.source.unbind(this);
        }
    }
}
