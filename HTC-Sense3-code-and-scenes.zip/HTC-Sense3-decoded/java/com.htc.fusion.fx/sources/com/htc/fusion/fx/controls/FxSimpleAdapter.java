package com.htc.fusion.fx.controls;

import android.content.Context;
import com.htc.fusion.fx.FxControl;
import java.util.List;
import java.util.Map;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxSimpleAdapter extends FxBaseAdapter {
    static final /* synthetic */ boolean $assertionsDisabled;
    private final Context mContext;
    private final String[] mControl;
    private final String[] mFrom;
    private FxListItemBinder mFxListItemBinder = new FxListItemBinder();
    private final List<? extends Map<String, ?>> mObjects;

    static {
        $assertionsDisabled = !FxSimpleAdapter.class.desiredAssertionStatus();
    }

    public FxSimpleAdapter(Context context, List<? extends Map<String, ?>> arraylist, String[] from, String[] control) {
        this.mContext = context;
        this.mObjects = arraylist;
        this.mFrom = from;
        this.mControl = control;
    }

    @Override // com.htc.fusion.fx.controls.FxBaseAdapter
    public int getCount() {
        return this.mObjects.size();
    }

    public Object getItem(int position) {
        return this.mObjects.get(position);
    }

    public Map<String, ?> getMapItem(int position) {
        return this.mObjects.get(position);
    }

    public FxListItemBinder getFxListItemBinder() {
        return this.mFxListItemBinder;
    }

    public void setFxListItemBinder(FxListItemBinder fxListItemBinder) {
        if (fxListItemBinder == null) {
            throw new NullPointerException("fxListItemBinder of setFxListItemBinder(FxListItemBinder fxListItemBinder) is null reference.");
        }
        this.mFxListItemBinder = fxListItemBinder;
    }

    @Override // com.htc.fusion.fx.controls.FxBaseAdapter
    protected void setFxListItemData(int position, FxListItem fxListItem) {
        if (this.mObjects != null) {
            Map<String, ?> dataSet = this.mObjects.get(position);
            for (int i = 0; i < this.mControl.length; i++) {
                Object data = dataSet.get(this.mFrom[i]);
                FxControl fx_control = (FxControl) fxListItem.getDescendant(this.mControl[i]);
                if (!$assertionsDisabled && fx_control == null) {
                    throw new AssertionError("FxListItem1.getDescendant(mFxTextLabelControl)=null");
                }
                this.mFxListItemBinder.setFxListItemValue(this.mContext, position, fx_control, data);
            }
        }
    }
}
