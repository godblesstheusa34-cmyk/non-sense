package com.htc.fusion.fx;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class Change<T> {
    private final T newValue;
    private final T oldValue;

    public Change(T oldValue, T newValue) {
        this.oldValue = oldValue;
        this.newValue = newValue;
    }

    public T getOldValue() {
        return this.oldValue;
    }

    public T getNewValue() {
        return this.newValue;
    }
}
