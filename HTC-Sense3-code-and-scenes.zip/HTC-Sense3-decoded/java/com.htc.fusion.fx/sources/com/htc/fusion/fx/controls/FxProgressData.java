package com.htc.fusion.fx.controls;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxProgressData {
    public float newValue;
    public FxProgressBar object;
    public float percentageOffset;
    public boolean touchDriven;
}
