package com.htc.fusion;

import android.util.FloatMath;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class Point3F {
    public float x;
    public float y;
    public float z;

    public Point3F() {
    }

    public Point3F(float x, float y, float z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public final void set(float x, float y, float z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public final void set(Point3F p) {
        this.x = p.x;
        this.y = p.y;
        this.z = p.z;
    }

    public final void negate() {
        this.x = -this.x;
        this.y = -this.y;
        this.z = -this.z;
    }

    public final void offset(float dx, float dy, float dz) {
        this.x += dx;
        this.y += dy;
        this.z += dz;
    }

    public final boolean equals(float x, float y, float z) {
        return this.x == x && this.y == y && this.z == z;
    }

    public final float length() {
        return length(this.x, this.y, this.z);
    }

    public static float length(float x, float y, float z) {
        return FloatMath.sqrt((x * x) + (y * y) + (z * z));
    }
}
