package com.htc.fusion.fx.controls;

import com.htc.fusion.fx.FxControl;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxTextInputEvent {
    public FxControl control;
    public int eventType;

    protected FxTextInputEvent(FxControl control, int eventType) {
        this.control = control;
        this.eventType = eventType;
    }
}
