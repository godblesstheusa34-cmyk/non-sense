package com.htc.fusion.fx;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public final class FxTimeMapFunction {
    public static final int EASE_IN_BACK = 33;
    public static final int EASE_IN_BOUNCE = 37;
    public static final int EASE_IN_CIRC = 25;
    public static final int EASE_IN_CUBIC = 5;
    public static final int EASE_IN_ELASTIC = 29;
    public static final int EASE_IN_EXPO = 21;
    public static final int EASE_IN_OUT_BACK = 35;
    public static final int EASE_IN_OUT_BOUNCE = 39;
    public static final int EASE_IN_OUT_CIRC = 27;
    public static final int EASE_IN_OUT_CUBIC = 7;
    public static final int EASE_IN_OUT_ELASTIC = 31;
    public static final int EASE_IN_OUT_EXPO = 23;
    public static final int EASE_IN_OUT_QUAD = 3;
    public static final int EASE_IN_OUT_QUART = 11;
    public static final int EASE_IN_OUT_QUINT = 15;
    public static final int EASE_IN_OUT_SINE = 19;
    public static final int EASE_IN_QUAD = 1;
    public static final int EASE_IN_QUART = 9;
    public static final int EASE_IN_QUINT = 13;
    public static final int EASE_IN_SINE = 17;
    public static final int EASE_OUT_BACK = 34;
    public static final int EASE_OUT_BOUNCE = 38;
    public static final int EASE_OUT_CIRC = 26;
    public static final int EASE_OUT_CUBIC = 6;
    public static final int EASE_OUT_ELASTIC = 30;
    public static final int EASE_OUT_EXPO = 22;
    public static final int EASE_OUT_IN_BACK = 36;
    public static final int EASE_OUT_IN_BOUNCE = 40;
    public static final int EASE_OUT_IN_CIRC = 28;
    public static final int EASE_OUT_IN_CUBIC = 8;
    public static final int EASE_OUT_IN_ELASTIC = 32;
    public static final int EASE_OUT_IN_EXPO = 24;
    public static final int EASE_OUT_IN_QUAD = 4;
    public static final int EASE_OUT_IN_QUART = 12;
    public static final int EASE_OUT_IN_QUINT = 16;
    public static final int EASE_OUT_IN_SINE = 20;
    public static final int EASE_OUT_QUAD = 2;
    public static final int EASE_OUT_QUART = 10;
    public static final int EASE_OUT_QUINT = 14;
    public static final int EASE_OUT_SINE = 18;
    public static final int LINEAR = 0;
}
