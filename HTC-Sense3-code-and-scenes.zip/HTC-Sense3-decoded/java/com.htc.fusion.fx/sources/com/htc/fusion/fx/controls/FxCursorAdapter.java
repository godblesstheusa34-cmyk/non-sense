package com.htc.fusion.fx.controls;

import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.os.Handler;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public abstract class FxCursorAdapter extends FxBaseAdapter {
    protected boolean mAutoRequery;
    protected final ChangeObserver mChangeObserver;
    protected Context mContext;
    protected Cursor mCursor;
    protected final DataSetObserver mDataSetObserver;
    protected boolean mDataValid;
    private final Object mLock = new Object();
    protected int mRowIDColumn;

    public abstract FxListItemBinder getFxListItemBinder();

    public abstract void setFxListItemBinder(FxListItemBinder fxListItemBinder);

    public FxCursorAdapter(Context context, Cursor c, boolean autoRequery) {
        if (c == null) {
            throw new NullPointerException("Cursor c can't be null reference.");
        }
        this.mContext = context;
        this.mCursor = c;
        this.mDataValid = true;
        this.mRowIDColumn = c.getColumnIndexOrThrow("_id");
        this.mAutoRequery = autoRequery;
        this.mChangeObserver = new ChangeObserver();
        this.mDataSetObserver = new MyDataSetObserver();
        c.registerContentObserver(this.mChangeObserver);
        c.registerDataSetObserver(this.mDataSetObserver);
    }

    public Cursor getCursor() {
        return this.mCursor;
    }

    @Override // com.htc.fusion.fx.controls.FxBaseAdapter
    public int getCount() {
        if (!this.mDataValid || this.mCursor == null) {
            return 0;
        }
        return this.mCursor.getCount();
    }

    public Cursor getItem(int position) {
        if (!this.mDataValid || this.mCursor == null) {
            return null;
        }
        this.mCursor.moveToPosition(position);
        return this.mCursor;
    }

    public long getItemId(int position) {
        if (!this.mDataValid || this.mCursor == null) {
            return 0L;
        }
        if (this.mCursor.moveToPosition(position)) {
            return this.mCursor.getLong(this.mRowIDColumn);
        }
        return 0L;
    }

    public void changeCursor(Cursor cursor) {
        synchronized (this.mLock) {
            if (cursor != this.mCursor) {
                if (cursor == null) {
                    throw new NullPointerException("Cursor cursor can't be null reference.");
                }
                this.mCursor.unregisterContentObserver(this.mChangeObserver);
                this.mCursor.unregisterDataSetObserver(this.mDataSetObserver);
                this.mCursor.close();
                this.mCursor = cursor;
                this.mCursor.registerContentObserver(this.mChangeObserver);
                this.mCursor.registerDataSetObserver(this.mDataSetObserver);
                this.mRowIDColumn = cursor.getColumnIndexOrThrow("_id");
                this.mDataValid = true;
                if (this.mfxCollection != null) {
                    this.mfxCollection = FxListViewCollection.create(this.mCursor.getCount());
                    this.mfxListView.setCollection(this.mfxCollection);
                }
            }
        }
    }

    @Override // com.htc.fusion.fx.controls.FxBaseAdapter
    public void notifyDataSetChanged() {
        synchronized (this.mLock) {
            this.mDataValid = true;
            super.notifyDataSetChanged();
        }
    }

    protected void onContentChanged() {
        synchronized (this.mLock) {
            if (this.mAutoRequery && this.mCursor != null && !this.mCursor.isClosed()) {
                this.mDataValid = this.mCursor.requery();
            }
        }
    }

    private class ChangeObserver extends ContentObserver {
        public ChangeObserver() {
            super(new Handler());
        }

        @Override // android.database.ContentObserver
        public boolean deliverSelfNotifications() {
            return true;
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean selfChange) {
            FxCursorAdapter.this.onContentChanged();
        }
    }

    private class MyDataSetObserver extends DataSetObserver {
        private MyDataSetObserver() {
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            FxCursorAdapter.this.notifyDataSetChanged();
        }

        @Override // android.database.DataSetObserver
        public void onInvalidated() {
            synchronized (FxCursorAdapter.this.mLock) {
                FxCursorAdapter.this.mDataValid = false;
                if (FxCursorAdapter.this.mfxCollection != null) {
                    FxCursorAdapter.this.mfxCollection.removeItems(0, FxCursorAdapter.this.getCount());
                }
            }
        }
    }
}
