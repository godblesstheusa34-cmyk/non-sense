package com.htc.fusion.fx.controls;

import android.content.Context;
import android.database.Cursor;
import com.htc.fusion.fx.FxControl;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxSimpleCursorAdapter extends FxCursorAdapter {
    static final /* synthetic */ boolean $assertionsDisabled;
    private String[] mControl;
    private String[] mFrom;
    private FxListItemBinder mFxListItemBinder;

    static {
        $assertionsDisabled = !FxSimpleCursorAdapter.class.desiredAssertionStatus();
    }

    public FxSimpleCursorAdapter(Context context, Cursor c, String[] from, String[] control) {
        super(context, c, true);
        this.mFrom = from;
        this.mControl = control;
        this.mFxListItemBinder = new FxListItemBinder();
    }

    @Override // com.htc.fusion.fx.controls.FxCursorAdapter
    public void changeCursor(Cursor c) {
        super.changeCursor(c);
    }

    public void changeCursorAndColumns(Cursor c, String[] from, String[] control) {
        this.mFrom = from;
        this.mControl = control;
        super.changeCursor(c);
    }

    @Override // com.htc.fusion.fx.controls.FxCursorAdapter
    public FxListItemBinder getFxListItemBinder() {
        return this.mFxListItemBinder;
    }

    @Override // com.htc.fusion.fx.controls.FxCursorAdapter
    public void setFxListItemBinder(FxListItemBinder fxListItemBinder) {
        if (fxListItemBinder == null) {
            throw new NullPointerException("fxListItemBinder of setFxListItemBinder(FxListItemBinder fxListItemBinder) is null reference.");
        }
        this.mFxListItemBinder = fxListItemBinder;
    }

    @Override // com.htc.fusion.fx.controls.FxBaseAdapter
    protected void setFxListItemData(int position, FxListItem fxListItem) {
        if (this.mCursor != null) {
            this.mCursor.moveToPosition(position);
            int count = this.mControl.length;
            for (int i = 0; i < count; i++) {
                String data = this.mCursor.getString(this.mCursor.getColumnIndexOrThrow(this.mFrom[i]));
                FxControl fx_control = (FxControl) fxListItem.getDescendant(this.mControl[i]);
                if (!$assertionsDisabled && fx_control == null) {
                    throw new AssertionError("FxListItem1.getDescendant(mFxTextLabelControl)=null");
                }
                this.mFxListItemBinder.setFxListItemValue(this.mContext, position, fx_control, data);
            }
        }
    }
}
