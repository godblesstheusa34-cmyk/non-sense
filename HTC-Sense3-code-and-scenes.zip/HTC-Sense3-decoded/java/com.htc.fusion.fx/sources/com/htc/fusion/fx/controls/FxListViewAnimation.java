package com.htc.fusion.fx.controls;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public final class FxListViewAnimation {
    public static final int ANIMATE = 1;
    public static final int INSTANT = 0;
}
