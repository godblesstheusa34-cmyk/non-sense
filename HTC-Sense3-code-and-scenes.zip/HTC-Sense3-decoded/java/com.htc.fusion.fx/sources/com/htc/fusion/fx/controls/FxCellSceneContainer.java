package com.htc.fusion.fx.controls;

import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import com.htc.fusion.fx.FxScene;
import com.htc.fusion.fx.FxTimelineControl;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxCellSceneContainer extends FxTimelineControl {
    public static final int Z_ORDER_BOTTOM_MOST = 2;
    public static final int Z_ORDER_NORMAL = 1;
    public static final int Z_ORDER_TOP_MOST = 0;

    private native Point getCellExtentNative();

    private native Point getCellPropertiesNative();

    private native Point rectToCellNative(Point point);

    private native Point sceneToCellNative(FxScene fxScene);

    public native boolean addScene(FxScene fxScene, Rect rect);

    public native boolean addScenes(FxScene[] fxSceneArr, Rect[] rectArr);

    public native Rect cellToRect(Rect rect);

    public native boolean changeScenePos(FxScene fxScene, Rect rect);

    public native boolean changeScenesPos(FxScene[] fxSceneArr, Rect[] rectArr);

    public native void fadeScene(FxScene fxScene, int i, float f);

    public native void fadeScenes(FxScene[] fxSceneArr, int[] iArr, float[] fArr);

    public native Rect getCellExtent();

    public native void hideIndicator();

    public native void moveScene(FxScene fxScene, Rect rect, float f);

    public native void moveScenes(FxScene[] fxSceneArr, Rect[] rectArr, float[] fArr);

    public native boolean removeScene(FxScene fxScene);

    public native boolean removeSceneFromContainer(FxScene fxScene);

    public native boolean removeScenes(FxScene[] fxSceneArr);

    public native boolean removeScenesFromContainer(FxScene[] fxSceneArr);

    public native boolean setSceneZOrder(FxScene fxScene, int i);

    public native void setShadowRegion(Rect rect, boolean z);

    public native void setTouchPosition(Point point);

    protected FxCellSceneContainer(int handle) {
        super(handle);
    }

    public class RectangleSize {
        public int nHeight;
        public int nWidth;

        public RectangleSize(int nWidthIn, int nHeightIn) {
            this.nWidth = nWidthIn;
            this.nHeight = nHeightIn;
        }
    }

    public static class AnimationInfo {
        public FxScene scene;

        public AnimationInfo(FxScene obj) {
            this.scene = obj;
        }
    }

    public RectF rectToCell(RectF rectQueried) {
        Point pointIn = recfToPoint(rectQueried);
        Point pointOut = rectToCellNative(pointIn);
        RectF rectfReturn = pointToRectf(pointOut);
        return rectfReturn;
    }

    public RectangleSize rectToCell(RectangleSize rectQueried) {
        Point pointIn = rectangleToPoint(rectQueried);
        Point pointOut = rectToCellNative(pointIn);
        RectangleSize rectReturn = pointToRectangle(pointOut);
        return rectReturn;
    }

    public RectF SceneToCell(FxScene scene) {
        Point pointOut = sceneToCellNative(scene);
        RectF rectfReturn = pointToRectf(pointOut);
        return rectfReturn;
    }

    public RectangleSize sceneToCell_New(FxScene scene) {
        Point pointOut = sceneToCellNative(scene);
        RectangleSize rectReturn = pointToRectangle(pointOut);
        return rectReturn;
    }

    public RectF GetCellProperties() {
        Point pointOut = getCellPropertiesNative();
        RectF rectfReturn = pointToRectf(pointOut);
        return rectfReturn;
    }

    public RectangleSize getCellProperties_New() {
        Point pointOut = getCellPropertiesNative();
        RectangleSize rectReturn = pointToRectangle(pointOut);
        return rectReturn;
    }

    public RectangleSize getCellExtent_New() {
        Point pointOut = getCellExtentNative();
        RectangleSize rectReturn = pointToRectangle(pointOut);
        return rectReturn;
    }

    private Point recfToPoint(RectF rectfIn) {
        Point pointOut = new Point(0, 0);
        pointOut.x = (int) rectfIn.right;
        pointOut.y = (int) rectfIn.bottom;
        return pointOut;
    }

    private RectF pointToRectf(Point pointIn) {
        RectF rectfOut = new RectF(0.0f, 0.0f, 0.0f, 0.0f);
        rectfOut.right = pointIn.x;
        rectfOut.bottom = pointIn.y;
        return rectfOut;
    }

    private Point rectangleToPoint(RectangleSize rectIn) {
        Point pointOut = new Point(0, 0);
        pointOut.x = rectIn.nWidth;
        pointOut.y = rectIn.nHeight;
        return pointOut;
    }

    private RectangleSize pointToRectangle(Point pointIn) {
        RectangleSize rectOut = new RectangleSize(0, 0);
        rectOut.nWidth = pointIn.x;
        rectOut.nHeight = pointIn.y;
        return rectOut;
    }
}
