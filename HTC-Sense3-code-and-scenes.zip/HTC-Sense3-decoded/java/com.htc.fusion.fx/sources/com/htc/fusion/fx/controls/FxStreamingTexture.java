package com.htc.fusion.fx.controls;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.util.Log;
import com.htc.fusion.fx.FxNodeControl;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxStreamingTexture extends FxNodeControl {

    private interface FutureBase<T> extends Future<T> {
        void set(T t);
    }

    public static native boolean flushCanvas(Canvas canvas);

    private native void nativeGetBackbuffer(FutureBase<Bitmap> futureBase);

    private native void nativeSwap(FutureBase<Boolean> futureBase, FutureBase<Boolean> futureBase2);

    public FxStreamingTexture(int handle) {
        super(handle);
    }

    public ArrayList<Future<Boolean>> swap() {
        ArrayList<Future<Boolean>> arrListFuture = new ArrayList<>();
        BasicFuture<Boolean> swapCompleteFuture = new BasicFuture<>();
        BasicFuture<Boolean> swapRenderCompleteFuture = new BasicFuture<>();
        nativeSwap(swapCompleteFuture, swapRenderCompleteFuture);
        arrListFuture.add(0, swapCompleteFuture);
        arrListFuture.add(1, swapRenderCompleteFuture);
        return arrListFuture;
    }

    public Future<Bitmap> backBuffer() {
        BasicFuture<Bitmap> backbufferFuture = new BasicFuture<>();
        nativeGetBackbuffer(backbufferFuture);
        return backbufferFuture;
    }

    @Deprecated
    public Future<Boolean> promote(boolean double_buffered) {
        BasicFuture<Boolean> promoteFuture = new BasicFuture<>();
        promoteFuture.set(new Boolean(true));
        return promoteFuture;
    }

    @Deprecated
    public Future<Boolean> demote() {
        BasicFuture<Boolean> demoteFuture = new BasicFuture<>();
        demoteFuture.set(new Boolean(true));
        return demoteFuture;
    }

    private class BasicFuture<T> implements FutureBase<T> {
        private boolean m_fIsSet;
        private Object m_lock;
        private T m_value;

        private BasicFuture() {
            this.m_lock = new Object();
            this.m_value = null;
            this.m_fIsSet = false;
        }

        @Override // java.util.concurrent.Future
        public boolean cancel(boolean mayInterruptIfRunning) {
            return false;
        }

        @Override // java.util.concurrent.Future
        public boolean isCancelled() {
            return false;
        }

        @Override // java.util.concurrent.Future
        public boolean isDone() {
            boolean z;
            synchronized (this.m_lock) {
                z = this.m_fIsSet;
            }
            return z;
        }

        @Override // java.util.concurrent.Future
        public T get() throws InterruptedException, ExecutionException {
            synchronized (this.m_lock) {
                if (!this.m_fIsSet) {
                    this.m_lock.wait();
                    if (!this.m_fIsSet) {
                        return null;
                    }
                }
                return this.m_value;
            }
        }

        @Override // java.util.concurrent.Future
        public T get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
            T t;
            synchronized (this.m_lock) {
                if (!this.m_fIsSet) {
                    this.m_lock.wait(unit.toMillis(timeout));
                    if (!this.m_fIsSet) {
                        Log.d("FxStreamingTexture", "BasicFuture_get timeout");
                        throw new TimeoutException();
                    }
                }
                Log.d("FxStreamingTexture", "BasicFuture_get return m_value = " + this.m_value);
                t = this.m_value;
            }
            return t;
        }

        @Override // com.htc.fusion.fx.controls.FxStreamingTexture.FutureBase
        public void set(T value) {
            synchronized (this.m_lock) {
                this.m_fIsSet = true;
                this.m_value = value;
                this.m_lock.notifyAll();
            }
        }
    }

    public final class FxFutureIndex {
        public static final int SWAP_COMPLETE = 0;
        public static final int SWAP_RENDER_COMPLETE = 1;

        public FxFutureIndex() {
        }
    }
}
