package com.htc.fusion.fx.controls;

import android.view.View;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.IMessageListener;
import com.htc.fusion.fx.IMessageSource;
import com.htc.fusion.fx.MessageActivityListener;
import com.htc.fusion.fx.MessageListener;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxSettingButton extends FxTimelineControl {
    private IMessageListener<Integer> onClickListenerCompatibleListener;

    public native void changeToNextState(boolean z);

    public native int currentState();

    public native void enterTurningToNextState();

    public native IMessageSource<ClickParameters> getClickEventSource();

    public native IMessageSource<Integer> getClickSource();

    public native boolean getEnabled();

    public native void initialize(int i, int i2);

    public native void setEnabled(boolean z);

    public native void setState(int i);

    protected FxSettingButton(int handle) {
        super(handle);
    }

    public void initialize(int state) {
        initialize(state, 30);
    }

    public static class ClickParameters {
        public FxSettingButton object;
        public int state;

        public ClickParameters(FxSettingButton obj, int state) {
            this.object = obj;
            this.state = state;
        }
    }

    public void bindClickEvent(IMessageListener<ClickParameters> listener) {
        getClickEventSource().bind(listener);
    }

    public void unbindClickEvent(IMessageListener<ClickParameters> listener) {
        getClickEventSource().unbind(listener);
    }

    @Deprecated
    public void bindClick(MessageActivityListener<ClickParameters> listener) {
        bindClickEvent(listener);
    }

    @Deprecated
    public void unbindClick(MessageActivityListener<ClickParameters> listener) {
        unbindClickEvent(listener);
    }

    public void bindClick(IMessageListener<Integer> listener) {
        getClickSource().bind(listener);
    }

    public void unbindClick(IMessageListener<Integer> listener) {
        getClickSource().unbind(listener);
    }

    public void setOnClickListener(final View.OnClickListener l) {
        IMessageSource<Integer> clickSource = getClickSource();
        if (this.onClickListenerCompatibleListener != null) {
            clickSource.unbind(this.onClickListenerCompatibleListener);
        }
        this.onClickListenerCompatibleListener = l == null ? null : new MessageListener<Integer>() { // from class: com.htc.fusion.fx.controls.FxSettingButton.1
            @Override // com.htc.fusion.fx.IMessageListener
            public void onMessageReceived(Integer message) {
                l.onClick(null);
            }
        };
        if (this.onClickListenerCompatibleListener != null) {
            clickSource.bind(this.onClickListenerCompatibleListener);
        }
    }
}
