package com.htc.fusion.fx.controls;

import android.graphics.PointF;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.IMessageSource;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxListView extends FxTimelineControl {
    public static final int INVALID_INDEX = -1;

    public native void applyScrollOffset(PointF pointF, int i);

    public native void disableRecycling();

    public native void disableVirtualization();

    public native void enableRecycling(int i);

    public native void enableVirtualization(int i);

    public native void flickListView(PointF pointF);

    public native IMessageSource<FxListItemEvent> getAsyncListItemEventSource();

    public native IMessageSource<FxListViewEvent> getAsyncListViewEventSource();

    public native FxListViewCollection getCollection();

    public native int getCollectionCount();

    public native int getCurrentlySelectedIndex();

    public native int getFirstVisibleIndex();

    public native int getLastVisibleIndex();

    public native IMessageSource<FxListItemEvent> getListItemEventSource();

    public native IMessageSource<FxListViewEvent> getListViewEventSource();

    public native PointF getMaxScrollOffset();

    public native int getScrollDirection();

    public native PointF getScrollOffset();

    public native PointF getScrollOffsetByItem(int i);

    public native boolean isHidden();

    public native boolean isPressed();

    public native boolean isScrolling();

    public native void requestAnimateIn(boolean z);

    public native void requestAnimateOut(boolean z);

    public native void requestRefresh(boolean z, boolean z2);

    public native void requestSyncCallback();

    public native boolean scrollToTopEnabled();

    public native void setCollection(FxListViewCollection fxListViewCollection);

    public native void setDefaultFooterPath(String str);

    public native void setDefaultHeaderPath(String str);

    public native void setDefaultItemPath(String str);

    public native void setListViewFooterCallbackHandler(FxListViewFooterCallbackHandler fxListViewFooterCallbackHandler);

    public native void setListViewHeaderCallbackHandler(FxListViewHeaderCallbackHandler fxListViewHeaderCallbackHandler);

    public native void setListViewItemCallbackHandler(FxListViewItemCallbackHandler fxListViewItemCallbackHandler);

    public native void setScrollOffset(PointF pointF, int i);

    public native void setScrollOffsetByItem(int i, PointF pointF, int i2);

    public native void setScrollOffsetByPercentage(float f, int i);

    public native boolean snappingEnabled();

    protected FxListView(int handle) {
        super(handle);
    }

    public void requestRefresh(boolean wait) {
        requestRefresh(wait, false);
    }
}
