package com.htc.fusion.fx.controls;

import com.htc.fusion.fx.FxTimelineControl;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxListItem extends FxTimelineControl {
    public native int getIndex();

    public native int getItemIndex();

    public native boolean isFooter();

    public native boolean isHeader();

    protected FxListItem(int handle) {
        super(handle);
    }
}
