package com.htc.fusion.fx.controls;

import com.htc.fusion.fx.FxObject;
import com.htc.fusion.fx.FxScene;
import com.htc.fusion.fx.FxTimelineControl;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxSceneContainer extends FxTimelineControl {
    public static native void batchRemoveScenes(FxSceneContainer[] fxSceneContainerArr, FxObject[] fxObjectArr);

    public static native void batchSetScenes(FxSceneContainer[] fxSceneContainerArr, FxScene[] fxSceneArr);

    public native FxScene getScene();

    public native void removeScene(FxObject fxObject);

    public native void setScene(FxScene fxScene);

    protected FxSceneContainer(int handle) {
        super(handle);
    }
}
