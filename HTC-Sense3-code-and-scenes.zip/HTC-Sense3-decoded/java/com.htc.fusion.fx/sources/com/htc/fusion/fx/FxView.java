package com.htc.fusion.fx;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.FrameLayout;
import java.util.concurrent.atomic.AtomicBoolean;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxView extends FrameLayout {
    private AtomicBoolean mDisposed;
    private FxSurfaceView mView;
    private FxViewObject mViewObject;

    public FxView(Context context) {
        super(context);
        initialize(true, 0, false);
    }

    public FxView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initialize(true, 0, false);
    }

    public FxView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        initialize(true, 0, false);
    }

    public FxView(Context context, boolean lpBroadcast, int lpPort, boolean quitOnDisconnect) {
        super(context);
        initialize(lpBroadcast, lpPort, quitOnDisconnect);
    }

    private void initialize(boolean lpBroadcast, int lpPort, boolean quitOnDisconnect) {
        this.mDisposed = new AtomicBoolean(false);
        this.mViewObject = FxViewObject.create(this);
        this.mViewObject.setPackageResourcePath(getContext().getPackageResourcePath());
        this.mView = new FxSurfaceView(getContext(), this.mViewObject);
        addView(this.mView);
        initLivePreview(lpBroadcast, lpPort, quitOnDisconnect);
    }

    private void initLivePreview(boolean lpBroadcast, int lpPort, boolean quitOnDisconnect) {
        String friendlyName;
        if (this.mViewObject.initLivePreviewHost(lpBroadcast, lpPort, quitOnDisconnect)) {
            PackageManager pm = getContext().getPackageManager();
            try {
                PackageInfo appInfo = pm.getPackageInfo(getContext().getPackageName(), 128);
                friendlyName = appInfo.applicationInfo.processName;
            } catch (PackageManager.NameNotFoundException e) {
                friendlyName = "Unknown application";
            }
            this.mViewObject.setLivePreviewDescription(friendlyName);
        }
    }

    public void pause() {
        if (this.mViewObject != null) {
            this.mViewObject.pauseRendering();
        }
    }

    public void resume() {
        if (this.mViewObject != null) {
            this.mViewObject.resumeRendering();
        }
    }

    public FxScene createScene(String fileName) {
        if (this.mViewObject == null) {
            return null;
        }
        FxScene s = this.mViewObject.createScene(fileName, false);
        return s;
    }

    public FxScene createScene(String fileName, boolean initialVisibility) {
        if (this.mViewObject == null) {
            return null;
        }
        FxScene s = this.mViewObject.createScene(fileName, initialVisibility);
        return s;
    }

    public FxScene createScene(FxSceneLoader loader, boolean initialVisibility) {
        if (this.mViewObject == null) {
            return null;
        }
        FxScene s = this.mViewObject.createScene(loader, initialVisibility);
        return s;
    }

    public FxViewObject getViewObject() {
        return this.mViewObject;
    }

    public void addScene(FxScene s) {
        if (this.mViewObject != null) {
            this.mViewObject.addScene(s);
        }
    }

    public void removeScene(FxScene s) {
        if (this.mViewObject != null) {
            this.mViewObject.removeScene(s);
        }
    }

    @Override // android.view.View
    public void playSoundEffect(final int soundConstant) {
        post(new Runnable() { // from class: com.htc.fusion.fx.FxView.1
            @Override // java.lang.Runnable
            public void run() {
                FxView.super.playSoundEffect(soundConstant);
            }
        });
    }

    private class UiThreadDispose implements Runnable {
        public UiThreadDispose() {
        }

        @Override // java.lang.Runnable
        public void run() {
            FxView.this.pause();
            if (FxView.this.mView != null) {
                FxView.this.mView.dispose();
                FxView.this.removeView(FxView.this.mView);
                FxView.this.mView = null;
            }
            if (FxView.this.mViewObject != null) {
                FxView.this.mViewObject.dispose();
                FxView.this.mViewObject = null;
            }
        }
    }

    public void dispose() {
        if (this.mDisposed.compareAndSet(false, true)) {
            UiThreadDispose disposeRunnable = new UiThreadDispose();
            Handler uiThreadHandler = getHandler();
            if (uiThreadHandler != null && Thread.currentThread() != uiThreadHandler.getLooper().getThread()) {
                uiThreadHandler.post(disposeRunnable);
            } else {
                disposeRunnable.run();
            }
        }
    }

    protected void finalize() throws Throwable {
        try {
            dispose();
        } finally {
            super.finalize();
        }
    }

    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if (!FxView.class.isInstance(o) || this.mViewObject == null) {
            return false;
        }
        FxViewObject fvo = ((FxView) o).getViewObject();
        return this.mViewObject.equals(fvo);
    }

    public int hashCode() {
        if (this.mViewObject == null) {
            return 0;
        }
        int hash = this.mViewObject.hashCode();
        return hash;
    }

    public void setFormat(int format) {
        if (this.mView != null) {
            Log.d("mode10", "FxView.setFormat: " + format);
            this.mView.setFormat(format);
        }
    }

    @Override // android.view.View
    public void setVisibility(int visibility) {
        if (this.mView != null) {
            Log.d("mode10", "FxView.setVisibility: " + visibility);
            this.mView.setVisibility(visibility);
        }
    }

    @Override // android.view.View
    public int getVisibility() {
        if (this.mView != null) {
            return this.mView.getVisibility();
        }
        return 8;
    }

    public void setClearColor(int color) {
        if (this.mViewObject != null) {
            this.mViewObject.setClearColor(color);
        }
    }

    public void waitForLivePreviewConnected() {
        if (this.mViewObject != null) {
            this.mViewObject.waitForLivePreviewConnected();
        }
    }

    public boolean perfReportsEnabled() {
        if (this.mViewObject != null) {
            return this.mViewObject.perfReportsEnabled();
        }
        return false;
    }

    public boolean writePerfReport(String fileName) {
        if (this.mViewObject != null) {
            return this.mViewObject.writePerfReport(fileName);
        }
        return false;
    }

    private static class FxSurfaceView extends SurfaceView implements SurfaceHolder.Callback {
        private FxViewObject mViewObject;

        public FxSurfaceView(Context context, FxViewObject viewObj) {
            super(context);
            this.mViewObject = viewObj;
            getHolder().setFormat(1);
            getHolder().addCallback(this);
        }

        public void dispose() {
            getHolder().removeCallback(this);
            this.mViewObject = null;
        }

        protected void finalize() throws Throwable {
            try {
                dispose();
            } finally {
                super.finalize();
            }
        }

        @Override // android.view.View
        public boolean onTouchEvent(MotionEvent ev) {
            if (this.mViewObject != null) {
                int action = ev.getActionMasked();
                if (action == 2) {
                    for (int i = 0; i < ev.getPointerCount(); i++) {
                        this.mViewObject.onTouchEvent(action, ev.getPointerId(i), ev.getX(i), ev.getY(i));
                    }
                    return true;
                }
                int pointerIndex = ev.getActionIndex();
                this.mViewObject.onTouchEvent(action, ev.getPointerId(pointerIndex), ev.getX(pointerIndex), ev.getY(pointerIndex));
                return true;
            }
            return true;
        }

        @Override // android.view.SurfaceHolder.Callback
        public void surfaceCreated(SurfaceHolder holder) {
        }

        @Override // android.view.SurfaceHolder.Callback
        public void surfaceDestroyed(SurfaceHolder holder) {
            if (this.mViewObject != null) {
                this.mViewObject.setSurface(null, 0, 0, 0);
            }
        }

        @Override // android.view.SurfaceHolder.Callback
        public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            if (this.mViewObject != null) {
                this.mViewObject.setSurface(holder.getSurface(), format, width, height);
            }
        }

        public void setFormat(int format) {
            getHolder().setFormat(format);
        }
    }

    @Deprecated
    protected void resetJavaView() {
    }
}
