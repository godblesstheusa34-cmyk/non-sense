package com.htc.fusion.fx.controls;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public interface FxListViewHeaderCallbackHandler {
    String getHeaderPath(int i);
}
