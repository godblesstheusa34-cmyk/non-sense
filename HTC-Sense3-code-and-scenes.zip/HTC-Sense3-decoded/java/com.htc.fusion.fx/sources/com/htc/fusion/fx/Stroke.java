package com.htc.fusion.fx;

import android.graphics.PointF;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class Stroke {
    public int durationMs;
    public PointF initialLocation;
    public PointF location;
    public int pointerId;
}
