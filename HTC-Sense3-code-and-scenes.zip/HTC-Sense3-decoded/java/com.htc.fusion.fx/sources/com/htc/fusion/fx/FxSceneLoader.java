package com.htc.fusion.fx;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxSceneLoader extends NativeReference {
    public static native FxSceneLoader create(String str);

    public native boolean preLoad();

    static {
        FxObject.loadNativeLibrary();
    }

    protected FxSceneLoader(int handle) {
        super(handle);
    }
}
