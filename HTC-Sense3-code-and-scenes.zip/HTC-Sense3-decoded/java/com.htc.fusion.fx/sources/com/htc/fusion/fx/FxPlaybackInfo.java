package com.htc.fusion.fx;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxPlaybackInfo {
    public int mode;
    public String name;
    public int playbackResult;
    public float playbackSpeed;
    public int timeMapFunction;

    public FxPlaybackInfo(String name, int mode, float playbackSpeed, int timeMapFunction) {
        this.name = name;
        this.mode = mode;
        this.playbackSpeed = playbackSpeed;
        this.timeMapFunction = timeMapFunction;
        this.playbackResult = 1;
    }

    public FxPlaybackInfo(String name, int mode, float playbackSpeed, int timeMapFunction, int playbackResult) {
        this.name = name;
        this.mode = mode;
        this.playbackSpeed = playbackSpeed;
        this.timeMapFunction = timeMapFunction;
        this.playbackResult = playbackResult;
    }

    public final class FxPlaybackResult {
        public static final int PLAYBACK_COMPLETED = 1;
        public static final int PLAYBACK_INTERRUPTED = 2;
        public static final int PLAYBACK_NOTSET = 0;

        public FxPlaybackResult() {
        }
    }
}
