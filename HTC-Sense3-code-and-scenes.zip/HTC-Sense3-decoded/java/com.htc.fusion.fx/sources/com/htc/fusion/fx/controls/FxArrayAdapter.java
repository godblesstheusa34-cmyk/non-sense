package com.htc.fusion.fx.controls;

import android.content.Context;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxArrayAdapter<T> extends FxBaseAdapter {
    static final /* synthetic */ boolean $assertionsDisabled;
    protected boolean mAutoRefresh;
    private final Context mContext;
    private final String mFxTextLabelControl;
    private final Object mLock;
    protected List<T> mObjects;

    static {
        $assertionsDisabled = !FxArrayAdapter.class.desiredAssertionStatus();
    }

    public FxArrayAdapter(Context context, List<T> arraylist) {
        this(context, arraylist, null);
    }

    public FxArrayAdapter(Context context, List<T> arraylist, String fxTextLabelControl) {
        this.mAutoRefresh = true;
        this.mLock = new Object();
        this.mContext = context;
        this.mObjects = arraylist;
        this.mFxTextLabelControl = fxTextLabelControl;
    }

    public void add(T object) {
        insert((FxArrayAdapter<T>) object, getCount());
    }

    public void addList(List<T> newlist) {
        insert((List) newlist, getCount());
    }

    public void insert(T object, int index) {
        List<T> objects = new ArrayList<>();
        objects.add(object);
        insert((List) objects, index);
    }

    public void insert(List<T> newlist, int index) {
        synchronized (this.mLock) {
            if (index > this.mObjects.size()) {
                index = this.mObjects.size();
            }
            this.mObjects.addAll(index, newlist);
            if (this.mfxCollection != null && this.mAutoRefresh) {
                this.mfxCollection.insertItems(index, newlist.size());
            }
        }
    }

    public void update(T object, int index) {
        synchronized (this.mLock) {
            List<T> objects = new ArrayList<>();
            objects.add(object);
            updateList(objects, index);
        }
    }

    public void updateList(List<T> newlist, int index) {
        synchronized (this.mLock) {
            for (int i = 0; i < newlist.size(); i++) {
                this.mObjects.set(index + i, newlist.get(i));
            }
            if (this.mfxCollection != null && this.mAutoRefresh) {
                this.mfxCollection.refreshItems(index, newlist.size());
            }
        }
    }

    public void remove(T object) {
        synchronized (this.mLock) {
            int index = getPosition(object);
            removeRange(index, 1);
        }
    }

    public void remove(int position) {
        removeRange(position, 1);
    }

    public void removeRange(int index, int count) {
        synchronized (this.mLock) {
            if (this.mfxCollection != null && this.mAutoRefresh) {
                this.mfxCollection.removeItems(index, count);
            }
            for (int i = 0; i <= count - 1; i++) {
                this.mObjects.remove(index);
            }
        }
    }

    public void clear() {
        synchronized (this.mLock) {
            if (this.mfxCollection != null) {
                this.mfxCollection.removeItems(0, getCount());
            }
            this.mObjects.clear();
        }
    }

    public void sort(Comparator<? super T> comparator) {
        synchronized (this.mLock) {
            Collections.sort(this.mObjects, comparator);
            notifyDataSetChanged();
        }
    }

    public void setDataSource(List<T> newlist) {
        synchronized (this.mLock) {
            this.mObjects = newlist;
            notifyDataSetChanged();
        }
    }

    public List<T> getDataSource() {
        List<T> unmodifiableList;
        synchronized (this.mLock) {
            unmodifiableList = Collections.unmodifiableList(this.mObjects);
        }
        return unmodifiableList;
    }

    public Context getContext() {
        return this.mContext;
    }

    @Override // com.htc.fusion.fx.controls.FxBaseAdapter
    public int getCount() {
        return this.mObjects.size();
    }

    public T getItem(int position) throws IndexOutOfBoundsException {
        return this.mObjects.get(position);
    }

    public int getPosition(T item) {
        return this.mObjects.indexOf(item);
    }

    @Override // com.htc.fusion.fx.controls.FxBaseAdapter
    protected void setFxListItemData(int position, FxListItem fxListItem) {
        if (this.mFxTextLabelControl != null) {
            FxTextLabel textPrim = (FxTextLabel) fxListItem.getDescendant(this.mFxTextLabelControl);
            if (!$assertionsDisabled && textPrim == null) {
                throw new AssertionError("FxListItem1.getDescendant(mFxTextLabelControl)=null");
            }
            textPrim.setString(getItem(position).toString());
        }
    }

    public boolean getAutoRefresh() {
        return this.mAutoRefresh;
    }

    public void setAutoRefresh(boolean autoRefresh) {
        this.mAutoRefresh = autoRefresh;
    }
}
