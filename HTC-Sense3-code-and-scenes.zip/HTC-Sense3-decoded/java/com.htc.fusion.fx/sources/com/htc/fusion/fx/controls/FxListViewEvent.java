package com.htc.fusion.fx.controls;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxListViewEvent {
    public static final int FLICK_END = 4;
    public static final int FLICK_START = 3;
    public static final int IDLE = 0;
    public static final int PAN_END = 2;
    public static final int PAN_START = 1;
    public static final int SELECTED_INDEX_CHANGED = 30;
    public static final int SYNC_CALLBACK = 20;
    public int eventType;
    public int firstVisibleIndex;
    public int lastVisibleIndex;
    public int selectedIndex;

    protected FxListViewEvent(int eventType, int firstVisibleIndex, int lastVisibleIndex, int selectedIndex) {
        this.eventType = eventType;
        this.firstVisibleIndex = firstVisibleIndex;
        this.lastVisibleIndex = lastVisibleIndex;
        this.selectedIndex = selectedIndex;
    }
}
