package com.htc.fusion.fx.controls;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class TextInputInfo {
    boolean autoText;
    int backgroundColor;
    boolean backgroundTransparent;
    int capitalize;
    boolean cursorVisible;
    boolean ellipsis;
    String hint;
    int hintTextColor;
    int horizonalAlignment;
    int inputType;
    int lineSpacingExtra;
    int lineSpacingMultiplier;
    int maxSizeHeight;
    int maxSizeWidth;
    int maxlength;
    int paddingBottom;
    int paddingLeft;
    int paddingRight;
    int paddingTop;
    float positionX;
    float positionY;
    boolean selectAllOnFocus;
    int sizeHeight;
    int sizeWidth;
    int textColor;
    int textSize;
    int typeStyle;
    int typeface;
    int verticalAlignment;

    TextInputInfo() {
    }
}
