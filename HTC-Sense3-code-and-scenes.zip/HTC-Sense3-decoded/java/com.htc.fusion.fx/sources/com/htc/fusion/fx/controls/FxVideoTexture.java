package com.htc.fusion.fx.controls;

import android.media.MediaPlayer;
import com.htc.fusion.fx.FxNodeControl;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxVideoTexture extends FxNodeControl {
    private static final String TAG = "FxVideoTexture";
    Object m_lock;

    private interface FutureBase<T> extends Future<T> {
        void set(T t);
    }

    private native boolean nativeConnectMediaPlayer(MediaPlayer mediaPlayer, FutureBase<Boolean> futureBase);

    public FxVideoTexture(int handle) {
        super(handle);
        this.m_lock = new Object();
    }

    public Future<Boolean> connectMediaPlayer(MediaPlayer m) {
        BasicFuture<Boolean> connectMediaPlayerFuture;
        synchronized (this.m_lock) {
            connectMediaPlayerFuture = new BasicFuture<>();
            if (!nativeConnectMediaPlayer(m, connectMediaPlayerFuture)) {
                connectMediaPlayerFuture.set(false);
            }
        }
        return connectMediaPlayerFuture;
    }

    private class BasicFuture<T> implements FutureBase<T> {
        private boolean m_fIsSet;
        private Object m_lock;
        private T m_value;

        private BasicFuture() {
            this.m_lock = new Object();
            this.m_value = null;
            this.m_fIsSet = false;
        }

        @Override // java.util.concurrent.Future
        public boolean cancel(boolean mayInterruptIfRunning) {
            return false;
        }

        @Override // java.util.concurrent.Future
        public boolean isCancelled() {
            return false;
        }

        @Override // java.util.concurrent.Future
        public boolean isDone() {
            boolean z;
            synchronized (this.m_lock) {
                z = this.m_fIsSet;
            }
            return z;
        }

        @Override // java.util.concurrent.Future
        public T get() throws InterruptedException, ExecutionException {
            synchronized (this.m_lock) {
                if (!this.m_fIsSet) {
                    this.m_lock.wait();
                    if (!this.m_fIsSet) {
                        return null;
                    }
                }
                return this.m_value;
            }
        }

        @Override // java.util.concurrent.Future
        public T get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
            T t;
            synchronized (this.m_lock) {
                if (!this.m_fIsSet) {
                    this.m_lock.wait(unit.toMillis(timeout));
                    if (!this.m_fIsSet) {
                        throw new TimeoutException();
                    }
                }
                t = this.m_value;
            }
            return t;
        }

        @Override // com.htc.fusion.fx.controls.FxVideoTexture.FutureBase
        public void set(T value) {
            synchronized (this.m_lock) {
                this.m_fIsSet = true;
                this.m_value = value;
                this.m_lock.notifyAll();
            }
        }
    }
}
