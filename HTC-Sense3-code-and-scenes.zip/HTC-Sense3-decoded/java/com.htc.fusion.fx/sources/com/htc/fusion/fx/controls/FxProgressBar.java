package com.htc.fusion.fx.controls;

import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.IMessageSource;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxProgressBar extends FxTimelineControl {
    public native float getPercentageOffset();

    public native float getValue();

    public native IMessageSource<FxProgressData> getValueChangedSource();

    public native float getValueMax();

    public native float getValueMin();

    public native void setValue(float f);

    public native void setValueByPercentage(float f);

    public FxProgressBar(int handle) {
        super(handle);
    }
}
