package com.htc.fusion.fx;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public final class FxObjectCommand {
    public static final int FxButton = 1024;
    public static final int FxDynamicImage = 1536;
    public static final int FxDynamicImage_SetImageFromBitmap = 1537;
    public static final int FxDynamicImage_SetImageFromDrawable = 1536;
    public static final int FxNodeControl = 512;
    public static final int FxNodeControl_SetVisibility = 512;
    public static final int FxObject = 256;
    public static final int FxTextLabel = 1280;
    public static final int FxTextLabel_SetString = 1280;
    public static final int FxTimelineControl = 768;
    public static final int FxTimlineControl_SetFrame = 768;
}
