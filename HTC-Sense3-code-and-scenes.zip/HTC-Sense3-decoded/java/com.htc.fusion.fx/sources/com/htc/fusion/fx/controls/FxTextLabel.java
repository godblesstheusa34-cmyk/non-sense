package com.htc.fusion.fx.controls;

import android.graphics.PointF;
import com.htc.fusion.fx.FxNodeControl;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxTextLabel extends FxNodeControl {
    public native double getBaseFontSize();

    public native CharSequence getContent();

    public native int getEllipsizeMode();

    public native int getFadeoutMode();

    public native float getFadeoutStrength();

    public native PointF getLayoutSize();

    public native String getString();

    public native void setContent(CharSequence charSequence);

    public native void setEllipsize(int i);

    public native void setEnableMarquee(boolean z);

    public native void setFadeout(int i, float f);

    public native void setString(String str);

    protected FxTextLabel(int handle) {
        super(handle);
    }

    public static class LayoutChangedParameters {
        FxTextLabel object;
        PointF size;

        LayoutChangedParameters(FxTextLabel obj, PointF newSize) {
            this.object = obj;
            this.size = newSize;
        }
    }
}
