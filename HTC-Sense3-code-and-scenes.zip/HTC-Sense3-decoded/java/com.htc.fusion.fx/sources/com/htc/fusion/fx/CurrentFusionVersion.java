package com.htc.fusion.fx;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public final class CurrentFusionVersion {
    public static final int BUILD = 1;
    public static final int MAJOR = 1;
    public static final int MINOR = 1617;
    public static final int STAMP = 1161701;
    public static final String VERSION = "01.1617.01";

    private CurrentFusionVersion() {
    }
}
