package com.htc.fusion.fx.controls;

import com.htc.fusion.fx.FxDraggable;
import com.htc.fusion.fx.FxDroppable;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.IMessageSource;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxDragControl extends FxTimelineControl implements FxDraggable {
    @Override // com.htc.fusion.fx.FxDraggable
    public native void beginDrag();

    @Override // com.htc.fusion.fx.FxDraggable
    public native void endDrag();

    @Override // com.htc.fusion.fx.FxDraggable
    public native IMessageSource<FxDraggable> getBeginDragSource();

    @Override // com.htc.fusion.fx.FxDraggable
    public native int getBeginDragStyle();

    @Override // com.htc.fusion.fx.FxDraggable
    public native IMessageSource<FxDroppable> getDragOutSource();

    @Override // com.htc.fusion.fx.FxDraggable
    public native IMessageSource<FxDroppable> getDragOverSource();

    @Override // com.htc.fusion.fx.FxDraggable
    public native String[] getDragScope();

    @Override // com.htc.fusion.fx.FxDraggable
    public native IMessageSource<FxDraggable> getEndDragSource();

    @Override // com.htc.fusion.fx.FxDraggable
    public native int getEndDragStyle();

    @Override // com.htc.fusion.fx.FxDraggable
    public native boolean isEnabled();

    @Override // com.htc.fusion.fx.FxDraggable
    public native void setBeginDragStyle(int i);

    @Override // com.htc.fusion.fx.FxDraggable
    public native void setDragScope(String[] strArr);

    @Override // com.htc.fusion.fx.FxDraggable
    public native void setEnabled(boolean z);

    @Override // com.htc.fusion.fx.FxDraggable
    public native void setEndDragStyle(int i);

    protected FxDragControl(int handle) {
        super(handle);
    }

    @Override // com.htc.fusion.fx.FxDraggable
    public void setOnBeginDragListener(FxDraggable.OnDragEventListener listener) {
        getBeginDragSource().bind(listener);
    }

    @Override // com.htc.fusion.fx.FxDraggable
    public void setOnEndDragListener(FxDraggable.OnDragEventListener listener) {
        getEndDragSource().bind(listener);
    }

    public String toString() {
        return "FxDragControl [name=" + getName() + "]";
    }
}
