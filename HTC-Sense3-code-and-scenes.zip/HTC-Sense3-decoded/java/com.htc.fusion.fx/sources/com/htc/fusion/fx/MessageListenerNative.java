package com.htc.fusion.fx;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
class MessageListenerNative<T> extends MessageListener<T> {
    private int nativeHandle;

    private native void deleteNative();

    @Override // com.htc.fusion.fx.IMessageListener
    public native void onMessageReceived(T t);

    MessageListenerNative() {
    }

    static {
        FxObject.loadNativeLibrary();
    }

    protected void finalize() throws Throwable {
        try {
            deleteNative();
        } finally {
            super.finalize();
        }
    }
}
