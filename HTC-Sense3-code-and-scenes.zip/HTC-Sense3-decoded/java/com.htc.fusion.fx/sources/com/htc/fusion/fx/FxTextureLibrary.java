package com.htc.fusion.fx;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxTextureLibrary {
    public static native boolean addLibrariesFromAPK(String[] strArr, String[] strArr2, int[] iArr);

    public static native boolean addLibraryFromAPK(String str, String str2, int i);

    public static native boolean addLibraryFromFile(String str, int i);

    static {
        System.loadLibrary("mode10fx");
    }
}
