package com.htc.fusion.fx.controls;

import android.graphics.Bitmap;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.KeyListener;
import android.view.View;
import android.widget.TextView;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.IMessageSource;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxTextInput extends FxTimelineControl {
    public static final int EVENT_ENTERINPUTMODE = 1;
    public static final int EVENT_EXITINPUTMODE = 2;

    public native void addTextChangedListener(TextWatcher textWatcher);

    public native void append(CharSequence charSequence);

    public native void append(CharSequence charSequence, int i, int i2);

    public native boolean containAndroidView(View view);

    public native void enterInputMode();

    public native void exitInputMode();

    public native int getCursorPosition();

    public native boolean getCursorVisible();

    public native boolean getEnableAutoText();

    public native boolean getEnabled();

    public native String getHintText();

    public native int getInputType();

    public native KeyListener getKeyListener();

    public native int getLineCount();

    public native int getMaxLength();

    public native int getPaddingBottom();

    public native int getPaddingLeft();

    public native int getPaddingRight();

    public native int getPaddingTop();

    public native boolean getSelectAllOnFocus();

    public native String getSelectedString();

    public native int getSelectionEnd();

    public native int getSelectionStart();

    public native String getString();

    public native Editable getText();

    public native IMessageSource<FxTextInputEvent> getTextInputEventSource();

    public native boolean isInInputMode();

    native void loadTexture(Bitmap bitmap);

    public native void selectAll();

    public native void setBackgroundColor(int i);

    public native void setCursorPosition(int i);

    public native void setCursorVisible(boolean z);

    public native void setEnableAutoText(boolean z);

    public native void setEnabled(boolean z);

    public native void setHintText(String str);

    public native void setHintTextColor(int i);

    public native void setInputType(int i);

    public native void setKeyListener(KeyListener keyListener);

    public native void setLines(int i);

    public native void setMaxLength(int i);

    public native void setOnKeyListener(View.OnKeyListener onKeyListener);

    public native void setPadding(int i, int i2, int i3, int i4);

    public native void setSelectAllOnFocus(boolean z);

    public native void setSelection(int i, int i2);

    public native void setSingleLine(boolean z);

    public native void setString(String str);

    public native void setText(CharSequence charSequence, TextView.BufferType bufferType);

    public native void setTextColor(int i);

    public native void setTransparentBackground(boolean z);

    public native void swapStreamingTextureVisibility(boolean z);

    public native void updateTextScreenPosition(boolean z);

    public FxTextInput(int handle) {
        super(handle);
    }
}
