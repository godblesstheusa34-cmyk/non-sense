package com.htc.fusion.fx;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class NativeReference {
    public static final int NULL = 0;
    private int handle = 0;

    private static native void addReference(int i);

    private static native void removeReference(int i);

    protected NativeReference(int handle) {
        setHandle(handle);
    }

    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if (o == this) {
            return true;
        }
        if ((o instanceof NativeReference) && ((NativeReference) o).handle == this.handle) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        return this.handle ^ 1951938932;
    }

    protected void finalize() throws Throwable {
        try {
            clearHandle();
        } finally {
            super.finalize();
        }
    }

    private void setHandle(int handle) {
        synchronized (this) {
            if (this.handle != handle) {
                if (handle != 0) {
                    addReference(handle);
                }
                if (this.handle != 0) {
                    removeReference(this.handle);
                }
                this.handle = handle;
            }
        }
    }

    public void clearHandle() {
        setHandle(0);
    }
}
