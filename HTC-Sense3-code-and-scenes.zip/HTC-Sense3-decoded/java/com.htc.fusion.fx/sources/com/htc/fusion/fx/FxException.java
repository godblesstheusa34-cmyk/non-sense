package com.htc.fusion.fx;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxException extends RuntimeException {
    private static final long serialVersionUID = 1;

    public FxException(String message) {
        super(message);
    }
}
