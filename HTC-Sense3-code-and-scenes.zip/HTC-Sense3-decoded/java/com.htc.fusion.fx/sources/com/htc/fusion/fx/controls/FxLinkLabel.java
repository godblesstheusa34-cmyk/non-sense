package com.htc.fusion.fx.controls;

import com.htc.fusion.fx.IMessageSource;
import com.htc.fusion.mode10.RichTextVisualAttributes;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxLinkLabel extends FxTextLabel {
    public native IMessageSource<LinkSelectedParameters> getLinkSelectedEventSource();

    public native IMessageSource<String[]> getLinkSelectedSource();

    public native RichTextVisualAttributes getLinkStyle();

    public native void setLinkStyle(RichTextVisualAttributes richTextVisualAttributes);

    protected FxLinkLabel(int handle) {
        super(handle);
    }

    public static class LinkSelectedParameters {
        public String[] links;
        public FxLinkLabel object;

        LinkSelectedParameters(FxLinkLabel obj, String[] linkList) {
            this.object = obj;
            this.links = linkList;
        }
    }
}
