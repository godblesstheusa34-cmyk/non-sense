package com.htc.fusion.fx.controls;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public final class FxListItemEventType {
    public static final int ANIMATE_IN_COMPLETE = 20;
    public static final int ANIMATE_OUT_COMPLETE = 21;
    public static final int ANIMATE_REFRESH_COMPLETE = 23;
    public static final int ANIMATE_REFRESH_UPDATE = 22;
    public static final int ITEM_CLICKED = 10;
    public static final int ITEM_CREATED = 0;
    public static final int ITEM_DESTROYED = 1;
}
