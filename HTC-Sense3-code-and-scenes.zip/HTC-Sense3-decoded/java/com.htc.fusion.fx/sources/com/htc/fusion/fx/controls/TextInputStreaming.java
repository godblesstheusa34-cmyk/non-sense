package com.htc.fusion.fx.controls;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Bundle;
import android.text.Editable;
import android.text.Layout;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class TextInputStreaming extends EditText {
    private Bundle m_Bundle;
    private Rect m_CursorRect;
    private Path m_HighlightPath;
    private RectF m_HightlightRectF;
    private InputMethodManager m_InputManager;
    private FxTextInput m_TextInput;
    private boolean m_bDrawing;
    private boolean m_bReloadTexture;
    private boolean m_bUsingStreamingTexture;
    private Bitmap m_screenshot;
    private FxStreamingTexture m_tex;
    private int m_windowHeight;
    private int m_windowWidth;

    public TextInputStreaming(Context context) {
        super(context);
        this.m_InputManager = (InputMethodManager) getContext().getSystemService("input_method");
        WindowManager windowMgr = (WindowManager) getContext().getSystemService("window");
        this.m_windowHeight = windowMgr.getDefaultDisplay().getHeight();
        this.m_windowWidth = windowMgr.getDefaultDisplay().getWidth();
        Log.d("TextInputStreaming", "Display height: " + this.m_windowHeight + " width: " + this.m_windowWidth);
    }

    public void setTexture(FxStreamingTexture tex, FxTextInput textInput, Bitmap screenshot) {
        this.m_tex = tex;
        this.m_bDrawing = false;
        this.m_bUsingStreamingTexture = true;
        this.m_TextInput = textInput;
        this.m_screenshot = screenshot;
        this.m_bReloadTexture = false;
        addTextChangedListener(new TextWatcher() { // from class: com.htc.fusion.fx.controls.TextInputStreaming.1
            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable s) {
                TextInputStreaming.this.m_bReloadTexture = TextInputStreaming.this.m_bUsingStreamingTexture;
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }
        });
    }

    public void enableStreamingTexture() {
        this.m_bUsingStreamingTexture = true;
        disableSuperToUpdateCursorPosition(true);
    }

    public void disableStreamingTexture() {
        this.m_bUsingStreamingTexture = false;
        this.m_bReloadTexture = false;
        disableSuperToUpdateCursorPosition(false);
    }

    public void hideSoftInput() {
        if (this.m_InputManager != null && this.m_InputManager.isActive() && this.m_InputManager.isActive(this)) {
            this.m_InputManager.hideSoftInputFromWindow(getWindowToken(), 0);
        }
    }

    public void showSoftInput() {
        if (this.m_InputManager != null) {
            this.m_InputManager.showSoftInput(this, 0);
        }
    }

    @Override // android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        float xShift;
        float yShift;
        boolean bSuperOnDraw = false;
        Bitmap bitmap = null;
        try {
            if (!this.m_bDrawing) {
                if (this.m_bUsingStreamingTexture && this.m_tex != null) {
                    Future<Bitmap> bitmap_future = this.m_tex.backBuffer();
                    bitmap = bitmap_future.get(1000L, TimeUnit.MILLISECONDS);
                } else if (!this.m_bUsingStreamingTexture) {
                    if (this.m_screenshot == null) {
                        Log.e("TextInputStreaming", "m_screenshot is null");
                    } else {
                        bitmap = this.m_screenshot;
                    }
                }
            }
            Log.d("TextInputStreaming", " View.width: " + getWidth() + " View.height: " + getHeight() + " Canvas.width: " + canvas.getWidth() + " Canvas.height: " + canvas.getHeight());
            if (bitmap == null || canvas.getWidth() < getWidth() || canvas.getHeight() < getHeight()) {
                bSuperOnDraw = true;
            } else {
                bitmap.eraseColor(0);
                Canvas c = new Canvas(bitmap);
                float[] systemCanvasValues = new float[9];
                canvas.getMatrix().getValues(systemCanvasValues);
                float systemCanvasX = systemCanvasValues[2];
                float systemCanvasY = systemCanvasValues[5];
                Log.d("TextInputStreaming", "systemCanvasX: " + systemCanvasX + " systemCanvasY: " + systemCanvasY);
                float[] ownedCanvasValue = new float[9];
                c.getMatrix().getValues(ownedCanvasValue);
                float ownedCanvasX = ownedCanvasValue[2];
                float ownedCanvasY = ownedCanvasValue[5];
                int[] windowLocation = new int[2];
                getLocationInWindow(windowLocation);
                if (canvas.getWidth() < this.m_windowHeight && canvas.getHeight() < this.m_windowWidth) {
                    xShift = ownedCanvasX + systemCanvasX;
                    yShift = ownedCanvasY + systemCanvasY;
                } else {
                    xShift = ownedCanvasX - (windowLocation[0] - systemCanvasX);
                    yShift = ownedCanvasY - (windowLocation[1] - systemCanvasY);
                }
                Log.d("TextInputStreaming", "windowLocation, xShift: " + xShift + " yShift: " + yShift);
                c.translate(xShift, yShift);
                this.m_bDrawing = true;
                draw(c);
                this.m_bDrawing = false;
                if (!this.m_bUsingStreamingTexture) {
                    this.m_TextInput.loadTexture(this.m_screenshot);
                } else {
                    if (this.m_bReloadTexture) {
                        this.m_TextInput.loadTexture(bitmap);
                        this.m_bReloadTexture = false;
                    }
                    FxStreamingTexture.flushCanvas(c);
                }
                if (this.m_bUsingStreamingTexture && this.m_tex != null && !this.m_tex.swap().get(0).get(1000L, TimeUnit.MILLISECONDS).booleanValue()) {
                    Log.e("TextInputStreaming", "Failed to swap buffers");
                }
                updateCursorPosition(canvas);
            }
        } catch (Exception e) {
            StringWriter writer = new StringWriter();
            e.printStackTrace(new PrintWriter(writer));
            Log.e("TextInputStreaming", writer.toString());
        }
        if (bSuperOnDraw) {
            super.onDraw(canvas);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public boolean onTouchEvent(MotionEvent event) {
        if (this.m_bUsingStreamingTexture) {
            return super.onTouchEvent(event);
        }
        return false;
    }

    private void disableSuperToUpdateCursorPosition(boolean disable) {
        this.m_Bundle = getInputExtras(false);
        if (this.m_Bundle == null) {
            this.m_Bundle = getInputExtras(true);
        }
        this.m_Bundle.putBoolean("Fusion_update_cursor", disable);
    }

    private void updateCursorPosition(Canvas canvas) {
        if (this.m_InputManager != null) {
            int selStart = getSelectionStart();
            int selEnd = getSelectionEnd();
            Layout layout = getLayout();
            if (this.m_TextInput.getCursorVisible() && selStart >= 0 && isEnabled()) {
                if (this.m_HighlightPath == null) {
                    this.m_HighlightPath = new Path();
                }
                if (selStart == selEnd) {
                    layout.getCursorPath(selStart, this.m_HighlightPath, "");
                } else {
                    layout.getSelectionPath(selStart, selEnd, this.m_HighlightPath);
                }
            }
            if (this.m_InputManager.isWatchingCursor(this) && this.m_HighlightPath != null) {
                if (this.m_HightlightRectF == null) {
                    this.m_HightlightRectF = new RectF();
                }
                this.m_HighlightPath.computeBounds(this.m_HightlightRectF, true);
                float[] offset = new float[2];
                canvas.getMatrix().mapPoints(offset);
                int[] positionInWindow = new int[2];
                getLocationInWindow(positionInWindow);
                int[] positionOnScreen = new int[2];
                getLocationOnScreen(positionOnScreen);
                int[] offsetOnScreen = {positionOnScreen[0] - positionInWindow[0], positionOnScreen[1] - positionInWindow[1]};
                this.m_HightlightRectF.offset(offset[0], offset[1]);
                this.m_HightlightRectF.offset(offsetOnScreen[0], offsetOnScreen[1]);
                this.m_HightlightRectF.offset(0.0f, 0.0f);
                if (this.m_CursorRect == null) {
                    this.m_CursorRect = new Rect();
                }
                this.m_CursorRect.set((int) (this.m_HightlightRectF.left + 0.5d), (int) (this.m_HightlightRectF.top + 0.5d), (int) (this.m_HightlightRectF.right + 0.5d), (int) (this.m_HightlightRectF.bottom + 0.5d));
                this.m_InputManager.updateCursor(this, this.m_CursorRect.left, this.m_CursorRect.top, this.m_CursorRect.right, this.m_CursorRect.bottom);
            }
        }
    }
}
