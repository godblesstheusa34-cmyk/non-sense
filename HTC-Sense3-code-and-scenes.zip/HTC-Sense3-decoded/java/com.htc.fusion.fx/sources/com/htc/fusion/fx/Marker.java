package com.htc.fusion.fx;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class Marker {
    public int EndFrame;
    public String Name;
    public int StartFrame;
}
