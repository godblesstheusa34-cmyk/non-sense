package com.htc.fusion.fx.controls;

import android.content.Context;
import android.graphics.drawable.Drawable;
import com.htc.fusion.fx.FxControl;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxListItemBinder {
    public static final String SET_VISIBILITY_FALSE = "SetVisibilityFalse";

    public void setFxListItemValue(Context context, int position, FxControl fx_control, Object data) {
        if (fx_control instanceof FxTextLabel) {
            ((FxTextLabel) fx_control).setString(data.toString());
            return;
        }
        if (fx_control instanceof FxDynamicImage) {
            if (data.toString().equals(SET_VISIBILITY_FALSE)) {
                ((FxDynamicImage) fx_control).setVisibility(false);
                return;
            }
            Drawable d = context.getResources().getDrawable(Integer.parseInt(data.toString()));
            ((FxDynamicImage) fx_control).setImage(d);
            ((FxDynamicImage) fx_control).setVisibility(true);
            return;
        }
        throw new IllegalStateException(fx_control.getClass().getName() + " is not a  FxListViewItem that can be bounds by this FxAdapter");
    }
}
