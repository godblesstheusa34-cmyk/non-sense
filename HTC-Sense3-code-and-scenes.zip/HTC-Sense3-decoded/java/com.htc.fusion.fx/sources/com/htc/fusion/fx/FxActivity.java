package com.htc.fusion.fx;

import android.R;
import android.app.Activity;
import android.os.Bundle;
import android.os.Process;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxActivity extends Activity {
    private static final String TAG = "FxActivity";
    private int mFxViewId = R.id.content;
    private FxScene mScene;
    private FxView mView;

    protected void setFxViewId(int id) {
        this.mFxViewId = id;
    }

    @Override // android.app.Activity
    public void setContentView(View view) {
        super.setContentView(view);
        this.mView = getViewOrChild(view);
        if (this.mView == null) {
            Log.w(TAG, "Unable to get FxView from content view");
        }
    }

    @Override // android.app.Activity
    public void setContentView(View view, ViewGroup.LayoutParams params) {
        super.setContentView(view, params);
        this.mView = getViewOrChild(view);
        if (this.mView == null) {
            Log.w(TAG, "Unable to get FxView from content view");
        }
    }

    @Override // android.app.Activity
    public void setContentView(int layoutResID) {
        super.setContentView(layoutResID);
        this.mView = (FxView) findViewById(this.mFxViewId);
        if (this.mView == null) {
            Log.w(TAG, "Unable to get FxView from content view");
        }
    }

    private FxView getViewOrChild(View view) {
        return view instanceof FxView ? (FxView) view : (FxView) view.findViewById(this.mFxViewId);
    }

    protected FxScene setScene(FxSceneLoader loader) {
        if (this.mScene != null) {
            Log.w(TAG, "setScene is really only supposed to be called once");
            return this.mScene;
        }
        this.mScene = getFxView().createScene(loader, true);
        return this.mScene;
    }

    protected FxScene setScene(String scenePath) {
        return setScene(FxSceneLoader.create(scenePath));
    }

    protected FxView getFxView() {
        if (this.mView == null) {
            this.mView = new FxView(this);
            setContentView(this.mView);
        }
        return this.mView;
    }

    protected FxScene getFxScene() {
        return this.mScene;
    }

    @Override // android.app.Activity
    protected void onPause() {
        Log.i(TAG, "FxActivity.onPause()");
        super.onPause();
        if (this.mView != null) {
            this.mView.pause();
        }
    }

    @Override // android.app.Activity
    protected void onResume() {
        Log.i(TAG, "FxActivity.onResume()");
        if (this.mView != null) {
            this.mView.resume();
        }
        super.onResume();
    }

    @Override // android.app.Activity
    protected void onStop() {
        Log.i(TAG, "FxActivity.onStop()");
        super.onStop();
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        Log.i(TAG, "FxActivity.onCreate()");
        super.onCreate(savedInstanceState);
    }

    @Override // android.app.Activity
    protected void onRestart() {
        Log.i(TAG, "FxActivity.onRestart()");
        super.onRestart();
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        Log.i(TAG, "FxActivity.onDestroy()");
        super.onDestroy();
        Process.killProcess(Process.myPid());
    }
}
