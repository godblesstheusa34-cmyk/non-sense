package com.htc.fusion.fx;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class MessageRelay<T> {
    private MessageSource<T> source = new MessageSource<>();
    private IMessageListener<T> listener = new MessageListener<T>() { // from class: com.htc.fusion.fx.MessageRelay.1
        static final /* synthetic */ boolean $assertionsDisabled;

        static {
            $assertionsDisabled = !MessageRelay.class.desiredAssertionStatus();
        }

        @Override // com.htc.fusion.fx.IMessageListener
        public void onMessageReceived(T message) {
            if (!$assertionsDisabled && message == null) {
                throw new AssertionError();
            }
            MessageRelay.this.source.raiseMessage(message);
        }
    };

    public IMessageSource<T> getSource() {
        return this.source;
    }

    public IMessageListener<T> getListener() {
        return this.listener;
    }
}
