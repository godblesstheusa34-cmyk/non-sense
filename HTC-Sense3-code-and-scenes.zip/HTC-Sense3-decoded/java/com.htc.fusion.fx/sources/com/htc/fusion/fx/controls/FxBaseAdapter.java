package com.htc.fusion.fx.controls;

import com.htc.fusion.fx.MessageListener;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public abstract class FxBaseAdapter {
    protected MessageListener<FxListItemEvent> mMessageListener;
    protected MessageListener<FxListItemEvent> mSyncMessageListener;
    protected FxListViewCollection mfxCollection;
    protected FxListView mfxListView;
    protected int mVirtualSize = 10;
    protected int mRecyclingSize = 25;

    public abstract int getCount();

    public FxBaseAdapter() {
    }

    @Deprecated
    public FxBaseAdapter(FxListViewCollection fxCollection) {
    }

    public void bindListView(FxListView fxListView) {
        bindListView(fxListView, this.mVirtualSize, this.mRecyclingSize);
    }

    public void bindListView(FxListView fxListView, int virtualSize) {
        bindListView(fxListView, virtualSize, this.mRecyclingSize);
    }

    public void bindListView(FxListView fxListView, int virtualSize, int recyclingSize) {
        if (this.mfxListView != null) {
            if (this.mMessageListener != null) {
                this.mfxListView.getAsyncListItemEventSource().unbind(this.mMessageListener);
            }
            if (this.mSyncMessageListener != null) {
                this.mfxListView.getListItemEventSource().unbind(this.mSyncMessageListener);
            }
        }
        this.mfxListView = fxListView;
        this.mVirtualSize = virtualSize;
        this.mRecyclingSize = recyclingSize;
        if (this.mMessageListener == null) {
            this.mMessageListener = new MessageListener<FxListItemEvent>() { // from class: com.htc.fusion.fx.controls.FxBaseAdapter.1
                @Override // com.htc.fusion.fx.IMessageListener
                public void onMessageReceived(FxListItemEvent message) {
                    int index = message.listItem.getIndex();
                    if (message.eventType == 0) {
                        FxBaseAdapter.this.setFxListItemData(index, message.listItem, message.eventType);
                    }
                    if (message.eventType == 22) {
                        FxBaseAdapter.this.setFxListItemData(index, message.listItem, message.eventType);
                    }
                }
            };
        }
        this.mfxListView.getAsyncListItemEventSource().bind(this.mMessageListener);
        if (this.mSyncMessageListener == null) {
            this.mSyncMessageListener = new MessageListener<FxListItemEvent>() { // from class: com.htc.fusion.fx.controls.FxBaseAdapter.2
                @Override // com.htc.fusion.fx.IMessageListener
                public void onMessageReceived(FxListItemEvent message) {
                    int index = message.listItem.getIndex();
                    if (message.eventType == 0) {
                        FxBaseAdapter.this.setSyncFxListItemData(index, message.listItem, message.eventType);
                    }
                    if (message.eventType == 22) {
                        FxBaseAdapter.this.setSyncFxListItemData(index, message.listItem, message.eventType);
                    }
                }
            };
        }
        this.mfxListView.getListItemEventSource().bind(this.mSyncMessageListener);
        if (this.mfxListView.getCollection() != null) {
            this.mfxCollection = this.mfxListView.getCollection();
            return;
        }
        if (this.mVirtualSize >= 0) {
            this.mfxListView.enableVirtualization(this.mVirtualSize);
        } else if (this.mVirtualSize == -1) {
            this.mfxListView.disableVirtualization();
        } else {
            throw new IndexOutOfBoundsException("Virtual size can't less -1.");
        }
        if (this.mRecyclingSize >= 0) {
            this.mfxListView.enableRecycling(this.mRecyclingSize);
        } else if (this.mRecyclingSize == -1) {
            this.mfxListView.disableRecycling();
        } else {
            throw new IndexOutOfBoundsException("RecyclingSize size can't less -1.");
        }
        this.mfxCollection = FxListViewCollection.create(getCount());
        this.mfxListView.setCollection(this.mfxCollection);
    }

    protected void setFxListItemData(int position, FxListItem fxListItem, int messageEventType) {
        setFxListItemData(position, fxListItem);
    }

    @Deprecated
    protected void setFxListItemData(int position, FxListItem fxListItem) {
    }

    protected void setSyncFxListItemData(int position, FxListItem fxListItem, int messageEventType) {
        setSyncFxListItemData(position, fxListItem);
    }

    @Deprecated
    protected void setSyncFxListItemData(int position, FxListItem fxListItem) {
    }

    public FxListViewCollection getFxListViewCollection() {
        return this.mfxCollection;
    }

    public void notifyDataSetChanged(int index, int count) {
        if (this.mfxListView == null) {
            throw new IllegalStateException("this adapter don't bind any ListView yet.");
        }
        synchronized (this) {
            this.mfxCollection.refreshItems(index, count);
        }
    }

    public void notifyDataSetChanged() {
        if (this.mfxListView == null) {
            throw new IllegalStateException("this adapter don't bind any ListView yet.");
        }
        synchronized (this) {
            int listCount = getCount();
            int collectionCount = this.mfxListView.getCollectionCount();
            int visibleStart = this.mfxListView.getFirstVisibleIndex();
            int visibleEnd = this.mfxListView.getLastVisibleIndex();
            if (listCount > collectionCount) {
                this.mfxCollection.refreshItems(0, listCount);
                this.mfxCollection.insertItems(collectionCount, listCount - collectionCount);
            } else {
                if (listCount < collectionCount) {
                    if (listCount - 1 >= visibleEnd) {
                        this.mfxCollection.removeItems(listCount, collectionCount - listCount);
                    } else if (listCount - 1 >= visibleStart) {
                        if (visibleStart >= visibleEnd - (listCount - 1)) {
                            this.mfxCollection.removeItems(0, visibleEnd - (listCount - 1));
                            this.mfxCollection.removeItems(visibleEnd + 1, (collectionCount - 1) - visibleEnd);
                        } else {
                            this.mfxCollection.removeItems(listCount, collectionCount - listCount);
                        }
                    } else if (listCount > collectionCount - listCount) {
                        this.mfxCollection.removeItems(0, collectionCount - listCount);
                    } else {
                        this.mfxCollection.removeItems(listCount, collectionCount - listCount);
                    }
                }
                this.mfxCollection.refreshItems(0, listCount);
            }
        }
    }
}
