package com.htc.fusion.fx.controls;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.DateKeyListener;
import android.text.method.DateTimeKeyListener;
import android.text.method.DialerKeyListener;
import android.text.method.DigitsKeyListener;
import android.text.method.KeyListener;
import android.text.method.PasswordTransformationMethod;
import android.text.method.QwertyKeyListener;
import android.text.method.TextKeyListener;
import android.text.method.TimeKeyListener;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.htc.fusion.fx.FxTimeMapFunction;
import com.htc.fusion.fx.FxViewObject;
import com.htc.fusion.fx.IMessageSource;
import com.htc.fusion.fx.MessageListener;
import com.htc.fusion.fx.Stroke;
import com.htc.fusion.fx.controls.FxHitbox;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.ref.WeakReference;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class TextInputWorker {
    public static final String IME_CURRENT_STATE = "HTC_IME_CURRENT_STATE";
    private static final boolean mTextInputSizeExtendabled = false;
    private TextKeyListener.Capitalize mCapOption;
    private TextInputStreaming mEditText;
    private float mEditTextInitialHeight;
    private boolean mEditTextInitialScale;
    private float mEditTextInitialWidth;
    private CountDownTimer mExitInputModeTimer;
    private FxHitbox mHitbox;
    private float mHitboxExpandHeight;
    private float mHitboxExpandWidth;
    private float mHitboxInitialScaleHeight;
    private float mHitboxInitialScaleWidth;
    private MessageHandlerListener<FxHitbox.EventParameters> mHitboxListener;
    private MessageHandlerListener<FxHitbox.MoveEventParameters> mHitboxMoveListener;
    private boolean mHitboxScaled;
    private int mInputType;
    private Bitmap mScreenshot;
    private FxStreamingTexture mStreamingTexture;
    private int mTextGravity;
    private FxTextInput mTextInput;
    private TextInputInfo mTextInputInfo;
    private WeakReference<View> mView;
    private SIPReceiver sipReceiver;
    private TextInputWorker mTextInputWorker = this;
    private boolean mInitialized = false;
    private boolean mTextEditEnabled = false;
    private boolean mTempTouchEventHandling = false;

    protected TextInputWorker(FxTextInput textInput, FxHitbox hitbox, FxStreamingTexture streamingTexture, View view, TextInputInfo textInputInfo) {
        this.mTextInput = textInput;
        this.mStreamingTexture = streamingTexture;
        this.mHitbox = hitbox;
        this.mView = new WeakReference<>(view);
        this.mTextInputInfo = textInputInfo;
    }

    public boolean isInitialized() {
        return this.mInitialized;
    }

    public void initialize(boolean textEditEnabled) {
        initialize(this.mTextInputInfo.positionX, this.mTextInputInfo.positionY, textEditEnabled);
    }

    public void initialize(final float positionX, final float positionY, final boolean textEditEnabled) {
        invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.1
            @Override // java.lang.Runnable
            public void run() {
                TextInputWorker.this.initialize_OnUiThread(positionX, positionY, textEditEnabled);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void initialize_OnUiThread(float positionX, float positionY, boolean textEditEnabled) {
        if (!this.mInitialized) {
            this.mInitialized = true;
            setTextEditEnabled(textEditEnabled);
            this.mInputType = 0;
            this.mTextGravity = 0;
            this.mTextInputInfo.positionX = positionX;
            this.mTextInputInfo.positionY = positionY;
            this.mEditText = createEditText_OnUiThread();
            View javaview = this.mView.get();
            if (javaview == null) {
                Log.e("TextInputWorker", "javaview is null");
                return;
            }
            FrameLayout frame = (FrameLayout) javaview;
            updateTextScreenPosition_OnUiThread(positionX, positionY);
            this.mEditText.setWidth(this.mTextInputInfo.sizeWidth);
            this.mEditText.setHeight(this.mTextInputInfo.sizeHeight);
            if (this.mTextInputInfo.maxSizeWidth > 0) {
                this.mEditText.setMinWidth(this.mTextInputInfo.sizeWidth);
                this.mEditText.setMaxWidth(this.mTextInputInfo.maxSizeWidth);
            }
            if (this.mTextInputInfo.maxSizeHeight > 0) {
                this.mEditText.setMinHeight(this.mTextInputInfo.sizeHeight);
                this.mEditText.setMaxHeight(this.mTextInputInfo.maxSizeHeight);
            }
            switch (this.mTextInputInfo.horizonalAlignment) {
                case 1:
                    this.mTextGravity |= 3;
                    break;
                case 2:
                    this.mTextGravity |= 1;
                    break;
                case 3:
                    this.mTextGravity |= 5;
                    break;
            }
            switch (this.mTextInputInfo.verticalAlignment) {
                case 1:
                    this.mTextGravity |= 48;
                    break;
                case 2:
                    this.mTextGravity |= 16;
                    break;
                case 3:
                    this.mTextGravity |= 80;
                    break;
            }
            this.mEditText.setGravity(this.mTextGravity);
            this.mEditText.setTextSize(this.mTextInputInfo.textSize);
            Typeface tf = Typeface.DEFAULT;
            switch (this.mTextInputInfo.typeface) {
                case 1:
                    tf = Typeface.DEFAULT;
                    break;
                case 2:
                    tf = Typeface.SANS_SERIF;
                    break;
                case 3:
                    tf = Typeface.SERIF;
                    break;
                case 4:
                    tf = Typeface.MONOSPACE;
                    break;
            }
            this.mEditText.setTypeface(tf, this.mTextInputInfo.typeStyle - 1);
            if (this.mTextInputInfo.maxlength > 0) {
                this.mEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(this.mTextInputInfo.maxlength)});
            }
            if (this.mTextInputInfo.ellipsis) {
                this.mEditText.setEllipsize(TextUtils.TruncateAt.END);
            }
            switch (this.mTextInputInfo.capitalize) {
                case 1:
                    this.mCapOption = TextKeyListener.Capitalize.NONE;
                    break;
                case 2:
                    this.mCapOption = TextKeyListener.Capitalize.SENTENCES;
                    break;
                case 3:
                    this.mCapOption = TextKeyListener.Capitalize.WORDS;
                    break;
                case 4:
                    this.mCapOption = TextKeyListener.Capitalize.CHARACTERS;
                    break;
                default:
                    this.mCapOption = TextKeyListener.Capitalize.NONE;
                    break;
            }
            switch (this.mTextInputInfo.inputType) {
                case 1:
                    this.mEditText.setKeyListener(new TextKeyListener(this.mCapOption, this.mTextInputInfo.autoText));
                    break;
                case 2:
                    this.mEditText.setKeyListener(new QwertyKeyListener(this.mCapOption, this.mTextInputInfo.autoText));
                    break;
                case 3:
                    this.mEditText.setKeyListener(DigitsKeyListener.getInstance(true, true));
                    break;
                case 4:
                    this.mEditText.setKeyListener(new DateKeyListener());
                    break;
                case FxTimeMapFunction.EASE_IN_CUBIC /* 5 */:
                    this.mEditText.setKeyListener(new TimeKeyListener());
                    break;
                case FxTimeMapFunction.EASE_OUT_CUBIC /* 6 */:
                    this.mEditText.setKeyListener(new DateTimeKeyListener());
                    break;
                case FxTimeMapFunction.EASE_IN_OUT_CUBIC /* 7 */:
                    this.mEditText.setKeyListener(new DialerKeyListener());
                    break;
                case 8:
                    this.mEditText.setTransformationMethod(new PasswordTransformationMethod());
                    break;
                default:
                    this.mEditText.setKeyListener(new TextKeyListener(this.mCapOption, this.mTextInputInfo.autoText));
                    break;
            }
            this.mEditText.setCursorVisible(this.mTextInputInfo.cursorVisible);
            this.mEditText.setSelectAllOnFocus(this.mTextInputInfo.selectAllOnFocus);
            this.mEditText.setHint(this.mTextInputInfo.hint);
            this.mEditText.setTextColor(this.mTextInputInfo.textColor);
            this.mEditText.setHintTextColor(this.mTextInputInfo.hintTextColor);
            this.mEditText.setPadding(this.mTextInputInfo.paddingLeft, this.mTextInputInfo.paddingTop, this.mTextInputInfo.paddingRight, this.mTextInputInfo.paddingBottom);
            if (this.mTextInputInfo.backgroundTransparent) {
                this.mEditText.setBackgroundDrawable(null);
            } else {
                this.mEditText.setBackgroundColor(this.mTextInputInfo.backgroundColor);
            }
            this.mScreenshot = Bitmap.createBitmap(this.mTextInputInfo.sizeWidth, this.mTextInputInfo.sizeHeight, Bitmap.Config.ARGB_8888);
            this.mEditText.setTexture(this.mStreamingTexture, this.mTextInput, this.mScreenshot);
            if (!initStreamingTexture()) {
                Log.e("TextInputWorker", "initStreamingTexture failed");
            }
            if (textEditEnabled) {
                this.mEditText.enableStreamingTexture();
                this.mEditText.setCursorVisible(this.mTextInputInfo.cursorVisible);
                this.mEditText.requestFocus();
            } else {
                this.mEditText.setCursorVisible(false);
                this.mEditText.disableStreamingTexture();
                this.mTextInput.exitInputMode();
            }
            if (this.sipReceiver == null) {
                IntentFilter filter = new IntentFilter();
                filter.addAction(IME_CURRENT_STATE);
                this.sipReceiver = new SIPReceiver(this.mEditText, this);
                javaview.getContext().getApplicationContext().registerReceiver(this.sipReceiver, filter);
            }
            this.mEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() { // from class: com.htc.fusion.fx.controls.TextInputWorker.2
                @Override // android.view.View.OnFocusChangeListener
                public void onFocusChange(View v, boolean hasFocus) {
                    long j = 250;
                    if (v.getId() == TextInputWorker.this.mEditText.getId()) {
                        if (hasFocus) {
                            if (TextInputWorker.this.mExitInputModeTimer != null) {
                                Log.i("TextInputWorker", "mExitInputModeTimer.cancel()!");
                                TextInputWorker.this.mExitInputModeTimer.cancel();
                            }
                            if (!TextInputWorker.this.isTextEditEnabled()) {
                                TextInputWorker.this.mTextInput.enterInputMode();
                            }
                            if (TextInputWorker.this.isTextEditEnabled()) {
                                TextInputWorker.this.mEditText.showSoftInput();
                                return;
                            }
                            return;
                        }
                        TextInputWorker.this.mEditText.hideSoftInput();
                        if (TextInputWorker.this.mExitInputModeTimer != null) {
                            TextInputWorker.this.mExitInputModeTimer.cancel();
                            TextInputWorker.this.mExitInputModeTimer.start();
                        } else {
                            TextInputWorker.this.mExitInputModeTimer = new CountDownTimer(j, j) { // from class: com.htc.fusion.fx.controls.TextInputWorker.2.1
                                @Override // android.os.CountDownTimer
                                public void onTick(long millisUntilFinished) {
                                }

                                @Override // android.os.CountDownTimer
                                public void onFinish() {
                                    if (TextInputWorker.this.isTextEditEnabled()) {
                                        TextInputWorker.this.mTextInputWorker.exitInputMode();
                                    }
                                }
                            }.start();
                        }
                    }
                }
            });
            this.mEditText.setOnTouchListener(new View.OnTouchListener() { // from class: com.htc.fusion.fx.controls.TextInputWorker.3
                @Override // android.view.View.OnTouchListener
                public boolean onTouch(View v, MotionEvent event) {
                    if (!TextInputWorker.this.isTextEditEnabled()) {
                        return false;
                    }
                    TextInputWorker.this.scaleHitboxWithEditText(TextInputWorker.this.mEditText, TextInputWorker.this.mHitbox);
                    float scaleX = 1.0f;
                    if (TextInputWorker.this.mEditText.getWidth() < TextInputWorker.this.mTextInputInfo.sizeWidth) {
                        scaleX = TextInputWorker.this.mEditText.getWidth() / TextInputWorker.this.mTextInputInfo.sizeWidth;
                    }
                    FxViewObject viewObject = TextInputWorker.this.mTextInput.getViewObject();
                    if (viewObject == null) {
                        return false;
                    }
                    int action = event.getActionMasked();
                    if (action == 2) {
                        for (int i = 0; i < event.getPointerCount(); i++) {
                            viewObject.onTouchEvent(action, event.getPointerId(i), (event.getX(i) / scaleX) + TextInputWorker.this.mEditText.getLeft(), event.getY(i) + TextInputWorker.this.mEditText.getTop());
                        }
                    } else {
                        int pointerIndex = event.getActionIndex();
                        viewObject.onTouchEvent(action, event.getPointerId(pointerIndex), (event.getX(pointerIndex) / scaleX) + TextInputWorker.this.mEditText.getLeft(), event.getY(pointerIndex) + TextInputWorker.this.mEditText.getTop());
                    }
                    return true;
                }
            });
            frame.addView(this.mEditText);
            AlphaAnimation anim = new AlphaAnimation(0.01f, 0.01f);
            anim.setDuration(0L);
            anim.setFillAfter(true);
            this.mEditText.startAnimation(anim);
            bindMessageListener(true);
        }
    }

    public void finalize() throws Throwable {
        try {
            release();
        } finally {
            super.finalize();
        }
    }

    public boolean equalsView(View view) {
        return this.mView.get().equals(view);
    }

    private boolean isCallingOnUiThread() {
        long uiThreadId = Looper.getMainLooper().getThread().getId();
        return uiThreadId == Thread.currentThread().getId();
    }

    private void bindMessageListener(boolean bind) {
        View javaview = this.mView.get();
        if (javaview != null) {
            if (this.mHitboxListener == null) {
                this.mHitboxListener = new MessageHandlerListener<FxHitbox.EventParameters>(javaview) { // from class: com.htc.fusion.fx.controls.TextInputWorker.4
                    @Override // com.htc.fusion.fx.IMessageListener
                    public void onMessageReceived(FxHitbox.EventParameters message) {
                        if (TextInputWorker.this.isTextEditEnabled()) {
                            switch (message.event) {
                                case 1:
                                    TextInputWorker.this.mTextInput.updateTextScreenPosition(false);
                                    if (TextInputWorker.this.mExitInputModeTimer != null) {
                                        TextInputWorker.this.mExitInputModeTimer.cancel();
                                    }
                                    MotionEvent ev = MotionEvent.obtain(1000L, SystemClock.uptimeMillis(), 0, message.hitbox_position.x * TextInputWorker.this.mEditText.getWidth(), message.hitbox_position.y * TextInputWorker.this.mEditText.getHeight(), 0);
                                    TextInputWorker.this.mEditText.onTouchEvent(ev);
                                    break;
                                case 2:
                                    MotionEvent ev2 = MotionEvent.obtain(1000L, SystemClock.uptimeMillis(), 1, message.hitbox_position.x * TextInputWorker.this.mEditText.getWidth(), message.hitbox_position.y * TextInputWorker.this.mEditText.getHeight(), 0);
                                    TextInputWorker.this.mEditText.onTouchEvent(ev2);
                                    break;
                                case 3:
                                    if (TextInputWorker.this.isTextEditEnabled()) {
                                        TextInputWorker.this.mTextInputWorker.exitInputMode_OnUiThread();
                                        break;
                                    }
                                    break;
                            }
                        }
                        switch (message.event) {
                            case 1:
                                TextInputWorker.this.mTextInput.updateTextScreenPosition(false);
                                if (!TextInputWorker.this.isFocused()) {
                                    TextInputWorker.this.mTempTouchEventHandling = true;
                                    TextInputWorker.this.mTextInput.swapStreamingTextureVisibility(true);
                                    TextInputWorker.this.mEditText.enableStreamingTexture();
                                    TextInputWorker.this.mEditText.setCursorVisible(TextInputWorker.this.mTextInputInfo.cursorVisible);
                                }
                                if (TextInputWorker.this.mExitInputModeTimer != null) {
                                    TextInputWorker.this.mExitInputModeTimer.cancel();
                                }
                                MotionEvent ev3 = MotionEvent.obtain(1000L, SystemClock.uptimeMillis(), 0, message.hitbox_position.x * TextInputWorker.this.mEditText.getWidth(), message.hitbox_position.y * TextInputWorker.this.mEditText.getHeight(), 0);
                                TextInputWorker.this.mEditText.onTouchEvent(ev3);
                                break;
                            case 2:
                                MotionEvent ev4 = MotionEvent.obtain(1000L, SystemClock.uptimeMillis(), 1, message.hitbox_position.x * TextInputWorker.this.mEditText.getWidth(), message.hitbox_position.y * TextInputWorker.this.mEditText.getHeight(), 0);
                                TextInputWorker.this.mEditText.onTouchEvent(ev4);
                                TextInputWorker.this.mTempTouchEventHandling = false;
                                if (!TextInputWorker.this.isFocused()) {
                                    TextInputWorker.this.mEditText.disableStreamingTexture();
                                    TextInputWorker.this.mTextInput.swapStreamingTextureVisibility(false);
                                    TextInputWorker.this.mEditText.setCursorVisible(false);
                                    break;
                                }
                                break;
                        }
                    }
                };
            }
            if (this.mHitboxMoveListener == null) {
                this.mHitboxMoveListener = new MessageHandlerListener<FxHitbox.MoveEventParameters>(javaview) { // from class: com.htc.fusion.fx.controls.TextInputWorker.5
                    @Override // com.htc.fusion.fx.IMessageListener
                    public void onMessageReceived(FxHitbox.MoveEventParameters message) {
                        if (TextInputWorker.this.isTextEditEnabled() || TextInputWorker.this.mTempTouchEventHandling) {
                            Stroke stroke = message.stroke;
                            float moveX = stroke.location.x - stroke.initialLocation.x;
                            float moveY = stroke.location.y - stroke.initialLocation.y;
                            MotionEvent ev = MotionEvent.obtain(1000L, SystemClock.uptimeMillis(), 2, (message.hitbox_position.x * TextInputWorker.this.mEditText.getWidth()) + moveX, (message.hitbox_position.y * TextInputWorker.this.mEditText.getHeight()) + moveY, 0);
                            TextInputWorker.this.mEditText.onTouchEvent(ev);
                        }
                    }
                };
            }
            if (this.mHitbox != null) {
                if (bind) {
                    this.mHitbox.getEventSource().bind(this.mHitboxListener);
                    this.mHitbox.getMoveEventSource().bind(this.mHitboxMoveListener);
                    this.mHitbox.setEnabled(true);
                    return;
                } else {
                    this.mHitbox.getEventSource().unbind(this.mHitboxListener);
                    this.mHitbox.getMoveEventSource().unbind(this.mHitboxMoveListener);
                    this.mHitbox.setEnabled(true);
                    return;
                }
            }
            Log.e("TextInputWorker", "mHitbox is null");
            return;
        }
        Log.e("TextInputWorker", "javaview is null");
    }

    public void workActivate() {
        invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.6
            @Override // java.lang.Runnable
            public void run() {
                TextInputWorker.this.workActivate_OnUiThread();
            }
        });
    }

    public void workActivate_OnUiThread() {
        if (!this.mInitialized) {
            this.mTextInput.swapStreamingTextureVisibility(false);
            this.mTextInput.updateTextScreenPosition(false);
            return;
        }
        this.mEditText.cancelLongPress();
        this.mTextInput.updateTextScreenPosition(true);
        if (isTextEditEnabled()) {
            this.mTextInput.swapStreamingTextureVisibility(true);
            this.mEditText.enableStreamingTexture();
            this.mEditText.setCursorVisible(this.mTextInputInfo.cursorVisible);
        } else {
            this.mEditText.disableStreamingTexture();
            this.mEditText.setCursorVisible(false);
            this.mTextInput.swapStreamingTextureVisibility(false);
        }
    }

    public void workDeactivate() {
        invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.7
            @Override // java.lang.Runnable
            public void run() {
                TextInputWorker.this.workDeactivate_OnUiThread();
            }
        });
    }

    public void workDeactivate_OnUiThread() {
        if (this.mInitialized) {
            this.mEditText.cancelLongPress();
            this.mTextInput.updateTextScreenPosition(false);
            this.mEditText.hideSoftInput();
            if (this.mTextInput.isInInputMode()) {
                exitInputMode_OnUiThread();
            }
        }
    }

    public boolean isFocused() {
        if (this.mEditText != null) {
            return this.mEditText.isFocused();
        }
        return false;
    }

    public void requestFocus() {
        if (this.mInitialized) {
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.8
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.requestFocus();
                }
            });
        }
    }

    public void setTextEditEnabled(boolean textEditEnabled) {
        this.mTextEditEnabled = textEditEnabled;
    }

    public boolean isTextEditEnabled() {
        return this.mTextEditEnabled;
    }

    private TextInputStreaming createEditText_OnUiThread() {
        View javaview = this.mView.get();
        if (javaview == null) {
            return null;
        }
        TextInputStreaming editText = new TextInputStreaming(javaview.getContext());
        return editText;
    }

    private boolean initStreamingTexture() {
        Log.i("TextInputWorker", "initStreamingTexture");
        try {
            Future<Boolean> promote_future = this.mStreamingTexture.promote(true);
            boolean proceed = promote_future.get(1000L, TimeUnit.MILLISECONDS).booleanValue();
            if (!proceed) {
                Log.e("TextInputWorker", "Failed to promote texture");
                return proceed;
            }
            return proceed;
        } catch (InterruptedException e) {
            StringWriter writer = new StringWriter();
            e.printStackTrace(new PrintWriter(writer));
            Log.e("TextInputWorker", writer.toString());
            return false;
        } catch (ExecutionException e2) {
            StringWriter writer2 = new StringWriter();
            e2.printStackTrace(new PrintWriter(writer2));
            Log.e("TextInputWorker", writer2.toString());
            return false;
        } catch (TimeoutException e3) {
            StringWriter writer3 = new StringWriter();
            e3.printStackTrace(new PrintWriter(writer3));
            Log.e("TextInputWorker", writer3.toString());
            return false;
        }
    }

    private boolean cleanupStreamingTexture() {
        Log.i("TextInputWorker", "cleanupStreamingTexture");
        try {
            Future<Boolean> demote_future = this.mStreamingTexture.demote();
            boolean proceed = demote_future.get(1000L, TimeUnit.MILLISECONDS).booleanValue();
            if (!proceed) {
                Log.e("TextInputWorker", "Failed to demote texture");
                return proceed;
            }
            return proceed;
        } catch (InterruptedException e) {
            StringWriter writer = new StringWriter();
            e.printStackTrace(new PrintWriter(writer));
            Log.e("TextInputWorker", writer.toString());
            return false;
        } catch (ExecutionException e2) {
            StringWriter writer2 = new StringWriter();
            e2.printStackTrace(new PrintWriter(writer2));
            Log.e("TextInputWorker", writer2.toString());
            return false;
        } catch (TimeoutException e3) {
            StringWriter writer3 = new StringWriter();
            e3.printStackTrace(new PrintWriter(writer3));
            Log.e("TextInputWorker", writer3.toString());
            return false;
        }
    }

    public void exitInputMode() {
        if (!this.mInitialized) {
            initialize(false);
        }
        invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.9
            @Override // java.lang.Runnable
            public void run() {
                TextInputWorker.this.exitInputMode_OnUiThread();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void exitInputMode_OnUiThread() {
        if (isTextEditEnabled()) {
            Log.i("TextInputWorker", "exitInputMode in the Java side!");
            setTextEditEnabled(false);
            this.mEditText.hideSoftInput();
            this.mEditText.setCursorVisible(false);
            if (this.mHitbox == null) {
                Log.e("TextInputWorker", "mHitbox is null");
            } else {
                scaleHitboxWithEditText(this.mEditText, this.mHitbox);
            }
            this.mEditText.cancelLongPress();
            this.mEditText.disableStreamingTexture();
            this.mEditText.clearFocus();
            this.mTextInput.exitInputMode();
        }
    }

    public void enterInputMode(final float positionX, final float positionY) {
        try {
            if (!this.mInitialized) {
                initialize(positionX, positionY, true);
            }
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.10
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.enterInputMode_OnUiThread(positionX, positionY);
                }
            });
        } catch (Exception e) {
            StringWriter writer = new StringWriter();
            e.printStackTrace(new PrintWriter(writer));
            Log.e("TextInputWorker", writer.toString());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void enterInputMode_OnUiThread(float positionX, float positionY) {
        if (!isTextEditEnabled()) {
            Log.i("TextInputWorker", "enterInputMode in the Java side, on UI thread!");
            setTextEditEnabled(true);
            updateTextScreenPosition_OnUiThread(positionX, positionY);
            this.mEditText.enableStreamingTexture();
            this.mEditText.showSoftInput();
            this.mEditText.setCursorVisible(this.mTextInputInfo.cursorVisible);
            if (this.mHitbox != null) {
                if (!this.mEditTextInitialScale) {
                    this.mEditTextInitialWidth = this.mEditText.getWidth();
                    this.mEditTextInitialHeight = this.mEditText.getHeight();
                    this.mHitboxInitialScaleWidth = this.mHitbox.getScaleWidth();
                    this.mHitboxInitialScaleHeight = this.mHitbox.getScaleHeight();
                    this.mEditTextInitialScale = true;
                }
                this.mHitboxScaled = scaleHitboxWithEditText(this.mEditText, this.mHitbox);
                return;
            }
            Log.e("TextInputWorker", "mHitbox is null");
        }
    }

    public void updateTextScreenPosition(final float positionX, final float positionY) {
        try {
            if (!this.mInitialized) {
                initialize(positionX, positionY, false);
            }
            if (isCallingOnUiThread()) {
                updateTextScreenPosition_OnUiThread(positionX, positionY);
                return;
            }
            View javaview = this.mView.get();
            if (javaview != null) {
                Handler handler = javaview.getHandler();
                if (handler != null) {
                    handler.post(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.11
                        @Override // java.lang.Runnable
                        public void run() {
                            TextInputWorker.this.updateTextScreenPosition_OnUiThread(positionX, positionY);
                        }
                    });
                    return;
                } else {
                    Log.e("TextInputWorker", "handler is null");
                    return;
                }
            }
            Log.e("TextInputWorker", "javaview is null");
        } catch (Exception e) {
            StringWriter writer = new StringWriter();
            e.printStackTrace(new PrintWriter(writer));
            Log.e("TextInputWorker", writer.toString());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateTextScreenPosition_OnUiThread(float positionX, float positionY) {
        Log.i("TextInputWorker", "updateTextScreenPosition in the Java side, on UI thread!");
        View javaview = this.mView.get();
        if (javaview != null) {
            FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(this.mTextInputInfo.sizeWidth, this.mTextInputInfo.sizeHeight);
            params.gravity = 51;
            ((ViewGroup.MarginLayoutParams) params).leftMargin = (int) positionX;
            ((ViewGroup.MarginLayoutParams) params).topMargin = (int) positionY;
            this.mEditText.setLayoutParams(params);
            this.mEditText.invalidate();
            return;
        }
        Log.e("TextInputWorker", "javaview == null");
    }

    static final class SIPReceiver extends BroadcastReceiver {
        View sipAssociateView;
        TextInputWorker sipFxTextInput;

        SIPReceiver(View view, TextInputWorker fxTextInput) {
            this.sipAssociateView = view;
            this.sipFxTextInput = fxTextInput;
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if (TextInputWorker.IME_CURRENT_STATE.equals(intent.getAction())) {
                boolean sipVisible = intent.getBooleanExtra("SIP_VISIBLE", true);
                if (sipVisible) {
                    this.sipAssociateView.setVisibility(0);
                }
            }
        }
    }

    public void release() {
        if (this.mInitialized) {
            bindMessageListener(false);
            this.mTextInput.updateTextScreenPosition(false);
            final View javaview = this.mView.get();
            if (javaview != null) {
                if (this.sipReceiver != null) {
                    javaview.getContext().getApplicationContext().unregisterReceiver(this.sipReceiver);
                }
                this.sipReceiver = null;
                cleanupStreamingTexture();
                if (isTextEditEnabled()) {
                    setTextEditEnabled(false);
                    this.mTextInput.exitInputMode();
                }
                invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.12
                    @Override // java.lang.Runnable
                    public void run() {
                        ((ViewGroup) javaview).removeView(TextInputWorker.this.mEditText);
                    }
                });
            }
        }
    }

    public void setText(final String text) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.13
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.setText(text);
                }
            }).start();
        } else {
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.14
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.setText(text);
                }
            });
        }
    }

    public void setEllipsize(final boolean whether) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.15
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.setEllipsize(whether);
                }
            }).start();
        } else {
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.16
                @Override // java.lang.Runnable
                public void run() {
                    if (whether) {
                        TextInputWorker.this.mEditText.setEllipsize(TextUtils.TruncateAt.END);
                    }
                }
            });
        }
    }

    public void selectAll() {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.17
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.selectAll();
                }
            }).start();
        } else {
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.18
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.selectAll();
                }
            });
        }
    }

    public void setCursorVisible(final boolean visible) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.19
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.setCursorVisible(visible);
                }
            }).start();
        } else {
            this.mTextInputInfo.cursorVisible = visible;
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.20
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.setCursorVisible(visible);
                }
            });
        }
    }

    public void setSelectAllOnFocus(final boolean selectAllOnFocus) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.21
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.setSelectAllOnFocus(selectAllOnFocus);
                }
            }).start();
        } else {
            this.mTextInputInfo.selectAllOnFocus = selectAllOnFocus;
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.22
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.setSelectAllOnFocus(selectAllOnFocus);
                }
            });
        }
    }

    public void setAutoText(final boolean autoText) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.23
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.setAutoText(autoText);
                }
            }).start();
        } else {
            this.mTextInputInfo.autoText = autoText;
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.24
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.setKeyListener(new TextKeyListener(TextInputWorker.this.mCapOption, autoText));
                }
            });
        }
    }

    public void setHintText(final String strHint) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.25
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.setHintText(strHint);
                }
            }).start();
        } else {
            this.mTextInputInfo.hint = strHint;
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.26
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.setHint(strHint);
                }
            });
        }
    }

    public void setMaxLength(final int maxlength) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.27
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.setMaxLength(maxlength);
                }
            }).start();
        } else {
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.28
                @Override // java.lang.Runnable
                public void run() {
                    if (maxlength > 0) {
                        TextInputWorker.this.mTextInputInfo.maxlength = maxlength;
                        TextInputWorker.this.mEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxlength)});
                    }
                }
            });
        }
    }

    public void setInputType(final int type) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.29
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.setInputType(type);
                }
            }).start();
        } else {
            this.mInputType = type;
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.30
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.setInputType(type);
                }
            });
        }
    }

    public void setSelection(final int start, final int stop) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.31
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.setSelection(start, stop);
                }
            }).start();
        } else {
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.32
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.setSelection(start, stop);
                }
            });
        }
    }

    public void setCursorPosition(final int index) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.33
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.setCursorPosition(index);
                }
            }).start();
        } else {
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.34
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.setSelection(index);
                }
            });
        }
    }

    public void setPadding(final int left, final int top, final int right, final int bottom) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.35
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.setPadding(left, top, right, bottom);
                }
            }).start();
            return;
        }
        this.mTextInputInfo.paddingLeft = left;
        this.mTextInputInfo.paddingTop = top;
        this.mTextInputInfo.paddingRight = right;
        this.mTextInputInfo.paddingBottom = bottom;
        invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.36
            @Override // java.lang.Runnable
            public void run() {
                TextInputWorker.this.mEditText.setPadding(left, top, right, bottom);
            }
        });
    }

    public void setBackgroundColor(final int color) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.37
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.setBackgroundColor(color);
                }
            }).start();
            return;
        }
        this.mTextInputInfo.backgroundColor = color;
        if (!this.mTextInputInfo.backgroundTransparent) {
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.38
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.setBackgroundColor(color);
                }
            });
        }
    }

    public void setTextColor(final int color) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.39
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.setTextColor(color);
                }
            }).start();
        } else {
            this.mTextInputInfo.textColor = color;
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.40
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.setTextColor(color);
                }
            });
        }
    }

    public void setHintTextColor(final int color) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.41
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.setHintTextColor(color);
                }
            }).start();
        } else {
            this.mTextInputInfo.hintTextColor = color;
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.42
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.setHintTextColor(color);
                }
            });
        }
    }

    public void setTransparentBackground(final boolean bTransparent) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.43
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.setTransparentBackground(bTransparent);
                }
            }).start();
        } else {
            this.mTextInputInfo.backgroundTransparent = bTransparent;
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.44
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.setBackgroundDrawable(null);
                }
            });
        }
    }

    public void setKeyListener(final KeyListener input) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.45
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.setKeyListener(input);
                }
            }).start();
        } else {
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.46
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.setKeyListener(input);
                }
            });
        }
    }

    public void setOnKeyListener(final View.OnKeyListener listener) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.47
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.setOnKeyListener(listener);
                }
            }).start();
        } else {
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.48
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.setOnKeyListener(listener);
                }
            });
        }
    }

    private class GetKeyListenerWorker implements Callable<KeyListener> {
        private GetKeyListenerWorker() {
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // java.util.concurrent.Callable
        public KeyListener call() throws Exception {
            return TextInputWorker.this.mEditText.getKeyListener();
        }
    }

    private class GetKeyListenerCreator extends FutureTask<KeyListener> {
        public GetKeyListenerCreator(Callable<KeyListener> callable) {
            super(callable);
        }
    }

    public KeyListener getKeyListener() throws InterruptedException, ExecutionException {
        if (!this.mInitialized) {
            initialize(false);
        }
        GetKeyListenerWorker worker = new GetKeyListenerWorker();
        GetKeyListenerCreator creator = new GetKeyListenerCreator(worker);
        if (isCallingOnUiThread()) {
            return this.mEditText.getKeyListener();
        }
        View javaview = this.mView.get();
        if (javaview == null) {
            Log.e("TextInputWorker", "javaview is null");
            return null;
        }
        Handler handler = javaview.getHandler();
        if (handler == null) {
            Log.e("TextInputWorker", "handler is null");
            return null;
        }
        handler.post(creator);
        KeyListener listener = creator.get();
        return listener;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String getStringFieldWrapperInternal(String fieldname) {
        if (fieldname.contentEquals("Text")) {
            return this.mEditText.getText().toString();
        }
        if (fieldname.contentEquals("HintText")) {
            return this.mTextInputInfo.hint;
        }
        if (fieldname.contentEquals("SelectedString")) {
            return this.mEditText.getText().subSequence(this.mEditText.getSelectionStart(), this.mEditText.getSelectionEnd()).toString();
        }
        Log.e("TextInputWorker", "Not supported String Field!" + fieldname);
        return null;
    }

    private class StringFieldWrapperWorker implements Callable<String> {
        protected String mFieldname;

        public StringFieldWrapperWorker(String fieldname) {
            this.mFieldname = fieldname;
        }

        @Override // java.util.concurrent.Callable
        public String call() throws Exception {
            return TextInputWorker.this.getStringFieldWrapperInternal(this.mFieldname);
        }
    }

    private class StringFieldWrapperCreator extends FutureTask<String> {
        public StringFieldWrapperCreator(Callable<String> callable) {
            super(callable);
        }
    }

    public String getStringFieldViewWrapper(String fieldname) throws InterruptedException, ExecutionException {
        if (!this.mInitialized) {
            initialize(false);
        }
        StringFieldWrapperWorker worker = new StringFieldWrapperWorker(fieldname);
        StringFieldWrapperCreator creator = new StringFieldWrapperCreator(worker);
        if (isCallingOnUiThread()) {
            return getStringFieldWrapperInternal(fieldname);
        }
        View javaview = this.mView.get();
        if (javaview == null) {
            Log.e("TextInputWorker", "javaview is null");
            return null;
        }
        Handler handler = javaview.getHandler();
        if (handler != null) {
            handler.post(creator);
            return creator.get();
        }
        Log.e("TextInputWorker", "handler is null");
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public Integer getIntegerFieldWrapperInternal(String fieldname) {
        if (fieldname.contentEquals("MaxLength")) {
            return new Integer(this.mTextInputInfo.maxlength);
        }
        if (fieldname.contentEquals("InputType")) {
            return new Integer(this.mInputType);
        }
        if (fieldname.contentEquals("SelectionStart")) {
            return new Integer(this.mEditText.getSelectionStart());
        }
        if (fieldname.contentEquals("SelectionEnd")) {
            return new Integer(this.mEditText.getSelectionEnd());
        }
        if (fieldname.contentEquals("CursorPosition")) {
            return new Integer(this.mEditText.getSelectionStart());
        }
        if (fieldname.contentEquals("LineCount")) {
            if (!isTextEditEnabled()) {
                Log.i("TextInputWorker", "EditText is not in the layout yet, getLineCount will return 0");
            }
            return new Integer(this.mEditText.getLineCount());
        }
        if (fieldname.contentEquals("PaddingLeft")) {
            return new Integer(this.mEditText.getPaddingLeft());
        }
        if (fieldname.contentEquals("PaddingTop")) {
            return new Integer(this.mEditText.getPaddingTop());
        }
        if (fieldname.contentEquals("PaddingRight")) {
            return new Integer(this.mEditText.getPaddingRight());
        }
        if (fieldname.contentEquals("PaddingBottom")) {
            return new Integer(this.mEditText.getPaddingBottom());
        }
        Log.e("TextInputWorker", "Not supported Integer Field!" + fieldname);
        return null;
    }

    private class IntegerFieldWrapperWorker implements Callable<Integer> {
        protected String mFieldname;

        public IntegerFieldWrapperWorker(String fieldname) {
            this.mFieldname = fieldname;
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // java.util.concurrent.Callable
        public Integer call() throws Exception {
            return TextInputWorker.this.getIntegerFieldWrapperInternal(this.mFieldname);
        }
    }

    private class IntegerFieldWrapperCreator extends FutureTask<Integer> {
        public IntegerFieldWrapperCreator(Callable<Integer> callable) {
            super(callable);
        }
    }

    public int getIntFieldViewWrapper(String fieldname) throws InterruptedException, ExecutionException {
        if (!this.mInitialized) {
            initialize(false);
        }
        IntegerFieldWrapperWorker worker = new IntegerFieldWrapperWorker(fieldname);
        IntegerFieldWrapperCreator creator = new IntegerFieldWrapperCreator(worker);
        if (isCallingOnUiThread()) {
            return getIntegerFieldWrapperInternal(fieldname).intValue();
        }
        View javaview = this.mView.get();
        if (javaview == null) {
            Log.e("TextInputWorker", "javaview is null");
            return 0;
        }
        Handler handler = javaview.getHandler();
        if (handler == null) {
            Log.e("TextInputWorker", "handler is null");
            return 0;
        }
        handler.post(creator);
        Integer integer = creator.get();
        if (integer != null) {
            return integer.intValue();
        }
        return 0;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public Boolean getBooleanFieldWrapperInternal(String fieldname) {
        if (fieldname.contentEquals("CursorVisible")) {
            return new Boolean(this.mTextInputInfo.cursorVisible);
        }
        if (fieldname.contentEquals("SelectAllOnFocus")) {
            return new Boolean(this.mTextInputInfo.selectAllOnFocus);
        }
        if (fieldname.contentEquals("EnableAutoText")) {
            return new Boolean(this.mTextInputInfo.autoText);
        }
        Log.e("TextInputWorker", "Not supported Boolean Field!" + fieldname);
        return null;
    }

    private class BooleanFieldWrapperWorker implements Callable<Boolean> {
        protected String mFieldname;

        public BooleanFieldWrapperWorker(String fieldname) {
            this.mFieldname = fieldname;
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // java.util.concurrent.Callable
        public Boolean call() throws Exception {
            return TextInputWorker.this.getBooleanFieldWrapperInternal(this.mFieldname);
        }
    }

    private class BooleanFieldWrapperCreator extends FutureTask<Boolean> {
        public BooleanFieldWrapperCreator(Callable<Boolean> callable) {
            super(callable);
        }
    }

    public boolean getboolFieldViewWrapper(String fieldname) throws InterruptedException, ExecutionException {
        if (!this.mInitialized) {
            initialize(false);
        }
        BooleanFieldWrapperWorker worker = new BooleanFieldWrapperWorker(fieldname);
        BooleanFieldWrapperCreator creator = new BooleanFieldWrapperCreator(worker);
        if (isCallingOnUiThread()) {
            Boolean bObject = getBooleanFieldWrapperInternal(fieldname);
            if (bObject != null) {
                return bObject.booleanValue();
            }
            return false;
        }
        View javaview = this.mView.get();
        if (javaview == null) {
            Log.e("TextInputWorker", "javaview is null");
            return false;
        }
        Handler handler = javaview.getHandler();
        if (handler == null) {
            Log.e("TextInputWorker", "handler is null");
            return false;
        }
        handler.post(creator);
        Boolean bObject2 = creator.get();
        if (bObject2 != null) {
            return bObject2.booleanValue();
        }
        return false;
    }

    public void addTextChangedListener(final TextWatcher textWatcher) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.49
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.addTextChangedListener(textWatcher);
                }
            }).start();
        } else {
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.50
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.addTextChangedListener(textWatcher);
                }
            });
        }
    }

    public void setText(final CharSequence text, final TextView.BufferType type) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.51
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.setText(text, type);
                }
            }).start();
        } else {
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.52
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.setText(text, type);
                }
            });
        }
    }

    private class GetTextWorker implements Callable<Editable> {
        private GetTextWorker() {
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // java.util.concurrent.Callable
        public Editable call() throws Exception {
            return TextInputWorker.this.mEditText.getText();
        }
    }

    private class GetTextCreator extends FutureTask<Editable> {
        public GetTextCreator(Callable<Editable> callable) {
            super(callable);
        }
    }

    public Editable getText() throws InterruptedException, ExecutionException {
        if (!this.mInitialized) {
            initialize(false);
        }
        GetTextWorker worker = new GetTextWorker();
        GetTextCreator creator = new GetTextCreator(worker);
        if (isCallingOnUiThread()) {
            return this.mEditText.getText();
        }
        View javaview = this.mView.get();
        if (javaview == null) {
            Log.e("TextInputWorker", "javaview is null");
            return null;
        }
        Handler handler = javaview.getHandler();
        if (handler == null) {
            Log.e("TextInputWorker", "handler is null");
            return null;
        }
        handler.post(creator);
        Editable editable = creator.get();
        return editable;
    }

    public void append(final CharSequence text) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.53
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.append(text);
                }
            }).start();
        } else {
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.54
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.append(text);
                }
            });
        }
    }

    public void append(final CharSequence text, final int start, final int end) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.55
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.append(text, start, end);
                }
            }).start();
        } else {
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.56
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.append(text, start, end);
                }
            });
        }
    }

    public void setSingleLine(final boolean bSingleLine) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.57
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.setSingleLine(bSingleLine);
                }
            }).start();
        } else {
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.58
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.setSingleLine(bSingleLine);
                }
            });
        }
    }

    public void setLines(final int lines) {
        if (!this.mInitialized) {
            new Thread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.59
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(100L);
                    } catch (InterruptedException e) {
                    }
                    TextInputWorker.this.setLines(lines);
                }
            }).start();
        } else {
            invokeOnUiThread(new Runnable() { // from class: com.htc.fusion.fx.controls.TextInputWorker.60
                @Override // java.lang.Runnable
                public void run() {
                    TextInputWorker.this.mEditText.setLines(lines);
                }
            });
        }
    }

    public boolean containAndroidView(View v) {
        return this.mEditText == v;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean scaleHitboxWithEditText(EditText editText, FxHitbox hitbox) {
        editText.getWidth();
        editText.getHeight();
        return true;
    }

    private void invokeOnUiThread(Runnable runnable) {
        if (isCallingOnUiThread()) {
            runnable.run();
            return;
        }
        View javaview = this.mView.get();
        if (javaview != null) {
            Handler handler = javaview.getHandler();
            if (handler != null) {
                handler.post(runnable);
                return;
            } else {
                Log.e("TextInputWorker", "handler is null");
                return;
            }
        }
        Log.e("TextInputWorker", "javaview is null");
    }

    private abstract class MessageHandlerListener<T> extends MessageListener<T> {
        private MessageHandlerListener<T>.InnerListener mInnerListener;

        public MessageHandlerListener(View view) {
            this.mInnerListener = new InnerListener(view);
        }

        @Override // com.htc.fusion.fx.MessageListener, com.htc.fusion.fx.IMessageListener
        public void setSource_ONLY_THE_SOURCE_SHOULD_CALL_THIS(IMessageSource<T> source) {
            if (source != null) {
                source.unbind(this);
                source.bind(this.mInnerListener);
            } else {
                unbind();
            }
        }

        @Override // com.htc.fusion.fx.MessageListener, com.htc.fusion.fx.IMessageListener
        public void unbind() {
            this.mInnerListener.unbind();
        }

        private class InnerListener extends MessageListener<T> {
            private Handler mHandler;
            private View mView;

            public InnerListener(View view) {
                this.mView = view;
                this.mHandler = this.mView.getHandler();
            }

            @Override // com.htc.fusion.fx.IMessageListener
            public void onMessageReceived(T message) {
                long uiThreadId = Looper.getMainLooper().getThread().getId();
                if (uiThreadId == Thread.currentThread().getId()) {
                    MessageHandlerListener.this.onMessageReceived(message);
                } else {
                    MessageHandlerListener<T>.InnerListener.OuterCaller outerCaller = new OuterCaller(message);
                    this.mHandler.post(outerCaller);
                }
            }

            private class OuterCaller implements Runnable {
                private T mMessageParam;

                public OuterCaller(T message) {
                    this.mMessageParam = message;
                }

                @Override // java.lang.Runnable
                public void run() {
                    MessageHandlerListener.this.onMessageReceived(this.mMessageParam);
                }
            }
        }
    }
}
