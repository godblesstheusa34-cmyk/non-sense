package com.htc.fusion.mode10;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class RichTextVisualAttributes {
    public boolean bold;
    public int color;
    public String fontFaceName;
    public float fontHeight;
    public boolean italic;
    public boolean underline;
}
