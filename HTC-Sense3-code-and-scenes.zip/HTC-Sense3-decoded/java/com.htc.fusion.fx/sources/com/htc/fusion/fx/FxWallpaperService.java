package com.htc.fusion.fx;

import android.content.Context;
import android.service.wallpaper.WallpaperService;
import android.view.MotionEvent;
import android.view.SurfaceHolder;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public abstract class FxWallpaperService extends WallpaperService {
    @Override // android.service.wallpaper.WallpaperService, android.app.Service
    public void onCreate() {
        super.onCreate();
    }

    @Override // android.service.wallpaper.WallpaperService, android.app.Service
    public void onDestroy() {
        super.onDestroy();
    }

    protected class FxWallpaperEngine extends WallpaperService.Engine {
        private Context mContext;
        private FxViewObject mViewObject;

        protected FxWallpaperEngine(Context context) {
            super(FxWallpaperService.this);
            this.mContext = context;
        }

        @Override // android.service.wallpaper.WallpaperService.Engine
        public void onCreate(SurfaceHolder surfaceHolder) {
            super.onCreate(surfaceHolder);
            this.mViewObject = FxViewObject.create(null);
            this.mViewObject.setPackageResourcePath(this.mContext.getPackageResourcePath());
        }

        public void dispose() {
            setTouchEventsEnabled(false);
            if (this.mViewObject != null) {
                this.mViewObject.clearHandle();
                this.mViewObject = null;
            }
        }

        @Override // android.service.wallpaper.WallpaperService.Engine
        public void onDestroy() {
            super.onDestroy();
            dispose();
        }

        @Override // android.service.wallpaper.WallpaperService.Engine
        public void onTouchEvent(MotionEvent ev) {
            if (this.mViewObject != null) {
                int action = ev.getActionMasked();
                if (action == 2) {
                    for (int i = 0; i < ev.getPointerCount(); i++) {
                        this.mViewObject.onTouchEvent(action, ev.getPointerId(i), ev.getX(i), ev.getY(i));
                    }
                } else {
                    int pointerIndex = ev.getActionIndex();
                    this.mViewObject.onTouchEvent(action, ev.getPointerId(pointerIndex), ev.getX(pointerIndex), ev.getY(pointerIndex));
                }
            }
            super.onTouchEvent(ev);
        }

        @Override // android.service.wallpaper.WallpaperService.Engine
        public void onSurfaceCreated(SurfaceHolder holder) {
            super.onSurfaceCreated(holder);
        }

        @Override // android.service.wallpaper.WallpaperService.Engine
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            super.onSurfaceDestroyed(holder);
            if (this.mViewObject != null) {
                this.mViewObject.setSurface(null, 0, 0, 0);
            }
        }

        @Override // android.service.wallpaper.WallpaperService.Engine
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            if (this.mViewObject != null) {
                this.mViewObject.setSurface(holder.getSurface(), format, width, height);
            }
        }

        @Override // android.service.wallpaper.WallpaperService.Engine
        public void onVisibilityChanged(boolean visible) {
            super.onVisibilityChanged(visible);
            if (visible) {
                if (this.mViewObject != null) {
                    this.mViewObject.resumeRendering();
                }
            } else if (this.mViewObject != null) {
                this.mViewObject.pauseRendering();
            }
        }

        public boolean equals(Object o) {
            if (o == null) {
                return false;
            }
            if (!FxWallpaperEngine.class.isInstance(o) || this.mViewObject == null) {
                return false;
            }
            FxViewObject fvo = ((FxWallpaperEngine) o).getViewObject();
            return this.mViewObject.equals(fvo);
        }

        public int hashCode() {
            if (this.mViewObject == null) {
                return 0;
            }
            int hash = this.mViewObject.hashCode();
            return hash;
        }

        public FxScene createScene(String fileName) {
            if (this.mViewObject == null) {
                return null;
            }
            FxScene s = this.mViewObject.createScene(fileName, false);
            return s;
        }

        public FxScene createScene(String fileName, boolean initialVisibility) {
            if (this.mViewObject == null) {
                return null;
            }
            FxScene s = this.mViewObject.createScene(fileName, initialVisibility);
            return s;
        }

        public FxScene createScene(FxSceneLoader loader, boolean initialVisibility) {
            if (this.mViewObject == null) {
                return null;
            }
            FxScene s = this.mViewObject.createScene(loader, initialVisibility);
            return s;
        }

        public FxViewObject getViewObject() {
            return this.mViewObject;
        }

        public void addScene(FxScene s) {
            if (this.mViewObject != null) {
                this.mViewObject.addScene(s);
            }
        }

        public void removeScene(FxScene s) {
            if (this.mViewObject != null) {
                this.mViewObject.removeScene(s);
            }
        }
    }
}
