package com.htc.fusion.fx.controls;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxListItemEvent {
    public int eventType;
    public FxListItem listItem;

    protected FxListItemEvent(FxListItem listItem, int eventType) {
        this.listItem = listItem;
        this.eventType = eventType;
    }
}
