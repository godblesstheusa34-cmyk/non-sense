package com.htc.fusion.fx;

import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class MessageSource<T> implements IMessageSource<T> {
    private CopyOnWriteArrayList<WeakReference<IMessageListener<T>>> listeners = new CopyOnWriteArrayList<>();

    @Override // com.htc.fusion.fx.IMessageSource
    public void bind(IMessageListener<T> listener) {
        if (listener == null) {
            throw new IllegalArgumentException();
        }
        listener.unbind();
        this.listeners.add(new WeakReference<>(listener));
        listener.setSource_ONLY_THE_SOURCE_SHOULD_CALL_THIS(this);
    }

    @Override // com.htc.fusion.fx.IMessageSource
    public void unbind(IMessageListener<T> listener) {
        listener.setSource_ONLY_THE_SOURCE_SHOULD_CALL_THIS(null);
        Iterator i$ = this.listeners.iterator();
        while (i$.hasNext()) {
            WeakReference<IMessageListener<T>> weakReference = i$.next();
            IMessageListener<T> currentListener = weakReference.get();
            if (currentListener == null || currentListener == listener || currentListener.equals(listener)) {
                this.listeners.remove(weakReference);
            }
        }
    }

    @Override // com.htc.fusion.fx.IMessageSource
    public void unbindAll() {
        Iterator i$ = this.listeners.iterator();
        while (i$.hasNext()) {
            WeakReference<IMessageListener<T>> weakReference = i$.next();
            IMessageListener<T> currentListener = weakReference.get();
            if (currentListener != null) {
                currentListener.setSource_ONLY_THE_SOURCE_SHOULD_CALL_THIS(null);
            }
        }
        this.listeners.clear();
    }

    public void raiseMessage(T message) {
        Iterator i$ = this.listeners.iterator();
        while (i$.hasNext()) {
            WeakReference<IMessageListener<T>> weakReference = i$.next();
            IMessageListener<T> currentListener = weakReference.get();
            if (currentListener != null) {
                currentListener.onMessageReceived(message);
            } else {
                this.listeners.remove(weakReference);
            }
        }
    }
}
