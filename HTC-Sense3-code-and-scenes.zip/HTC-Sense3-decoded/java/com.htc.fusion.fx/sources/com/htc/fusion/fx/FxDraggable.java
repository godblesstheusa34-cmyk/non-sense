package com.htc.fusion.fx;

import android.app.Activity;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public interface FxDraggable {

    public static class BeginDragStyle {
        public static int PRESS = 1;
        public static int LONG_PRESS = 2;
        public static int MANUAL = 3;
        public static int DEFAULT = PRESS;
    }

    public static class EndDragStyle {
        public static int AUTO = 1;
        public static int MANUAL = 2;
        public static int DEFAULT = AUTO;
    }

    void beginDrag();

    void endDrag();

    IMessageSource<FxDraggable> getBeginDragSource();

    int getBeginDragStyle();

    IMessageSource<FxDroppable> getDragOutSource();

    IMessageSource<FxDroppable> getDragOverSource();

    String[] getDragScope();

    IMessageSource<FxDraggable> getEndDragSource();

    int getEndDragStyle();

    boolean isEnabled();

    void setBeginDragStyle(int i);

    void setDragScope(String[] strArr);

    void setEnabled(boolean z);

    void setEndDragStyle(int i);

    void setOnBeginDragListener(OnDragEventListener onDragEventListener);

    void setOnEndDragListener(OnDragEventListener onDragEventListener);

    public static abstract class OnDragEventListener extends MessageActivityListener<FxDraggable> {
        public abstract void onDragEvent(FxDraggable fxDraggable);

        public OnDragEventListener(Activity activity) {
            super(activity);
        }

        @Override // com.htc.fusion.fx.IMessageListener
        public void onMessageReceived(FxDraggable draggable) {
            onDragEvent(draggable);
        }
    }
}
