package com.htc.fusion.fx;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public interface IMessageSource<T> {
    void bind(IMessageListener<T> iMessageListener);

    void unbind(IMessageListener<T> iMessageListener);

    void unbindAll();
}
