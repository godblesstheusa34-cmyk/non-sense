package com.htc.fusion.fx;

import android.util.Log;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxObject extends NativeReference {
    private static native int getBuildVersion();

    private static native int getMajorVersion();

    private static native int getMinorVersion();

    @Deprecated
    public native boolean executeCommandOnDescendant(String str, int i, Object obj);

    public native FxObject getChild(String str);

    public native FxObject getChildByType(Class<? extends FxObject> cls, int i);

    public native int getChildCount();

    public native int getChildCountByType(Class<? extends FxObject> cls);

    public native ChildIterator getChildIterator();

    public native FxObject[] getChildren(String[] strArr);

    public native FxObject getDescendant(String str);

    public native FxObject getDescendantByType(Class<? extends FxObject> cls, int i);

    public native int getDescendantCount();

    public native int getDescendantCountByType(Class<? extends FxObject> cls);

    public native FxObject[] getDescendants(String[] strArr);

    public native String getName();

    public native FxObject getParent();

    static {
        loadNativeLibrary();
    }

    protected static void loadNativeLibrary() {
        System.loadLibrary("mode10fx");
        if (1 != getMajorVersion() || 1617 < getMinorVersion() || 1 < getBuildVersion()) {
            String exceptionMsg = "mode10fx.so version mismatch 1.1617.1:" + getMajorVersion() + "." + getMinorVersion() + "." + getBuildVersion();
            Log.e("mode10", exceptionMsg);
            throw new RuntimeException(exceptionMsg);
        }
    }

    protected FxObject(int handle) {
        super(handle);
    }

    public FxObject getChildByType(Class<? extends FxObject> type) {
        return getChildByType(type, 0);
    }

    public FxObject getDescendantByType(Class<? extends FxObject> type) {
        return getDescendantByType(type, 0);
    }

    public static class ChildIterator extends NativeReference {
        public native FxObject get();

        public native void goToBeginning();

        public native void goToEnd();

        public native boolean isBeginning();

        public native boolean isEnd();

        public native void next();

        public native void previous();

        protected ChildIterator(int handle) {
            super(handle);
        }
    }
}
