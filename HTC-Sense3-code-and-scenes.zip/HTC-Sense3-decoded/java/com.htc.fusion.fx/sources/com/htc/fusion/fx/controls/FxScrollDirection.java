package com.htc.fusion.fx.controls;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public final class FxScrollDirection {
    public static final int HORIZONTAL_LEFT_TO_RIGHT = 0;
    public static final int HORIZONTAL_RIGHT_TO_LEFT = 1;
    public static final int VERTICAL_BOTTOM_TO_TOP = 3;
    public static final int VERTICAL_TOP_TO_BOTTOM = 2;
}
