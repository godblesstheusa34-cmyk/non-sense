package com.htc.fusion.fx.controls;

import android.graphics.PointF;
import com.htc.fusion.fx.FxControl;
import com.htc.fusion.fx.FxNodeControl;
import com.htc.fusion.fx.IMessageSource;
import com.htc.fusion.fx.Stroke;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxHitbox extends FxNodeControl {
    public static final int EVENT_CANCEL = 3;
    public static final int EVENT_PRESS = 1;
    public static final int EVENT_RELEASE = 2;
    public static final int GESTUREFLAG_ALL = 15;
    public static final int GESTUREFLAG_LONGTAP = 2;
    public static final int GESTUREFLAG_NONE = 0;
    public static final int GESTUREFLAG_SCALE = 8;
    public static final int GESTUREFLAG_SWIPE = 4;
    public static final int GESTUREFLAG_TAP = 1;
    public static final int GESTUREFLAG_VALID = 15;
    public static final int TOUCHINTEREST_CLAIMOWNERSHIP = 2;
    public static final int TOUCHINTEREST_INTERESTED = 1;
    public static final int TOUCHINTEREST_NOTINTERESTED = 0;
    public static final int TOUCHOPACITY_ANCESTORTRANSPARENT = 3;
    public static final int TOUCHOPACITY_OPAQUE = 2;
    public static final int TOUCHOPACITY_TRANSPARENT = 1;

    public static class EventParameters {
        public FxControl control;
        public int event;
        public PointF hitbox_position;
        public int signaledGestures;
        public Stroke stroke;
    }

    public static class LongTapParameters {
        public FxControl control;
        public PointF position;
    }

    public static class MoveEventParameters {
        public FxControl control;
        public PointF hitbox_position;
        public boolean inNode;
        public int signaledGestures;
        public Stroke stroke;
    }

    public static class ScaleParameters {
        public FxControl control;
        public PointF currentPosition1;
        public PointF currentPosition2;
        public int duration;
        public float scale;
        public PointF startPosition1;
        public PointF startPosition2;
    }

    public static class SwipeParameters {
        public FxControl control;
        public int duration;
        public PointF endPosition;
        public PointF startPosition;
        public float velocity;
    }

    public static class TapParameters {
        public FxControl control;
        public PointF position;
    }

    public native boolean getEnabled();

    public native int getEnabledGestures();

    public native IMessageSource<EventParameters> getEventSource();

    public native IMessageSource<LongTapParameters> getLongTapSource();

    public native IMessageSource<MoveEventParameters> getMoveEventSource();

    public native float getScaleHeight();

    public native IMessageSource<ScaleParameters> getScaleSource();

    public native float getScaleWidth();

    public native int getStrokeInterest();

    public native IMessageSource<SwipeParameters> getSwipeSource();

    public native IMessageSource<TapParameters> getTapSource();

    public native int getTouchOpacity();

    public native void setEnabled(boolean z);

    public native void setEnabledGestures(int i);

    public native void setScaleHeight(float f);

    public native void setScaleWidth(float f);

    public native void setStrokeInterest(int i);

    public native void setTouchOpacity(int i);

    public FxHitbox(int handle) {
        super(handle);
    }
}
