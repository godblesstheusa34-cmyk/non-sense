package com.htc.fusion.fx;

import android.graphics.PointF;
import android.util.Log;
import com.htc.fusion.Point3F;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxNodeControl extends FxControl {

    private interface FutureBase<T> extends Future<T> {
        void set(T t);
    }

    private native void setVisibilityNative(boolean z, FutureBase<Boolean> futureBase, FutureBase<Boolean> futureBase2);

    public native int getHighlight();

    @Deprecated
    public native Point3F getPosition();

    @Deprecated
    public native PointF getSize();

    public native boolean getTouchFilter();

    public native boolean getVisibility();

    public native Point3F getWorldPosition();

    public native void setHighlight(int i);

    @Deprecated
    public native void setPosition(Point3F point3F);

    public native void setTouchFilter(boolean z);

    protected FxNodeControl(int handle) {
        super(handle);
    }

    public ArrayList<Future<Boolean>> setVisibility(boolean visibility) {
        ArrayList<Future<Boolean>> arrListFuture = new ArrayList<>();
        BasicFuture<Boolean> setVisibilityCompleteFuture = new BasicFuture<>();
        BasicFuture<Boolean> setVisibilityRenderCompleteFuture = new BasicFuture<>();
        setVisibilityNative(visibility, setVisibilityCompleteFuture, setVisibilityRenderCompleteFuture);
        arrListFuture.add(0, setVisibilityCompleteFuture);
        arrListFuture.add(1, setVisibilityRenderCompleteFuture);
        return arrListFuture;
    }

    private class BasicFuture<T> implements FutureBase<T> {
        private boolean m_fIsSet;
        private Object m_lock;
        private T m_value;

        private BasicFuture() {
            this.m_lock = new Object();
            this.m_value = null;
            this.m_fIsSet = false;
        }

        @Override // java.util.concurrent.Future
        public boolean cancel(boolean mayInterruptIfRunning) {
            return false;
        }

        @Override // java.util.concurrent.Future
        public boolean isCancelled() {
            return false;
        }

        @Override // java.util.concurrent.Future
        public boolean isDone() {
            boolean z;
            synchronized (this.m_lock) {
                z = this.m_fIsSet;
            }
            return z;
        }

        @Override // java.util.concurrent.Future
        public T get() throws InterruptedException, ExecutionException {
            synchronized (this.m_lock) {
                if (!this.m_fIsSet) {
                    this.m_lock.wait();
                    if (!this.m_fIsSet) {
                        return null;
                    }
                }
                return this.m_value;
            }
        }

        @Override // java.util.concurrent.Future
        public T get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
            T t;
            synchronized (this.m_lock) {
                if (!this.m_fIsSet) {
                    this.m_lock.wait(unit.toMillis(timeout));
                    if (!this.m_fIsSet) {
                        Log.d("FxNodeControl", "BasicFuture_get timeout");
                        throw new TimeoutException();
                    }
                }
                Log.d("FxNodeControl", "BasicFuture_get return m_value = " + this.m_value);
                t = this.m_value;
            }
            return t;
        }

        @Override // com.htc.fusion.fx.FxNodeControl.FutureBase
        public void set(T value) {
            synchronized (this.m_lock) {
                this.m_fIsSet = true;
                this.m_value = value;
                this.m_lock.notifyAll();
            }
        }
    }

    public final class SetVisibilityFutureIndex {
        public static final int SET_VISIBILITY_COMPLETE = 0;
        public static final int SET_VISIBILITY_RENDER_COMPLETE = 1;

        public SetVisibilityFutureIndex() {
        }
    }
}
