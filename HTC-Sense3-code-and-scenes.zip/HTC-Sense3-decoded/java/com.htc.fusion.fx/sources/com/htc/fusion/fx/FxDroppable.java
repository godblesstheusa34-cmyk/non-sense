package com.htc.fusion.fx;

import android.app.Activity;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public interface FxDroppable {
    void drop(FxDraggable fxDraggable);

    void dropActivate(FxDraggable fxDraggable);

    void dropDeactivate(FxDraggable fxDraggable);

    String[] getDragScope();

    IMessageSource<FxDraggable> getDropActivateSource();

    IMessageSource<FxDraggable> getDropDeactivateSource();

    IMessageSource<FxDraggable> getDropOutSource();

    IMessageSource<FxDraggable> getDropOverSource();

    IMessageSource<FxDraggable> getDropSource();

    boolean isEnabled();

    void setDragScope(String[] strArr);

    void setEnabled(boolean z);

    void setOnDropActivateListener(OnDragEventListener onDragEventListener);

    void setOnDropDeactivateListener(OnDragEventListener onDragEventListener);

    void setOnDropListener(OnDragEventListener onDragEventListener);

    void setOnDropOutListener(OnDragEventListener onDragEventListener);

    void setOnDropOverListener(OnDragEventListener onDragEventListener);

    public static abstract class OnDragEventListener extends MessageActivityListener<FxDraggable> {
        public abstract void onDropEvent(FxDraggable fxDraggable);

        public OnDragEventListener(Activity activity) {
            super(activity);
        }

        @Override // com.htc.fusion.fx.IMessageListener
        public void onMessageReceived(FxDraggable draggable) {
            onDropEvent(draggable);
        }
    }
}
