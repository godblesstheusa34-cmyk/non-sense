package com.htc.fusion.fx;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public interface IMessageListener<T> {
    void onMessageReceived(T t);

    void setSource_ONLY_THE_SOURCE_SHOULD_CALL_THIS(IMessageSource<T> iMessageSource);

    void unbind();
}
