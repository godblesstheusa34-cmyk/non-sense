package com.htc.fusion.fx;

import android.graphics.Bitmap;
import android.graphics.Rect;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxScene extends FxTimelineControl {

    private interface FutureBase<T> extends Future<T> {
        void set(T t);
    }

    public static native FxScene create(FxSceneLoader fxSceneLoader, boolean z);

    public static native FxScene create(String str, boolean z);

    private native void nativeGetSceneSnapshot(FutureBase<Bitmap> futureBase, Rect rect);

    public native String getLoadedFile();

    public native boolean isFileLoaded();

    public native boolean load(FxSceneLoader fxSceneLoader, boolean z);

    public native void unload();

    protected FxScene(int handle) {
        super(handle);
    }

    public static FxScene create(String fileName) {
        return create(fileName, false);
    }

    public static FxScene create(FxSceneLoader loader) {
        return create(loader, false);
    }

    public boolean load(String fileName) {
        return load(fileName, false);
    }

    public boolean load(String fileName, boolean initialVisibility) {
        return load(FxSceneLoader.create(fileName), initialVisibility);
    }

    public FxControl findControl(String controlName) {
        FxObject descendant = getDescendant(controlName);
        if (descendant != null && !(descendant instanceof FxControl)) {
            throw new FxException("Named descendant object is not a control");
        }
        return (FxControl) descendant;
    }

    public Future<Bitmap> getSceneSnapshot() {
        BasicFuture<Bitmap> sceneSnapshotFuture = new BasicFuture<>();
        Rect rect = new Rect(0, 0, 0, 0);
        nativeGetSceneSnapshot(sceneSnapshotFuture, rect);
        return sceneSnapshotFuture;
    }

    public Future<Bitmap> getSceneSnapshot(Rect rect) {
        BasicFuture<Bitmap> sceneSnapshotFuture = new BasicFuture<>();
        nativeGetSceneSnapshot(sceneSnapshotFuture, rect);
        return sceneSnapshotFuture;
    }

    private class BasicFuture<T> implements FutureBase<T> {
        private boolean m_fIsSet;
        private Object m_lock;
        private T m_value;

        private BasicFuture() {
            this.m_lock = new Object();
            this.m_value = null;
            this.m_fIsSet = false;
        }

        @Override // java.util.concurrent.Future
        public boolean cancel(boolean mayInterruptIfRunning) {
            return false;
        }

        @Override // java.util.concurrent.Future
        public boolean isCancelled() {
            return false;
        }

        @Override // java.util.concurrent.Future
        public boolean isDone() {
            boolean z;
            synchronized (this.m_lock) {
                z = this.m_fIsSet;
            }
            return z;
        }

        @Override // java.util.concurrent.Future
        public T get() throws InterruptedException, ExecutionException {
            synchronized (this.m_lock) {
                if (!this.m_fIsSet) {
                    this.m_lock.wait();
                    if (!this.m_fIsSet) {
                        return null;
                    }
                }
                return this.m_value;
            }
        }

        @Override // java.util.concurrent.Future
        public T get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException {
            T t;
            synchronized (this.m_lock) {
                if (!this.m_fIsSet) {
                    this.m_lock.wait(unit.toMillis(timeout));
                    if (!this.m_fIsSet) {
                        throw new TimeoutException();
                    }
                }
                t = this.m_value;
            }
            return t;
        }

        @Override // com.htc.fusion.fx.FxScene.FutureBase
        public void set(T value) {
            synchronized (this.m_lock) {
                this.m_fIsSet = true;
                this.m_value = value;
                this.m_lock.notifyAll();
            }
        }
    }
}
