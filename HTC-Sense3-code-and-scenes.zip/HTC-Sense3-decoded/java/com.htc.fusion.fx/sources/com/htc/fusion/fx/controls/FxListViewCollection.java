package com.htc.fusion.fx.controls;

import android.util.Log;
import com.htc.fusion.fx.NativeReference;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxListViewCollection extends NativeReference {
    public static native FxListViewCollection create(int i, int[] iArr, int[] iArr2);

    public native void insertItems(int i, int i2, int[] iArr, int[] iArr2);

    public native void refreshItems(int i, int i2, boolean z);

    public native void removeItems(int i, int i2);

    protected FxListViewCollection(int handle) {
        super(handle);
        Log.i("FxListViewCollection", "FxListViewCollection is created with handle " + handle);
    }

    public void insertItems(int index, int count) {
        insertItems(index, count, new int[0], new int[0]);
    }

    public void refreshItems(int index, int count) {
        refreshItems(index, count, false);
    }

    public static FxListViewCollection create(int count) {
        return create(count, new int[0], new int[0]);
    }
}
