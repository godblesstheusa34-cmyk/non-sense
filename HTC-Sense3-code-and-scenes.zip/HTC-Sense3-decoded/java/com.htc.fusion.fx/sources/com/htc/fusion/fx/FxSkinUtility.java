package com.htc.fusion.fx;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/com.htc.fusion.fx.dex */
public class FxSkinUtility {
    private static final String DEFAULT_SKIN = "Default";
    private static final String FUSION_APK_PATH = "/system/app/fusion.apk";
    private static final String FUSION_SHAREDM10PATH_LANDSCAPE = "/drawable_land/shared.m10";
    private static final String FUSION_SHAREDM10PATH_PORTRAIT = "/drawable/shared.m10";

    public static void loadSkinResource(Context context, int orientation) {
        String skinPackage;
        boolean isSystemApk;
        Class htcSkinUtil = HtcCommonCtrl.loadClass("com.htc.util.skin.HtcSkinUtil");
        if (htcSkinUtil != null) {
            try {
                skinPackage = (String) htcSkinUtil.getMethod("getAppliedSkinPackageName", new Class[0]).invoke(null, new Object[0]);
            } catch (Exception e) {
                Log.e("mode10", "Unable to locate getAppliedSkinPackageName.");
                e.printStackTrace();
                skinPackage = null;
            }
            if (skinPackage == null) {
                loadSkinResource(orientation, DEFAULT_SKIN, FUSION_APK_PATH);
                return;
            }
            String skinName = skinPackage.substring(skinPackage.lastIndexOf(46) + 1);
            Log.i("mode10", "loadSkinResource : Package = " + skinPackage + " skinName = " + skinName);
            try {
                isSystemApk = ((Boolean) htcSkinUtil.getMethod("isSystemApk", Context.class, String.class).invoke(null, context, skinPackage)).booleanValue();
            } catch (Exception e2) {
                Log.e("mode10", "Unable to locate isSystemApk.");
                e2.printStackTrace();
                isSystemApk = false;
            }
            if (!isSystemApk) {
                PackageManager pm = context.getPackageManager();
                if (pm != null) {
                    try {
                        PackageInfo pkgInfo = pm.getPackageInfo(skinPackage, 8192);
                        Log.i("mode10", "APK directory = " + pkgInfo.applicationInfo.sourceDir);
                        loadSkinResource(orientation, skinName, pkgInfo.applicationInfo.sourceDir);
                        return;
                    } catch (PackageManager.NameNotFoundException e3) {
                        Log.i("mode10", "No such skin package matches the given name :" + skinPackage);
                        e3.printStackTrace();
                        loadSkinResource(orientation, skinName, FUSION_APK_PATH);
                        return;
                    }
                }
                loadSkinResource(orientation, skinName, FUSION_APK_PATH);
                return;
            }
            loadSkinResource(orientation, skinName, FUSION_APK_PATH);
            return;
        }
        Log.e("mode10", "Unable to locate HtcSkinUtil class.");
    }

    private static void loadSkinResource(int orientation, String skinName, String apkPath) {
        Log.i("mode10", "loadSkinResource private");
        if (orientation == 2) {
            String[] ApkNames = {FUSION_APK_PATH, FUSION_APK_PATH, apkPath, apkPath};
            String[] AssetName = {"Default/drawable/shared.m10", "Default/drawable_land/shared.m10", skinName + FUSION_SHAREDM10PATH_PORTRAIT, skinName + FUSION_SHAREDM10PATH_LANDSCAPE};
            int[] addToIndex = {0, 0, 0, 0};
            FxTextureLibrary.addLibrariesFromAPK(ApkNames, AssetName, addToIndex);
            return;
        }
        String[] ApkNames2 = {FUSION_APK_PATH, FUSION_APK_PATH, apkPath, apkPath};
        String[] AssetName2 = {"Default/drawable_land/shared.m10", "Default/drawable/shared.m10", skinName + FUSION_SHAREDM10PATH_LANDSCAPE, skinName + FUSION_SHAREDM10PATH_PORTRAIT};
        int[] addToIndex2 = {0, 0, 0, 0};
        FxTextureLibrary.addLibrariesFromAPK(ApkNames2, AssetName2, addToIndex2);
    }
}
