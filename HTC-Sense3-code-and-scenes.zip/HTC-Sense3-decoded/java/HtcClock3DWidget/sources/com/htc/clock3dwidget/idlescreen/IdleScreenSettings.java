package com.htc.clock3dwidget.idlescreen;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import com.htc.clock.util.MyLog;
import com.htc.clock3dwidget.util.Constants;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class IdleScreenSettings extends Activity {
    private static final String DEFAULT_CLOCK_TYPE = "0";
    public static final String EXTRA_KEY_PREFIX = "com.htc.launcher.intent";
    public static final String EXTRA_KEY_WIDGET_PROVIDER_ARRAY = "com.htc.launcher.intent.EXTRA_KEY_WIDGET_PROVIDER_ARRAY";
    public static final String EXTRA_KEY_WIDGET_PROVIDER_ARRAY_INDEX_FILTER = "com.htc.launcher.intent.EXTRA_KEY_WIDGET_PROVIDER_ARRAY_INDEX_FILTER";
    public static final String EXTRA_KEY_WIDGET_PROVIDER_ARRAY_INDEX_SELECT = "com.htc.launcher.intent.EXTRA_KEY_WIDGET_PROVIDER_ARRAY_INDEX_SELECT";
    public static final String FIRST_SET = "first_set";
    public static final String IS_APPLY = "is_apply";
    private static final String KEY_CLOCK_TYPE = "clock_type";
    private boolean mFirstSet;

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getApply() && getFirstSet()) {
            setResult(-1);
            finish();
            return;
        }
        Intent intent = new Intent();
        intent.setComponent(new ComponentName("com.htc.AddProgramWidget", "com.htc.AddProgramWidget.fusionwidget.StyleChooser"));
        if (getPackageManager().resolveActivity(intent, 0) == null) {
            intent.setComponent(new ComponentName("com.htc.home.personalize", "com.htc.home.personalize.fusionwidget.StyleChooser"));
        }
        ComponentName[] p = {new ComponentName(Constants.SETTING_PACKAGE, "com.htc.clock3dwidget.ClockWidgetProvider")};
        int[] value = {4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
        try {
            intent.putExtra(EXTRA_KEY_WIDGET_PROVIDER_ARRAY, p);
            intent.putExtra(EXTRA_KEY_WIDGET_PROVIDER_ARRAY_INDEX_FILTER, value);
            startActivityForResult(intent, 0);
        } catch (Exception ex) {
            MyLog.e("exception" + ex.toString());
        }
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
    }

    public static int getClockType(Context context) {
        String type = PreferenceManager.getDefaultSharedPreferences(context).getString(KEY_CLOCK_TYPE, DEFAULT_CLOCK_TYPE);
        return Integer.parseInt(type);
    }

    private boolean getApply() {
        Intent intent = getIntent();
        return intent != null && intent.hasExtra(IS_APPLY) && intent.getBooleanExtra(IS_APPLY, false);
    }

    private boolean getFirstSet() {
        SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
        this.mFirstSet = settings.getBoolean(FIRST_SET, false);
        return this.mFirstSet;
    }

    @Override // android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data != null) {
            int index = data.getIntExtra(EXTRA_KEY_WIDGET_PROVIDER_ARRAY_INDEX_SELECT, 0);
            SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(this);
            settings.edit().putString(KEY_CLOCK_TYPE, String.valueOf(index)).commit();
            if (!this.mFirstSet) {
                settings.edit().putBoolean(FIRST_SET, true).commit();
            }
            setResult(-1);
        }
        finish();
    }
}
