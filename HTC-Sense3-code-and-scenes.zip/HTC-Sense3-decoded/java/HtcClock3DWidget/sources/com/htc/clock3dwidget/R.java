package com.htc.clock3dwidget;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public final class R {

    public static final class array {
        public static final int am_and_pm_capital = 0x7f070002;
        public static final int clock_type_entries = 0x7f070003;
        public static final int clock_type_values = 0x7f070004;
        public static final int days_of_week_capital = 0x7f070000;
        public static final int month_of_year = 0x7f070001;
    }

    public static final class attr {
    }

    public static final class color {
        public static final int black = 0x7f05000a;
        public static final int day_am_and_pm_color = 0x7f050003;
        public static final int day_am_and_pm_shade_color = 0x7f050004;
        public static final int day_week_and_day_color = 0x7f050001;
        public static final int day_week_and_day_shade_color = 0x7f050002;
        public static final int grey = 0x7f05000d;
        public static final int light_grey = 0x7f05000e;
        public static final int ltgrey = 0x7f05000c;
        public static final int magic_flame = 0x7f050000;
        public static final int more_detail_pressed = 0x7f050012;
        public static final int more_detail_unpress = 0x7f050011;
        public static final int night_am_and_pm_color = 0x7f050007;
        public static final int night_am_and_pm_shade_color = 0x7f050008;
        public static final int night_week_and_day_color = 0x7f050005;
        public static final int night_week_and_day_shade_color = 0x7f050006;
        public static final int red = 0x7f05000f;
        public static final int transparent = 0x7f05000b;
        public static final int transparent_grey = 0x7f050010;
        public static final int white = 0x7f050009;
    }

    public static final class drawable {
        public static final int clock = 0x7f020000;
        public static final int icon_indicator_likes_white = 0x7f020001;
        public static final int icon_indicator_replies_white = 0x7f020002;
        public static final int my_common_divider_items = 0x7f020003;
        public static final int preview_clock = 0x7f020004;
        public static final int preview_clock03 = 0x7f020005;
        public static final int preview_clock04 = 0x7f020006;
        public static final int preview_clock05 = 0x7f020007;
        public static final int preview_clock06 = 0x7f020008;
        public static final int preview_clock07 = 0x7f020009;
        public static final int preview_clock08 = 0x7f02000a;
        public static final int preview_clock09 = 0x7f02000b;
        public static final int preview_clock10 = 0x7f02000c;
        public static final int preview_clock1x1 = 0x7f02000d;
        public static final int preview_clock2x2 = 0x7f02000e;
        public static final int preview_clock_beam = 0x7f02000f;
        public static final int preview_clock_digital = 0x7f020010;
        public static final int preview_clock_dual = 0x7f020011;
        public static final int preview_clock_ring = 0x7f020012;
        public static final int preview_clock_social = 0x7f020013;
        public static final int preview_clock_spin_cycle = 0x7f020014;
        public static final int preview_clock_weather = 0x7f020015;
    }

    public static final class id {
        public static final int LL_list_cities = 0x7f090000;
        public static final int command_bar = 0x7f090005;
        public static final int list_cities = 0x7f090002;
        public static final int setting_list = 0x7f090004;
        public static final int title = 0x7f090001;
        public static final int wwp_setting_layout = 0x7f090003;
    }

    public static final class layout {
        public static final int select_city = 0x7f030000;
        public static final int wwp_setting_view = 0x7f030001;
    }

    public static final class string {
        public static final int add_city = 0x7f06002c;
        public static final int add_city_error_msg = 0x7f06002d;
        public static final int add_city_error_title = 0x7f060028;
        public static final int add_widget = 0x7f060004;
        public static final int and = 0x7f060020;
        public static final int app_name = 0x7f060011;
        public static final int apply = 0x7f060019;
        public static final int check_box_show_city_name = 0x7f06002a;
        public static final int cite_reselect = 0x7f06001d;
        public static final int clock_type_title = 0x7f060016;
        public static final int clock_widget_provider_label = 0x7f060000;
        public static final int company = 0x7f060002;
        public static final int current_location = 0x7f060005;
        public static final int data_error = 0x7f06001e;
        public static final int done = 0x7f060027;
        public static final int dummy_settings_label = 0x7f060012;
        public static final int home = 0x7f06002e;
        public static final int home_widget_plugins = 0x7f060001;
        public static final int idle_screen_clock = 0x7f060013;
        public static final int idle_screen_desc = 0x7f060014;
        public static final int location_enable = 0x7f060018;
        public static final int mylocation = 0x7f060017;
        public static final int number_photos_multiple = 0x7f060021;
        public static final int number_photos_single = 0x7f060022;
        public static final int number_videos_multiple = 0x7f060023;
        public static final int number_videos_single = 0x7f060024;
        public static final int ok = 0x7f06002b;
        public static final int recently_uploaded = 0x7f06001f;
        public static final int select_city = 0x7f060029;
        public static final int select_city_first = 0x7f06002f;
        public static final int select_city_second = 0x7f060030;
        public static final int settings = 0x7f060015;
        public static final int simple_widget_date = 0x7f060010;
        public static final int social_empty = 0x7f06001c;
        public static final int social_login_now_tap = 0x7f06001b;
        public static final int weather_high_indicator = 0x7f060006;
        public static final int weather_low_indicator = 0x7f060007;
        public static final int widget_analog_clock = 0x7f06000a;
        public static final int widget_beam_clock = 0x7f06000d;
        public static final int widget_detail = 0x7f06001a;
        public static final int widget_digital_clock = 0x7f06000b;
        public static final int widget_dual_clock = 0x7f06000c;
        public static final int widget_label = 0x7f060003;
        public static final int widget_ring_clock = 0x7f06000e;
        public static final int widget_social_clock = 0x7f060009;
        public static final int widget_spin_cycle_clock = 0x7f06000f;
        public static final int widget_weather_clock = 0x7f060008;
        public static final int wwp_setting_show_wwp = 0x7f060026;
        public static final int wwp_setting_title = 0x7f060025;
    }

    public static final class style {
        public static final int ThemeTitle = 0x7f080000;
    }

    public static final class xml {
        public static final int clock_widget = 0x7f040000;
        public static final int idle_screen_clock = 0x7f040001;
    }
}
