package com.htc.clock3dwidget.weatherclock;

import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.sqlite.SQLiteFullException;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;
import com.htc.android.rosie.widget.Widget;
import com.htc.clock.util.MyLog;
import com.htc.clock.util.MyUtil;
import com.htc.clock.util.location.LocationCtrl;
import com.htc.clock.util.location.LocationListener;
import com.htc.clock.util.location.LocationUtil;
import com.htc.clock3dwidget.ClockUtils;
import com.htc.clock3dwidget.R;
import com.htc.clock3dwidget.util.Constants;
import com.htc.clock3dwidget.util.MyProjectSetting;
import com.htc.fusion.fx.FxScene;
import com.htc.util.weather.WeatherLocation;
import com.htc.util.weather.WeatherUtility;
import java.net.URISyntaxException;
import java.util.Locale;
import java.util.Properties;
import java.util.TimeZone;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class WeatherClockWidgetView extends Widget.Base {
    static final String ACTION_HIDE_WEATHER_WALLPAPER = "com.htc.weatherwallpaper.service.intent.action.HIDE_WEATHER_WALLPAPER";
    static final String ACTION_SHOW_WEATHER_WALLPAPER = "com.htc.weatherwallpaper.service.intent.action.SHOW_WEATHER_WALLPAPER";
    public static final String DEF_CITY = "defCityCode_";
    public static final String TAG = "WeatherClockWidget";
    private static boolean mbPlayWWPAtRosieStart = true;
    private Context mApplication;
    private WeatherClock mClockView;
    private FxWeatherControls mFxControlsLand;
    private FxWeatherControls mFxControlsPort;
    private Widget.Host.Worker mHandler;
    private BroadcastReceiver mLockScreenRec;
    private Context mResContext;
    private FxScene mSceneLand;
    private FxScene mScenePort;
    private Widget.Host.Worker mUiHandler;
    private Context mViewContext;
    private LocationCtrl mWeatherCtrl;
    private View mWeatherPress;
    private WeatherClock mWeatherView;
    private View uiView;
    int mWidgetId = 0;
    private int mOrientation = 1;
    private boolean mInitCreate = false;
    private boolean mInitResume = false;
    private boolean mInitPause = false;
    private Object mInitLock = new Object();
    private Object mLock = new Object();
    private boolean mBChangeTimeZone = false;
    private boolean mBoolAppResume = false;
    private boolean mBoolAppDestroy = false;
    private Intent mBackIntent = null;
    private boolean mLongClick = false;
    private boolean mbPlayWWPAtAdd = false;
    private UiState mUiState = UiState.NONE;
    private ContentResolver mContentResolver = null;
    private View.OnClickListener mClockClickListener = new View.OnClickListener() { // from class: com.htc.clock3dwidget.weatherclock.WeatherClockWidgetView.1
        @Override // android.view.View.OnClickListener
        public void onClick(View arg0) {
            WeatherClockWidgetView.this.sendNonUiMessageDelayed(Constants.WHAT_ON_CLICK_AP1, 0L);
        }
    };
    private View.OnClickListener mWeatherClockClick = new View.OnClickListener() { // from class: com.htc.clock3dwidget.weatherclock.WeatherClockWidgetView.2
        @Override // android.view.View.OnClickListener
        public void onClick(View arg0) {
            WeatherClockWidgetView.this.sendNonUiMessageDelayed(Constants.WHAT_ON_CLICK_AP2, 0L);
        }
    };
    boolean mPauseByAddToHome = false;
    private Handler.Callback mWorker = new Handler.Callback() { // from class: com.htc.clock3dwidget.weatherclock.WeatherClockWidgetView.3
        @Override // android.os.Handler.Callback
        public boolean handleMessage(Message msg) {
            if (msg.what == 1) {
                MyLog.i("weatherClock handleMessage~ help to check lock");
            }
            synchronized (this) {
                if (WeatherClockWidgetView.this.isWidgetDestroy()) {
                    MyLog.e("weather clock handleMessage~ widget destroied");
                    return false;
                }
                switch (msg.what) {
                    case 1:
                        MyLog.d("WHAT_ON_RESUME~ notifyCause:" + msg.arg1);
                        WeatherClockWidgetView.this.mUiState = UiState.RESUME;
                        WeatherClockWidgetView.this.mResumeNotifyCaused = msg.arg1;
                        WeatherClockWidgetView.this.mLastResumeTime = SystemClock.elapsedRealtime();
                        if (WeatherClockWidgetView.this.mClockView != null) {
                            WeatherClockWidgetView.this.mClockView.updateFormat();
                        } else {
                            MyLog.e("WHAT_ON_RESUME~ mClockView is null");
                        }
                        WeatherClockWidgetView.this.mBoolAppResume = true;
                        Message uiMsg = WeatherClockWidgetView.this.mUiHandler.obtainMessage();
                        uiMsg.what = Constants.MSG_ON_RESUME;
                        uiMsg.arg1 = msg.arg1;
                        uiMsg.arg2 = 0;
                        if (WeatherClockWidgetView.this.mWeatherCtrl.getState() != LocationCtrl.State.START) {
                            WeatherClockWidgetView.this.mUiHandler.sendDelayed(uiMsg, 0L);
                            Handler handler = new Handler();
                            WeatherClockWidgetView.this.mWeatherCtrl.register(handler, WeatherClockWidgetView.this.mWeatherListener);
                            WeatherClockWidgetView.this.mWeatherCtrl.checkLocEnable();
                            break;
                        } else {
                            WeatherClockWidgetView.this.mUiHandler.sendDelayed(uiMsg, 0L);
                            WeatherClockWidgetView.this.sendNonUiMessageDelayed(Constants.WHAT_ON_RESUME_DELAY, 300L);
                            break;
                        }
                    case 2:
                        int notifyCause = msg.arg1;
                        WeatherClockWidgetView.this.myOnNotifyWidgetPause(notifyCause);
                        break;
                    case 4:
                        MyLog.i("WHAT_ON_GL_ANIMATION_STOP~");
                        if (WeatherClockWidgetView.this.mWeatherView != null) {
                            WeatherClockWidgetView.this.mWeatherView.animationEnd();
                            break;
                        } else {
                            MyLog.e("WHAT_ON_GL_ANIMATION_STOP~ mWeatherView is null");
                            break;
                        }
                    case Constants.WHAT_ON_INIT /* 36865 */:
                        WeatherClockWidgetView.this.initData();
                        break;
                    case Constants.WHAT_ON_RESUME_DELAY /* 36868 */:
                        MyLog.d("WHAT_ON_RESUME_DELAY");
                        WeatherClockWidgetView.this.mUiState = UiState.RESUME_DELAY;
                        WeatherClockWidgetView.this.mBoolAppResume = true;
                        if (WeatherClockWidgetView.this.mWeatherCtrl == null || WeatherClockWidgetView.this.mWeatherView == null) {
                            if (WeatherClockWidgetView.this.mWeatherCtrl == null) {
                                MyLog.e("WHAT_ON_RESUME_DELAY~ mWeatherCtrl is null");
                            }
                            if (WeatherClockWidgetView.this.mWeatherView == null) {
                                MyLog.e("WHAT_ON_RESUME_DELAY~ mWeatherView is null");
                            }
                        } else {
                            boolean bLocEnableChanged = WeatherClockWidgetView.this.mWeatherCtrl.checkLocEnable();
                            if (WeatherClockWidgetView.this.mWeatherCtrl.getState() == LocationCtrl.State.START) {
                                if (WeatherClockWidgetView.this.mWeatherCtrl.checkTempUnit()) {
                                    WeatherClockWidgetView.this.mWeatherListener.onTempUnitChange(WeatherClockWidgetView.this.mWeatherCtrl);
                                }
                                if (WeatherClockWidgetView.this.mWeatherCtrl.updateDataByForeCast() || WeatherClockWidgetView.this.mWeatherView.IsNeedUpdate() || bLocEnableChanged) {
                                    WeatherClockWidgetView.this.mWeatherView.update();
                                }
                                if (WeatherClockWidgetView.this.mWeatherView.isUseWWPAnimation()) {
                                    WeatherClockWidgetView.this.mWeatherView.checkPlayAnimationTime();
                                    if (WeatherClockWidgetView.this.mLongClick) {
                                        WeatherClockWidgetView.this.mLongClick = false;
                                        WeatherClockWidgetView.this.mWeatherView.attach3DObject();
                                    }
                                    WeatherClockWidgetView.this.checkToPlayWWP();
                                }
                                WeatherClockWidgetView.this.mWeatherCtrl.forceUpdateIfNoData();
                            } else {
                                Handler handler2 = new Handler();
                                WeatherClockWidgetView.this.mWeatherCtrl.register(handler2, WeatherClockWidgetView.this.mWeatherListener);
                                WeatherClockWidgetView.this.mWeatherCtrl.checkLocEnable();
                                return false;
                            }
                        }
                        WeatherClockWidgetView.this.sendNonUiMessageDelayed(Constants.WHAT_ON_STATELOG, 3000L);
                        break;
                    case Constants.WHAT_ON_STATELOG /* 36873 */:
                        WeatherClockWidgetView.this.stateToLog();
                        break;
                    case Constants.WHAT_ON_CONFIG_CHANGED /* 36881 */:
                        WeatherClockWidgetView.this.doConfigurationChanged();
                        break;
                    case Constants.WHAT_ON_CLICK_AP1 /* 36882 */:
                        MyUtil.launchWorldClockAp(WeatherClockWidgetView.this.mApplication, WeatherClockWidgetView.this.getCityCode());
                        break;
                    case Constants.WHAT_ON_CLICK_AP2 /* 36883 */:
                        WeatherClockWidgetView.this.launchWeatherClockAp();
                        break;
                    case Constants.WHAT_ON_ACTIVITY_RESULT /* 36884 */:
                        WeatherClockWidgetView.this.doActivityResult((Intent) msg.obj);
                        break;
                    case Constants.WHAT_ON_RESUME_KEYGUARD /* 36885 */:
                        if (WeatherClockWidgetView.this.mClockView != null) {
                            WeatherClockWidgetView.this.mClockView.updateFormat();
                        }
                        if (WeatherClockWidgetView.this.mClockView != null && !WeatherClockWidgetView.this.mPauseByAddToHome) {
                            if (WeatherClockWidgetView.this.mClockView.mUseAnimation) {
                                WeatherClockWidgetView.this.mUiHandler.recall(Constants.MSG_PREPARE_FLIP);
                                Message message = WeatherClockWidgetView.this.mUiHandler.obtainMessage();
                                message.what = Constants.MSG_PREPARE_FLIP;
                                WeatherClockWidgetView.this.mUiHandler.sendDelayed(message, 0L);
                            }
                            if (WeatherClockWidgetView.this.mWeatherView.isUseWWPAnimation()) {
                                WeatherClockWidgetView.this.m_bPlayingWWP = true;
                                break;
                            }
                        }
                        break;
                    case Constants.WHAT_ON_WEATHER_UPDATE /* 37377 */:
                        MyLog.i("WHAT_ON_WEATHER_UPDATE~");
                        WeatherClockWidgetView.this.removeUiMessages(Constants.WHAT_ON_WEATHER_UPDATE);
                        if (WeatherClockWidgetView.this.mWeatherView != null) {
                            WeatherClockWidgetView.this.mWeatherView.update();
                            WeatherClockWidgetView.this.playWWPAtFirstTime();
                            break;
                        } else {
                            MyLog.e("WHAT_ON_WEATHER_UPDATE~ mWeatherView is null");
                            break;
                        }
                    case Constants.WHAT_ON_TEMP_UNIT_CHANGED /* 37378 */:
                        MyLog.i("WHAT_ON_TEMP_UNIT_CHANGED~");
                        if (WeatherClockWidgetView.this.mWeatherView != null) {
                            WeatherClockWidgetView.this.mWeatherView.updateTempUnit();
                            break;
                        } else {
                            MyLog.e("WHAT_ON_TEMP_UNIT_CHANGED~ mWeatherView is null");
                            break;
                        }
                    case Constants.WHAT_ON_CITY_CHANGED /* 37379 */:
                        MyLog.i("WHAT_ON_CITY_CHANGED~");
                        WeatherClockWidgetView.this.removeUiMessages(Constants.WHAT_ON_CITY_CHANGED);
                        if (WeatherClockWidgetView.this.mWeatherView != null) {
                            WeatherClockWidgetView.this.mWeatherView.update();
                            WeatherClockWidgetView.this.mBChangeTimeZone = true;
                            WeatherClockWidgetView.this.sendUiMessageDelayed(Constants.MSG_TIMEZONE_CHANGED, 0L);
                            WeatherClockWidgetView.this.playWWPAtFirstTime();
                            break;
                        } else {
                            MyLog.e("WHAT_ON_CITY_CHANGED~ mWeatherView is null");
                            break;
                        }
                    case Constants.WHAT_ON_TRY_UPDATE_WEATHER /* 37380 */:
                        MyLog.i("WHAT_ON_TRY_UPDATE_WEATHER~");
                        if (WeatherClockWidgetView.this.mWeatherCtrl.getLocState() == LocationCtrl.LocationState.NO_DATA) {
                            WeatherClockWidgetView.this.mWeatherCtrl.updateWeatherData();
                            break;
                        }
                        break;
                    case Constants.WHAT_ON_FORMAT_UPDATE /* 37381 */:
                        if (WeatherClockWidgetView.this.mClockView != null) {
                            WeatherClockWidgetView.this.mClockView.updateFormat();
                            WeatherClockWidgetView.this.mClockView.checkSystemAutoSynTimezone();
                            WeatherClockWidgetView.this.checkClockTimeZone();
                        }
                        if (WeatherClockWidgetView.this.mWeatherCtrl.checkTempUnit()) {
                            WeatherClockWidgetView.this.mWeatherListener.onTempUnitChange(WeatherClockWidgetView.this.mWeatherCtrl);
                        }
                        if (WeatherClockWidgetView.this.mWeatherCtrl.checkLocEnable() && WeatherClockWidgetView.this.mWeatherView != null) {
                            WeatherClockWidgetView.this.mWeatherView.update();
                        }
                        WeatherClockWidgetView.this.sendUiMessageDelayed(Constants.WHAT_TIME_CHANGED, 0L);
                        WeatherClockWidgetView.this.sendUiMessageDelayed(Constants.MSG_FORMAT_UPDATE, 0L);
                        break;
                }
                return true;
            }
        }
    };
    private Handler.Callback mUiWorker = new Handler.Callback() { // from class: com.htc.clock3dwidget.weatherclock.WeatherClockWidgetView.4
        @Override // android.os.Handler.Callback
        public boolean handleMessage(Message msg) {
            if (!WeatherClockWidgetView.this.isWidgetOnResume() && msg.what != 32793 && msg.what != 32800 && msg.what != 32769 && msg.what != 32801) {
                MyLog.w("handleUiMessage~ in pause. msg:" + msg.what);
                return false;
            }
            if (!WeatherClockWidgetView.this.isWidgetDestroy()) {
                if (WeatherClockWidgetView.this.mClockView == null || WeatherClockWidgetView.this.mWeatherView == null) {
                    return false;
                }
                switch (msg.what) {
                    case Constants.MSG_ON_RESUME /* 32769 */:
                        if (WeatherClockWidgetView.this.mBChangeTimeZone) {
                            WeatherClockWidgetView.this.mBChangeTimeZone = false;
                            WeatherClockWidgetView.this.checkClockTimeZone();
                        }
                        if (!WeatherClockWidgetView.this.mClockView.mUseAnimation) {
                            WeatherClockWidgetView.this.mClockView.setPause(!WeatherClockWidgetView.this.mBoolAppResume);
                            break;
                        } else if (msg.arg2 != 1) {
                            WeatherClockWidgetView.this.mClockView.startAnimation();
                            break;
                        } else {
                            MyLog.i("MSG_ON_RESUME~ need to delay");
                            WeatherClockWidgetView.this.sendUiMessageDelayed(Constants.MSG_ON_WOW, 1000L);
                            break;
                        }
                    case Constants.MSG_START_ANIMATION /* 32777 */:
                        WeatherClockWidgetView.this.mWeatherView.uiStartTodayAnimation();
                        break;
                    case Constants.MSG_STOP_ANIMATION /* 32778 */:
                        WeatherClockWidgetView.this.mClockView.clearAnimations();
                        WeatherClockWidgetView.this.mWeatherView.uiStopTodayAnimation();
                        break;
                    case Constants.MSG_START_CLOCK_ANIMATION /* 32780 */:
                        WeatherClockWidgetView.this.mClockView.startAnimation();
                        break;
                    case Constants.MSG_TIMEZONE_CHANGED /* 32786 */:
                        WeatherClockWidgetView.this.mBChangeTimeZone = false;
                        WeatherClockWidgetView.this.checkClockTimeZone();
                        WeatherClockWidgetView.this.mClockView.onTimeChanged();
                        break;
                    case Constants.MSG_PLAY_ANIMATION /* 32787 */:
                        int[] pos = WeatherClockWidgetView.this.getPosition();
                        if (pos != null) {
                            MyLog.i("getPosition(x,y)= (" + pos[0] + "," + pos[1] + ")");
                            WeatherClockWidgetView.this.mWeatherView.setPosition(pos[0], pos[1]);
                        }
                        WeatherClockWidgetView.this.mWeatherView.uiStartWWPAnimation();
                        WeatherClockWidgetView.this.mbPlayWWPAtAdd = false;
                        boolean unused = WeatherClockWidgetView.mbPlayWWPAtRosieStart = false;
                        break;
                    case Constants.MSG_WEATHER_UPDATE /* 32788 */:
                        WeatherClockWidgetView.this.mWeatherView.uiUpdate();
                        break;
                    case Constants.MSG_TEMP_UPDATE /* 32789 */:
                        WeatherClockWidgetView.this.mWeatherView.uiUpdateTempUnit();
                        break;
                    case Constants.MSG_FORMAT_UPDATE /* 32790 */:
                        WeatherClockWidgetView.this.mClockView.onTimeChanged();
                        break;
                    case Constants.MSG_PREPARE_FLIP /* 32793 */:
                        if (WeatherClockWidgetView.this.mClockView != null) {
                            WeatherClockWidgetView.this.mClockView.prepareAnimation();
                            break;
                        }
                        break;
                    case Constants.MSG_ON_WOW /* 32800 */:
                        if (WeatherClockWidgetView.this.mClockView.mUseAnimation) {
                            WeatherClockWidgetView.this.mClockView.startAnimation(!WeatherClockWidgetView.this.mBoolAppResume);
                            break;
                        }
                        break;
                    case Constants.MSG_ON_SWITCH_CUR /* 32801 */:
                        WeatherClockWidgetView.this.switchToNewCity(true, null);
                        break;
                    case Constants.WHAT_TIME_CHANGED /* 36867 */:
                        WeatherClockWidgetView.this.mClockView.onTimeChanged();
                        break;
                }
                return true;
            }
            MyLog.e("weather clock handleMessage~ widget destroied");
            return false;
        }
    };
    private WeatherClock m_floatView = null;
    private long mResumeNotifyCaused = 0;
    private long mLastUnLockTime = 0;
    private long mLastResumeTime = 0;
    private boolean m_bPlayingWWP = false;
    private View.OnLongClickListener mLongClickListener = new View.OnLongClickListener() { // from class: com.htc.clock3dwidget.weatherclock.WeatherClockWidgetView.5
        @Override // android.view.View.OnLongClickListener
        public boolean onLongClick(View v) {
            MyLog.d("weather clock onLongClick~~~");
            WeatherClockWidgetView.this.mLongClick = true;
            if (WeatherClockWidgetView.this.uiView != null) {
                onLongClick(WeatherClockWidgetView.this.uiView);
                return false;
            }
            return false;
        }
    };
    private LocationListener mWeatherListener = new LocationListener() { // from class: com.htc.clock3dwidget.weatherclock.WeatherClockWidgetView.6
        @Override // com.htc.clock.util.location.LocationListener
        public void onCityUpdate(LocationCtrl weatherCtrl) {
            if (!WeatherClockWidgetView.this.mBoolAppDestroy) {
                MyLog.i("onCityUpdate~ mWeatherCtrl.getLocKey():" + WeatherClockWidgetView.this.mWeatherCtrl.getLocKey());
                if (!LocationCtrl.CURRENT_LOCATION_KEY.equals(WeatherClockWidgetView.this.mWeatherCtrl.getLocKey())) {
                    WeatherClockWidgetView.this.sendUiMessageDelayed(Constants.MSG_ON_SWITCH_CUR, 0L);
                } else {
                    WeatherClockWidgetView.this.sendNonUiMessageDelayed(Constants.WHAT_ON_CITY_CHANGED, 0L);
                }
            }
        }

        @Override // com.htc.clock.util.location.LocationListener
        public void onWeatherUpdate(LocationCtrl weatherCtrl) {
            WeatherClockWidgetView.this.sendNonUiMessageDelayed(Constants.WHAT_ON_WEATHER_UPDATE, 0L);
        }

        @Override // com.htc.clock.util.location.LocationListener
        public void onTempUnitChange(LocationCtrl weatherCtrl) {
            WeatherClockWidgetView.this.sendNonUiMessageDelayed(Constants.WHAT_ON_TEMP_UNIT_CHANGED, 0L);
        }

        @Override // com.htc.clock.util.location.LocationListener
        public boolean isChinaLocationService() {
            return MyProjectSetting.isChinaLocationService();
        }

        @Override // com.htc.clock.util.location.LocationListener
        public boolean isHelpTurnOnLoc() {
            return true;
        }

        @Override // com.htc.clock.util.location.LocationListener
        public boolean isResume() {
            return WeatherClockWidgetView.this.mBoolAppResume;
        }
    };
    private DbChangeObserver mFormatChangeObserver = null;
    private DbChangeObserver mSecureChangeObserver = null;

    public enum UiState {
        NONE,
        RESUME,
        RESUME_DELAY,
        PAUSED
    }

    public void onCreate(Bundle saved) {
        super.onCreate(saved);
        this.mScenePort = getHost().createScene(ClockUtils.getClockPath(ClockUtils.ClockType.CLOCK_WEATHER, true), true);
        this.mSceneLand = !ClockUtils.SUPPORT_LAND ? this.mScenePort : getHost().createScene(ClockUtils.getClockPath(ClockUtils.ClockType.CLOCK_WEATHER, false), true);
        this.mResContext = getContext();
        this.mApplication = getHost().getContext();
        this.mOrientation = this.mApplication.getResources().getConfiguration().orientation;
    }

    protected void onPostCreate(Bundle savedState) {
        super.onPostCreate(savedState);
        this.mHandler = getHost().getWorker(this.mWorker);
        this.mUiHandler = getHost().getWorker(this.mUiWorker);
        this.mViewContext = this.mResContext;
        this.mBackIntent = getIntent();
        this.mBoolAppDestroy = false;
        this.mLongClick = false;
        this.mWeatherCtrl = new LocationCtrl(this.mResContext);
        this.mWeatherView = new WeatherClock(this.mResContext, this, getHost());
        this.mFxControlsPort = new FxWeatherControls(this.mScenePort);
        this.mFxControlsLand = !ClockUtils.SUPPORT_LAND ? this.mFxControlsPort : new FxWeatherControls(this.mSceneLand);
        this.mWeatherView.bind(this.mFxControlsPort, this.mFxControlsLand);
        this.mWeatherView.init(this.mOrientation == 1 ? this.mFxControlsPort : this.mFxControlsLand);
        this.mWeatherView.init();
        this.mWeatherView.setOnWeatherClickListener(this.mWeatherClockClick);
        String defaultCurName = this.mResContext.getResources().getString(R.string.current_location);
        LocationUtil.setDefaultLocName(defaultCurName);
        initClock();
        this.mBoolAppResume = true;
        registerIntentReceivers();
        this.mHandler.send(Constants.WHAT_ON_INIT);
        this.mWeatherView.checkPlayAnimationTime();
        MyLog.i("WeatherClock onPostCreate ~ mInitResume = " + this.mInitResume);
        synchronized (this.mInitLock) {
            if (this.mInitResume) {
                doResume();
            }
            if (this.mInitPause) {
                doPause();
            }
            this.mInitCreate = true;
        }
    }

    public void onResume() {
        super.onResume();
        MyLog.i("WeatherClock onResume ~ mInitCreate = " + this.mInitCreate);
        synchronized (this.mInitLock) {
            if (this.mInitCreate) {
                doResume();
            }
            this.mInitResume = true;
        }
    }

    private void doResume() {
        removeResumeMessage();
        Message msg = this.mHandler.obtainMessage();
        msg.what = 1;
        msg.arg1 = 30;
        this.mHandler.send(msg);
    }

    private void removeResumeMessage() {
        if (this.mHandler.hasMessage(Constants.WHAT_ON_RESUME_DELAY)) {
            this.mHandler.recall(Constants.WHAT_ON_RESUME_DELAY);
        }
        if (this.mHandler.hasMessage(1)) {
            this.mHandler.recall(1);
        }
    }

    private void removePauseMessage() {
        if (this.mHandler.hasMessage(2)) {
            this.mHandler.recall(2);
        }
    }

    public void onPause() {
        super.onPause();
        synchronized (this.mInitLock) {
            if (this.mInitCreate) {
                doPause();
            }
            this.mInitPause = true;
        }
    }

    private void doPause() {
        removePauseMessage();
        Message msg = this.mHandler.obtainMessage();
        msg.what = 2;
        msg.arg1 = 30;
        this.mHandler.send(msg);
    }

    protected boolean isSharingHandlerThread() {
        return false;
    }

    public String getSettingIntent() {
        Intent intent = new Intent(Constants.ACTION_INTENT_SETTING);
        intent.setClassName(Constants.SETTING_PACKAGE, Constants.SETTING_CLASS);
        intent.putExtra(Constants.WIDGET_TYPE, 3);
        boolean wwpPlay = true;
        if (this.mWeatherView != null) {
            wwpPlay = this.mWeatherView.isUseWWPAnimation();
        }
        intent.putExtra(Constants.WWP_PLAY, wwpPlay);
        return intent.toUri(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void launchWeatherClockAp() {
        if (MyProjectSetting.hasWeatherAp() && this.mWeatherCtrl != null) {
            if (!this.mWeatherCtrl.isLocServiceEnable() && this.mWeatherCtrl.isCurrentLocation()) {
                launchLocSetting();
            } else if (this.mWeatherCtrl.getLocState() != LocationCtrl.LocationState.NO_DATA) {
                launchWeatherAp();
            } else if (!this.mWeatherCtrl.isLocServiceAvailable()) {
                launchResetCityActivity();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String getCityCode() {
        try {
            String cityCode = this.mWeatherCtrl.getWeatherLocation().getCode();
            return cityCode;
        } catch (Exception e) {
            MyLog.i("get city code fail");
            return null;
        }
    }

    private void launchWeatherAp() {
        Intent intent = new Intent(Constants.ACTION_INTENT_LOCATE);
        if (intent != null) {
            intent.setClassName(Constants.WEATHER_PACKAGENAME, Constants.LAUNCHAP_CLASSNAME);
            WeatherLocation weatherLoc = this.mWeatherCtrl.getWeatherLocation();
            if (weatherLoc != null) {
                String cityName = LocationCtrl.getWeatheApCityName(weatherLoc);
                intent.putExtra("name_", cityName);
                intent.putExtra(Constants.KEY_SELECT_CITY_CODE, weatherLoc.getCode());
                intent.putExtra("app_", weatherLoc.getApp());
                MyLog.i("launchWeatherAp~ name_:" + cityName);
                MyLog.i("launchWeatherAp~ code_:" + weatherLoc.getCode());
                MyLog.i("launchWeatherAp~ app_:" + weatherLoc.getApp());
            }
            if (!this.mWeatherCtrl.isCurrentLocation()) {
                WeatherLocation[] locs = WeatherUtility.loadLocations(this.mViewContext.getContentResolver(), Constants.WEATHER_PROVIDER_KEYNAME);
                boolean inList = false;
                int len$ = locs.length;
                int i$ = 0;
                while (true) {
                    if (i$ >= len$) {
                        break;
                    }
                    WeatherLocation l = locs[i$];
                    if (!l.getCode().equals(weatherLoc.getCode())) {
                        i$++;
                    } else {
                        inList = true;
                        break;
                    }
                }
                MyLog.i("launchWeatherAp~ inList:" + inList);
                if (!inList && locs.length < 15) {
                    WeatherUtility.addLocation(this.mViewContext.getContentResolver(), Constants.WEATHER_PROVIDER_KEYNAME, new WeatherLocation[]{weatherLoc});
                    MyLog.i("launchWeatherAp~ add loc:" + weatherLoc.getCode());
                }
            }
            intent.addFlags(268435456);
            intent.addFlags(67108864);
            try {
                this.mApplication.startActivity(intent);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(this.mViewContext, "Activity is not ready to execute", 0).show();
            }
        }
    }

    public int getNotifyType() {
        return 50;
    }

    public void onTiltChanged(float tilt) {
        super.onTiltChanged(tilt);
        if (!this.mBoolAppDestroy && this.mWeatherView != null) {
            this.mWeatherView.doTiltChanged(tilt);
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == -1) {
            Message msg = this.mHandler.obtainMessage();
            msg.what = Constants.WHAT_ON_ACTIVITY_RESULT;
            msg.obj = data;
            sendNonUiMessageDelayed(msg, 0L);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doActivityResult(Intent data) {
        if (data != null) {
            boolean bCurLocation = data.getBooleanExtra("currentLocation", false);
            this.mbPlayWWPAtAdd = true;
            switchToNewCity(bCurLocation, data);
            savePropertyData(data);
        }
    }

    private void savePropertyData(Intent intent) {
        if (intent != null) {
            boolean bCurLocation = intent.getBooleanExtra("currentLocation", true);
            boolean bPlayWWP = intent.getBooleanExtra(Constants.WWP_PLAY, true);
            this.mWeatherView.setPlayWWP(bPlayWWP);
            MyLog.i("initData~ from intent bCurLocation:" + bCurLocation);
            if (!bCurLocation) {
                WeatherLocation loc = getLocationFromIntent(intent);
                this.mWeatherCtrl.addLoc(loc);
                this.mWeatherCtrl.setLocKey(loc.getCode());
                saveInitProps(loc, bPlayWWP);
                return;
            }
            this.mWeatherCtrl.addCurLoc();
            this.mWeatherCtrl.setLocKey(LocationCtrl.CURRENT_LOCATION_KEY);
            saveInitProps(null, bPlayWWP);
        }
    }

    protected void onHostMessage(Message msg) {
        super.onHostMessage(msg);
        switch (msg.what) {
            case 3:
                sendNonUiMessageDelayed(Constants.WHAT_ON_CONFIG_CHANGED, 0L);
                break;
            case 4:
                if (this.mWeatherView != null && (msg.arg1 & 1) != 0) {
                    int x = getPositionX(msg.arg2);
                    int y = getPositionY(msg.arg2);
                    MyLog.i("HOST_RESUME_IN_KEYGUARD(x,y)=(" + x + "," + y + ")");
                    this.mWeatherView.setPosition(x, y);
                    break;
                }
                break;
            case Constants.WIDGET_TYPE_DIGITALCLOCK /* 5 */:
                MyLog.i("HOST_USER_PRESENT,arg1= " + msg.arg1 + ", mUiState=" + this.mUiState);
                if ((msg.arg1 & 1) != 0) {
                    if (this.mUiState == UiState.PAUSED || this.mUiState == UiState.NONE) {
                        doResumeInKeyguard();
                        break;
                    }
                }
                break;
        }
    }

    private void doResumeInKeyguard() {
        Message msg = this.mHandler.obtainMessage();
        msg.what = Constants.WHAT_ON_RESUME_KEYGUARD;
        this.mHandler.send(msg);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void switchToNewCity(boolean bCurLocation, Intent data) {
        synchronized (this) {
            if (!this.mBoolAppDestroy) {
                if (data != null) {
                    boolean bPlayWWP = data.getBooleanExtra(Constants.WWP_PLAY, true);
                    this.mWeatherView.setPlayWWP(bPlayWWP);
                }
                if (this.mWeatherCtrl != null) {
                    this.mWeatherCtrl.unRegister();
                }
                this.mWeatherCtrl = new LocationCtrl(this.mResContext);
                if (!bCurLocation) {
                    WeatherLocation loc = getLocationFromIntent(data);
                    this.mWeatherCtrl.addLoc(loc);
                    this.mWeatherCtrl.setLocKey(loc.getCode());
                    MyLog.i("onActivityResult~ loc:" + loc.getCode());
                } else {
                    this.mWeatherCtrl.addCurLoc();
                    this.mWeatherCtrl.setLocKey(LocationCtrl.CURRENT_LOCATION_KEY);
                }
                if (this.mWeatherCtrl.getState() != LocationCtrl.State.START) {
                    Handler handler = new Handler();
                    this.mWeatherCtrl.register(handler, this.mWeatherListener);
                    this.mWeatherCtrl.checkLocEnable();
                }
                testWeatherCtrl();
                sendNonUiMessageDelayed(Constants.WHAT_ON_CITY_CHANGED, 0L);
            }
        }
    }

    public void testWeatherCtrl() {
        MyLog.i("testWeatherCtrl~ getLocCode:" + this.mWeatherCtrl.getLocCode());
        MyLog.i("testWeatherCtrl~ getLocName:" + this.mWeatherCtrl.getLocName());
        MyLog.i("testWeatherCtrl~ getLocConditionIdInt:" + this.mWeatherCtrl.getLocConditionIdInt());
        MyLog.i("testWeatherCtrl~ getState:" + this.mWeatherCtrl.getState());
    }

    public void onDestroy() {
        this.mBoolAppDestroy = true;
        MyLog.i("weather clock onActivityDestroy~");
        removeMessages();
        try {
            clear();
        } catch (Exception e) {
        }
        super.onDestroy();
    }

    public void updateScrollCache() {
    }

    private void removeMessages() {
        removeNonUiMessages(1);
        removeNonUiMessages(Constants.WHAT_ON_RESUME_DELAY);
        removeNonUiMessages(Constants.WHAT_ON_STATELOG);
        removeNonUiMessages(2);
        removeNonUiMessages(Constants.WHAT_ON_INIT);
        removeNonUiMessages(Constants.WHAT_ON_TEMP_UNIT_CHANGED);
        removeNonUiMessages(Constants.WHAT_ON_WEATHER_UPDATE);
        removeNonUiMessages(Constants.WHAT_ON_CITY_CHANGED);
        removeNonUiMessages(4);
        removeNonUiMessages(Constants.WHAT_ON_TRY_UPDATE_WEATHER);
        removeNonUiMessages(Constants.WHAT_ON_FORMAT_UPDATE);
        removeNonUiMessages(Constants.WHAT_ON_CONFIG_CHANGED);
        removeNonUiMessages(Constants.WHAT_ON_CLICK_AP1);
        removeNonUiMessages(Constants.WHAT_ON_CLICK_AP2);
        removeNonUiMessages(Constants.WHAT_ON_ACTIVITY_RESULT);
        removeUiMessages(Constants.WHAT_TIME_CHANGED);
        removeUiMessages(Constants.MSG_FORMAT_UPDATE);
        removeUiMessages(Constants.MSG_START_ANIMATION);
        removeUiMessages(Constants.MSG_STOP_ANIMATION);
        removeUiMessages(Constants.MSG_ON_RESUME);
        removeUiMessages(Constants.MSG_ON_WOW);
        removeUiMessages(Constants.MSG_PREPARE_FLIP);
        removeUiMessages(Constants.MSG_WEATHER_UPDATE);
        removeUiMessages(Constants.MSG_TEMP_UPDATE);
        removeUiMessages(Constants.MSG_START_CLOCK_ANIMATION);
        removeUiMessages(Constants.MSG_PLAY_ANIMATION);
        removeUiMessages(Constants.MSG_TIMEZONE_CHANGED);
        removeUiMessages(Constants.MSG_ON_SWITCH_CUR);
    }

    private void clear() {
        synchronized (this) {
            MyLog.i("weather clock clear~");
            unInitReceiver();
            if (this.mWeatherView != null) {
                this.mWeatherView.unbind(this.mFxControlsPort, this.mFxControlsLand);
                this.mWeatherView.deInit();
            }
            if (this.mWeatherCtrl != null) {
                this.mWeatherCtrl.unRegister();
            }
        }
    }

    private void correctResourcesLocale() {
        Resources res = Resources.getSystem();
        if (res == null) {
            MyLog.w("Resources.getSystem() is null");
            return;
        }
        String resISO3Language = res.getConfiguration().locale.getISO3Language();
        Configuration config = res.getConfiguration();
        if (config == null) {
            MyLog.w("res.getConfiguration() is null");
            return;
        }
        String currentISO3Language = Locale.getDefault().getISO3Language();
        if (!TextUtils.isEmpty(resISO3Language) && !TextUtils.isEmpty(currentISO3Language) && !resISO3Language.equals(currentISO3Language)) {
            config.locale = Locale.getDefault();
            Resources.updateSystemConfiguration(config, null);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void initData() {
        MyLog.i("initData~");
        correctResourcesLocale();
        Properties props = loadInstanceData();
        if (props == null) {
            this.mbPlayWWPAtAdd = true;
            savePropertyData(this.mBackIntent);
        } else {
            loadPropertyData(props);
        }
        this.mWeatherView.initAnimation();
        initReceiver();
        this.mClockView.updateFormat();
        this.mClockView.checkSystemAutoSynTimezone();
        checkClockTimeZone();
    }

    private void loadPropertyData(Properties props) {
        boolean bCurLocation = false;
        boolean bPlayWWP = false;
        String code = null;
        if (MyProjectSetting.hasWeatherWallpaper()) {
            bPlayWWP = true;
        }
        if (MyProjectSetting.hasCurrentLocation()) {
            bCurLocation = true;
        }
        try {
            bCurLocation = Boolean.parseBoolean(props.getProperty("isCurLocation"));
            bPlayWWP = Boolean.parseBoolean(props.getProperty(Constants.WWP_PLAY));
            if (!bCurLocation) {
                code = props.getProperty(Constants.KEY_SELECT_CITY_CODE);
            }
        } catch (Exception e) {
            MyLog.e("initData~ get isCurLocation property error:" + e.getMessage());
        }
        MyLog.i("initData~ from prop bCurLocation:" + bCurLocation);
        if (!bCurLocation && code != null) {
            MyLog.d("Code:" + code);
            WeatherLocation loc = getLocationFromCode(code);
            if (loc == null) {
                loc = new WeatherLocation();
                loc.setCode(code);
                loc.setName(props.getProperty("name_"));
                loc.setState(props.getProperty("state_"));
                loc.setCountry(props.getProperty("country_"));
                loc.setTimezoneId(props.getProperty("timezone_"));
                loc.setApp(props.getProperty("app_"));
                loc.setLatitude(props.getProperty("latitude_"));
                loc.setLongitude(props.getProperty("longitude_"));
            }
            this.mWeatherCtrl.addLoc(loc);
            this.mWeatherCtrl.setLocKey(loc.getCode());
        } else {
            String defCityCode = null;
            if (props != null) {
                defCityCode = props.getProperty(DEF_CITY);
            }
            MyLog.i("initData~ defCityCode:" + defCityCode);
            if (!TextUtils.isEmpty(defCityCode)) {
                WeatherLocation loc2 = getLocationFromCode(defCityCode);
                this.mWeatherCtrl.addLoc(loc2);
                this.mWeatherCtrl.addCurLoc();
                this.mWeatherCtrl.setLocKey(loc2.getCode());
            } else {
                this.mWeatherCtrl.addCurLoc();
                this.mWeatherCtrl.setLocKey(LocationCtrl.CURRENT_LOCATION_KEY);
            }
        }
        this.mWeatherView.setPlayWWP(bPlayWWP);
    }

    private WeatherLocation getLocationFromIntent(Intent intent) {
        WeatherLocation loc = new WeatherLocation();
        String code = intent.getStringExtra(Constants.KEY_SELECT_CITY_CODE);
        MyLog.d("Code:" + code);
        loc.setCode(code);
        loc.setName(intent.getStringExtra("name_"));
        loc.setTimezoneId(intent.getStringExtra("timezone_"));
        loc.setState(intent.getStringExtra("state_"));
        loc.setCountry(intent.getStringExtra("country_"));
        loc.setApp(intent.getStringExtra("app_"));
        loc.setLatitude(intent.getStringExtra("latitude_"));
        loc.setLongitude(intent.getStringExtra("longitude_"));
        return loc;
    }

    private WeatherLocation getLocationFromCode(String code) {
        WeatherLocation loc = null;
        Cursor locationListCursor = WeatherUtility.getLocationListByCode(this.mApplication.getContentResolver(), code);
        if (locationListCursor != null) {
            if (locationListCursor.getCount() > 0 && locationListCursor.moveToFirst()) {
                loc = WeatherUtility.CursorToWeatherLocation(locationListCursor);
            }
            locationListCursor.close();
        }
        return loc;
    }

    private void initClock() {
        String timezone = null;
        if (this.mBackIntent != null) {
            Boolean isCurrentLocation = Boolean.valueOf(this.mBackIntent.getBooleanExtra("currentLocation", false));
            if (!isCurrentLocation.booleanValue()) {
                timezone = this.mBackIntent.getStringExtra("timezone_");
            }
        }
        initClock(timezone);
    }

    private void initClock(String timezone) {
        MyLog.i("initClock~ timezone:" + timezone);
        this.mClockView = this.mWeatherView;
        if (this.mClockView != null) {
            this.mClockView.setTimeZone(timezone);
            this.mClockView.onTimeChanged(false);
            this.mClockView.setOnClockClickListener(this.mClockClickListener);
            return;
        }
        MyLog.e("initClock~ mClockView is null");
    }

    private void saveInitProps(WeatherLocation weatherLoc, boolean bPlayWWP) {
        try {
            Properties props = new Properties();
            props.setProperty(Constants.WWP_PLAY, Boolean.toString(bPlayWWP));
            if (weatherLoc != null && weatherLoc.getName() != null && weatherLoc.getName().length() > 0) {
                props.setProperty("name_", weatherLoc.getName());
                props.setProperty("state_", weatherLoc.getState());
                props.setProperty("country_", weatherLoc.getCountry());
                props.setProperty(Constants.KEY_SELECT_CITY_CODE, weatherLoc.getCode());
                props.setProperty("latitude_", weatherLoc.getLatitude());
                props.setProperty("longitude_", weatherLoc.getLongitude());
                props.setProperty("app_", weatherLoc.getApp());
                props.setProperty("timezone_", weatherLoc.getTimezoneId());
                props.setProperty("isCurLocation", Boolean.toString(false));
            } else {
                props.setProperty("isCurLocation", Boolean.toString(true));
            }
            try {
                storeInstanceData(props);
            } catch (SQLiteFullException e) {
                e.printStackTrace();
            }
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    public void onNotifyWidgetPause(int notifyCause) {
        MyLog.i("onNotifyWidgetPause notifyCause:" + notifyCause);
        if (!isWidgetDestroy()) {
            removeNonUiMessages(Constants.WHAT_ON_RESUME_DELAY);
            removeUiMessages(Constants.MSG_START_ANIMATION);
            removeUiMessages(Constants.MSG_PLAY_ANIMATION);
            removeUiMessages(Constants.MSG_ON_RESUME);
            if (this.mClockView == null || notifyCause == 20) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void myOnNotifyWidgetPause(int notifyCause) {
        if (!isWidgetDestroy()) {
            MyLog.d("myOnNotifyWidgetPause:" + notifyCause);
            if (notifyCause == 40) {
                this.mPauseByAddToHome = true;
            } else {
                this.mPauseByAddToHome = false;
            }
            this.mUiState = UiState.PAUSED;
            this.mBoolAppResume = false;
            this.mbPlayWWPAtAdd = false;
            mbPlayWWPAtRosieStart = false;
            removeNonUiMessages(Constants.WHAT_ON_RESUME_DELAY);
            removeNonUiMessages(Constants.WHAT_ON_STATELOG);
            removeUiMessages(Constants.MSG_START_ANIMATION);
            removeUiMessages(Constants.MSG_PLAY_ANIMATION);
            removeUiMessages(Constants.MSG_ON_RESUME);
            if (this.mClockView != null) {
                this.mClockView.setPause(true);
            } else {
                MyLog.e("onNotifyWidgetPause~ mClockView is null");
            }
            if (this.mWeatherView != null) {
                this.mWeatherView.uiStopTodayAnimation();
                this.mWeatherView.setNeedPlayWeatherWallpaper(false);
                this.mWeatherView.onPause();
                if (this.mWeatherView.isUseWWPAnimation() && this.mLongClick) {
                    this.mWeatherView.detach3DObject();
                    return;
                }
                return;
            }
            MyLog.e("onNotifyWidgetPause~ mWeatherView is null");
        }
    }

    private void registerIntentReceivers() {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void stateToLog() {
        if (MyLog.IsDebugLog()) {
            StringBuffer log = new StringBuffer();
            if (this.mWeatherCtrl != null) {
                LocationCtrl.LocationState locState = this.mWeatherCtrl.getLocState();
                LocationCtrl.State state = this.mWeatherCtrl.getState();
                log.append("stateToLog~ state:").append(state).append("\n");
                log.append("stateToLog~ locState:").append(locState).append("\n");
                if (LocationCtrl.LocationState.ONLY_LOC.equals(locState) || LocationCtrl.LocationState.OK.equals(locState)) {
                    log.append("stateToLog~ weather update time:").append(this.mWeatherCtrl.getLastUpdateTime()).append(" ");
                    log.append("stateToLog~ weather locCode:").append(this.mWeatherCtrl.getLocCode()).append(" ");
                    log.append("locName:").append(this.mWeatherCtrl.getLocName()).append(" ");
                    log.append("(lat,lng):(").append(this.mWeatherCtrl.getWeatherLocation().getLatitude()).append(",");
                    log.append(this.mWeatherCtrl.getWeatherLocation().getLongitude()).append(") ");
                    log.append("stateToLog~ LocConditionId:").append(this.mWeatherCtrl.getLocConditionId()).append("\n");
                }
            }
            if (this.mClockView != null) {
                TimeZone tz = this.mClockView.getTimeZone();
                log.append("stateToLog~ listen timezone changed:").append(this.mClockView.getListenTimeZoneChanged()).append(" mReceiverRegistered:" + this.mClockView.mReceiverRegistered);
                if (tz != null) {
                    log.append(" used timezone:").append(tz.getID());
                } else {
                    log.append(" tz null");
                }
            }
            log.append("\n---start last weather receive log---\n");
            log.append("mBOnReceiveWeatherData:").append(this.mWeatherCtrl.mBOnReceiveWeatherData);
            log.append(" ").append(this.mWeatherCtrl.mSOnReceiveLog.toString());
            log.append("\n---end last weather receive log---");
            if (log.length() > 0) {
                MyLog.i(log.toString());
            }
        }
    }

    protected void sendUiMessageDelayed(int what, long delayMillis, int arg1, int arg2) {
        if (this.mUiHandler != null) {
            Message msg = this.mUiHandler.obtainMessage();
            msg.what = what;
            msg.arg1 = arg1;
            msg.arg2 = arg2;
            if (delayMillis > 0) {
                this.mUiHandler.sendDelayed(msg, delayMillis);
            } else {
                this.mUiHandler.send(msg);
            }
        }
    }

    protected void sendUiMessageDelayed(int what, long delayMillis) {
        if (this.mUiHandler != null) {
            if (delayMillis > 0) {
                this.mUiHandler.sendDelayed(what, delayMillis);
            } else {
                this.mUiHandler.send(what);
            }
        }
    }

    protected void removeUiMessages(int what) {
        if (this.mUiHandler != null) {
            this.mUiHandler.recall(what);
        }
    }

    private boolean hasNonUiMessage(int what) {
        if (this.mHandler != null) {
            return this.mHandler.hasMessage(what);
        }
        return false;
    }

    protected void sendNonUiMessageDelayed(int what, long delayMillis) {
        if (this.mHandler != null) {
            if (delayMillis > 0) {
                this.mHandler.sendDelayed(what, delayMillis);
            } else {
                this.mHandler.send(what);
            }
        }
    }

    protected void sendNonUiMessageDelayed(Message msg, long delayMillis) {
        if (this.mHandler != null) {
            if (delayMillis > 0) {
                this.mHandler.sendDelayed(msg, delayMillis);
            } else {
                this.mHandler.send(msg);
            }
        }
    }

    protected void removeNonUiMessages(int what) {
        if (this.mHandler != null) {
            this.mHandler.recall(what);
        }
    }

    public LocationCtrl getWeatherCtrl() {
        return this.mWeatherCtrl;
    }

    public boolean isAttach3DObject() {
        MyLog.i("isAttach3DObject");
        if (this.mWeatherView != null) {
            return this.mWeatherView.isUseWWPAnimation();
        }
        return false;
    }

    public boolean isWidgetOnResume() {
        return !this.mBoolAppDestroy && this.mBoolAppResume;
    }

    public boolean isWidgetDestroy() {
        return this.mBoolAppDestroy;
    }

    private void initReceiver() {
        registerFormatObserver();
    }

    private void unInitReceiver() {
        synchronized (this.mLock) {
            if (this.mLockScreenRec != null) {
                this.mResContext.unregisterReceiver(this.mLockScreenRec);
                this.mLockScreenRec = null;
            }
            if (this.mContentResolver != null) {
                if (this.mFormatChangeObserver != null) {
                    this.mContentResolver.unregisterContentObserver(this.mFormatChangeObserver);
                    this.mFormatChangeObserver = null;
                }
                if (this.mSecureChangeObserver != null) {
                    this.mContentResolver.unregisterContentObserver(this.mSecureChangeObserver);
                    this.mSecureChangeObserver = null;
                }
                this.mContentResolver = null;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean checkToPlayWWP() {
        if (!isWidgetOnResume() || this.mResumeNotifyCaused != 30 || this.mUiState != UiState.RESUME_DELAY) {
            MyLog.i("checkToPlayWWP~ isWidgetOnResume:" + isWidgetOnResume() + " mResumeNotifyCaused:" + this.mResumeNotifyCaused + " mUiState:" + this.mUiState);
            return false;
        }
        long needDelayTime = 1300;
        if (this.mClockView != null && !this.mClockView.mUseAnimation) {
            needDelayTime = 600;
        }
        if (this.m_bPlayingWWP) {
            long delayTime = needDelayTime - (SystemClock.elapsedRealtime() - this.mLastResumeTime);
            if (delayTime > needDelayTime) {
                delayTime = needDelayTime;
            } else if (delayTime < 0) {
                delayTime = 0;
            }
            MyLog.i("checkToPlayWWP~ delayTime:" + delayTime);
            this.mWeatherView.startWWPAnimation(0L);
            this.m_bPlayingWWP = false;
        }
        return false;
    }

    public void checkClockTimeZone() {
        if (this.mWeatherCtrl != null && this.mClockView != null) {
            String timezoneId = this.mWeatherCtrl.getTimeZoneId();
            MyLog.i("checkClockTimeZone~ timezoneId:" + timezoneId);
            MyLog.i("checkClockTimeZone~ isTimezoneAutoSyn:" + this.mClockView.isTimezoneAutoSyn());
            if (!this.mWeatherCtrl.isCurrentLocation()) {
                this.mClockView.setListenTimeZoneChanged(false);
                this.mClockView.setTimeZone(timezoneId);
                return;
            }
            if (this.mClockView.isTimezoneAutoSyn()) {
                this.mClockView.setListenTimeZoneChanged(true);
                this.mClockView.setTimeZone(null);
                return;
            }
            boolean locEnable = this.mWeatherCtrl.isLocServiceEnable();
            if (this.mWeatherCtrl.getLocState() == LocationCtrl.LocationState.NO_DATA || timezoneId == null || timezoneId.length() <= 0 || !locEnable) {
                this.mClockView.setListenTimeZoneChanged(true);
                this.mClockView.setTimeZone(null);
            } else {
                this.mClockView.setListenTimeZoneChanged(false);
                this.mClockView.setTimeZone(timezoneId);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void playWWPAtFirstTime() {
        if (mbPlayWWPAtRosieStart) {
            this.mWeatherView.startWWPAnimation(0L);
        } else if (this.mbPlayWWPAtAdd) {
            this.mWeatherView.startWWPAnimation(0L);
        }
    }

    private void registerFormatObserver() {
        synchronized (this.mLock) {
            if (this.mContentResolver == null) {
                this.mContentResolver = this.mResContext.getContentResolver();
            }
            Handler handler = new Handler();
            if (this.mFormatChangeObserver == null) {
                this.mFormatChangeObserver = new DbChangeObserver(handler);
                this.mContentResolver.registerContentObserver(Settings.System.CONTENT_URI, true, this.mFormatChangeObserver);
            }
            if (this.mSecureChangeObserver == null) {
                this.mSecureChangeObserver = new DbChangeObserver(handler);
                this.mContentResolver.registerContentObserver(Settings.Secure.CONTENT_URI, true, this.mSecureChangeObserver);
            }
        }
    }

    private class DbChangeObserver extends ContentObserver {
        public DbChangeObserver(Handler hander) {
            super(hander);
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean selfChange) {
            WeatherClockWidgetView.this.onSettingChanged();
        }
    }

    public synchronized void onSettingChanged() {
        if (!this.mBoolAppDestroy) {
            MyLog.i("onSettingChanged");
            this.mHandler.recall(Constants.WHAT_ON_FORMAT_UPDATE);
            sendNonUiMessageDelayed(Constants.WHAT_ON_FORMAT_UPDATE, 3000L);
        }
    }

    public void buildCache() {
    }

    public void launchResetCityActivity() {
        try {
            Intent intent = Intent.parseUri(getSettingIntent(), 0);
            intent.putExtra(Constants.WIDGET_RESET, true);
            startActivityForResult(intent, this.mWidgetId);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }

    private void startLocSettingActivity() {
        try {
            Intent intent = new Intent("android.settings.LOCATION_SOURCE_SETTINGS");
            intent.setFlags(276824064);
            this.mApplication.startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [com.htc.clock3dwidget.weatherclock.WeatherClockWidgetView$7] */
    public void launchLocSetting() {
        startLocSettingActivity();
        new Thread() { // from class: com.htc.clock3dwidget.weatherclock.WeatherClockWidgetView.7
            @Override // java.lang.Thread, java.lang.Runnable
            public void run() {
                Settings.Secure.setLocationProviderEnabled(WeatherClockWidgetView.this.mResContext.getContentResolver(), "network", true);
            }
        }.start();
    }

    public void skinApply() {
    }

    public boolean isEditable() {
        return true;
    }

    public void onEdit() {
        try {
            Intent intent = Intent.parseUri(getSettingIntent(), 0);
            startActivityForResult(intent, 0);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }

    protected FxScene getScene(int orientation) {
        return orientation == 1 ? this.mScenePort : this.mSceneLand;
    }

    protected FxScene getScene() {
        return this.mOrientation == 1 ? this.mScenePort : this.mSceneLand;
    }

    public void onConfigurationChanged(Configuration newConfiguration) {
        super.onConfigurationChanged(newConfiguration);
        this.mOrientation = newConfiguration.orientation;
        if (hasNonUiMessage(Constants.WHAT_ON_CONFIG_CHANGED)) {
            removeNonUiMessages(Constants.WHAT_ON_CONFIG_CHANGED);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doConfigurationChanged() {
        if (this.mFxControlsPort != null && this.mFxControlsLand != null && this.mWeatherView != null) {
            this.mWeatherView.init(this.mOrientation == 1 ? this.mFxControlsPort : this.mFxControlsLand);
            this.mWeatherView.mPreviousResId = -1;
            sendUiMessageDelayed(Constants.MSG_ON_WOW, 0L);
            this.mWeatherView.update();
        }
    }
}
