package com.htc.clock3dwidget.socialclock;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import com.htc.android.rosie.widget.Widget;
import com.htc.clock.util.MyLog;
import com.htc.clock.util.social.SocialData;
import com.htc.clock.util.social.SocialNetworkCtrl;
import com.htc.clock.util.social.SocialNetworkUtil;
import com.htc.clock3dwidget.ClockUtils;
import com.htc.clock3dwidget.analogclock.AnalogClockWidget;
import com.htc.clock3dwidget.util.Constants;
import com.htc.fusion.fx.FxScene;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class SocialWidget {
    public static final int WHAT_ON_INIT = 9001;
    public static final int WHAT_ON_RESUME_DELAY = 9002;
    public static final int WHAT_UI_UPDATE = 9101;
    private Context mApplication;
    private FxSocialControls mFxControlsLand;
    private FxSocialControls mFxControlsPort;
    private Widget.Host.Worker mHandler;
    private Widget.Host mHost;
    private AnalogClockWidget.InstanceCallback mInstanceCallback;
    private int mOrientation;
    private Context mResContext;
    private FxScene mSceneLand;
    private FxScene mScenePort;
    private SocialData mSocialData;
    private SocialView mSocialView;
    private Widget.Host.Worker mUiHandler;
    private boolean mBoolAppDestroy = false;
    private boolean mResume = false;
    private SocialNetworkCtrl mCtrl = new SocialNetworkCtrl();
    private boolean mNeedToUpdate = true;
    private boolean mIsLoggedIn = false;
    private View.OnClickListener mSocialClick = new View.OnClickListener() { // from class: com.htc.clock3dwidget.socialclock.SocialWidget.1
        @Override // android.view.View.OnClickListener
        public void onClick(View arg0) {
            SocialWidget.this.mHandler.send(Constants.WHAT_ON_CLICK_AP1);
        }
    };
    private Handler.Callback mWorker = new Handler.Callback() { // from class: com.htc.clock3dwidget.socialclock.SocialWidget.2
        @Override // android.os.Handler.Callback
        public boolean handleMessage(Message msg) {
            if (!SocialWidget.this.isWidgetDestroy()) {
                switch (msg.what) {
                    case 1:
                        SocialWidget.this.mUiHandler.recall(Constants.MSG_PREPARE_FLIP);
                        int notifyCause = msg.arg1;
                        MyLog.d("SocialNetworkWidget WHAT_ON_RESUME~ notifyCause:" + notifyCause);
                        SocialWidget.this.mResume = true;
                        int delay = 500;
                        if (notifyCause == 30) {
                            MyLog.i("SocialNetworkWidget WHAT_ON_RESUME~ NOTIFY_CAUSE_ACTIVITY");
                            delay = 300;
                        }
                        SocialWidget.this.mHandler.sendDelayed(SocialWidget.WHAT_ON_RESUME_DELAY, delay);
                        break;
                    case 2:
                        MyLog.d("SocialNetworkWidget WHAT_ON_PAUSE");
                        SocialWidget.this.mResume = false;
                        break;
                    case SocialWidget.WHAT_ON_RESUME_DELAY /* 9002 */:
                        MyLog.d("SocialNetworkWidget WHAT_ON_RESUME_DELAY");
                        SocialWidget.this.mResume = true;
                        if (SocialWidget.this.mCtrl.getState() == SocialNetworkCtrl.State.START) {
                            SocialWidget.this.mCtrl.updateIsLoggedIn();
                            SocialWidget.this.mUiHandler.sendDelayed(SocialWidget.WHAT_UI_UPDATE, 0L);
                            break;
                        } else {
                            Handler handler = new Handler();
                            SocialWidget.this.mCtrl.init(SocialWidget.this.mResContext, SocialWidget.this.mOnUpdateListener, handler, handler);
                            break;
                        }
                    case Constants.WHAT_ON_CONFIG_CHANGED /* 36881 */:
                        SocialWidget.this.doConfigurationChanged();
                        break;
                    case Constants.WHAT_ON_CLICK_AP1 /* 36882 */:
                        SocialWidget.this.launchSocialAp();
                        break;
                }
                return true;
            }
            MyLog.e("SocialNetworkWidget handleMessage~ widget destroied msg.what:" + msg.what);
            return false;
        }
    };
    private Handler.Callback mUiWorker = new Handler.Callback() { // from class: com.htc.clock3dwidget.socialclock.SocialWidget.3
        @Override // android.os.Handler.Callback
        public boolean handleMessage(Message msg) {
            if (!SocialWidget.this.isWidgetDestroy()) {
                switch (msg.what) {
                    case SocialWidget.WHAT_UI_UPDATE /* 9101 */:
                        if (SocialWidget.this.mCtrl != null && SocialWidget.this.mCtrl.getState() == SocialNetworkCtrl.State.START && SocialWidget.this.mResume) {
                            SocialData data = SocialWidget.this.mCtrl.getLastSocialData();
                            SocialWidget.this.mSocialData = data;
                            SocialWidget.this.mIsLoggedIn = SocialWidget.this.mCtrl.isLoggedIn();
                            SocialWidget.this.mSocialView.updateUI(SocialWidget.this.mIsLoggedIn, data);
                            SocialWidget.this.mNeedToUpdate = false;
                        }
                        break;
                    default:
                        return true;
                }
            } else {
                MyLog.e("SocialNetworkWidget handleMessage~ widget destroied msg.what:" + msg.what);
                return false;
            }
        }
    };
    private SocialNetworkCtrl.OnUpdateListener mOnUpdateListener = new SocialNetworkCtrl.OnUpdateListener() { // from class: com.htc.clock3dwidget.socialclock.SocialWidget.4
        @Override // com.htc.clock.util.social.SocialNetworkCtrl.OnUpdateListener
        public void onUpdate(SocialData data) {
            if (SocialWidget.this.mResume) {
                boolean isLoggedIn = SocialWidget.this.mCtrl.isLoggedIn();
                SocialWidget.this.mSocialData = data;
                SocialWidget.this.mSocialView.updateUI(isLoggedIn, data);
                return;
            }
            SocialWidget.this.mNeedToUpdate = true;
        }
    };

    public SocialWidget(Context resContext, Context appContext, Widget.Host host, Intent intent, FxScene scenePort, FxScene sceneLand, AnalogClockWidget.InstanceCallback callback) {
        this.mOrientation = 1;
        this.mResContext = resContext;
        this.mApplication = appContext;
        this.mHandler = host.getWorker(this.mWorker);
        this.mUiHandler = host.getWorker(this.mUiWorker);
        this.mHost = host;
        this.mScenePort = scenePort;
        this.mSceneLand = sceneLand;
        this.mFxControlsPort = new FxSocialControls(this.mScenePort);
        this.mFxControlsLand = !ClockUtils.SUPPORT_LAND ? this.mFxControlsPort : new FxSocialControls(this.mSceneLand);
        this.mInstanceCallback = callback;
        this.mSocialView = new SocialView(this.mResContext, this.mApplication, null);
        this.mOrientation = appContext.getResources().getConfiguration().orientation;
        this.mSocialView.bind(this.mFxControlsPort, this.mFxControlsLand);
        this.mSocialView.init(this.mOrientation == 1 ? this.mFxControlsPort : this.mFxControlsLand);
        this.mSocialView.setOnClickListener(this.mSocialClick);
        this.mHandler.send(9001);
    }

    public void doResume() {
        removeResumeMessage();
        Message msg = this.mHandler.obtainMessage();
        msg.what = 1;
        msg.arg1 = 30;
        this.mHandler.send(msg);
    }

    public void doPause() {
        removePauseMessage();
        Message msg = this.mHandler.obtainMessage();
        msg.what = 2;
        msg.arg1 = 30;
        this.mHandler.send(msg);
    }

    public void doHostMessage(Message msg) {
        switch (msg.what) {
            case 3:
                this.mHandler.sendDelayed(Constants.WHAT_ON_CONFIG_CHANGED, 0L);
                break;
        }
    }

    public void doActivityResult(int requestCode, int resultCode, Intent data) {
    }

    public void doDestroy() {
        this.mBoolAppDestroy = true;
        removeMessages();
        clear();
    }

    private void removeMessages() {
        removeNonUiMessages(9001);
        removeNonUiMessages(1);
        removeNonUiMessages(WHAT_ON_RESUME_DELAY);
        removeNonUiMessages(2);
        removeNonUiMessages(Constants.WHAT_ON_CONFIG_CHANGED);
        removeNonUiMessages(Constants.WHAT_ON_CLICK_AP1);
        removeUiMessages(WHAT_UI_UPDATE);
    }

    private void clear() {
        if (this.mSocialView != null) {
            this.mSocialView.unbind(this.mFxControlsPort, this.mFxControlsLand);
        }
        if (this.mCtrl != null) {
            this.mCtrl.uninit();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void launchSocialAp() {
        if (this.mCtrl != null) {
            if (!this.mCtrl.isLoggedIn()) {
                SocialNetworkUtil.launchLoginPage(this.mApplication);
                return;
            }
            SocialData data = this.mCtrl.getLastSocialData();
            if (data != null) {
                data.launchRelativePage(this.mApplication);
            } else {
                SocialNetworkUtil.launchMainPage(this.mApplication);
            }
        }
    }

    public boolean isWidgetDestroy() {
        return this.mBoolAppDestroy;
    }

    protected void removeNonUiMessages(int what) {
        if (this.mHandler != null) {
            this.mHandler.recall(what);
        }
    }

    protected void removeUiMessages(int what) {
        if (this.mUiHandler != null) {
            this.mUiHandler.recall(what);
        }
    }

    public void removeMessage(Handler handler, int what) {
        if (handler != null) {
            handler.removeMessages(what);
        }
    }

    public void sendMessage(Handler handler, int what, long delay) {
        if (handler != null) {
            handler.sendEmptyMessageDelayed(what, delay);
        }
    }

    public void sendMessage(Handler handler, Message msg, long delay) {
        if (handler != null) {
            handler.sendMessageDelayed(msg, delay);
        }
    }

    private void removePauseMessage() {
        if (this.mHandler.hasMessage(2)) {
            this.mHandler.recall(2);
        }
    }

    private void removeResumeMessage() {
        if (this.mHandler.hasMessage(Constants.WHAT_ON_RESUME_DELAY)) {
            this.mHandler.recall(Constants.WHAT_ON_RESUME_DELAY);
        }
        if (this.mHandler.hasMessage(1)) {
            this.mHandler.recall(1);
        }
    }

    public void onConfigurationChanged(int orientation) {
        this.mOrientation = orientation;
        if (this.mHandler.hasMessage(Constants.WHAT_ON_CONFIG_CHANGED)) {
            this.mHandler.recall(Constants.WHAT_ON_CONFIG_CHANGED);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doConfigurationChanged() {
        this.mSocialView.init(this.mOrientation == 1 ? this.mFxControlsPort : this.mFxControlsLand);
        doResume();
    }
}
