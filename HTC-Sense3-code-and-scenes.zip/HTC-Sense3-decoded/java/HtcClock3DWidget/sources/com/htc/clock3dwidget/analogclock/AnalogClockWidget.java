package com.htc.clock3dwidget.analogclock;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import com.htc.android.rosie.widget.Widget;
import com.htc.clock.util.MyLog;
import com.htc.clock.util.MyUtil;
import com.htc.clock.util.location.LocationUtil;
import com.htc.clock.util.time.CurLocationTimeCtrl;
import com.htc.clock.util.time.HomeTimeCtrl;
import com.htc.clock.util.time.TimeCtrl;
import com.htc.clock3dwidget.ClockRes;
import com.htc.clock3dwidget.ClockUtils;
import com.htc.clock3dwidget.R;
import com.htc.clock3dwidget.util.Constants;
import com.htc.clock3dwidget.util.MyProjectSetting;
import com.htc.fusion.fx.FxScene;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class AnalogClockWidget {
    public static final int WHAT_ON_INIT = 9001;
    private AnalogClockView mAnalogClockView;
    private Context mApplication;
    private FxAnalogControls mFxControlsLand;
    private FxAnalogControls mFxControlsPort;
    private Widget.Host.Worker mHandler;
    private InstanceCallback mInstanceCallback;
    private int mOrientation;
    private Context mResContext;
    private FxScene mSceneLand;
    private FxScene mScenePort;
    private TimeCtrl mTimeCtrl;
    private Widget.Host.Worker mUiHandler;
    private Handler mhHandler;
    private Handler mhUiHandler;
    private boolean mBShowCityLabel = true;
    private TimeCtrl.OnTimeListener mTimeListener = new MyTimeListener();
    protected boolean mUseCurrentLocation = false;
    protected boolean mIsHomeClock = false;
    private String mCityCode = null;
    private String mCityName = null;
    protected String mTimeZoneStr = null;
    protected boolean mTimeZoneChanged = false;
    private Object mTimeCtrlLock = new Object();
    boolean mPauseByAddToHome = false;
    private boolean mBoolAppDestroy = false;
    private UiState mUiState = UiState.NONE;
    private View.OnClickListener mClockClick = new View.OnClickListener() { // from class: com.htc.clock3dwidget.analogclock.AnalogClockWidget.1
        @Override // android.view.View.OnClickListener
        public void onClick(View arg0) {
            AnalogClockWidget.this.sendNonUiMessageDelayed(Constants.WHAT_ON_CLICK_AP1, 0L);
        }
    };
    private Handler.Callback mWorker = new Handler.Callback() { // from class: com.htc.clock3dwidget.analogclock.AnalogClockWidget.2
        @Override // android.os.Handler.Callback
        public boolean handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    AnalogClockWidget.this.mUiState = UiState.RESUME;
                    AnalogClockWidget.this.removeNonUiMessages(Constants.WHAT_IS_PAUSED);
                    if (AnalogClockWidget.this.mAnalogClockView != null && AnalogClockWidget.this.mTimeCtrl != null) {
                        AnalogClockWidget.this.mTimeCtrl.updateFormat();
                        AnalogClockWidget.this.mAnalogClockView.setDateFormat(AnalogClockWidget.this.mTimeCtrl.is24HourFormat(), AnalogClockWidget.this.mTimeCtrl.getDateFormat());
                        AnalogClockWidget.this.updateTimeZone();
                        AnalogClockWidget.this.updateCityName();
                    }
                    MyLog.d("WHAT_ON_RESUME~ notifyCause:" + msg.arg1);
                    Message message = null;
                    if (AnalogClockWidget.this.mUiHandler != null) {
                        message = AnalogClockWidget.this.mUiHandler.obtainMessage();
                        message.what = Constants.MSG_ON_RESUME;
                        message.arg1 = msg.arg1;
                        message.arg2 = msg.arg2;
                    } else if (AnalogClockWidget.this.mhUiHandler != null) {
                        message = AnalogClockWidget.this.mhUiHandler.obtainMessage();
                        message.what = Constants.MSG_ON_RESUME;
                        message.arg1 = msg.arg1;
                        message.arg2 = msg.arg2;
                    }
                    AnalogClockWidget.this.sendUiMessageDelayed(message, 0L);
                    AnalogClockWidget.this.sendUiMessageDelayed(Constants.MSG_ON_WIGGLE, (int) (Math.random() * 2000.0d));
                    break;
                case 2:
                    AnalogClockWidget.this.mUiState = UiState.PAUSED;
                    int notifyCause = msg.arg1;
                    AnalogClockWidget.this.onNotifyWidgetPause(notifyCause);
                    break;
                case Constants.WHAT_ON_INIT /* 36865 */:
                    if (AnalogClockWidget.this.mInstanceCallback != null) {
                        ClockConfig config = AnalogClockWidget.this.mInstanceCallback.loadPropertyData();
                        if (config != null) {
                            AnalogClockWidget.this.initData(config.citnameCode, config.bShowCityLabel);
                            break;
                        } else {
                            AnalogClockWidget.this.initData(null, false);
                            break;
                        }
                    } else {
                        AnalogClockWidget.this.initData(null, false);
                        break;
                    }
                case Constants.WHAT_IS_PAUSED /* 36866 */:
                    AnalogClockWidget.this.what_Is_Paused();
                    break;
                case Constants.WHAT_TIME_CHANGED /* 36867 */:
                    AnalogClockWidget.this.doTimeChanged();
                    break;
                case Constants.WHAT_ON_CONFIG_CHANGED /* 36881 */:
                    AnalogClockWidget.this.doConfigurationChanged();
                    break;
                case Constants.WHAT_ON_CLICK_AP1 /* 36882 */:
                    MyUtil.launchWorldClockAp(AnalogClockWidget.this.mApplication, AnalogClockWidget.this.mCityCode);
                    break;
                case Constants.WHAT_ON_ACTIVITY_RESULT /* 36884 */:
                    AnalogClockWidget.this.doActivityResult((Intent) msg.obj);
                    break;
                case Constants.WHAT_ON_RESUME_KEYGUARD /* 36885 */:
                    AnalogClockWidget.this.removeNonUiMessages(Constants.WHAT_IS_PAUSED);
                    if (AnalogClockWidget.this.mAnalogClockView != null && AnalogClockWidget.this.mTimeCtrl != null) {
                        AnalogClockWidget.this.mTimeCtrl.updateFormat();
                        AnalogClockWidget.this.mAnalogClockView.setDateFormat(AnalogClockWidget.this.mTimeCtrl.is24HourFormat(), AnalogClockWidget.this.mTimeCtrl.getDateFormat());
                        AnalogClockWidget.this.updateTimeZone();
                        AnalogClockWidget.this.updateCityName();
                    }
                    if (AnalogClockWidget.this.mAnalogClockView != null && !AnalogClockWidget.this.mPauseByAddToHome && AnalogClockWidget.this.mUiHandler != null && AnalogClockWidget.this.mAnalogClockView != null && AnalogClockWidget.this.mAnalogClockView.mUseAnimation) {
                        AnalogClockWidget.this.removeUiMessages(Constants.MSG_PREPARE_FLIP);
                        Message message2 = AnalogClockWidget.this.mUiHandler.obtainMessage();
                        message2.what = Constants.MSG_PREPARE_FLIP;
                        AnalogClockWidget.this.sendUiMessageDelayed(message2, 0L);
                        break;
                    }
                    break;
                case Constants.WHAT_ON_FORMAT_UPDATE /* 37381 */:
                    AnalogClockWidget.this.doFormatChanged();
                    break;
            }
            return true;
        }
    };
    private Handler.Callback mUiWorker = new Handler.Callback() { // from class: com.htc.clock3dwidget.analogclock.AnalogClockWidget.3
        @Override // android.os.Handler.Callback
        public boolean handleMessage(Message msg) {
            switch (msg.what) {
                case Constants.MSG_ON_RESUME /* 32769 */:
                    if (AnalogClockWidget.this.mAnalogClockView != null) {
                        if (AnalogClockWidget.this.mAnalogClockView.mUseAnimation) {
                            AnalogClockWidget.this.mAnalogClockView.startAnimation();
                            break;
                        } else {
                            AnalogClockWidget.this.mAnalogClockView.setPause(false);
                            break;
                        }
                    }
                    break;
                case Constants.MSG_UPDATE_CITY_NAME /* 32772 */:
                    AnalogClockWidget.this.updateCityName();
                    break;
                case Constants.MSG_UPDATE_TIMEZONE /* 32773 */:
                    AnalogClockWidget.this.updateTimeZone();
                    AnalogClockWidget.this.updateCityName();
                    AnalogClockWidget.this.updateTime();
                    break;
                case Constants.KEY_INVAILDATE_NOW /* 32785 */:
                    AnalogClockWidget.this.mAnalogClockView.invalidate(false);
                    break;
                case Constants.MSG_PREPARE_FLIP /* 32793 */:
                    if (AnalogClockWidget.this.mAnalogClockView != null) {
                        AnalogClockWidget.this.mAnalogClockView.prepareAnimation();
                        break;
                    }
                    break;
                case Constants.MSG_ON_WIGGLE /* 32802 */:
                    if (AnalogClockWidget.this.mAnalogClockView != null) {
                        AnalogClockWidget.this.mAnalogClockView.playWiggle();
                        break;
                    }
                    break;
            }
            return true;
        }
    };

    public interface InstanceCallback {
        ClockConfig loadPropertyData();

        void savePropertyData(Intent intent);
    }

    public enum UiState {
        NONE,
        RESUME,
        PAUSED
    }

    public AnalogClockWidget(Context resContext, Context appContext, Widget.Host host, FxScene scenePort, FxScene sceneLand, int orientation, InstanceCallback callback, ClockRes res) {
        this.mOrientation = 1;
        this.mResContext = resContext;
        this.mApplication = appContext;
        if (host != null) {
            this.mHandler = host.getWorker(this.mWorker);
            this.mUiHandler = host.getWorker(this.mUiWorker);
        } else {
            this.mhHandler = new Handler(this.mWorker);
            this.mhUiHandler = new Handler(this.mUiWorker);
        }
        this.mScenePort = scenePort;
        this.mSceneLand = sceneLand;
        this.mOrientation = orientation;
        this.mInstanceCallback = callback;
        this.mAnalogClockView = new AnalogClockView(this.mResContext, this.mApplication);
        this.mFxControlsPort = new FxAnalogControls(this.mScenePort, res);
        this.mFxControlsLand = !ClockUtils.SUPPORT_LAND ? this.mFxControlsPort : new FxAnalogControls(this.mSceneLand, res);
        this.mAnalogClockView.bind(this.mFxControlsPort, this.mFxControlsLand);
        this.mAnalogClockView.init(this.mOrientation == 1 ? this.mFxControlsPort : this.mFxControlsLand);
        if (host != null) {
            this.mAnalogClockView.setOnClickListener(this.mClockClick);
        }
        String defaultCurName = this.mResContext.getResources().getString(R.string.current_location);
        LocationUtil.setDefaultLocName(defaultCurName);
        initView();
        sendNonUiMessageDelayed(Constants.WHAT_ON_INIT, 0L);
    }

    public void doResume() {
        removeUiMessages(Constants.MSG_ON_WIGGLE);
        removeNonUiMessages(1);
        sendNonUiMessageDelayed(1, 0L);
    }

    public void doPause() {
        removeUiMessages(Constants.MSG_ON_WIGGLE);
        removeNonUiMessages(2);
        Message msg = null;
        if (this.mHandler != null) {
            msg = this.mHandler.obtainMessage();
            msg.what = 2;
            msg.arg1 = 30;
        } else if (this.mhHandler != null) {
            msg = this.mhHandler.obtainMessage();
            msg.what = 2;
            msg.arg1 = 30;
        }
        sendNonUiMessageDelayed(msg, 0L);
    }

    public void doHostMessage(Message msg) {
        switch (msg.what) {
            case 3:
                sendNonUiMessageDelayed(Constants.WHAT_ON_CONFIG_CHANGED, 0L);
                break;
            case Constants.WIDGET_TYPE_DIGITALCLOCK /* 5 */:
                MyLog.i("HOST_USER_PRESENT,arg1= " + msg.arg1 + ", mUiState=" + this.mUiState);
                if ((msg.arg1 & 1) != 0) {
                    if (this.mUiState == UiState.PAUSED || this.mUiState == UiState.NONE) {
                        doResumeInKeyguard();
                        break;
                    }
                }
                break;
        }
    }

    public void doActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == -1) {
            Message msg = obtainNonUiMessage();
            msg.what = Constants.WHAT_ON_ACTIVITY_RESULT;
            msg.obj = data;
            sendNonUiMessageDelayed(msg, 0L);
        }
    }

    public void doDestroy() {
        this.mBoolAppDestroy = true;
        removeMessages();
        clear();
    }

    private void removeMessages() {
        removeNonUiMessages(Constants.WHAT_ON_INIT);
        removeNonUiMessages(Constants.WHAT_IS_PAUSED);
        removeNonUiMessages(1);
        removeNonUiMessages(2);
        removeNonUiMessages(Constants.WHAT_TIME_CHANGED);
        removeNonUiMessages(Constants.WHAT_ON_FORMAT_UPDATE);
        removeNonUiMessages(Constants.WHAT_ON_CONFIG_CHANGED);
        removeNonUiMessages(Constants.WHAT_ON_CLICK_AP1);
        removeNonUiMessages(Constants.WHAT_ON_ACTIVITY_RESULT);
        removeUiMessages(Constants.MSG_ON_RESUME);
        removeUiMessages(Constants.MSG_ON_WIGGLE);
        removeUiMessages(Constants.MSG_PREPARE_FLIP);
        removeUiMessages(Constants.MSG_UPDATE_CITY_NAME);
        removeUiMessages(Constants.MSG_UPDATE_TIMEZONE);
        removeUiMessages(Constants.KEY_INVAILDATE_NOW);
    }

    private void clear() {
        unInitTimeCtrl();
        if (this.mAnalogClockView != null) {
            this.mAnalogClockView.unbind(this.mFxControlsPort, this.mFxControlsLand);
            this.mAnalogClockView.clear();
        }
    }

    private void doResumeInKeyguard() {
        Message msg = this.mHandler.obtainMessage();
        msg.what = Constants.WHAT_ON_RESUME_KEYGUARD;
        this.mHandler.send(msg);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void initData(String citnameCode, boolean bShowCityLabel) {
        if (citnameCode != null && Constants.HOME_CITY.equals(citnameCode)) {
            this.mIsHomeClock = true;
            this.mUseCurrentLocation = false;
        } else {
            this.mIsHomeClock = false;
            this.mUseCurrentLocation = (citnameCode != null && Constants.CURRENT_CITY.equals(citnameCode)) || citnameCode == null;
            if (!MyProjectSetting.hasCurrentLocation()) {
                this.mUseCurrentLocation = false;
            }
        }
        this.mCityCode = citnameCode;
        unInitTimeCtrl();
        initTimeCtrl();
        this.mTimeCtrl.updateFormat();
        this.mAnalogClockView.setDateFormat(this.mTimeCtrl.is24HourFormat(), this.mTimeCtrl.getDateFormat());
        this.mBShowCityLabel = bShowCityLabel;
        sendUiMessageDelayed(Constants.MSG_UPDATE_TIMEZONE, 0L);
    }

    private void initTimeCtrl() {
        synchronized (this.mTimeCtrlLock) {
            Handler handler = new Handler();
            if (this.mInstanceCallback != null) {
                if (this.mUseCurrentLocation) {
                    this.mTimeCtrl = new CurLocationTimeCtrl();
                } else if (this.mIsHomeClock) {
                    this.mTimeCtrl = new HomeTimeCtrl();
                } else {
                    this.mTimeCtrl = new TimeCtrl();
                }
                this.mTimeCtrl.init(this.mResContext, this.mTimeListener, 2, handler, this.mCityCode);
            } else {
                this.mTimeCtrl = new TimeCtrl();
                this.mTimeCtrl.init(this.mResContext, this.mTimeListener, 6, handler, this.mCityCode);
            }
        }
    }

    private void unInitTimeCtrl() {
        synchronized (this.mTimeCtrlLock) {
            if (this.mTimeCtrl != null) {
                this.mTimeCtrl.uninit();
            }
        }
    }

    private class MyTimeListener implements TimeCtrl.OnTimeListener {
        private MyTimeListener() {
        }

        @Override // com.htc.clock.util.time.TimeCtrl.OnTimeListener
        public void onMinute() {
            AnalogClockWidget.this.sendNonUiMessageDelayed(Constants.WHAT_TIME_CHANGED, 0L);
        }

        @Override // com.htc.clock.util.time.TimeCtrl.OnTimeListener
        public void onSecond() {
        }

        @Override // com.htc.clock.util.time.TimeCtrl.OnTimeListener
        public void onFormatChanged() {
            AnalogClockWidget.this.sendNonUiMessageDelayed(Constants.WHAT_ON_FORMAT_UPDATE, 0L);
        }

        @Override // com.htc.clock.util.time.TimeCtrl.OnTimeListener
        public void onTimeChanged() {
            AnalogClockWidget.this.sendNonUiMessageDelayed(Constants.WHAT_TIME_CHANGED, 0L);
        }

        @Override // com.htc.clock.util.time.TimeCtrl.OnTimeListener
        public void onTimeZoneChanged() {
            AnalogClockWidget.this.sendUiMessageDelayed(Constants.MSG_UPDATE_TIMEZONE, 0L);
        }
    }

    public void onNotifyWidgetPause(int notifyCause) {
        removeUiMessages(Constants.MSG_ON_RESUME);
        if (notifyCause == 30) {
            sendNonUiMessageDelayed(Constants.WHAT_IS_PAUSED, 0L);
        } else {
            this.mAnalogClockView.setPause(true);
        }
    }

    protected void what_Is_Paused() {
        if (this.mAnalogClockView != null) {
            this.mAnalogClockView.setPause(true);
        }
    }

    protected void sendUiMessageDelayed(int what, long delayMillis) {
        if (this.mUiHandler != null) {
            if (delayMillis > 0) {
                this.mUiHandler.sendDelayed(what, delayMillis);
                return;
            } else {
                this.mUiHandler.send(what);
                return;
            }
        }
        if (this.mhUiHandler != null) {
            if (delayMillis > 0) {
                this.mhUiHandler.sendEmptyMessageDelayed(what, delayMillis);
            } else {
                this.mhUiHandler.sendEmptyMessage(what);
            }
        }
    }

    protected void sendUiMessageDelayed(Message msg, long delayMillis) {
        if (this.mUiHandler != null) {
            if (delayMillis > 0) {
                this.mUiHandler.sendDelayed(msg, delayMillis);
                return;
            } else {
                this.mUiHandler.send(msg);
                return;
            }
        }
        if (this.mhUiHandler != null) {
            if (delayMillis > 0) {
                this.mhUiHandler.sendMessageDelayed(msg, delayMillis);
            } else {
                this.mhUiHandler.sendMessage(msg);
            }
        }
    }

    protected void removeUiMessages(int what) {
        if (this.mUiHandler != null) {
            this.mUiHandler.recall(what);
        } else if (this.mhUiHandler != null) {
            this.mhUiHandler.removeMessages(what);
        }
    }

    private boolean hasNonUiMessage(int what) {
        if (this.mHandler != null) {
            return this.mHandler.hasMessage(what);
        }
        if (this.mhHandler != null) {
            return this.mhHandler.hasMessages(what);
        }
        return false;
    }

    protected void sendNonUiMessageDelayed(int what, long delayMillis) {
        if (this.mHandler != null) {
            if (delayMillis > 0) {
                this.mHandler.sendDelayed(what, delayMillis);
                return;
            } else {
                this.mHandler.send(what);
                return;
            }
        }
        if (this.mhHandler != null) {
            if (delayMillis > 0) {
                this.mhHandler.sendEmptyMessageDelayed(what, delayMillis);
            } else {
                this.mhHandler.sendEmptyMessage(what);
            }
        }
    }

    protected void sendNonUiMessageDelayed(Message msg, long delayMillis) {
        if (this.mHandler != null) {
            if (delayMillis > 0) {
                this.mHandler.sendDelayed(msg, delayMillis);
                return;
            } else {
                this.mHandler.send(msg);
                return;
            }
        }
        if (this.mhHandler != null) {
            if (delayMillis > 0) {
                this.mhHandler.sendMessageDelayed(msg, delayMillis);
            } else {
                this.mhHandler.sendMessage(msg);
            }
        }
    }

    private Message obtainNonUiMessage() {
        if (this.mHandler != null) {
            Message msg = this.mHandler.obtainMessage();
            return msg;
        }
        if (this.mhHandler == null) {
            return null;
        }
        Message msg2 = this.mhHandler.obtainMessage();
        return msg2;
    }

    protected void removeNonUiMessages(int what) {
        if (this.mHandler != null) {
            this.mHandler.recall(what);
        } else if (this.mhHandler != null) {
            this.mhHandler.removeMessages(what);
        }
    }

    protected void updateCityName() {
        if (this.mTimeCtrl != null && this.mAnalogClockView != null) {
            this.mCityName = this.mTimeCtrl.getTimeZoneCity();
            setCityName(this.mCityName);
        }
    }

    public void updateTimeZone() {
        this.mTimeZoneStr = this.mTimeCtrl.getCalendar().getTimeZone().getID();
        MyLog.i("TimeCtrl~ getCalendar mTimeZoneStr:" + this.mTimeZoneStr);
        if (this.mAnalogClockView != null) {
            this.mAnalogClockView.setTimeZone(this.mTimeZoneStr);
        }
    }

    public void updateTime() {
        if (this.mAnalogClockView != null) {
            this.mAnalogClockView.onTimeChanged();
        }
    }

    protected void setCityName(String cityName) {
        if (this.mAnalogClockView.mCityName != null) {
            if (this.mBShowCityLabel) {
                this.mAnalogClockView.mCityName.setVisibility(true);
                this.mAnalogClockView.mCityName.setString(cityName);
            } else {
                this.mAnalogClockView.mCityName.setVisibility(false);
            }
        }
    }

    protected void initView() {
        updateCityName();
        this.mAnalogClockView.setAnimationFeedback(false, this.mUiHandler, this.mhUiHandler);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doActivityResult(Intent data) {
        if (data != null) {
            switchToNewCity(data);
        }
    }

    public void doTiltChanged(float tilt) {
        if (!this.mBoolAppDestroy && this.mAnalogClockView != null) {
            this.mAnalogClockView.doTiltChanged(tilt);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doTimeChanged() {
        if (this.mAnalogClockView != null) {
            this.mAnalogClockView.onTimeChanged();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doFormatChanged() {
        if (this.mAnalogClockView != null && this.mTimeCtrl != null) {
            this.mAnalogClockView.setDateFormat(this.mTimeCtrl.is24HourFormat(), this.mTimeCtrl.getDateFormat());
            this.mAnalogClockView.onTimeChanged();
        }
    }

    private void switchToNewCity(Intent data) {
        this.mInstanceCallback.savePropertyData(data);
        sendNonUiMessageDelayed(Constants.WHAT_ON_INIT, 0L);
    }

    public void onConfigurationChanged(int orientation) {
        this.mOrientation = orientation;
        if (hasNonUiMessage(Constants.WHAT_ON_CONFIG_CHANGED)) {
            removeNonUiMessages(Constants.WHAT_ON_CONFIG_CHANGED);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doConfigurationChanged() {
        this.mAnalogClockView.init(this.mOrientation == 1 ? this.mFxControlsPort : this.mFxControlsLand);
        doResume();
    }
}
