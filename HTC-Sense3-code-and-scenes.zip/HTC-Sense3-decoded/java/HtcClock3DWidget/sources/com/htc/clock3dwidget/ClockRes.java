package com.htc.clock3dwidget;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class ClockRes {
    public String hitboxClock;
    public String m10FilePath;
    public String progressBarHourHand;
    public String progressBarMinuteHand;
    public String progressBarSecondHand;
    public String progressBarUnitHourHand;
    public String progressBarUnitMinuteHand;
    public String textLabalClockAmPm;
    public String textLabalClockAmPm_night;
    public String textLabelCityName;
    public String textLabelClockDate;
    public String textLabelClockDate_night;
    public String textLabelClockLongDate;
    public String textLabelClockWeekDay;
    public String textLabelClockWeekDay_night;
    public String textLabelHour;
    public String textLabelMinute;
    public String textLabelSecond;
    public String timelineAmPm;
    public String timelineAmPmOpp;
    public String timelineClock;
    public String timelineClockAmPm;
    public String timelineClockBase;
    public String timelineClockDate;
    public String timelineClockHour;
    public String timelineClockMinute;
    public String timelineClockNumbers;
    public String timelineFlipHour;
    public String timelineFlipMinute;
    public String timelineGear01;
    public String timelineGear02;
    public String timelineGear03;
    public String timelineGear04;
    public String timelineGear05;
    public String timelineHourTen;
    public String timelineHourUnit;
    public String timelineMinuteTen;
    public String timelineMinuteUinit;
    public String timelineWiggle;
}
