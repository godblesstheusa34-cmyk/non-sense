package com.htc.clock3dwidget.socialclock;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.text.SpannableStringBuilder;
import android.text.TextPaint;
import android.text.style.CharacterStyle;
import android.text.style.ImageSpan;
import android.view.View;
import com.htc.clock.util.MyLog;
import com.htc.clock.util.social.SocialData;
import com.htc.clock3dwidget.R;
import com.htc.fusion.fx.MessageListener;
import com.htc.fusion.fx.controls.FxDynamicImage;
import com.htc.fusion.fx.controls.FxHitbox;
import com.htc.fusion.fx.controls.FxTextLabel;
import com.htc.graphics.drawable.UrlDrawable;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class SocialView {
    private Context mApContext;
    private View.OnClickListener mClickListener;
    protected FxHitbox mFxHitboxSocial;
    private FxDynamicImage mIcon;
    private ImageSpan mImageSpanLike;
    private ImageSpan mImageSpanReplay;
    private FxDynamicImage mIndicator;
    private FxTextLabel mInfo;
    private String mLoggedInTap;
    private FxTextLabel mMessage;
    private FxTextLabel mReply;
    private Context mResContext;
    private SocialClickListener mSocialClickLand;
    private SocialClickListener mSocialClickPort;
    private String mSocialEmpty;
    private FxTextLabel mTime;
    private SpannableStringBuilder mContentStringBuilder = new SpannableStringBuilder();
    private SocialData.InflatedCallback mInflatedCallback = new SocialData.InflatedCallback() { // from class: com.htc.clock3dwidget.socialclock.SocialView.1
        @Override // com.htc.clock.util.social.SocialData.InflatedCallback
        public void onURLDrawableInflated(SocialData.RemoteUrlDrawable drawable) {
            SocialView.this.updateIcon(drawable.getBitmap());
        }
    };

    public class MessageSpan extends CharacterStyle {
        private boolean mBold;

        public MessageSpan(boolean bold) {
            this.mBold = false;
            this.mBold = bold;
        }

        @Override // android.text.style.CharacterStyle
        public void updateDrawState(TextPaint ds) {
            if (this.mBold) {
                ds.setTypeface(Typeface.DEFAULT_BOLD);
            }
        }
    }

    public void init(FxSocialControls controls) {
        this.mMessage = controls.mMessage;
        this.mTime = controls.mTime;
        this.mReply = controls.mReply;
        this.mIcon = controls.mIcon;
        this.mIndicator = controls.mIndicator;
        this.mFxHitboxSocial = controls.mFxHitboxSocial;
        this.mInfo = controls.mInfo;
    }

    public void bind(FxSocialControls controlsPort, FxSocialControls controlsLand) {
        controlsPort.mFxHitboxSocial.getTapSource().bind(this.mSocialClickPort);
        if (!controlsPort.equals(controlsLand)) {
            controlsLand.mFxHitboxSocial.getTapSource().bind(this.mSocialClickLand);
        }
    }

    public void unbind(FxSocialControls controlsPort, FxSocialControls controlsLand) {
        controlsPort.mFxHitboxSocial.getTapSource().unbind(this.mSocialClickPort);
        if (!controlsPort.equals(controlsLand)) {
            controlsLand.mFxHitboxSocial.getTapSource().unbind(this.mSocialClickLand);
        }
    }

    public SocialView(Context apContext, Context resContext, View parent) {
        this.mSocialClickPort = new SocialClickListener();
        this.mSocialClickLand = new SocialClickListener();
        this.mApContext = apContext;
        this.mResContext = resContext;
        this.mLoggedInTap = this.mApContext.getResources().getString(R.string.social_login_now_tap);
        this.mSocialEmpty = this.mApContext.getResources().getString(R.string.social_empty);
        Drawable dLike = this.mApContext.getResources().getDrawable(R.drawable.icon_indicator_likes_white);
        dLike.setBounds(0, 0, 0, 0);
        this.mImageSpanLike = new ImageSpan(dLike, 0);
        Drawable dReplay = this.mApContext.getResources().getDrawable(R.drawable.icon_indicator_replies_white);
        dReplay.setBounds(0, 0, 0, 0);
        this.mImageSpanReplay = new ImageSpan(dReplay, 0);
    }

    public void updateUI(boolean isLoggedIn, SocialData data) {
        if (!isLoggedIn) {
            MyLog.i("SocialNetworkView~ updateUI not login");
            showEmptyText(this.mLoggedInTap);
            return;
        }
        if (data != null) {
            MyLog.i("SocialNetworkView~ updateUI normal");
            this.mInfo.setVisibility(false);
            CharSequence content = formatStr(data);
            this.mMessage.setString(content.toString());
            this.mMessage.setVisibility(true);
            SocialData.RemoteUrlDrawable remoteIcon = (SocialData.RemoteUrlDrawable) data.getIcon(this.mResContext);
            remoteIcon.setInflatedCallback(this.mInflatedCallback);
            updateIcon(remoteIcon.getBitmap());
            this.mIcon.setVisibility(true);
            Bitmap indicator = data.getIconIndicator(this.mApContext);
            if (indicator != null) {
                this.mIndicator.setImage(indicator);
                this.mIndicator.setVisibility(true);
            } else {
                this.mIndicator.setVisibility(false);
            }
            this.mTime.setString(data.getPastTimeString(this.mApContext).toString());
            this.mTime.setVisibility(true);
            this.mContentStringBuilder.clear();
            long like = data.getLikeCnt();
            long comment = data.getCommentCnt();
            if (like > 0) {
                this.mContentStringBuilder.append((CharSequence) " ").setSpan(this.mImageSpanLike, this.mContentStringBuilder.length() - 1, this.mContentStringBuilder.length(), 33);
                this.mContentStringBuilder.append((CharSequence) (" " + Long.toString(like)));
                if (comment > 0) {
                    this.mContentStringBuilder.append((CharSequence) " ");
                }
            }
            if (comment > 0) {
                this.mContentStringBuilder.append((CharSequence) " ").setSpan(this.mImageSpanReplay, this.mContentStringBuilder.length() - 1, this.mContentStringBuilder.length(), 33);
                this.mContentStringBuilder.append((CharSequence) (" " + Long.toString(comment)));
            }
            if (like > 0 || comment > 0) {
                this.mReply.setContent(this.mContentStringBuilder);
                this.mReply.setVisibility(true);
                return;
            } else {
                this.mReply.setVisibility(false);
                return;
            }
        }
        MyLog.i("SocialNetworkView~ updateUI no data");
        showEmptyText(this.mSocialEmpty);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateIcon(Bitmap icon) {
        if (!UrlDrawable.isValidBitmap(icon)) {
            BitmapDrawable defaultIcon = (BitmapDrawable) this.mResContext.getResources().getDrawable(34078914);
            this.mIcon.setImage(defaultIcon.getBitmap());
        } else {
            this.mIcon.setImage(icon);
        }
    }

    private void showEmptyText(String text) {
        this.mIcon.setVisibility(false);
        this.mMessage.setVisibility(false);
        this.mReply.setVisibility(false);
        this.mTime.setVisibility(false);
        this.mIndicator.setVisibility(false);
        this.mInfo.setString(text);
        this.mInfo.setVisibility(true);
    }

    private CharSequence formatStr(SocialData data) {
        String message;
        String name = data.getName();
        if (data.isFlicker()) {
            message = getFlickrMessage(data);
        } else {
            message = data.getMessage();
        }
        SpannableStringBuilder builder = new SpannableStringBuilder();
        MessageSpan userSpan = new MessageSpan(true);
        builder.append((CharSequence) (name + " ")).setSpan(userSpan, 0, name.length(), 33);
        if (message != null) {
            builder.append((CharSequence) message);
        }
        CharSequence content = builder.subSequence(0, builder.length());
        return content;
    }

    private String getFlickrMessage(SocialData data) {
        int[] uploaded = data.getUploaded(this.mApContext);
        int photos = uploaded[0];
        int videos = uploaded[1];
        String message = "\n";
        if (photos > 0 || videos > 0) {
            String message2 = "\n" + this.mApContext.getResources().getString(R.string.recently_uploaded);
            message = message2 + " ";
        }
        if (photos > 0) {
            message = photos == 1 ? message + this.mApContext.getResources().getString(R.string.number_photos_single, Integer.valueOf(photos)) : message + this.mApContext.getResources().getString(R.string.number_photos_multiple, Integer.valueOf(photos));
        }
        if (videos > 0) {
            if (photos > 0) {
                message = ((message + " ") + this.mApContext.getResources().getString(R.string.and)) + " ";
            }
            return videos == 1 ? message + this.mApContext.getResources().getString(R.string.number_videos_single, Integer.valueOf(videos)) : message + this.mApContext.getResources().getString(R.string.number_videos_multiple, Integer.valueOf(videos));
        }
        return message;
    }

    private class SocialClickListener extends MessageListener<FxHitbox.TapParameters> {
        private SocialClickListener() {
        }

        public void onMessageReceived(FxHitbox.TapParameters message) {
            if (SocialView.this.mClickListener != null) {
                SocialView.this.mClickListener.onClick(null);
            }
        }
    }

    public void setOnClickListener(View.OnClickListener l) {
        this.mClickListener = l;
    }
}
