package com.htc.clock3dwidget.analogclock;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class ClockConfig {
    boolean bShowCityLabel;
    String citnameCode;
}
