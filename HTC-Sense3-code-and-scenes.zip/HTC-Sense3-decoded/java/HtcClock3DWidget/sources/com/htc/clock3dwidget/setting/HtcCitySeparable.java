package com.htc.clock3dwidget.setting;

import com.htc.widget.HtcListItemSeparable;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class HtcCitySeparable implements HtcListItemSeparable {
    public boolean shouldDrawOnThis() {
        return true;
    }

    public boolean shouldSeparate(Object arg0) {
        return true;
    }
}
