package com.htc.clock3dwidget.setting;

import android.content.Intent;
import android.os.Bundle;
import com.htc.clock3dwidget.util.Constants;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class ConfigAnalogClock extends HtcClockSetting {
    @Override // com.htc.clock3dwidget.setting.HtcClockSetting, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        Intent intent = getIntent();
        intent.putExtra(Constants.WIDGET_TYPE, 1);
        super.onCreate(savedInstanceState);
    }
}
