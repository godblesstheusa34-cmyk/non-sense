package com.htc.clock3dwidget.idlescreen;

import android.content.Context;
import android.view.SurfaceHolder;
import com.htc.clock.util.MyLog;
import com.htc.clock3dwidget.ClockUtils;
import com.htc.clock3dwidget.ResUtils;
import com.htc.fusion.fx.FxScene;
import com.htc.lockscreen.fusion.idlescreen.FxIdleScreenEngine;
import com.htc.lockscreen.idlescreen.IdleScreenEngine;
import com.htc.lockscreen.idlescreen.IdleScreenService;
import java.lang.reflect.Method;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class IdleScreenClockService extends IdleScreenService {
    public IdleScreenEngine onCreateEngine() {
        return new MyEngine(this);
    }

    private class MyEngine extends FxIdleScreenEngine {
        private FxScene mFxScene;
        private IdleScreenClockStub mStub;

        public MyEngine(IdleScreenService service) {
            super(service);
        }

        public void onCreate(SurfaceHolder surfaceHolder) {
            super.onCreate(surfaceHolder);
            try {
                Class name = IdleScreenClockService.getClassName();
                Method m = name.getMethod("setClockType", Integer.TYPE);
                m.invoke(this, 1);
            } catch (ClassNotFoundException e) {
                MyLog.i("IdleScreenClockService~ Class not Found");
            } catch (NoSuchMethodException e2) {
                MyLog.i("IdleScreenClockService~ Method not Found");
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        }

        public void onStart() {
            super.onStart();
            this.mFxScene = createScene(ClockUtils.getMode10Path((Context) IdleScreenClockService.this) + ResUtils.M10_LOCKSCREEN_CONTAINER, true);
            this.mStub = new IdleScreenClockStub(IdleScreenClockService.this, this.mFxScene);
        }

        public void onStop() {
            if (this.mStub != null) {
                this.mStub.onDestroy();
            }
            this.mStub = null;
            this.mFxScene = null;
            super.onStop();
            System.gc();
        }

        public void onVisibilityChanged(boolean visible) {
            if (visible) {
                super.onVisibilityChanged(visible);
                if (this.mStub != null) {
                    this.mStub.onResume();
                    return;
                }
                return;
            }
            if (this.mStub != null) {
                this.mStub.onPause();
            }
            super.onVisibilityChanged(visible);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static Class getClassName() throws ClassNotFoundException {
        Class classname = Class.forName("com.htc.lockscreen.fusion.idlescreen.FxIdleScreenEngine");
        return classname;
    }
}
