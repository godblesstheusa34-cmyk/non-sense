package com.htc.clock3dwidget.util;

import com.htc.android.rosie.widget.WidgetHelper;
import com.htc.fusion.fx.FxPlaybackInfo;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.Marker;
import com.htc.fusion.fx.MessageListener;
import java.lang.reflect.Array;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class DigitControl {
    static final /* synthetic */ boolean $assertionsDisabled;
    private static final String TAG;
    private static final int TOTAL_FRAMES = 10;
    private static final boolean localLOGV = false;
    private FxTimelineControl mBottom_0;
    private FxTimelineControl mBottom_0_ampm;
    private FxTimelineControl mBottom_1;
    private FxTimelineControl mBottom_1_ampm;
    private FxTimelineControl mBottom_2;
    private FxTimelineControl mBottom_2_ampm;
    private FxTimelineControl mBottom_3;
    private FxTimelineControl mBottom_3_ampm;
    private int mCurrentNumber;
    private int mDestNumber;
    private final int mMaxNumber;
    private float mPlaybackSpeed;
    private FxTimelineControl mRoot;
    private final Marker mTilt;
    private FxTimelineControl mTop_0;
    private FxTimelineControl mTop_1;
    private FxTimelineControl mTop_2;
    private FxTimelineControl mTop_3;
    private PlaybackCompleteListener mPlaybackListener = new PlaybackCompleteListener();
    private FxTimelineControl[][] mFlipControls = (FxTimelineControl[][]) Array.newInstance((Class<?>) FxTimelineControl.class, 4, 3);
    private int mFlipCount = 0;
    private int mNextNumber = 0;

    static {
        $assertionsDisabled = !DigitControl.class.desiredAssertionStatus();
        TAG = DigitControl.class.getSimpleName();
    }

    static /* synthetic */ int access$104(DigitControl x0) {
        int i = x0.mNextNumber + 1;
        x0.mNextNumber = i;
        return i;
    }

    public DigitControl(FxTimelineControl timeline, int maxNumber) {
        String[] controls = {"timeline.tile_flip_anim", "timeline.bottom_0", "timeline.bottom_1", "timeline.bottom_2", "timeline.bottom_3", "timeline.top_0", "timeline.top_1", "timeline.top_2", "timeline.top_3"};
        FxTimelineControl[] descendants = timeline.getDescendants(controls);
        this.mRoot = descendants[0];
        this.mBottom_0 = descendants[1];
        this.mBottom_1 = descendants[2];
        this.mBottom_2 = descendants[3];
        this.mBottom_3 = descendants[4];
        this.mTop_0 = descendants[5];
        this.mTop_1 = descendants[6];
        this.mTop_2 = descendants[7];
        this.mTop_3 = descendants[8];
        setChild(this.mBottom_0);
        setChild(this.mBottom_1);
        setChild(this.mBottom_2);
        setChild(this.mBottom_3);
        setChild(this.mTop_0);
        setChild(this.mTop_1);
        setChild(this.mTop_2);
        setChild(this.mTop_3);
        this.mBottom_0_ampm = this.mBottom_0.getDescendant("timeline.am_pm");
        this.mBottom_1_ampm = this.mBottom_1.getDescendant("timeline.am_pm");
        this.mBottom_2_ampm = this.mBottom_2.getDescendant("timeline.am_pm");
        this.mBottom_3_ampm = this.mBottom_3.getDescendant("timeline.am_pm");
        this.mMaxNumber = maxNumber;
        findFlipControls(this.mBottom_0, 0);
        findFlipControls(this.mBottom_1, 1);
        findFlipControls(this.mTop_0, 2);
        findFlipControls(this.mTop_1, 3);
        this.mTilt = this.mRoot.getMarker("tilt");
    }

    public void doTiltChanged(float tilt) {
        float frame = WidgetHelper.convertTiltAngleToFrame(tilt, this.mTilt.StartFrame, this.mTilt.EndFrame);
        this.mRoot.setFrame(frame);
    }

    public void bind() {
        this.mRoot.getPlaybackCompleteSource().bind(this.mPlaybackListener);
    }

    public void unbind() {
        this.mRoot.getPlaybackCompleteSource().unbind(this.mPlaybackListener);
    }

    private void findFlipControls(FxTimelineControl timeline, int index) {
        String[] controls = {"timeline.first", "timeline.second", "timeline.center"};
        FxTimelineControl[] descendants = timeline.getDescendants(controls);
        this.mFlipControls[index][0] = descendants[0];
        this.mFlipControls[index][1] = descendants[1];
        this.mFlipControls[index][2] = descendants[2];
    }

    private class PlaybackCompleteListener extends MessageListener<FxPlaybackInfo> {
        private PlaybackCompleteListener() {
        }

        public void onMessageReceived(FxPlaybackInfo message) {
            DigitControl.this.mNextNumber = DigitControl.access$104(DigitControl.this) % DigitControl.this.mMaxNumber;
            DigitControl.this.nextNumber(DigitControl.this.mNextNumber);
        }
    }

    private void setChild(FxTimelineControl child) {
        if (!$assertionsDisabled && child == null) {
            throw new AssertionError();
        }
        child.setAsync(false);
        FxTimelineControl tile = child.getChildByType(FxTimelineControl.class);
        if (tile != null) {
            tile.setAsync(false);
        }
    }

    public void setCurrentNumber(int number) {
        int i = number % this.mMaxNumber;
        this.mCurrentNumber = i;
        this.mDestNumber = i;
        int digit1 = this.mCurrentNumber / 10;
        int digit2 = this.mCurrentNumber % 10;
        setDigit(2, digit1, digit2);
        setDigit(1, digit1, digit2);
        this.mRoot.playFrames(0, 0, 0, 1.0f, false);
        setDigit(3, digit1, digit2);
        setDigit(0, digit1, digit2);
        this.mRoot.playFrames(10, 10, 0, 1.0f, false);
    }

    public void setDestNumber(int number) {
        setDestNumber(number, 1);
    }

    public void setDestNumber(int number, int flipCount) {
        if (this.mDestNumber != number) {
            this.mDestNumber = number;
            this.mFlipCount = flipCount;
            if (flipCount == 2) {
                this.mNextNumber = ((this.mMaxNumber + number) - 1) % this.mMaxNumber;
            } else {
                this.mNextNumber = number;
            }
            if (flipCount == 2) {
                this.mPlaybackSpeed = 1.0f;
            } else {
                this.mPlaybackSpeed = 0.5f;
            }
            nextNumber(this.mNextNumber);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void nextNumber(int number) {
        if (this.mFlipCount != 0) {
            this.mFlipCount--;
            int digit1_old = this.mCurrentNumber / 10;
            int digit2_old = this.mCurrentNumber % 10;
            setDigit(1, digit1_old, digit2_old);
            setDigit(2, digit1_old, digit2_old);
            this.mRoot.playFrames(0, 0, 0, this.mPlaybackSpeed, false);
            int digit1_new = number / 10;
            int digit2_new = number % 10;
            setDigit(0, digit1_new, digit2_new);
            setDigit(3, digit1_new, digit2_new);
            this.mRoot.playFrames(0, 10, 0, this.mPlaybackSpeed, true);
            this.mCurrentNumber = number;
        }
    }

    private void setDigit(int index, int digit1, int digit2) {
        FxTimelineControl first = this.mFlipControls[index][0];
        FxTimelineControl second = this.mFlipControls[index][1];
        FxTimelineControl center = this.mFlipControls[index][2];
        if (center != null) {
            center.setFrame(digit2);
            boolean useDouble = (digit1 * 10) + digit2 >= 10 || this.mMaxNumber != 24;
            if (useDouble) {
                center.setVisibility(false);
                first.setVisibility(true);
                second.setVisibility(true);
            } else {
                first.setVisibility(false);
                second.setVisibility(false);
                center.setVisibility(true);
            }
        }
        first.setFrame(digit1);
        second.setFrame(digit2);
    }

    public void setAmPm(int ampm) {
        switch (ampm) {
            case -1:
                this.mBottom_0_ampm.setVisibility(false);
                this.mBottom_1_ampm.setVisibility(false);
                this.mBottom_2_ampm.setVisibility(false);
                this.mBottom_3_ampm.setVisibility(false);
                break;
            case 0:
                this.mBottom_0_ampm.setFrame(0.0f);
                this.mBottom_1_ampm.setFrame(0.0f);
                this.mBottom_2_ampm.setFrame(0.0f);
                this.mBottom_3_ampm.setFrame(0.0f);
                this.mBottom_0_ampm.setVisibility(true);
                this.mBottom_1_ampm.setVisibility(true);
                this.mBottom_2_ampm.setVisibility(true);
                this.mBottom_3_ampm.setVisibility(true);
                break;
            case 1:
                this.mBottom_0_ampm.setFrame(1.0f);
                this.mBottom_1_ampm.setFrame(1.0f);
                this.mBottom_2_ampm.setFrame(1.0f);
                this.mBottom_3_ampm.setFrame(1.0f);
                this.mBottom_0_ampm.setVisibility(true);
                this.mBottom_1_ampm.setVisibility(true);
                this.mBottom_2_ampm.setVisibility(true);
                this.mBottom_3_ampm.setVisibility(true);
                break;
        }
    }
}
