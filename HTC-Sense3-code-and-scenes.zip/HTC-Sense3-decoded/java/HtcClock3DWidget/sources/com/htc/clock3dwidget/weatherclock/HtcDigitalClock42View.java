package com.htc.clock3dwidget.weatherclock;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.format.DateFormat;
import com.htc.android.rosie.widget.Widget;
import com.htc.clock.util.MyLog;
import com.htc.clock3dwidget.util.DigitControl;
import com.htc.clock3dwidget.util.MyProjectSetting;
import com.htc.fusion.fx.controls.FxTextLabel;
import java.util.Calendar;
import java.util.TimeZone;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class HtcDigitalClock42View extends WeatherView {
    private static boolean mB24hourFormat = false;
    protected final int ANIMATION_HOUR_COUNT;
    protected final int ANIMATION_MINUTE_COUNT;
    protected final String[] ClockFormats;
    protected boolean mBListenTimeZoneChanged;
    private boolean mBUpdateFomate;
    protected Calendar mCalendar;
    private String mDateFormat;
    protected FxTextLabel mDigital_Data;
    protected DigitControl mDigital_Hour;
    protected DigitControl mDigital_Minute;
    private boolean mFlipAnimePrepared;
    protected int mHour;
    private BroadcastReceiver mIntentReceiver;
    private int mLogCount;
    protected int mMinuteFlipCount;
    protected int mMinutes;
    protected int mOldHour;
    protected int mOldMinutes;
    protected boolean mPaused;
    public boolean mReceiverRegistered;
    private StringBuffer mTimeZoneChangedLog;
    private Widget.Host.Worker mUIHandler;
    public boolean mUseAnimation;
    private boolean m_bAutoSyn;
    private TelephonyManager m_telephonyManager;
    protected TimeZone tz;

    HtcDigitalClock42View(Context context, WeatherClockWidgetView widget, Widget.Host host) {
        super(context, widget, host);
        this.mOldHour = 0;
        this.mOldMinutes = 0;
        this.mMinutes = 0;
        this.mHour = 0;
        this.mPaused = true;
        this.ANIMATION_HOUR_COUNT = 1;
        this.ANIMATION_MINUTE_COUNT = 2;
        this.ClockFormats = new String[]{"EE, MM-dd", "EE, dd-MM", "EE, MMM dd", "EE, dd-MMM", "EE, MM-dd", "EE, MMM dd"};
        this.mUseAnimation = MyProjectSetting.isFlipEnable();
        this.mFlipAnimePrepared = false;
        this.mReceiverRegistered = false;
        this.mIntentReceiver = new BroadcastReceiver() { // from class: com.htc.clock3dwidget.weatherclock.HtcDigitalClock42View.1
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context2, Intent intent) {
                Message msg = HtcDigitalClock42View.this.mUIHandler.obtainMessage();
                msg.obj = intent;
                HtcDigitalClock42View.this.mUIHandler.send(msg);
            }
        };
        this.mBListenTimeZoneChanged = true;
        this.mLogCount = 0;
        this.mDateFormat = null;
        this.mBUpdateFomate = false;
        this.m_bAutoSyn = true;
        this.m_telephonyManager = null;
        this.mUIHandler = host.getWorker(new UIHandler());
    }

    private class UIHandler implements Handler.Callback {
        private UIHandler() {
        }

        @Override // android.os.Handler.Callback
        public boolean handleMessage(Message m) {
            Intent intent = (Intent) m.obj;
            if (intent == null) {
                return false;
            }
            PowerManager pm = (PowerManager) HtcDigitalClock42View.this.mContext.getSystemService("power");
            if (intent.getAction().equals("android.intent.action.TIME_TICK") && !pm.isScreenOn()) {
                return false;
            }
            MyLog.i("weatherClock onReceive~ action:" + intent.getAction() + " mPaused:" + HtcDigitalClock42View.this.mPaused);
            if (intent.getAction().equals("android.intent.action.TIMEZONE_CHANGED")) {
                MyLog.i("receive ACTION_TIMEZONE_CHANGED mBListenTimeZoneChanged:" + HtcDigitalClock42View.this.mBListenTimeZoneChanged);
                if (HtcDigitalClock42View.this.mBListenTimeZoneChanged) {
                    String changeTz = intent.getStringExtra("time-zone");
                    HtcDigitalClock42View.this.setTimeZone(changeTz);
                }
            }
            if (HtcDigitalClock42View.this.mFlipAnimePrepared) {
                HtcDigitalClock42View.this.prepareAnimation();
            }
            if (!HtcDigitalClock42View.this.mPaused) {
                HtcDigitalClock42View.this.onTimeChanged();
            }
            return true;
        }
    }

    public void init() {
        if (!this.mReceiverRegistered) {
            IntentFilter filter = new IntentFilter();
            filter.addAction("android.intent.action.TIME_SET");
            filter.addAction("android.intent.action.TIMEZONE_CHANGED");
            filter.addAction("android.intent.action.TIME_TICK");
            filter.addAction("android.intent.action.SCREEN_ON");
            this.mContext.registerReceiver(this.mIntentReceiver, filter);
            this.mReceiverRegistered = true;
        }
    }

    public void deInit() {
        if (this.mReceiverRegistered) {
            try {
                this.mContext.unregisterReceiver(this.mIntentReceiver);
            } catch (NullPointerException e) {
                e.getStackTrace();
            }
            this.mIntentReceiver = null;
            this.mReceiverRegistered = false;
        }
    }

    @Override // com.htc.clock3dwidget.weatherclock.WeatherView
    public void clear() {
        this.mPaused = true;
        deInit();
    }

    public void setData() {
        String format;
        if (this.mDigital_Data != null && (format = getDateFormat()) != null) {
            String text = DateFormat.format(format, this.mCalendar).toString();
            this.mDigital_Data.setString(text);
        }
    }

    void updateCurrentTime() {
        this.mOldHour = this.mHour;
        this.mOldMinutes = this.mMinutes;
        this.mCalendar = getCalendarNow();
        this.mCalendar.setTimeInMillis(System.currentTimeMillis());
        this.mMinutes = this.mCalendar.get(12);
        this.mHour = this.mCalendar.get(10);
        if (is24HourFormat()) {
            if (this.mCalendar.get(9) == 1) {
                this.mHour += 12;
            }
            if (this.mDigital_Hour != null) {
                this.mDigital_Hour.setAmPm(-1);
            }
        } else {
            if (this.mHour == 0) {
                this.mHour = 12;
            }
            if (this.mDigital_Hour != null) {
                this.mDigital_Hour.setAmPm(this.mCalendar.get(9));
            }
        }
        setData();
    }

    public void clearAnimations() {
        clearAnimations(this.mHour, this.mMinutes);
    }

    public void clearAnimations(int hour, int minutes) {
        if (!this.mUseAnimation) {
        }
    }

    public void onTimeChanged() {
        onTimeChanged(true);
    }

    public void onTimeChanged(boolean bUseAnimation) {
        if (this.mPaused) {
            MyLog.w("onTimeChanged~ mPaused is true");
        }
        if (this.mCalendar == null) {
            MyLog.w("onTimeChanged mCalendar null");
        }
        updateCurrentTime();
        if (this.mHour != this.mOldHour || this.mMinutes != this.mOldMinutes) {
            clearAnimations(this.mOldHour, this.mOldMinutes);
        }
        this.mMinuteFlipCount = 1;
        if (!this.mUseAnimation) {
            MyLog.i("onTimeChanged~ mHour:" + this.mHour + " mMinutes:" + this.mMinutes);
            if (this.mDigital_Hour != null && this.mDigital_Minute != null) {
                this.mDigital_Hour.setCurrentNumber(this.mHour);
                this.mDigital_Minute.setCurrentNumber(this.mMinutes);
                return;
            }
            return;
        }
        if (bUseAnimation) {
            applyRotationTest();
            return;
        }
        MyLog.i("onTimeChanged~ mHour:" + this.mHour + " mMinutes:" + this.mMinutes);
        if (this.mDigital_Hour != null && this.mDigital_Minute != null) {
            this.mDigital_Hour.setCurrentNumber(this.mHour);
            this.mDigital_Minute.setCurrentNumber(this.mMinutes);
        }
    }

    public void setTimeZone(String timezone) {
        synchronized (this) {
            if (timezone != null) {
                if (timezone.length() > 0) {
                    this.tz = TimeZone.getTimeZone(timezone);
                    this.mCalendar = Calendar.getInstance(this.tz);
                    MyLog.i("setTimeZone~ time zone id=" + this.tz.getID());
                }
            }
            this.tz = TimeZone.getDefault();
            this.mCalendar = Calendar.getInstance();
            MyLog.i("setTimeZone~ time zone id=" + this.tz.getID());
        }
    }

    private void increaseHour() {
        this.mHour++;
        if (is24HourFormat()) {
            this.mHour %= 24;
        } else if (this.mHour > 12) {
            this.mHour -= 12;
        }
    }

    public void testAnimation() {
        clearAnimations();
        this.mOldHour = this.mHour;
        this.mOldMinutes = this.mMinutes;
        this.mMinutes = (this.mMinutes + 1) % 60;
        if (this.mMinutes % 3 == 0) {
            increaseHour();
        }
        applyRotation();
    }

    private void applyRotation() {
        if (this.mDigital_Hour != null && this.mDigital_Minute != null) {
            this.mDigital_Hour.setDestNumber(this.mHour);
            this.mDigital_Minute.setDestNumber(this.mMinutes, 2);
        }
    }

    public void setPause(boolean value) {
        setPause(value, true);
    }

    public void setPause(boolean value, boolean bTimeChanged) {
        MyLog.i("setPause~ mPaused:" + value);
        this.mPaused = value;
        if (!this.mPaused && bTimeChanged) {
            onTimeChanged();
        }
    }

    public boolean isPaused() {
        return this.mPaused;
    }

    public void startAnimation() {
        startAnimation(false);
    }

    public void startAnimation(boolean bPause) {
        this.mPaused = bPause;
        if (this.mUseAnimation) {
            if (!this.mFlipAnimePrepared) {
                onTimeChanged();
                return;
            }
            MyLog.i("startAnimation~");
            this.mCalendar = getCalendarNow();
            this.mMinutes = this.mCalendar.get(12);
            this.mHour = this.mCalendar.get(10);
            if (is24HourFormat()) {
                if (this.mCalendar.get(9) == 1) {
                    this.mHour += 12;
                }
                if (this.mDigital_Hour != null) {
                    this.mDigital_Hour.setAmPm(-1);
                }
            } else {
                if (this.mHour == 0) {
                    this.mHour = 12;
                }
                if (this.mDigital_Hour != null) {
                    this.mDigital_Hour.setAmPm(this.mCalendar.get(9));
                }
            }
            setData();
            this.mMinuteFlipCount = 2;
            applyRotation();
            this.mFlipAnimePrepared = false;
        }
    }

    public void prepareAnimation() {
        if (this.mUseAnimation) {
            clearAnimations();
            this.mCalendar = getCalendarNow();
            this.mMinutes = this.mCalendar.get(12);
            this.mHour = this.mCalendar.get(10);
            if (is24HourFormat()) {
                if (this.mCalendar.get(9) == 1) {
                    this.mHour += 12;
                }
                if (this.mDigital_Hour != null) {
                    this.mDigital_Hour.setAmPm(-1);
                }
                this.mOldHour = ((this.mHour + 24) - 1) % 24;
            } else {
                if (this.mHour == 0) {
                    this.mHour = 12;
                }
                if (this.mDigital_Hour != null) {
                    this.mDigital_Hour.setAmPm(this.mCalendar.get(9));
                }
                this.mOldHour = ((this.mHour + 12) - 1) % 12;
                if (this.mOldHour == 0) {
                    this.mOldHour = 12;
                }
            }
            setData();
            this.mOldMinutes = ((this.mMinutes + 60) - 2) % 60;
            if (this.mDigital_Hour != null && this.mDigital_Minute != null) {
                this.mDigital_Hour.setCurrentNumber(this.mOldHour);
                this.mDigital_Minute.setCurrentNumber(this.mOldMinutes);
            }
            MyLog.i("prepareAnimation~ mOldHour:" + this.mOldHour + " mOldMinutes:" + this.mOldMinutes);
            this.mFlipAnimePrepared = true;
        }
    }

    public boolean isPreparedFlip() {
        return this.mFlipAnimePrepared;
    }

    public TimeZone getTimeZone() {
        return this.tz;
    }

    public void setListenTimeZoneChanged(boolean bListen) {
        this.mBListenTimeZoneChanged = bListen;
    }

    public boolean getListenTimeZoneChanged() {
        return this.mBListenTimeZoneChanged;
    }

    public void printLog() {
        if (this.mTimeZoneChangedLog != null) {
            MyLog.i(this.mTimeZoneChangedLog.toString());
        }
    }

    public Calendar getCalendarNow() {
        if (this.mBListenTimeZoneChanged) {
            Calendar calendar = Calendar.getInstance();
            return calendar;
        }
        Calendar calendar2 = Calendar.getInstance(this.tz);
        return calendar2;
    }

    public String getDateFormat() {
        return this.mDateFormat;
    }

    public void updateDateFormat() {
        String format = Settings.System.getString(this.mContext.getContentResolver(), "date_format_short");
        if (format != null && format.length() > 0) {
            this.mDateFormat = format;
        }
    }

    public boolean is24HourFormat() {
        return mB24hourFormat;
    }

    public void update24HourFormat() {
        mB24hourFormat = DateFormat.is24HourFormat(this.mContext);
    }

    public void updateFormat() {
        updateDateFormat();
        update24HourFormat();
        this.mBUpdateFomate = true;
    }

    public void checkSystemAutoSynTimezone() {
        this.m_bAutoSyn = isTimeAutoState();
        MyLog.i("checkSystemAutoSynTimezone~ m_bAutoSyn:" + this.m_bAutoSyn);
    }

    public boolean isTimezoneAutoSyn() {
        return this.m_bAutoSyn;
    }

    public boolean isTimeAutoState() {
        try {
            return Settings.System.getInt(this.mContext.getContentResolver(), "auto_time") > 0;
        } catch (Settings.SettingNotFoundException e) {
            return true;
        }
    }

    public boolean isSimExist() {
        if (this.m_telephonyManager == null) {
            this.m_telephonyManager = (TelephonyManager) this.mContext.getSystemService("phone");
        }
        int simState = this.m_telephonyManager.getSimState();
        return (simState == 1 || simState == 0) ? false : true;
    }

    protected void applyRotationTest() {
        this.mCalendar.setTimeInMillis(System.currentTimeMillis());
        this.mMinutes = this.mCalendar.get(12);
        this.mHour = this.mCalendar.get(10);
        if (is24HourFormat()) {
            if (this.mCalendar.get(9) == 1) {
                this.mHour += 12;
            }
            this.mOldHour = ((this.mHour + 24) - 1) % 24;
        } else {
            if (this.mHour == 0) {
                this.mHour = 12;
            }
            this.mOldHour = ((this.mHour + 12) - 1) % 12;
            if (this.mOldHour == 0) {
                this.mOldHour = 12;
            }
        }
        if (!this.mPaused && this.mDigital_Hour != null && this.mDigital_Minute != null) {
            this.mDigital_Hour.setDestNumber(this.mHour);
            this.mDigital_Minute.setDestNumber(this.mMinutes);
        }
    }

    public void skinApply() {
    }
}
