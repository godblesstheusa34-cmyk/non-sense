package com.htc.clock3dwidget;

import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import com.htc.clock.util.MyLog;
import com.htc.widget.HtcListView;
import com.htc.widget.Title1;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class ResUtils {
    public static final int CLOCK_LAYOUT_ID = 2130903040;
    public static final int CLOCK_LISTVIEW_ID = 2131296258;
    public static final int CLOCK_TITLE_ID = 2131099689;
    public static final boolean DELETE_ADD_CITY = false;
    public static final String M10_CLOCK_03 = "Pyramid_Clock_03.m10";
    public static final String M10_CLOCK_04 = "Pyramid_Clock_04.m10";
    public static final String M10_CLOCK_05 = "Pyramid_Clock_05.m10";
    public static final String M10_CLOCK_06 = "Pyramid_Clock_06.m10";
    public static final String M10_CLOCK_07 = "Pyramid_Clock_07.m10";
    public static final String M10_CLOCK_08 = "Pyramid_Clock_08.m10";
    public static final String M10_CLOCK_09 = "Pyramid_Clock_09.m10";
    public static final String M10_CLOCK_10 = "Pyramid_Clock_10.m10";
    public static final String M10_CLOCK_1x1 = "Pyramid_Clock_Worldclock.m10";
    public static final String M10_CLOCK_2x2 = "Pyramid_Clock_2x2.m10";
    public static final String M10_CLOCK_BEAM = "Pyramid_Clock_Beam.m10";
    public static final String M10_CLOCK_DIGITAL = "Pyramid_Clock_Digital.m10";
    public static final String M10_CLOCK_DUAL = "Pyramid_Clock_Dual.m10";
    public static final String M10_CLOCK_RING = "Pyramid_Clock_Ring.m10";
    public static final String M10_CLOCK_SOCIAL = "Pyramid_Clock_Weather_social_4x2.m10";
    public static final String M10_CLOCK_SPIN_CYCLE = "Pyramid_Clock_SpinCycle.m10";
    public static final String M10_CLOCK_WEATHER = "Pyramid_Clock_Weather_4x2.m10";
    public static final String M10_LOCKSCREEN_CONTAINER = "Pyramid_Lockscreen_clock.m10";
    public static final String M10_LOCKSCREEN_RING_MOTION = "Pyramid_Lock_ring_motion.m10";
    public static final boolean NO_TOP_ROUND = false;
    public static final boolean WIGGLE_LOOPING = false;
    public static final int WWP_LAYOUT_ID = 2130903041;
    public static final int WWP_LISTVIEW_ID = 2131296260;
    public static final int WWP_TITLE_ID = 2131099685;

    public static void setupView(Activity activity, int layoutId, int listViewId, int titleStringId, int type) {
        activity.setContentView(layoutId);
        try {
            Title1 title = activity.findViewById(R.id.title);
            if (title != null) {
                title.disablePulldownButton();
                title.setRightButtonImage2(34080485);
                if (type == 4) {
                    title.setLeftTitle(R.string.select_city_first);
                } else if (type == 7) {
                    title.setLeftTitle(R.string.select_city_second);
                } else {
                    title.setLeftTitle(titleStringId);
                }
            }
        } catch (Exception e) {
            MyLog.e("onCreate~ set title exception:" + e.getMessage());
        }
    }

    public static void setupWWPView(Activity activity, int layoutId, int listViewId, int titleStringId, int type) {
        activity.setContentView(layoutId);
        try {
            Title1 title = activity.findViewById(R.id.title);
            if (title != null) {
                if (type == 4) {
                    title.setTitle1(R.string.select_city_first);
                } else if (type == 7) {
                    title.setTitle1(R.string.select_city_second);
                } else {
                    title.setTitle1(titleStringId);
                }
            }
        } catch (Exception e) {
            MyLog.e("onCreate~ set title exception:" + e.getMessage());
        }
    }

    public static void addHeaderView(Activity activity, HtcListView listview, View.OnClickListener addClickListener) {
        try {
            Title1 title = activity.findViewById(R.id.title);
            if (title != null) {
                ImageButton btnAdd = (ImageButton) title.findViewById(33686060);
                btnAdd.setOnClickListener(addClickListener);
            }
        } catch (Exception e) {
            MyLog.e("onCreate~ set title exception:" + e.getMessage());
        }
    }

    public static void setupButton(Activity activity, View.OnClickListener l) {
        try {
            Button button = (Button) activity.findViewById(33685505);
            if (button != null) {
                button.setText(R.string.done);
                button.setOnClickListener(l);
            }
        } catch (Exception e) {
            MyLog.e("onCreate~ set button exception:" + e.getMessage());
        }
    }
}
