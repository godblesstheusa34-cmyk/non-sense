package com.htc.clock3dwidget.setting;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.htc.clock.util.MyLog;
import com.htc.clock3dwidget.R;
import com.htc.clock3dwidget.ResUtils;
import com.htc.clock3dwidget.util.Constants;
import com.htc.clock3dwidget.util.MyProjectSetting;
import com.htc.util.skin.HtcSkinUtil;
import com.htc.util.weather.WeatherLocation;
import com.htc.util.weather.WeatherUtility;
import com.htc.widget.HtcAdapterView;
import com.htc.widget.HtcAlertDialog;
import com.htc.widget.HtcListView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class HtcClockSetting extends Activity implements View.OnClickListener {
    private static final int CITY_LIST_ITEM_FULL = 97;
    protected static final String KEY_DISPLAYNAME = "name";
    protected static final String KEY_GMT = "gmt";
    protected static final String KEY_ID = "id";
    protected static final String KEY_SECONDCITY = "second_city";
    public static final String TAG = "HtcClockSettings";
    protected static final String XMLTAG_TIMEZONE = "timezone";
    private LinearLayout layoutList;
    private LinearLayout layoutListCities;
    private CheckBox mCheckImg;
    private int mCusFolderId;
    private String mCusFolderName;
    private View mDisplayCityName;
    private TimeZoneAdapter mTimeZoneAdapter;
    private HtcListView mTimeZoneList;
    private final int ADD_CITY = 1;
    private final int WWP_SETTING = 2;
    private final int DUAL_SETTING = 3;
    private List<HashMap<String, String>> mAllDataList = new ArrayList();
    private WeatherLocation[] mLocs = null;
    private int mWidgetType = 3;
    private boolean mShowCurrentCity = true;
    private boolean mIsCustomer = false;
    private HtcAdapterView.OnItemClickListener listener = new HtcAdapterView.OnItemClickListener() { // from class: com.htc.clock3dwidget.setting.HtcClockSetting.1
        public void onItemClick(HtcAdapterView<?> parent, View view, int position, long id) {
            String cityname;
            int index = (int) HtcClockSetting.this.mTimeZoneAdapter.getItemId(position);
            MyLog.i("onItemClick~ index:" + index + " position:" + position + " id:" + id);
            if (HtcClockSetting.this.mDisplayCityName.getVisibility() != 0 || index != 0) {
                if (HtcClockSetting.this.mDisplayCityName.getVisibility() == 0) {
                    index--;
                }
                if (index >= 0) {
                    Intent intent = HtcClockSetting.this.getIntent();
                    boolean bCityReset = intent.getBooleanExtra(Constants.WIDGET_RESET, false);
                    HashMap<String, String> map = (HashMap) HtcClockSetting.this.mAllDataList.get(index);
                    int tmpindex = index;
                    if (MyProjectSetting.hasCurrentLocation() && !bCityReset) {
                        tmpindex--;
                    }
                    if (HtcClockSetting.this.mWidgetType == 4 || HtcClockSetting.this.mWidgetType == 7) {
                        tmpindex--;
                    }
                    if (HtcClockSetting.this.getResources().getString(R.string.current_location).equals(map.get(HtcClockSetting.KEY_DISPLAYNAME))) {
                        cityname = Constants.CURRENT_CITY;
                    } else if (HtcClockSetting.this.getResources().getString(R.string.home).equals(map.get(HtcClockSetting.KEY_DISPLAYNAME)) && map.get(HtcClockSetting.KEY_ID) == null) {
                        cityname = Constants.HOME_CITY;
                    } else if (tmpindex > -1 && tmpindex < HtcClockSetting.this.mLocs.length) {
                        cityname = HtcClockSetting.this.mLocs[tmpindex].getCode();
                    } else {
                        String cityname2 = map.get(HtcClockSetting.KEY_DISPLAYNAME);
                        cityname = cityname2;
                    }
                    if (HtcClockSetting.this.mWidgetType == 7) {
                        intent.putExtra(Constants.KEY_SELECT_CITY_CODE2, cityname);
                    } else {
                        intent.putExtra(Constants.KEY_SELECT_CITY_CODE, cityname);
                        intent.putExtra(Constants.KEY_DISPLAY_CITY_NAME, HtcClockSetting.this.mShowCurrentCity);
                    }
                    if (HtcClockSetting.this.mWidgetType != 4) {
                        if (HtcClockSetting.this.mWidgetType == 3) {
                            if (tmpindex > -1) {
                                WeatherLocation loc = HtcClockSetting.this.mLocs[tmpindex];
                                intent.putExtra("Unit", 0);
                                intent.putExtra("name_", loc.getName());
                                intent.putExtra("state_", loc.getState());
                                intent.putExtra("country_", loc.getCountry());
                                intent.putExtra(Constants.KEY_SELECT_CITY_CODE, loc.getCode());
                                intent.putExtra("latitude_", loc.getLatitude());
                                intent.putExtra("longitude_", loc.getLongitude());
                                intent.putExtra("timezone_", loc.getTimezoneId());
                                intent.putExtra("app_", loc.getApp());
                                intent.putExtra("currentLocation", false);
                            } else {
                                intent.putExtra("currentLocation", true);
                            }
                            if (!bCityReset) {
                                if (MyProjectSetting.hasWeatherWallpaper()) {
                                    Intent wwpIntent = new Intent("OpenWWPSettings");
                                    wwpIntent.setClassName(Constants.SETTING_PACKAGE, Constants.SETTING_WWP_CLASS);
                                    wwpIntent.putExtras(intent);
                                    HtcClockSetting.this.startActivityForResult(wwpIntent, 2);
                                    return;
                                }
                                intent.putExtra(Constants.WWP_PLAY, false);
                            }
                        }
                        if (HtcClockSetting.this.mIsCustomer) {
                            intent.putExtra(Constants.KEY_FOLDER, HtcClockSetting.this.mCusFolderName);
                            intent.putExtra(Constants.KEY_PARENTFOLDERID, HtcClockSetting.this.mCusFolderId);
                        }
                        HtcClockSetting.this.setResult(-1, intent);
                        HtcClockSetting.this.finish();
                        return;
                    }
                    Intent dualIntent = new Intent(Constants.ACTION_INTENT_SETTING);
                    dualIntent.setClassName(Constants.SETTING_PACKAGE, Constants.SETTING_CLASS);
                    dualIntent.putExtras(intent);
                    dualIntent.putExtra(Constants.WIDGET_TYPE, 7);
                    HtcClockSetting.this.startActivityForResult(dualIntent, 3);
                    return;
                }
                return;
            }
            HtcClockSetting.this.mShowCurrentCity = !HtcClockSetting.this.mShowCurrentCity;
            HtcClockSetting.this.mCheckImg.setChecked(HtcClockSetting.this.mShowCurrentCity);
            MyLog.i("onItemClick~ mShowCurrentCity");
        }
    };

    @Override // android.app.Activity
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case CITY_LIST_ITEM_FULL /* 97 */:
                return new HtcAlertDialog.Builder(this).setTitle(getString(R.string.add_city_error_title)).setIcon(android.R.drawable.ic_dialog_alert).setMessage(getString(R.string.add_city_error_msg)).setNeutralButton(R.string.ok, new DialogInterface.OnClickListener() { // from class: com.htc.clock3dwidget.setting.HtcClockSetting.2
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int whichButton) {
                    }
                }).create();
            default:
                return null;
        }
    }

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            this.mWidgetType = savedInstanceState.getInt(Constants.WIDGET_TYPE, 3);
            this.mShowCurrentCity = savedInstanceState.getBoolean(Constants.KEY_DISPLAY_CITY_NAME, true);
            if (this.mWidgetType == 6) {
                this.mIsCustomer = true;
                this.mCusFolderId = savedInstanceState.getInt(Constants.KEY_PARENTFOLDERID, -1);
                this.mCusFolderName = savedInstanceState.getString(Constants.KEY_FOLDER);
            }
        } else {
            Intent intent = getIntent();
            this.mWidgetType = intent.getIntExtra(Constants.WIDGET_TYPE, 3);
            this.mShowCurrentCity = intent.getBooleanExtra(Constants.KEY_DISPLAY_CITY_NAME, true);
            if (this.mWidgetType == 6) {
                this.mIsCustomer = true;
                this.mCusFolderId = intent.getIntExtra(Constants.KEY_PARENTFOLDERID, -1);
                this.mCusFolderName = intent.getStringExtra(Constants.KEY_FOLDER);
            }
        }
        ResUtils.setupView(this, 2130903040, 2131296258, 2131099689, this.mWidgetType);
        this.mTimeZoneList = findViewById(2131296258);
        int list_selector = HtcSkinUtil.getDrawableResIdentifier(this, "list_selector_background", 34078814);
        this.mTimeZoneList.setSelector(list_selector);
        this.mDisplayCityName = getLayoutInflater().inflate(34144387, (ViewGroup) null);
        TextView displayCityView = (TextView) this.mDisplayCityName.findViewById(33685520);
        if (displayCityView != null) {
            displayCityView.setText(R.string.check_box_show_city_name);
        }
        this.mCheckImg = (CheckBox) this.mDisplayCityName.findViewById(33685535);
        this.mCheckImg.setChecked(this.mShowCurrentCity);
        this.mCheckImg.setVisibility(0);
        if (this.mWidgetType == 3 || this.mWidgetType == 7) {
            this.mDisplayCityName.setVisibility(8);
        }
        ResUtils.addHeaderView(this, this.mTimeZoneList, this);
        if (this.mDisplayCityName.getVisibility() == 0) {
            if (MyProjectSetting.hasSeparateLine2()) {
                this.mDisplayCityName.setTag(new HtcCitySeparable());
            }
            this.mTimeZoneList.addHeaderView(this.mDisplayCityName, (Object) null, true);
        }
        loadWorldClockCity();
    }

    private void action_add_city() {
        this.mLocs = WeatherUtility.loadLocations(getContentResolver(), Constants.APP_WORLD_CLOCK);
        if (this.mLocs.length >= 15) {
            showDialog(CITY_LIST_ITEM_FULL);
            return;
        }
        Intent intent = new Intent();
        intent.setClassName(Constants.APP_WORLD_CLOCK, "com.htc.android.worldclock.TimeZonePicker");
        intent.putExtra("search_intention", 1);
        startActivityForResult(intent, 1);
    }

    private void loadWorldClockCity() {
        this.mAllDataList = getWorldClockCity();
        this.mTimeZoneAdapter = new TimeZoneAdapter(this, this.mAllDataList);
        this.mTimeZoneList.setAdapter(this.mTimeZoneAdapter);
        this.mTimeZoneList.setOnItemClickListener(this.listener);
    }

    @Override // android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 2) {
            if (resultCode == -1) {
                setResult(-1, data);
                finish();
                return;
            }
            return;
        }
        if (requestCode == 3) {
            if (resultCode == -1) {
                setResult(-1, data);
                finish();
                return;
            }
            return;
        }
        if (requestCode == 1 && resultCode == -1) {
            loadWorldClockCity();
        }
    }

    private List<HashMap<String, String>> getWorldClockCity() {
        List<HashMap<String, String>> myData = new ArrayList<>();
        Intent intent = getIntent();
        boolean bCityReset = intent.getBooleanExtra(Constants.WIDGET_RESET, false);
        if (MyProjectSetting.hasCurrentLocation() && !bCityReset) {
            HashMap<String, String> map = new HashMap<>();
            map.put(KEY_ID, null);
            map.put(KEY_DISPLAYNAME, getResources().getString(R.string.current_location));
            myData.add(map);
        }
        if (this.mWidgetType == 4 || this.mWidgetType == 7) {
            HashMap<String, String> map2 = new HashMap<>();
            map2.put(KEY_ID, null);
            map2.put(KEY_DISPLAYNAME, getResources().getString(R.string.home));
            myData.add(map2);
        }
        String[] apps = {Constants.APP_WORLD_CLOCK};
        this.mLocs = WeatherUtility.loadMultiAppLocations(getContentResolver(), apps);
        if (this.mLocs.length > 0) {
            for (int i = 0; i < this.mLocs.length; i++) {
                HashMap<String, String> map3 = new HashMap<>();
                map3.put(KEY_ID, this.mLocs[i].getTimezoneId());
                map3.put(KEY_DISPLAYNAME, this.mLocs[i].getName());
                if (!myData.contains(map3)) {
                    myData.add(map3);
                }
            }
        }
        return myData;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        action_add_city();
    }

    @Override // android.app.Activity
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean(Constants.KEY_DISPLAY_CITY_NAME, this.mShowCurrentCity);
        outState.putInt(Constants.WIDGET_TYPE, this.mWidgetType);
        if (this.mWidgetType == 6) {
            outState.putInt(Constants.KEY_DISPLAY_CITY_NAME, this.mCusFolderId);
            outState.putString(Constants.WIDGET_TYPE, this.mCusFolderName);
        }
    }
}
