package com.htc.clock3dwidget.setting;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.htc.clock3dwidget.util.MyProjectSetting;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class TimeZoneAdapter extends BaseAdapter {
    private Context mContext;
    private List<HashMap<String, String>> mDataList;
    private LayoutInflater mInflater;
    private boolean showAll = true;
    private ArrayList<Integer> mIndexArray = new ArrayList<>();
    private ArrayList<Integer> mFilterIndexArray = new ArrayList<>();
    private final String KEY_NAME = "name";
    private final String KEY_CITY = "second_city";

    public TimeZoneAdapter(Context context, List<HashMap<String, String>> data) {
        this.mContext = context;
        this.mInflater = (LayoutInflater) context.getSystemService("layout_inflater");
        this.mDataList = data;
    }

    public void setDataList(List<HashMap<String, String>> data) {
        this.mDataList = data;
        notifyDataSetChanged();
    }

    @Override // android.widget.Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        View v;
        int index;
        HashMap<String, String> map;
        if (convertView == null) {
            v = this.mInflater.inflate(34144263, parent, false);
        } else {
            v = convertView;
        }
        TextView vCity = (TextView) v.findViewById(33685520);
        if (this.showAll) {
            index = position;
        } else {
            index = this.mIndexArray.size() > 0 ? this.mIndexArray.get(position).intValue() : -1;
        }
        if (MyProjectSetting.hasSeparateLine2()) {
            if (index == 0) {
                v.setTag(new HtcCitySeparable());
            } else {
                v.setTag(null);
            }
        }
        if (index != -1 && (map = this.mDataList.get(index)) != null) {
            vCity.setText(map.get("name"));
        }
        return v;
    }

    @Override // android.widget.Adapter
    public final long getItemId(int position) {
        return (this.showAll || this.mIndexArray.size() <= 0) ? position : this.mIndexArray.get(position).intValue();
    }

    @Override // android.widget.Adapter
    public final Object getItem(int position) {
        return (this.showAll || this.mIndexArray.size() <= 0) ? this.mDataList.get(position) : this.mDataList.get(this.mIndexArray.get(position).intValue());
    }

    @Override // android.widget.Adapter
    public final int getCount() {
        return this.showAll ? this.mDataList.size() : this.mIndexArray.size();
    }

    public final char getCurrentFirstLetter(int firstVisibleItem) {
        int index;
        if (!this.showAll && this.mIndexArray.size() > 0) {
            index = this.mIndexArray.get(firstVisibleItem).intValue();
        } else {
            index = firstVisibleItem;
        }
        HashMap<String, String> map = this.mDataList.get(index);
        if (map == null) {
            return ' ';
        }
        String name = map.get("name");
        return name.charAt(0);
    }

    public int updateList(String prefix) {
        int len = prefix.length();
        if (len == 0) {
            this.showAll = true;
            this.mIndexArray.clear();
            this.mFilterIndexArray.clear();
        } else if (len == 1) {
            if (this.showAll) {
                this.showAll = false;
                String prefix2 = prefix.toUpperCase();
                for (int i = 0; i < this.mDataList.size(); i++) {
                    HashMap<String, String> map = this.mDataList.get(i);
                    if (map != null) {
                        String name = map.get("name");
                        String city = map.get("second_city") != null ? map.get("second_city").toString() : null;
                        if (name.startsWith(prefix2) || (city != null && city.startsWith(prefix2))) {
                            this.mFilterIndexArray.add(Integer.valueOf(i));
                        }
                    }
                }
            }
            this.mIndexArray = this.mFilterIndexArray;
        } else {
            this.mIndexArray.clear();
            String firstCh = "" + prefix.charAt(0);
            String prefix3 = firstCh.toUpperCase() + prefix.substring(1);
            for (int i2 = 0; i2 < this.mFilterIndexArray.size(); i2++) {
                int index = this.mFilterIndexArray.get(i2).intValue();
                HashMap<String, String> map2 = this.mDataList.get(index);
                if (map2 != null) {
                    String name2 = map2.get("name");
                    String city2 = map2.get("second_city") != null ? map2.get("second_city") : null;
                    if (name2.startsWith(prefix3) || (city2 != null && city2.startsWith(prefix3))) {
                        this.mIndexArray.add(Integer.valueOf(index));
                    }
                }
            }
        }
        return this.mIndexArray.size();
    }
}
