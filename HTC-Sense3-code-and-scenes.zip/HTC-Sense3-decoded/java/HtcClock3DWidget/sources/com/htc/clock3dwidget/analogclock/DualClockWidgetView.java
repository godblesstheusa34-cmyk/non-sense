package com.htc.clock3dwidget.analogclock;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Message;
import com.htc.android.rosie.widget.Widget;
import com.htc.clock.util.MyLog;
import com.htc.clock3dwidget.ClockRes;
import com.htc.clock3dwidget.ClockUtils;
import com.htc.clock3dwidget.analogclock.AnalogClockWidget;
import com.htc.clock3dwidget.util.Constants;
import com.htc.fusion.fx.FxScene;
import java.net.URISyntaxException;
import java.util.Properties;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class DualClockWidgetView extends Widget.Base {
    private static final String TAG = DualClockWidgetView.class.getSimpleName();
    private static final boolean localLOGV = false;
    private AnalogClockWidget mAnalogClockCurrent;
    private AnalogClockWidget mAnalogClockHome;
    protected ClockRes mClockResCurrent;
    protected ClockRes mClockResHome;
    private ClockConfig mConfigCurrent;
    private ClockConfig mConfigHome;
    private FxScene mSceneLand;
    private FxScene mScenePort;
    private int mOrientation = 1;
    private boolean mLoadConfig = false;
    private boolean mInitCreate = false;
    private boolean mInitResume = false;
    private boolean mInitPause = false;
    private Object mInitLock = new Object();
    private AnalogClockWidget.InstanceCallback mHomeCallback = new AnalogClockWidget.InstanceCallback() { // from class: com.htc.clock3dwidget.analogclock.DualClockWidgetView.1
        @Override // com.htc.clock3dwidget.analogclock.AnalogClockWidget.InstanceCallback
        public ClockConfig loadPropertyData() {
            if (!DualClockWidgetView.this.mLoadConfig) {
                DualClockWidgetView.this.loadConfig();
                DualClockWidgetView.this.mLoadConfig = true;
            }
            return DualClockWidgetView.this.mConfigHome;
        }

        @Override // com.htc.clock3dwidget.analogclock.AnalogClockWidget.InstanceCallback
        public void savePropertyData(Intent intent) {
            DualClockWidgetView.this.saveDualClockConfig(intent);
        }
    };
    private AnalogClockWidget.InstanceCallback mCurrentCallback = new AnalogClockWidget.InstanceCallback() { // from class: com.htc.clock3dwidget.analogclock.DualClockWidgetView.2
        @Override // com.htc.clock3dwidget.analogclock.AnalogClockWidget.InstanceCallback
        public ClockConfig loadPropertyData() {
            if (!DualClockWidgetView.this.mLoadConfig) {
                DualClockWidgetView.this.loadConfig();
                DualClockWidgetView.this.mLoadConfig = true;
            }
            return DualClockWidgetView.this.mConfigCurrent;
        }

        @Override // com.htc.clock3dwidget.analogclock.AnalogClockWidget.InstanceCallback
        public void savePropertyData(Intent intent) {
            DualClockWidgetView.this.saveDualClockConfig(intent);
        }
    };

    public void onCreate(Bundle saved) {
        super.onCreate(saved);
        this.mScenePort = getHost().createScene(ClockUtils.getClockPath(ClockUtils.ClockType.CLOCK_DUAL_R, true), true);
        this.mSceneLand = !ClockUtils.SUPPORT_LAND ? this.mScenePort : getHost().createScene(ClockUtils.getClockPath(ClockUtils.ClockType.CLOCK_DUAL_R, false), true);
        this.mOrientation = getHost().getContext().getResources().getConfiguration().orientation;
    }

    protected void onPostCreate(Bundle savedState) {
        super.onPostCreate(savedState);
        this.mAnalogClockHome = new AnalogClockWidget(getContext(), getHost().getContext(), getHost(), this.mScenePort, this.mSceneLand, this.mOrientation, this.mHomeCallback, this.mClockResHome);
        this.mAnalogClockCurrent = new AnalogClockWidget(getContext(), getHost().getContext(), getHost(), this.mScenePort, this.mSceneLand, this.mOrientation, this.mCurrentCallback, this.mClockResCurrent);
        synchronized (this.mInitLock) {
            if (this.mInitResume) {
                doResume();
            }
            if (this.mInitPause) {
                doPause();
            }
            this.mInitCreate = true;
        }
    }

    public void onResume() {
        super.onResume();
        synchronized (this.mInitLock) {
            if (this.mInitCreate) {
                doResume();
            }
            this.mInitResume = true;
        }
    }

    public void onPause() {
        super.onPause();
        synchronized (this.mInitLock) {
            if (this.mInitCreate) {
                doPause();
            }
            this.mInitPause = true;
        }
    }

    private void doResume() {
        if (this.mAnalogClockHome != null) {
            this.mAnalogClockHome.doResume();
        }
        if (this.mAnalogClockCurrent != null) {
            this.mAnalogClockCurrent.doResume();
        }
    }

    private void doPause() {
        if (this.mAnalogClockHome != null) {
            this.mAnalogClockHome.doPause();
        }
        if (this.mAnalogClockCurrent != null) {
            this.mAnalogClockCurrent.doPause();
        }
    }

    public void onDestroy() {
        super.onDestroy();
        if (this.mAnalogClockHome != null) {
            this.mAnalogClockHome.doDestroy();
        }
        if (this.mAnalogClockCurrent != null) {
            this.mAnalogClockCurrent.doDestroy();
        }
    }

    public void onTiltChanged(float tilt) {
        super.onTiltChanged(tilt);
        if (this.mAnalogClockHome != null) {
            this.mAnalogClockHome.doTiltChanged(tilt);
        }
        if (this.mAnalogClockCurrent != null) {
            this.mAnalogClockCurrent.doTiltChanged(tilt);
        }
    }

    protected void onHostMessage(Message msg) {
        super.onHostMessage(msg);
        if (this.mAnalogClockHome != null) {
            this.mAnalogClockHome.doHostMessage(msg);
        }
        if (this.mAnalogClockCurrent != null) {
            this.mAnalogClockCurrent.doHostMessage(msg);
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (this.mAnalogClockHome != null) {
            this.mAnalogClockHome.doActivityResult(requestCode, resultCode, data);
        }
        if (this.mAnalogClockCurrent != null) {
            this.mAnalogClockCurrent.doActivityResult(requestCode, resultCode, data);
        }
    }

    protected FxScene getScene(int orientation) {
        return orientation == 1 ? this.mScenePort : this.mSceneLand;
    }

    protected FxScene getScene() {
        return this.mOrientation == 1 ? this.mScenePort : this.mSceneLand;
    }

    public void onConfigurationChanged(Configuration newConfiguration) {
        super.onConfigurationChanged(newConfiguration);
        this.mOrientation = newConfiguration.orientation;
        if (this.mAnalogClockCurrent != null && this.mAnalogClockHome != null) {
            this.mAnalogClockCurrent.onConfigurationChanged(this.mOrientation);
            this.mAnalogClockHome.onConfigurationChanged(this.mOrientation);
        }
    }

    public boolean isEditable() {
        return true;
    }

    public void onEdit() {
        try {
            Intent intent = Intent.parseUri(getSettingIntent(), 0);
            startActivityForResult(intent, 0);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }

    public String getSettingIntent() {
        Intent intent = new Intent(Constants.ACTION_INTENT_SETTING);
        intent.setClassName(Constants.SETTING_PACKAGE, Constants.SETTING_CLASS);
        intent.putExtra(Constants.WIDGET_TYPE, 4);
        intent.putExtra(Constants.KEY_DISPLAY_CITY_NAME, this.mConfigHome.bShowCityLabel);
        return intent.toUri(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void loadConfig() {
        Properties props = loadInstanceData();
        if (props == null) {
            saveDualClockConfig(getIntent());
        } else {
            this.mConfigHome = loadConfig(props, Constants.KEY_SELECT_CITY_CODE);
            this.mConfigCurrent = loadConfig(props, Constants.KEY_SELECT_CITY_CODE2);
        }
    }

    private ClockConfig loadConfig(Properties props, String selectCity) {
        boolean bShowCityLabel;
        String citnameCode = props.getProperty(selectCity);
        ClockConfig config = new ClockConfig();
        String StrIsDisplayCityName = props.getProperty(Constants.KEY_DISPLAY_CITY_NAME);
        MyLog.i("AnalogClock initData~ StrIsDisplayCityName:" + StrIsDisplayCityName);
        if (StrIsDisplayCityName != null && StrIsDisplayCityName.length() > 0) {
            bShowCityLabel = Boolean.parseBoolean(StrIsDisplayCityName);
            MyLog.i("AnalogClock initData~ 1 bShowCityLabel:" + bShowCityLabel);
        } else {
            bShowCityLabel = true;
            MyLog.i("AnalogClock initData~ 2 bShowCityLabel:true");
        }
        config.citnameCode = citnameCode;
        config.bShowCityLabel = bShowCityLabel;
        return config;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void saveDualClockConfig(Intent intent) {
        if (intent != null) {
            String citnameCode = intent.getStringExtra(Constants.KEY_SELECT_CITY_CODE);
            String citnameCode2 = intent.getStringExtra(Constants.KEY_SELECT_CITY_CODE2);
            boolean bShowCityLabel = intent.getBooleanExtra(Constants.KEY_DISPLAY_CITY_NAME, true);
            Properties props = new Properties();
            try {
                if (citnameCode != null) {
                    props.setProperty(Constants.KEY_SELECT_CITY_CODE, citnameCode);
                } else {
                    props.setProperty(Constants.KEY_SELECT_CITY_CODE, Constants.HOME_CITY);
                }
                if (citnameCode2 != null) {
                    props.setProperty(Constants.KEY_SELECT_CITY_CODE2, citnameCode2);
                }
                props.setProperty(Constants.KEY_DISPLAY_CITY_NAME, Boolean.toString(bShowCityLabel));
                storeInstanceData(props);
            } catch (Exception e) {
            }
            ClockConfig home = new ClockConfig();
            home.citnameCode = citnameCode == null ? Constants.HOME_CITY : citnameCode;
            home.bShowCityLabel = bShowCityLabel;
            this.mConfigHome = home;
            ClockConfig current = new ClockConfig();
            current.citnameCode = citnameCode2;
            current.bShowCityLabel = bShowCityLabel;
            this.mConfigCurrent = current;
        }
    }
}
