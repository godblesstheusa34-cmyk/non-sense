package com.htc.clock3dwidget;

import android.content.Context;
import com.htc.clock.util.location.LocationCtrl;
import com.htc.clock3dwidget.util.Constants;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class ClockUtils {
    private static boolean USE_LOCAL_PATH = true;
    public static boolean SUPPORT_LAND = false;
    public static boolean SUPPORT_TIMELINE = false;

    public enum ClockType {
        CLOCK_03,
        CLOCK_04,
        CLOCK_05,
        CLOCK_06,
        CLOCK_07,
        CLOCK_08,
        CLOCK_09,
        CLOCK_10,
        CLOCK_2x2,
        CLOCK_1x1,
        CLOCK_DIGITAL,
        CLOCK_DUAL_L,
        CLOCK_DUAL_R,
        CLOCK_BEAM,
        CLOCK_RING,
        CLOCK_SPIN_CYCLE,
        CLOCK_WEATHER,
        CLOCK_SOCIAL
    }

    public static String getMode10Path(boolean portrait, boolean supportLand) {
        if (USE_LOCAL_PATH) {
            if (portrait || !supportLand) {
                String modePath = "";
                return modePath;
            }
            String modePath2 = "land/";
            return modePath2;
        }
        if (portrait || !supportLand) {
            String modePath3 = "/sdcard/data/mode10/scenes/";
            return modePath3;
        }
        String modePath4 = "/sdcard/data/mode10/scenes/land/";
        return modePath4;
    }

    public static String getMode10Path(boolean portrait) {
        return getMode10Path(portrait, false);
    }

    public static String getMode10Path(Context context) {
        boolean isPortrait = context.getResources().getConfiguration().orientation == 1;
        return getMode10Path(isPortrait);
    }

    public static ClockRes getClockRes(ClockType type, Context context) {
        boolean isPortrait = context.getResources().getConfiguration().orientation == 1;
        switch (AnonymousClass1.$SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType[type.ordinal()]) {
            case 1:
                ClockRes res = getClock03(isPortrait);
                return res;
            case 2:
                ClockRes res2 = getClock04(isPortrait);
                return res2;
            case 3:
                ClockRes res3 = getClock05(isPortrait);
                return res3;
            case 4:
                ClockRes res4 = getClock06(isPortrait);
                return res4;
            case Constants.WIDGET_TYPE_DIGITALCLOCK /* 5 */:
                ClockRes res5 = getClock07(isPortrait);
                return res5;
            case Constants.WIDGET_TYPE_ANALOGCLOCKADJ /* 6 */:
                ClockRes res6 = getClock08(isPortrait);
                return res6;
            case Constants.WIDGET_TYPE_TRAVELCLOCK2 /* 7 */:
                ClockRes res7 = getClock09(isPortrait);
                return res7;
            case 8:
                ClockRes res8 = getClock10(isPortrait);
                return res8;
            case 9:
                ClockRes res9 = getClock2x2(isPortrait);
                return res9;
            case LocationCtrl.MAX_RETRY_CNT /* 10 */:
                ClockRes res10 = getClock1x1(isPortrait);
                return res10;
            case 11:
                ClockRes res11 = getClockDigital(isPortrait);
                return res11;
            case 12:
                ClockRes res12 = getClockDualL(isPortrait);
                return res12;
            case 13:
                ClockRes res13 = getClockDualR(isPortrait);
                return res13;
            case 14:
                ClockRes res14 = getClockBeam(isPortrait);
                return res14;
            case 15:
                ClockRes res15 = getClockRing(isPortrait);
                return res15;
            case 16:
                ClockRes res16 = getClockSpinCycle(isPortrait);
                return res16;
            case 17:
                ClockRes res17 = getClockSocial(isPortrait);
                return res17;
            default:
                return null;
        }
    }

    /* renamed from: com.htc.clock3dwidget.ClockUtils$1, reason: invalid class name */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType = new int[ClockType.values().length];

        static {
            try {
                $SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType[ClockType.CLOCK_03.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType[ClockType.CLOCK_04.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType[ClockType.CLOCK_05.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType[ClockType.CLOCK_06.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                $SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType[ClockType.CLOCK_07.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            try {
                $SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType[ClockType.CLOCK_08.ordinal()] = 6;
            } catch (NoSuchFieldError e6) {
            }
            try {
                $SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType[ClockType.CLOCK_09.ordinal()] = 7;
            } catch (NoSuchFieldError e7) {
            }
            try {
                $SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType[ClockType.CLOCK_10.ordinal()] = 8;
            } catch (NoSuchFieldError e8) {
            }
            try {
                $SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType[ClockType.CLOCK_2x2.ordinal()] = 9;
            } catch (NoSuchFieldError e9) {
            }
            try {
                $SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType[ClockType.CLOCK_1x1.ordinal()] = 10;
            } catch (NoSuchFieldError e10) {
            }
            try {
                $SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType[ClockType.CLOCK_DIGITAL.ordinal()] = 11;
            } catch (NoSuchFieldError e11) {
            }
            try {
                $SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType[ClockType.CLOCK_DUAL_L.ordinal()] = 12;
            } catch (NoSuchFieldError e12) {
            }
            try {
                $SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType[ClockType.CLOCK_DUAL_R.ordinal()] = 13;
            } catch (NoSuchFieldError e13) {
            }
            try {
                $SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType[ClockType.CLOCK_BEAM.ordinal()] = 14;
            } catch (NoSuchFieldError e14) {
            }
            try {
                $SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType[ClockType.CLOCK_RING.ordinal()] = 15;
            } catch (NoSuchFieldError e15) {
            }
            try {
                $SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType[ClockType.CLOCK_SPIN_CYCLE.ordinal()] = 16;
            } catch (NoSuchFieldError e16) {
            }
            try {
                $SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType[ClockType.CLOCK_SOCIAL.ordinal()] = 17;
            } catch (NoSuchFieldError e17) {
            }
            try {
                $SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType[ClockType.CLOCK_WEATHER.ordinal()] = 18;
            } catch (NoSuchFieldError e18) {
            }
        }
    }

    public static String getClockPath(ClockType type, Context context) {
        boolean isPortrait = context.getResources().getConfiguration().orientation == 1;
        return getClockPath(type, isPortrait);
    }

    public static String getClockPath(ClockType type, boolean isPortrait) {
        switch (AnonymousClass1.$SwitchMap$com$htc$clock3dwidget$ClockUtils$ClockType[type.ordinal()]) {
            case 1:
                String path = getClock03Path(isPortrait);
                return path;
            case 2:
                String path2 = getClock04Path(isPortrait);
                return path2;
            case 3:
                String path3 = getClock05Path(isPortrait);
                return path3;
            case 4:
                String path4 = getClock06Path(isPortrait);
                return path4;
            case Constants.WIDGET_TYPE_DIGITALCLOCK /* 5 */:
                String path5 = getClock07Path(isPortrait);
                return path5;
            case Constants.WIDGET_TYPE_ANALOGCLOCKADJ /* 6 */:
                String path6 = getClock08Path(isPortrait);
                return path6;
            case Constants.WIDGET_TYPE_TRAVELCLOCK2 /* 7 */:
                String path7 = getClock09Path(isPortrait);
                return path7;
            case 8:
                String path8 = getClock10Path(isPortrait);
                return path8;
            case 9:
                String path9 = getClock2x2Path(isPortrait);
                return path9;
            case LocationCtrl.MAX_RETRY_CNT /* 10 */:
                String path10 = getClock1x1Path(isPortrait);
                return path10;
            case 11:
                String path11 = getClockDigitalPath(isPortrait);
                return path11;
            case 12:
                String path12 = getClockDualLPath(isPortrait);
                return path12;
            case 13:
                String path13 = getClockDualRPath(isPortrait);
                return path13;
            case 14:
                String path14 = getClockBeamPath(isPortrait);
                return path14;
            case 15:
                String path15 = getClockRingPath(isPortrait);
                return path15;
            case 16:
                String path16 = getClockSpinCyclePath(isPortrait);
                return path16;
            case 17:
                String path17 = getClockSocialPath(isPortrait);
                return path17;
            case 18:
                String path18 = getClockWeatherPath(isPortrait);
                return path18;
            default:
                return null;
        }
    }

    private static ClockRes getClock03(boolean portrait) {
        ClockRes res = new ClockRes();
        res.m10FilePath = getClock03Path(portrait);
        res.hitboxClock = "Clock_hitbox";
        res.progressBarHourHand = "progressbar.clock03.hour_hand";
        res.progressBarMinuteHand = "progressbar.clock03.minute_hand";
        res.progressBarSecondHand = "progressbar.clock03.second_hand";
        res.textLabelCityName = "textlabel.clock";
        res.timelineClockBase = "timeline.clock_base";
        res.timelineClockDate = "timeline.clock_date";
        res.textLabelClockDate = "textlabel.date_day";
        res.textLabelClockWeekDay = "textlabel.week_day";
        res.textLabalClockAmPm = "textlabel.AM";
        res.textLabelClockDate_night = "textlabel.date_night";
        res.textLabelClockWeekDay_night = "textlabel.week_night";
        res.textLabalClockAmPm_night = "textlabel.PM";
        res.timelineClock = "timeline.Clock_03";
        return res;
    }

    private static String getClock03Path(boolean portrait) {
        return getMode10Path(portrait) + ResUtils.M10_CLOCK_03;
    }

    private static ClockRes getClock04(boolean portrait) {
        ClockRes res = new ClockRes();
        res.m10FilePath = getClock04Path(portrait);
        res.hitboxClock = "Clock_hitbox";
        res.progressBarHourHand = "progressbar.hour_hand";
        res.progressBarMinuteHand = "progressbar.minute_hand";
        res.progressBarSecondHand = "progressbar.second_hand";
        res.textLabelCityName = "textlabel.widget_clock_city";
        res.textLabelClockDate = "textlabel.Clock_date";
        res.timelineClock = "timeline.Clock_04";
        return res;
    }

    private static String getClock04Path(boolean portrait) {
        return getMode10Path(portrait) + ResUtils.M10_CLOCK_04;
    }

    private static ClockRes getClock05(boolean portrait) {
        ClockRes res = new ClockRes();
        res.m10FilePath = getClock05Path(portrait);
        res.hitboxClock = "Clock_hitbox";
        res.progressBarHourHand = "progressbar.hour_hand";
        res.progressBarMinuteHand = "progressbar.minute_hand";
        res.progressBarSecondHand = "progressbar.second_hand";
        res.textLabelCityName = "textlabel.widget_clock_city";
        res.textLabelClockDate = "textlabel.widget_clock_month";
        res.textLabalClockAmPm = "textlabel.widget_clock_am";
        res.timelineClock = "timeline.Clock_05";
        return res;
    }

    private static String getClock05Path(boolean portrait) {
        return getMode10Path(portrait) + ResUtils.M10_CLOCK_05;
    }

    private static ClockRes getClock06(boolean portrait) {
        ClockRes res = new ClockRes();
        res.m10FilePath = getClock06Path(portrait);
        res.hitboxClock = "Clock_hitbox";
        res.progressBarHourHand = "progressbar.clock06.hour_hand";
        res.progressBarMinuteHand = "progressbar.clock06.minute_hand";
        res.progressBarSecondHand = "progressbar.clock06.second_hand";
        res.textLabelCityName = "textlabel.clock";
        res.timelineClock = "timeline.Clock_06";
        res.timelineGear01 = "timeline.gear_01";
        res.timelineGear02 = "timeline.gear_02";
        res.timelineGear03 = "timeline.gear_03";
        res.timelineGear04 = "timeline.gear_04";
        res.timelineGear05 = "timeline.gear_02_1";
        return res;
    }

    private static String getClock06Path(boolean portrait) {
        return getMode10Path(portrait) + ResUtils.M10_CLOCK_06;
    }

    private static ClockRes getClock07(boolean portrait) {
        ClockRes res = new ClockRes();
        res.m10FilePath = getClock07Path(portrait);
        res.hitboxClock = "Clock_hitbox";
        res.progressBarHourHand = "progressbar.clock07.hour_hand";
        res.progressBarMinuteHand = "progressbar.clock07.minute_hand";
        res.progressBarSecondHand = "progressbar.clock07.second_hand";
        res.textLabelCityName = "textlabel.widget_clock_city";
        res.timelineClock = "timeline.Clock_07";
        return res;
    }

    private static String getClock07Path(boolean portrait) {
        return getMode10Path(portrait) + ResUtils.M10_CLOCK_07;
    }

    private static ClockRes getClock08(boolean portrait) {
        ClockRes res = new ClockRes();
        res.m10FilePath = getClock08Path(portrait);
        res.hitboxClock = "Clock.hitbox";
        res.progressBarHourHand = "progressbar.hour_hand";
        res.progressBarMinuteHand = "progressbar.minute_hand";
        res.progressBarSecondHand = "progressbar.second_hand";
        res.textLabelCityName = "textlabel.widget_clock_city";
        res.timelineAmPm = "timeline.am_pm";
        res.timelineClock = "timeline.Clock_08";
        return res;
    }

    private static String getClock08Path(boolean portrait) {
        return getMode10Path(portrait) + ResUtils.M10_CLOCK_08;
    }

    private static ClockRes getClock09(boolean portrait) {
        ClockRes res = new ClockRes();
        res.m10FilePath = getClock09Path(portrait);
        res.hitboxClock = "Clock_hitbox";
        res.progressBarHourHand = "progressbar.hour_hand";
        res.progressBarMinuteHand = "progressbar.minute_hand";
        res.progressBarSecondHand = "progressbar.second_hand";
        res.textLabelCityName = "textlabel.widget_clock_city";
        res.timelineClock = "timeline.Clock_09";
        return res;
    }

    private static String getClock09Path(boolean portrait) {
        return getMode10Path(portrait) + ResUtils.M10_CLOCK_09;
    }

    private static ClockRes getClock10(boolean portrait) {
        ClockRes res = new ClockRes();
        res.m10FilePath = getClock10Path(portrait);
        res.hitboxClock = "Clock_hitbox";
        res.progressBarHourHand = "progressbar.hour_hand";
        res.progressBarMinuteHand = "progressbar.minute_hand";
        res.progressBarSecondHand = "progressbar.second_hand";
        res.textLabelCityName = "textlabel.widget_clock_city";
        res.timelineClock = "timeline.Clock_10";
        return res;
    }

    private static String getClock10Path(boolean portrait) {
        return getMode10Path(portrait) + ResUtils.M10_CLOCK_10;
    }

    private static ClockRes getClockDigital(boolean portrait) {
        ClockRes res = new ClockRes();
        res.m10FilePath = getClockDigitalPath(portrait);
        res.hitboxClock = "Clock_hitbox";
        res.timelineHourTen = "timeline.digital_numbers_01";
        res.timelineHourUnit = "timeline.digital_numbers_02";
        res.timelineMinuteTen = "timeline.digital_numbers_03";
        res.timelineMinuteUinit = "timeline.digital_numbers_04";
        res.timelineAmPmOpp = "timeline.am_pm";
        res.textLabelCityName = "textlabel.city";
        res.textLabelClockLongDate = "textlabel.digital_clock_01";
        return res;
    }

    private static String getClockDigitalPath(boolean portrait) {
        return getMode10Path(portrait) + ResUtils.M10_CLOCK_DIGITAL;
    }

    private static ClockRes getClock2x2(boolean portrait) {
        ClockRes res = new ClockRes();
        res.m10FilePath = getClock2x2Path(portrait);
        res.hitboxClock = "Clock_hitbox";
        res.timelineClockBase = "timeline.clock_day_night";
        res.timelineClockDate = "timeline.clock_date";
        res.progressBarHourHand = "progressbar.hour_hand";
        res.progressBarMinuteHand = "progressbar.minute_hand";
        res.progressBarSecondHand = "progressbar.second_hand";
        res.textLabelClockDate = "textlabel.date_day";
        res.textLabelClockWeekDay = "textlabel.clock_week_day";
        res.textLabalClockAmPm = "textlabel.AM_day";
        res.textLabelClockDate_night = "textlabel.date_night";
        res.textLabelClockWeekDay_night = "textlabel.clock_week_night";
        res.textLabalClockAmPm_night = "textlabel.PM_night";
        res.textLabelCityName = "textlabel.clock";
        return res;
    }

    private static String getClock2x2Path(boolean portrait) {
        return getMode10Path(portrait) + ResUtils.M10_CLOCK_2x2;
    }

    private static ClockRes getClock1x1(boolean portrait) {
        ClockRes res = new ClockRes();
        res.m10FilePath = getClock1x1Path(portrait);
        res.hitboxClock = "Clock_hitbox";
        res.progressBarHourHand = "progressbar.hour_hand";
        res.progressBarMinuteHand = "progressbar.minute_hand";
        res.progressBarSecondHand = "progressbar.second_hand";
        res.textLabelCityName = "textlabel.widget_clock_city";
        res.timelineWiggle = "timeline.clock_base";
        res.timelineClockBase = "timeline.clock_base_day_night";
        res.timelineClockHour = "timeline.clock_hour";
        res.timelineClockMinute = "timeline.clock_minute";
        return res;
    }

    private static String getClock1x1Path(boolean portrait) {
        return getMode10Path(portrait) + ResUtils.M10_CLOCK_1x1;
    }

    private static ClockRes getClockDualL(boolean portrait) {
        ClockRes res = new ClockRes();
        res.m10FilePath = getClockDualLPath(portrait);
        res.hitboxClock = "Clock_hitbox";
        res.progressBarHourHand = "progressbar.hour_hand_right";
        res.progressBarMinuteHand = "progressbar.minute_hand_right";
        res.progressBarSecondHand = "progressbar.second_hand_right";
        res.timelineClockBase = "timeline.clock_base_right";
        res.timelineClockNumbers = "timeline.clock_numbers_right";
        res.textLabelCityName = "textlabel.clock_left";
        return res;
    }

    private static String getClockDualLPath(boolean portrait) {
        return getMode10Path(portrait) + ResUtils.M10_CLOCK_DUAL;
    }

    private static ClockRes getClockDualR(boolean portrait) {
        ClockRes res = new ClockRes();
        res.m10FilePath = getClockDualRPath(portrait);
        res.hitboxClock = "Clock_hitbox";
        res.progressBarHourHand = "progressbar.hour_hand_left";
        res.progressBarMinuteHand = "progressbarl.minute_hand_left";
        res.progressBarSecondHand = "progressbar.second_hand_left";
        res.timelineClockBase = "timeline.clock_base_left";
        res.timelineClockNumbers = "timeline.clock_numbers_left";
        res.textLabelCityName = "textlabel.clock_right";
        return res;
    }

    private static String getClockDualRPath(boolean portrait) {
        return getMode10Path(portrait) + ResUtils.M10_CLOCK_DUAL;
    }

    private static ClockRes getClockBeam(boolean portrait) {
        ClockRes res = new ClockRes();
        res.m10FilePath = getClockBeamPath(portrait);
        res.hitboxClock = "Clock_hitbox";
        res.progressBarHourHand = "progressbar.hour_hand";
        res.progressBarMinuteHand = "progressbar.minute_hand";
        res.progressBarSecondHand = "progressbar.second_hand";
        res.textLabelCityName = "textlabel.widget_clock_city";
        res.timelineClock = "timeline.Clock_Beam";
        return res;
    }

    private static String getClockBeamPath(boolean portrait) {
        return getMode10Path(portrait) + ResUtils.M10_CLOCK_BEAM;
    }

    private static ClockRes getClockRing(boolean portrait) {
        ClockRes res = new ClockRes();
        res.m10FilePath = getClockRingPath(portrait);
        res.hitboxClock = "Clock_hitbox";
        res.progressBarUnitHourHand = "progressbar.hour_hand";
        res.progressBarUnitMinuteHand = "progressbar.minute_hand";
        res.progressBarSecondHand = "progressbar.second_hand";
        res.textLabelCityName = "textlabel.widget_clock_city";
        res.timelineClock = "timeline.Clock_Ring";
        res.textLabelHour = "textlabel.clock_hour";
        res.textLabelMinute = "textlabel.clock_minute";
        res.textLabelSecond = "textlabel.clock_second";
        return res;
    }

    private static String getClockRingPath(boolean portrait) {
        return getMode10Path(portrait) + ResUtils.M10_CLOCK_RING;
    }

    private static ClockRes getClockSpinCycle(boolean portrait) {
        ClockRes res = new ClockRes();
        res.m10FilePath = getClockSpinCyclePath(portrait);
        res.hitboxClock = "Clock_hitbox";
        res.progressBarUnitHourHand = "progressbar.hour_hand";
        res.progressBarUnitMinuteHand = "progressbar.minute_hand";
        res.progressBarSecondHand = "progressbar.second_hand";
        res.textLabelCityName = "textlabel.widget_clock_city";
        res.textLabelClockWeekDay = "textlabel.clock_week";
        res.textLabelClockDate = "textlabel.clock_date";
        res.timelineClock = "timeline.Clock_04";
        res.timelineClockAmPm = "timeline.clock_ampm";
        res.timelineHourTen = "timeline.clock_number_01";
        res.timelineHourUnit = "timeline.clock_number_02";
        res.timelineMinuteTen = "timeline.clock_number_03";
        res.timelineMinuteUinit = "timeline.clock_number_04";
        return res;
    }

    private static String getClockSpinCyclePath(boolean portrait) {
        return getMode10Path(portrait) + ResUtils.M10_CLOCK_SPIN_CYCLE;
    }

    public static String getClockWeatherPath(boolean portrait) {
        return getMode10Path(portrait) + ResUtils.M10_CLOCK_WEATHER;
    }

    private static ClockRes getClockSocial(boolean portrait) {
        ClockRes res = new ClockRes();
        res.m10FilePath = getClockSocialPath(portrait);
        res.hitboxClock = "button.clock.hitbox";
        res.timelineFlipHour = "timeline.flip_hour";
        res.timelineFlipMinute = "timeline.flip_minute";
        return res;
    }

    public static String getClockSocialPath(boolean portrait) {
        return getMode10Path(portrait) + ResUtils.M10_CLOCK_SOCIAL;
    }
}
