package com.htc.clock3dwidget.idlescreen;

import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import com.htc.clock.util.MyLog;
import com.htc.clock3dwidget.ClockRes;
import com.htc.clock3dwidget.ClockUtils;
import com.htc.clock3dwidget.analogclock.AnalogClockWidget;
import com.htc.fusion.fx.FxScene;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.MessageListener;
import com.htc.fusion.fx.controls.FxHitbox;
import com.htc.fusion.fx.controls.FxSceneContainer;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
class IdleScreenClockStub {
    public static final String TAG = "[FBIdlScn]";
    private static final int WHAT_ON_INIT = 16;
    private static final int WHAT_ON_PAUSE = 18;
    private static final int WHAT_ON_RESUME = 17;
    private AnalogClockWidget mAnalogClockWidget;
    private Context mContext;
    private FxScene mFxClock;
    private FxSceneContainer mFxContainer;
    private FxHitbox mFxHitbox;
    private FxScene mFxScene;
    private FxTimelineControl mFxTimelineTouch;
    private ClickListener mClockClick = new ClickListener();
    protected HandlerThread mHandlerThread = null;
    protected Looper mLooper = null;
    private Handler mNonUiHandler = null;
    private ClockUtils.ClockType[] sClockType = {ClockUtils.ClockType.CLOCK_03, ClockUtils.ClockType.CLOCK_04, ClockUtils.ClockType.CLOCK_05, ClockUtils.ClockType.CLOCK_06, ClockUtils.ClockType.CLOCK_07, ClockUtils.ClockType.CLOCK_08, ClockUtils.ClockType.CLOCK_09, ClockUtils.ClockType.CLOCK_10, ClockUtils.ClockType.CLOCK_BEAM, ClockUtils.ClockType.CLOCK_RING, ClockUtils.ClockType.CLOCK_SPIN_CYCLE};

    public IdleScreenClockStub(Context context, FxScene scene) {
        this.mContext = context;
        this.mFxScene = scene;
        initHandler();
        this.mNonUiHandler.sendEmptyMessage(WHAT_ON_INIT);
    }

    private void initHandler() {
        this.mHandlerThread = new HandlerThread("IdleScreenClockStub", 10);
        this.mHandlerThread.start();
        this.mLooper = this.mHandlerThread.getLooper();
        this.mNonUiHandler = new Handler(this.mLooper) { // from class: com.htc.clock3dwidget.idlescreen.IdleScreenClockStub.1
            @Override // android.os.Handler
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case IdleScreenClockStub.WHAT_ON_INIT /* 16 */:
                        IdleScreenClockStub.this.doCreate();
                        break;
                    case IdleScreenClockStub.WHAT_ON_RESUME /* 17 */:
                        IdleScreenClockStub.this.doResume();
                        break;
                    case IdleScreenClockStub.WHAT_ON_PAUSE /* 18 */:
                        IdleScreenClockStub.this.doPause();
                        break;
                }
            }
        };
    }

    public void onResume() {
        if (this.mNonUiHandler != null) {
            this.mNonUiHandler.sendEmptyMessage(WHAT_ON_RESUME);
        }
    }

    public void onPause() {
        if (this.mNonUiHandler != null) {
            this.mNonUiHandler.sendEmptyMessage(WHAT_ON_PAUSE);
        }
    }

    public void onDestroy() {
        if (this.mNonUiHandler != null) {
            this.mNonUiHandler.removeMessages(WHAT_ON_INIT);
            this.mNonUiHandler.removeMessages(WHAT_ON_RESUME);
            this.mNonUiHandler.removeMessages(WHAT_ON_PAUSE);
            this.mNonUiHandler = null;
        }
        if (this.mLooper != null) {
            this.mLooper.quit();
            this.mLooper = null;
        }
        if (this.mAnalogClockWidget != null) {
            this.mAnalogClockWidget.doDestroy();
        }
        if (this.mFxContainer != null) {
            this.mFxContainer.setScene((FxScene) null);
        }
        if (this.mFxHitbox != null) {
            this.mFxHitbox.getEventSource().unbind(this.mClockClick);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doCreate() {
        int index = IdleScreenSettings.getClockType(this.mContext);
        ClockUtils.ClockType clock_type = this.sClockType[index];
        ClockRes analogClockRes = ClockUtils.getClockRes(clock_type, this.mContext);
        FxScene scene = this.mFxScene;
        if (scene != null) {
            String[] controls = {"scenecontainer.lockscreen_clock", "timeline.clock_touch", "hitbox.touch_bounce"};
            FxHitbox[] descendants = scene.getDescendants(controls);
            this.mFxContainer = (FxSceneContainer) descendants[0];
            this.mFxTimelineTouch = (FxTimelineControl) descendants[1];
            this.mFxHitbox = descendants[2];
            this.mFxHitbox.setEnabled(true);
            this.mFxHitbox.getEventSource().bind(this.mClockClick);
            this.mFxClock = FxScene.create(analogClockRes.m10FilePath);
            this.mFxClock.setVisibility(true);
            this.mFxContainer.setScene(this.mFxClock);
            this.mAnalogClockWidget = new AnalogClockWidget(this.mContext, this.mContext, null, this.mFxClock, this.mFxClock, 1, null, analogClockRes);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doResume() {
        if (this.mFxScene != null) {
            this.mFxScene.setVisibility(true);
        }
        if (this.mAnalogClockWidget != null) {
            this.mAnalogClockWidget.doResume();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doPause() {
        if (this.mFxScene != null) {
            this.mFxScene.setVisibility(false);
        }
        if (this.mAnalogClockWidget != null) {
            this.mAnalogClockWidget.doPause();
        }
    }

    private class ClickListener extends MessageListener<FxHitbox.EventParameters> {
        private ClickListener() {
        }

        public void onMessageReceived(FxHitbox.EventParameters message) {
            MyLog.i("Touch bounce clicked~");
            switch (message.event) {
                case 2:
                    if (IdleScreenClockStub.this.mFxTimelineTouch != null) {
                        IdleScreenClockStub.this.mFxTimelineTouch.playMarker("touch_bounce");
                        break;
                    }
                    break;
            }
        }
    }
}
