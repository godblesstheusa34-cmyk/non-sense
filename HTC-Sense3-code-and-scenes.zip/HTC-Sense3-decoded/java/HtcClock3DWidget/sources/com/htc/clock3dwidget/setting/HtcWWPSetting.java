package com.htc.clock3dwidget.setting;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import com.htc.clock.util.MyLog;
import com.htc.clock3dwidget.R;
import com.htc.clock3dwidget.ResUtils;
import com.htc.clock3dwidget.util.Constants;
import com.htc.util.skin.HtcSkinUtil;
import com.htc.widget.HtcAdapterView;
import com.htc.widget.HtcListView;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class HtcWWPSetting extends Activity implements View.OnClickListener {
    private Button mButton;
    private CheckBox mCheckWWPPlayBox;
    private HtcListView mSettingListView;
    public boolean mBWWPPlay = true;
    HtcAdapterView.OnItemClickListener mListener = new HtcAdapterView.OnItemClickListener() { // from class: com.htc.clock3dwidget.setting.HtcWWPSetting.1
        public void onItemClick(HtcAdapterView<?> parent, View view, int position, long id) {
            HtcWWPSetting.this.mBWWPPlay = !HtcWWPSetting.this.mBWWPPlay;
            HtcWWPSetting.this.mCheckWWPPlayBox.setChecked(HtcWWPSetting.this.mBWWPPlay);
        }
    };

    private class EmptyAdapter extends BaseAdapter {
        private EmptyAdapter() {
        }

        @Override // android.widget.Adapter
        public int getCount() {
            return 0;
        }

        @Override // android.widget.Adapter
        public Object getItem(int arg0) {
            return null;
        }

        @Override // android.widget.Adapter
        public long getItemId(int arg0) {
            return 0L;
        }

        @Override // android.widget.Adapter
        public View getView(int arg0, View arg1, ViewGroup arg2) {
            return null;
        }
    }

    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            this.mBWWPPlay = savedInstanceState.getBoolean(Constants.WWP_PLAY, true);
        } else {
            Intent intent = getIntent();
            this.mBWWPPlay = intent.getBooleanExtra(Constants.WWP_PLAY, true);
        }
        ResUtils.setupWWPView(this, 2130903041, 2131296260, 2131099685, -1);
        this.mSettingListView = findViewById(2131296260);
        int list_selector = HtcSkinUtil.getDrawableResIdentifier(this, "list_selector_background", 34078814);
        this.mSettingListView.setSelector(list_selector);
        View checkItem = View.inflate(getApplicationContext(), 34144387, null);
        TextView textView = (TextView) checkItem.findViewById(33685520);
        textView.setText(R.string.wwp_setting_show_wwp);
        this.mCheckWWPPlayBox = (CheckBox) checkItem.findViewById(33685535);
        this.mCheckWWPPlayBox.setChecked(this.mBWWPPlay);
        this.mCheckWWPPlayBox.setVisibility(0);
        this.mSettingListView.addHeaderView(checkItem, (Object) null, true);
        this.mSettingListView.setAdapter(new EmptyAdapter());
        this.mSettingListView.setOnItemClickListener(this.mListener);
        MyLog.i("mSettingListView good");
        ResUtils.setupButton(this, this);
    }

    @Override // android.app.Activity
    public void onStart() {
        super.onStart();
    }

    @Override // android.app.Activity
    public void onResume() {
        super.onResume();
    }

    @Override // android.app.Activity
    public void onPause() {
        super.onPause();
    }

    @Override // android.app.Activity
    public void onStop() {
        super.onStop();
    }

    @Override // android.app.Activity
    public void onDestroy() {
        super.onDestroy();
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        Intent intent = getIntent();
        intent.putExtra(Constants.WWP_PLAY, this.mBWWPPlay);
        setResult(-1, intent);
        finish();
    }

    @Override // android.app.Activity
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean(Constants.WWP_PLAY, this.mBWWPPlay);
    }
}
