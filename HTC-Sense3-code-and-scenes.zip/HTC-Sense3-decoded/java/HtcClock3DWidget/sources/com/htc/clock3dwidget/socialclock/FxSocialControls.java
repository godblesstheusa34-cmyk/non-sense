package com.htc.clock3dwidget.socialclock;

import com.htc.fusion.fx.FxScene;
import com.htc.fusion.fx.controls.FxDynamicImage;
import com.htc.fusion.fx.controls.FxHitbox;
import com.htc.fusion.fx.controls.FxTextLabel;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class FxSocialControls {
    public FxHitbox mFxHitboxSocial;
    public FxDynamicImage mIcon;
    public FxDynamicImage mIndicator;
    public FxTextLabel mInfo;
    public FxTextLabel mMessage;
    public FxTextLabel mReply;
    public FxTextLabel mTime;

    public FxSocialControls(FxScene scene) {
        String[] controls = {"textlabel.primary", "textlabel.time", "textlabel.FS_reply", "dynamicimage.photos", "dynamicimage.indicator_icons", "button.weather.hitbox", "textlabel.info"};
        FxTextLabel[] descendants = scene.getDescendants(controls);
        this.mMessage = descendants[0];
        this.mTime = descendants[1];
        this.mReply = descendants[2];
        this.mIcon = (FxDynamicImage) descendants[3];
        if (this.mIcon != null) {
            this.mIcon.setVisibility(false);
            this.mIcon.playMarker("loading_to_loaded");
        }
        this.mIndicator = (FxDynamicImage) descendants[4];
        if (this.mIndicator != null) {
            this.mIndicator.setVisibility(false);
            this.mIndicator.playMarker("loading_to_loaded");
        }
        this.mFxHitboxSocial = (FxHitbox) descendants[5];
        if (this.mFxHitboxSocial != null) {
            this.mFxHitboxSocial.setEnabled(true);
            this.mFxHitboxSocial.setEnabledGestures(1);
        }
        this.mInfo = descendants[6];
        reset();
    }

    private void reset() {
        if (this.mReply != null) {
            this.mReply.setString("");
        }
        if (this.mMessage != null) {
            this.mMessage.setString("");
        }
        if (this.mTime != null) {
            this.mTime.setString("");
        }
        if (this.mInfo != null) {
            this.mInfo.setString("");
        }
    }
}
