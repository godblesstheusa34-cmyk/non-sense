package com.htc.clock3dwidget.analogclock;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Message;
import com.htc.android.rosie.widget.Widget;
import com.htc.clock.util.MyLog;
import com.htc.clock3dwidget.ClockRes;
import com.htc.clock3dwidget.ClockUtils;
import com.htc.clock3dwidget.analogclock.AnalogClockWidget;
import com.htc.clock3dwidget.util.Constants;
import com.htc.fusion.fx.FxScene;
import java.net.URISyntaxException;
import java.util.Properties;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class AnalogClockWidgetView extends Widget.Base {
    private static final String TAG = AnalogClockWidgetView.class.getSimpleName();
    private static final boolean localLOGV = false;
    private AnalogClockWidget mAnalogClockWidget;
    private Context mApContext;
    private ClockConfig mClockConfig;
    protected ClockRes mClockRes;
    protected ClockUtils.ClockType mClockType;
    private FxScene mSceneLand;
    private FxScene mScenePort;
    private int mOrientation = 1;
    private boolean mLoadConfig = false;
    private boolean mInitCreate = false;
    private boolean mInitResume = false;
    private boolean mInitPause = false;
    private Object mInitLock = new Object();
    private AnalogClockWidget.InstanceCallback mInstanceCallback = new AnalogClockWidget.InstanceCallback() { // from class: com.htc.clock3dwidget.analogclock.AnalogClockWidgetView.1
        @Override // com.htc.clock3dwidget.analogclock.AnalogClockWidget.InstanceCallback
        public ClockConfig loadPropertyData() {
            if (!AnalogClockWidgetView.this.mLoadConfig) {
                AnalogClockWidgetView.this.loadConfig();
                AnalogClockWidgetView.this.mLoadConfig = true;
            }
            return AnalogClockWidgetView.this.mClockConfig;
        }

        @Override // com.htc.clock3dwidget.analogclock.AnalogClockWidget.InstanceCallback
        public void savePropertyData(Intent intent) {
            AnalogClockWidgetView.this.saveClockConfig(intent);
        }
    };

    public void onCreate(Bundle saved) {
        super.onCreate(saved);
        this.mApContext = getHost().getContext();
        this.mClockRes = ClockUtils.getClockRes(this.mClockType, this.mApContext);
        this.mScenePort = getHost().createScene(ClockUtils.getClockPath(this.mClockType, true), true);
        this.mSceneLand = !ClockUtils.SUPPORT_LAND ? this.mScenePort : getHost().createScene(ClockUtils.getClockPath(this.mClockType, false), true);
        this.mOrientation = this.mApContext.getResources().getConfiguration().orientation;
    }

    protected void onPostCreate(Bundle savedState) {
        super.onPostCreate(savedState);
        this.mAnalogClockWidget = new AnalogClockWidget(getContext(), getHost().getContext(), getHost(), this.mScenePort, this.mSceneLand, this.mOrientation, this.mInstanceCallback, this.mClockRes);
        synchronized (this.mInitLock) {
            if (this.mInitResume) {
                doResume();
            }
            if (this.mInitPause) {
                doPause();
            }
            this.mInitCreate = true;
        }
    }

    public void onResume() {
        super.onResume();
        synchronized (this.mInitLock) {
            if (this.mInitCreate) {
                doResume();
            }
            this.mInitResume = true;
        }
    }

    public void onPause() {
        super.onPause();
        synchronized (this.mInitLock) {
            if (this.mInitCreate) {
                doPause();
            }
            this.mInitPause = true;
        }
    }

    private void doResume() {
        if (this.mAnalogClockWidget != null) {
            this.mAnalogClockWidget.doResume();
        }
    }

    private void doPause() {
        if (this.mAnalogClockWidget != null) {
            this.mAnalogClockWidget.doPause();
        }
    }

    public void onDestroy() {
        super.onDestroy();
        if (this.mAnalogClockWidget != null) {
            this.mAnalogClockWidget.doDestroy();
        }
    }

    public void onTiltChanged(float tilt) {
        super.onTiltChanged(tilt);
        if (this.mAnalogClockWidget != null) {
            this.mAnalogClockWidget.doTiltChanged(tilt);
        }
    }

    protected void onHostMessage(Message msg) {
        super.onHostMessage(msg);
        if (this.mAnalogClockWidget != null) {
            this.mAnalogClockWidget.doHostMessage(msg);
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (this.mAnalogClockWidget != null) {
            this.mAnalogClockWidget.doActivityResult(requestCode, resultCode, data);
        }
    }

    protected FxScene getScene(int orientation) {
        return orientation == 1 ? this.mScenePort : this.mSceneLand;
    }

    protected FxScene getScene() {
        return this.mOrientation == 1 ? this.mScenePort : this.mSceneLand;
    }

    public void onConfigurationChanged(Configuration newConfiguration) {
        super.onConfigurationChanged(newConfiguration);
        this.mOrientation = newConfiguration.orientation;
        if (this.mAnalogClockWidget != null) {
            this.mAnalogClockWidget.onConfigurationChanged(this.mOrientation);
        }
    }

    public boolean isEditable() {
        return true;
    }

    public void onEdit() {
        try {
            Intent intent = Intent.parseUri(getSettingIntent(), 0);
            startActivityForResult(intent, 0);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }

    public String getSettingIntent() {
        Intent intent = new Intent(Constants.ACTION_INTENT_SETTING);
        intent.setClassName(Constants.SETTING_PACKAGE, Constants.SETTING_CLASS);
        intent.putExtra(Constants.WIDGET_TYPE, 1);
        intent.putExtra(Constants.KEY_DISPLAY_CITY_NAME, this.mClockConfig.bShowCityLabel);
        return intent.toUri(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void loadConfig() {
        Properties props = loadInstanceData();
        if (props == null) {
            saveClockConfig(getIntent());
        } else {
            this.mClockConfig = loadConfig(props, Constants.KEY_SELECT_CITY_CODE);
        }
    }

    private ClockConfig loadConfig(Properties props, String selectCity) {
        boolean bShowCityLabel;
        String citnameCode = props.getProperty(selectCity);
        ClockConfig config = new ClockConfig();
        String StrIsDisplayCityName = props.getProperty(Constants.KEY_DISPLAY_CITY_NAME);
        MyLog.i("AnalogClock initData~ StrIsDisplayCityName:" + StrIsDisplayCityName);
        if (StrIsDisplayCityName != null && StrIsDisplayCityName.length() > 0) {
            bShowCityLabel = Boolean.parseBoolean(StrIsDisplayCityName);
            MyLog.i("AnalogClock initData~ 1 bShowCityLabel:" + bShowCityLabel);
        } else {
            bShowCityLabel = true;
            MyLog.i("AnalogClock initData~ 2 bShowCityLabel:true");
        }
        config.citnameCode = citnameCode;
        config.bShowCityLabel = bShowCityLabel;
        return config;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void saveClockConfig(Intent intent) {
        if (intent != null) {
            String citnameCode = intent.getStringExtra(Constants.KEY_SELECT_CITY_CODE);
            boolean bShowCityLabel = intent.getBooleanExtra(Constants.KEY_DISPLAY_CITY_NAME, true);
            Properties props = new Properties();
            if (citnameCode != null) {
                try {
                    props.setProperty(Constants.KEY_SELECT_CITY_CODE, citnameCode);
                } catch (Exception e) {
                }
            }
            props.setProperty(Constants.KEY_DISPLAY_CITY_NAME, Boolean.toString(bShowCityLabel));
            storeInstanceData(props);
            ClockConfig config = new ClockConfig();
            config.citnameCode = citnameCode;
            config.bShowCityLabel = bShowCityLabel;
            this.mClockConfig = config;
        }
    }
}
