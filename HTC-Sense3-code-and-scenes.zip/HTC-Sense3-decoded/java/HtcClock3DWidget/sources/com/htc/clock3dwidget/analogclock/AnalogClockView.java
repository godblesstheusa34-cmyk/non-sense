package com.htc.clock3dwidget.analogclock;

import android.content.Context;
import android.content.res.Resources;
import android.os.Handler;
import android.os.SystemClock;
import android.text.format.DateFormat;
import android.view.View;
import com.htc.android.rosie.widget.Widget;
import com.htc.android.rosie.widget.WidgetHelper;
import com.htc.clock.util.MyLog;
import com.htc.clock.util.MyTimeUtil;
import com.htc.clock3dwidget.R;
import com.htc.clock3dwidget.util.DigitControl;
import com.htc.clock3dwidget.util.MyProjectSetting;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.Marker;
import com.htc.fusion.fx.MessageListener;
import com.htc.fusion.fx.controls.FxHitbox;
import com.htc.fusion.fx.controls.FxProgressBar;
import com.htc.fusion.fx.controls.FxTextLabel;
import java.util.Calendar;
import java.util.TimeZone;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class AnalogClockView {
    protected boolean isAnimation;
    public int mAMPM;
    protected CharSequence[] mAm_Pm;
    protected Calendar mCalendar;
    public FxTextLabel mCityName;
    private View.OnClickListener mClickListener;
    private ClickListener mClockClickLand;
    private ClickListener mClockClickPort;
    protected Context mContext;
    private String mDateFormat;
    protected CharSequence[] mDaysOfWeek;
    protected DigitControl mDigital_Hour;
    protected FxTimelineControl mDigital_Hour_ten;
    protected FxTimelineControl mDigital_Hour_unit;
    protected DigitControl mDigital_Minute;
    protected FxTimelineControl mDigital_Minute_ten;
    protected FxTimelineControl mDigital_Minute_unit;
    protected FxTimelineControl mFxClockBase;
    protected FxTimelineControl mFxClockDate;
    protected FxTimelineControl mFxClockHour;
    protected FxTimelineControl mFxClockMinute;
    protected FxTimelineControl mFxClockNumbers;
    protected FxHitbox mFxHitbox;
    protected FxProgressBar mFxPBHour;
    protected FxProgressBar mFxPBMin;
    protected FxProgressBar mFxPBSec;
    protected FxProgressBar mFxPBUintHour;
    protected FxProgressBar mFxPBUnitMin;
    protected FxTextLabel mFxTextAMPM;
    protected FxTextLabel mFxTextAMPM_night;
    protected FxTextLabel mFxTextDate;
    protected FxTextLabel mFxTextDate_night;
    protected FxTextLabel mFxTextHour;
    protected FxTextLabel mFxTextLongDate;
    protected FxTextLabel mFxTextMinute;
    protected FxTextLabel mFxTextSecond;
    protected FxTextLabel mFxTextWeekDay;
    protected FxTextLabel mFxTextWeekDay_night;
    protected FxTimelineControl mFxTimeLineGear01;
    protected FxTimelineControl mFxTimeLineGear02;
    protected FxTimelineControl mFxTimeLineGear03;
    protected FxTimelineControl mFxTimeLineGear04;
    protected FxTimelineControl mFxTimeLineGear05;
    protected FxTimelineControl mFxTimeLineWiggle;
    protected FxTimelineControl mFxTimelineAmPm;
    protected FxTimelineControl mFxTimelineAmPmOpp;
    protected FxTimelineControl mFxTimelineClock;
    protected FxTimelineControl mFxTimelineClockAmPm;
    public int mHour;
    protected FxTimelineControl mHourCap;
    protected Marker mMarkerHour;
    protected Marker mMarkerMin;
    protected FxTimelineControl mMinCap;
    protected int mMinuteFlipCount;
    public int mMinutes;
    protected CharSequence[] mMonth;
    protected int mRadius;
    protected Context mResContext;
    public int mSeconds;
    protected int mTextHeight;
    protected int mTextWidth;
    protected Marker mTileMark;
    protected FxTimelineControl mTiltAnime;
    private Widget.Host.Worker mUiHandler;
    private Handler mhUiHandler;
    private float mUnitMinValue = 0.0f;
    private float mUnitHourValue = 0.0f;
    private boolean mDayPanel = false;
    private boolean mDayPanelInit = false;
    protected String mDay = "";
    protected String mWeek = "";
    protected int mClockStyle = 0;
    private int mAmPmType = 0;
    private boolean mAmPmInit = false;
    private boolean mTimePBInit = false;
    private boolean mPaused = true;
    private boolean mTickerStopped = true;
    protected long mAnimStart = -1;
    private boolean m24HourFormat = false;
    private int mUpdateIntervals = 1000;
    public boolean mUseAnimation = MyProjectSetting.isFlipEnable();
    private boolean mFlipAnimePrepared = false;
    protected int mOldHour = 0;
    protected int mOldMinutes = 0;
    protected final int ANIMATION_HOUR_COUNT = 1;
    protected final int ANIMATION_MINUTE_COUNT = 2;
    private Runnable mTicker = new Runnable() { // from class: com.htc.clock3dwidget.analogclock.AnalogClockView.1
        @Override // java.lang.Runnable
        public void run() {
            if (!AnalogClockView.this.mTickerStopped) {
                AnalogClockView.this.updateTime();
                if (AnalogClockView.this.mUiHandler == null) {
                    if (AnalogClockView.this.mhUiHandler != null) {
                        long now = SystemClock.uptimeMillis();
                        AnalogClockView.this.mhUiHandler.postAtTime(AnalogClockView.this.mTicker, (AnalogClockView.this.mUpdateIntervals - (System.currentTimeMillis() % AnalogClockView.this.mUpdateIntervals)) + now);
                        return;
                    }
                    return;
                }
                long now2 = SystemClock.uptimeMillis();
                AnalogClockView.this.mUiHandler.postAtTime(AnalogClockView.this.mTicker, (AnalogClockView.this.mUpdateIntervals - (System.currentTimeMillis() % AnalogClockView.this.mUpdateIntervals)) + now2);
            }
        }
    };

    AnalogClockView(Context resContext, Context context) {
        this.mClockClickPort = new ClickListener();
        this.mClockClickLand = new ClickListener();
        this.mResContext = resContext;
        this.mContext = context;
        Resources r = this.mResContext.getResources();
        this.mDaysOfWeek = r.getTextArray(R.array.days_of_week_capital);
        this.mMonth = r.getTextArray(R.array.month_of_year);
        this.mAm_Pm = r.getTextArray(R.array.am_and_pm_capital);
    }

    public void init(FxAnalogControls controls) {
        this.mFxHitbox = controls.mFxHitbox;
        this.mFxPBHour = controls.mFxPBHour;
        this.mFxPBMin = controls.mFxPBMin;
        this.mFxPBSec = controls.mFxPBSec;
        this.mFxPBUintHour = controls.mFxPBUintHour;
        this.mFxPBUnitMin = controls.mFxPBUnitMin;
        this.mCityName = controls.mCityName;
        this.mDigital_Hour_ten = controls.mDigital_Hour_ten;
        this.mDigital_Hour_unit = controls.mDigital_Hour_unit;
        this.mDigital_Minute_ten = controls.mDigital_Minute_ten;
        this.mDigital_Minute_unit = controls.mDigital_Minute_unit;
        this.mFxTimeLineGear01 = controls.mFxTimeLineGear01;
        this.mFxTimeLineGear02 = controls.mFxTimeLineGear02;
        this.mFxTimeLineGear03 = controls.mFxTimeLineGear03;
        this.mFxTimeLineGear04 = controls.mFxTimeLineGear04;
        this.mFxTimeLineGear05 = controls.mFxTimeLineGear05;
        this.mFxTimeLineWiggle = controls.mFxTimelineWiggle;
        this.mFxTextHour = controls.mFxTextHour;
        this.mFxTextMinute = controls.mFxTextMinute;
        this.mFxTextSecond = controls.mFxTextSecond;
        this.mFxClockBase = controls.mFxClockBase;
        this.mFxClockNumbers = controls.mFxClockNumbers;
        this.mFxClockDate = controls.mFxClockDate;
        this.mFxClockHour = controls.mFxClockHour;
        this.mFxClockMinute = controls.mFxClockMinute;
        this.mFxTimelineClock = controls.mFxTimelineClock;
        this.mFxTimelineAmPm = controls.mFxTimelineAmPm;
        this.mFxTimelineAmPmOpp = controls.mFxTimelineAmPmOpp;
        this.mFxTimelineClockAmPm = controls.mFxTimelineClockAmPm;
        this.mFxTextDate = controls.mFxTextDate;
        this.mFxTextLongDate = controls.mFxTextLongDate;
        this.mFxTextWeekDay = controls.mFxTextWeekDay;
        this.mFxTextAMPM = controls.mFxTextAMPM;
        this.mFxTextDate_night = controls.mFxTextDate_night;
        this.mFxTextWeekDay_night = controls.mFxTextWeekDay_night;
        this.mFxTextAMPM_night = controls.mFxTextAMPM_night;
        if (this.mFxPBSec != null) {
            this.mUpdateIntervals = 1000;
        } else {
            this.mUpdateIntervals = 60000;
        }
        this.mDigital_Hour = controls.mDigital_Hour;
        this.mDigital_Minute = controls.mDigital_Minute;
        if (this.mDigital_Hour != null && this.mDigital_Minute != null && MyProjectSetting.isFlipEnable()) {
            this.mUseAnimation = true;
        } else {
            this.mUseAnimation = false;
        }
        this.mTiltAnime = controls.mTiltAnime;
        this.mTileMark = controls.mTileMark;
        this.mHourCap = controls.mHourCap;
        this.mMarkerHour = controls.mMarkerHour;
        this.mMinCap = controls.mMinCap;
        this.mMarkerMin = controls.mMarkerMin;
        this.mDayPanelInit = false;
        this.mAmPmInit = false;
        this.mTimePBInit = false;
    }

    public void bind(FxAnalogControls controlsPort, FxAnalogControls controlsLand) {
        controlsPort.mFxHitbox.getTapSource().bind(this.mClockClickPort);
        controlsPort.bind();
        if (!controlsPort.equals(controlsLand)) {
            controlsLand.mFxHitbox.getTapSource().bind(this.mClockClickLand);
            controlsLand.bind();
        }
    }

    public void unbind(FxAnalogControls controlsPort, FxAnalogControls controlsLand) {
        controlsPort.mFxHitbox.getTapSource().unbind(this.mClockClickPort);
        controlsPort.unbind();
        if (!controlsPort.equals(controlsLand)) {
            controlsLand.mFxHitbox.getTapSource().unbind(this.mClockClickLand);
            controlsLand.unbind();
        }
    }

    private float calcHourPBValue(float max, int nHour, int nMin, int nSec) {
        float nPBMax = max + 1.0f;
        float nSeconds = (nHour * 3600) + (nMin * 60) + nSec;
        return (nSeconds * nPBMax) / 43200.0f;
    }

    private float calcMinPBValue(float max, int nMin, int nSec) {
        float nPBMax = max + 1.0f;
        float nSeconds = (nMin * 60) + nSec;
        return (nSeconds * nPBMax) / 3600.0f;
    }

    private float calcSecPBValue(float max, int nSec) {
        float nPBMax = max + 1.0f;
        return (nSec * nPBMax) / 60.0f;
    }

    protected void switchDayNightPanel(boolean bDayPanel) {
        if ((this.mDayPanel == bDayPanel && this.mDayPanelInit) ? false : true) {
            this.mDayPanel = bDayPanel;
            this.mDayPanelInit = true;
            if (this.mDayPanel) {
                if (this.mFxClockBase != null) {
                    this.mFxClockBase.playFrames(30, 0);
                }
                if (this.mFxClockNumbers != null) {
                    this.mFxClockNumbers.playFrames(30, 0);
                }
                if (this.mFxClockDate != null) {
                    this.mFxClockDate.playFrames(30, 0);
                }
                if (this.mFxClockHour != null) {
                    this.mFxClockHour.playFrames(30, 0);
                }
                if (this.mFxClockMinute != null) {
                    this.mFxClockMinute.playFrames(30, 0);
                    return;
                }
                return;
            }
            if (this.mFxClockBase != null) {
                this.mFxClockBase.playFrames(0, 30);
            }
            if (this.mFxClockNumbers != null) {
                this.mFxClockNumbers.playFrames(0, 30);
            }
            if (this.mFxClockDate != null) {
                this.mFxClockDate.playFrames(0, 30);
            }
            if (this.mFxClockHour != null) {
                this.mFxClockHour.playFrames(0, 30);
            }
            if (this.mFxClockMinute != null) {
                this.mFxClockMinute.playFrames(0, 30);
            }
        }
    }

    protected Context getContext() {
        return this.mContext;
    }

    public void invalidate(boolean useAnimation) {
        if ((this.mAMPM == 0 && this.mHour < 6) || (this.mAMPM == 1 && this.mHour >= 6)) {
            switchDayNightPanel(false);
        } else {
            switchDayNightPanel(true);
        }
        showRingText();
        showTimePB();
        showDateWeekText();
        if (this.mAMPM == 0) {
            showAMInfo();
        } else {
            showPMInfo();
        }
        showHourMinuteInfo(useAnimation);
    }

    private void showHourMinuteInfo(boolean useAnimation) {
        int hour = this.mHour;
        if (this.m24HourFormat) {
            if (this.mCalendar.get(9) == 1) {
                hour += 12;
            }
            if (this.mDigital_Hour != null) {
                this.mDigital_Hour.setAmPm(-1);
            }
        } else {
            if (hour == 0) {
                hour = 12;
            }
            if (this.mDigital_Hour != null) {
                this.mDigital_Hour.setAmPm(this.mCalendar.get(9));
            }
        }
        setHourMinute(hour, this.mMinutes);
        if (useAnimation) {
            if (this.mDigital_Hour != null && this.mDigital_Minute != null) {
                this.mDigital_Hour.setDestNumber(hour);
                this.mDigital_Minute.setDestNumber(this.mMinutes);
                return;
            }
            return;
        }
        if (this.mDigital_Hour != null && this.mDigital_Minute != null) {
            this.mDigital_Hour.setCurrentNumber(hour);
            this.mDigital_Minute.setCurrentNumber(this.mMinutes);
        }
    }

    private void showDateWeekText() {
        if (this.mFxTextDate != null) {
            this.mFxTextDate.setString(this.mDay);
        }
        if (this.mFxTextDate_night != null) {
            this.mFxTextDate_night.setString(this.mDay);
        }
        if (this.mFxTextLongDate != null && this.mDateFormat != null) {
            String text = DateFormat.format(this.mDateFormat, this.mCalendar).toString();
            this.mFxTextLongDate.setString(text);
        }
        if (this.mFxTextWeekDay != null) {
            this.mFxTextWeekDay.setString(this.mWeek);
        }
        if (this.mFxTextWeekDay_night != null) {
            this.mFxTextWeekDay_night.setString(this.mWeek);
        }
    }

    private void showRingText() {
        if (this.mFxTextHour != null) {
            int hour = this.mHour == 0 ? this.mHour + 12 : this.mHour;
            String hourStr = Integer.toString(hour);
            if (!hourStr.equals(this.mFxTextHour.getString())) {
                this.mFxTextHour.setString(hourStr);
            }
        }
        if (this.mFxTextMinute != null) {
            String minuteStr = Integer.toString(this.mMinutes);
            if (!minuteStr.equals(this.mFxTextMinute.getString())) {
                this.mFxTextMinute.setString(minuteStr);
            }
        }
        if (this.mFxTextSecond != null) {
            String secondStr = Integer.toString(this.mSeconds);
            if (!secondStr.equals(this.mFxTextSecond.getString())) {
                this.mFxTextSecond.setString(secondStr);
            }
        }
    }

    private void showTimePB() {
        if (this.mFxPBHour != null) {
            this.mFxPBHour.setValue(calcHourPBValue(this.mFxPBHour.getValueMax(), this.mHour, this.mMinutes, this.mSeconds));
        }
        if (this.mFxPBMin != null) {
            this.mFxPBMin.setValue(calcMinPBValue(this.mFxPBMin.getValueMax(), this.mMinutes, this.mSeconds));
        }
        if (this.mFxPBSec != null) {
            this.mFxPBSec.setValue(calcSecPBValue(this.mFxPBSec.getValueMax(), this.mSeconds));
        }
        if (this.mFxPBUintHour != null) {
            float current = calcHourPBValue(this.mFxPBUintHour.getValueMax(), this.mHour, 0, 0);
            if (current != this.mUnitHourValue || !this.mTimePBInit) {
                if (Math.abs(this.mUnitHourValue - current) < 31.0f && this.mTimePBInit) {
                    this.mFxPBUintHour.playFrames((int) this.mUnitHourValue, (int) current);
                } else {
                    this.mFxPBUintHour.setFrame(current);
                }
                this.mUnitHourValue = current;
            }
        }
        if (this.mFxPBUnitMin != null) {
            float current2 = calcMinPBValue(this.mFxPBUnitMin.getValueMax(), this.mMinutes, 0);
            if (current2 != this.mUnitMinValue || !this.mTimePBInit) {
                if (Math.abs(this.mUnitMinValue - current2) < 3.0f && this.mTimePBInit) {
                    this.mFxPBUnitMin.playFrames((int) this.mUnitMinValue, (int) current2);
                } else {
                    this.mFxPBUnitMin.setFrame(current2);
                }
                this.mUnitMinValue = current2;
            }
        }
        if (!this.mTimePBInit) {
            this.mTimePBInit = true;
        }
    }

    private void showAMInfo() {
        if (this.mFxTextAMPM != null) {
            this.mFxTextAMPM.setString(this.mAm_Pm[0].toString());
        }
        if (this.mFxTextAMPM_night != null) {
            this.mFxTextAMPM_night.setString(this.mAm_Pm[0].toString());
        }
        if (this.mFxTimelineAmPm != null && (this.mAmPmType != this.mAMPM || !this.mAmPmInit)) {
            this.mAmPmType = this.mAMPM;
            if (this.mAmPmInit) {
                this.mFxTimelineAmPm.playFrames(10, 0);
            } else {
                this.mFxTimelineAmPm.setFrame(0.0f);
                this.mAmPmInit = true;
            }
        }
        if (this.m24HourFormat) {
            if (this.mFxTimelineAmPmOpp != null) {
                if (this.mAmPmType != this.mAMPM || !this.mAmPmInit) {
                    this.mAmPmType = this.mAMPM;
                    this.mAmPmInit = true;
                }
                this.mFxTimelineAmPmOpp.setVisibility(false);
            }
            if (this.mFxTimelineClockAmPm != null) {
                if (this.mAmPmType != this.mAMPM || !this.mAmPmInit) {
                    this.mAmPmType = this.mAMPM;
                    this.mAmPmInit = true;
                }
                this.mFxTimelineClockAmPm.setVisibility(false);
                return;
            }
            return;
        }
        if (this.mFxTimelineAmPmOpp != null) {
            if (this.mAmPmType != this.mAMPM || !this.mAmPmInit) {
                this.mAmPmType = this.mAMPM;
                if (this.mAmPmInit) {
                    this.mFxTimelineAmPmOpp.playFrames(0, 10);
                } else {
                    this.mFxTimelineAmPmOpp.setFrame(10.0f);
                    this.mAmPmInit = true;
                }
            }
            this.mFxTimelineAmPmOpp.setVisibility(true);
        }
        if (this.mFxTimelineClockAmPm != null) {
            if (this.mAmPmType != this.mAMPM || !this.mAmPmInit) {
                this.mAmPmType = this.mAMPM;
                if (this.mAmPmInit) {
                    this.mFxTimelineClockAmPm.playFrames(1, 0);
                } else {
                    this.mAmPmInit = true;
                    this.mFxTimelineClockAmPm.setFrame(0.0f);
                }
            }
            this.mFxTimelineClockAmPm.setVisibility(true);
        }
    }

    private void showPMInfo() {
        if (this.mFxTextAMPM != null) {
            this.mFxTextAMPM.setString(this.mAm_Pm[1].toString());
        }
        if (this.mFxTextAMPM_night != null) {
            this.mFxTextAMPM_night.setString(this.mAm_Pm[1].toString());
        }
        if (this.mFxTimelineAmPm != null && (this.mAmPmType != this.mAMPM || !this.mAmPmInit)) {
            this.mAmPmType = this.mAMPM;
            if (this.mAmPmInit) {
                this.mFxTimelineAmPm.playFrames(0, 10);
            } else {
                this.mAmPmInit = true;
                this.mFxTimelineAmPm.setFrame(10.0f);
            }
        }
        if (this.m24HourFormat) {
            if (this.mFxTimelineAmPmOpp != null) {
                if (this.mAmPmType != this.mAMPM || !this.mAmPmInit) {
                    this.mAmPmType = this.mAMPM;
                    this.mAmPmInit = true;
                }
                this.mFxTimelineAmPmOpp.setVisibility(false);
            }
            if (this.mFxTimelineClockAmPm != null) {
                if (this.mAmPmType != this.mAMPM || !this.mAmPmInit) {
                    this.mAmPmType = this.mAMPM;
                    this.mAmPmInit = true;
                }
                this.mFxTimelineClockAmPm.setVisibility(false);
                return;
            }
            return;
        }
        if (this.mFxTimelineAmPmOpp != null) {
            if (this.mAmPmType != this.mAMPM || !this.mAmPmInit) {
                this.mAmPmType = this.mAMPM;
                if (this.mAmPmInit) {
                    this.mFxTimelineAmPmOpp.playFrames(10, 0);
                } else {
                    this.mAmPmInit = true;
                    this.mFxTimelineAmPmOpp.setFrame(0.0f);
                }
            }
            this.mFxTimelineAmPmOpp.setVisibility(true);
        }
        if (this.mFxTimelineClockAmPm != null) {
            if (this.mAmPmType != this.mAMPM || !this.mAmPmInit) {
                this.mAmPmType = this.mAMPM;
                if (this.mAmPmInit) {
                    this.mFxTimelineClockAmPm.playFrames(0, 1);
                } else {
                    this.mAmPmInit = true;
                    this.mFxTimelineClockAmPm.setFrame(1.0f);
                }
            }
            this.mFxTimelineClockAmPm.setVisibility(true);
        }
    }

    private void setHourMinute(int hour, int minute) {
        if (this.mDigital_Hour_ten != null) {
            if (hour / 10 < 1) {
                this.mDigital_Hour_ten.setVisibility(false);
            } else {
                this.mDigital_Hour_ten.setVisibility(true);
                this.mDigital_Hour_ten.setFrame(hour / 10);
            }
        }
        if (this.mDigital_Hour_unit != null) {
            this.mDigital_Hour_unit.setFrame(hour % 10);
        }
        if (this.mDigital_Minute_ten != null) {
            this.mDigital_Minute_ten.setFrame(minute / 10);
        }
        if (this.mDigital_Minute_unit != null) {
            this.mDigital_Minute_unit.setFrame(minute % 10);
        }
    }

    private class ClickListener extends MessageListener<FxHitbox.TapParameters> {
        private ClickListener() {
        }

        public void onMessageReceived(FxHitbox.TapParameters message) {
            if (AnalogClockView.this.mClickListener != null) {
                AnalogClockView.this.mClickListener.onClick(null);
            }
        }
    }

    public void setDateFormat(boolean is24HourFormat, String dateFormat) {
        this.m24HourFormat = is24HourFormat;
        this.mDateFormat = dateFormat;
        this.mAmPmInit = false;
    }

    public void setOnClickListener(View.OnClickListener l) {
        this.mClickListener = l;
    }

    public String getTimeZoneId() {
        if (this.mCalendar == null) {
            return "";
        }
        String timezoneId = this.mCalendar.getTimeZone().getID();
        return timezoneId;
    }

    public void setTimeZone(String timezone) {
        TimeZone tz;
        if (timezone == null || timezone.length() <= 0) {
            tz = TimeZone.getDefault();
        } else {
            tz = TimeZone.getTimeZone(timezone);
        }
        this.mCalendar = Calendar.getInstance(tz);
    }

    public void clear() {
        this.mPaused = true;
        stopGears();
        stopWiggle();
        stopTickers();
    }

    public void setPause(boolean value) {
        synchronized (this) {
            this.mPaused = value;
            if (this.mPaused) {
                this.mTickerStopped = true;
                stopTickers();
                stopGears();
                stopWiggle();
            } else {
                startTickers();
                playGears();
                onTimeChanged();
            }
        }
    }

    public boolean isPaused() {
        return this.mPaused;
    }

    public void playGears() {
        if (this.mFxTimeLineGear01 != null) {
            this.mFxTimeLineGear01.playMarker("walk", 1, 1.0f, false);
        }
        if (this.mFxTimeLineGear02 != null) {
            this.mFxTimeLineGear02.playMarker("walk", 1, 1.0f, false);
        }
        if (this.mFxTimeLineGear03 != null) {
            this.mFxTimeLineGear03.playMarker("walk", 1, 1.0f, false);
        }
        if (this.mFxTimeLineGear04 != null) {
            this.mFxTimeLineGear04.playMarker("walk", 1, 1.0f, false);
        }
        if (this.mFxTimeLineGear05 != null) {
            this.mFxTimeLineGear05.playMarker("walk", 1, 1.0f, false);
        }
    }

    public void playWiggle() {
        if (this.mFxTimeLineWiggle != null) {
            this.mFxTimeLineWiggle.playMarker("start_wiggle", 0, 1.0f, false);
        }
    }

    private void stopGears() {
        if (this.mFxTimeLineGear01 != null) {
            this.mFxTimeLineGear01.stop();
        }
        if (this.mFxTimeLineGear02 != null) {
            this.mFxTimeLineGear02.stop();
        }
        if (this.mFxTimeLineGear03 != null) {
            this.mFxTimeLineGear03.stop();
        }
        if (this.mFxTimeLineGear04 != null) {
            this.mFxTimeLineGear04.stop();
        }
        if (this.mFxTimeLineGear05 != null) {
            this.mFxTimeLineGear05.stop();
        }
    }

    public void stopWiggle() {
        if (this.mFxTimeLineWiggle != null) {
            this.mFxTimeLineWiggle.stop();
        }
    }

    public void setAnimationFeedback(boolean ani, Widget.Host.Worker uiHandler, Handler uihHandler) {
        this.isAnimation = ani;
        this.mUiHandler = uiHandler;
        this.mhUiHandler = uihHandler;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateTime() {
        if (this.mPaused) {
            MyLog.w("onTimeChanged~ mPaused is true");
        } else if (this.mCalendar == null) {
            MyLog.w("onTimeChanged mCalendar null");
        } else {
            setData();
            invalidate(true);
        }
    }

    public void onTimeChanged() {
        if (this.mPaused) {
            MyLog.w("onTimeChanged~ mPaused is true");
        } else {
            if (this.mCalendar == null) {
                MyLog.w("onTimeChanged mCalendar null");
                return;
            }
            setData();
            this.mMinuteFlipCount = 1;
            invalidate(true);
        }
    }

    public void prepareAnimation() {
        if (this.mUseAnimation) {
            this.mCalendar.setTimeInMillis(System.currentTimeMillis());
            this.mMinutes = this.mCalendar.get(12);
            this.mHour = this.mCalendar.get(10);
            if (this.m24HourFormat) {
                if (this.mCalendar.get(9) == 1) {
                    this.mHour += 12;
                }
                if (this.mDigital_Hour != null) {
                    this.mDigital_Hour.setAmPm(-1);
                }
                this.mOldHour = ((this.mHour + 24) - 1) % 24;
            } else {
                if (this.mHour == 0) {
                    this.mHour = 12;
                }
                if (this.mDigital_Hour != null) {
                    this.mDigital_Hour.setAmPm(this.mCalendar.get(9));
                }
                this.mOldHour = ((this.mHour + 12) - 1) % 12;
                if (this.mOldHour == 0) {
                    this.mOldHour = 12;
                }
            }
            this.mOldMinutes = ((this.mMinutes + 60) - 2) % 60;
            if (this.mDigital_Hour != null && this.mDigital_Minute != null) {
                this.mDigital_Hour.setCurrentNumber(this.mOldHour);
                this.mDigital_Minute.setCurrentNumber(this.mOldMinutes);
            }
            MyLog.i("prepareAnimation~ mOldHour:" + this.mOldHour + " mOldMinutes:" + this.mOldMinutes);
            this.mFlipAnimePrepared = true;
        }
    }

    public void startAnimation() {
        startAnimation(false);
    }

    public void startAnimation(boolean bPause) {
        this.mPaused = bPause;
        if (this.mUseAnimation) {
            if (!this.mFlipAnimePrepared) {
                setPause(bPause);
                return;
            }
            MyLog.i("startAnimation~");
            this.mCalendar.setTimeInMillis(System.currentTimeMillis());
            this.mMinutes = this.mCalendar.get(12);
            this.mHour = this.mCalendar.get(10);
            if (this.m24HourFormat) {
                if (this.mCalendar.get(9) == 1) {
                    this.mHour += 12;
                }
                if (this.mDigital_Hour != null) {
                    this.mDigital_Hour.setAmPm(-1);
                }
            } else {
                if (this.mHour == 0) {
                    this.mHour = 12;
                }
                if (this.mDigital_Hour != null) {
                    this.mDigital_Hour.setAmPm(this.mCalendar.get(9));
                }
            }
            this.mMinuteFlipCount = 2;
            applyRotation();
            this.mFlipAnimePrepared = false;
            startTickers();
            playGears();
        }
    }

    private void startTickers() {
        if (this.mTicker != null && this.mTickerStopped) {
            this.mTickerStopped = false;
            if (this.mUiHandler != null) {
                long now = SystemClock.uptimeMillis();
                this.mUiHandler.postAtTime(this.mTicker, (this.mUpdateIntervals - (System.currentTimeMillis() % this.mUpdateIntervals)) + now);
            } else if (this.mhUiHandler != null) {
                long now2 = SystemClock.uptimeMillis();
                this.mhUiHandler.postAtTime(this.mTicker, (this.mUpdateIntervals - (System.currentTimeMillis() % this.mUpdateIntervals)) + now2);
            }
        }
    }

    private void stopTickers() {
        if (this.mTicker != null) {
            this.mTickerStopped = true;
            if (this.mUiHandler != null) {
                this.mUiHandler.cancel(this.mTicker);
            } else if (this.mhUiHandler != null) {
                this.mhUiHandler.removeCallbacks(this.mTicker);
            }
        }
    }

    private void applyRotation() {
        if (this.mDigital_Hour != null && this.mDigital_Minute != null) {
            this.mDigital_Hour.setDestNumber(this.mHour);
            this.mDigital_Minute.setDestNumber(this.mMinutes, 2);
        }
    }

    private void setData() {
        this.mCalendar.setTimeInMillis(System.currentTimeMillis());
        this.mHour = this.mCalendar.get(10);
        this.mMinutes = this.mCalendar.get(12);
        this.mSeconds = this.mCalendar.get(13);
        this.mAMPM = this.mCalendar.get(9);
        this.mOldHour = this.mHour;
        this.mOldMinutes = this.mMinutes;
        int dayOfWeek = this.mCalendar.get(7);
        this.mWeek = this.mDaysOfWeek[dayOfWeek].toString();
        this.mDay = MyTimeUtil.getDateString(this.mMonth, this.mCalendar);
    }

    public void doTiltChanged(float tilt) {
        if (this.mTiltAnime != null && this.mTileMark != null) {
            float frame = WidgetHelper.convertTiltAngleToFrame(tilt, this.mTileMark.StartFrame, this.mTileMark.EndFrame);
            this.mTiltAnime.setFrame(frame);
        }
        if (this.mHourCap != null && this.mMarkerHour != null) {
            float frame2 = WidgetHelper.convertTiltAngleToFrame(tilt, this.mMarkerHour.StartFrame, this.mMarkerHour.EndFrame);
            this.mHourCap.setFrame(frame2);
        }
        if (this.mMinCap != null && this.mMarkerMin != null) {
            float frame3 = WidgetHelper.convertTiltAngleToFrame(tilt, this.mMarkerMin.StartFrame, this.mMarkerMin.EndFrame);
            this.mMinCap.setFrame(frame3);
        }
        if (this.mDigital_Minute != null) {
            this.mDigital_Minute.doTiltChanged(tilt);
        }
        if (this.mDigital_Hour != null) {
            this.mDigital_Hour.doTiltChanged(tilt);
        }
    }
}
