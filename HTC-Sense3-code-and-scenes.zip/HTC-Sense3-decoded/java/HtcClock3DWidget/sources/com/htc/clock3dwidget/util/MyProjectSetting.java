package com.htc.clock3dwidget.util;

import android.os.SystemProperties;
import com.htc.clock.util.MyLog;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class MyProjectSetting {
    public static boolean hasTravelClock() {
        return true;
    }

    public static boolean hasWeatherClock() {
        return true;
    }

    public static boolean hasWeatherWallpaper() {
        boolean testWWP = SystemProperties.getBoolean("persist.debug.testAP.WWP", false);
        if (!testWWP && !hasWeatherAp()) {
            return false;
        }
        return true;
    }

    public static boolean hasCurrentLocation() {
        if (!isChina() || isChinaLocationService()) {
            return true;
        }
        return false;
    }

    public static boolean isChinaLocationService() {
        return isChina();
    }

    public static boolean hasWeatherAp() {
        return true;
    }

    public static boolean hasSeparateLine() {
        return ((double) Float.parseFloat("3.0")) < 2.0d;
    }

    public static boolean hasSeparateLine2() {
        return true;
    }

    public static boolean isChina() {
        MyLog.i("isChina Language Flag = 0 Device Flag = 123 Project Flag = 52");
        return false;
    }

    public static boolean isHelpTurnOnLoc() {
        return true;
    }

    public static boolean isFlipEnable() {
        return true;
    }
}
