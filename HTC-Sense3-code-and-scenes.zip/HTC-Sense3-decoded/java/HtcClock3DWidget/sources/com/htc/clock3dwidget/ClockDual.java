package com.htc.clock3dwidget;

import android.os.Bundle;
import com.htc.clock3dwidget.ClockUtils;
import com.htc.clock3dwidget.analogclock.DualClockWidgetView;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class ClockDual extends DualClockWidgetView {
    @Override // com.htc.clock3dwidget.analogclock.DualClockWidgetView
    public void onCreate(Bundle saved) {
        this.mClockResCurrent = ClockUtils.getClockRes(ClockUtils.ClockType.CLOCK_DUAL_R, getHost().getContext());
        this.mClockResHome = ClockUtils.getClockRes(ClockUtils.ClockType.CLOCK_DUAL_L, getHost().getContext());
        super.onCreate(saved);
    }
}
