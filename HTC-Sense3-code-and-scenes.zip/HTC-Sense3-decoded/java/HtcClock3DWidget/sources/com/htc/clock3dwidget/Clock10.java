package com.htc.clock3dwidget;

import android.os.Bundle;
import com.htc.clock3dwidget.ClockUtils;
import com.htc.clock3dwidget.analogclock.AnalogClockWidgetView;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class Clock10 extends AnalogClockWidgetView {
    @Override // com.htc.clock3dwidget.analogclock.AnalogClockWidgetView
    public void onCreate(Bundle saved) {
        this.mClockType = ClockUtils.ClockType.CLOCK_10;
        super.onCreate(saved);
    }
}
