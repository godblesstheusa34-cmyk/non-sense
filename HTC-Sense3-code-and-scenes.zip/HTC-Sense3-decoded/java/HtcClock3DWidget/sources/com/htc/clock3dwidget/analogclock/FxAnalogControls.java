package com.htc.clock3dwidget.analogclock;

import com.htc.clock3dwidget.ClockRes;
import com.htc.clock3dwidget.util.DigitControl;
import com.htc.fusion.fx.FxObject;
import com.htc.fusion.fx.FxScene;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.Marker;
import com.htc.fusion.fx.controls.FxHitbox;
import com.htc.fusion.fx.controls.FxProgressBar;
import com.htc.fusion.fx.controls.FxTextLabel;
import java.util.ArrayList;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class FxAnalogControls {
    private static final String HOUR = "timeline.flip_hour";
    private static final String MIN = "timeline.flip_minute";
    private static final String TILT = "timeline.tiltanim";
    public FxTextLabel mCityName;
    public DigitControl mDigital_Hour;
    public FxTimelineControl mDigital_Hour_ten;
    public FxTimelineControl mDigital_Hour_unit;
    public DigitControl mDigital_Minute;
    public FxTimelineControl mDigital_Minute_ten;
    public FxTimelineControl mDigital_Minute_unit;
    public FxTimelineControl mFxClockBase;
    public FxTimelineControl mFxClockDate;
    public FxTimelineControl mFxClockHour;
    public FxTimelineControl mFxClockMinute;
    public FxTimelineControl mFxClockNumbers;
    private FxTimelineControl mFxDigitalHour;
    private FxTimelineControl mFxDigitalMinute;
    public FxHitbox mFxHitbox;
    public FxProgressBar mFxPBHour;
    public FxProgressBar mFxPBMin;
    public FxProgressBar mFxPBSec;
    public FxProgressBar mFxPBUintHour;
    public FxProgressBar mFxPBUnitMin;
    public FxTextLabel mFxTextAMPM;
    public FxTextLabel mFxTextAMPM_night;
    public FxTextLabel mFxTextDate;
    public FxTextLabel mFxTextDate_night;
    public FxTextLabel mFxTextHour;
    public FxTextLabel mFxTextLongDate;
    public FxTextLabel mFxTextMinute;
    public FxTextLabel mFxTextSecond;
    public FxTextLabel mFxTextWeekDay;
    public FxTextLabel mFxTextWeekDay_night;
    public FxTimelineControl mFxTimeLineGear01;
    public FxTimelineControl mFxTimeLineGear02;
    public FxTimelineControl mFxTimeLineGear03;
    public FxTimelineControl mFxTimeLineGear04;
    public FxTimelineControl mFxTimeLineGear05;
    public FxTimelineControl mFxTimelineAmPm;
    public FxTimelineControl mFxTimelineAmPmOpp;
    public FxTimelineControl mFxTimelineClock;
    public FxTimelineControl mFxTimelineClockAmPm;
    public FxTimelineControl mFxTimelineWiggle;
    public FxTimelineControl mHourCap;
    public Marker mMarkerHour;
    public Marker mMarkerMin;
    public FxTimelineControl mMinCap;
    public Marker mTileMark;
    public FxTimelineControl mTiltAnime;

    public FxAnalogControls(FxScene scene, ClockRes res) {
        ArrayList<String> nameList = new ArrayList<>();
        getFxControls(scene, res, nameList, null);
        FxObject[] objs = scene.getDescendants((String[]) nameList.toArray(new String[0]));
        getFxControls(scene, res, null, objs);
        setupControls();
        reset();
    }

    private void getFxControls(FxScene scene, ClockRes res, ArrayList<String> nameList, FxObject[] objs) {
        int index;
        boolean name = nameList != null;
        int index2 = 0;
        if (res.hitboxClock != null) {
            if (!name) {
                this.mFxHitbox = (FxHitbox) objs[0];
                index2 = 0 + 1;
            } else {
                nameList.add(res.hitboxClock);
            }
        }
        if (res.progressBarHourHand != null) {
            if (name) {
                nameList.add(res.progressBarHourHand);
            } else {
                this.mFxPBHour = (FxProgressBar) objs[index2];
                index2++;
            }
        }
        if (res.progressBarMinuteHand != null) {
            if (name) {
                nameList.add(res.progressBarMinuteHand);
            } else {
                this.mFxPBMin = (FxProgressBar) objs[index2];
                index2++;
            }
        }
        if (res.progressBarSecondHand != null) {
            if (name) {
                nameList.add(res.progressBarSecondHand);
            } else {
                this.mFxPBSec = (FxProgressBar) objs[index2];
                index2++;
            }
        }
        if (res.progressBarUnitHourHand != null) {
            if (name) {
                nameList.add(res.progressBarUnitHourHand);
            } else {
                this.mFxPBUintHour = (FxProgressBar) objs[index2];
                index2++;
            }
        }
        if (res.progressBarUnitMinuteHand != null) {
            if (name) {
                nameList.add(res.progressBarUnitMinuteHand);
            } else {
                this.mFxPBUnitMin = (FxProgressBar) objs[index2];
                index2++;
            }
        }
        if (res.textLabelCityName != null) {
            if (name) {
                nameList.add(res.textLabelCityName);
            } else {
                this.mCityName = (FxTextLabel) objs[index2];
                index2++;
            }
        }
        if (res.timelineHourTen != null) {
            if (name) {
                nameList.add(res.timelineHourTen);
            } else {
                this.mDigital_Hour_ten = (FxTimelineControl) objs[index2];
                index2++;
            }
        }
        if (res.timelineHourUnit != null) {
            if (name) {
                nameList.add(res.timelineHourUnit);
            } else {
                this.mDigital_Hour_unit = (FxTimelineControl) objs[index2];
                index2++;
            }
        }
        if (res.timelineMinuteTen != null) {
            if (name) {
                nameList.add(res.timelineMinuteTen);
            } else {
                this.mDigital_Minute_ten = (FxTimelineControl) objs[index2];
                index2++;
            }
        }
        if (res.timelineMinuteUinit != null) {
            if (name) {
                nameList.add(res.timelineMinuteUinit);
            } else {
                this.mDigital_Minute_unit = (FxTimelineControl) objs[index2];
                index2++;
            }
        }
        if (res.timelineGear01 != null) {
            if (name) {
                nameList.add(res.timelineGear01);
            } else {
                this.mFxTimeLineGear01 = (FxTimelineControl) objs[index2];
                index2++;
            }
        }
        if (res.timelineGear02 != null) {
            if (name) {
                nameList.add(res.timelineGear02);
            } else {
                this.mFxTimeLineGear02 = (FxTimelineControl) objs[index2];
                index2++;
            }
        }
        if (res.timelineGear03 != null) {
            if (name) {
                nameList.add(res.timelineGear03);
            } else {
                this.mFxTimeLineGear03 = (FxTimelineControl) objs[index2];
                index2++;
            }
        }
        if (res.timelineGear04 != null) {
            if (name) {
                nameList.add(res.timelineGear04);
            } else {
                this.mFxTimeLineGear04 = (FxTimelineControl) objs[index2];
                index2++;
            }
        }
        if (res.timelineGear05 != null) {
            if (name) {
                nameList.add(res.timelineGear05);
            } else {
                this.mFxTimeLineGear05 = (FxTimelineControl) objs[index2];
                index2++;
            }
        }
        if (res.timelineWiggle != null) {
            if (name) {
                nameList.add(res.timelineWiggle);
            } else {
                this.mFxTimelineWiggle = (FxTimelineControl) objs[index2];
                index2++;
            }
        }
        if (res.textLabelHour != null) {
            if (name) {
                nameList.add(res.textLabelHour);
            } else {
                this.mFxTextHour = (FxTextLabel) objs[index2];
                index2++;
            }
        }
        if (res.textLabelMinute != null) {
            if (name) {
                nameList.add(res.textLabelMinute);
            } else {
                this.mFxTextMinute = (FxTextLabel) objs[index2];
                index2++;
            }
        }
        if (res.textLabelSecond != null) {
            if (name) {
                nameList.add(res.textLabelSecond);
            } else {
                this.mFxTextSecond = (FxTextLabel) objs[index2];
                index2++;
            }
        }
        if (res.timelineClockBase != null) {
            if (name) {
                nameList.add(res.timelineClockBase);
            } else {
                this.mFxClockBase = (FxTimelineControl) objs[index2];
                index2++;
            }
        }
        if (res.timelineClockNumbers != null) {
            if (name) {
                nameList.add(res.timelineClockNumbers);
            } else {
                this.mFxClockNumbers = (FxTimelineControl) objs[index2];
                index2++;
            }
        }
        if (res.timelineClockDate != null) {
            if (name) {
                nameList.add(res.timelineClockDate);
            } else {
                this.mFxClockDate = (FxTimelineControl) objs[index2];
                index2++;
            }
        }
        if (res.timelineClockHour != null) {
            if (name) {
                nameList.add(res.timelineClockHour);
            } else {
                this.mFxClockHour = (FxTimelineControl) objs[index2];
                index2++;
            }
        }
        if (res.timelineClockMinute != null) {
            if (name) {
                nameList.add(res.timelineClockMinute);
            } else {
                this.mFxClockMinute = (FxTimelineControl) objs[index2];
                index2++;
            }
        }
        if (res.timelineClock != null) {
            if (name) {
                nameList.add(res.timelineClock);
            } else {
                this.mFxTimelineClock = (FxTimelineControl) objs[index2];
                index2++;
            }
        }
        if (res.timelineAmPm != null) {
            if (name) {
                nameList.add(res.timelineAmPm);
            } else {
                this.mFxTimelineAmPm = (FxTimelineControl) objs[index2];
                index2++;
            }
        }
        if (res.timelineAmPmOpp != null) {
            if (name) {
                nameList.add(res.timelineAmPmOpp);
            } else {
                this.mFxTimelineAmPmOpp = (FxTimelineControl) objs[index2];
                index2++;
            }
        }
        if (res.timelineClockAmPm != null) {
            if (name) {
                nameList.add(res.timelineClockAmPm);
            } else {
                this.mFxTimelineClockAmPm = (FxTimelineControl) objs[index2];
                index2++;
            }
        }
        if (res.textLabelClockDate != null) {
            if (name) {
                nameList.add(res.textLabelClockDate);
            } else {
                this.mFxTextDate = (FxTextLabel) objs[index2];
                index2++;
            }
        }
        if (res.textLabelClockLongDate != null) {
            if (name) {
                nameList.add(res.textLabelClockLongDate);
            } else {
                this.mFxTextLongDate = (FxTextLabel) objs[index2];
                index2++;
            }
        }
        if (res.textLabelClockWeekDay != null) {
            if (name) {
                nameList.add(res.textLabelClockWeekDay);
            } else {
                this.mFxTextWeekDay = (FxTextLabel) objs[index2];
                index2++;
            }
        }
        if (res.textLabalClockAmPm != null) {
            if (name) {
                nameList.add(res.textLabalClockAmPm);
            } else {
                this.mFxTextAMPM = (FxTextLabel) objs[index2];
                index2++;
            }
        }
        if (res.textLabelClockDate_night != null) {
            if (name) {
                nameList.add(res.textLabelClockDate_night);
            } else {
                this.mFxTextDate_night = (FxTextLabel) objs[index2];
                index2++;
            }
        }
        if (res.textLabelClockWeekDay_night != null) {
            if (name) {
                nameList.add(res.textLabelClockWeekDay_night);
            } else {
                this.mFxTextWeekDay_night = (FxTextLabel) objs[index2];
                index2++;
            }
        }
        if (res.textLabalClockAmPm_night != null) {
            if (name) {
                nameList.add(res.textLabalClockAmPm_night);
            } else {
                this.mFxTextAMPM_night = (FxTextLabel) objs[index2];
                index2++;
            }
        }
        if (res.timelineFlipHour != null) {
            if (name) {
                nameList.add(res.timelineFlipHour);
            } else {
                this.mFxDigitalHour = (FxTimelineControl) objs[index2];
                index2++;
            }
        }
        if (res.timelineFlipMinute == null) {
            index = index2;
        } else if (name) {
            nameList.add(res.timelineFlipMinute);
            index = index2;
        } else {
            index = index2 + 1;
            this.mFxDigitalMinute = (FxTimelineControl) objs[index2];
        }
        if (name) {
            nameList.add(TILT);
        } else {
            this.mTiltAnime = (FxTimelineControl) objs[index];
            index++;
        }
        if (name) {
            nameList.add(HOUR);
        } else {
            this.mHourCap = (FxTimelineControl) objs[index];
            index++;
        }
        if (name) {
            nameList.add(MIN);
        } else {
            int i = index + 1;
            this.mMinCap = (FxTimelineControl) objs[index];
        }
    }

    private void setupControls() {
        if (this.mFxHitbox != null) {
            this.mFxHitbox.setEnabled(true);
            this.mFxHitbox.setEnabledGestures(1);
        }
        if (this.mFxTimelineClock != null) {
            this.mFxTimelineClock.playFrames(25, 25);
        }
        if (this.mFxDigitalHour != null) {
            this.mDigital_Hour = new DigitControl(this.mFxDigitalHour, 24);
            this.mDigital_Hour.setCurrentNumber(0);
        }
        if (this.mFxDigitalMinute != null) {
            this.mDigital_Minute = new DigitControl(this.mFxDigitalMinute, 60);
            this.mDigital_Minute.setAmPm(-1);
            this.mDigital_Minute.setCurrentNumber(0);
        }
        if (this.mTiltAnime != null) {
            this.mTileMark = this.mTiltAnime.getMarker("tilt");
        }
        if (this.mHourCap != null) {
            this.mMarkerHour = this.mHourCap.getMarker("tilt");
        }
        if (this.mMinCap != null) {
            this.mMarkerMin = this.mMinCap.getMarker("tilt");
        }
    }

    private void reset() {
        if (this.mCityName != null) {
            this.mCityName.setString("");
        }
        if (this.mFxTextDate != null) {
            this.mFxTextDate.setString("");
        }
        if (this.mFxTextAMPM != null) {
            this.mFxTextAMPM.setString("");
        }
        if (this.mFxTextLongDate != null) {
            this.mFxTextLongDate.setString("");
        }
    }

    public void bind() {
        if (this.mDigital_Hour != null) {
            this.mDigital_Hour.bind();
        }
        if (this.mDigital_Minute != null) {
            this.mDigital_Minute.bind();
        }
    }

    public void unbind() {
        if (this.mDigital_Hour != null) {
            this.mDigital_Hour.unbind();
        }
        if (this.mDigital_Minute != null) {
            this.mDigital_Minute.unbind();
        }
    }
}
