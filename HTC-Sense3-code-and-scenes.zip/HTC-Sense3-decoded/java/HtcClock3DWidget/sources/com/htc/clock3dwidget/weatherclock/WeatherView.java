package com.htc.clock3dwidget.weatherclock;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.SystemClock;
import com.htc.android.rosie.widget.Widget;
import com.htc.clock.util.MyLog;
import com.htc.clock.util.location.LocationCtrl;
import com.htc.clock3dwidget.ClockUtils;
import com.htc.clock3dwidget.R;
import com.htc.clock3dwidget.util.Constants;
import com.htc.fusion.fx.FxScene;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.controls.FxSceneContainer;
import com.htc.fusion.fx.controls.FxTextLabel;
import com.htc.weather.StateResources;
import java.io.File;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class WeatherView {
    static final String ACTION_HIDE_WEATHER_WALLPAPER = "com.htc.weatherwallpaper.service.intent.action.HIDE_WEATHER_WALLPAPER";
    static final String ACTION_SHOW_WEATHER_WALLPAPER = "com.htc.weatherwallpaper.service.intent.action.SHOW_WEATHER_WALLPAPER";
    protected static final boolean flagUseTodayAnimation = false;
    protected static final int[] mMapToWeatherWallpaper = {7, 6, 1, 1, 6, 1, 1, 1, 1, 1, 1, 4, 4, 4, 8, 8, 8, 4, 5, 5, 5, 5, 5, 5, 5, 5, 1, 1, 5, 7, 5, 9, 3, 2, 1, 1, 2, 1, 4, 4, 8, 8, 5, 5};
    private boolean mArabic;
    protected FxTimelineControl mCityRest;
    protected FxTextLabel mCityRestText;
    protected FxTextLabel mCityView;
    protected FxTimelineControl mConditionLength;
    protected FxTextLabel mConditionView;
    protected Context mContext;
    protected FxTextLabel mFxTextIndH;
    protected FxTextLabel mFxTextIndL;
    protected FxTextLabel mHTempView;
    protected Widget.Host mHost;
    protected FxSceneContainer mImgToday;
    protected FxTextLabel mLTempView;
    protected FxTextLabel mNoWeatherView;
    protected WeatherClockWidgetView mParentWidget;
    protected StateResources mStateResources;
    protected FxTextLabel mTempView;
    private FxScene mTodayAnimation;
    protected FxTimelineControl mWeatherType;
    protected FxTextLabel mWeekDayView;
    protected boolean flagUseWeatherAnimation = true;
    protected int mPreviousResId = -1;
    protected int mFrameNumber = 0;
    protected int mTime = 0;
    protected int mMode = 0;
    protected int mDfMode = 0;
    protected int mPreviousMode = -1;
    protected boolean mNeedPlayWeatherWallpaperAnimation = false;
    protected boolean mPlayAnimationWhenStartAnimation = false;
    int API_level = Build.VERSION.SDK_INT;
    protected boolean mBNeedToUpdate = false;
    private int mCellX = -1;
    private int mCellY = -1;
    protected boolean mBNeedUpdateTemp = false;
    private long mPlayWWPTime = 0;
    private Object m3DLock = new Object();
    private boolean mIsWeatherWallpaperShowing = false;

    WeatherView(Context context, WeatherClockWidgetView widget, Widget.Host host) {
        this.mArabic = false;
        String locale = context.getResources().getConfiguration().locale.getLanguage();
        MyLog.i("locale=" + locale);
        if (locale.equals("ar")) {
            this.mArabic = true;
        } else {
            this.mArabic = false;
        }
    }

    public void update() {
        MyLog.i("weatherView update~");
        this.mBNeedToUpdate = true;
        if (this.flagUseWeatherAnimation) {
            LocationCtrl weatherCtrl = this.mParentWidget.getWeatherCtrl();
            this.mDfMode = weatherCtrl.getLocConditionIdInt();
            if (this.mDfMode > 0 && this.mDfMode <= mMapToWeatherWallpaper.length) {
                this.mMode = mMapToWeatherWallpaper[this.mDfMode - 1];
            }
            if (this.mPreviousMode != this.mMode) {
                this.mPreviousMode = this.mMode;
            }
        }
        this.mParentWidget.sendUiMessageDelayed(Constants.MSG_WEATHER_UPDATE, 0L);
    }

    public boolean isWeatherVisiable() {
        LocationCtrl weatherCtrl = this.mParentWidget.getWeatherCtrl();
        boolean isLocationEnable = weatherCtrl.isLocServiceEnable() || !weatherCtrl.isWithCurrentLocation();
        MyLog.i("weatherView isWeatherVisiable~ isLocationEnable:" + isLocationEnable);
        return LocationCtrl.LocationState.OK == weatherCtrl.getLocState() && isLocationEnable;
    }

    public void uiUpdate() {
        String locName;
        int conditionId;
        MyLog.i("weatherView uiUpdate~");
        LocationCtrl weatherCtrl = this.mParentWidget.getWeatherCtrl();
        boolean openResetOption = false;
        boolean openLocOption = false;
        boolean isLocationEnable = weatherCtrl.isLocServiceEnable() || !weatherCtrl.isWithCurrentLocation();
        if (isWeatherVisiable()) {
            locName = weatherCtrl.getLocName();
            String conditionIdStr = weatherCtrl.getLocConditionId();
            MyLog.i("weather visible, condition id=" + conditionIdStr);
            try {
                conditionId = Integer.parseInt(conditionIdStr);
            } catch (Exception e) {
                conditionId = -1;
            }
            if (conditionId >= 0) {
                String text = getWeatherRes().getConditionText(conditionId);
                if (this.mNoWeatherView != null) {
                    this.mNoWeatherView.setString("");
                }
                this.mConditionView.setString(text);
                setTodayImage(conditionId);
            } else {
                this.mPreviousResId = -1;
                showDataError();
            }
            String LocTemp = weatherCtrl.getLocTemp();
            this.mTempView.setString(LocTemp);
            String HTemp = weatherCtrl.getHTemp();
            this.mHTempView.setString(HTemp);
            String LTemp = weatherCtrl.getLTemp();
            this.mLTempView.setString(LTemp);
            int length = Math.max(HTemp.length(), LTemp.length());
            MyLog.i("temperature length=" + length);
            switch (length) {
                case 1:
                case 2:
                    this.mWeatherType.playMarker("position_1");
                    break;
                case 3:
                    this.mWeatherType.playMarker("position_2");
                    break;
                case 4:
                    this.mWeatherType.playMarker("position_3");
                    break;
                default:
                    this.mWeatherType.playMarker("position_3");
                    break;
            }
            setIndicatorText();
        } else {
            MyLog.i("weather not visible,LocState=" + weatherCtrl.getLocState());
            if (LocationCtrl.LocationState.NO_DATA == weatherCtrl.getLocState() || !isLocationEnable) {
                if (!isLocationEnable) {
                    locName = "";
                    openLocOption = true;
                } else if (!weatherCtrl.isLocServiceAvailable()) {
                    locName = "";
                    openResetOption = true;
                } else {
                    locName = this.mContext.getResources().getString(R.string.mylocation);
                }
            } else {
                locName = weatherCtrl.getLocName();
            }
            this.mPreviousResId = -1;
            showDataError();
        }
        MyLog.i("mCityView=" + locName + ", openLocOption=" + openLocOption + ", openResetOption=" + openResetOption);
        this.mCityView.setString(locName);
        if (openLocOption) {
            setWeatherViewVisibility(false);
            setLocationInfoVisibility(true);
            if (this.mCityRestText != null) {
                this.mCityRestText.setString(this.mContext.getResources().getString(R.string.location_enable));
            }
        } else if (openResetOption) {
            setWeatherViewVisibility(false);
            setLocationInfoVisibility(true);
            if (this.mCityRestText != null) {
                this.mCityRestText.setString(this.mContext.getResources().getString(R.string.cite_reselect));
            }
        } else {
            setWeatherViewVisibility(true);
            setLocationInfoVisibility(false);
        }
        this.mBNeedToUpdate = false;
    }

    private void setIndicatorText() {
        String indH = this.mContext.getResources().getString(R.string.weather_high_indicator);
        String indL = this.mContext.getResources().getString(R.string.weather_low_indicator);
        if (this.mArabic) {
            this.mFxTextIndH.setString("");
            this.mFxTextIndL.setString("");
        } else {
            this.mFxTextIndH.setString(indH);
            this.mFxTextIndL.setString(indL);
        }
    }

    private void showDataError() {
        String text = this.mContext.getResources().getString(R.string.data_error);
        if (this.mNoWeatherView != null) {
            this.mConditionView.setString("");
            this.mNoWeatherView.setString(text);
        } else {
            this.mConditionView.setString(text);
        }
        if (this.mImgToday != null) {
            this.mImgToday.setVisibility(false);
        }
        this.mTempView.setString("");
        this.mHTempView.setString("");
        this.mLTempView.setString("");
        this.mFxTextIndH.setString("");
        this.mFxTextIndL.setString("");
    }

    private void setLocationInfoVisibility(boolean visible) {
        if (this.mCityRest != null) {
            this.mCityRest.setVisibility(visible);
        }
    }

    private void setWeatherViewVisibility(boolean visible) {
        if (this.mWeekDayView != null) {
            this.mWeekDayView.setVisibility(visible);
        }
        if (this.mTempView != null) {
            this.mTempView.setVisibility(visible);
        }
        if (this.mHTempView != null) {
            this.mHTempView.setVisibility(visible);
        }
        if (this.mLTempView != null) {
            this.mLTempView.setVisibility(visible);
        }
        if (this.mFxTextIndH != null) {
            this.mFxTextIndH.setVisibility(visible);
        }
        if (this.mFxTextIndL != null) {
            this.mFxTextIndL.setVisibility(visible);
        }
        if (this.mConditionView != null) {
            this.mConditionView.setVisibility(visible);
        }
        if (this.mNoWeatherView != null) {
            this.mNoWeatherView.setVisibility(visible);
        }
    }

    public void updateTempUnit() {
        this.mBNeedUpdateTemp = true;
        this.mParentWidget.sendUiMessageDelayed(Constants.MSG_WEATHER_UPDATE, 0L);
    }

    public void uiUpdateTempUnit() {
        this.mBNeedUpdateTemp = false;
        LocationCtrl weatherCtrl = this.mParentWidget.getWeatherCtrl();
        if (LocationCtrl.LocationState.OK == weatherCtrl.getLocState()) {
            this.mTempView.setString(weatherCtrl.getLocTemp());
            this.mHTempView.setString(weatherCtrl.getHTemp());
            this.mLTempView.setString(weatherCtrl.getLTemp());
            setIndicatorText();
        }
    }

    public boolean IsNeedUpdate() {
        return this.mBNeedUpdateTemp || this.mBNeedToUpdate;
    }

    private synchronized StateResources getWeatherRes() {
        if (this.mStateResources == null) {
            this.mStateResources = new StateResources();
            this.mStateResources.init(this.mContext);
        }
        return this.mStateResources;
    }

    private void setTodayImage(int conditionId) {
        if (this.mImgToday != null && this.mPreviousResId != conditionId) {
            String m10Path = ClockUtils.getMode10Path(true);
            String id = conditionId < 10 ? "0" + String.valueOf(conditionId) : String.valueOf(conditionId);
            String path = m10Path + id + ".m10";
            this.mTodayAnimation = this.mHost.createScene(path, true);
            if (this.mTodayAnimation != null) {
                this.mImgToday.setVisibility(true);
                this.mImgToday.setScene(this.mTodayAnimation);
                if (ClockUtils.SUPPORT_TIMELINE) {
                    String condition = "timeline.s_" + id;
                    FxTimelineControl timelineToday = this.mTodayAnimation.findControl(condition);
                    if (timelineToday != null) {
                        timelineToday.playMarker("In");
                    }
                } else {
                    this.mTodayAnimation.playMarker("In");
                }
            }
            this.mPreviousResId = conditionId;
        }
    }

    public void uiStopTodayAnimation() {
        this.mParentWidget.removeUiMessages(Constants.MSG_STOP_ANIMATION);
        if (this.mImgToday != null) {
            this.mImgToday.stop();
        }
    }

    public void clear() {
        this.mPreviousResId = -1;
        uiStopTodayAnimation();
        if (this.mImgToday != null) {
            this.mImgToday = null;
        }
        detach3DObject();
    }

    public void startTodayAnimation() {
        this.mParentWidget.sendUiMessageDelayed(Constants.MSG_START_ANIMATION, 0L);
    }

    public void uiStartTodayAnimation() {
        this.mParentWidget.removeUiMessages(Constants.MSG_START_ANIMATION);
        if (this.flagUseWeatherAnimation) {
            if (this.mPlayAnimationWhenStartAnimation) {
                this.mParentWidget.sendUiMessageDelayed(Constants.MSG_PLAY_ANIMATION, 0L);
            }
            this.mNeedPlayWeatherWallpaperAnimation = false;
        }
    }

    public boolean startWWPAnimation(long delayTime) {
        boolean bGoToPlay = false;
        if (this.flagUseWeatherAnimation) {
            LocationCtrl wthCtrl = this.mParentWidget.getWeatherCtrl();
            if (wthCtrl == null || LocationCtrl.LocationState.OK != wthCtrl.getLocState() || (wthCtrl.isCurrentLocation() && !wthCtrl.isLocServiceEnable())) {
                if (wthCtrl != null) {
                    MyLog.i("startWWPAnimation~ wthCtrl.getLocState():" + wthCtrl.getLocState());
                } else {
                    MyLog.e("startWWPAnimation~ wthCtrl is null");
                }
                return false;
            }
            if (!this.mPlayAnimationWhenStartAnimation) {
                MyLog.i("startWWPAnimation~ play");
                this.mParentWidget.removeUiMessages(Constants.MSG_PLAY_ANIMATION);
                this.mParentWidget.sendUiMessageDelayed(Constants.MSG_PLAY_ANIMATION, delayTime);
                bGoToPlay = true;
            }
            this.mNeedPlayWeatherWallpaperAnimation = false;
        }
        return bGoToPlay;
    }

    public void animationEnd() {
        MyLog.d("animationEnd");
    }

    public void setPosition(int cellX, int cellY) {
        this.mCellX = cellX;
        this.mCellY = cellY;
    }

    public void uiStartWWPAnimation() {
        this.mParentWidget.removeUiMessages(Constants.MSG_PLAY_ANIMATION);
        if (!this.flagUseWeatherAnimation || isPlayingWWP()) {
            MyLog.i("uiStartWWPAnimation~ fail");
            return;
        }
        int icon_x = -1;
        int icon_y = -1;
        if (this.mImgToday != null) {
            int[] iArr = new int[2];
            icon_x = this.mCellX;
            icon_y = this.mCellY;
        } else {
            MyLog.e("uiStartWWPAnimation~ mImgToday null");
        }
        MyLog.i("uiStartWWPAnimation~ mDfMode:" + this.mDfMode + " icon_x:" + icon_x + " icon_y:" + icon_y + " icon_w:-1 icon_h:-1");
        if (this.mDfMode > 0 && this.mDfMode <= mMapToWeatherWallpaper.length) {
            this.mParentWidget.buildCache();
            this.mPlayWWPTime = SystemClock.elapsedRealtime();
            int conditionId = Integer.parseInt(this.mParentWidget.getWeatherCtrl().getLocConditionId());
            if (!requestShowWeatherWallpaper(conditionId, icon_x, icon_y, -1, -1)) {
            }
        }
    }

    private boolean isPlayingWWP() {
        long curTime = SystemClock.elapsedRealtime();
        long dif = curTime - this.mPlayWWPTime;
        return 0 < dif && dif < 1000;
    }

    public void uiResetLayout() {
        uiUpdate();
    }

    private Drawable getDrawableFromResId(Resources res, int resId) {
        Drawable drawable = res.getDrawable(resId);
        if (drawable == null) {
            MyLog.e("getDrawableFromResId~ can't get drawable object:" + resId);
            return null;
        }
        drawable.setDither(false);
        return drawable;
    }

    public void checkPlayAnimationTime() {
        File file = new File("/data/data/", "WeatherWallpaperEasy");
        if (file.exists()) {
            this.mPlayAnimationWhenStartAnimation = true;
        } else {
            this.mPlayAnimationWhenStartAnimation = false;
        }
    }

    public void attach3DObject() {
    }

    public void detach3DObject() {
    }

    public void setNeedPlayWeatherWallpaper(boolean flag) {
        this.mNeedPlayWeatherWallpaperAnimation = flag;
    }

    public boolean isUseWWPAnimation() {
        return this.flagUseWeatherAnimation;
    }

    public void setInstanceVisiable(boolean bool) {
    }

    public void onResume() {
        setInstanceVisiable(false);
    }

    public void onPause() {
        setInstanceVisiable(false);
        if (this.mIsWeatherWallpaperShowing) {
            this.mIsWeatherWallpaperShowing = false;
            Intent intent = new Intent(ACTION_HIDE_WEATHER_WALLPAPER);
            this.mHost.getContext().stopService(intent);
        }
    }

    public void initAnimation() {
        if (this.flagUseWeatherAnimation) {
            this.mFrameNumber = 0;
            this.mTime = 0;
            attach3DObject();
        }
    }

    public void setPlayWWP(boolean bPlayWWP) {
        this.flagUseWeatherAnimation = bPlayWWP;
    }

    public boolean requestShowWeatherWallpaper(int condition, int icon_x, int icon_y, int icon_w, int icon_h) {
        Intent intent = new Intent(ACTION_SHOW_WEATHER_WALLPAPER);
        intent.putExtra("WeatherCondition", condition);
        int[] iconInfo = {icon_x, icon_y, icon_w, icon_h};
        intent.putExtra("iconInfo", iconInfo);
        this.mIsWeatherWallpaperShowing = true;
        this.mHost.getContext().startService(intent);
        return true;
    }
}
