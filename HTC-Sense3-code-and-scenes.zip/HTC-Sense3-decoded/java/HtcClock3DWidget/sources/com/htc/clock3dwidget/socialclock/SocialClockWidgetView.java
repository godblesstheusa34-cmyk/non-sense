package com.htc.clock3dwidget.socialclock;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Message;
import com.htc.android.rosie.widget.Widget;
import com.htc.clock.util.MyLog;
import com.htc.clock3dwidget.ClockRes;
import com.htc.clock3dwidget.ClockUtils;
import com.htc.clock3dwidget.analogclock.AnalogClockWidget;
import com.htc.fusion.fx.FxScene;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class SocialClockWidgetView extends Widget.Base {
    private Context mApContext;
    private AnalogClockWidget mClockWidget;
    private FxScene mSceneLand;
    private FxScene mScenePort;
    private SocialWidget mSocialWidget;
    private int mOrientation = 1;
    private boolean mInitCreate = false;
    private boolean mInitResume = false;
    private boolean mInitPause = false;
    private Object mInitLock = new Object();

    public void onCreate(Bundle saved) {
        super.onCreate(saved);
        this.mScenePort = getHost().createScene(ClockUtils.getClockPath(ClockUtils.ClockType.CLOCK_SOCIAL, true), true);
        this.mSceneLand = !ClockUtils.SUPPORT_LAND ? this.mScenePort : getHost().createScene(ClockUtils.getClockPath(ClockUtils.ClockType.CLOCK_SOCIAL, false), true);
        this.mApContext = getHost().getContext();
        this.mOrientation = this.mApContext.getResources().getConfiguration().orientation;
    }

    protected void onPostCreate(Bundle savedState) {
        super.onPostCreate(savedState);
        ClockRes clockRes = ClockUtils.getClockRes(ClockUtils.ClockType.CLOCK_SOCIAL, this.mApContext);
        this.mClockWidget = new AnalogClockWidget(getContext(), this.mApContext, getHost(), this.mScenePort, this.mSceneLand, this.mOrientation, null, clockRes);
        this.mSocialWidget = new SocialWidget(getContext(), getHost().getContext(), getHost(), getIntent(), this.mScenePort, this.mSceneLand, null);
        synchronized (this.mInitLock) {
            if (this.mInitResume) {
                doResume();
            }
            if (this.mInitPause) {
                doPause();
            }
            this.mInitCreate = true;
        }
    }

    public void onResume() {
        super.onResume();
        synchronized (this.mInitLock) {
            if (this.mInitCreate) {
                doResume();
            }
            this.mInitResume = true;
        }
    }

    private void doResume() {
        if (this.mClockWidget != null) {
            this.mClockWidget.doResume();
        }
        if (this.mSocialWidget != null) {
            this.mSocialWidget.doResume();
        }
    }

    public void onPause() {
        super.onPause();
        synchronized (this.mInitLock) {
            if (this.mInitCreate) {
                doPause();
            }
            this.mInitPause = true;
        }
    }

    private void doPause() {
        if (this.mClockWidget != null) {
            this.mClockWidget.doPause();
        }
        if (this.mSocialWidget != null) {
            this.mSocialWidget.doPause();
        }
    }

    public void onDestroy() {
        MyLog.i("weather clock onActivityDestroy~");
        if (this.mClockWidget != null) {
            this.mClockWidget.doDestroy();
        }
        if (this.mSocialWidget != null) {
            this.mSocialWidget.doDestroy();
        }
        super.onDestroy();
    }

    public void onTiltChanged(float tilt) {
        super.onTiltChanged(tilt);
        if (this.mClockWidget != null) {
            this.mClockWidget.doTiltChanged(tilt);
        }
    }

    protected void onHostMessage(Message msg) {
        super.onHostMessage(msg);
        if (this.mClockWidget != null) {
            this.mClockWidget.doHostMessage(msg);
        }
        if (this.mSocialWidget != null) {
            this.mSocialWidget.doHostMessage(msg);
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (this.mClockWidget != null) {
            this.mClockWidget.doActivityResult(requestCode, resultCode, data);
        }
        if (this.mSocialWidget != null) {
            this.mSocialWidget.doActivityResult(requestCode, resultCode, data);
        }
    }

    protected FxScene getScene(int orientation) {
        return orientation == 1 ? this.mScenePort : this.mSceneLand;
    }

    protected FxScene getScene() {
        return this.mOrientation == 1 ? this.mScenePort : this.mSceneLand;
    }

    public void onConfigurationChanged(Configuration newConfiguration) {
        super.onConfigurationChanged(newConfiguration);
        this.mOrientation = newConfiguration.orientation;
        if (this.mClockWidget != null) {
            this.mClockWidget.onConfigurationChanged(this.mOrientation);
        }
        if (this.mSocialWidget != null) {
            this.mSocialWidget.onConfigurationChanged(this.mOrientation);
        }
    }
}
