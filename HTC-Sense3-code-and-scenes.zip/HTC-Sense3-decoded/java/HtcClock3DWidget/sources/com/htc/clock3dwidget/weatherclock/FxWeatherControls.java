package com.htc.clock3dwidget.weatherclock;

import android.os.Build;
import com.htc.clock3dwidget.util.DigitControl;
import com.htc.fusion.fx.FxScene;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.Marker;
import com.htc.fusion.fx.controls.FxHitbox;
import com.htc.fusion.fx.controls.FxSceneContainer;
import com.htc.fusion.fx.controls.FxTextLabel;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class FxWeatherControls {
    private static final String HOUR = "timeline.flip_hour";
    private static final String MIN = "timeline.flip_minute";
    private static final String TILT = "timeline.tiltanim";
    int API_level = Build.VERSION.SDK_INT;
    public FxTimelineControl mCityRest;
    public FxTextLabel mCityRestText;
    public FxTextLabel mCityView;
    public FxTimelineControl mConditionLength;
    public FxTextLabel mConditionView;
    public FxTextLabel mDigital_Data;
    public DigitControl mDigital_Hour;
    public DigitControl mDigital_Minute;
    public FxHitbox mFxHitboxClock;
    public FxHitbox mFxHitboxWeather;
    public FxTextLabel mFxTextIndH;
    public FxTextLabel mFxTextIndL;
    public FxTextLabel mHTempView;
    public FxTimelineControl mHourCap;
    public FxSceneContainer mImgToday;
    public FxTextLabel mLTempView;
    public Marker mMarkerHour;
    public Marker mMarkerMin;
    public FxTimelineControl mMinCap;
    public FxTextLabel mNoWeatherView;
    public FxTextLabel mTempView;
    public Marker mTileMark;
    public FxTimelineControl mTiltAnime;
    public FxScene mTodayAnimation;
    public FxTimelineControl mWeatherType;

    public FxWeatherControls(FxScene scene) {
        String[] controls = {"button.clock.hitbox", "button.weather.hitbox", MIN, HOUR, "textlabel.weatherclock_cityname", "textlabel.weatherclock_weather", "textlabel.weatherclock_noweather", "textlabel.weatherclock_date", "textlabel.weatherclock_todaytemp", "textlabel.weatherclock_H", "textlabel.weatherclock_L", "textlabel.weatherclock_tempHi", "textlabel.weatherclock_templow", "scenecontainer.forecast_weather_state", TILT, HOUR, MIN, "timeline.info", "textlabel.info", "timeline.weather_type", "timeline.city_name"};
        FxTimelineControl[] descendants = scene.getDescendants(controls);
        this.mFxHitboxClock = (FxHitbox) descendants[0];
        this.mFxHitboxClock.setEnabled(true);
        this.mFxHitboxClock.setEnabledGestures(1);
        this.mFxHitboxWeather = (FxHitbox) descendants[1];
        this.mFxHitboxWeather.setEnabled(true);
        this.mFxHitboxWeather.setEnabledGestures(1);
        this.mDigital_Minute = new DigitControl(descendants[2], 60);
        this.mDigital_Minute.setAmPm(-1);
        this.mDigital_Minute.setCurrentNumber(0);
        this.mDigital_Hour = new DigitControl(descendants[3], 24);
        this.mDigital_Hour.setCurrentNumber(0);
        this.mCityView = (FxTextLabel) descendants[4];
        this.mConditionView = (FxTextLabel) descendants[5];
        this.mNoWeatherView = (FxTextLabel) descendants[6];
        this.mDigital_Data = (FxTextLabel) descendants[7];
        this.mTempView = (FxTextLabel) descendants[8];
        this.mFxTextIndH = (FxTextLabel) descendants[9];
        this.mFxTextIndL = (FxTextLabel) descendants[10];
        this.mHTempView = (FxTextLabel) descendants[11];
        this.mLTempView = (FxTextLabel) descendants[12];
        this.mImgToday = (FxSceneContainer) descendants[13];
        this.mTiltAnime = descendants[14];
        if (this.API_level >= 11) {
        }
        if (this.mTiltAnime != null) {
            this.mTileMark = this.mTiltAnime.getMarker("tilt");
        }
        this.mHourCap = descendants[15];
        if (this.mHourCap != null) {
            this.mMarkerHour = this.mHourCap.getMarker("tilt");
        }
        this.mMinCap = descendants[16];
        if (this.mMinCap != null) {
            this.mMarkerMin = this.mMinCap.getMarker("tilt");
        }
        this.mCityRest = descendants[17];
        if (this.mCityRest != null) {
            this.mCityRest.setVisibility(false);
        }
        this.mCityRestText = (FxTextLabel) descendants[18];
        this.mWeatherType = descendants[19];
        reset();
    }

    private void reset() {
        if (this.mConditionView != null) {
            this.mConditionView.setString("");
        }
        if (this.mDigital_Data != null) {
            this.mDigital_Data.setString("");
        }
        if (this.mFxTextIndH != null) {
            this.mFxTextIndH.setString("");
        }
        if (this.mFxTextIndL != null) {
            this.mFxTextIndL.setString("");
        }
        if (this.mHTempView != null) {
            this.mHTempView.setString("");
        }
        if (this.mLTempView != null) {
            this.mLTempView.setString("");
        }
        if (this.mTempView != null) {
            this.mTempView.setString("");
        }
        if (this.mCityView != null) {
            this.mCityView.setString("");
        }
    }
}
