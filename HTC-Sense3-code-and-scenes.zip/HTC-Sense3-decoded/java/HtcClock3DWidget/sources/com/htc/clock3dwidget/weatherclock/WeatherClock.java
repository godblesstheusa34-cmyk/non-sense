package com.htc.clock3dwidget.weatherclock;

import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.view.View;
import com.htc.android.rosie.widget.Widget;
import com.htc.android.rosie.widget.WidgetHelper;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.Marker;
import com.htc.fusion.fx.MessageListener;
import com.htc.fusion.fx.controls.FxHitbox;
import com.htc.fusion.fx.controls.FxTextLabel;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class WeatherClock extends HtcDigitalClock42View {
    private static final String TAG = "[WeatherClock]";
    int API_level;
    private ClockClickListener mClockClickLand;
    private View.OnClickListener mClockClickListener;
    private ClockClickListener mClockClickPort;
    protected FxHitbox mFxHitboxClock;
    protected FxHitbox mFxHitboxWeather;
    private FxTimelineControl mHourCap;
    private Marker mMarkerHour;
    private Marker mMarkerMin;
    private FxTimelineControl mMinCap;
    private Marker mTileMark;
    private FxTimelineControl mTiltAnime;
    private WeatherClickListener mWeatherClickLand;
    private View.OnClickListener mWeatherClickListener;
    private WeatherClickListener mWeatherClickPort;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    protected WeatherClock(Context context, WeatherClockWidgetView widget, Widget.Host host) {
        super(context, widget, host);
        this.mWeatherClickPort = new WeatherClickListener();
        this.mWeatherClickLand = new WeatherClickListener();
        this.mClockClickPort = new ClockClickListener();
        this.mClockClickLand = new ClockClickListener();
        this.API_level = Build.VERSION.SDK_INT;
        this.mContext = context;
        this.mParentWidget = widget;
        this.mHost = host;
    }

    public void init(FxWeatherControls controls) {
        this.mFxHitboxClock = controls.mFxHitboxClock;
        this.mFxHitboxWeather = controls.mFxHitboxWeather;
        this.mDigital_Minute = controls.mDigital_Minute;
        this.mDigital_Hour = controls.mDigital_Hour;
        this.mCityView = controls.mCityView;
        if (this.API_level >= 11) {
        }
        this.mConditionView = controls.mConditionView;
        this.mNoWeatherView = controls.mNoWeatherView;
        FxTextLabel fxTextLabel = controls.mDigital_Data;
        this.mDigital_Data = fxTextLabel;
        this.mWeekDayView = fxTextLabel;
        this.mCityRest = controls.mCityRest;
        this.mCityRestText = controls.mCityRestText;
        this.mWeatherType = controls.mWeatherType;
        this.mTempView = controls.mTempView;
        this.mFxTextIndH = controls.mFxTextIndH;
        this.mFxTextIndL = controls.mFxTextIndL;
        this.mHTempView = controls.mHTempView;
        this.mLTempView = controls.mLTempView;
        this.mImgToday = controls.mImgToday;
        this.mTiltAnime = controls.mTiltAnime;
        this.mTileMark = controls.mTileMark;
        this.mHourCap = controls.mHourCap;
        this.mMarkerHour = controls.mMarkerHour;
        this.mMinCap = controls.mMinCap;
        this.mMarkerMin = controls.mMarkerMin;
    }

    public void bind(FxWeatherControls controlsPort, FxWeatherControls controlsLand) {
        controlsPort.mFxHitboxClock.getTapSource().bind(this.mClockClickPort);
        controlsPort.mFxHitboxWeather.getTapSource().bind(this.mWeatherClickPort);
        controlsPort.mDigital_Hour.bind();
        controlsPort.mDigital_Minute.bind();
        if (!controlsPort.equals(controlsLand)) {
            controlsLand.mDigital_Hour.bind();
            controlsLand.mDigital_Minute.bind();
            controlsLand.mFxHitboxClock.getTapSource().bind(this.mClockClickLand);
            controlsLand.mFxHitboxWeather.getTapSource().bind(this.mWeatherClickLand);
        }
    }

    public void unbind(FxWeatherControls controlsPort, FxWeatherControls controlsLand) {
        controlsPort.mFxHitboxClock.getTapSource().unbind(this.mClockClickPort);
        controlsPort.mFxHitboxWeather.getTapSource().unbind(this.mWeatherClickPort);
        controlsPort.mDigital_Hour.unbind();
        controlsPort.mDigital_Minute.unbind();
        if (!controlsPort.equals(controlsLand)) {
            controlsLand.mDigital_Hour.unbind();
            controlsLand.mDigital_Minute.unbind();
            controlsLand.mFxHitboxClock.getTapSource().unbind(this.mClockClickLand);
            controlsLand.mFxHitboxWeather.getTapSource().unbind(this.mWeatherClickLand);
        }
    }

    public void doTiltChanged(float tilt) {
        if (this.mTiltAnime != null && this.mTileMark != null) {
            float frame = WidgetHelper.convertTiltAngleToFrame(tilt, this.mTileMark.StartFrame, this.mTileMark.EndFrame);
            this.mTiltAnime.setFrame(frame);
        }
        if (this.mHourCap != null && this.mMarkerHour != null) {
            float frame2 = WidgetHelper.convertTiltAngleToFrame(tilt, this.mMarkerHour.StartFrame, this.mMarkerHour.EndFrame);
            this.mHourCap.setFrame(frame2);
        }
        if (this.mMinCap != null && this.mMarkerMin != null) {
            float frame3 = WidgetHelper.convertTiltAngleToFrame(tilt, this.mMarkerMin.StartFrame, this.mMarkerMin.EndFrame);
            this.mMinCap.setFrame(frame3);
        }
        if (this.mDigital_Minute != null) {
            this.mDigital_Minute.doTiltChanged(tilt);
        }
        if (this.mDigital_Hour != null) {
            this.mDigital_Hour.doTiltChanged(tilt);
        }
    }

    private class ClockClickListener extends MessageListener<FxHitbox.TapParameters> {
        private ClockClickListener() {
        }

        public void onMessageReceived(FxHitbox.TapParameters arg0) {
            Log.d(WeatherClock.TAG, "clock is clicked");
            if (WeatherClock.this.mClockClickListener != null) {
                WeatherClock.this.mClockClickListener.onClick(null);
            }
        }
    }

    private class WeatherClickListener extends MessageListener<FxHitbox.TapParameters> {
        private WeatherClickListener() {
        }

        public void onMessageReceived(FxHitbox.TapParameters arg0) {
            Log.d(WeatherClock.TAG, "weather is clicked");
            if (WeatherClock.this.mWeatherClickListener != null) {
                WeatherClock.this.mWeatherClickListener.onClick(null);
            }
        }
    }

    public void setOnWeatherClickListener(View.OnClickListener l) {
        this.mWeatherClickListener = l;
    }

    public void setOnClockClickListener(View.OnClickListener l) {
        this.mClockClickListener = l;
    }
}
