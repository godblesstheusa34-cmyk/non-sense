package com.htc.clock.util.location;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import com.htc.util.weather.WeatherLocation;
import com.htc.util.weather.WeatherUtility;
import java.util.Calendar;
import java.util.Locale;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class LocationUtil {
    public static final String APP_LOCATION_SERVICE = "com.htc.htclocationservice";
    public static final String DE = "de";
    public static final String EN = "en";
    public static final String ES = "es";
    public static final String FR = "fr";
    public static final String FS = "fs";
    public static final String IT = "it";
    public static final String JA = "ja";
    public static final String KO = "ko";
    public static final String NL = "nl";
    public static final String NO = "no";
    public static final String PL = "pl";
    public static final String RU = "ru";
    public static final String TIMEZONEID = "timezoneId";
    public static final String ZH = "zh";
    public static final String ZHTW = "zhTW";
    public static final Uri CONTENT_URI = Uri.parse("content://com.htc.android.alarmclock/timezone");
    public static String sDefaultLocName = "Current location";

    public static String getCurrentCityName(Context mApp) {
        WeatherLocation[] current_locs = WeatherUtility.loadLocations(mApp.getContentResolver(), "com.htc.htclocationservice");
        if (current_locs != null && current_locs.length > 0) {
            String city_name = current_locs[0].getName();
            if (city_name == null || city_name.length() == 0) {
                return sDefaultLocName;
            }
            return current_locs[0].getName();
        }
        return getHome(mApp);
    }

    public static String getCurrentCityTimezone(Context mApp) {
        WeatherLocation[] current_locs = WeatherUtility.loadLocations(mApp.getContentResolver(), "com.htc.htclocationservice");
        if (current_locs == null || current_locs.length <= 0) {
            return null;
        }
        String city_name = current_locs[0].getName();
        if (city_name == null || city_name.length() == 0) {
            return null;
        }
        if (current_locs[0].getTimezoneId() == null || current_locs[0].getTimezoneId().length() <= 0) {
            return null;
        }
        return current_locs[0].getTimezoneId();
    }

    private static String getTimeZoneCity(Context mApp, String id) {
        String where = "timezoneId='" + id + "'";
        Locale systemLocale = mApp.getResources().getConfiguration().locale;
        String systemLang = systemLocale.getLanguage();
        if (systemLocale.equals(Locale.TAIWAN)) {
            systemLang = ZHTW;
        }
        Cursor c = mApp.getContentResolver().query(CONTENT_URI, null, where, null, null);
        if (c != null) {
            if (c.getCount() > 0 && c.moveToFirst()) {
                int index = c.getColumnIndex(systemLang);
                if (index < 0) {
                    index = c.getColumnIndex(EN);
                }
                if (index >= 0) {
                    id = c.getString(index);
                }
            }
            c.close();
        }
        return id;
    }

    private static String getHome(Context mApp) {
        String id = Calendar.getInstance().getTimeZone().getID();
        String where = "timezoneId='" + id + "'";
        Locale systemLocale = mApp.getResources().getConfiguration().locale;
        String systemLang = systemLocale.getLanguage();
        if (systemLocale.equals(Locale.TAIWAN)) {
            systemLang = ZHTW;
        }
        Cursor c = mApp.getContentResolver().query(CONTENT_URI, null, where, null, null);
        if (c != null) {
            if (c.getCount() > 0 && c.moveToFirst()) {
                int index = c.getColumnIndex(systemLang);
                if (index < 0) {
                    index = c.getColumnIndex(EN);
                }
                if (index >= 0) {
                    id = c.getString(index);
                }
            }
            c.close();
        }
        return id;
    }

    public static void setDefaultLocName(String defaultName) {
        sDefaultLocName = defaultName;
    }
}
