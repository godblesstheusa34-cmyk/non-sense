package com.htc.clock.util.time;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.database.Cursor;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import android.text.format.DateFormat;
import com.htc.clock.util.MyLog;
import com.htc.clock.util.MyUtil;
import com.htc.util.weather.WeatherLocation;
import com.htc.util.weather.WeatherUtility;
import java.util.Calendar;
import java.util.TimeZone;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class TimeCtrl {
    public static final int TIME_TYPE_MIN = 2;
    public static final int TIME_TYPE_SETTING = 8;
    public static final int TIME_TYPE_TIMEZONE = 4;
    public static final int WHAT_ON_INIT_DATA = 3;
    public static final int WHAT_ON_SETTING_CHANGED = 2;
    public static final int WHAT_ON_START_SECOND = 1;
    public static final int WHAT_UI_MINUTE = 1002;
    public static final int WHAT_UI_SECOND = 1001;
    public static final int WHAT_UI_SETTING_CHANGED = 1005;
    public static final int WHAT_UI_TIMEZONE_CHANGED = 1004;
    public static final int WHAT_UI_TIME_CHANGED = 1003;
    private static boolean mB24hourFormat = false;
    Looper mBGLooper;
    Calendar mCalendar;
    private String mCityCode;
    protected String mCityName;
    Context mContext;
    Handler mHandler;
    OnTimeListener mListener;
    BroadcastReceiver mReceiver;
    ContentObserver mSettingChangeObserver;
    private String mTimeZoneStr;
    int mType;
    Handler mUIHandler = new MyUIHandler(Looper.getMainLooper());
    private String mDateFormat = "EE, MM-dd";

    public interface OnTimeListener {
        void onFormatChanged();

        void onMinute();

        void onSecond();

        void onTimeChanged();

        void onTimeZoneChanged();
    }

    public void init(Context context, OnTimeListener listener, int type, Handler handler, String locCode) {
        if (this.mReceiver == null) {
            MyLog.i("TimeCtrl~ init mCityCode:" + locCode);
            this.mContext = context;
            this.mListener = listener;
            this.mType = type;
            this.mCityCode = locCode;
            setTimeZone(null);
            initBGHandler(handler);
            this.mReceiver = new MyReceiver();
            IntentFilter filter = new IntentFilter();
            filter.addAction("android.intent.action.TIME_SET");
            if ((type & 2) > 0) {
                filter.addAction("android.intent.action.TIME_TICK");
            }
            if ((type & 4) > 0) {
                filter.addAction("android.intent.action.TIMEZONE_CHANGED");
            }
            context.registerReceiver(this.mReceiver, filter);
            if (this.mSettingChangeObserver == null && (type & 8) > 0) {
                this.mSettingChangeObserver = new DbChangeObserver(this.mHandler);
                this.mContext.getContentResolver().registerContentObserver(Settings.System.CONTENT_URI, true, this.mSettingChangeObserver);
            }
            MyUtil.sendMessage(this.mHandler, 3);
        }
    }

    public void setTimeZone(String timezone) {
        TimeZone tz = null;
        this.mTimeZoneStr = timezone;
        if (!TextUtils.isEmpty(timezone)) {
            tz = TimeZone.getTimeZone(timezone);
        }
        if (tz != null) {
            this.mCalendar = Calendar.getInstance(tz);
        } else {
            this.mCalendar = Calendar.getInstance();
        }
        MyLog.i("TimeCtrl~ setTimeZone tz:" + this.mCalendar.getTimeZone().getID());
    }

    private void initBGHandler(Handler handler) {
        Looper looper = null;
        if (handler != null) {
            looper = handler.getLooper();
        }
        if (looper == null) {
            if (this.mBGLooper == null) {
                HandlerThread thread = new HandlerThread("TimeCtrl");
                thread.start();
                this.mBGLooper = thread.getLooper();
            }
            looper = this.mBGLooper;
        }
        this.mHandler = new MyBGHandler(looper);
    }

    public void uninit() {
        if (this.mSettingChangeObserver != null) {
            this.mContext.getContentResolver().unregisterContentObserver(this.mSettingChangeObserver);
            this.mSettingChangeObserver = null;
        }
        if (this.mBGLooper != null) {
            this.mBGLooper.quit();
        }
        if (this.mReceiver != null) {
            this.mContext.unregisterReceiver(this.mReceiver);
            this.mReceiver = null;
        }
        this.mListener = null;
    }

    private class MyReceiver extends BroadcastReceiver {
        private MyReceiver() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if ("android.intent.action.TIME_TICK".equals(action)) {
                TimeCtrl.this.mCalendar.setTimeInMillis(System.currentTimeMillis());
                MyUtil.sendMessage(TimeCtrl.this.mUIHandler, 1002);
            } else if ("android.intent.action.TIME_SET".equals(action)) {
                TimeCtrl.this.mCalendar.setTimeInMillis(System.currentTimeMillis());
                MyUtil.removeMessage(TimeCtrl.this.mUIHandler, 1003);
                MyUtil.sendMessage(TimeCtrl.this.mUIHandler, 1003);
            } else if ("android.intent.action.TIMEZONE_CHANGED".equals(action)) {
                TimeCtrl.this.handlerTimeZoneChanged();
            }
        }
    }

    protected void handlerTimeZoneChanged() {
        this.mCalendar = Calendar.getInstance();
        MyUtil.removeMessage(this.mUIHandler, WHAT_UI_TIMEZONE_CHANGED);
        MyUtil.sendMessage(this.mUIHandler, WHAT_UI_TIMEZONE_CHANGED);
    }

    private class MyBGHandler extends Handler {
        public MyBGHandler(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            int what = msg.what;
            switch (what) {
                case 1:
                    TimeCtrl.this.mCalendar.setTimeInMillis(System.currentTimeMillis());
                    long next = TimeCtrl.this.getNextSecTime();
                    MyUtil.sendMessage(TimeCtrl.this.mUIHandler, 1001, next);
                    break;
                case 2:
                    TimeCtrl.this.handlerSettingChanged();
                    break;
                case 3:
                    TimeCtrl.this.handlerInit();
                    break;
            }
        }
    }

    private class MyUIHandler extends Handler {
        MyUIHandler(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            int what = msg.what;
            switch (what) {
                case 1001:
                    TimeCtrl.this.mCalendar.setTimeInMillis(System.currentTimeMillis());
                    TimeCtrl.this.onSecond();
                    sendEmptyMessageAtTime(1001, TimeCtrl.this.getNextSecTime());
                    break;
                case 1002:
                    TimeCtrl.this.onMinute();
                    break;
                case 1003:
                    TimeCtrl.this.onTimeChanged();
                    break;
                case TimeCtrl.WHAT_UI_TIMEZONE_CHANGED /* 1004 */:
                    TimeCtrl.this.onTimeZoneChanged();
                    break;
                case TimeCtrl.WHAT_UI_SETTING_CHANGED /* 1005 */:
                    TimeCtrl.this.onSettingChanged();
                    break;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public long getNextSecTime() {
        long now = SystemClock.uptimeMillis();
        long next = now + (1000 - (now % 1000));
        return next;
    }

    protected void onMinute() {
        OnTimeListener listener = this.mListener;
        if (listener != null) {
            listener.onMinute();
        }
    }

    protected void onSecond() {
        OnTimeListener listener = this.mListener;
        if (listener != null) {
            listener.onSecond();
        }
    }

    protected void onTimeChanged() {
        OnTimeListener listener = this.mListener;
        if (listener != null) {
            listener.onTimeChanged();
        }
    }

    protected void onTimeZoneChanged() {
        OnTimeListener listener = this.mListener;
        if (listener != null) {
            listener.onTimeZoneChanged();
        }
    }

    protected void onSettingChanged() {
        OnTimeListener listener = this.mListener;
        if (listener != null) {
            listener.onFormatChanged();
        }
    }

    private class DbChangeObserver extends ContentObserver {
        public DbChangeObserver(Handler hander) {
            super(hander);
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean selfChange) {
            MyUtil.removeMessage(TimeCtrl.this.mHandler, 2);
            MyUtil.sendMessage(TimeCtrl.this.mHandler, 2, 5000L);
        }
    }

    protected void handlerSettingChanged() {
        boolean bUpdate = updateFormat();
        if (bUpdate) {
            MyUtil.sendMessage(this.mUIHandler, WHAT_UI_SETTING_CHANGED);
        }
    }

    protected void handlerInit() {
        Cursor locationListCursor;
        MyLog.i("TimeCtrl~ handlerInit");
        boolean bUpdateCity = false;
        if (!TextUtils.isEmpty(this.mCityCode) && (locationListCursor = WeatherUtility.getLocationListByCode(this.mContext.getContentResolver(), this.mCityCode)) != null) {
            if (locationListCursor.getCount() > 0 && locationListCursor.moveToFirst()) {
                WeatherLocation tempWeatherLocation = WeatherUtility.CursorToWeatherLocation(locationListCursor);
                this.mCityName = tempWeatherLocation.getName();
                String timeZoneStr = tempWeatherLocation.getTimezoneId();
                setTimeZone(timeZoneStr);
                bUpdateCity = true;
            }
            locationListCursor.close();
        }
        handlerSettingChanged();
        if (bUpdateCity) {
            MyUtil.removeMessage(this.mUIHandler, WHAT_UI_TIMEZONE_CHANGED);
            MyUtil.sendMessage(this.mUIHandler, WHAT_UI_TIMEZONE_CHANGED);
        }
    }

    public String getDateFormat() {
        return this.mDateFormat;
    }

    public boolean updateDateFormat() {
        String format = Settings.System.getString(this.mContext.getContentResolver(), "date_format_short");
        if (format == null || format.length() <= 0 || TextUtils.equals(this.mDateFormat, format)) {
            return false;
        }
        this.mDateFormat = format;
        return true;
    }

    public boolean is24HourFormat() {
        return mB24hourFormat;
    }

    public boolean update24HourFormat() {
        boolean is24Hour = DateFormat.is24HourFormat(this.mContext);
        if (mB24hourFormat == is24Hour) {
            return false;
        }
        mB24hourFormat = is24Hour;
        return true;
    }

    public boolean updateFormat() {
        boolean bUpdated = false | updateDateFormat();
        return bUpdated | update24HourFormat();
    }

    public Calendar getCalendar() {
        if (this.mCalendar == null) {
            MyLog.e("TimeCtrl~ getCalendar null");
            return Calendar.getInstance();
        }
        MyLog.i("TimeCtrl~ getCalendar tz:" + this.mCalendar.getTimeZone().getID());
        return this.mCalendar;
    }

    public String getTimeZoneCity() {
        return this.mCityName;
    }
}
