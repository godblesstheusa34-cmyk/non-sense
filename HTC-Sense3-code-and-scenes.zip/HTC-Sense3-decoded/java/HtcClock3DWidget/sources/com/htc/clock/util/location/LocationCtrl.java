package com.htc.clock.util.location;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.TextUtils;
import com.htc.clock.util.MyLog;
import com.htc.clock.util.MyUtil;
import com.htc.clock.util.location.WeatherForecast;
import com.htc.util.http.NetworkUtil;
import com.htc.util.weather.WSPData;
import com.htc.util.weather.WSPRequest;
import com.htc.util.weather.WSPUtility;
import com.htc.util.weather.WeatherLocation;
import com.htc.util.weather.WeatherUtility;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class LocationCtrl {
    public static final String APP_LOCATION_SERVICE = "com.htc.htclocationservice";
    private static final String CATEGORY_NAME = "WeatherClock";
    public static final String CURRENT_LOCATION_AVAIABLE = "com.htc.Weather.location.avaiable";
    public static final String CURRENT_LOCATION_KEY = "cur";
    private static final String DEGREE = "°";
    public static final int MAX_RETRY_CNT = 10;
    public static final int MAX_RETRY_CNT_IMMEDIATE = 2;
    private static final long OVERDUE_OFFSET = 180000;
    public static final int WHAT_ON_CONNECTION_UPDATE = 2;
    public static final int WHAT_ON_WEATHER_DELETE = 4;
    public static final int WHAT_ON_WEATHER_FORCE_UPDATE = 3;
    public static final int WHAT_ON_WEATHER_UPDATE = 1;
    public static final int WHAT_UI_CITY_CHANGED = 1001;
    public static final int WHAT_UI_TEMP_CHANGED = 1003;
    public static final int WHAT_UI_WEATHER_CHANGED = 1002;
    private static final long[] sRetryTimes = {15000, 30000, 60000, 600000};
    private BroadcastReceiver mConnectChangeRec;
    private Context mContext;
    private Handler mHandler;
    private LocationListener mListener;
    private String mLocKey;
    private BroadcastReceiver mTempUnitReceiver;
    private BroadcastReceiver mWeatherApReceiver;
    private BroadcastReceiver mWeatherReceiver;
    public boolean mBOnReceiveWeatherData = false;
    public StringBuffer mSOnReceiveLog = new StringBuffer();
    private boolean mIsWithCurLocation = false;
    private HashMap<String, LocationData> mLocDataMap = new HashMap<>();
    private State mState = State.NONE;
    private ArrayList<WSPRequest> mWSPReqList = new ArrayList<>();
    private WeatherForecast.UNIT mUnit = WeatherForecast.UNIT._C;
    private boolean mRetryEnable = false;
    private boolean mTempUnitEnable = false;
    private long mLastForceSyncTime = 0;
    private int mRetryForceCnt = 0;
    private Handler mUIHandler = new UIHandler(Looper.getMainLooper());
    private boolean mLocationAvailable = true;
    private boolean mLocationEnable = true;

    public enum LocationState {
        NO_DATA,
        ONLY_LOC,
        OK
    }

    public enum State {
        NONE,
        STOP,
        START
    }

    public LocationCtrl(Context context) {
        this.mContext = context;
    }

    public void setRetryEnable(boolean enable) {
        this.mRetryEnable = enable;
    }

    public void setTempUnitEnable(boolean enable) {
        this.mTempUnitEnable = enable;
    }

    public WSPData requestCurData() {
        WSPData data = WSPUtility.request(this.mContext, WSPUtility.generateWSPReqestForCurrentLocation());
        return data;
    }

    public WSPData requestLocData(String locCode) {
        WSPData data = WSPUtility.request(this.mContext, WSPUtility.generateWSPRequestForLocCode(locCode));
        return data;
    }

    public boolean addLoc(WeatherLocation wthLoc) {
        LocationData locData = new LocationData(this.mContext, wthLoc);
        return addLoc(locData);
    }

    public boolean addLoc(String locCode, String locName, String timezoneid) {
        LocationData locData = new LocationData(this.mContext, locCode, locName, timezoneid);
        return addLoc(locData);
    }

    private boolean addLoc(LocationData locData) {
        boolean addRet = false;
        if (locData != null) {
            WSPRequest wasReq = WSPUtility.generateWSPRequestForLocCode(locData.getLocCode());
            addRet = addWSPReq(wasReq);
            if (addRet) {
                this.mLocDataMap.put(locData.getLocCode(), locData);
            } else {
                MyLog.e("addLoc~ fail, locData:" + locData.getLocCode());
            }
        }
        return addRet;
    }

    public boolean addCurLoc() {
        WeatherLocation wthLoc;
        WSPRequest wasReq = WSPUtility.generateWSPReqestForCurrentLocation();
        boolean bRet = addWSPReq(wasReq);
        if (bRet) {
            WeatherLocation[] locs = WeatherUtility.loadLocations(this.mContext.getContentResolver(), "com.htc.htclocationservice");
            LocationState locState = LocationState.NO_DATA;
            if (locs != null && locs.length > 0) {
                wthLoc = locs[0];
                locState = LocationState.ONLY_LOC;
            } else {
                wthLoc = new WeatherLocation();
                wthLoc.setName("");
                wthLoc.setTimezoneId((String) null);
            }
            LocationData curLocData = new LocationData(this.mContext, wthLoc, locState);
            curLocData.mIsCurLocation = true;
            this.mIsWithCurLocation = true;
            this.mLocDataMap.put(CURRENT_LOCATION_KEY, curLocData);
        } else {
            MyLog.e("addCurLoc~ fail");
        }
        return bRet;
    }

    public void setLocKey(String locKey) {
        this.mLocKey = locKey;
    }

    public String getLocKey() {
        return this.mLocKey;
    }

    public boolean addWSPReq(WSPRequest wspReq) {
        if (wspReq == null) {
            MyLog.e("addWSPReq~ the WSPReq is wrong");
            return false;
        }
        if (this.mState == State.START) {
            MyLog.e("addWSPReq~ the WSPReq is wrong becasue start");
            return false;
        }
        this.mWSPReqList.add(wspReq);
        return true;
    }

    public boolean isForceUpdateAvailable() {
        boolean isLocationEnable = isLocServiceEnable() || !isWithCurrentLocation();
        if (allowBackgroundData(this.mContext) && NetworkUtil.isActiveNetwork(this.mContext) && WSPUtility.isSyncAutomatically(this.mContext) && isLocationEnable) {
            return true;
        }
        MyLog.i("forceToSync~ no way to update");
        return false;
    }

    public void forceToSync() {
        if (isForceUpdateAvailable()) {
            long currentTime = SystemClock.elapsedRealtime();
            long retryPending = getRetryPendingTime();
            if (retryPending <= 0) {
                this.mLastForceSyncTime = currentTime;
                this.mRetryForceCnt++;
                MyLog.i("forceToSync~");
                if (this.mWSPReqList.size() > 0) {
                    WSPRequest[] wspReqArray = (WSPRequest[]) this.mWSPReqList.toArray(new WSPRequest[this.mWSPReqList.size()]);
                    WSPUtility.triggerSyncService(this.mContext, CATEGORY_NAME, wspReqArray);
                    return;
                }
                return;
            }
            MyLog.i("forceToSync~ wait retryPending:" + retryPending);
        }
    }

    public long getRetryPendingTime() {
        long waitTime;
        int maxSize = sRetryTimes.length;
        if (this.mRetryForceCnt > maxSize - 1) {
            waitTime = sRetryTimes[maxSize - 1];
        } else {
            waitTime = sRetryTimes[this.mRetryForceCnt];
        }
        long currentTime = SystemClock.elapsedRealtime();
        if (this.mLastForceSyncTime == 0 && this.mRetryForceCnt == 0) {
            this.mLastForceSyncTime = currentTime;
            return waitTime;
        }
        long startSyncTime = this.mLastForceSyncTime + waitTime;
        long pending = startSyncTime - currentTime;
        if (pending > waitTime) {
            return waitTime;
        }
        if (pending < 0) {
            return 0L;
        }
        return pending;
    }

    public int getRetryCnt() {
        return this.mRetryForceCnt;
    }

    public void setRetryCntBack() {
        this.mLastForceSyncTime = 0L;
        this.mRetryForceCnt = 0;
    }

    public void register(Handler handler, LocationListener listener) {
        MyLog.i("register");
        this.mListener = listener;
        setHandler(handler);
        if (this.mWeatherReceiver == null) {
            initWeatherReceiver();
        }
        if (this.mTempUnitReceiver == null && this.mTempUnitEnable) {
            initTempUnitReceiver();
        }
        if (this.mConnectChangeRec == null && this.mRetryEnable) {
            initConnReceiver();
        }
        this.mState = State.START;
        if (isUsedTempC()) {
            this.mUnit = WeatherForecast.UNIT._C;
        } else {
            this.mUnit = WeatherForecast.UNIT._F;
        }
        updateWeatherData();
    }

    public void forceUpdateIfNoData() {
        if (State.START == this.mState) {
            MyLog.i("forceUpdateIfNoData~");
            if (isNeedUpdate()) {
                forceToSync();
            }
        }
    }

    private void initConnReceiver() {
        this.mConnectChangeRec = new BroadcastReceiver() { // from class: com.htc.clock.util.location.LocationCtrl.1
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent intent) {
                MyLog.i("mConnectChangeRec onReceive~");
                MyUtil.removeMessage(LocationCtrl.this.mHandler, 2);
                MyUtil.sendMessage(LocationCtrl.this.mHandler, 2, 500L);
            }
        };
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.net.conn.BACKGROUND_DATA_SETTING_CHANGED");
        intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        this.mContext.registerReceiver(this.mConnectChangeRec, intentFilter);
    }

    public void forceRetryWeather() {
        MyUtil.removeMessage(this.mHandler, 2);
        if (getState() == State.START && isNeedUpdate()) {
            int cnt = getRetryCnt();
            MyLog.i("forceRetryWeather~ cnt:" + cnt);
            if (isForceUpdateAvailable()) {
                forceUpdateIfNoData();
                if (cnt < 2) {
                    long pending = getRetryPendingTime();
                    MyLog.i("forceRetryWeather~ schedule pending:" + pending);
                    MyUtil.sendMessage(this.mHandler, 2, pending);
                }
            }
        }
    }

    private void initTempUnitReceiver() {
        if (this.mTempUnitReceiver == null) {
            MyLog.i("initTempUnitReceiver~");
            this.mTempUnitReceiver = new BroadcastReceiver() { // from class: com.htc.clock.util.location.LocationCtrl.2
                @Override // android.content.BroadcastReceiver
                public void onReceive(Context context, Intent intent) {
                    WeatherForecast.UNIT unit;
                    String temperatureUnit = intent.getStringExtra("settingData");
                    if (temperatureUnit.equals("c")) {
                        unit = WeatherForecast.UNIT._C;
                    } else {
                        unit = WeatherForecast.UNIT._F;
                    }
                    MyLog.i("tempUnit onReceive~ temperatureUnit:" + temperatureUnit);
                    if (LocationCtrl.this.mUnit != unit) {
                        LocationCtrl.this.mUnit = unit;
                        if (LocationCtrl.this.mListener != null) {
                            MyUtil.sendMessage(LocationCtrl.this.mUIHandler, 1003);
                        } else {
                            MyLog.e("tempUnit onReceive~ mListener is null");
                        }
                    }
                }
            };
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("com.htc.sync.provider.weather.SETTINGS_UPDATED");
            intentFilter.addCategory("com.htc.sync.provider.weather.setting.temperatureunit");
            this.mContext.registerReceiver(this.mTempUnitReceiver, intentFilter);
        }
    }

    private void initWeatherReceiver() {
        if (this.mWeatherReceiver == null) {
            MyLog.i("initWeatherReceiver~ init weatherReceiver");
            this.mWeatherReceiver = new BroadcastReceiver() { // from class: com.htc.clock.util.location.LocationCtrl.3
                @Override // android.content.BroadcastReceiver
                public void onReceive(Context context, Intent intent) {
                    LocationCtrl.this.mBOnReceiveWeatherData = true;
                    int length = LocationCtrl.this.mSOnReceiveLog.length();
                    if (length > 0) {
                        LocationCtrl.this.mSOnReceiveLog.delete(0, length - 1);
                    }
                    Calendar time = Calendar.getInstance();
                    int hour = time.get(10);
                    int min = time.get(12);
                    LocationCtrl.this.mSOnReceiveLog.append("onReceive~ weatherdata:").append(hour).append(":").append(min).append("\n");
                    MyLog.i("onReceive~ weatherdata");
                    Set<String> categories = intent.getCategories();
                    WSPData data = intent.getParcelableExtra("data");
                    Message msg = Message.obtain();
                    msg.obj = data;
                    if (categories.contains(LocationCtrl.CATEGORY_NAME)) {
                        msg.what = 3;
                        boolean forceUpdateResult = intent.getBooleanExtra("status", false);
                        if (forceUpdateResult) {
                            msg.arg1 = 1;
                        } else {
                            msg.arg1 = 0;
                        }
                        LocationCtrl.this.mSOnReceiveLog.append("onReceive~ category\n");
                        MyUtil.sendMessage(LocationCtrl.this.mHandler, msg, 0L);
                        return;
                    }
                    LocationCtrl.this.mSOnReceiveLog.append("onReceive~ normal\n");
                    msg.what = 1;
                    MyUtil.sendMessage(LocationCtrl.this.mHandler, msg, 0L);
                }
            };
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("com.htc.sync.provider.weather.result");
            intentFilter.addCategory(CATEGORY_NAME);
            Iterator i$ = this.mWSPReqList.iterator();
            while (i$.hasNext()) {
                WSPRequest wspReq = i$.next();
                MyLog.i("initWeatherReceiver~ wspReq.toString():" + wspReq.toString());
                intentFilter.addCategory(wspReq.toString());
            }
            this.mContext.registerReceiver(this.mWeatherReceiver, intentFilter);
        }
        if (this.mWeatherApReceiver == null) {
            MyLog.i("initWeatherReceiver~ init mWeatherApReceiver");
            this.mWeatherApReceiver = new BroadcastReceiver() { // from class: com.htc.clock.util.location.LocationCtrl.4
                @Override // android.content.BroadcastReceiver
                public void onReceive(Context context, Intent intent) {
                    MyLog.i("onReceive~ weather ap update");
                    if ("com.htc.Weather.delete_current_location".equals(intent.getAction()) && LocationCtrl.this.mIsWithCurLocation) {
                        MyUtil.sendMessage(LocationCtrl.this.mHandler, 4, 0L);
                    }
                }
            };
            IntentFilter intentFilter2 = new IntentFilter();
            intentFilter2.addAction("com.htc.Weather.delete_current_location");
            this.mContext.registerReceiver(this.mWeatherApReceiver, intentFilter2);
        }
    }

    public void unRegister() {
        MyUtil.removeMessage(this.mHandler, 1);
        MyUtil.removeMessage(this.mHandler, 2);
        MyUtil.removeMessage(this.mHandler, 3);
        MyUtil.removeMessage(this.mHandler, 4);
        if (this.mWeatherReceiver != null) {
            this.mContext.unregisterReceiver(this.mWeatherReceiver);
            this.mWeatherReceiver = null;
        }
        if (this.mTempUnitReceiver != null) {
            this.mContext.unregisterReceiver(this.mTempUnitReceiver);
            this.mTempUnitReceiver = null;
        }
        if (this.mWeatherApReceiver != null) {
            this.mContext.unregisterReceiver(this.mWeatherApReceiver);
            this.mWeatherApReceiver = null;
        }
        if (this.mConnectChangeRec != null) {
            this.mContext.unregisterReceiver(this.mConnectChangeRec);
            this.mConnectChangeRec = null;
        }
        this.mState = State.STOP;
    }

    public void onReceiverForceRetWeatherData(boolean bForceRet, WSPData data) {
    }

    public void onReceiverWeatherData(WSPData data) {
        LocationData locData;
        if (data == null) {
            this.mSOnReceiveLog.append("onReceiverWeatherData~ data is null\n");
            return;
        }
        this.mSOnReceiveLog.append("onReceiverWeatherData~ data:").append(data.toDebugInfo());
        boolean isCurData = data.getType() == 1;
        if (isCurData) {
            LocationData locData2 = this.mLocDataMap.get(CURRENT_LOCATION_KEY);
            locData = locData2;
        } else {
            LocationData locData3 = this.mLocDataMap.get(data.getLocCode());
            locData = locData3;
        }
        if (locData == null) {
            this.mSOnReceiveLog.append("onReceiverWeatherData~ locData == null\n");
            return;
        }
        boolean change = locData.setupByWSPData(data, false);
        if (TextUtils.equals(data.getLocCode(), this.mLocKey) || (isCurData && isCurrentLocation())) {
            sendWSPUpdateMessage(change);
        } else if (data.getType() == 1 && locData.mState != LocationState.NO_DATA) {
            sendWSPUpdateMessage(change);
        }
    }

    public void updateWeatherData() {
        WSPData wspData;
        boolean bCityChanged = false;
        boolean bwithCurData = false;
        for (String locKey : this.mLocDataMap.keySet()) {
            MyLog.i("updateWeatherData~ locKey:" + locKey);
            LocationData locData = this.mLocDataMap.get(locKey);
            if (CURRENT_LOCATION_KEY.equals(locKey)) {
                wspData = requestCurData();
            } else {
                wspData = requestLocData(locData.getLocCode());
            }
            boolean change = locData.setupByWSPData(wspData, true);
            if (CURRENT_LOCATION_KEY.equals(locKey) && isCurrentLocation()) {
                if (isCurrentLocation()) {
                    bCityChanged = change;
                }
                bwithCurData = locData.mState != LocationState.NO_DATA;
            }
        }
        if (!CURRENT_LOCATION_KEY.equals(this.mLocKey) && bwithCurData) {
            bCityChanged = true;
        }
        sendWSPUpdateMessage(bCityChanged);
    }

    public String getLocName() {
        String locName = null;
        LocationData locData = this.mLocDataMap.get(this.mLocKey);
        if (locData != null) {
            locName = locData.getLocName();
        }
        MyLog.i("LocationCtrl~ getLocName:" + locName);
        return locName;
    }

    public String getLocConditionId() {
        String locConditon = null;
        LocationData locData = this.mLocDataMap.get(this.mLocKey);
        WeatherForecast weatherForecast = null;
        if (locData != null) {
            weatherForecast = locData.getForecast();
        }
        if (weatherForecast != null) {
            locConditon = weatherForecast.getCondition();
        }
        if (locConditon == null) {
            return "";
        }
        return locConditon;
    }

    public int getLocConditionIdInt() {
        String conditionId = getLocConditionId();
        try {
            int id = Integer.parseInt(conditionId);
            return id;
        } catch (Exception e) {
            MyLog.i("getLocConditionIdInt~ exception:" + e.getMessage());
            return 0;
        }
    }

    public String getLocTemp() {
        LocationData locData = this.mLocDataMap.get(this.mLocKey);
        if (locData == null) {
            return "";
        }
        int temp = locData.getForecast().getCur(this.mUnit);
        return getTemp(temp);
    }

    public String getHTemp() {
        LocationData locData = this.mLocDataMap.get(this.mLocKey);
        if (locData == null) {
            return "";
        }
        WeatherForecast weatherForecast = locData.getForecast();
        if (weatherForecast == null) {
            return "";
        }
        int temp = locData.getForecast().getHigh(this.mUnit);
        return getTemp(temp);
    }

    public String getLTemp() {
        LocationData locData = this.mLocDataMap.get(this.mLocKey);
        if (locData == null) {
            return "";
        }
        WeatherForecast weatherForecast = locData.getForecast();
        if (weatherForecast == null) {
            return "";
        }
        int temp = locData.getForecast().getLow(this.mUnit);
        return getTemp(temp);
    }

    private String getTemp(int temp) {
        if (temp == -500) {
            return "";
        }
        StringBuffer strBuffer = new StringBuffer(10);
        strBuffer.append(temp);
        strBuffer.append(DEGREE);
        return strBuffer.toString();
    }

    public boolean updateDataByForeCast() {
        LocationData locData = this.mLocDataMap.get(this.mLocKey);
        if (locData == null) {
            return false;
        }
        boolean bUpdate = locData.updateForecastDateNow();
        return bUpdate;
    }

    private class UIHandler extends Handler {
        UIHandler(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            LocationListener listener = LocationCtrl.this.mListener;
            if (listener != null) {
                switch (msg.what) {
                    case 1001:
                        listener.onCityUpdate(LocationCtrl.this);
                        break;
                    case 1002:
                        listener.onWeatherUpdate(LocationCtrl.this);
                        break;
                    case 1003:
                        listener.onTempUnitChange(LocationCtrl.this);
                        break;
                }
            }
        }
    }

    private class BGHandler extends Handler {
        BGHandler(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    WSPData data = (WSPData) msg.obj;
                    LocationCtrl.this.onReceiverWeatherData(data);
                    break;
                case 2:
                    if (LocationCtrl.this.mListener != null && LocationCtrl.this.mListener.isResume()) {
                        LocationCtrl.this.forceRetryWeather();
                        break;
                    }
                    break;
                case 3:
                    WSPData data2 = (WSPData) msg.obj;
                    boolean forceUpdateResult = msg.arg1 == 1;
                    LocationCtrl.this.onReceiverForceRetWeatherData(forceUpdateResult, data2);
                    break;
                case 4:
                    LocationCtrl.this.updateWeatherData();
                    break;
            }
        }
    }

    private void setHandler(Handler handler) {
        Looper looper = null;
        if (handler != null) {
            looper = handler.getLooper();
        }
        if (looper == null) {
            MyLog.e("setHandler~ no looper");
        }
        this.mHandler = new BGHandler(looper);
    }

    public LocationState getLocState() {
        LocationData locData = this.mLocDataMap.get(this.mLocKey);
        return locData == null ? LocationState.NO_DATA : locData.mState;
    }

    public boolean isNeedUpdate() {
        if (getLocState() != LocationState.OK) {
            MyLog.i("isNeedUpdate~ no weather");
            return true;
        }
        long updateInterval = WSPUtility.getAutoSyncFrequency(this.mContext) + OVERDUE_OFFSET;
        long updateTime = getLastUpdateTime();
        long nextAutoSyncTime = updateTime + updateInterval;
        if (MyLog.IsDebugLog()) {
            Calendar time = Calendar.getInstance();
            time.setTimeInMillis(System.currentTimeMillis());
            int day = time.get(5);
            int hour = time.get(10);
            int min = time.get(12);
            MyLog.i("isNeedUpdate~ updateInterval:" + (updateInterval / 60000));
            MyLog.i("isNeedUpdate~ current):" + day + ":" + hour + ":" + min);
            time.setTimeInMillis(updateTime);
            int day2 = time.get(5);
            int hour2 = time.get(10);
            int min2 = time.get(12);
            MyLog.i("isNeedUpdate~ updateTime):" + day2 + ":" + hour2 + ":" + min2);
            time.setTimeInMillis(nextAutoSyncTime);
            int day3 = time.get(5);
            int hour3 = time.get(10);
            int min3 = time.get(12);
            MyLog.i("isNeedUpdate~ nextAutoSyncTime):" + day3 + ":" + hour3 + ":" + min3);
        }
        if (System.currentTimeMillis() - nextAutoSyncTime >= 0) {
            MyLog.i("isNeedUpdate~ true");
            return true;
        }
        MyLog.i("isNeedUpdate~ false");
        return false;
    }

    public long getLastUpdateTime() {
        LocationData locData = this.mLocDataMap.get(this.mLocKey);
        if (locData != null) {
            return locData.getLastUpdateTime();
        }
        return 0L;
    }

    public boolean isWithCurrentLocation() {
        return this.mIsWithCurLocation;
    }

    public boolean isCurrentLocation() {
        return this.mIsWithCurLocation && TextUtils.equals(this.mLocKey, CURRENT_LOCATION_KEY);
    }

    public String getLocCode() {
        LocationData locData = this.mLocDataMap.get(this.mLocKey);
        if (locData != null) {
            return locData.getLocCode();
        }
        return null;
    }

    public WeatherLocation getWeatherLocation() {
        LocationData locData = this.mLocDataMap.get(this.mLocKey);
        if (locData != null) {
            return locData.getWeatherLocation();
        }
        return null;
    }

    public String getTimeZoneId() {
        LocationData locData = this.mLocDataMap.get(this.mLocKey);
        if (locData != null) {
            return locData.getLocTimeZoneId();
        }
        return null;
    }

    public State getState() {
        return this.mState;
    }

    public void sendWSPUpdateMessage(boolean bCityChanged) {
        if (this.mListener == null) {
            MyLog.e("sendWSPUpdateMessage~ listener is null");
            return;
        }
        if (getLocState() == LocationState.OK) {
            setRetryCntBack();
        }
        if (bCityChanged) {
            if (getLocState() == LocationState.NO_DATA) {
                checkLocService();
            }
            MyUtil.sendMessage(this.mUIHandler, 1001);
            return;
        }
        MyUtil.sendMessage(this.mUIHandler, 1002);
    }

    private boolean isUsedTempC() {
        String tempUnit = WSPUtility.getTemperatureUnit(this.mContext);
        if (tempUnit == null || tempUnit.length() <= 0) {
            return true;
        }
        boolean bUseTempC = tempUnit.equals("c");
        return bUseTempC;
    }

    public static String getWeatheApCityName(WeatherLocation weatherLoc) {
        String cityName = "";
        if (weatherLoc == null) {
            return "";
        }
        if (weatherLoc.getName() != null && weatherLoc.getName().length() > 0) {
            cityName = weatherLoc.getName();
        }
        if (weatherLoc.getState() != null && weatherLoc.getState().length() > 0) {
            return cityName + ", " + weatherLoc.getState();
        }
        if (weatherLoc.getCountry() != null && weatherLoc.getCountry().length() > 0) {
            return cityName + ", " + weatherLoc.getCountry();
        }
        return cityName;
    }

    public boolean checkTempUnit() {
        WeatherForecast.UNIT unit;
        WeatherForecast.UNIT unit2 = WeatherForecast.UNIT._C;
        if (isUsedTempC()) {
            unit = WeatherForecast.UNIT._C;
        } else {
            unit = WeatherForecast.UNIT._F;
        }
        if (unit != this.mUnit) {
            this.mUnit = unit;
            return true;
        }
        return false;
    }

    public void checkLocService() {
        LocationListener listener = this.mListener;
        if (listener != null && listener.isChinaLocationService()) {
            this.mLocationAvailable = 1 == Settings.System.getInt(this.mContext.getContentResolver(), CURRENT_LOCATION_AVAIABLE, 1);
        }
    }

    public boolean isLocServiceAvailable() {
        return this.mLocationAvailable;
    }

    public boolean checkLocEnable() {
        boolean bOrg = this.mLocationEnable;
        LocationListener listener = this.mListener;
        if (listener != null && listener.isHelpTurnOnLoc()) {
            this.mLocationEnable = isUseWirelessNetworks(this.mContext);
        }
        MyLog.i("checkLocEnable enable:" + this.mLocationEnable);
        return bOrg != this.mLocationEnable;
    }

    public boolean isLocServiceEnable() {
        MyLog.i("isLocServiceEnable enable:" + this.mLocationEnable);
        return this.mLocationEnable;
    }

    public static boolean isUseWirelessNetworks(Context context) {
        return Settings.Secure.isLocationProviderEnabled(context.getContentResolver(), "network");
    }

    private boolean allowBackgroundData(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService("connectivity");
        if (cm != null) {
            return cm.getBackgroundDataSetting();
        }
        MyLog.w("allowBackgroundData can't get Connectivity Manager");
        return false;
    }
}
