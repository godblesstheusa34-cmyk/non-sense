package com.htc.clock.util.location;

import android.content.ContentResolver;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import com.htc.clock.util.MyLog;
import com.htc.clock.util.MyUtil;
import com.htc.consts.WeatherConsts;
import com.htc.util.weather.WeatherLocation;
import com.htc.util.weather.WeatherUtility;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class HomeUtil {
    public static final String APP_MY_HOME = "com.htc.android.worldclock.home";
    private static final int WHAT_UI_UPDATE = 1;
    private Context mContext;
    private Handler mHandler;
    private String mHomeName;
    private ContentObserver mHomeObserver;
    private String mHomeTimezone;
    private onHomeChangeListener mListener;
    private Object mLock = new Object();
    private Runnable mUpdater = new Runnable() { // from class: com.htc.clock.util.location.HomeUtil.1
        @Override // java.lang.Runnable
        public void run() {
            HomeUtil.this.getCurrentHomeTime();
        }
    };
    private Handler mUIHandler = new MyUIHandler(Looper.getMainLooper());

    public interface onHomeChangeListener {
        void onHomeCityChange();
    }

    public HomeUtil(Context context, Handler handler) {
        this.mContext = context;
        this.mHandler = handler;
    }

    public String getHomeCityName() {
        return this.mHomeName;
    }

    public String getHomeCityTimezone() {
        return this.mHomeTimezone;
    }

    public void register(onHomeChangeListener listener) {
        synchronized (this.mLock) {
            MyLog.i("MyHomeUtil register~");
            this.mListener = listener;
            if (this.mHomeObserver == null) {
                Uri uri = Uri.withAppendedPath(WeatherConsts.CONTENT_URI, "location");
                Uri uri2 = Uri.withAppendedPath(uri, "com.htc.android.worldclock.home");
                this.mHomeObserver = new HomeObserver(this.mContext.getContentResolver());
                this.mContext.getContentResolver().registerContentObserver(uri2, true, this.mHomeObserver);
            }
            getCurrentHomeTime();
        }
    }

    public void unRegister() {
        synchronized (this.mLock) {
            MyLog.i("MyHomeUtil unRegister~");
            if (this.mHomeObserver != null) {
                this.mContext.getContentResolver().unregisterContentObserver(this.mHomeObserver);
            }
            this.mHomeObserver = null;
            this.mListener = null;
            if (this.mHandler != null) {
                this.mHandler.removeCallbacks(this.mUpdater);
            }
            this.mHandler = null;
        }
    }

    protected void getCurrentHomeTime() {
        String homeName;
        MyLog.i("MyHomeUtil getCurrentHomeTime~");
        WeatherLocation[] w = WeatherUtility.loadLocations(this.mContext.getContentResolver(), "com.htc.android.worldclock.home");
        Calendar calNow = Calendar.getInstance();
        TimeZone tzNow = calNow.getTimeZone();
        String timezone = tzNow.getID();
        if (w != null && w.length > 0) {
            String idHome = w[0].getTimezoneId();
            String nameHome = w[0].getName();
            if (nameHome == null || nameHome.length() == 0) {
                homeName = queryTimeZoneName(idHome);
            } else {
                homeName = nameHome;
            }
            timezone = idHome;
        } else {
            homeName = queryTimeZoneName(timezone);
        }
        this.mHomeName = homeName;
        this.mHomeTimezone = timezone;
        MyUtil.sendMessage(this.mUIHandler, 1);
    }

    protected String queryTimeZoneName(String timezoneId) {
        MyLog.i("MyHomeUtil queryTimeZoneName~");
        String where = "timezoneId='" + timezoneId + "'";
        Locale systemLocale = this.mContext.getResources().getConfiguration().locale;
        String systemLang = systemLocale.getLanguage();
        String systemCountry = systemLocale.getCountry();
        if (LocationUtil.ZH.equals(systemLang)) {
            if ("CN".equals(systemCountry)) {
                systemLang = LocationUtil.ZH;
            } else if ("TW".equals(systemCountry)) {
                systemLang = LocationUtil.ZHTW;
            } else if ("HK".equals(systemCountry)) {
                systemLang = LocationUtil.ZHTW;
            } else if ("SG".equals(systemCountry)) {
                systemLang = LocationUtil.ZH;
            }
        }
        Cursor c = null;
        try {
            c = this.mContext.getContentResolver().query(LocationUtil.CONTENT_URI, null, where, null, null);
        } catch (Exception e) {
            MyLog.e("queryTimeZoneName~ queryTimeZoneName fail e:" + e.getMessage());
        }
        if (c != null) {
            if (c.getCount() > 0 && c.moveToFirst()) {
                int index = c.getColumnIndex(systemLang);
                if (index < 0) {
                    index = c.getColumnIndex(LocationUtil.EN);
                }
                if (index >= 0) {
                    timezoneId = c.getString(index);
                } else {
                    MyLog.e("queryTimeZoneName~ error index:" + index);
                }
            }
            c.close();
        } else {
            MyLog.e("queryTimeZoneName~ c is null");
        }
        return timezoneId;
    }

    private class HomeObserver extends ContentObserver {
        public HomeObserver(ContentResolver cr) {
            super(new Handler());
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean selfChange) {
            Handler handler = HomeUtil.this.mHandler;
            if (handler != null) {
                handler.removeCallbacks(HomeUtil.this.mUpdater);
                handler.postDelayed(HomeUtil.this.mUpdater, 500L);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateHomeListener() {
        onHomeChangeListener listener = this.mListener;
        if (listener != null) {
            listener.onHomeCityChange();
        }
    }

    private class MyUIHandler extends Handler {
        public MyUIHandler(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            int what = msg.what;
            switch (what) {
                case 1:
                    HomeUtil.this.updateHomeListener();
                    break;
            }
        }
    }
}
