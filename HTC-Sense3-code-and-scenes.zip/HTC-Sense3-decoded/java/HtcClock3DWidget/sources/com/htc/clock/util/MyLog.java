package com.htc.clock.util;

import android.util.Log;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class MyLog {
    private static final String TAG = "ClockWidget";
    private static final boolean localLOGV = false;

    public static void i(String msg) {
    }

    public static void d(String msg) {
    }

    public static void w(String msg) {
    }

    public static void e(String msg, Throwable e) {
        Log.e(TAG, msg, e);
    }

    public static void e(String msg) {
        Log.e(TAG, msg);
    }

    public static boolean IsDebugLog() {
        return false;
    }
}
