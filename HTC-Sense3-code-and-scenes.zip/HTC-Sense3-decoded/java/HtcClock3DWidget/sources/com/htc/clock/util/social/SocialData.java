package com.htc.clock.util.social;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;
import com.htc.clock.util.MyLog;
import com.htc.graphics.drawable.UrlDrawable;
import com.htc.text.util.HtcDateUtils;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.net.URISyntaxException;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class SocialData {
    public static final String AUTHORITY = "com.htc.socialnetwork.flickr.provider.StreamProvider";
    public static final String COL_DATE_UPLOAD = "date_upload";
    public static final String COL_MEDIUM_TYPE = "medium_type";
    public static final String COL_OWNER_ID = "owner_id";
    public static final String DEFAULT_SORT_ORDER = "date_upload DESC";
    public static final String FACEBOOK_AUTHORITY = "com.htc.socialnetwork.facebook.provider.CacheImageProvider";
    public static final String FLICKR_AUTHORITY = "com.htc.socialnetwork.flickr.provider.CacheImageProvider";
    private static final long MAX_CLUSTER_TIME = 600000;
    public static final String PATH_NAME = "cache";
    public static final String PLURK_AUTHORITY = "com.htc.socialnetwork.plurk.provider.CacheImageProvider";
    public static final String TABLE_NAME = "media";
    public static final String TWITTER_AUTHORITY = "com.htc.htctwitter.provider.CacheImageProvider";
    String cache_image;
    int comment_count;
    RemoteUrlDrawable iconDrawable;
    int icon_id;
    int icon_indicator;
    String icon_url;
    Bitmap indicator;
    String intentUri;
    int label_id;
    int like_count;
    String media;
    String message;
    String message_id;
    String package_name;
    long timestamp;
    String uid;
    String username;
    public static final Uri FACEBOOK_AUTHORITY_URI = Uri.parse("content://com.htc.socialnetwork.facebook.provider.CacheImageProvider");
    public static final Uri FLICKR_AUTHORITY_URI = Uri.parse("content://com.htc.socialnetwork.flickr.provider.CacheImageProvider");
    public static final Uri PLURK_AUTHORITY_URI = Uri.parse("content://com.htc.socialnetwork.plurk.provider.CacheImageProvider");
    public static final Uri TWITTER_AUTHORITY_URI = Uri.parse("content://com.htc.htctwitter.provider.CacheImageProvider");
    public static final Uri AUTHORITY_URI = Uri.parse("content://com.htc.socialnetwork.flickr.provider.StreamProvider");
    public static final Uri MEDIA_CONTENT_URI = Uri.withAppendedPath(AUTHORITY_URI, "media");
    private static String TYPE_FLICKR = SocialNetworkResolver.FLICKR_ACCOUNT_TYPE;
    private static final Bitmap sDefaultAvatar = BitmapFactory.decodeResource(Resources.getSystem(), 34078914);

    public interface InflatedCallback {
        void onURLDrawableInflated(RemoteUrlDrawable remoteUrlDrawable);
    }

    public SocialData(Cursor cursor) {
        this.uid = getString(cursor, SocialNetworkResolver.COL_UID);
        this.message_id = getString(cursor, SocialNetworkResolver.COL_MESSAGE_ID);
        this.message = getString(cursor, SocialNetworkResolver.COL_MESSAGE);
        this.timestamp = getLong(cursor, SocialNetworkResolver.COL_TIMESTAMP);
        this.package_name = getString(cursor, SocialNetworkResolver.COL_PACKAGE_NAME);
        this.label_id = getInt(cursor, SocialNetworkResolver.COL_LABEL_ID);
        this.icon_id = getInt(cursor, SocialNetworkResolver.COL_ICON_ID);
        this.username = getString(cursor, SocialNetworkResolver.COL_USERNAME);
        this.icon_url = getString(cursor, SocialNetworkResolver.COL_ICON_URL);
        this.comment_count = getInt(cursor, SocialNetworkResolver.COL_COMMENT_COUNT);
        this.like_count = getInt(cursor, SocialNetworkResolver.COL_LIKE_COUNT);
        this.intentUri = getString(cursor, SocialNetworkResolver.COL_INTENT);
        this.icon_indicator = getInt(cursor, SocialNetworkResolver.COL_INDICATOR);
        this.cache_image = getString(cursor, SocialNetworkResolver.COL_CACHE_IMAGE);
        this.media = getString(cursor, "media");
    }

    private long getLong(Cursor cursor, String columnName) {
        int index = cursor.getColumnIndex(columnName);
        if (index >= 0) {
            try {
                long value = cursor.getLong(index);
                return value;
            } catch (Exception e) {
                MyLog.e("socailData getlong e:" + e.getMessage());
                return -1L;
            }
        }
        MyLog.e("socailData getlong(" + columnName + ") index < 0");
        return -1L;
    }

    private int getInt(Cursor cursor, String columnName) {
        int index = cursor.getColumnIndex(columnName);
        if (index >= 0) {
            try {
                int value = cursor.getInt(index);
                return value;
            } catch (Exception e) {
                MyLog.e("socailData getlong e:" + e.getMessage());
                return -1;
            }
        }
        MyLog.e("socailData getlong(" + columnName + ") index < 0");
        return -1;
    }

    private String getString(Cursor cursor, String columnName) {
        int index = cursor.getColumnIndex(columnName);
        if (index >= 0) {
            try {
                String value = cursor.getString(index);
                return value;
            } catch (Exception e) {
                MyLog.e("socailData getlong e:" + e.getMessage());
                return null;
            }
        }
        MyLog.e("socailData getString(" + columnName + ") index < 0");
        return null;
    }

    public String getMessage() {
        return this.message;
    }

    public boolean isFlicker() {
        if (this.package_name == null) {
            return false;
        }
        return this.package_name.equals(TYPE_FLICKR);
    }

    public String getName() {
        return this.username;
    }

    public Drawable getIcon(Context context) {
        MyLog.i("socailData getIcon:" + this.icon_url + " icon_indicator:" + this.icon_indicator + " package_name:" + this.package_name);
        if (this.iconDrawable == null) {
            UrlDrawable.Options opt = new UrlDrawable.Options();
            UrlDrawable.Dimension dimension = opt.forceDim;
            UrlDrawable.Dimension dimension2 = opt.forceDim;
            int width = sDefaultAvatar.getWidth();
            dimension2.height = width;
            dimension.width = width;
            opt.defaultBitmap = sDefaultAvatar;
            opt.overlayPos = 17;
            try {
                opt.overlayBitmap = BitmapFactory.decodeResource(Resources.getSystem(), this.icon_indicator);
            } catch (Exception e) {
                try {
                    opt.overlayBitmap = BitmapFactory.decodeResource(context.getPackageManager().getResourcesForApplication(this.package_name), this.icon_indicator);
                } catch (PackageManager.NameNotFoundException e2) {
                    MyLog.e("Icon not found");
                }
            }
            this.iconDrawable = new RemoteUrlDrawable(context, this.icon_url, opt);
        }
        return this.iconDrawable;
    }

    public int[] getUploaded(Context context) {
        ContentResolver cr = context.getContentResolver();
        Cursor c = null;
        int[] data = {0, 0};
        long previous_time = this.timestamp * 1000;
        try {
            c = cr.query(MEDIA_CONTENT_URI, null, null, null, DEFAULT_SORT_ORDER);
            if (c != null) {
                while (c.getCount() > 0 && c.moveToNext()) {
                    long create_time = getCreateTime(context, c);
                    String previous_user = getProfileId(context, c);
                    if (previous_time - create_time > MAX_CLUSTER_TIME || this.uid.compareTo(previous_user) != 0) {
                        break;
                    }
                    if (getMediaType(context, c) == 0) {
                        data[0] = data[0] + 1;
                    } else {
                        data[1] = data[1] + 1;
                    }
                    previous_time = create_time;
                }
            }
            if (c != null) {
                c.close();
            }
        } catch (Exception e) {
            if (c != null) {
                c.close();
            }
        } catch (Throwable th) {
            if (c != null) {
                c.close();
            }
            throw th;
        }
        return data;
    }

    private long getCreateTime(Context context, Cursor c) {
        long time = c.getLong(c.getColumnIndex(COL_DATE_UPLOAD));
        return time;
    }

    private String getProfileId(Context context, Cursor c) {
        String user_id = c.getString(c.getColumnIndex(COL_OWNER_ID));
        return user_id;
    }

    private int getMediaType(Context context, Cursor c) {
        int type = c.getInt(c.getColumnIndex(COL_MEDIUM_TYPE));
        return type;
    }

    public Bitmap getIconIndicator(Context context) {
        PackageManager pm = context.getPackageManager();
        try {
            Resources res = pm.getResourcesForApplication(this.package_name);
            this.indicator = ((BitmapDrawable) res.getDrawable(this.icon_indicator)).getBitmap();
        } catch (PackageManager.NameNotFoundException e) {
            MyLog.e("getIconIndicator : Icon indicator can't be found from packagename");
        }
        return this.indicator;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public Uri getCacheUri() {
        if (!TextUtils.isEmpty(this.cache_image)) {
            Uri contentUri = Uri.parse(this.cache_image);
            return contentUri;
        }
        Uri contentUri2 = mapToURI(this.package_name);
        return contentUri2;
    }

    public long getTimeStamp() {
        return this.timestamp;
    }

    public CharSequence getPastTimeString(Context context) {
        MyLog.i("socailData getPastTimeString:" + this.timestamp);
        CharSequence pastTimeString = HtcDateUtils.getRelativeDateTimeString(context, this.timestamp * 1000, 1000L, 86400000L, 262160);
        return pastTimeString;
    }

    public int getLikeCnt() {
        return this.like_count;
    }

    public int getCommentCnt() {
        return this.comment_count;
    }

    public void launchRelativePage(Context hostActivity) {
        MyLog.i("socailData launchRelativePage in phone");
        if (!TextUtils.isEmpty(this.intentUri)) {
            try {
                Intent intent = Intent.parseUri(this.intentUri, 0);
                if (intent != null) {
                    intent.addFlags(268435456);
                    intent.addFlags(67108864);
                    hostActivity.startActivity(intent);
                }
            } catch (URISyntaxException e) {
                e.printStackTrace();
            }
        }
    }

    public class RemoteUrlDrawable extends UrlDrawable {
        private InflatedCallback mInflateCallback;

        public RemoteUrlDrawable(Context context, String url, UrlDrawable.Options options) {
            super(context, url, options);
        }

        public Bitmap getBitmapFromDiskCache() throws Exception {
            Uri contentUri = SocialData.this.getCacheUri();
            MyLog.i("getBitmapFromDiskCache contentUri =" + contentUri);
            if (contentUri == null) {
                MyLog.e("getBitmapFromDiskCache no cache URL!  package_name=" + SocialData.this.package_name);
                return super.getBitmapFromDiskCache();
            }
            Uri uri = Uri.withAppendedPath(contentUri, ((UrlDrawable) this).mUrl.hashCode() + ".png");
            Bitmap bitmap = null;
            sFileReadLock.lockInterruptibly();
            try {
                ParcelFileDescriptor f = ((UrlDrawable) this).mContext.getContentResolver().openFileDescriptor(uri, "r");
                bitmap = BitmapFactory.decodeFileDescriptor(f.getFileDescriptor());
            } catch (FileNotFoundException e) {
                MyLog.w("getBitmapFromDiskCache FileNotFoundException!  url=" + ((UrlDrawable) this).mUrl);
            } catch (Exception e2) {
                MyLog.e("getBitmapFromDiskCache failed!  url=" + ((UrlDrawable) this).mUrl, e2);
            } finally {
                sFileReadLock.unlock();
            }
            return bitmap;
        }

        public void writeBitmapToDiskCache(Bitmap bitmap) throws Exception {
            Exception e;
            FileOutputStream fos;
            Uri contentUri = SocialData.this.mapToURI(SocialData.this.package_name);
            if (contentUri == null) {
                MyLog.e("writeBitmapToDiskCache no cache URL!  package_name=" + SocialData.this.package_name);
                super.writeBitmapToDiskCache(bitmap);
                return;
            }
            if (((UrlDrawable) this).mOptions.writeDisk) {
                Uri uri = Uri.withAppendedPath(contentUri, ((UrlDrawable) this).mUrl.hashCode() + ".png");
                FileOutputStream fos2 = null;
                sFileWriteLock.lockInterruptibly();
                try {
                    try {
                        ParcelFileDescriptor f = ((UrlDrawable) this).mContext.getContentResolver().openFileDescriptor(uri, "w");
                        fos = new FileOutputStream(f.getFileDescriptor());
                    } catch (Throwable th) {
                        th = th;
                    }
                } catch (FileNotFoundException e2) {
                } catch (Exception e3) {
                    e = e3;
                }
                try {
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
                    if (fos != null) {
                        fos.close();
                    }
                    sFileWriteLock.unlock();
                } catch (FileNotFoundException e4) {
                    fos2 = fos;
                    MyLog.w("writeBitmapToDiskCache FileNotFoundException!  url=" + ((UrlDrawable) this).mUrl);
                    if (fos2 != null) {
                        fos2.close();
                    }
                    sFileWriteLock.unlock();
                } catch (Exception e5) {
                    e = e5;
                    fos2 = fos;
                    MyLog.e("writeBitmapToDiskCache failed!  url=" + ((UrlDrawable) this).mUrl, e);
                    if (fos2 != null) {
                        fos2.close();
                    }
                    sFileWriteLock.unlock();
                } catch (Throwable th2) {
                    th = th2;
                    fos2 = fos;
                    if (fos2 != null) {
                        fos2.close();
                    }
                    sFileWriteLock.unlock();
                    throw th;
                }
            }
        }

        public void setInflatedCallback(InflatedCallback callback) {
            this.mInflateCallback = callback;
        }

        /* JADX WARN: Multi-variable type inference failed */
        public void invalidateSelf() {
            super/*android.graphics.drawable.Drawable*/.invalidateSelf();
            InflatedCallback callback = this.mInflateCallback;
            if (callback != null) {
                callback.onURLDrawableInflated(this);
            }
        }
    }

    public Uri mapToURI(String packageName) {
        if (SocialNetworkResolver.FACEBOOK_ACCOUNT_TYPE.equals(packageName)) {
            Uri contentUri = Uri.withAppendedPath(FACEBOOK_AUTHORITY_URI, PATH_NAME);
            return contentUri;
        }
        if (SocialNetworkResolver.PLURK_ACCOUNT_TYPE.equals(packageName)) {
            Uri contentUri2 = Uri.withAppendedPath(PLURK_AUTHORITY_URI, PATH_NAME);
            return contentUri2;
        }
        if (SocialNetworkResolver.TWITTER_ACCOUNT_TYPE.equals(packageName)) {
            Uri contentUri3 = Uri.withAppendedPath(TWITTER_AUTHORITY_URI, PATH_NAME);
            return contentUri3;
        }
        if (!SocialNetworkResolver.FLICKR_ACCOUNT_TYPE.equals(packageName)) {
            return null;
        }
        Uri contentUri4 = Uri.withAppendedPath(FLICKR_AUTHORITY_URI, PATH_NAME);
        return contentUri4;
    }
}
