package com.htc.clock.util.social;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class SocialNetworkResolver {
    public static final String COL_CACHE_IMAGE = "cache_image";
    public static final String COL_COMMENT_COUNT = "comment_count";
    public static final String COL_ICON_ID = "icon_id";
    public static final String COL_ICON_URL = "icon_url";
    public static final String COL_INDICATOR = "icon_indicator";
    public static final String COL_INTENT = "intent_uri";
    public static final String COL_LABEL_ID = "label_id";
    public static final String COL_LIKE_COUNT = "like_count";
    public static final String COL_MEDIA = "media";
    public static final String COL_MESSAGE = "message";
    public static final String COL_MESSAGE_ID = "message_id";
    public static final String COL_PACKAGE_NAME = "package_name";
    public static final String COL_TIMESTAMP = "timestamp";
    public static final String COL_UID = "uid";
    public static final String COL_USERNAME = "username";
    public static final Uri CONTENT_URI = Uri.parse("content://com.htc.friendstream.provider.FriendStreamProvider/status_update");
    public static final String FACEBOOK_ACCOUNT_TYPE = "com.htc.socialnetwork.facebook";
    public static final String FLICKR_ACCOUNT_TYPE = "com.htc.socialnetwork.flickr";
    public static final String LOG_PREFIX = "SocialNetworkResolver";
    public static final String PLURK_ACCOUNT_TYPE = "com.htc.socialnetwork.plurk";
    public static final String TWITTER_ACCOUNT_TYPE = "com.htc.htctwitter";
    private static SocialData s_cacheData;

    public static SocialData getLastMessage(Context context, boolean bUpdate) {
        if (bUpdate) {
            update(context);
        }
        return s_cacheData;
    }

    public static synchronized void update(Context context) {
        synchronized (SocialNetworkResolver.class) {
            ContentResolver crs = context.getContentResolver();
            SocialData data = null;
            Cursor cursor = null;
            try {
                try {
                    cursor = crs.query(CONTENT_URI, null, null, null, null);
                    if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {
                        data = new SocialData(cursor);
                    }
                } finally {
                    if (0 != 0) {
                        try {
                            cursor.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            } catch (Exception e2) {
                e2.printStackTrace();
                data = null;
                if (cursor != null) {
                    try {
                        cursor.close();
                    } catch (Exception e3) {
                        e3.printStackTrace();
                    }
                }
            }
            s_cacheData = data;
        }
    }
}
