package com.htc.clock.util.time;

import android.content.Context;
import android.os.Handler;
import android.text.TextUtils;
import com.htc.clock.util.MyLog;
import com.htc.clock.util.location.HomeUtil;
import com.htc.clock.util.time.TimeCtrl;
import java.util.Calendar;
import java.util.TimeZone;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class HomeTimeCtrl extends TimeCtrl implements HomeUtil.onHomeChangeListener {
    private String mHomeCityName;
    private HomeUtil mHomeUtil;
    private String mTimeZoneStr;

    @Override // com.htc.clock.util.time.TimeCtrl
    public void init(Context context, TimeCtrl.OnTimeListener listener, int type, Handler handler, String timezone) {
        MyLog.i("HomeTimeCtrl~ init");
        super.init(context, listener, type, handler, null);
        registerHome();
    }

    @Override // com.htc.clock.util.time.TimeCtrl
    public void uninit() {
        MyLog.i("HomeTimeCtrl~ uninit");
        unregisterHome();
        super.uninit();
    }

    public void registerHome() {
        synchronized (this) {
            if (this.mHomeUtil == null) {
                this.mHomeUtil = new HomeUtil(this.mContext, this.mHandler);
                this.mHomeUtil.register(this);
            }
        }
    }

    public void unregisterHome() {
        synchronized (this) {
            if (this.mHomeUtil != null) {
                this.mHomeUtil.unRegister();
                this.mHomeUtil = null;
            }
        }
    }

    @Override // com.htc.clock.util.location.HomeUtil.onHomeChangeListener
    public void onHomeCityChange() {
        this.mHomeCityName = this.mHomeUtil.getHomeCityName();
        this.mTimeZoneStr = this.mHomeUtil.getHomeCityTimezone();
        MyLog.i("HomeTimeCtrl~ onHomeCityChange mHomeCityName:" + this.mHomeCityName + " timeZoneStr:" + this.mTimeZoneStr);
        super.onTimeZoneChanged();
    }

    @Override // com.htc.clock.util.time.TimeCtrl
    public String getTimeZoneCity() {
        return this.mHomeCityName;
    }

    @Override // com.htc.clock.util.time.TimeCtrl
    public Calendar getCalendar() {
        TimeZone tz = null;
        String timezoneStr = this.mTimeZoneStr;
        if (!TextUtils.isEmpty(timezoneStr)) {
            tz = TimeZone.getTimeZone(timezoneStr);
        }
        return tz != null ? Calendar.getInstance(tz) : Calendar.getInstance();
    }
}
