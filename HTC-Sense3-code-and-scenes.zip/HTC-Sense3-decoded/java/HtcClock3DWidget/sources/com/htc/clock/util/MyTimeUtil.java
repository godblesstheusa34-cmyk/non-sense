package com.htc.clock.util;

import android.text.format.Time;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class MyTimeUtil {
    private static final double ONE_DAY_SEC = 86400.0d;

    public static Time setTimeObject(Time t, String date, String timezoneId) {
        int y = 1900;
        int m = 1;
        int d = 1;
        ArrayList<String> keywords = new ArrayList<>();
        String[] arr$ = date.split("/");
        for (String k : arr$) {
            if (!k.equals("")) {
                keywords.add(k);
            }
        }
        try {
            if (keywords.size() > 0) {
                m = Integer.valueOf(keywords.get(0)).intValue();
            }
            if (keywords.size() > 1) {
                d = Integer.valueOf(keywords.get(1)).intValue();
            }
            if (keywords.size() > 2) {
                y = Integer.valueOf(keywords.get(2)).intValue();
            }
        } catch (Exception e) {
        }
        keywords.clear();
        if (timezoneId != null && timezoneId.length() > 0) {
            t.switchTimezone(timezoneId);
        }
        t.set(d, m - 1, y);
        return t;
    }

    public static Time getToday(String timeZoneId) {
        Time now = new Time();
        now.setToNow();
        if (timeZoneId != null) {
            now.switchTimezone(timeZoneId);
        }
        now.hour = 0;
        now.minute = 0;
        now.second = 0;
        return now;
    }

    public static double dayDiff(Time from, Time to) {
        long tTo = to.toMillis(false) / 1000;
        long tFrom = from.toMillis(false) / 1000;
        double daysBetween = Math.abs((tFrom - tTo) / ONE_DAY_SEC);
        return daysBetween;
    }

    public static String getDateString(CharSequence[] MonsString, Calendar c) {
        int month = c.get(2);
        int day = c.get(5);
        String str = MonsString[month].toString().toUpperCase() + " " + day;
        if (Locale.getDefault().getLanguage().equalsIgnoreCase(Locale.CHINA.getLanguage()) || Locale.getDefault().getLanguage().equalsIgnoreCase(Locale.CHINESE.getLanguage()) || Locale.getDefault().getLanguage().equalsIgnoreCase(Locale.JAPAN.getLanguage()) || Locale.getDefault().getLanguage().equalsIgnoreCase(Locale.JAPANESE.getLanguage())) {
            String date = MonsString[month].toString().toUpperCase() + "" + day + "日";
            return date;
        }
        String date2 = MonsString[month].toString().toUpperCase() + " " + day;
        return date2;
    }
}
