package com.htc.clock.util.time;

import android.content.Context;
import android.os.Handler;
import android.provider.Settings;
import android.text.TextUtils;
import com.htc.clock.util.MyLog;
import com.htc.clock.util.location.LocationCtrl;
import com.htc.clock.util.location.LocationListener;
import com.htc.clock.util.location.LocationUtil;
import com.htc.clock.util.time.TimeCtrl;
import java.util.Calendar;
import java.util.TimeZone;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class CurLocationTimeCtrl extends TimeCtrl implements LocationListener {
    private LocationCtrl mLocCtrl;
    private boolean mLocCtrlNeedRegister = false;
    private boolean mCheckAutoTimeAlready = false;
    private boolean m_bAutoSyn = true;

    @Override // com.htc.clock.util.time.TimeCtrl
    public void init(Context context, TimeCtrl.OnTimeListener listener, int type, Handler handler, String timezone) {
        MyLog.i("CurLocationTimeCtrl~ init");
        int type2 = type | 12;
        if (this.mLocCtrl == null) {
            this.mLocCtrl = new LocationCtrl(context);
            this.mLocCtrl.addCurLoc();
            this.mLocCtrl.setLocKey(LocationCtrl.CURRENT_LOCATION_KEY);
            this.mLocCtrlNeedRegister = true;
        }
        super.init(context, listener, type2, handler, (String) null);
    }

    public void init(Context context, TimeCtrl.OnTimeListener listener, LocationCtrl locCtrl, int type, Handler handler) {
        super.init(context, listener, type | 12, handler, (String) null);
        this.mLocCtrl = locCtrl;
    }

    @Override // com.htc.clock.util.time.TimeCtrl
    public void uninit() {
        MyLog.i("CurLocationTimeCtrl~ uninit");
        if (this.mLocCtrl != null && this.mLocCtrlNeedRegister) {
            this.mLocCtrl.unRegister();
        }
        this.mLocCtrl = null;
        super.uninit();
    }

    @Override // com.htc.clock.util.location.LocationListener
    public boolean isResume() {
        return false;
    }

    @Override // com.htc.clock.util.location.LocationListener
    public void onCityUpdate(LocationCtrl weatherCtrl) {
        MyLog.i("CurLocationTimeCtrl~ onCityUpdate");
        super.onTimeZoneChanged();
    }

    @Override // com.htc.clock.util.location.LocationListener
    public void onTempUnitChange(LocationCtrl weatherCtrl) {
    }

    @Override // com.htc.clock.util.location.LocationListener
    public void onWeatherUpdate(LocationCtrl weatherCtrl) {
    }

    protected void onTimeZoneChange() {
        if (this.m_bAutoSyn) {
            super.onTimeZoneChanged();
        }
    }

    @Override // com.htc.clock.util.time.TimeCtrl
    protected void handlerInit() {
        MyLog.i("CurLocationTimeCtrl~ handlerInit");
        if (this.mLocCtrl != null && this.mLocCtrlNeedRegister) {
            this.mLocCtrl.register(this.mHandler, this);
        }
        super.handlerInit();
    }

    @Override // com.htc.clock.util.time.TimeCtrl
    protected void handlerSettingChanged() {
        boolean firstCheck = !this.mCheckAutoTimeAlready;
        boolean changed = checkSystemAutoSynTimezone();
        if (changed || firstCheck) {
            super.handlerTimeZoneChanged();
        }
        super.handlerSettingChanged();
    }

    @Override // com.htc.clock.util.time.TimeCtrl
    public Calendar getCalendar() {
        TimeZone tz;
        if (this.m_bAutoSyn) {
            if (this.mCalendar == null) {
                MyLog.e("TimeCtrl~ getCalendar null");
                this.mCalendar = Calendar.getInstance();
            } else {
                this.mCalendar.setTimeInMillis(System.currentTimeMillis());
            }
            return this.mCalendar;
        }
        String timeZoneStr = null;
        if (this.mLocCtrl != null) {
            timeZoneStr = this.mLocCtrl.getTimeZoneId();
        }
        if (!TextUtils.isEmpty(timeZoneStr)) {
            tz = TimeZone.getTimeZone(timeZoneStr);
        } else {
            tz = TimeZone.getDefault();
        }
        return Calendar.getInstance(tz);
    }

    public boolean checkCurTimezoneProblem() {
        TimeZone locTz;
        if (!this.m_bAutoSyn) {
            return false;
        }
        if (this.mLocCtrl == null) {
            return true;
        }
        String timeZoneStr = this.mLocCtrl.getTimeZoneId();
        MyLog.i("checkCurTimezoneProblem~ timZoneStr = " + timeZoneStr);
        if (!TextUtils.isEmpty(timeZoneStr)) {
            locTz = TimeZone.getTimeZone(timeZoneStr);
        } else {
            locTz = TimeZone.getDefault();
        }
        MyLog.i("checkCurTimezoneProblem~ locTz = " + locTz);
        TimeZone SysTz = getCalendar().getTimeZone();
        String systz = getCalendar().getTimeZone().getID();
        MyLog.i("checkCurTimezoneProblem~ SysTz = " + SysTz);
        MyLog.i("checkCurTimezoneProblem~ systzID = " + systz);
        if (!SysTz.hasSameRules(locTz) && !systz.equals(timeZoneStr)) {
            MyLog.i("checkCurTimezoneProblem~ timezone not the same~");
            return true;
        }
        return false;
    }

    public boolean checkSystemAutoSynTimezone() {
        boolean ret = false;
        boolean isAuto = isTimeAutoState();
        if (this.m_bAutoSyn != isAuto) {
            ret = true;
            this.m_bAutoSyn = isAuto;
        }
        MyLog.i("checkSystemAutoSynTimezone~ m_bAutoSyn:" + this.m_bAutoSyn);
        this.mCheckAutoTimeAlready = true;
        return ret;
    }

    public boolean isTimezoneAutoSyn() {
        return this.m_bAutoSyn;
    }

    public boolean isTimeAutoState() {
        try {
            return Settings.System.getInt(this.mContext.getContentResolver(), "auto_time") > 0;
        } catch (Settings.SettingNotFoundException e) {
            return true;
        }
    }

    @Override // com.htc.clock.util.time.TimeCtrl
    public String getTimeZoneCity() {
        LocationCtrl locCtrl = this.mLocCtrl;
        if (locCtrl == null) {
            MyLog.i("CurLocationTimeCtrl~ getTimeZoneCity~ Ctrl is not init");
            return null;
        }
        if (!this.mCheckAutoTimeAlready) {
            MyLog.i("CurLocationTimeCtrl~ getTimeZoneCity~ setting not init");
            return null;
        }
        MyLog.i("CurLocationTimeCtrl~ getTimeZoneCity~");
        if (this.m_bAutoSyn) {
            if (checkCurTimezoneProblem()) {
                return LocationUtil.sDefaultLocName;
            }
            return locCtrl.getLocName();
        }
        return locCtrl.getLocName();
    }

    @Override // com.htc.clock.util.location.LocationListener
    public boolean isChinaLocationService() {
        return false;
    }

    @Override // com.htc.clock.util.location.LocationListener
    public boolean isHelpTurnOnLoc() {
        return false;
    }
}
