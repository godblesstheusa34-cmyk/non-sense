package com.htc.clock.util.social;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import com.htc.clock.util.MyLog;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class SocialNetworkCtrl {
    public static final String ACTION_PLUGIN_COMPOSE_MESSAGE = "com.htc.friendstream.intent.action.COMPOSE_MESSAGE";
    public static final String ACTION_UPDATE1 = "com.htc.friendstream.intent.action.COMPOSE_MESSAGE_RESPONSE";
    public static final String ACTION_UPDATE2 = "com.htc.friendstream.intent.action.SYNC_STREAM_RESPONSE";
    public static final String ACTION_UPDATE3 = "com.htc.socialnetwork.facebook.UPDATE_COMMENT_COUNT_END";
    public static final String ACTION_UPDATE4 = "android.accounts.LOGIN_ACCOUNTS_CHANGED";
    public static final String FEATURE_NAME_FRIENDSTREAM_ADAPTER = "AddFriendStreamAdapter";
    public static final String METADATA_PLUGIN_ACCOUNT_TYPE = "com.htc.friendstream.intent.metadata.ACCOUNT_TYPE";
    public static final int WHAT_ON_UPDATE = 1;
    private Handler mBGHandler;
    private Looper mBGLooper;
    private Handler mCallbackHandler;
    Context mContext;
    private OnUpdateListener mListener;
    private BroadcastReceiver mUpdateReceiver;
    State mState = State.STOP;
    private boolean mIsDestroyed = false;
    private boolean mIsLoggedin = false;
    private Runnable mUpdateRunnable = new Runnable() { // from class: com.htc.clock.util.social.SocialNetworkCtrl.1
        @Override // java.lang.Runnable
        public void run() {
            OnUpdateListener listener = SocialNetworkCtrl.this.mListener;
            if (listener != null) {
                listener.onUpdate(SocialNetworkCtrl.this.getLastSocialData());
            }
        }
    };

    public interface OnUpdateListener {
        void onUpdate(SocialData socialData);
    }

    public enum State {
        STOP,
        START
    }

    private class BGHandler extends Handler {
        BGHandler(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            SocialNetworkCtrl.this.update(SocialNetworkCtrl.this.mContext);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void update(Context context) {
        if (!this.mIsDestroyed && context != null) {
            this.mIsLoggedin = SocialNetworkUtil.isLoggedIn(context);
            SocialNetworkResolver.getLastMessage(context, true);
            this.mCallbackHandler.removeCallbacks(this.mUpdateRunnable);
            this.mCallbackHandler.postDelayed(this.mUpdateRunnable, 500L);
        }
    }

    public boolean updateIsLoggedIn() {
        boolean old = this.mIsLoggedin;
        this.mIsLoggedin = SocialNetworkUtil.isLoggedIn(this.mContext);
        return old != this.mIsLoggedin;
    }

    public SocialData getLastSocialData() {
        return SocialNetworkResolver.getLastMessage(this.mContext, false);
    }

    public boolean isLoggedIn() {
        return this.mIsLoggedin;
    }

    public void init(Context context, OnUpdateListener listener, Handler callbackHanler, Handler bgHandler) {
        synchronized (this) {
            if (this.mIsDestroyed) {
                MyLog.e("SocialNetworkCtrl init after destroyed");
                return;
            }
            this.mState = State.START;
            this.mContext = context;
            this.mCallbackHandler = callbackHanler;
            this.mListener = listener;
            this.mIsLoggedin = SocialNetworkUtil.isLoggedIn(context);
            registerReceiverLocked();
            initBGHandlerLocked(bgHandler);
            removeBGMsg(1);
            sendBGMsg(1, 500L);
        }
    }

    public void uninit() {
        synchronized (this) {
            this.mIsDestroyed = true;
            this.mState = State.STOP;
            unregisterReceiverLocked();
            removeBGMsg(1);
            if (this.mBGLooper != null) {
                this.mBGLooper.quit();
                this.mBGLooper = null;
            }
            this.mBGHandler = null;
            this.mListener = null;
        }
    }

    private void initBGHandlerLocked(Handler bgHandler) {
        if (this.mBGHandler == null) {
            Looper looper = null;
            if (bgHandler != null) {
                looper = bgHandler.getLooper();
            }
            if (looper == null) {
                HandlerThread thread = new HandlerThread("SocialNetworkCtrl");
                thread.start();
                this.mBGLooper = thread.getLooper();
                looper = this.mBGLooper;
            }
            this.mBGHandler = new BGHandler(looper);
        }
    }

    private void registerReceiverLocked() {
        synchronized (this) {
            if (this.mUpdateReceiver == null) {
                this.mUpdateReceiver = new BroadcastReceiver() { // from class: com.htc.clock.util.social.SocialNetworkCtrl.2
                    @Override // android.content.BroadcastReceiver
                    public void onReceive(Context context, Intent intent) {
                        MyLog.i("SocialNetworkCtrl registerReceiverLocked~ action:" + intent.getAction());
                        SocialNetworkCtrl.this.removeBGMsg(1);
                        SocialNetworkCtrl.this.sendBGMsg(1, 5000L);
                    }
                };
                IntentFilter filter = new IntentFilter();
                filter.addAction(ACTION_UPDATE1);
                filter.addAction(ACTION_UPDATE2);
                filter.addAction(ACTION_UPDATE3);
                filter.addAction(ACTION_UPDATE4);
                this.mContext.registerReceiver(this.mUpdateReceiver, filter);
            }
        }
    }

    private void unregisterReceiverLocked() {
        synchronized (this) {
            if (this.mUpdateReceiver != null) {
                this.mContext.unregisterReceiver(this.mUpdateReceiver);
                this.mUpdateReceiver = null;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void removeBGMsg(int what) {
        Handler handler = this.mBGHandler;
        if (handler != null) {
            handler.removeMessages(what);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void sendBGMsg(int what, long delay) {
        Handler handler = this.mBGHandler;
        if (handler != null) {
            if (delay > 0) {
                handler.sendEmptyMessageDelayed(what, delay);
            } else {
                handler.sendEmptyMessage(what);
            }
        }
    }

    public State getState() {
        State state;
        synchronized (this) {
            state = this.mState;
        }
        return state;
    }
}
