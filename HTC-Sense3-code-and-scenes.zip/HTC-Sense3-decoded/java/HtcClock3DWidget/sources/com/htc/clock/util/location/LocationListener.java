package com.htc.clock.util.location;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public interface LocationListener {
    boolean isChinaLocationService();

    boolean isHelpTurnOnLoc();

    boolean isResume();

    void onCityUpdate(LocationCtrl locationCtrl);

    void onTempUnitChange(LocationCtrl locationCtrl);

    void onWeatherUpdate(LocationCtrl locationCtrl);
}
