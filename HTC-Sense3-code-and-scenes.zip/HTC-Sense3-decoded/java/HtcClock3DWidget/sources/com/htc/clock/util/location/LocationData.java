package com.htc.clock.util.location;

import android.content.Context;
import android.provider.Settings;
import android.text.format.Time;
import com.htc.clock.util.MyLog;
import com.htc.clock.util.MyTimeUtil;
import com.htc.clock.util.MyUtil;
import com.htc.clock.util.location.LocationCtrl;
import com.htc.util.weather.WSPData;
import com.htc.util.weather.WSPUtility;
import com.htc.util.weather.WeatherLocation;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class LocationData {
    private Context mContext;
    private String mFSTDateNow;
    private WeatherForecast mFSTNow;
    private ArrayList<WeatherForecast> mForecastList;
    public boolean mIsCurLocation;
    private long mLastUpdateTime;
    public LocationCtrl.LocationState mState;
    private WSPData mWSPData;
    private WeatherLocation mWeatherLocation;

    public LocationData(Context context) {
        this.mState = LocationCtrl.LocationState.NO_DATA;
        this.mForecastList = new ArrayList<>();
        this.mIsCurLocation = false;
        this.mLastUpdateTime = -1L;
        this.mContext = context;
    }

    public LocationData(Context context, String locCode, String locName, String locTimeZoneId) {
        this.mState = LocationCtrl.LocationState.NO_DATA;
        this.mForecastList = new ArrayList<>();
        this.mIsCurLocation = false;
        this.mLastUpdateTime = -1L;
        this.mContext = context;
        this.mState = LocationCtrl.LocationState.ONLY_LOC;
        this.mWeatherLocation = new WeatherLocation();
        this.mWeatherLocation.setCode(locCode);
        this.mWeatherLocation.setName(locName);
        this.mWeatherLocation.setTimezoneId(locTimeZoneId);
    }

    public LocationData(Context context, WeatherLocation weatherLocation) {
        this.mState = LocationCtrl.LocationState.NO_DATA;
        this.mForecastList = new ArrayList<>();
        this.mIsCurLocation = false;
        this.mLastUpdateTime = -1L;
        this.mContext = context;
        this.mWeatherLocation = weatherLocation;
        this.mState = LocationCtrl.LocationState.ONLY_LOC;
    }

    public LocationData(Context context, WeatherLocation weatherLocation, LocationCtrl.LocationState locState) {
        this.mState = LocationCtrl.LocationState.NO_DATA;
        this.mForecastList = new ArrayList<>();
        this.mIsCurLocation = false;
        this.mLastUpdateTime = -1L;
        this.mContext = context;
        this.mWeatherLocation = weatherLocation;
        this.mState = locState;
    }

    public void reset() {
        this.mFSTDateNow = null;
        this.mFSTNow = null;
        this.mForecastList.clear();
        if (this.mState == LocationCtrl.LocationState.OK) {
            this.mState = LocationCtrl.LocationState.ONLY_LOC;
        }
    }

    public void setUpLocInfo(WSPData wspData) {
        setWeatherLoc(wspData);
    }

    public boolean setupByWSPData(WSPData wspData, boolean bClearCache) {
        boolean bCityChanged = false;
        if (bClearCache) {
            reset();
            if (this.mIsCurLocation) {
                this.mState = LocationCtrl.LocationState.NO_DATA;
                this.mWeatherLocation.setState("");
                this.mWeatherLocation.setCode("");
                this.mWeatherLocation.setCountry("");
                this.mWeatherLocation.setLatitude("");
                this.mWeatherLocation.setLongitude("");
                this.mWeatherLocation.setTimezoneId("");
                this.mWeatherLocation.setName("");
                this.mWeatherLocation.setTimezoneId((String) null);
                bCityChanged = true;
            } else {
                this.mState = LocationCtrl.LocationState.ONLY_LOC;
            }
        }
        if (wspData == null) {
            return bCityChanged;
        }
        MyLog.i("setupByWSPData~ wspData:" + wspData.toDebugInfo());
        reset();
        this.mWSPData = wspData;
        if (this.mIsCurLocation) {
            bCityChanged = setWeatherLoc(wspData);
        }
        long updateTime = wspData.getLastUpdate();
        this.mLastUpdateTime = updateTime;
        if (wspData.hasWeatherData()) {
            this.mState = LocationCtrl.LocationState.OK;
            ArrayList<String> dateString = wspData.getFstDate();
            ArrayList<String> conditionString = wspData.getFstConditionId();
            ArrayList<String> tempHCString = wspData.getFstHighTempC();
            ArrayList<String> tempHFString = wspData.getFstHighTempF();
            ArrayList<String> tempLCString = wspData.getFstLowTempC();
            ArrayList<String> tempLFString = wspData.getFstLowTempF();
            int i = 0;
            Iterator i$ = dateString.iterator();
            while (i$.hasNext()) {
                String date = i$.next();
                WeatherForecast forecast = new WeatherForecast();
                forecast.setDate(date);
                String tempF = tempHFString.get(i);
                String tempC = tempHCString.get(i);
                forecast.setHigh(tempF, tempC);
                String tempF2 = tempLFString.get(i);
                String tempC2 = tempLCString.get(i);
                forecast.setLow(tempF2, tempC2);
                if (i == 0) {
                    this.mFSTDateNow = date;
                    this.mFSTNow = forecast;
                    MyLog.i("setupByWSPData~ mFSTDateNow:" + this.mFSTDateNow);
                    forecast.setCondition(wspData.getCurConditionId());
                    forecast.setCur(wspData.getCurTempF(), wspData.getCurTempC());
                } else {
                    forecast.setCondition(conditionString.get(i));
                    forecast.setCurByForecast();
                }
                addForecast(forecast);
                i++;
            }
            updateForecastDateNow();
        } else {
            reset();
        }
        return bCityChanged;
    }

    public void addForecast(WeatherForecast forecast) {
        this.mForecastList.add(forecast);
    }

    public boolean updateForecastDateNow() {
        boolean bUpdate = false;
        String forecastDay = null;
        WeatherForecast forecastNow = null;
        if (this.mState == LocationCtrl.LocationState.OK && this.mForecastList != null && this.mForecastList.size() > 0) {
            if (isOverdue()) {
                String timezoneId = this.mWeatherLocation.getTimezoneId();
                Time now = MyTimeUtil.getToday(timezoneId);
                Time forecastDate = new Time();
                double min = -1.0d;
                Iterator i$ = this.mForecastList.iterator();
                while (i$.hasNext()) {
                    WeatherForecast forecast = i$.next();
                    String date = forecast.getDate();
                    forecastDate = MyTimeUtil.setTimeObject(forecastDate, date, timezoneId);
                    double difDay = MyTimeUtil.dayDiff(now, forecastDate);
                    if (difDay < min || min == -1.0d) {
                        min = difDay;
                        forecastDay = date;
                        forecastNow = forecast;
                    }
                }
            } else {
                WeatherForecast forecastNow2 = this.mForecastList.get(0);
                forecastNow = forecastNow2;
                forecastDay = forecastNow.getDate();
            }
            if (forecastDay != null) {
                if (!forecastDay.equals(this.mFSTDateNow)) {
                    this.mFSTDateNow = forecastDay;
                    this.mFSTNow = forecastNow;
                    bUpdate = true;
                }
            } else {
                MyLog.e("updateForecastDateNow~ forecastDay is null");
            }
        }
        MyLog.i("updateForecastDateNow~ mFSTDateNow:" + this.mFSTDateNow);
        return bUpdate;
    }

    public boolean isOverdue() {
        long interval = 10800000;
        boolean bAutoSync = WSPUtility.isSyncAutomatically(this.mContext);
        if (bAutoSync) {
            interval = MyUtil.safe_parseInt(Settings.System.getString(this.mContext.getContentResolver(), "com.htc.sync.provider.weather.setting.autosyncfrequency"));
        }
        long current_time = System.currentTimeMillis();
        return current_time < this.mLastUpdateTime || current_time - this.mLastUpdateTime >= interval;
    }

    public WeatherForecast getForecast() {
        return this.mFSTNow;
    }

    private boolean setWeatherLoc(WSPData wspData) {
        this.mState = LocationCtrl.LocationState.ONLY_LOC;
        String oldFullName = LocationCtrl.getWeatheApCityName(this.mWeatherLocation);
        this.mWeatherLocation.setState(wspData.getCurLocState());
        this.mWeatherLocation.setName(wspData.getCurLocName());
        this.mWeatherLocation.setCountry(wspData.getCurLocCountry());
        this.mWeatherLocation.setLatitude(wspData.getCurLocLat());
        this.mWeatherLocation.setLongitude(wspData.getCurLocLng());
        this.mWeatherLocation.setTimezoneId(wspData.getCurLocTimezoneId());
        String updatedFullName = LocationCtrl.getWeatheApCityName(this.mWeatherLocation);
        return !oldFullName.equals(updatedFullName);
    }

    public String getLocName() {
        String locName = this.mWeatherLocation.getName();
        if (this.mIsCurLocation) {
            if (locName == null || locName.length() <= 0) {
                return LocationUtil.sDefaultLocName;
            }
            return locName;
        }
        return locName;
    }

    public String getLocTimeZoneId() {
        String timezoneId = this.mWeatherLocation.getTimezoneId();
        return timezoneId;
    }

    public String getLocCode() {
        return this.mWeatherLocation.getCode();
    }

    public WeatherLocation getWeatherLocation() {
        return this.mWeatherLocation;
    }

    public long getLastUpdateTime() {
        return this.mLastUpdateTime;
    }
}
