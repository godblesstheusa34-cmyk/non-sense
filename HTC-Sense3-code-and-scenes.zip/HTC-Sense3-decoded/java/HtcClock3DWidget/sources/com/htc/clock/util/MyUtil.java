package com.htc.clock.util;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import com.htc.clock3dwidget.util.Constants;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class MyUtil {
    public static final String TAB_WORLDCLOCK = "1";
    public static final String WORLDCLOCK_ACTION = "worldclock_action";
    public static final String WORLDCLOCK_EXTRA_CITY_CODE = "worldclock_city_code";

    public static void launchWorldClockAp(Context context, String code) {
        Intent intent = new Intent("android.intent.action.MAIN");
        intent.addFlags(268435456);
        intent.addFlags(67108864);
        intent.putExtra(WORLDCLOCK_ACTION, TAB_WORLDCLOCK);
        intent.putExtra(WORLDCLOCK_EXTRA_CITY_CODE, code);
        intent.setClassName(Constants.APP_WORLD_CLOCK, "com.htc.android.worldclock.WorldClockTabControl");
        context.startActivity(intent);
    }

    public static int safe_parseInt(String intStr) {
        try {
            int iRet = Integer.parseInt(intStr);
            return iRet;
        } catch (Exception e) {
            MyLog.i("safe_parseInt~ parse error e:" + e.getMessage());
            return 0;
        }
    }

    public static boolean compareString(String a, String b) {
        if (a != null) {
            return a.equals(b);
        }
        if (b == null) {
            return true;
        }
        return false;
    }

    public static void sendMessage(Handler handler, int what) {
        sendMessage(handler, what, 0L);
    }

    public static void sendMessage(Handler handler, int what, long delay) {
        if (handler == null) {
            return;
        }
        if (delay > 0) {
            handler.sendEmptyMessageDelayed(what, delay);
        } else {
            handler.sendEmptyMessage(what);
        }
    }

    public static void sendMessage(Handler handler, Message msg) {
        sendMessage(handler, msg, 0L);
    }

    public static void sendMessage(Handler handler, Message msg, long delay) {
        if (handler == null) {
            return;
        }
        if (delay > 0) {
            handler.sendMessageDelayed(msg, delay);
        } else {
            handler.sendMessage(msg);
        }
    }

    public static void removeMessage(Handler handler, int what) {
        if (handler != null) {
            handler.removeMessages(what);
        }
    }
}
