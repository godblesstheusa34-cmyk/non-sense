package com.htc.clock.util.location;

import com.htc.clock.util.MyLog;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class WeatherForecast {
    public static final int NO_TEMPERATUR = -500;
    private String mCondition;
    private String mDate;
    private int mHighF = NO_TEMPERATUR;
    private int mHighC = NO_TEMPERATUR;
    private int mLowF = NO_TEMPERATUR;
    private int mLowC = NO_TEMPERATUR;
    private int mCurF = NO_TEMPERATUR;
    private int mCurC = NO_TEMPERATUR;

    public enum UNIT {
        _F,
        _C
    }

    private int getTempFromString(String tempStr) {
        if (tempStr == null) {
            return NO_TEMPERATUR;
        }
        try {
            int temp = Integer.parseInt(tempStr);
            return temp;
        } catch (Exception e) {
            MyLog.w("getTempFromString~ exception" + e.getMessage());
            return NO_TEMPERATUR;
        }
    }

    public void setHigh(String f, String c) {
        int intF = getTempFromString(f);
        int intC = getTempFromString(c);
        setHigh(intF, intC);
    }

    public void setHigh(int f, int c) {
        this.mHighF = f;
        this.mHighC = c;
    }

    public int getHigh(UNIT unit) {
        return unit == UNIT._C ? this.mHighC : this.mHighF;
    }

    public void setLow(String f, String c) {
        int intF = getTempFromString(f);
        int intC = getTempFromString(c);
        setLow(intF, intC);
    }

    public void setLow(int f, int c) {
        this.mLowF = f;
        this.mLowC = c;
    }

    public int getLow(UNIT unit) {
        return unit == UNIT._C ? this.mLowC : this.mLowF;
    }

    public void setCurByForecast() {
        this.mCurF = (this.mLowF + this.mHighF) / 2;
        this.mCurC = (this.mLowC + this.mHighC) / 2;
    }

    public void setCur(int f, int c) {
        this.mCurF = f;
        this.mCurC = c;
        if (this.mLowF > f) {
            this.mLowF = f;
        }
        if (this.mHighF < f) {
            this.mHighF = f;
        }
        if (this.mLowC > c) {
            this.mLowC = c;
        }
        if (this.mHighC < c) {
            this.mHighC = c;
        }
    }

    public int getCur(UNIT unit) {
        return unit == UNIT._C ? this.mCurC : this.mCurF;
    }

    public void setDate(String date) {
        this.mDate = date;
    }

    public String getDate() {
        return this.mDate;
    }

    public void setCondition(String condition) {
        this.mCondition = condition;
    }

    public String getCondition() {
        return this.mCondition;
    }

    private int calculateTemperature(int val) {
        return Math.round(((val - 32.0f) * 5.0f) / 9.0f);
    }
}
