package com.htc.clock.util.social;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;
import com.htc.clock.util.MyLog;
import com.htc.opensense.plugin.Plugin;
import com.htc.opensense.plugin.PluginRegistryHelper;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/HtcClock3DWidget.dex */
public class SocialNetworkUtil {
    static String ACTION_PLUGIN_COMPOSE_MESSAGE = SocialNetworkCtrl.ACTION_PLUGIN_COMPOSE_MESSAGE;
    static String METADATA_PLUGIN_ACCOUNT_TYPE = SocialNetworkCtrl.METADATA_PLUGIN_ACCOUNT_TYPE;
    static String FEATURE_NAME_FRIENDSTREAM_ADAPTER = SocialNetworkCtrl.FEATURE_NAME_FRIENDSTREAM_ADAPTER;
    static String PKG_FRIENDSTREAM_AP = "com.htc.friendstream";
    static String CLASS_FRIENDSTREAM_AP = "com.htc.friendstream.FriendStream";
    static String CLASS_FRIENDSTREAM_SETTINGS = "com.htc.friendstream.SettingsActivity";
    static String EXTRA_SETTINGS_PAGE = "com.htc.friendstream.intent.EXTRA_SETTINGS_PAGE";
    static String PREF_SCREEN_KEY_ACCOUNTS_AND_SYNC = "prefscreen_accounts";
    static String CLASS_TABLET_FRIENDSTREAM_AP = "com.htc.friendstream.SwitchMultipleActivityMain";
    static String CLASS_FRIENDSTREAM_ENTRANCE = "com.htc.friendstream.FriendStream";
    static int API_level = Build.VERSION.SDK_INT;

    public static boolean isLoggedIn(Context context) {
        Account[] as;
        Plugin[] plugins = PluginRegistryHelper.getPlugins(context, FEATURE_NAME_FRIENDSTREAM_ADAPTER);
        AccountManager am = AccountManager.get(context);
        boolean isLoggedIn = false;
        int len$ = plugins.length;
        int i$ = 0;
        while (true) {
            if (i$ >= len$) {
                break;
            }
            Plugin plugin = plugins[i$];
            String type = null;
            if (plugin != null) {
                if (plugin.pluginMeta != null) {
                    type = plugin.pluginMeta;
                } else if (plugin.component_name != null) {
                    type = plugin.component_name.getPackageName();
                }
                MyLog.i("SocialNetworkUtil type:" + type);
                if (!TextUtils.isEmpty(type) && (as = am.getAccountsByType(type)) != null && as.length > 0 && as[0] != null && !TextUtils.isEmpty(as[0].name)) {
                    MyLog.i("SocialNetworkUtil as[0].name:" + as[0].name);
                    isLoggedIn = true;
                    break;
                }
            }
            i$++;
        }
        MyLog.i("SocialNetworkUtil isloggedin:" + isLoggedIn);
        return isLoggedIn;
    }

    public static void launchLoginPage(Context hostActivity) {
        if (API_level >= 11) {
            CLASS_FRIENDSTREAM_SETTINGS = "com.htc.friendstream.settings.AddAccountActivity";
        }
        Intent intent = new Intent().setClassName(PKG_FRIENDSTREAM_AP, CLASS_FRIENDSTREAM_SETTINGS).setFlags(268435456).putExtra(EXTRA_SETTINGS_PAGE, PREF_SCREEN_KEY_ACCOUNTS_AND_SYNC);
        hostActivity.startActivity(intent);
    }

    public static void launchMainPage(Context hostActivity) {
        Intent intent = new Intent();
        intent.setClassName(PKG_FRIENDSTREAM_AP, CLASS_FRIENDSTREAM_AP);
        hostActivity.startActivity(intent);
    }
}
