package com.android.common;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class Search {
    public static final String SOURCE = "source";

    private Search() {
    }
}
