package com.android.common;

import android.content.SharedPreferences;
import android.net.http.AndroidHttpClient;
import android.text.format.Time;
import java.util.Iterator;
import java.util.TreeSet;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class OperationScheduler {
    private static final String PREFIX = "OperationScheduler_";
    private final SharedPreferences mStorage;

    public static class Options {
        public long backoffFixedMillis = 0;
        public long backoffIncrementalMillis = 5000;
        public long maxMoratoriumMillis = 86400000;
        public long minTriggerMillis = 0;
        public long periodicIntervalMillis = 0;

        public String toString() {
            return String.format("OperationScheduler.Options[backoff=%.1f+%.1f max=%.1f min=%.1f period=%.1f]", Double.valueOf(this.backoffFixedMillis / 1000.0d), Double.valueOf(this.backoffIncrementalMillis / 1000.0d), Double.valueOf(this.maxMoratoriumMillis / 1000.0d), Double.valueOf(this.minTriggerMillis / 1000.0d), Double.valueOf(this.periodicIntervalMillis / 1000.0d));
        }
    }

    public OperationScheduler(SharedPreferences storage) {
        this.mStorage = storage;
    }

    public static Options parseOptions(String spec, Options options) throws IllegalArgumentException {
        String[] arr$ = spec.split(" +");
        for (String param : arr$) {
            if (param.length() != 0) {
                if (param.startsWith("backoff=")) {
                    int plus = param.indexOf(43, 8);
                    if (plus < 0) {
                        options.backoffFixedMillis = parseSeconds(param.substring(8));
                    } else {
                        if (plus > 8) {
                            options.backoffFixedMillis = parseSeconds(param.substring(8, plus));
                        }
                        options.backoffIncrementalMillis = parseSeconds(param.substring(plus + 1));
                    }
                } else if (param.startsWith("max=")) {
                    options.maxMoratoriumMillis = parseSeconds(param.substring(4));
                } else if (param.startsWith("min=")) {
                    options.minTriggerMillis = parseSeconds(param.substring(4));
                } else if (param.startsWith("period=")) {
                    options.periodicIntervalMillis = parseSeconds(param.substring(7));
                } else {
                    options.periodicIntervalMillis = parseSeconds(param);
                }
            }
        }
        return options;
    }

    private static long parseSeconds(String param) throws NumberFormatException {
        return (long) (Float.parseFloat(param) * 1000.0f);
    }

    public long getNextTimeMillis(Options options) {
        boolean enabledState = this.mStorage.getBoolean("OperationScheduler_enabledState", true);
        if (!enabledState) {
            return Long.MAX_VALUE;
        }
        boolean permanentError = this.mStorage.getBoolean("OperationScheduler_permanentError", false);
        if (permanentError) {
            return Long.MAX_VALUE;
        }
        int errorCount = this.mStorage.getInt("OperationScheduler_errorCount", 0);
        long now = currentTimeMillis();
        long lastSuccessTimeMillis = getTimeBefore("OperationScheduler_lastSuccessTimeMillis", now);
        long lastErrorTimeMillis = getTimeBefore("OperationScheduler_lastErrorTimeMillis", now);
        long triggerTimeMillis = this.mStorage.getLong("OperationScheduler_triggerTimeMillis", Long.MAX_VALUE);
        long moratoriumSetMillis = getTimeBefore("OperationScheduler_moratoriumSetTimeMillis", now);
        long moratoriumTimeMillis = getTimeBefore("OperationScheduler_moratoriumTimeMillis", options.maxMoratoriumMillis + moratoriumSetMillis);
        long time = triggerTimeMillis;
        if (options.periodicIntervalMillis > 0) {
            time = Math.min(time, options.periodicIntervalMillis + lastSuccessTimeMillis);
        }
        long time2 = Math.max(Math.max(time, moratoriumTimeMillis), options.minTriggerMillis + lastSuccessTimeMillis);
        if (errorCount > 0) {
            time2 = Math.max(time2, options.backoffFixedMillis + lastErrorTimeMillis + (options.backoffIncrementalMillis * errorCount));
        }
        return time2;
    }

    public long getLastSuccessTimeMillis() {
        return this.mStorage.getLong("OperationScheduler_lastSuccessTimeMillis", 0L);
    }

    public long getLastAttemptTimeMillis() {
        return Math.max(this.mStorage.getLong("OperationScheduler_lastSuccessTimeMillis", 0L), this.mStorage.getLong("OperationScheduler_lastErrorTimeMillis", 0L));
    }

    private long getTimeBefore(String name, long max) {
        long time = this.mStorage.getLong(name, 0L);
        if (time > max) {
            SharedPreferencesCompat.apply(this.mStorage.edit().putLong(name, max));
            return max;
        }
        return time;
    }

    public void setTriggerTimeMillis(long millis) {
        SharedPreferencesCompat.apply(this.mStorage.edit().putLong("OperationScheduler_triggerTimeMillis", millis));
    }

    public void setMoratoriumTimeMillis(long millis) {
        SharedPreferencesCompat.apply(this.mStorage.edit().putLong("OperationScheduler_moratoriumTimeMillis", millis).putLong("OperationScheduler_moratoriumSetTimeMillis", currentTimeMillis()));
    }

    public boolean setMoratoriumTimeHttp(String retryAfter) {
        try {
            long ms = Long.valueOf(retryAfter).longValue() * 1000;
            setMoratoriumTimeMillis(currentTimeMillis() + ms);
            return true;
        } catch (NumberFormatException e) {
            try {
                setMoratoriumTimeMillis(AndroidHttpClient.parseDate(retryAfter));
                return true;
            } catch (IllegalArgumentException e2) {
                return false;
            }
        }
    }

    public void setEnabledState(boolean enabled) {
        SharedPreferencesCompat.apply(this.mStorage.edit().putBoolean("OperationScheduler_enabledState", enabled));
    }

    public void onSuccess() {
        resetTransientError();
        resetPermanentError();
        SharedPreferencesCompat.apply(this.mStorage.edit().remove("OperationScheduler_errorCount").remove("OperationScheduler_lastErrorTimeMillis").remove("OperationScheduler_permanentError").remove("OperationScheduler_triggerTimeMillis").putLong("OperationScheduler_lastSuccessTimeMillis", currentTimeMillis()));
    }

    public void onTransientError() {
        SharedPreferences.Editor editor = this.mStorage.edit();
        editor.putLong("OperationScheduler_lastErrorTimeMillis", currentTimeMillis());
        editor.putInt("OperationScheduler_errorCount", this.mStorage.getInt("OperationScheduler_errorCount", 0) + 1);
        SharedPreferencesCompat.apply(editor);
    }

    public void resetTransientError() {
        SharedPreferencesCompat.apply(this.mStorage.edit().remove("OperationScheduler_errorCount"));
    }

    public void onPermanentError() {
        SharedPreferencesCompat.apply(this.mStorage.edit().putBoolean("OperationScheduler_permanentError", true));
    }

    public void resetPermanentError() {
        SharedPreferencesCompat.apply(this.mStorage.edit().remove("OperationScheduler_permanentError"));
    }

    public String toString() {
        StringBuilder out = new StringBuilder("[OperationScheduler:");
        Iterator i$ = new TreeSet(this.mStorage.getAll().keySet()).iterator();
        while (i$.hasNext()) {
            String key = (String) i$.next();
            if (key.startsWith(PREFIX)) {
                if (key.endsWith("TimeMillis")) {
                    Time time = new Time();
                    time.set(this.mStorage.getLong(key, 0L));
                    out.append(" ").append(key.substring(PREFIX.length(), key.length() - 10));
                    out.append("=").append(time.format("%Y-%m-%d/%H:%M:%S"));
                } else {
                    out.append(" ").append(key.substring(PREFIX.length()));
                    out.append("=").append(this.mStorage.getAll().get(key).toString());
                }
            }
        }
        return out.append("]").toString();
    }

    protected long currentTimeMillis() {
        return System.currentTimeMillis();
    }
}
