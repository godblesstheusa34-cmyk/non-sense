package com.android.common;

import android.database.AbstractCursor;
import android.database.CursorWindow;
import com.htc.launcher.LauncherSettings;
import java.util.ArrayList;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class ArrayListCursor extends AbstractCursor {
    private String[] mColumnNames;
    private ArrayList<Object>[] mRows;

    public ArrayListCursor(String[] columnNames, ArrayList<ArrayList> rows) {
        int colCount = columnNames.length;
        boolean foundID = false;
        int i = 0;
        while (true) {
            if (i >= colCount) {
                break;
            }
            if (columnNames[i].compareToIgnoreCase(LauncherSettings.Favorites.ID) != 0) {
                i++;
            } else {
                this.mColumnNames = columnNames;
                foundID = true;
                break;
            }
        }
        if (!foundID) {
            this.mColumnNames = new String[colCount + 1];
            System.arraycopy(columnNames, 0, this.mColumnNames, 0, columnNames.length);
            this.mColumnNames[colCount] = LauncherSettings.Favorites.ID;
        }
        int rowCount = rows.size();
        this.mRows = new ArrayList[rowCount];
        for (int i2 = 0; i2 < rowCount; i2++) {
            this.mRows[i2] = rows.get(i2);
            if (!foundID) {
                this.mRows[i2].add(Integer.valueOf(i2));
            }
        }
    }

    @Override // android.database.AbstractCursor, android.database.CrossProcessCursor
    public void fillWindow(int position, CursorWindow window) {
        if (position >= 0 && position <= getCount()) {
            window.acquireReference();
            try {
                int oldpos = ((AbstractCursor) this).mPos;
                ((AbstractCursor) this).mPos = position - 1;
                window.clear();
                window.setStartPosition(position);
                int columnNum = getColumnCount();
                window.setNumColumns(columnNum);
                while (moveToNext() && window.allocRow()) {
                    int i = 0;
                    while (true) {
                        if (i >= columnNum) {
                            break;
                        }
                        Object data = this.mRows[((AbstractCursor) this).mPos].get(i);
                        if (data != null) {
                            if (data instanceof byte[]) {
                                byte[] field = (byte[]) data;
                                if (window.putBlob(field, ((AbstractCursor) this).mPos, i)) {
                                    i++;
                                } else {
                                    window.freeLastRow();
                                    break;
                                }
                            } else {
                                String field2 = data.toString();
                                if (window.putString(field2, ((AbstractCursor) this).mPos, i)) {
                                    i++;
                                } else {
                                    window.freeLastRow();
                                    break;
                                }
                            }
                        } else if (window.putNull(((AbstractCursor) this).mPos, i)) {
                            i++;
                        } else {
                            window.freeLastRow();
                            break;
                        }
                    }
                }
                ((AbstractCursor) this).mPos = oldpos;
            } catch (IllegalStateException e) {
            } finally {
                window.releaseReference();
            }
        }
    }

    @Override // android.database.AbstractCursor, android.database.Cursor
    public int getCount() {
        return this.mRows.length;
    }

    @Override // android.database.AbstractCursor, android.database.Cursor
    public String[] getColumnNames() {
        return this.mColumnNames;
    }

    @Override // android.database.AbstractCursor, android.database.Cursor
    public byte[] getBlob(int columnIndex) {
        return (byte[]) this.mRows[((AbstractCursor) this).mPos].get(columnIndex);
    }

    @Override // android.database.AbstractCursor, android.database.Cursor
    public String getString(int columnIndex) {
        Object cell = this.mRows[((AbstractCursor) this).mPos].get(columnIndex);
        if (cell == null) {
            return null;
        }
        return cell.toString();
    }

    @Override // android.database.AbstractCursor, android.database.Cursor
    public short getShort(int columnIndex) {
        Number num = (Number) this.mRows[((AbstractCursor) this).mPos].get(columnIndex);
        return num.shortValue();
    }

    @Override // android.database.AbstractCursor, android.database.Cursor
    public int getInt(int columnIndex) {
        Number num = (Number) this.mRows[((AbstractCursor) this).mPos].get(columnIndex);
        return num.intValue();
    }

    @Override // android.database.AbstractCursor, android.database.Cursor
    public long getLong(int columnIndex) {
        Number num = (Number) this.mRows[((AbstractCursor) this).mPos].get(columnIndex);
        return num.longValue();
    }

    @Override // android.database.AbstractCursor, android.database.Cursor
    public float getFloat(int columnIndex) {
        Number num = (Number) this.mRows[((AbstractCursor) this).mPos].get(columnIndex);
        return num.floatValue();
    }

    @Override // android.database.AbstractCursor, android.database.Cursor
    public double getDouble(int columnIndex) {
        Number num = (Number) this.mRows[((AbstractCursor) this).mPos].get(columnIndex);
        return num.doubleValue();
    }

    @Override // android.database.AbstractCursor, android.database.Cursor
    public boolean isNull(int columnIndex) {
        return this.mRows[((AbstractCursor) this).mPos].get(columnIndex) == null;
    }
}
