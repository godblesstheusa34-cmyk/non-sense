package com.android.common.speech;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class Recognition {
    public static final String EXTRA_HINT_CONTEXT = "android.speech.extra.HINT_CONTEXT";
    public static final String EXTRA_HINT_STRINGS = "android.speech.extra.HINT_STRINGS";
    public static final int HINT_CONTEXT_CAR_HOME = 2;
    public static final int HINT_CONTEXT_LAUNCHER = 3;
    public static final int HINT_CONTEXT_UNKNOWN = 0;
    public static final int HINT_CONTEXT_VOICE_SEARCH_HELP = 1;

    private Recognition() {
    }
}
