package com.htc.launcher;

import android.graphics.Rect;
import com.htc.launcher.DragSource;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public interface DropTarget {
    boolean acceptDrop(DragSource dragSource, int i, int i2, int i3, int i4, Draggee draggee);

    boolean claimDrop(int i, int i2, int[] iArr);

    Rect estimateDropLocation(DragSource dragSource, int i, int i2, int i3, int i4, Draggee draggee, Rect rect);

    DragSource.DragCompletedAction getDragCompletedAction();

    void getHitRect(Rect rect);

    int getLeft();

    void getLocationOnScreen(int[] iArr);

    int getTop();

    void onDragEnter(DragSource dragSource, int i, int i2, int i3, int i4, Draggee draggee);

    void onDragExit(DragSource dragSource, DropTarget dropTarget, int i, int i2, int i3, int i4, Draggee draggee);

    void onDragOver(DragSource dragSource, int i, int i2, int i3, int i4, Draggee draggee);

    void onDrop(DragSource dragSource, int i, int i2, int i3, int i4, Draggee draggee);
}
