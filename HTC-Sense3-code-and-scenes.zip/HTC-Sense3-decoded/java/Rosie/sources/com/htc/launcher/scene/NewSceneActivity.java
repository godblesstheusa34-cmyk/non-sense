package com.htc.launcher.scene;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.htc.launcher.LauncherIntent;
import com.htc.launcher.Logger;
import com.htc.launcher.R;
import com.htc.launcher.WidgetWorkspaceManager;
import com.htc.launcher.custom.CustomResourceUtil;
import com.htc.launcher.settings.SettingUtil;
import com.htc.widget.HtcAlertDialog;
import java.io.File;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class NewSceneActivity extends Activity {
    public static final String ACTION_NEW_ITEM = "com.htc.launcher.NewSceneActivity.action.new_scene";
    public static final int CREATE_SCENE = 0;
    public static final String DELETE_SCENE_ID = "delete_scene_id";
    public static final int DIALOG_INVALIDATE_SCENE_NAME = 22;
    public static final String KEY_LAUNCH_MODE = "launch_mode";
    public static final String KEY_SELECT_ID = "select_id";
    public static final int RENAME_SCENE = 1;
    public static final int REQUEST_RESULT = 100;
    public static final int SCENE_CREATED = 3;
    public static final int SCENE_DELETED = 4;
    public static final int SCENE_NAME_CHANGED = 2;
    public static final int SCENE_REPLACED = 5;
    private static final String TAG = "NewSceneActivity";
    private static final boolean localLOGV = false;
    private String mCurrentUsingSceneName;
    private EditText mEditText;
    private TextWatcher mEditTextWatcher;
    private int mLaunchMode = 0;
    private Button mLeftButton;
    private int mSelectId;
    private WidgetWorkspaceManager mWidgetWorkspaceManager;

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        setContentView(R.layout.new_scene);
        this.mWidgetWorkspaceManager = WidgetWorkspaceManager.instance(this);
        this.mLaunchMode = getIntent().getIntExtra(KEY_LAUNCH_MODE, 0);
        this.mSelectId = getIntent().getIntExtra(KEY_SELECT_ID, -1);
        init();
    }

    private void init() {
        String titleName = getResources().getString(R.string.new_scene_title);
        ((TextView) findViewById(33685587)).setText(titleName);
        ((TextView) findViewById(33685588)).setText(titleName);
        View buttonBarBackground = findViewById(R.id.button_bar_background);
        if (buttonBarBackground != null && buttonBarBackground.getBackground() != null) {
            Drawable d = buttonBarBackground.getBackground();
            if (d instanceof BitmapDrawable) {
                ((BitmapDrawable) d).setGravity(80);
            }
        }
        Button done = (Button) findViewById(33685505);
        this.mLeftButton = done;
        done.setText(34341168);
        done.setOnClickListener(new View.OnClickListener() { // from class: com.htc.launcher.scene.NewSceneActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                if (NewSceneActivity.this.mLaunchMode == 0) {
                    final int scene = NewSceneActivity.this.mWidgetWorkspaceManager.findScene(NewSceneActivity.this.mEditText.getText().toString());
                    if (scene == -1) {
                        NewSceneActivity.this.createNewScene();
                        NewSceneActivity.this.setResult(3);
                        NewSceneActivity.this.finish();
                        return;
                    }
                    HtcAlertDialog.Builder builder = new HtcAlertDialog.Builder(NewSceneActivity.this);
                    builder.setTitle(NewSceneActivity.this.getString(R.string.scene_already_exists));
                    builder.setMessage(NewSceneActivity.this.getString(R.string.scene_already_exists_user));
                    builder.setNegativeButton(NewSceneActivity.this.getString(34341181), new DialogInterface.OnClickListener() { // from class: com.htc.launcher.scene.NewSceneActivity.1.1
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
                    builder.setPositiveButton(NewSceneActivity.this.getString(R.string.replace_action), new DialogInterface.OnClickListener() { // from class: com.htc.launcher.scene.NewSceneActivity.1.2
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialog, int which) {
                            Intent data = new Intent();
                            data.putExtra(NewSceneActivity.DELETE_SCENE_ID, scene);
                            NewSceneActivity.this.setResult(5, data);
                            NewSceneActivity.this.createNewScene();
                            NewSceneActivity.this.finish();
                        }
                    });
                    HtcAlertDialog dialog = builder.create();
                    dialog.show();
                    return;
                }
                if (NewSceneActivity.this.mLaunchMode == 1) {
                    if (NewSceneActivity.this.mSelectId == -1) {
                        Log.e(NewSceneActivity.TAG, "onClick(), mLaunchMode == RENAME_SCENE, mSelectId is invalidate");
                        NewSceneActivity.this.finish();
                    }
                    final int scene2 = NewSceneActivity.this.mWidgetWorkspaceManager.findScene(NewSceneActivity.this.mEditText.getText().toString());
                    if (scene2 == -1) {
                        NewSceneActivity.this.renameScene();
                        return;
                    }
                    HtcAlertDialog.Builder builder2 = new HtcAlertDialog.Builder(NewSceneActivity.this);
                    builder2.setTitle(NewSceneActivity.this.getString(R.string.scene_already_exists));
                    builder2.setMessage(NewSceneActivity.this.getString(R.string.scene_already_exists_user));
                    builder2.setNegativeButton(NewSceneActivity.this.getString(34341181), new DialogInterface.OnClickListener() { // from class: com.htc.launcher.scene.NewSceneActivity.1.3
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialog2, int which) {
                        }
                    });
                    builder2.setPositiveButton(NewSceneActivity.this.getString(R.string.replace_action), new DialogInterface.OnClickListener() { // from class: com.htc.launcher.scene.NewSceneActivity.1.4
                        @Override // android.content.DialogInterface.OnClickListener
                        public void onClick(DialogInterface dialog2, int which) {
                            if (scene2 != NewSceneActivity.this.mSelectId) {
                                NewSceneActivity.this.mWidgetWorkspaceManager.setDisplayName(NewSceneActivity.this.mSelectId, NewSceneActivity.this.mEditText.getText().toString());
                                Intent data = new Intent();
                                data.putExtra(NewSceneActivity.DELETE_SCENE_ID, scene2);
                                NewSceneActivity.this.setResult(4, data);
                            }
                            NewSceneActivity.this.finish();
                        }
                    });
                    HtcAlertDialog dialog2 = builder2.create();
                    dialog2.show();
                }
            }
        });
        Button cancel = (Button) findViewById(33685507);
        cancel.setText(34341181);
        cancel.setOnClickListener(new View.OnClickListener() { // from class: com.htc.launcher.scene.NewSceneActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                NewSceneActivity.this.finish();
            }
        });
        ((TextView) findViewById(R.id.name)).setText(R.string.themes_change_name);
        this.mEditText = (EditText) findViewById(R.id.new_name_text);
        this.mEditText.addTextChangedListener(new TextWatcher() { // from class: com.htc.launcher.scene.NewSceneActivity.3
            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable arg0) {
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence text, int arg1, int arg2, int arg3) {
                if (NewSceneActivity.this.checkNullOrAllSpaceString(text)) {
                    NewSceneActivity.this.mLeftButton.setEnabled(false);
                } else {
                    NewSceneActivity.this.mLeftButton.setEnabled(true);
                }
            }
        });
        int colorID = CustomResourceUtil.getColorResIdentifier(getBaseContext(), "app_selection_highlight", 0);
        if (colorID != 0) {
            this.mEditText.setHighlightColor(getResources().getColor(colorID));
        }
        if (this.mLaunchMode == 0) {
            this.mEditText.setText(generateHint(this));
        } else if (this.mLaunchMode == 1) {
            if (this.mSelectId == -1) {
                Log.e(TAG, "Select id is invalidate");
                finish();
            } else {
                this.mEditText.setText(this.mWidgetWorkspaceManager.getWidgetWorkspace(this.mSelectId).displayName);
            }
        }
        this.mEditText.selectAll();
        this.mEditText.requestFocus();
        final InputMethodManager imm = (InputMethodManager) getSystemService("input_method");
        this.mEditText.postDelayed(new Runnable() { // from class: com.htc.launcher.scene.NewSceneActivity.4
            @Override // java.lang.Runnable
            public void run() {
                imm.showSoftInput(NewSceneActivity.this.mEditText, 0);
            }
        }, 200L);
        this.mEditTextWatcher = new TextWatcher() { // from class: com.htc.launcher.scene.NewSceneActivity.5
            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable arg0) {
                Button done2 = (Button) NewSceneActivity.this.findViewById(33685505);
                if (NewSceneActivity.this.mEditText.getText().length() != 0) {
                    int length = NewSceneActivity.this.mEditText.getText().length();
                    boolean allspace = true;
                    for (int i = 0; i < length; i++) {
                        if (NewSceneActivity.this.mEditText.getText().charAt(i) != ' ') {
                            allspace = false;
                        }
                    }
                    done2.setEnabled(!allspace);
                    return;
                }
                done2.setEnabled(false);
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
            }
        };
        this.mEditText.addTextChangedListener(this.mEditTextWatcher);
        this.mCurrentUsingSceneName = this.mWidgetWorkspaceManager.getCurrentWorkspaceName();
        if (SettingUtil.localLOGD) {
            Log.d(TAG, "NewSceneActivity -> mCurrentUsingSceneName = " + this.mCurrentUsingSceneName);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void createNewScene() {
        int currentSceneId = this.mWidgetWorkspaceManager.newWorkspace(this.mEditText.getText().toString());
        Intent intent = new Intent();
        intent.setAction(LauncherIntent.ACTION_THEME_CHANGE);
        intent.putExtra("workspace_id", currentSceneId);
        if (SettingUtil.localLOGD) {
            Log.d(TAG, "new scene " + currentSceneId);
        }
        sendBroadcast(intent);
        if (SettingUtil.localLOGD) {
            Log.d(TAG, "create Scene(" + currentSceneId + ") as: " + this.mEditText.getText().toString());
        }
        launchHome();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void renameScene() {
        this.mWidgetWorkspaceManager.setDisplayName(this.mSelectId, this.mEditText.getText().toString());
        setResult(2);
        if (SettingUtil.localLOGD) {
            Log.d(TAG, "rename Scene(" + this.mSelectId + ") as: " + this.mEditText.getText().toString());
        }
        finish();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void deleteScene(int sceneId) {
        if (SettingUtil.localLOGD) {
            Log.d(TAG, "Rename scene and delete the scene with the same scene name: " + sceneId);
        }
        if (sceneId >= 0) {
            this.mWidgetWorkspaceManager.removeWorkspace(this.mWidgetWorkspaceManager.getWidgetWorkspace(sceneId), false);
            File deleteScene = new File(ScenePickerAdapter.PREVIEW_PATH + sceneId + ".png");
            if (deleteScene.exists()) {
                deleteScene.delete();
            }
            File deleteScene2 = new File(ScenePickerAdapter.ICON_PATH + sceneId + ".png");
            if (deleteScene2.exists()) {
                deleteScene2.delete();
            }
            File deleteScene3 = new File(ScenePickerAdapter.PREVIEW_PATH_LAND + sceneId + ".png");
            if (deleteScene3.exists()) {
                deleteScene3.delete();
            }
            File deleteScene4 = new File(ScenePickerAdapter.ICON_PATH_LAND + sceneId + ".png");
            if (deleteScene4.exists()) {
                deleteScene4.delete();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean checkNullOrAllSpaceString(CharSequence text) {
        if (text == null || text.length() == 0 || ((this.mSelectId == -1 || !text.toString().equals(this.mWidgetWorkspaceManager.getWidgetWorkspace(this.mSelectId).displayName)) && text.toString().equals(this.mCurrentUsingSceneName))) {
            return true;
        }
        int stringLength = text.length();
        for (int i = 0; i < stringLength; i++) {
            if (text.charAt(i) != ' ') {
                return false;
            }
        }
        return true;
    }

    private boolean checkSceneNameValid(String name) {
        return (this.mWidgetWorkspaceManager.containDisplayName(name) && (name == null || this.mSelectId == -1 || !name.equals(this.mWidgetWorkspaceManager.getWidgetWorkspace(this.mSelectId).displayName))) ? false : true;
    }

    static String generateHint(Context con) {
        WidgetWorkspaceManager wm = WidgetWorkspaceManager.instance();
        int index = 1;
        String strHint = con.getResources().getString(34341112);
        if (strHint.length() > 50) {
            strHint = "get Mojibake from com.htc.R.string.phone_type_custom please check com.htc.R.string.phone_type_custom";
            Logger.e(TAG, "get Mojibake from com.htc.R.string.phone_type_custom please check com.htc.R.string.phone_type_custom");
        }
        String newString = strHint + 1;
        while (wm.containDisplayName(newString)) {
            index++;
            newString = strHint + " " + index;
        }
        return newString;
    }

    private void launchHome() {
        Intent intent = new Intent("android.intent.action.MAIN");
        intent.addCategory("android.intent.category.HOME");
        startActivity(intent);
        finish();
    }

    @Override // android.app.Activity
    protected Dialog onCreateDialog(int id, Bundle args) {
        return id == 22 ? new HtcAlertDialog.Builder(this).setIcon(android.R.drawable.ic_dialog_alert).setTitle(R.string.scene_already_exists).setMessage(R.string.scene_already_exists_user).setPositiveButton(R.string.replace_action, new DialogInterface.OnClickListener() { // from class: com.htc.launcher.scene.NewSceneActivity.7
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface arg0, int arg1) {
                String sceneName = NewSceneActivity.this.mEditText.getText().toString();
                NewSceneActivity.this.deleteScene(NewSceneActivity.this.mWidgetWorkspaceManager.getWidgetWorkspace(sceneName, false).id);
                if (NewSceneActivity.this.mLaunchMode == 0) {
                    NewSceneActivity.this.createNewScene();
                } else if (NewSceneActivity.this.mLaunchMode == 1) {
                    NewSceneActivity.this.renameScene();
                }
                if (SettingUtil.localLOGD) {
                    Log.d(NewSceneActivity.TAG, "Duplicate scene name dialog: click replace");
                }
            }
        }).setNegativeButton(34341181, new DialogInterface.OnClickListener() { // from class: com.htc.launcher.scene.NewSceneActivity.6
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface arg0, int arg1) {
                if (SettingUtil.localLOGD) {
                    Log.d(NewSceneActivity.TAG, "Duplicate scene name dialog: click cancel");
                }
            }
        }).create() : super.onCreateDialog(id, args);
    }
}
