package com.htc.launcher;

import android.content.ComponentName;
import android.content.Intent;
import com.htc.launcher.OperatorTabCore;
import com.htc.launcher.model.FilterableAndSortableApplicationInfoList;
import java.io.File;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class OperatorTab extends OperatorTabCore {
    private static final String ACTION = CarouselDummyActivity.class.getName();
    private FilterableAndSortableApplicationInfoList.Classifier classifier;
    private Comparator<ApplicationInfo> comparator;
    private Intent intent;

    OperatorTab(int minorNb, String id, int initOrder, int initPlace, File restIconPath, File onIconPath, File overlayIconPath, HashMap<Locale, String> labelMap, List<OperatorTabCore.Application> appList) {
        super(minorNb, id, initOrder, initPlace, restIconPath, onIconPath, overlayIconPath, labelMap, appList);
        this.intent = null;
        this.classifier = null;
    }

    public synchronized Intent getIntent() {
        if (this.intent == null) {
            this.intent = new Intent(ACTION);
            this.intent.putExtra(CarouselDummyActivity.EXTRA_TAB, getClassifier().toString());
        }
        return this.intent;
    }

    public synchronized FilterableAndSortableApplicationInfoList.Classifier getClassifier() {
        if (this.classifier == null) {
            this.classifier = new OperatorTabClassifier();
        }
        return this.classifier;
    }

    public synchronized Comparator<ApplicationInfo> getAppComparator() {
        if (this.comparator == null) {
            this.comparator = new OperatorTabAppComparator();
        }
        return this.comparator;
    }

    private class OperatorTabClassifier implements FilterableAndSortableApplicationInfoList.Classifier {
        private OperatorTabClassifier() {
        }

        @Override // com.htc.launcher.model.FilterableAndSortableApplicationInfoList.Classifier
        public void reset() {
        }

        @Override // com.htc.launcher.model.FilterableAndSortableApplicationInfoList.Classifier
        public boolean classified(ApplicationInfo theApp) {
            ComponentName theComp = theApp.intent.getComponent();
            for (OperatorTabCore.Application tmp : OperatorTab.this.getAppList()) {
                if (tmp.getComponent().equals(theComp)) {
                    return true;
                }
            }
            return false;
        }
    }

    private class OperatorTabAppComparator implements Comparator<ApplicationInfo> {
        private OperatorTabAppComparator() {
        }

        @Override // java.util.Comparator
        public int compare(ApplicationInfo left, ApplicationInfo right) {
            int leftPriority = Integer.MAX_VALUE;
            int rightPriority = Integer.MAX_VALUE;
            List<OperatorTabCore.Application> appList = OperatorTab.this.getAppList();
            for (OperatorTabCore.Application tmp : appList) {
                if (tmp.getComponent().equals(left.intent.getComponent())) {
                    leftPriority = tmp.priority;
                }
                if (tmp.getComponent().equals(right.intent.getComponent())) {
                    rightPriority = tmp.priority;
                }
                if (Integer.MAX_VALUE != leftPriority && Integer.MAX_VALUE != rightPriority) {
                    break;
                }
            }
            return leftPriority - rightPriority;
        }
    }
}
