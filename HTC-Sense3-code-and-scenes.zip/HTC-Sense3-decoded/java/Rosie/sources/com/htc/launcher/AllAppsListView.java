package com.htc.launcher;

import android.content.ComponentName;
import android.content.Context;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.Toast;
import com.htc.launcher.AllAppsView;
import com.htc.launcher.Launcher;
import com.htc.launcher.custom.CustomResourceUtil;
import com.htc.launcher.model.FilterableAndSortableApplicationInfoList;
import com.htc.widget.HtcAdapterView;
import com.htc.widget.HtcListView;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
class AllAppsListView extends FrameLayout implements HtcAdapterView.OnItemClickListener, HtcAdapterView.OnItemLongClickListener, AllAppsView.Content {
    private AllAppsView mContainer;
    private FrameLayout mFrameLayout;
    private View mListLayout;
    private HtcListView mProgramList;

    public AllAppsListView(Context context) {
        this(context, null);
    }

    public AllAppsListView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        removeAllViews();
        if (this.mListLayout == null) {
            LayoutInflater inflater = (LayoutInflater) ((View) this).mContext.getSystemService("layout_inflater");
            this.mListLayout = inflater.inflate(R.layout.bladelistview, (ViewGroup) null);
            this.mListLayout.findViewById(R.id.blade_list).setSelector(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "rosie_list_selector", R.drawable.list_selector));
        }
        this.mFrameLayout = (FrameLayout) this.mListLayout.findViewById(R.id.program_list_main);
        this.mProgramList = this.mFrameLayout.findViewById(R.id.blade_list);
        this.mProgramList.setVerticalScrollBarEnabled(false);
        this.mProgramList.setOnItemClickListener(this);
        this.mProgramList.setOnItemLongClickListener(this);
        ColorDrawable color = new ColorDrawable(-16777216);
        this.mProgramList.setListBackground(color);
        this.mProgramList.setSelectionFromTop(0, (int) ((View) this).mContext.getResources().getDimension(R.dimen.add_to_home_top_height));
        this.mProgramList.setBottomBorderHeight(getResources().getDimensionPixelSize(R.dimen.application_boxed_bottomborder_height));
        this.mProgramList.setVerticalFadingEdgeEnabled(true);
        this.mProgramList.setSelector(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "rosie_list_selector", R.drawable.list_selector));
        this.mProgramList.setTextFilterEnabled(false);
        addView(this.mFrameLayout);
    }

    public void setFilterText(String text) {
        if (this.mProgramList != null) {
            this.mProgramList.setFilterText(text);
        }
    }

    public void setScrollingCacheEnabled(boolean bool) {
        if (this.mProgramList != null) {
            this.mProgramList.setScrollingCacheEnabled(bool);
        }
    }

    @Override // android.view.View
    public void setFadingEdgeLength(int length) {
        if (this.mProgramList != null) {
            this.mProgramList.setFadingEdgeLength(length);
        }
    }

    public void setTextFilterEnabled(boolean bool) {
        if (this.mProgramList != null) {
            this.mProgramList.setTextFilterEnabled(bool);
        }
    }

    public void clearTextFilter() {
        if (this.mProgramList != null) {
            this.mProgramList.clearTextFilter();
        }
    }

    public void setAdapter(ListAdapter adapter) {
        if (this.mProgramList != null) {
            this.mProgramList.setAdapter(adapter);
            if (!isFastScrollAllowed()) {
                this.mProgramList.setFastScrollEnabled(false);
            } else {
                this.mProgramList.setFastScrollEnabled(true);
            }
            this.mProgramList.setFillEmpty(false);
        }
    }

    public void setFastScrollEnabled(boolean enabled) {
        if (this.mProgramList != null) {
            if (isFastScrollAllowed() || !enabled) {
                this.mProgramList.setFastScrollEnabled(enabled);
            }
        }
    }

    public void setSelection(int position) {
        if (this.mProgramList != null) {
            this.mProgramList.setSelection(position);
        }
    }

    @Override // com.htc.launcher.AllAppsView.Content
    public void setContainer(AllAppsView container) {
        this.mContainer = container;
    }

    public void onItemClick(HtcAdapterView parent, View v, int position, long id) {
        ApplicationInfo app = (ApplicationInfo) parent.getItemAtPosition(position);
        Launcher launcher = this.mContainer.getLauncher();
        ComponentName cpn = app.intent.getComponent();
        if (cpn != null && "com.htc.searchanywhere/.SearchActivity".equals(cpn.flattenToShortString())) {
            app.intent.putExtra("launch_flag", 3);
        }
        if (launcher.currentAppTab == Launcher.AppTabType.allApp) {
            launcher.launchAppType = "All_apps";
        } else if (launcher.currentAppTab == Launcher.AppTabType.downloaded) {
            launcher.launchAppType = "Downloaded";
        } else if (launcher.currentAppTab == Launcher.AppTabType.frequent) {
            launcher.launchAppType = "Frequent";
        }
        launcher.startActivitySafely(app.intent);
    }

    public boolean isFastScrollAllowed() {
        boolean ret = false;
        ApplicationsAdapter adapter = (ApplicationsAdapter) (this.mProgramList == null ? null : this.mProgramList.getAdapter());
        if (adapter != null && FilterableAndSortableApplicationInfoList.ALPHABET.equals(adapter.getList().getComparator())) {
            ret = true;
        }
        String systemLang = getResources().getConfiguration().locale.getLanguage();
        return !"zh".equals(systemLang) && ret;
    }

    public boolean onItemLongClick(HtcAdapterView<?> parent, View view, int position, long id) {
        if (!view.isInTouchMode()) {
            return false;
        }
        Workspace workspace = this.mContainer.getLauncher().getWorkspace();
        if (workspace == null) {
            return true;
        }
        workspace.invalidateVacant();
        if (!workspace.hasRoomForSpan(1, 1)) {
            workspace.invalidateVacant();
            Toast.makeText(getContext(), this.mContainer.getResources().getString(R.string.out_of_space), 0).show();
            return true;
        }
        workspace.invalidateVacant();
        ApplicationInfo app = new ApplicationInfo((ApplicationInfo) parent.getItemAtPosition(position));
        FxItem fxItem = (FxItem) app.createItem(this.mContainer.getLauncher(), null);
        Logger.d("AllAppsGridView", "[APPS] Info:" + fxItem.getInfo());
        View icon = this.mContainer.prepareDragView(app.title, app.icon);
        RectF bounds = this.mContainer.getLauncher().getDesktopItemController().getExternalFloatingBounds(icon);
        this.mContainer.getLauncher().getDesktopItemController().startDragFxWidget(this.mContainer, fxItem, bounds);
        workspace.closeAllOpenLiveFolder();
        this.mContainer.getLauncher().closeAllApplications();
        return false;
    }

    public void updateOrientation(boolean portrait) {
        this.mProgramList.setBottomBorderHeight(getResources().getDimensionPixelSize(R.dimen.application_boxed_bottomborder_height));
    }
}
