package com.htc.launcher.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.android.common.speech.LoggingEvents;
import com.htc.launcher.Launcher;
import com.htc.launcher.R;
import com.htc.launcher.custom.CustomResourceUtil;
import com.htc.launcher.settings.SettingUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class ButtonBar extends RelativeLayout {
    private ButtonBar mButtons;
    private View.OnClickListener mClickOnButton;
    private View mControl;
    private View mFocusDelegate;
    private Launcher mLauncher;

    public ButtonBar(Context context) {
        super(context);
        this.mClickOnButton = new View.OnClickListener() { // from class: com.htc.launcher.widget.ButtonBar.1
            @Override // android.view.View.OnClickListener
            public void onClick(View button) {
                switch (button.getId()) {
                    case R.id.middle_btn /* 2131099659 */:
                        ButtonBar.this.mLauncher.onClickPhone();
                        break;
                    case R.id.left_btn /* 2131099661 */:
                        if (SettingUtil.isDoubleShot()) {
                            ButtonBar.this.mLauncher.startCallActivity();
                            break;
                        } else {
                            ButtonBar.this.mLauncher.onClickAllProgram();
                            break;
                        }
                    case R.id.right_btn /* 2131099662 */:
                        if (ButtonBar.this.mLauncher.mDrawer.isMoving()) {
                            Log.w("Handle buttons", " right_btn.mDrawer.isMoving() =  " + ButtonBar.this.mLauncher.mDrawer.isMoving());
                            break;
                        } else {
                            Log.w("Handle buttons", " right_btn is working");
                            ButtonBar.this.mLauncher.removeTutorialNotice();
                            if (SettingUtil.isDoubleShot()) {
                                ButtonBar.this.mLauncher.onClickAllProgram();
                                break;
                            } else {
                                ButtonBar.this.mLauncher.isNeedLaunchAddToHome = false;
                                ButtonBar.this.mLauncher.onClickAddtoHome(null);
                                break;
                            }
                        }
                }
            }
        };
    }

    public ButtonBar(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ButtonBar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mClickOnButton = new View.OnClickListener() { // from class: com.htc.launcher.widget.ButtonBar.1
            @Override // android.view.View.OnClickListener
            public void onClick(View button) {
                switch (button.getId()) {
                    case R.id.middle_btn /* 2131099659 */:
                        ButtonBar.this.mLauncher.onClickPhone();
                        break;
                    case R.id.left_btn /* 2131099661 */:
                        if (SettingUtil.isDoubleShot()) {
                            ButtonBar.this.mLauncher.startCallActivity();
                            break;
                        } else {
                            ButtonBar.this.mLauncher.onClickAllProgram();
                            break;
                        }
                    case R.id.right_btn /* 2131099662 */:
                        if (ButtonBar.this.mLauncher.mDrawer.isMoving()) {
                            Log.w("Handle buttons", " right_btn.mDrawer.isMoving() =  " + ButtonBar.this.mLauncher.mDrawer.isMoving());
                            break;
                        } else {
                            Log.w("Handle buttons", " right_btn is working");
                            ButtonBar.this.mLauncher.removeTutorialNotice();
                            if (SettingUtil.isDoubleShot()) {
                                ButtonBar.this.mLauncher.onClickAllProgram();
                                break;
                            } else {
                                ButtonBar.this.mLauncher.isNeedLaunchAddToHome = false;
                                ButtonBar.this.mLauncher.onClickAddtoHome(null);
                                break;
                            }
                        }
                }
            }
        };
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchUnhandledMove(View focused, int direction) {
        if (this.mFocusDelegate == null || !this.mFocusDelegate.dispatchUnhandledMove(focused, direction)) {
            return super.dispatchUnhandledMove(focused, direction);
        }
        return true;
    }

    public void setFocusDelegate(View delegate) {
        this.mFocusDelegate = delegate;
    }

    public void setMoveAction(boolean bool) {
    }

    @Override // android.view.View
    protected void onFinishInflate() {
        super.onFinishInflate();
        setAnimationCacheEnabled(false);
        Resources res = getContext().getResources();
        ((ImageButton) findViewById(R.id.left_btn)).setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "bb_btn_left", R.drawable.bb_btn_left)));
        ((ImageButton) findViewById(R.id.right_btn)).setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "bb_btn_right", R.drawable.bb_btn_right)));
        ((RelativeLayout) findViewById(R.id.middle_btn)).setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "bb_btn_middle", R.drawable.bb_btn_middle)));
        if (SettingUtil.isDoubleShot()) {
            setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "navbar", 34078817)));
        } else {
            setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "navbar", 34079090)));
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void dispatchSetPressed(boolean pressed) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childView = getChildAt(i);
            childView.setPressed(pressed);
        }
    }

    @Override // android.view.View
    public void setOnTouchListener(View.OnTouchListener touchListener) {
    }

    public void setOnLongClick(View.OnLongClickListener longClickListener) {
    }

    public void updateOrientation(int CurrentOrientation) {
        Resources res = getContext().getResources();
        if (CurrentOrientation == 2) {
            setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "navbar", 34079090)));
            RelativeLayout.LayoutParams tmp = new RelativeLayout.LayoutParams(-2, -1);
            tmp.addRule(11);
            setLayoutParams(tmp);
            RelativeLayout middle_background = (RelativeLayout) findViewById(R.id.middle_btn);
            RelativeLayout.LayoutParams tmp2 = new RelativeLayout.LayoutParams(-2, -2);
            tmp2.addRule(15);
            tmp2.addRule(11);
            tmp2.setMargins(0, 0, res.getDimensionPixelSize(R.dimen.button_bar_mid_margin_right), 0);
            middle_background.setLayoutParams(tmp2);
            middle_background.setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "bb_btn_middle", R.drawable.bb_btn_middle)));
            ImageButton left_btn = (ImageButton) findViewById(R.id.left_btn);
            RelativeLayout.LayoutParams tmp3 = new RelativeLayout.LayoutParams(-2, -2);
            tmp3.addRule(11);
            tmp3.setMargins(0, 0, res.getDimensionPixelSize(R.dimen.button_bar_left_margin_right), res.getDimensionPixelSize(R.dimen.button_bar_margin));
            tmp3.addRule(12);
            left_btn.setLayoutParams(tmp3);
            left_btn.setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "bb_btn_left", R.drawable.bb_btn_left)));
            left_btn.setImageDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "bb_btn_left_src_on", R.drawable.bb_btn_left_src_on)));
            left_btn.setScaleType(ImageView.ScaleType.CENTER);
            ImageButton right_btn = (ImageButton) findViewById(R.id.right_btn);
            RelativeLayout.LayoutParams tmp4 = new RelativeLayout.LayoutParams(-2, -2);
            tmp4.addRule(7, R.id.left_btn);
            tmp4.addRule(10);
            tmp4.setMargins(0, res.getDimensionPixelSize(R.dimen.button_bar_margin), 0, 0);
            right_btn.setLayoutParams(tmp4);
            right_btn.setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "bb_btn_right", R.drawable.bb_btn_right)));
            right_btn.setImageDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "bb_btn_right_personalize_src", R.drawable.bb_btn_right_personalize_src)));
            right_btn.setScaleType(ImageView.ScaleType.CENTER);
            right_btn.setImageResource(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "bb_btn_right_personalize_src", R.drawable.bb_btn_right_personalize_src));
            TextView middle_label = (TextView) findViewById(R.id.middle_btn_content);
            RelativeLayout.LayoutParams tmp5 = new RelativeLayout.LayoutParams(-2, -2);
            tmp5.addRule(15);
            tmp5.addRule(11);
            middle_label.setLayoutParams(tmp5);
            middle_label.setGravity(17);
            middle_label.setPadding(0, res.getDimensionPixelSize(R.dimen.button_bar_mid_padding_right), res.getDimensionPixelSize(R.dimen.button_bar_mid_padding_bottom), 0);
            middle_label.setCompoundDrawablesWithIntrinsicBounds(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "bb_btn_middle_src", R.drawable.bb_btn_middle_src)), (Drawable) null, (Drawable) null, (Drawable) null);
            middle_label.setText(LoggingEvents.EXTRA_CALLING_APP_NAME);
            return;
        }
        if (CurrentOrientation == 1) {
            RelativeLayout.LayoutParams tmp6 = new RelativeLayout.LayoutParams(-1, res.getDimensionPixelSize(R.dimen.button_bar_height));
            tmp6.addRule(12);
            setLayoutParams(tmp6);
            setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "navbar", 34079090)));
            RelativeLayout middle_background2 = (RelativeLayout) findViewById(R.id.middle_btn);
            RelativeLayout.LayoutParams tmp7 = new RelativeLayout.LayoutParams(-2, -2);
            tmp7.addRule(14);
            tmp7.addRule(12);
            middle_background2.setLayoutParams(tmp7);
            middle_background2.setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "bb_btn_middle", R.drawable.bb_btn_middle)));
            TextView middle_label2 = (TextView) findViewById(R.id.middle_btn_content);
            RelativeLayout.LayoutParams tmp8 = new RelativeLayout.LayoutParams(-2, -2);
            tmp8.addRule(14);
            tmp8.addRule(12);
            middle_label2.setLayoutParams(tmp8);
            middle_label2.setGravity(17);
            middle_label2.setPadding(0, 0, res.getDimensionPixelSize(R.dimen.button_bar_mid_padding_right), res.getDimensionPixelSize(R.dimen.button_bar_mid_padding_bottom));
            middle_label2.setText(R.string.phone);
            middle_label2.setCompoundDrawablesWithIntrinsicBounds(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "bb_btn_middle_src", R.drawable.bb_btn_middle_src)), (Drawable) null, (Drawable) null, (Drawable) null);
            ImageButton left_btn2 = (ImageButton) findViewById(R.id.left_btn);
            RelativeLayout.LayoutParams tmp9 = new RelativeLayout.LayoutParams(-2, -2);
            tmp9.addRule(8, R.id.middle_btn);
            tmp9.setMargins(res.getDimensionPixelSize(R.dimen.button_bar_margin), 0, 0, 0);
            tmp9.addRule(9);
            left_btn2.setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "bb_btn_left", R.drawable.bb_btn_left)));
            left_btn2.setImageDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "bb_btn_left_src_on", R.drawable.bb_btn_left_src_on)));
            left_btn2.setScaleType(ImageView.ScaleType.CENTER);
            left_btn2.setLayoutParams(tmp9);
            ImageButton right_btn2 = (ImageButton) findViewById(R.id.right_btn);
            RelativeLayout.LayoutParams tmp10 = new RelativeLayout.LayoutParams(-2, -2);
            tmp10.addRule(8, R.id.middle_btn);
            tmp10.addRule(11);
            tmp10.setMargins(0, 0, res.getDimensionPixelSize(R.dimen.button_bar_margin), 0);
            right_btn2.setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "bb_btn_right", R.drawable.bb_btn_right)));
            right_btn2.setImageDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "bb_btn_right_personalize_src", R.drawable.bb_btn_right_personalize_src)));
            right_btn2.setScaleType(ImageView.ScaleType.CENTER);
            right_btn2.setLayoutParams(tmp10);
        }
    }

    public void setLauncher(Launcher launcher) {
        this.mLauncher = launcher;
    }

    public void setControl(View control) {
        this.mControl = control;
    }

    public void setButtonBar(ButtonBar buttons) {
        this.mButtons = buttons;
    }

    public void setup2DButtonBarViews() {
        View.OnClickListener bl = this.mClickOnButton;
        int touchWidth = getResources().getDimensionPixelSize(R.dimen.button_bar_touch_width);
        int touchHeight = getResources().getDimensionPixelSize(R.dimen.button_bar_touch_height);
        ImageButton buttonLeft = (ImageButton) this.mButtons.findViewById(R.id.left_btn);
        buttonLeft.setOnClickListener(bl);
        buttonLeft.setFocusable(false);
        TouchDelegate delegateLeft = new TouchDelegate(new Rect(0, 0, touchWidth, touchHeight), buttonLeft);
        View touchLeft = this.mButtons.findViewById(R.id.left_btn_touch);
        touchLeft.setTouchDelegate(delegateLeft);
        View buttonMiddle = this.mButtons.findViewById(R.id.middle_btn);
        buttonMiddle.setOnClickListener(bl);
        View buttonRight = this.mButtons.findViewById(R.id.right_btn);
        buttonRight.setOnClickListener(bl);
        buttonRight.setFocusable(false);
        TouchDelegate delegateRight = new TouchDelegate(new Rect(0, 0, touchWidth, touchHeight), buttonRight);
        View touchRight = this.mButtons.findViewById(R.id.right_btn_touch);
        touchRight.setTouchDelegate(delegateRight);
        this.mButtons.clearFocus();
    }

    public void update2DButtonBarViews() {
    }

    public void ButtonBarViews_UpdateOrientation() {
        if (!this.mLauncher.isPortrait()) {
            FrameLayout.LayoutParams controlParams = (FrameLayout.LayoutParams) this.mControl.getLayoutParams();
            ((ViewGroup.LayoutParams) controlParams).width = getResources().getDimensionPixelSize(R.dimen.launcher_control_height);
            Log.v("jojojojo", "controlParams.width: " + ((ViewGroup.LayoutParams) controlParams).width);
            ((ViewGroup.LayoutParams) controlParams).height = -1;
            controlParams.gravity = 21;
            RelativeLayout.LayoutParams buttonsParams = (RelativeLayout.LayoutParams) this.mButtons.getLayoutParams();
            ((ViewGroup.LayoutParams) buttonsParams).width = getResources().getDimensionPixelSize(R.dimen.button_bar_height);
            ((ViewGroup.LayoutParams) buttonsParams).height = -1;
            buttonsParams.addRule(15);
            buttonsParams.addRule(11);
            buttonsParams.addRule(14, 0);
            buttonsParams.addRule(12, 0);
            View buttonMiddle = this.mButtons.findViewById(R.id.middle_btn);
            RelativeLayout.LayoutParams MidParam = (RelativeLayout.LayoutParams) buttonMiddle.getLayoutParams();
            MidParam.addRule(15);
            MidParam.addRule(11);
            MidParam.addRule(14, 0);
            MidParam.addRule(12, 0);
            ImageButton buttonLeft = (ImageButton) this.mButtons.findViewById(R.id.left_btn);
            RelativeLayout.LayoutParams LftParam = (RelativeLayout.LayoutParams) buttonLeft.getLayoutParams();
            LftParam.addRule(7, R.id.middle_btn);
            LftParam.addRule(8, 0);
            LftParam.addRule(12);
            LftParam.addRule(9, 0);
            ((ViewGroup.MarginLayoutParams) LftParam).bottomMargin = getResources().getDimensionPixelSize(R.dimen.button_bar_margin);
            ((ViewGroup.MarginLayoutParams) LftParam).leftMargin = 0;
            View buttonRight = this.mButtons.findViewById(R.id.right_btn);
            RelativeLayout.LayoutParams RightParam = (RelativeLayout.LayoutParams) buttonRight.getLayoutParams();
            RightParam.addRule(7, R.id.middle_btn);
            RightParam.addRule(8, 0);
            RightParam.addRule(10);
            RightParam.addRule(11, 0);
            ((ViewGroup.MarginLayoutParams) RightParam).topMargin = getResources().getDimensionPixelSize(R.dimen.button_bar_margin);
            ((ViewGroup.MarginLayoutParams) RightParam).rightMargin = 0;
            View ViewLeft = this.mButtons.findViewById(R.id.left_btn_touch);
            RelativeLayout.LayoutParams LftViewParam = (RelativeLayout.LayoutParams) ViewLeft.getLayoutParams();
            LftViewParam.addRule(8, 0);
            LftViewParam.addRule(7, R.id.middle_btn);
            LftViewParam.addRule(12);
            LftViewParam.addRule(9, 0);
            ((ViewGroup.MarginLayoutParams) LftViewParam).leftMargin = getResources().getDimensionPixelSize(R.dimen.button_bar_margin);
            ((ViewGroup.MarginLayoutParams) LftViewParam).bottomMargin = 0;
            View ViewRight = this.mButtons.findViewById(R.id.right_btn_touch);
            RelativeLayout.LayoutParams RightViewParam = (RelativeLayout.LayoutParams) ViewRight.getLayoutParams();
            RightViewParam.addRule(8, 0);
            RightViewParam.addRule(7, R.id.middle_btn);
            RightViewParam.addRule(10);
            RightViewParam.addRule(11, 0);
            ((ViewGroup.MarginLayoutParams) RightViewParam).rightMargin = getResources().getDimensionPixelSize(R.dimen.button_bar_margin);
            ((ViewGroup.MarginLayoutParams) RightViewParam).topMargin = 0;
            return;
        }
        FrameLayout.LayoutParams controlParams2 = (FrameLayout.LayoutParams) this.mControl.getLayoutParams();
        ((ViewGroup.LayoutParams) controlParams2).height = getResources().getDimensionPixelSize(R.dimen.launcher_control_height);
        ((ViewGroup.LayoutParams) controlParams2).width = -1;
        Log.v("jojojojo", "controlParams.height: " + ((ViewGroup.LayoutParams) controlParams2).height);
        controlParams2.gravity = 81;
        RelativeLayout.LayoutParams buttonsParams2 = (RelativeLayout.LayoutParams) this.mButtons.getLayoutParams();
        ((ViewGroup.LayoutParams) buttonsParams2).height = getResources().getDimensionPixelSize(R.dimen.button_bar_height);
        ((ViewGroup.LayoutParams) buttonsParams2).width = -1;
        buttonsParams2.addRule(14);
        buttonsParams2.addRule(12);
        buttonsParams2.addRule(15, 0);
        buttonsParams2.addRule(11, 0);
        View buttonMiddle2 = this.mButtons.findViewById(R.id.middle_btn);
        RelativeLayout.LayoutParams MidParam2 = (RelativeLayout.LayoutParams) buttonMiddle2.getLayoutParams();
        MidParam2.addRule(15, 0);
        MidParam2.addRule(11, 0);
        MidParam2.addRule(14);
        MidParam2.addRule(12);
        ImageButton buttonLeft2 = (ImageButton) this.mButtons.findViewById(R.id.left_btn);
        RelativeLayout.LayoutParams LftParam2 = (RelativeLayout.LayoutParams) buttonLeft2.getLayoutParams();
        LftParam2.addRule(8, R.id.middle_btn);
        LftParam2.addRule(7, 0);
        LftParam2.addRule(12, 0);
        LftParam2.addRule(9);
        ((ViewGroup.MarginLayoutParams) LftParam2).leftMargin = getResources().getDimensionPixelSize(R.dimen.button_bar_margin);
        ((ViewGroup.MarginLayoutParams) LftParam2).bottomMargin = 0;
        View buttonRight2 = this.mButtons.findViewById(R.id.right_btn);
        RelativeLayout.LayoutParams RightParam2 = (RelativeLayout.LayoutParams) buttonRight2.getLayoutParams();
        RightParam2.addRule(8, R.id.middle_btn);
        RightParam2.addRule(7, 0);
        RightParam2.addRule(10, 0);
        RightParam2.addRule(11);
        ((ViewGroup.MarginLayoutParams) RightParam2).rightMargin = getResources().getDimensionPixelSize(R.dimen.button_bar_margin);
        ((ViewGroup.MarginLayoutParams) RightParam2).topMargin = 0;
        View ViewLeft2 = this.mButtons.findViewById(R.id.left_btn_touch);
        RelativeLayout.LayoutParams LftViewParam2 = (RelativeLayout.LayoutParams) ViewLeft2.getLayoutParams();
        LftViewParam2.addRule(8, R.id.middle_btn);
        LftViewParam2.addRule(7, 0);
        LftViewParam2.addRule(12, 0);
        LftViewParam2.addRule(9);
        ((ViewGroup.MarginLayoutParams) LftViewParam2).leftMargin = getResources().getDimensionPixelSize(R.dimen.button_bar_margin);
        ((ViewGroup.MarginLayoutParams) LftViewParam2).bottomMargin = 0;
        View ViewRight2 = this.mButtons.findViewById(R.id.right_btn_touch);
        RelativeLayout.LayoutParams RightViewParam2 = (RelativeLayout.LayoutParams) ViewRight2.getLayoutParams();
        RightViewParam2.addRule(8, R.id.middle_btn);
        RightViewParam2.addRule(7, 0);
        RightViewParam2.addRule(10, 0);
        RightViewParam2.addRule(11);
        ((ViewGroup.MarginLayoutParams) RightViewParam2).rightMargin = getResources().getDimensionPixelSize(R.dimen.button_bar_margin);
        ((ViewGroup.MarginLayoutParams) RightViewParam2).topMargin = 0;
    }
}
