package com.htc.launcher;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class PendingUIUpdate {
    private static final String LOG_TAG = "PendingUIUpdate";
    private static PendingUIUpdate sDelayedUIUpdate;
    private static Object sSyncObject = new Object();
    protected Handler mHandler;
    protected Looper mLooper;
    private boolean mDidScroll = false;
    private int mCount = 1;
    private HandlerThread mHandlerThread = new HandlerThread(LOG_TAG, 10);

    public static synchronized PendingUIUpdate instance() {
        PendingUIUpdate pendingUIUpdate;
        synchronized (PendingUIUpdate.class) {
            if (sDelayedUIUpdate == null) {
                sDelayedUIUpdate = new PendingUIUpdate();
            }
            pendingUIUpdate = sDelayedUIUpdate;
        }
        return pendingUIUpdate;
    }

    private class PendingUIHandler extends Handler {
        public PendingUIHandler(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if ((msg.obj instanceof Runnable) && msg.arg1 == PendingUIUpdate.this.mCount) {
                if (Launcher.localLOGD) {
                    Log.d(PendingUIUpdate.LOG_TAG, "after take - " + msg.obj);
                }
                if (PendingUIUpdate.this.mDidScroll) {
                    synchronized (PendingUIUpdate.sSyncObject) {
                        try {
                            if (Launcher.localLOGD) {
                                Log.d(PendingUIUpdate.LOG_TAG, "enter waiting.");
                            }
                            PendingUIUpdate.sSyncObject.wait();
                            if (Launcher.localLOGD) {
                                Log.d(PendingUIUpdate.LOG_TAG, "wake from waiting.");
                            }
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
                Launcher launcher = Launcher.sRefLauncher.get();
                if (launcher != null) {
                    launcher.mHandler.post((Runnable) msg.obj);
                    try {
                        Thread.sleep(200L);
                    } catch (InterruptedException e2) {
                    }
                }
            }
        }
    }

    private PendingUIUpdate() {
        this.mHandlerThread.start();
        this.mLooper = this.mHandlerThread.getLooper();
        this.mHandler = new PendingUIHandler(this.mLooper);
    }

    public void postPending(int what, Runnable runnable) {
        this.mHandler.removeMessages(what);
        this.mHandler.sendMessage(Message.obtain(this.mHandler, what, this.mCount, 0, runnable));
    }

    public static void reset() {
        if (sDelayedUIUpdate != null) {
            sDelayedUIUpdate.mCount++;
        }
    }

    public void beginScroll() {
        this.mDidScroll = true;
    }

    public void endScroll() {
        this.mDidScroll = false;
        synchronized (sSyncObject) {
            sSyncObject.notifyAll();
        }
    }
}
