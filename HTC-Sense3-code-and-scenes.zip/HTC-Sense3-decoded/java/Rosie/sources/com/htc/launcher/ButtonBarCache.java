package com.htc.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;
import com.htc.launcher.settings.SettingUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class ButtonBarCache extends RelativeLayout {
    private boolean isUseCacheBitmap;
    private Bitmap mCacheBitmap;
    private Canvas mCacheCanvas;
    private Paint mPaint;

    public ButtonBarCache(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mCacheBitmap = null;
        this.isUseCacheBitmap = false;
    }

    public ButtonBarCache(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mCacheBitmap = null;
        this.isUseCacheBitmap = false;
    }

    public ButtonBarCache(Context context) {
        super(context);
        this.mCacheBitmap = null;
        this.isUseCacheBitmap = false;
    }

    public void useCacheBitmap(boolean enable) {
        this.isUseCacheBitmap = enable;
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (this.isUseCacheBitmap) {
            return false;
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void dispatchDraw(Canvas canvas) {
        if (this.isUseCacheBitmap) {
            buildCache();
            if (this.mCacheBitmap != null) {
                if (this.mPaint == null) {
                    this.mPaint = new Paint();
                }
                canvas.drawColor(0, PorterDuff.Mode.CLEAR);
                canvas.drawBitmap(this.mCacheBitmap, 0.0f, 0.0f, this.mPaint);
                return;
            }
        }
        super.dispatchDraw(canvas);
    }

    public void updateOrientation() {
        if (this.mCacheBitmap != null) {
            this.mCacheBitmap.recycle();
        }
        this.mCacheBitmap = null;
        this.mCacheCanvas = null;
    }

    public void buildCache() {
        if (this.mCacheBitmap == null) {
            int width = getWidth();
            int height = getHeight();
            int orientation = ((View) this).mContext.getResources().getConfiguration().orientation;
            if (width <= 0 || height <= 0 || ((orientation == 1 && width != SettingUtil.getScreenShortAxisLength()) || (orientation == 2 && height != ((View) ((View) this).mParent).getHeight()))) {
                Log.e("ButtonBarCache", "buildCache error!!! width = " + width + ", height = " + height);
                return;
            }
            this.mCacheBitmap = Bitmap.createBitmap(getWidth(), getHeight(), Bitmap.Config.ARGB_8888);
            if (this.mCacheCanvas == null) {
                this.mCacheCanvas = new Canvas(this.mCacheBitmap);
            }
            this.mCacheCanvas.drawColor(0, PorterDuff.Mode.CLEAR);
            super.dispatchDraw(this.mCacheCanvas);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void dispatchSetPressed(boolean pressed) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childView = getChildAt(i);
            childView.setPressed(pressed);
        }
    }

    public final Bitmap getButtonBarCahce() {
        return this.mCacheBitmap;
    }
}
