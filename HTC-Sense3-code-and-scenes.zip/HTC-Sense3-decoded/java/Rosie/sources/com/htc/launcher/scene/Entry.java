package com.htc.launcher.scene;

import android.os.Bundle;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class Entry {
    private ArrayList<Entry> mEntries;
    private Bundle mInfo;
    private String mTag;

    public void setTag(String tag) {
        this.mTag = tag;
    }

    public String getTag() {
        return this.mTag;
    }

    public void addInfo(String key, String value) {
        if (this.mInfo == null) {
            this.mInfo = new Bundle();
        }
        this.mInfo.putString(key, value);
    }

    public Bundle getInfo() {
        return this.mInfo;
    }

    public void addEntry(Entry entry) {
        if (this.mEntries == null) {
            this.mEntries = new ArrayList<>();
        }
        this.mEntries.add(entry);
    }

    public ArrayList<Entry> getEntries() {
        return this.mEntries;
    }

    public ArrayList<Entry> getEntryByTag(String tag) {
        if (tag == null) {
            return null;
        }
        ArrayList<Entry> result = new ArrayList<>();
        Iterator i$ = this.mEntries.iterator();
        while (i$.hasNext()) {
            Entry entry = i$.next();
            if (tag.equals(entry.getTag())) {
                result.add(entry);
            }
        }
        return result;
    }

    public boolean isCompleted() {
        return getTag() != null;
    }

    public String toString() {
        return String.format("Entry(%s)(%d, %d)", getTag(), Integer.valueOf(getInfo().size()), Integer.valueOf(getEntries().size()));
    }
}
