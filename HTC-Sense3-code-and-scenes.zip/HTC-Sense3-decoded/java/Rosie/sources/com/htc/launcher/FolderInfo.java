package com.htc.launcher;

import com.android.common.speech.LoggingEvents;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
abstract class FolderInfo extends FxShortcutInfo {
    boolean opened;
    CharSequence title;

    FolderInfo() {
    }

    @Override // com.htc.launcher.FxShortcutInfo, com.htc.launcher.ItemInfo
    public String getUlog() {
        String ret = this.title.toString() + ", folder, " + this.screen + ", " + this.cellX + ", " + this.cellY + ", " + this.spanX + ", " + this.spanY;
        if (this.screen < 0 || this.screen > max_screen) {
            return LoggingEvents.EXTRA_CALLING_APP_NAME;
        }
        return ret;
    }
}
