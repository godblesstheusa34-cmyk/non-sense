package com.htc.launcher.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import com.htc.launcher.R;
import com.htc.launcher.Workspace;
import com.htc.launcher.custom.CustomResourceUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class Scrollbar extends FrameLayout implements Workspace.OnSlideListener {
    private static final String TAG = "Scrollbar";
    private static boolean isInitialed = false;
    private static final boolean localLOGV = false;
    private float[] curveEquation;
    private boolean isLinear;
    private Paint mAlphaPaint;
    private boolean mHide;
    private Matrix mMatrix;
    private int mOrientation;
    private Paint mPaint;
    private ThumbBitmap mThumbBitmap;
    private int mThumbWidth;
    private int mTrackOffset;
    private int mTrackWidth;
    private int x1;
    private int x2;
    private int x3;
    private int y1;
    private int y2;
    private int y3;

    public Scrollbar(Context context) {
        this(context, null);
    }

    public Scrollbar(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public Scrollbar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mTrackOffset = 0;
        this.curveEquation = new float[3];
        this.isLinear = false;
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.Scrollbar, defStyle, 0);
        this.x1 = a.getInt(0, 0);
        this.y1 = a.getInt(1, 30);
        this.x2 = a.getInt(2, 160);
        this.y2 = a.getInt(3, 7);
        this.x3 = a.getInt(4, 320);
        this.y3 = a.getInt(5, 30);
        this.mHide = a.getBoolean(6, false);
        if (this.mHide) {
            hide();
        }
        this.curveEquation = solveLinearEquation(this.x1, this.y1, this.x2, this.y2, this.x3, this.y3);
        initScrollbar();
        this.mAlphaPaint = new Paint();
        this.mAlphaPaint.setAlpha(Color.alpha(R.color.scrollbar));
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void dispatchDraw(Canvas canvas) {
        if (!this.mHide && isInitialed) {
            if (this.mMatrix == null) {
                this.mMatrix = new Matrix();
            }
            this.mMatrix.postRotate(this.mThumbBitmap.angle, this.mThumbBitmap.getWidth() / 2, this.mThumbBitmap.getHeight());
            this.mMatrix.postTranslate(this.mThumbBitmap.getLeft(), this.mThumbBitmap.mTop);
            if (this.mPaint == null) {
                this.mPaint = new Paint();
                this.mPaint.setFilterBitmap(true);
            }
            canvas.drawBitmap(this.mThumbBitmap.thumbBitmap, this.mMatrix, this.mPaint);
            this.mMatrix.reset();
        }
    }

    private void initScrollbar() {
        this.mOrientation = getResources().getConfiguration().orientation;
        removeAllViews();
        this.mThumbBitmap = new ThumbBitmap();
        this.mThumbBitmap.thumbBitmap = BitmapFactory.decodeResource(((View) this).mContext.getResources(), R.drawable.common_mainnav_scroller1);
        int thumbSize = this.mThumbBitmap.getWidth();
        this.mTrackOffset = 10;
        this.mTrackWidth = (this.x3 - this.x1) - thumbSize;
        this.mThumbWidth = thumbSize;
        isInitialed = true;
    }

    public void moveThumbTo(float pos) {
        moveThumbToInternal(((int) ((this.mTrackWidth + (this.mTrackOffset * 2)) * pos)) - this.mTrackOffset);
    }

    private void moveThumbToInternal(int pos) {
        float dragImageTop = 0.0f;
        float angle = 0.0f;
        if ((CustomResourceUtil.getIntegerResIdentifier(((View) this).mContext, "rosie_scrollbar_curve", 0) == 0 || getResources().getInteger(CustomResourceUtil.getIntegerResIdentifier(((View) this).mContext, "rosie_scrollbar_curve", 0)) != 1) && !this.isLinear) {
            pos = Math.max(-this.mTrackOffset, Math.min(this.mTrackWidth + this.mTrackOffset, pos));
            dragImageTop = getDragImageY(pos);
            angle = (float) getRotateAngle(pos);
        }
        this.mThumbBitmap.angle = angle;
        this.mThumbBitmap.mTop = dragImageTop;
        this.mThumbBitmap.mLeft = pos;
    }

    public void setHide(boolean hide) {
        this.mHide = hide;
    }

    public void setLinear(boolean linear) {
        this.isLinear = linear;
    }

    @Override // android.view.View
    public String toString() {
        return String.format("Scrollbar: rect=(%d,%d)-(%d,%d), measure=%dx%d, scroll=(%d,%d).", Integer.valueOf(((View) this).mLeft), Integer.valueOf(((View) this).mTop), Integer.valueOf(((View) this).mRight), Integer.valueOf(((View) this).mBottom), Integer.valueOf(((View) this).mMeasuredWidth), Integer.valueOf(((View) this).mMeasuredHeight), Integer.valueOf(((View) this).mScrollX), Integer.valueOf(((View) this).mScrollY));
    }

    private float getDragImageY(int x) {
        int x2 = x + (this.mThumbWidth / 2);
        return ((((this.curveEquation[2] * x2) * x2) + (this.curveEquation[1] * x2)) + this.curveEquation[0]) - 8.0f;
    }

    private double getRotateAngle(int x) {
        int x2 = x + (this.mThumbWidth / 2);
        return this.mOrientation == 1 ? (Math.atan(((this.curveEquation[2] * 2.0f) * x2) + this.curveEquation[1]) * 180.0d) / 3.141592653589793d : (Math.atan(((this.curveEquation[2] * 2.0f) * x2) + this.curveEquation[1]) * 180.0d) / 3.141592653589793d;
    }

    private static float[] solveLinearEquation(int x1, int y1, int x2, int y2, int x3, int y3) {
        float[] result = new float[3];
        float[] mother = {x1 * x1, x1, 1.0f, x2 * x2, x2, 1.0f, x3 * x3, x3, 1.0f};
        float[] child = new float[9];
        for (int i = 0; i < mother.length; i++) {
            child[i] = mother[i];
        }
        child[0] = y1;
        child[3] = y2;
        child[6] = y3;
        result[2] = delta(child) / delta(mother);
        for (int i2 = 0; i2 < mother.length; i2++) {
            child[i2] = mother[i2];
        }
        child[1] = y1;
        child[4] = y2;
        child[7] = y3;
        result[1] = delta(child) / delta(mother);
        for (int i3 = 0; i3 < mother.length; i3++) {
            child[i3] = mother[i3];
        }
        child[2] = y1;
        child[5] = y2;
        child[8] = y3;
        result[0] = delta(child) / delta(mother);
        return result;
    }

    public static float delta(float[] matrix) {
        return ((((((matrix[0] * matrix[4]) * matrix[8]) + ((matrix[1] * matrix[5]) * matrix[6])) + ((matrix[2] * matrix[3]) * matrix[7])) - ((matrix[2] * matrix[4]) * matrix[6])) - ((matrix[0] * matrix[5]) * matrix[7])) - ((matrix[1] * matrix[3]) * matrix[8]);
    }

    private void hide() {
        if (this.mHide) {
            setEnabled(false);
            setVisibility(4);
            setClickable(false);
            setFocusable(false);
        }
    }

    @Override // android.view.View
    public void setVisibility(int visibility) {
        if (this.mHide) {
            super.setVisibility(4);
        } else {
            super.setVisibility(visibility);
        }
    }

    private class ThumbBitmap {
        float angle;
        float mLeft;
        float mTop;
        Bitmap thumbBitmap;

        private ThumbBitmap() {
        }

        int getWidth() {
            if (this.thumbBitmap != null) {
                return this.thumbBitmap.getWidth();
            }
            return 0;
        }

        float getLeft() {
            return this.mLeft;
        }

        float getHeight() {
            if (this.thumbBitmap != null) {
                return this.thumbBitmap.getHeight();
            }
            return 0.0f;
        }
    }

    public void setAxis() {
        Resources res = getResources();
        this.x1 = res.getInteger(R.integer.scroll_x1);
        this.y1 = res.getInteger(R.integer.scroll_y1);
        this.x2 = res.getInteger(R.integer.scroll_x2);
        this.y2 = res.getInteger(R.integer.scroll_y2);
        this.x3 = res.getInteger(R.integer.scroll_x3);
        this.y3 = res.getInteger(R.integer.scroll_y3);
        this.curveEquation = solveLinearEquation(this.x1, this.y1, this.x2, this.y2, this.x3, this.y3);
        initScrollbar();
    }

    @Override // com.htc.launcher.Workspace.OnSlideListener
    public void onScrollTo(float x, float y, int scrollRange, int screenWidth) {
        float pos = x / scrollRange;
        moveThumbTo(pos);
    }

    @Override // com.htc.launcher.Workspace.OnSlideListener
    public void onFling(int x, int begin, int end) {
    }

    @Override // com.htc.launcher.Workspace.OnSlideListener
    public void onTouch(MotionEvent ev, int x) {
    }
}
