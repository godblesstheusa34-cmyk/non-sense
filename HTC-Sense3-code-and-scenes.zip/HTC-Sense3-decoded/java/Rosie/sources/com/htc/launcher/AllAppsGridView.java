package com.htc.launcher;

import android.content.ComponentName;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.Toast;
import com.htc.launcher.AllAppsView;
import com.htc.launcher.Launcher;
import com.htc.launcher.custom.CustomResourceUtil;
import com.htc.launcher.settings.SettingUtil;
import com.htc.widget.HtcAdapterView;
import com.htc.widget.PagedGridView;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
class AllAppsGridView extends PagedGridView implements HtcAdapterView.OnItemClickListener, HtcAdapterView.OnItemLongClickListener, AllAppsView.Content {
    private float mBeforeY;
    private AllAppsView mContainer;
    private Paint mPaint;
    private Bitmap mTexture;
    private int mTextureHeight;
    private int mTextureWidth;

    /* JADX WARN: Multi-variable type inference failed */
    public AllAppsGridView(Context context) {
        super(context);
        this.mBeforeY = 0.0f;
        setChildrenDrawnWithCacheEnabled(true);
        setAlwaysDrawnWithCacheEnabled(true);
        setFocusable(false);
        setNumColumns(numColumns());
    }

    /* JADX WARN: Multi-variable type inference failed */
    public AllAppsGridView(Context context, AttributeSet attrs) {
        this(context, attrs, android.R.attr.gridViewStyle);
        setChildrenDrawnWithCacheEnabled(true);
        setAlwaysDrawnWithCacheEnabled(true);
        setFocusable(false);
        setNumColumns(numColumns());
    }

    /* JADX WARN: Multi-variable type inference failed */
    public AllAppsGridView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mBeforeY = 0.0f;
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.AllAppsGridView, defStyle, 0);
        int textureId = a.getResourceId(0, 0);
        if (textureId != 0) {
            this.mTexture = BitmapFactory.decodeResource(getResources(), textureId);
            this.mTextureWidth = this.mTexture.getWidth();
            this.mTextureHeight = this.mTexture.getHeight();
            this.mPaint = new Paint();
            this.mPaint.setDither(false);
        }
        a.recycle();
        setChildrenDrawnWithCacheEnabled(true);
        setAlwaysDrawnWithCacheEnabled(true);
        setFocusable(false);
        setHorizontalSpacing(getResources().getDimensionPixelSize(R.dimen.all_program_grid_view_horizontal_spacing));
        setNumColumns(numColumns());
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onFinishInflate() {
        setOnItemClickListener(this);
        setOnItemLongClickListener(this);
        setSelector(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "rosie_grid_selector", R.drawable.grid_selector));
        setFocusableInTouchMode(false);
        Resources res = getContext().getResources();
        int ITEMS_PER_ROW = res.getInteger(R.integer.allprogram_grid_columns);
        int ROWS_PER_PAGE = res.getInteger(R.integer.allprogram_grid_rows);
        int ITEMS_PER_PAGE = ITEMS_PER_ROW * ROWS_PER_PAGE;
        setItemsPerPage(ITEMS_PER_PAGE);
        setGapBetweenPageAndRow(3);
    }

    public void layoutChildren() {
        try {
            super.layoutChildren();
        } catch (NullPointerException npe) {
            Log.e("Rosie", "Error: null pointer during GridView layout", npe);
        }
    }

    public void onItemClick(HtcAdapterView parent, View v, int position, long id) {
        ApplicationInfo app = (ApplicationInfo) parent.getItemAtPosition(position);
        TFC.d("AllAppsGridView", "onItemClick: pos=" + position + " app.title=" + ((Object) app.title));
        Launcher launcher = this.mContainer.getLauncher();
        ComponentName cpn = app.intent.getComponent();
        if (cpn != null && "com.htc.searchanywhere/.SearchActivity".equals(cpn.flattenToShortString())) {
            app.intent.putExtra("launch_flag", 3);
        }
        if (launcher.currentAppTab == Launcher.AppTabType.allApp) {
            launcher.launchAppType = "All_apps";
        } else if (launcher.currentAppTab == Launcher.AppTabType.downloaded) {
            launcher.launchAppType = "Downloaded";
        } else if (launcher.currentAppTab == Launcher.AppTabType.frequent) {
            launcher.launchAppType = "Frequent";
        }
        launcher.startActivitySafely(app.intent);
    }

    private boolean isFolderOpenedInCurrentScreen() {
        Workspace workspace = this.mContainer.getLauncher().getWorkspace();
        Folder open = workspace.getOpenFolder();
        return open != null && (open instanceof UserFolder);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public boolean onItemLongClick(HtcAdapterView<?> parent, View view, int position, long id) {
        if (!view.isInTouchMode()) {
            return false;
        }
        Workspace workspace = this.mContainer.getLauncher().getWorkspace();
        if (workspace == null) {
            return true;
        }
        workspace.invalidateVacant();
        if (!isFolderOpenedInCurrentScreen() && !workspace.hasRoomForSpan(1, 1)) {
            workspace.invalidateVacant();
            Toast.makeText(getContext(), this.mContainer.getResources().getString(R.string.out_of_space), 0).show();
            return true;
        }
        workspace.invalidateVacant();
        ApplicationInfo app = new ApplicationInfo((ApplicationInfo) parent.getItemAtPosition(position));
        app.title = translateAppTitle((String) app.title, getContext());
        FxItem fxItem = (FxItem) app.createItem(this.mContainer.getLauncher(), null);
        Logger.d("AllAppsGridView", "[APPS] Info:" + fxItem.getInfo());
        View icon = this.mContainer.prepareDragView(app.title, app.icon);
        RectF bounds = this.mContainer.getLauncher().getDesktopItemController().getExternalFloatingBounds(icon);
        this.mContainer.getLauncher().getDesktopItemController().startDragFxWidget(this.mContainer, fxItem, bounds);
        workspace.closeAllOpenLiveFolder();
        this.mContainer.getLauncher().closeAllApplications();
        return false;
    }

    public static String translateAppTitle(String appTitle, Context ctx) {
        return appTitle;
    }

    @Override // com.htc.launcher.AllAppsView.Content
    public void setContainer(AllAppsView container) {
        this.mContainer = container;
    }

    public boolean onTouchEvent(MotionEvent ev) {
        int action = ev.getAction();
        switch (action) {
            case 0:
                this.mBeforeY = ev.getY();
                break;
            case 2:
                if (Math.abs(this.mBeforeY - ev.getY()) < 2.0f) {
                    return true;
                }
                this.mBeforeY = ev.getY();
                break;
        }
        return super.onTouchEvent(ev);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void updateOrientation(boolean portrait) {
        setNumColumns(numColumns());
        if (SettingUtil.isTabletDevice()) {
            setPadding(getResources().getDimensionPixelOffset(R.dimen.application_grid_left_padding), getResources().getDimensionPixelOffset(R.dimen.application_boxed_padding_top), getResources().getDimensionPixelOffset(R.dimen.application_grid_right_padding), 0);
        }
    }

    public void setFilterText(String filterText) {
        if (filterText != null && (getAdapter() instanceof Filterable)) {
            Filter f = ((Filterable) getAdapter()).getFilter();
            f.filter(filterText);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private int numColumns() {
        Resources res = getContext().getResources();
        return res.getConfiguration().orientation == 1 ? getResources().getInteger(R.integer.allprogram_grid_columns) : getResources().getInteger(R.integer.allprogram_land_grid_columns);
    }
}
