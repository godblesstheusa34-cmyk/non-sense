package com.htc.launcher;

import android.content.Context;
import android.os.Debug;
import android.util.Log;
import com.htc.launcher.settings.SettingUtil;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class OrientationMonitor {
    private static final String LOG_TAG = "[OrientationKPI]";
    private static final String TRACE_PATH = "/sdcard/rosie_orientation";
    public static boolean localLOGD = SettingUtil.localLOGD;
    private boolean isUseTraceView;
    private Context mContext;
    private FileOutputStream mOrientationLogOutput;
    private boolean mOrientationMonitor;
    private long mTimeOnConfigurationChanged = -1;
    private long mTimeOnOrientationChanged = -1;
    private long mTimeEnd = -1;
    private long mBeginWorkspaceOnMeasure = -1;
    private long mEndWorkspaceOnMeasure = -1;
    private long mBeginDispatchDraw = -1;
    private long mEndDispatchDraw = -1;
    private ArrayList<String> mOnConfigurationChanged = new ArrayList<>();
    private ArrayList<Long> mWorkspaceOnMeasure = new ArrayList<>();
    private ArrayList<Long> mWorkspaceDispatchDraw = new ArrayList<>();

    public OrientationMonitor(Context context) {
        this.mOrientationMonitor = false;
        this.isUseTraceView = false;
        this.mContext = context;
        File file = new File("/data/data/", "OrientationMonitor");
        if (file.exists()) {
            this.mOrientationMonitor = true;
            if (localLOGD) {
                Log.d(LOG_TAG, "enable OrientationMonitor");
            }
        }
        File file2 = new File("/data/data/", "TraceView");
        if (file2.exists()) {
            this.isUseTraceView = true;
            if (localLOGD) {
                Log.d(LOG_TAG, "enable traceView");
            }
        }
    }

    public void onConfigurationChanged() {
        if (this.mOrientationMonitor) {
            this.mTimeOnConfigurationChanged = System.currentTimeMillis();
        }
    }

    public void addOnConfigurationChanged() {
        if (this.mTimeOnConfigurationChanged >= 0 && this.mOrientationMonitor) {
            this.mOnConfigurationChanged.add("onOrientationChanged(Rosie) - " + (System.currentTimeMillis() - this.mTimeOnConfigurationChanged));
        }
    }

    public void onOrientationChanged(boolean isOrientationChanged) {
        if (this.mOrientationMonitor) {
            if (isOrientationChanged) {
                this.mTimeOnOrientationChanged = System.currentTimeMillis();
            } else {
                this.mTimeOnConfigurationChanged = -1L;
            }
        }
    }

    public void beginWorkspaceOnMeasure() {
        if (this.mTimeOnConfigurationChanged >= 0 && this.mOrientationMonitor) {
            if (localLOGD) {
                Log.d(LOG_TAG, "beginWorkspaceOnMeasure()");
            }
            this.mBeginWorkspaceOnMeasure = System.currentTimeMillis();
        }
    }

    public void endWorkspaceOnMeasure() {
        if (this.mTimeOnConfigurationChanged >= 0 && this.mOrientationMonitor) {
            if (localLOGD) {
                Log.d(LOG_TAG, "endWorkspaceOnMeasure()");
            }
            this.mEndWorkspaceOnMeasure = System.currentTimeMillis();
            this.mWorkspaceOnMeasure.add(Long.valueOf(this.mEndWorkspaceOnMeasure - this.mBeginWorkspaceOnMeasure));
        }
    }

    public void beginDispatchDraw() {
        if (this.mTimeOnConfigurationChanged >= 0 && this.mOrientationMonitor) {
            if (localLOGD) {
                Log.d(LOG_TAG, "beginDispatchDraw()");
            }
            this.mBeginDispatchDraw = System.currentTimeMillis();
        }
    }

    public void endDispatchDraw() {
        if (this.mTimeOnConfigurationChanged >= 0 && this.mOrientationMonitor) {
            if (localLOGD) {
                Log.d(LOG_TAG, "endDispatchDraw()");
            }
            this.mEndDispatchDraw = System.currentTimeMillis();
            this.mWorkspaceDispatchDraw.add(Long.valueOf(this.mEndDispatchDraw - this.mBeginDispatchDraw));
        }
    }

    public void end() {
        if (this.mTimeOnConfigurationChanged >= 0 && this.mOrientationMonitor) {
            if (localLOGD) {
                Log.d(LOG_TAG, "end()");
            }
            this.mTimeEnd = System.currentTimeMillis();
            if (this.isUseTraceView) {
                Debug.stopMethodTracing();
            }
            refreshFile();
            try {
                StringBuffer buffer = new StringBuffer();
                buffer.append(">>>>> time diff");
                Iterator i$ = this.mOnConfigurationChanged.iterator();
                while (i$.hasNext()) {
                    String data = i$.next();
                    buffer.append("\n" + data);
                }
                buffer.append("\nonOrientationChanged(Total) - " + (this.mTimeOnOrientationChanged - this.mTimeOnConfigurationChanged));
                Iterator i$2 = this.mWorkspaceOnMeasure.iterator();
                while (i$2.hasNext()) {
                    Long data2 = i$2.next();
                    buffer.append("\nWorkspace.onMeasure(Total) - " + data2);
                }
                Iterator i$3 = this.mWorkspaceDispatchDraw.iterator();
                while (i$3.hasNext()) {
                    Long data3 = i$3.next();
                    buffer.append("\nWorkspace.dispatchDraw(Total) - " + data3);
                }
                buffer.append("\nTotal - " + (this.mTimeEnd - this.mTimeOnConfigurationChanged));
                buffer.append("\n\n>>>>> processes");
                if (localLOGD) {
                    Log.d(LOG_TAG, "\n" + buffer.toString());
                }
                this.mOrientationLogOutput.write(buffer.toString().getBytes());
                this.mOrientationLogOutput.close();
            } catch (IOException e) {
                if (localLOGD) {
                    Log.d(LOG_TAG, e.getMessage(), e);
                }
            }
            clean();
        }
    }

    private void refreshFile() {
        if (this.mTimeOnConfigurationChanged >= 0 && this.mOrientationMonitor) {
            try {
                this.mOrientationLogOutput = this.mContext.openFileOutput("orien_" + this.mTimeOnConfigurationChanged + ".txt", 0);
            } catch (IOException e) {
                Log.e(LOG_TAG, e.getMessage(), e);
            }
        }
    }

    private void clean() {
        this.mTimeOnConfigurationChanged = -1L;
        this.mTimeOnOrientationChanged = -1L;
        this.mOnConfigurationChanged.clear();
        this.mWorkspaceOnMeasure.clear();
    }

    public void addOnConfigurationChanged(Object component, long diff) {
        if (this.mTimeOnConfigurationChanged >= 0 && this.mOrientationMonitor) {
            this.mOnConfigurationChanged.add("onOrientationChanged(" + component + ") - " + diff);
        }
    }
}
