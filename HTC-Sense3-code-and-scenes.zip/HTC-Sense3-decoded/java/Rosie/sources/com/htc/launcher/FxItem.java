package com.htc.launcher;

import android.graphics.Point;
import android.graphics.Rect;
import android.view.View;
import com.htc.fusion.fx.FxScene;
import com.htc.launcher.Draggee;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class FxItem implements Draggee {
    private Draggee mDraggee;
    private ItemInfo mInfo;
    private FxScene mScene;
    private FxScene mSceneOther;

    protected FxItem(FxScene scene, ItemInfo info) {
        this.mScene = scene;
        this.mInfo = info;
    }

    public FxItem(ItemInfo aInfo, Draggee aDraggee) {
        this((FxScene) null, aInfo);
        setDraggee(aDraggee);
    }

    static FxItem create(FxScene scene, ItemInfo info) {
        FxItem item = new FxItem(scene, info);
        return item;
    }

    public Draggee getDraggee() {
        return this.mDraggee;
    }

    public void setDraggee(Draggee draggee) {
        this.mDraggee = draggee;
    }

    public FxScene getScene() {
        return this.mScene;
    }

    public void setOtherScene(FxScene scene) {
        this.mSceneOther = scene;
    }

    public FxScene getOtherScene() {
        return this.mSceneOther;
    }

    public ItemInfo getInfo() {
        return this.mInfo;
    }

    public void setScene(FxScene scene) {
        this.mScene = scene;
    }

    @Override // com.htc.launcher.Draggee
    public Object getItem() {
        return this.mDraggee.getItem();
    }

    @Override // com.htc.launcher.Draggee
    public ItemInfo getItemInfo() {
        if (this.mDraggee == null) {
            return null;
        }
        return this.mDraggee.getItemInfo();
    }

    @Override // com.htc.launcher.Draggee
    public Point getCellXY() {
        if (this.mDraggee == null) {
            return null;
        }
        return this.mDraggee.getCellXY();
    }

    @Override // com.htc.launcher.Draggee
    public Rect getRectInPixels() {
        if (this.mDraggee == null) {
            return null;
        }
        return this.mDraggee.getRectInPixels();
    }

    @Override // com.htc.launcher.Draggee
    public void onDrop(DropTarget target, int cellX, int cellY) {
        if (this.mDraggee != null) {
            this.mDraggee.onDrop(target, cellX, cellY);
        }
    }

    @Override // com.htc.launcher.Draggee
    public void onDrag() {
        if (this.mDraggee != null) {
            this.mDraggee.onDrag();
        }
    }

    @Override // com.htc.launcher.Draggee
    public void onDropAbort(DragSource source) {
        if (this.mDraggee != null) {
            this.mDraggee.onDropAbort(source);
        }
    }

    static FxItem create(FxScene scene, View view, ItemInfo info) {
        FxItem legacy = new FxItem(scene, info);
        legacy.mDraggee = Draggee.LegacyDraggee.wrap(view);
        return legacy;
    }

    public void onBeforeDrag() {
    }
}
