package com.htc.launcher;

import android.appwidget.AppWidgetHost;
import android.appwidget.AppWidgetHostView;
import android.appwidget.AppWidgetProviderInfo;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class LauncherAppWidgetHost extends AppWidgetHost {
    private static final String LOG_TAG = "LauncherAppWidgetHost";
    private Context mContext;
    boolean mListening;
    private static final String ACTION_RESUME_APP_WIDGETS = "com.htc.content.Intent.ACTION_RESUME_APP_WIDGETS";
    private static final Intent sResumeAppWidgetsIntent = new Intent(ACTION_RESUME_APP_WIDGETS);
    private static final String ACTION_PAUSE_APP_WIDGETS = "com.htc.content.Intent.ACTION_PAUSE_APP_WIDGETS";
    private static final Intent sPauseAppWidgetsIntent = new Intent(ACTION_PAUSE_APP_WIDGETS);

    public LauncherAppWidgetHost(Context context, int hostId) {
        super(context, hostId);
        this.mListening = false;
        this.mContext = context;
    }

    @Override // android.appwidget.AppWidgetHost
    protected AppWidgetHostView onCreateView(Context context, int appWidgetId, AppWidgetProviderInfo appWidget) {
        return new LauncherAppWidgetHostView(context);
    }

    @Override // android.appwidget.AppWidgetHost
    public void startListening() {
        if (!this.mListening) {
            this.mListening = true;
            try {
                super.startListening();
            } catch (Exception ex) {
                Log.w(LOG_TAG, "fail to start listening - " + ex.getMessage());
            }
            this.mContext.sendBroadcast(sResumeAppWidgetsIntent);
        }
    }

    @Override // android.appwidget.AppWidgetHost
    public void stopListening() {
        if (this.mListening) {
            try {
                this.mContext.sendBroadcast(sPauseAppWidgetsIntent);
                super.stopListening();
            } catch (NullPointerException e) {
            }
            this.mListening = false;
        }
    }
}
