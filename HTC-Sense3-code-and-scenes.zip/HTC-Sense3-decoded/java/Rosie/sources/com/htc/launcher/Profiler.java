package com.htc.launcher;

import android.util.Log;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class Profiler {
    private static boolean sIsRecorded = true;
    private static long sStart;

    static void start() {
        sIsRecorded = false;
        sStart = System.currentTimeMillis();
    }

    static void stop(boolean once, String log) {
        if (once) {
            if (!sIsRecorded) {
                sIsRecorded = true;
            } else {
                return;
            }
        }
        long current = System.currentTimeMillis();
        Log.d("PERF", log + " " + (current - sStart));
    }
}
