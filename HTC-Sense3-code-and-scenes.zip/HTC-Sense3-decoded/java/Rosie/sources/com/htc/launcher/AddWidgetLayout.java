package com.htc.launcher;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewSwitcher;
import com.htc.launcher.AddAdapter;
import com.htc.launcher.AllAppsView;
import com.htc.launcher.Launcher;
import com.htc.launcher.custom.CustomResourceUtil;
import com.htc.launcher.settings.SettingUtil;
import com.htc.widget.HtcAbsListView;
import com.htc.widget.HtcAdapterView;
import com.htc.widget.HtcListView;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public final class AddWidgetLayout extends ViewSwitcher implements AllAppsView.Content {
    private AddListAdapter mAdapter;
    AllAppsView mContainer;
    private View mListLayout;
    private OnAddWidgetListener mOnAddWidgetListener;
    private Launcher.PersonalizeOnItemClickListener mOnPersonalizeItemClickListener;
    private HtcListView mProgramList;
    private TextView mTitle;
    private TextView mTitle_shade;

    public interface OnAddWidgetListener {
        void onItemClick(HtcAdapterView<?> htcAdapterView, View view, int i, long j);
    }

    public AddWidgetLayout(Context context) {
        this(context, null);
    }

    public AddWidgetLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mAdapter = null;
    }

    @Override // android.view.View, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return false;
    }

    public void setAdapter(AddListAdapter a) {
        this.mAdapter = a;
        if (this.mProgramList != null) {
            this.mProgramList.setAdapter(this.mAdapter);
        }
    }

    public void updateContentView(boolean doTransition) {
        removeAllViews();
        if (this.mListLayout == null) {
            LayoutInflater inflater = (LayoutInflater) ((View) this).mContext.getSystemService("layout_inflater");
            this.mListLayout = inflater.inflate(R.layout.program_list, (ViewGroup) null);
        }
        addView(this.mListLayout);
        if (this.mTitle != null && this.mTitle_shade != null) {
            if (this.mAdapter == null) {
                this.mTitle.setText(R.string.add_to_home);
                this.mTitle_shade.setText(R.string.add_to_home);
            } else {
                doCheckTitle();
            }
            this.mTitle.setVisibility(0);
            this.mTitle_shade.setVisibility(0);
        }
        if (this.mProgramList == null) {
            this.mProgramList = this.mListLayout.findViewById(R.id.program_list);
            if (this.mProgramList != null) {
                if (this.mAdapter != null) {
                    this.mProgramList.setAdapter(this.mAdapter);
                }
                this.mProgramList.setOnItemClickListener(new AddOnClickListener());
                ColorDrawable color = new ColorDrawable(-16777216);
                this.mProgramList.setListBackground(color);
                this.mProgramList.setSelector(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "rosie_list_selector", R.drawable.list_selector));
                this.mProgramList.setTextFilterEnabled(false);
                this.mProgramList.setVerticalScrollBarEnabled(false);
                this.mProgramList.setOnScrollListener(new HtcAbsListView.OnScrollListener() { // from class: com.htc.launcher.AddWidgetLayout.1
                    public void onScroll(HtcAbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                    }

                    public void onScrollStateChanged(HtcAbsListView view, int scrollState) {
                        if (scrollState == 0) {
                            AddWidgetLayout.this.mProgramList.setVerticalScrollBarEnabled(false);
                        } else {
                            AddWidgetLayout.this.mProgramList.setVerticalScrollBarEnabled(true);
                        }
                    }
                });
                this.mProgramList.setTopBorderHeight(0);
            }
        }
    }

    private class AddOnClickListener implements HtcAdapterView.OnItemClickListener {
        private AddOnClickListener() {
        }

        public void onItemClick(HtcAdapterView<?> parent, View view, int position, long id) {
            Object tag = view.getTag();
            if (tag instanceof AddAdapter.ListItem) {
                AddAdapter.ListItem item = (AddAdapter.ListItem) tag;
                if (item.actionTag != -2) {
                    if (item.actionTag == -1 || item.actionTag == 105) {
                        Launcher launcher = Launcher.sRefLauncher.get();
                        if (!SettingUtil.isTabletDevice() || !launcher.isAddButtonbar()) {
                            Workspace workspace = AddWidgetLayout.this.mContainer.getLauncher().getWorkspace();
                            if (workspace != null) {
                                workspace.invalidateVacant();
                                if (!workspace.hasRoomForSpan(1, 1)) {
                                    workspace.invalidateVacant();
                                    Toast.makeText(AddWidgetLayout.this.getContext(), AddWidgetLayout.this.mContainer.getResources().getString(R.string.out_of_space), 0).show();
                                    return;
                                }
                            } else {
                                return;
                            }
                        }
                        parent.postInvalidateDelayed(150L);
                        AddWidgetLayout.this.mAdapter.setClick(item.mNextAdapter, position);
                        AddWidgetLayout.this.doCheckTitle();
                        return;
                    }
                    if (item.actionTag != 200 && item.actionTag != 104) {
                        if (item.actionTag == 103) {
                            if (AddWidgetLayout.this.mOnPersonalizeItemClickListener != null) {
                                AddWidgetLayout.this.mOnPersonalizeItemClickListener.onItemClick(parent, view, position, id);
                            }
                        } else if (AddWidgetLayout.this.mOnAddWidgetListener != null) {
                            AddWidgetLayout.this.mOnAddWidgetListener.onItemClick(parent, view, position, id);
                        }
                    }
                }
            }
        }
    }

    public void setAddWidgetListener(OnAddWidgetListener l) {
        this.mOnAddWidgetListener = l;
    }

    public void setPersonalizeOnItemClickListener(Launcher.PersonalizeOnItemClickListener onClickListener) {
        this.mOnPersonalizeItemClickListener = onClickListener;
    }

    public void setTitleTextView(TextView title, TextView titleShade) {
        this.mTitle = title;
        this.mTitle_shade = titleShade;
    }

    public void doCheckTitle() {
        if (this.mTitle_shade != null && this.mTitle != null && this.mAdapter != null) {
            this.mTitle.setText(this.mAdapter.getTitleString());
            this.mTitle_shade.setText(this.mAdapter.getTitleString());
        }
        if (this.mProgramList != null && this.mAdapter != null) {
            this.mProgramList.setSelectionFromTop(this.mAdapter.getKeepPosition(), (int) ((View) this).mContext.getResources().getDimension(R.dimen.add_to_home_top_height));
        }
    }

    public void setTitle(String title) {
        if (this.mTitle != null && this.mTitle_shade != null) {
            this.mTitle.setText(title);
            this.mTitle_shade.setText(title);
        }
    }

    public void setFilterText(String text) {
    }

    public void setScrollingCacheEnabled(boolean bool) {
    }

    @Override // android.view.View
    public void setFadingEdgeLength(int length) {
    }

    public void setTextFilterEnabled(boolean bool) {
    }

    public void clearTextFilter() {
    }

    public void setAdapter(ListAdapter adapter) {
    }

    public void setSelection(int position) {
        if (this.mProgramList != null) {
            this.mProgramList.setSelection(position);
        }
    }

    @Override // com.htc.launcher.AllAppsView.Content
    public void setContainer(AllAppsView container) {
        this.mContainer = container;
    }
}
