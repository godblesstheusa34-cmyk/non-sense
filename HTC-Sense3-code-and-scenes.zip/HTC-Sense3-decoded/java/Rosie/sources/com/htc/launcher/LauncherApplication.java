package com.htc.launcher;

import android.app.Application;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class LauncherApplication extends Application {
    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
    }
}
