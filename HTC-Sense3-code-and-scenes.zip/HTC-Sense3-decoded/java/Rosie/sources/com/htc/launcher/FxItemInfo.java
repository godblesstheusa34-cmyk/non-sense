package com.htc.launcher;

import android.content.ComponentName;
import android.content.ContentValues;
import android.util.Log;
import android.view.ViewGroup;
import com.android.common.speech.LoggingEvents;
import com.htc.android.rosie.home.HostWidgetManager;
import com.htc.launcher.LauncherSettings;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Properties;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class FxItemInfo extends ItemInfo {
    private static final String LOG_TAG = FxItemInfo.class.getSimpleName();
    public byte[] data;
    public String name;
    public String provider;
    public int widgetId;

    FxItemInfo(ComponentName provider, ComponentName name) {
        this.itemType = 5;
        this.provider = provider.flattenToShortString();
        this.name = name.flattenToShortString();
    }

    public FxItemInfo(String provider, String name) {
        this.itemType = 5;
        this.provider = provider;
        this.name = name;
    }

    FxItemInfo(HostWidgetManager.WidgetInfo info) {
        this(info.getProvider(), info.getName());
        this.provider = info.getProvider().flattenToShortString();
        this.name = info.getName().flattenToShortString();
        this.spanX = info.getSpanX();
        this.spanY = info.getSpanY();
        this.screen = info.getContainerId();
        this.cellX = info.getX();
        this.cellY = info.getY();
        this.widgetId = info.getId();
        this.id = info.getStoreId();
        if (info.getContainerId() != -1) {
            this.container = -100L;
        }
        Properties p = info.getData();
        if (p != null) {
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                ObjectOutputStream out2 = new ObjectOutputStream(out);
                out2.writeObject(p);
                this.data = out.toByteArray();
            } catch (Exception e) {
                Log.e(LOG_TAG, "fail to convert properties to byte array" + e.getMessage(), e);
                this.data = null;
            }
        }
    }

    FxItemInfo(FxItemInfo info) {
        super(info);
        this.itemType = 5;
        this.provider = info.provider;
        this.name = info.name;
        this.data = info.data;
    }

    public HostWidgetManager.WidgetInfo toWidgetInfo() {
        HostWidgetManager.WidgetInfo wi = new HostWidgetManager.WidgetInfo(ComponentName.unflattenFromString(this.provider), ComponentName.unflattenFromString(this.name), this.spanX, this.spanY, this.widgetId, this.screen, this.cellX, this.cellY);
        wi.setStoreId(this.id);
        if (this.data != null && this.data.length > 0) {
            try {
                ByteArrayInputStream in = new ByteArrayInputStream(this.data);
                ObjectInputStream in2 = new ObjectInputStream(in);
                Properties p = (Properties) in2.readObject();
                wi.saveData(p);
            } catch (Exception e) {
                Log.e(LOG_TAG, "Fail to convert byte array to properties" + e.getMessage(), e);
            }
        }
        return wi;
    }

    @Override // com.htc.launcher.ItemInfo
    void onAddToDatabase(ContentValues values) {
        super.onAddToDatabase(values);
        values.put("intent", this.provider);
        values.put("uri", this.name);
        values.put("appWidgetId", Integer.valueOf(this.widgetId));
        if (this.data != null) {
            values.put(LauncherSettings.Favorites.PROPS, this.data);
        }
    }

    @Override // com.htc.launcher.ItemInfo
    public String toString() {
        return new String("Fusion widget: provider=(" + this.provider + ") name=(" + this.name + ") ID=(" + this.widgetId + ") info:" + super.toString());
    }

    @Override // com.htc.launcher.ItemInfo
    public Draggee createItem(Launcher launcher, ViewGroup container) {
        return null;
    }

    @Override // com.htc.launcher.ItemInfo
    public boolean isItemEditable() {
        return true;
    }

    @Override // com.htc.launcher.ItemInfo
    public String getUlog() {
        String ret = this.name + ", htcfxwidget, " + this.screen + ", " + this.cellX + ", " + this.cellY + ", " + this.spanX + ", " + this.spanY;
        if (this.screen < 0 || this.screen > max_screen) {
            return LoggingEvents.EXTRA_CALLING_APP_NAME;
        }
        return ret;
    }

    @Override // com.htc.launcher.ItemInfo
    public long getId() {
        return this.widgetId;
    }
}
