package com.htc.launcher;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.view.ViewGroup;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class LiveFolderIcon extends FolderIcon {
    public LiveFolderIcon(ItemInfo info, int orientation) {
        super(info, orientation);
    }

    /* JADX WARN: Multi-variable type inference failed */
    static Draggee fromXml(int resId, Launcher launcher, ViewGroup group, LiveFolderInfo folderInfo) {
        LiveFolderIcon folderIcon = new LiveFolderIcon(folderInfo, launcher.getOrientation());
        Resources resources = launcher.getResources();
        Drawable d = folderInfo.icon;
        if (d == null) {
            resources.getDrawable(34079058);
            d = Utilities.createIconThumbnail(d, launcher);
            folderInfo.filtered = true;
        }
        folderIcon.setContents(d, ((FolderInfo) folderInfo).title);
        folderIcon.setOnClickListener(launcher.getDesktopItemController().mOnClickFolderListener);
        return folderIcon;
    }
}
