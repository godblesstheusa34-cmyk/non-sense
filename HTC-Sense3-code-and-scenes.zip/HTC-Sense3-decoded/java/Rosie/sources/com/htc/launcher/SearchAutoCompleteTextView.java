package com.htc.launcher;

import android.app.Activity;
import android.content.Context;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class SearchAutoCompleteTextView extends AutoCompleteTextView {
    private Handler mLoseFocusHandler;
    private boolean mShowKeyboard;

    public SearchAutoCompleteTextView(Context context) {
        super(context);
        this.mLoseFocusHandler = new Handler() { // from class: com.htc.launcher.SearchAutoCompleteTextView.1
            @Override // android.os.Handler
            public void handleMessage(Message msg) {
                if (msg.what == 1 && !SearchAutoCompleteTextView.this.hasFocus()) {
                    InputMethodManager.peekInstance().hideSoftInputFromWindow(SearchAutoCompleteTextView.this.getWindowToken(), 0);
                }
            }
        };
    }

    public SearchAutoCompleteTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mLoseFocusHandler = new Handler() { // from class: com.htc.launcher.SearchAutoCompleteTextView.1
            @Override // android.os.Handler
            public void handleMessage(Message msg) {
                if (msg.what == 1 && !SearchAutoCompleteTextView.this.hasFocus()) {
                    InputMethodManager.peekInstance().hideSoftInputFromWindow(SearchAutoCompleteTextView.this.getWindowToken(), 0);
                }
            }
        };
    }

    public SearchAutoCompleteTextView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mLoseFocusHandler = new Handler() { // from class: com.htc.launcher.SearchAutoCompleteTextView.1
            @Override // android.os.Handler
            public void handleMessage(Message msg) {
                if (msg.what == 1 && !SearchAutoCompleteTextView.this.hasFocus()) {
                    InputMethodManager.peekInstance().hideSoftInputFromWindow(SearchAutoCompleteTextView.this.getWindowToken(), 0);
                }
            }
        };
    }

    @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
    protected void onFocusChanged(boolean gainFocus, int direction, Rect previouslyFocusedRect) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect);
        WindowManager.LayoutParams lp = ((Activity) getContext()).getWindow().getAttributes();
        if (gainFocus) {
            lp.softInputMode = (lp.softInputMode & (-16)) | 1;
        } else {
            lp.softInputMode = (lp.softInputMode & (-16)) | 0;
            this.mLoseFocusHandler.sendEmptyMessage(1);
        }
        if (getWindowToken() != null) {
            WindowManager manager = (WindowManager) getContext().getSystemService("window");
            manager.updateViewLayout(getRootView(), lp);
            if (this.mShowKeyboard) {
                if (getContext().getResources().getConfiguration().hardKeyboardHidden == 2) {
                    InputMethodManager inputManager = (InputMethodManager) getContext().getSystemService("input_method");
                    inputManager.showSoftInput(this, 0);
                }
                this.mShowKeyboard = false;
            }
        }
    }

    @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
    public void onWindowFocusChanged(boolean hasWindowFocus) {
        super.onWindowFocusChanged(hasWindowFocus);
        setFocusableInTouchMode(false);
    }

    void showKeyboardOnNextFocus() {
        this.mShowKeyboard = true;
    }
}
