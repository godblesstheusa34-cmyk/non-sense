package com.htc.launcher;

import android.content.Context;
import android.util.Log;
import android.view.MotionEvent;
import com.htc.launcher.LauncherSettings;
import com.htc.launcher.Workspace;
import com.htc.launcher.settings.SettingUtil;
import com.htc.launcher.widget.EaseInBack;
import com.htc.launcher.widget.EaseOutBack;
import com.htc.launcher.widget.EaseOutCubic;
import com.htc.launcher.widget.EasingFunction;
import com.htc.launcher.widget.HtcScroller;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class SlideController {
    private static final String LOG_TAG = SlideController.class.getSimpleName();
    private ScrollMonitor mScrollMonitor;
    private ArrayList<Workspace.OnSlideListener> mSlideListeners;
    protected Workspace mWorkspace;
    protected EasingFunction mEasingFunction = defaultEasingFunction();
    private ScrollRunnable mScrollRunnable = new ScrollRunnable(true);

    public SlideController(Context context, Workspace workspace) {
        this.mWorkspace = workspace;
    }

    public void slideBy(float deltaX, float scrollX, boolean isPortrait) {
        if (!isPortrait) {
            deltaX *= 2.0f;
        }
        float scrollToX = scrollXConverter(scrollX + deltaX);
        scrollTo(scrollToX, 0.0f);
        if (this.mSlideListeners != null) {
            Iterator i$ = this.mSlideListeners.iterator();
            while (i$.hasNext()) {
                i$.next();
            }
        }
    }

    protected final void scrollTo(float x, float y) {
        this.mWorkspace.updateScrollValue((int) x, (int) y);
        Iterator i$ = this.mSlideListeners.iterator();
        while (i$.hasNext()) {
            Workspace.OnSlideListener listener = i$.next();
            listener.onScrollTo(x, y, this.mWorkspace.getScrollRange(), this.mWorkspace.getWidth());
        }
    }

    public void registerSlideListener(Workspace.OnSlideListener listener) {
        if (this.mSlideListeners == null) {
            this.mSlideListeners = new ArrayList<>();
        }
        this.mSlideListeners.add(listener);
    }

    public void unRegisterWorkspaceScrollListener(Workspace.OnSlideListener listener) {
        if (this.mSlideListeners != null) {
            this.mSlideListeners.remove(listener);
        }
    }

    public int getDestinationScreen(int currentTouchScreen, int velocityX) {
        if (velocityX <= 0) {
            return currentTouchScreen + 1 >= this.mWorkspace.getChildCount() ? currentTouchScreen : currentTouchScreen + 1;
        }
        if (currentTouchScreen == 0) {
            return 0;
        }
        return currentTouchScreen - 1;
    }

    private class ScrollRunnable implements Runnable {
        private static final int FIXED_FPS = 16;
        private boolean isFinished = true;
        private boolean mFixFps;
        private HtcScroller mScroller;

        public ScrollRunnable(boolean fixFps) {
            this.mScroller = new HtcScroller(SlideController.this.mWorkspace.getContext());
            this.mFixFps = fixFps;
        }

        public void startScroll(int startX, int startY, int dx, int dy, int duration, EasingFunction function) {
            this.mScroller.startScroll(startX, startY, dx, dy, duration, function);
            start();
        }

        private void start() {
            this.isFinished = false;
            SlideController.this.mWorkspace.post(this);
        }

        public void stopScroll() {
            this.isFinished = true;
            this.mScroller.abortAnimation();
        }

        public boolean isFinished() {
            return this.isFinished;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (!this.isFinished) {
                HtcScroller scroller = this.mScroller;
                boolean more = scroller.computeScrollOffset();
                if (more) {
                    if (this.mFixFps) {
                        SlideController.this.mWorkspace.postDelayed(this, 16L);
                    }
                    SlideController.this.onScrollProgress(scroller.getScrollingProgress());
                    float x = SlideController.this.scrollXConverter(scroller.getHighPrecisionCurrX());
                    if (SlideController.this.mSlideListeners != null) {
                        Iterator i$ = SlideController.this.mSlideListeners.iterator();
                        while (i$.hasNext()) {
                            Workspace.OnSlideListener listener = (Workspace.OnSlideListener) i$.next();
                            listener.onScrollTo(x, SlideController.this.mWorkspace.getScrollY(), SlideController.this.mWorkspace.getScrollRange(), SlideController.this.mWorkspace.getWidth());
                        }
                    }
                    SlideController.this.mWorkspace.updateScrollValue((int) x, 0);
                    SlideController.this.mWorkspace.updateWallpaperOffset();
                    if (!this.mFixFps) {
                        SlideController.this.mWorkspace.post(this);
                        return;
                    }
                    return;
                }
                if (SlideController.this.mWorkspace.getNextScreen() != -1) {
                    if (!scroller.isAborted()) {
                        SlideController.this.onScrollEnd();
                        int currentScreen = Math.max(0, Math.min(SlideController.this.mWorkspace.getNextScreen(), SlideController.this.mWorkspace.getChildCount() - 1));
                        SlideController.this.mWorkspace.setCurrentScreen(currentScreen);
                        Launcher.setScreen(currentScreen);
                        SlideController.this.mWorkspace.endScroll();
                    }
                    SlideController.this.mWorkspace.setBounceScreen(-1);
                    SlideController.this.mWorkspace.setNextScreen(-1);
                    this.isFinished = true;
                }
            }
        }
    }

    public boolean isSlideFinish() {
        return this.mScrollRunnable.isFinished();
    }

    public void stopSlide() {
        this.mScrollRunnable.stopScroll();
    }

    protected void startSlide(int startX, int startY, int dx, int dy, int duration, EasingFunction function) {
        this.mScrollRunnable.startScroll(startX, startY, dx, dy, duration, function);
    }

    public void snapScreen(int currentTouchScreen, int velocityX) {
        if (isSinking() && velocityX < getKeepSinkVelocity()) {
            currentTouchScreen = getCurrentSinkScreenIndexByScrollX();
        }
        int destinationScreen = getDestinationScreen(currentTouchScreen, velocityX);
        snapToScreen(destinationScreen, velocityX);
    }

    public int snapToDefaultScreen(int whichScreen) {
        this.mWorkspace.beginFling();
        snapToScreen(whichScreen);
        return LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK;
    }

    protected void onScrollProgress(float progress) {
    }

    protected void onScrollEnd() {
    }

    protected boolean isSinking() {
        return false;
    }

    public void snapToScreen(int whichScreen) {
        this.mWorkspace.beginScroll(true, whichScreen);
        int whichScreen2 = Math.max(0, Math.min(whichScreen, this.mWorkspace.getChildCount() - 1));
        this.mWorkspace.setNextScreen(whichScreen2);
        int delta = getDeltaXForSnapScreen(this.mWorkspace.getCurrentScreenIndex(), whichScreen2, 0);
        if (SettingUtil.localLOGD) {
            Log.d(LOG_TAG, "snapToScreen Duration = " + ((int) Math.max(Math.abs(delta) * 1.5d * Workspace.sScrollSpeedScale, 640.0d)) + ", delta = " + delta + ", mScrollSpeedScale = " + Workspace.sScrollSpeedScale);
        }
        startSlide(this.mWorkspace.getScrollX(), 0, delta, 0, (int) Math.max(Math.abs(delta) * 1.5d * Workspace.sScrollSpeedScale, 640.0d), this.mEasingFunction);
    }

    protected int getDeltaXForSnapScreen(int currentScreen, int nextScreen, int velocity) {
        int newX = nextScreen * this.mWorkspace.getWidth();
        int delta = newX - this.mWorkspace.getScrollX();
        return delta;
    }

    protected int getSnapOffset(int velocityX) {
        return 0;
    }

    protected float getKeepSinkVelocity() {
        return 0.0f;
    }

    void snapToScreen(int whichScreen, int velocityX) {
        int delta;
        if (SettingUtil.localLOGD) {
            Log.d(LOG_TAG, "SlideController.snapToScreen(" + whichScreen + ", " + velocityX + ")");
        }
        this.mWorkspace.beginScroll(false, whichScreen);
        int whichScreen2 = Math.max(0, Math.min(whichScreen, this.mWorkspace.getChildCount() - 1));
        this.mWorkspace.setNextScreen(whichScreen2);
        if (isSinking() && velocityX < getKeepSinkVelocity()) {
            delta = getDeltaXForSnapScreen(getCurrentSinkScreenIndexByScrollX(), whichScreen2, velocityX);
        } else {
            delta = getDeltaXForSnapScreen(this.mWorkspace.getCurrentScreenIndexByScrollX(), whichScreen2, velocityX);
        }
        this.mWorkspace.updateSnapInfo(whichScreen2, getSnapOffset(velocityX));
        if (velocityX == 0) {
            if (Math.abs(delta) > 10) {
                if (this.mWorkspace.getScrollX() < 0 || this.mWorkspace.getScrollX() > this.mWorkspace.getWidth() * (this.mWorkspace.getChildCount() - 1)) {
                    startSlide(this.mWorkspace.getScrollX(), 0, delta, 0, Math.max((int) (Math.abs(delta) * SettingUtil.sEaseOutDuration * Workspace.sScrollSpeedScale), 500), new EaseOutCubic());
                    return;
                } else {
                    startSlide(this.mWorkspace.getScrollX(), 0, delta, 0, Math.max((int) (Math.abs(delta) * SettingUtil.sEaseOutBackDuration * Workspace.sScrollSpeedScale), 500), this.mEasingFunction);
                    return;
                }
            }
            if (this.mWorkspace.getScrollX() < 0 || this.mWorkspace.getScrollX() > this.mWorkspace.getWidth() * (this.mWorkspace.getChildCount() - 1)) {
                startSlide(this.mWorkspace.getScrollX(), 0, delta, 0, (int) (Math.abs(delta) * SettingUtil.sEaseOutDuration * Workspace.sScrollSpeedScale), new EaseOutCubic());
                return;
            } else {
                startSlide(this.mWorkspace.getScrollX(), 0, delta, 0, (int) (Math.abs(delta) * SettingUtil.sEaseOutBackDuration * Workspace.sScrollSpeedScale), this.mEasingFunction);
                return;
            }
        }
        if (delta < 0) {
            this.mWorkspace.setBounceScreen(whichScreen2 - 1);
            if (this.mWorkspace.getScrollX() > this.mWorkspace.getWidth() * (this.mWorkspace.getChildCount() - 1) && velocityX < 0) {
                startSlide(this.mWorkspace.getScrollX(), 0, delta, 0, (int) (Math.abs(delta) * SettingUtil.sEaseInBackDuration * Workspace.sScrollSpeedScale), new EaseInBack());
                return;
            } else {
                startScrollByVelocityX(delta, velocityX);
                return;
            }
        }
        this.mWorkspace.setBounceScreen(whichScreen2 + 1);
        if (this.mWorkspace.getScrollX() < 0 && velocityX > 0) {
            startSlide(this.mWorkspace.getScrollX(), 0, delta, 0, (int) (Math.abs(delta) * SettingUtil.sEaseInBackDuration * Workspace.sScrollSpeedScale), new EaseInBack());
        } else {
            startScrollByVelocityX(delta, velocityX);
        }
    }

    protected void startScrollByVelocityX(int delta, int velocityX) {
        int fixedVelocity;
        if (SettingUtil.sFixedScrollVelocity) {
            if (this.mWorkspace.isPortrait()) {
                fixedVelocity = SettingUtil.sFixedScrollDurationPort;
            } else {
                fixedVelocity = SettingUtil.sFixedScrollDurationLand;
            }
            startSlide(this.mWorkspace.getScrollX(), 0, delta, 0, fixedVelocity, this.mEasingFunction);
            return;
        }
        startSlide(this.mWorkspace.getScrollX(), 0, delta, 0, (int) (Math.abs((delta * LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK) / velocityX) * SettingUtil.sEaseOutBackDuration), this.mEasingFunction);
    }

    public void setScrollMonitor(ScrollMonitor scrollMonitor) {
        this.mScrollMonitor = scrollMonitor;
    }

    public boolean scrollLeft() {
        if (this.mWorkspace.getNextScreen() != -1 || !isSlideFinish() || this.mWorkspace.getCurrentScreenIndex() <= 0) {
            return false;
        }
        snapToScreen(this.mWorkspace.getCurrentScreenIndex() - 1);
        return true;
    }

    public boolean scrollRight() {
        if (this.mWorkspace.getNextScreen() != -1 || !isSlideFinish() || this.mWorkspace.getCurrentScreenIndex() >= this.mWorkspace.getChildCount() - 1) {
            return false;
        }
        snapToScreen(this.mWorkspace.getCurrentScreenIndex() + 1);
        return true;
    }

    public void snapToDestination() {
        int screenWidth = this.mWorkspace.getWidth();
        int whichScreen = (this.mWorkspace.getScrollX() + (screenWidth / 2)) / screenWidth;
        snapToScreen(whichScreen, 0);
    }

    private EasingFunction defaultEasingFunction() {
        return SettingUtil.usesRingSlide() ? new EaseOutCubic() : new EaseOutBack();
    }

    public void setCurrntScreen(int currentScreen) {
    }

    public float scrollXConverter(float x) {
        int leftEdge = ((0 - this.mWorkspace.getWidth()) * 4) / 5;
        int rightEdge = (this.mWorkspace.getWidth() * (this.mWorkspace.getChildCount() - 1)) + ((this.mWorkspace.getWidth() * 4) / 5);
        if (x < leftEdge) {
            return leftEdge;
        }
        return x > ((float) rightEdge) ? rightEdge : x;
    }

    public void actionDown(MotionEvent ev) {
        if (this.mSlideListeners != null) {
            Iterator i$ = this.mSlideListeners.iterator();
            while (i$.hasNext()) {
                Workspace.OnSlideListener listener = i$.next();
                listener.onTouch(ev, (int) ev.getX());
            }
        }
    }

    protected int getCurrentScreenIndexByScrollX() {
        int width = this.mWorkspace.getWidth();
        if (width <= 0) {
            return this.mWorkspace.getCurrentScreenIndex();
        }
        int page = (this.mWorkspace.getScrollX() + (this.mWorkspace.getWidth() / 2)) / this.mWorkspace.getWidth();
        if (page >= this.mWorkspace.getChildCount()) {
            page = this.mWorkspace.getChildCount() - 1;
        }
        return page;
    }

    protected int getCurrentSinkScreenIndexByScrollX() {
        int width = this.mWorkspace.getWidth();
        if (width <= 0) {
            return this.mWorkspace.getCurrentScreenIndex();
        }
        int page = this.mWorkspace.getScrollX() / this.mWorkspace.getWidth();
        if (page >= this.mWorkspace.getChildCount()) {
            page = this.mWorkspace.getChildCount() - 1;
        }
        return page;
    }
}
