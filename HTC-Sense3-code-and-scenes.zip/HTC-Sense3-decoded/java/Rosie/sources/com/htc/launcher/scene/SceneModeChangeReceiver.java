package com.htc.launcher.scene;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import com.htc.launcher.Launcher;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class SceneModeChangeReceiver extends BroadcastReceiver {
    public static final String ACTION_ASPECT_CHANGED = "com.htc.launcher.scene.ACTION_ASPECT_CHANGED";
    public static final String EXTRA_ASPECT_ISTHUMB = "EXTRA_ASPECT_ISTHUMB";
    private static final String KEY_SCENE_IS_PICKER_MODE = "scene_picker_mode";

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        boolean isPanelMode = intent.getBooleanExtra(EXTRA_ASPECT_ISTHUMB, true);
        if (Launcher.localLOGD) {
            Log.d("SceneModeChangeReceiver", "onReceive(" + isPanelMode + ")");
        }
        SharedPreferences preference = context.getSharedPreferences("launcher", 0);
        SharedPreferences.Editor editor = preference.edit();
        editor.putBoolean(KEY_SCENE_IS_PICKER_MODE, isPanelMode);
        editor.apply();
    }
}
