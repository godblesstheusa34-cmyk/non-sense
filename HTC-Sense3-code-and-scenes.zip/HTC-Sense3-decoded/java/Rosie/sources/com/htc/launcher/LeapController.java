package com.htc.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.animation.DecelerateInterpolator;
import com.htc.launcher.LauncherSettings;
import com.htc.launcher.settings.SettingUtil;
import com.htc.launcher.widget.GestureDetector;
import com.htc.launcher.widget.HtcScroller;
import com.htc.utils.ulog.ReusableULogData;
import com.htc.utils.ulog.ULog;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class LeapController implements DragLeaper {
    private static final int LEAP_FINE_TUNE_ZOOM_IN_ANIMATION_DURATION = 350;
    private static final String TAG = "LeapMode";
    public static final int TOUCH_EVENT_HOLDER_MULTI_TOUCH = 2;
    public static final int TOUCH_EVENT_HOLDER_NON = 0;
    public static final int TOUCH_EVENT_HOLDER_SCROLLING = 1;
    private static final int ZOOM_IN_ANIMATION_DURATION = 500;
    private static final int ZOOM_OUT_ANIMATION_DURATION = 500;
    private Context mContext;
    private GestureDetector mGestureDetector;
    private ArrayList<LeapAnimationPlayer> mLeapAnimationPlayers;
    private LeapLayer mLeapLayer;
    private ArrayList<LeapListener> mLeapListeners;
    private Bitmap mRearrangeIndicator;
    private Rect mRearrangeRect;
    private int mVirtualScrollX;
    private static final boolean DEBUG_TOUCH = false;
    private static float sThumbnailScaleHorizontalRatio = 4.0f;
    private static float sThumbnailScaleVerticalRatio = 4.0f;
    private boolean mIsLeapMode = false;
    private Handler mHandler = new Handler();
    private int mTouchEventHolder = 0;
    private int mSelectPage = 3;
    private boolean mRearrange = false;
    private boolean mPlayingZoomOutAnimation = false;
    private boolean mPlayingZoomInAnimation = false;
    private ZoomDirection mZoomDirection = ZoomDirection.NONE;
    public int mAnimationProgress = 0;
    private GestureDetector.OnMultiTouchListener mGestureListener = new GestureDetector.OnMultiTouchListener() { // from class: com.htc.launcher.LeapController.1
        @Override // com.htc.launcher.widget.GestureDetector.OnMultiTouchListener
        public boolean onScale(float ratio) {
            if (!LeapController.this.mIsLeapMode && LeapController.this.mLeapLayer.canEnterLeapMode()) {
                ReusableULogData uLogData = ReusableULogData.obtain();
                uLogData.setAppId("com.htc.launcher").setCategory("leap_view");
                uLogData.addData("leapview_launch", "pitch");
                if (SettingUtil.localLOGD) {
                    Log.d(LeapController.TAG, "HTC user profiling     leapview_launch     true,pitch");
                }
                ULog.log(uLogData);
                uLogData.recycle();
                LeapController.this.enterLeapMode();
            }
            if (LeapController.this.mTouchEventHolder == 2) {
                if (!LeapController.this.mPlayingZoomOutAnimation) {
                    if (LeapController.this.mPlayingZoomInAnimation) {
                        LeapController.this.mAnimationProgress = (int) (((ratio - 1.0f) * 1000.0f) / (LeapController.sThumbnailScaleHorizontalRatio - 1.0f));
                        LeapController.this.mAnimationProgress = Math.min(Math.max(LeapController.this.mAnimationProgress, 0), LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK);
                        Iterator i$ = LeapController.this.mLeapAnimationPlayers.iterator();
                        while (i$.hasNext()) {
                            LeapAnimationPlayer player = (LeapAnimationPlayer) i$.next();
                            player.setZoomInAnimationProgress(LeapController.this.mSelectPage, 2, LeapController.this.mAnimationProgress, LeapController.this.mVirtualScrollX);
                        }
                        if (LeapController.this.mAnimationProgress >= 200) {
                            LeapController.this.mZoomDirection = ZoomDirection.ZOOM_IN;
                        } else {
                            LeapController.this.mZoomDirection = ZoomDirection.ZOOM_OUT;
                        }
                    }
                } else {
                    LeapController.this.mAnimationProgress = (int) (((1.0f - ratio) * 1000.0f) / (1.0f - (1.0f / LeapController.sThumbnailScaleHorizontalRatio)));
                    LeapController.this.mAnimationProgress = Math.min(Math.max(LeapController.this.mAnimationProgress, 0), LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK);
                    Iterator i$2 = LeapController.this.mLeapAnimationPlayers.iterator();
                    while (i$2.hasNext()) {
                        LeapAnimationPlayer player2 = (LeapAnimationPlayer) i$2.next();
                        player2.setZoomOutAnimationProgress(LeapController.this.mSelectPage, 2, LeapController.this.mAnimationProgress, LeapController.this.mVirtualScrollX);
                    }
                    if (LeapController.this.mAnimationProgress >= 300 || ratio == 1.0f) {
                        LeapController.this.mZoomDirection = ZoomDirection.ZOOM_OUT;
                    } else {
                        LeapController.this.mZoomDirection = ZoomDirection.ZOOM_IN;
                    }
                }
                if (LeapController.DEBUG_TOUCH) {
                    Log.v(LeapController.TAG, "TOUCH EVENT: onZooming(" + ratio + "), mCurrentZoomingAnimation = " + LeapController.this.mZoomDirection + ", mPlayZoomOutAnimation = " + LeapController.this.mPlayingZoomOutAnimation + ", mPlayZoomInAnimation = " + LeapController.this.mPlayingZoomInAnimation + ", mAnimationProgress = " + LeapController.this.mAnimationProgress);
                }
            }
            return false;
        }

        @Override // com.htc.launcher.widget.GestureDetector.OnMultiTouchListener
        public boolean onActionUp(MotionEvent e) {
            if (LeapController.DEBUG_TOUCH) {
                Log.d(LeapController.TAG, "TOUCH EVENT: onActionUp()");
            }
            playRemainingAnimation();
            return false;
        }

        private void playRemainingAnimation() {
            if (LeapController.DEBUG_TOUCH) {
                Log.d(LeapController.TAG, " => mCurrentZoomingAnimation = " + LeapController.this.mZoomDirection + ", mPlayZoomOutAnimation = " + LeapController.this.mPlayingZoomOutAnimation + ", mPlayZoomInAnimation = " + LeapController.this.mPlayingZoomInAnimation + ", mAnimationProgress = " + LeapController.this.mAnimationProgress);
            }
            if (LeapController.this.mTouchEventHolder == 2) {
                if (LeapController.this.mPlayingZoomOutAnimation) {
                    if (LeapController.this.mZoomDirection == ZoomDirection.ZOOM_OUT) {
                        LeapController.this.mScrollRunnable.startScroll(LeapController.this.mAnimationProgress, LeapController.this.mVirtualScrollX, LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK - LeapController.this.mAnimationProgress, 0, ((LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK - LeapController.this.mAnimationProgress) * 500) / LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK);
                    } else if (LeapController.this.mZoomDirection == ZoomDirection.ZOOM_IN) {
                        LeapController.this.mScrollRunnable.startScroll(LeapController.this.mAnimationProgress, LeapController.this.mVirtualScrollX, -LeapController.this.mAnimationProgress, 0, (Math.abs(-LeapController.this.mAnimationProgress) * 500) / LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK);
                    }
                } else if (LeapController.this.mPlayingZoomInAnimation) {
                    if (LeapController.this.mZoomDirection == ZoomDirection.ZOOM_OUT) {
                        LeapController.this.mScrollRunnable.startScroll(LeapController.this.mAnimationProgress, LeapController.this.mVirtualScrollX, -LeapController.this.mAnimationProgress, 0, (Math.abs(-LeapController.this.mAnimationProgress) * 500) / LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK);
                    } else if (LeapController.this.mZoomDirection == ZoomDirection.ZOOM_IN) {
                        LeapController.this.mScrollRunnable.startScroll(LeapController.this.mAnimationProgress, LeapController.this.mVirtualScrollX, LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK - LeapController.this.mAnimationProgress, (LeapController.this.mSelectPage * LeapController.this.mContext.getResources().getInteger(R.integer.rosie_width)) - LeapController.this.mVirtualScrollX, ((LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK - LeapController.this.mAnimationProgress) * 500) / LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK);
                    }
                }
            }
            LeapController.this.setTouchEventHolder(0);
        }

        @Override // com.htc.launcher.widget.GestureDetector.OnMultiTouchListener
        public boolean onActionCancel(MotionEvent e) {
            if (LeapController.DEBUG_TOUCH) {
                Log.d(LeapController.TAG, "TOUCH EVENT: onActionCancel()");
            }
            playRemainingAnimation();
            LeapController.this.setTouchEventHolder(0);
            return false;
        }

        @Override // com.htc.launcher.widget.GestureDetector.OnMultiTouchListener
        public boolean onSingleTapUp(MotionEvent e) {
            if (LeapController.this.isLeapMode()) {
                if (LeapController.DEBUG_TOUCH) {
                    Log.d(LeapController.TAG, "TOUCH EVENT: onSingleTapUp()");
                }
                if (LeapController.this.mZoomDirection == ZoomDirection.NONE) {
                    float x = e.getX();
                    float y = e.getY();
                    int selectPage = LeapController.this.mLeapLayer.findPage(x, y);
                    if (SettingUtil.localLOGD) {
                        Log.d(LeapController.TAG, "mLeapLayer.findPage(" + x + ", " + y + ") = " + selectPage);
                    }
                    if (selectPage >= 0) {
                        LeapController.this.mSelectPage = selectPage;
                        LeapController.this.leaveLeapMode();
                        return false;
                    }
                    return false;
                }
                return false;
            }
            return false;
        }

        @Override // com.htc.launcher.widget.GestureDetector.OnMultiTouchListener
        public boolean onMultiTouch(float x, float y) {
            int selectPage;
            if (LeapController.DEBUG_TOUCH) {
                Log.d(LeapController.TAG, "TOUCH EVENT: onMultiTouch(), mIsLeapMode = " + LeapController.this.mIsLeapMode + ", mCurrentZoomingAnimation = " + LeapController.this.mZoomDirection);
            }
            if (LeapController.this.mZoomDirection == ZoomDirection.NONE) {
                LeapController.this.setTouchEventHolder(2);
                if (LeapController.this.mIsLeapMode && (selectPage = LeapController.this.mLeapLayer.findPage(x, y)) >= 0) {
                    LeapController.this.mSelectPage = selectPage;
                    LeapController.this.leaveLeapMode();
                    return false;
                }
                return false;
            }
            return false;
        }

        @Override // com.htc.launcher.widget.GestureDetector.OnMultiTouchListener
        public boolean onLongPress(MotionEvent e) {
            if (!LeapController.this.mIsLeapMode) {
                return false;
            }
            if (LeapController.DEBUG_TOUCH) {
                Log.d(LeapController.TAG, "TOUCH EVENT: onLongPress(), Rearrange.");
            }
            Iterator i$ = LeapController.this.mLeapListeners.iterator();
            while (i$.hasNext()) {
                LeapListener listener = (LeapListener) i$.next();
                listener.onLongPress();
            }
            return false;
        }

        @Override // com.htc.launcher.widget.GestureDetector.OnMultiTouchListener
        public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
            if (!LeapController.this.mIsLeapMode) {
                return false;
            }
            if (LeapController.DEBUG_TOUCH) {
                Log.d(LeapController.TAG, "TOUCH EVENT: onScroll()");
            }
            return false;
        }

        @Override // com.htc.launcher.widget.GestureDetector.OnMultiTouchListener
        public void onShowPress(MotionEvent e) {
            if (LeapController.this.mIsLeapMode && LeapController.this.mRearrange && LeapController.DEBUG_TOUCH) {
                Log.d(LeapController.TAG, "TOUCH EVENT: onShowPress(), Rearrange.");
            }
        }
    };
    private ScrollRunnable mScrollRunnable = new ScrollRunnable(true);

    public interface LeapAnimationPlayer {
        public static final int ACTION_BEGIN = 0;
        public static final int ACTION_END = 1;
        public static final int ACTION_MOVE = 2;

        void setZoomInAnimationProgress(int i, int i2, float f, int i3);

        void setZoomOutAnimationProgress(int i, int i2, float f, int i3);
    }

    public interface LeapLayer {
        boolean canEnterLeapMode();

        int findPage(float f, float f2);

        int getCurrentPage();

        void setCurrentPage(int i);
    }

    public interface LeapListener {
        void beginLeap(int i);

        void endLeap(int i);

        void onAnimationStateChanged(boolean z, ZoomDirection zoomDirection);

        void onLongPress();
    }

    public enum ZoomDirection {
        ZOOM_OUT,
        ZOOM_IN,
        NONE
    }

    public LeapController(Context context, LeapLayer leapLayer) {
        this.mContext = context;
        this.mLeapLayer = leapLayer;
        this.mGestureDetector = new GestureDetector(context, this.mGestureListener);
    }

    public void addLeapAnimationPlayer(LeapAnimationPlayer animationPlayer) {
        if (this.mLeapAnimationPlayers == null) {
            this.mLeapAnimationPlayers = new ArrayList<>();
        }
        this.mLeapAnimationPlayers.add(animationPlayer);
    }

    public boolean isHandleMotionEvent(MotionEvent ev) {
        if (SettingUtil.sEnableThumbnailMode && (this.mTouchEventHolder == 0 || this.mTouchEventHolder == 2)) {
            this.mGestureDetector.onTouchEvent(ev);
            if (this.mTouchEventHolder == 2 || this.mIsLeapMode) {
                return true;
            }
        }
        return false;
    }

    public void cancelGesture() {
        this.mGestureDetector.cancelGesture();
    }

    public void setTouchEventHolder(int eventHolder) {
        if (SettingUtil.localLOGD) {
            Log.d(TAG, "setTouchEventHolder(" + eventHolder + ")");
        }
        this.mTouchEventHolder = eventHolder;
    }

    public boolean isLeapMode() {
        return this.mIsLeapMode;
    }

    public int getVirtualScrollX() {
        return this.mVirtualScrollX;
    }

    public void enterLeapMode() {
        if (SettingUtil.sEnableThumbnailMode) {
            this.mIsLeapMode = true;
            this.mSelectPage = this.mLeapLayer.getCurrentPage();
            this.mZoomDirection = ZoomDirection.ZOOM_OUT;
            this.mPlayingZoomOutAnimation = true;
            this.mPlayingZoomInAnimation = false;
            if (this.mLeapListeners != null) {
                Iterator i$ = this.mLeapListeners.iterator();
                while (i$.hasNext()) {
                    LeapListener listener = i$.next();
                    listener.beginLeap(this.mSelectPage);
                    listener.onAnimationStateChanged(true, this.mZoomDirection);
                }
            }
            this.mVirtualScrollX = this.mSelectPage * this.mContext.getResources().getInteger(R.integer.rosie_width);
            this.mAnimationProgress = 0;
            Iterator i$2 = this.mLeapAnimationPlayers.iterator();
            while (i$2.hasNext()) {
                LeapAnimationPlayer player = i$2.next();
                player.setZoomOutAnimationProgress(this.mSelectPage, 0, this.mAnimationProgress, this.mVirtualScrollX);
            }
            if (this.mTouchEventHolder != 2) {
                if (SettingUtil.localLOGD) {
                    Log.d(TAG, "enterLeapMode(" + this.mSelectPage + ") by press home key.");
                }
                this.mScrollRunnable.startScroll(this.mAnimationProgress, this.mVirtualScrollX, LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK - this.mAnimationProgress, 0, ((LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK - this.mAnimationProgress) * 500) / LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK);
            } else if (SettingUtil.localLOGD) {
                Log.d(TAG, "enterLeapMode(" + this.mSelectPage + ") by multi touch.");
            }
        }
    }

    public void endLeapMode() {
        if (this.mIsLeapMode) {
            if (this.mScrollRunnable != null) {
                this.mScrollRunnable.stopScroll();
            }
            this.mIsLeapMode = false;
            this.mZoomDirection = ZoomDirection.NONE;
            this.mLeapLayer.setCurrentPage(this.mSelectPage);
            if (this.mLeapListeners != null) {
                Iterator i$ = this.mLeapListeners.iterator();
                while (i$.hasNext()) {
                    LeapListener listener = i$.next();
                    listener.endLeap(this.mSelectPage);
                }
            }
            setTouchEventHolder(0);
            if (SettingUtil.localLOGD) {
                Log.d(TAG, "endLeapMode(" + this.mSelectPage + ")");
            }
        }
    }

    public void leaveLeapMode(int selectPage) {
        if (SettingUtil.sEnableThumbnailMode && !this.mPlayingZoomInAnimation) {
            this.mSelectPage = selectPage;
            leaveLeapMode();
        }
    }

    public void leaveLeapMode() {
        if (SettingUtil.localLOGD) {
            Log.d(TAG, "stopSelect(), mSelectPage = " + this.mSelectPage + ",mPlayZoomInAnimation = " + this.mPlayingZoomInAnimation);
        }
        if (SettingUtil.sEnableThumbnailMode && !this.mPlayingZoomInAnimation) {
            this.mZoomDirection = ZoomDirection.ZOOM_IN;
            this.mPlayingZoomInAnimation = true;
            this.mPlayingZoomOutAnimation = false;
            if (this.mLeapListeners != null) {
            }
            Iterator i$ = this.mLeapListeners.iterator();
            while (i$.hasNext()) {
                LeapListener listener = i$.next();
                listener.onAnimationStateChanged(true, this.mZoomDirection);
            }
            this.mAnimationProgress = 0;
            Iterator i$2 = this.mLeapAnimationPlayers.iterator();
            while (i$2.hasNext()) {
                LeapAnimationPlayer player = i$2.next();
                player.setZoomInAnimationProgress(this.mSelectPage, 0, this.mAnimationProgress, this.mVirtualScrollX);
            }
            if (this.mTouchEventHolder != 2) {
                this.mScrollRunnable.startScroll(this.mAnimationProgress, this.mVirtualScrollX, LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK - this.mAnimationProgress, (this.mSelectPage * this.mContext.getResources().getInteger(R.integer.rosie_width)) - this.mVirtualScrollX, ((LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK - this.mAnimationProgress) * 350) / LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK);
            }
        }
    }

    public void endAnimation() {
        if (this.mZoomDirection != ZoomDirection.NONE) {
            this.mScrollRunnable.stopScroll();
            endLeapMode();
        }
    }

    private class ScrollRunnable implements Runnable {
        private static final int FIXED_FPS = 16;
        private boolean isFinished = true;
        private final boolean mFixFps;
        private HtcScroller mScroller;

        public ScrollRunnable(boolean fixFps) {
            this.mScroller = new HtcScroller(LeapController.this.mContext, new DecelerateInterpolator());
            this.mFixFps = fixFps;
        }

        public void startScroll(int startX, int startY, int dx, int dy, int duration) {
            this.mScroller.startScroll(startX, startY, dx, dy, duration);
            start();
        }

        private void start() {
            this.isFinished = false;
            LeapController.this.mHandler.post(this);
        }

        public void stopScroll() {
            this.mScroller.abortAnimation();
            this.isFinished = true;
        }

        public boolean isFinished() {
            return this.isFinished;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (!this.isFinished) {
                HtcScroller scroller = this.mScroller;
                boolean more = scroller.computeScrollOffset();
                if (!more) {
                    if (LeapController.this.mZoomDirection == ZoomDirection.ZOOM_OUT) {
                        if (!LeapController.this.mPlayingZoomOutAnimation) {
                            if (LeapController.this.mPlayingZoomInAnimation) {
                                LeapController.this.mAnimationProgress = 0;
                                Iterator i$ = LeapController.this.mLeapAnimationPlayers.iterator();
                                while (i$.hasNext()) {
                                    LeapAnimationPlayer player = (LeapAnimationPlayer) i$.next();
                                    player.setZoomInAnimationProgress(LeapController.this.mSelectPage, 1, LeapController.this.mAnimationProgress, LeapController.this.mVirtualScrollX);
                                }
                            }
                        } else {
                            LeapController.this.mAnimationProgress = LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK;
                            Iterator i$2 = LeapController.this.mLeapAnimationPlayers.iterator();
                            while (i$2.hasNext()) {
                                LeapAnimationPlayer player2 = (LeapAnimationPlayer) i$2.next();
                                player2.setZoomOutAnimationProgress(LeapController.this.mSelectPage, 1, LeapController.this.mAnimationProgress, LeapController.this.mVirtualScrollX);
                            }
                        }
                        LeapController.this.mPlayingZoomOutAnimation = false;
                        LeapController.this.mPlayingZoomInAnimation = false;
                        if (LeapController.this.mLeapListeners != null) {
                            Iterator i$3 = LeapController.this.mLeapListeners.iterator();
                            while (i$3.hasNext()) {
                                LeapListener listener = (LeapListener) i$3.next();
                                listener.onAnimationStateChanged(false, LeapController.this.mZoomDirection);
                            }
                        }
                        LeapController.this.mZoomDirection = ZoomDirection.NONE;
                        if (SettingUtil.localLOGD) {
                            Log.d(LeapController.TAG, "Zoom out animation end");
                        }
                    } else if (LeapController.this.mZoomDirection == ZoomDirection.ZOOM_IN) {
                        if (!LeapController.this.mPlayingZoomOutAnimation) {
                            if (LeapController.this.mPlayingZoomInAnimation) {
                                LeapController.this.mAnimationProgress = LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK;
                                Iterator i$4 = LeapController.this.mLeapAnimationPlayers.iterator();
                                while (i$4.hasNext()) {
                                    LeapAnimationPlayer player3 = (LeapAnimationPlayer) i$4.next();
                                    player3.setZoomInAnimationProgress(LeapController.this.mSelectPage, 1, LeapController.this.mAnimationProgress, LeapController.this.mVirtualScrollX);
                                }
                            }
                        } else {
                            LeapController.this.mAnimationProgress = 0;
                            Iterator i$5 = LeapController.this.mLeapAnimationPlayers.iterator();
                            while (i$5.hasNext()) {
                                LeapAnimationPlayer player4 = (LeapAnimationPlayer) i$5.next();
                                player4.setZoomOutAnimationProgress(LeapController.this.mSelectPage, 1, LeapController.this.mAnimationProgress, LeapController.this.mVirtualScrollX);
                            }
                        }
                        LeapController.this.mPlayingZoomOutAnimation = false;
                        LeapController.this.mPlayingZoomInAnimation = false;
                        if (LeapController.this.mLeapListeners != null) {
                            Iterator i$6 = LeapController.this.mLeapListeners.iterator();
                            while (i$6.hasNext()) {
                                LeapListener listener2 = (LeapListener) i$6.next();
                                listener2.onAnimationStateChanged(false, LeapController.this.mZoomDirection);
                            }
                        }
                        LeapController.this.mZoomDirection = ZoomDirection.NONE;
                        LeapController.this.endLeapMode();
                        if (SettingUtil.localLOGD) {
                            Log.d(LeapController.TAG, "Zoom in animation end");
                        }
                    }
                    this.isFinished = true;
                } else {
                    if (this.mFixFps) {
                        LeapController.this.mHandler.postDelayed(this, 16L);
                    }
                    LeapController.this.mAnimationProgress = scroller.getCurrX();
                    LeapController.this.mVirtualScrollX = scroller.getCurrY();
                    if (!this.mFixFps) {
                        LeapController.this.mHandler.post(this);
                    }
                    if (LeapController.this.mPlayingZoomOutAnimation) {
                        Iterator i$7 = LeapController.this.mLeapAnimationPlayers.iterator();
                        while (i$7.hasNext()) {
                            LeapAnimationPlayer player5 = (LeapAnimationPlayer) i$7.next();
                            player5.setZoomOutAnimationProgress(LeapController.this.mSelectPage, 2, LeapController.this.mAnimationProgress, LeapController.this.mVirtualScrollX);
                        }
                    } else if (LeapController.this.mPlayingZoomInAnimation) {
                        Iterator i$8 = LeapController.this.mLeapAnimationPlayers.iterator();
                        while (i$8.hasNext()) {
                            LeapAnimationPlayer player6 = (LeapAnimationPlayer) i$8.next();
                            player6.setZoomInAnimationProgress(LeapController.this.mSelectPage, 2, LeapController.this.mAnimationProgress, LeapController.this.mVirtualScrollX);
                        }
                    }
                }
                if (SettingUtil.localLOGD) {
                    Log.d(LeapController.TAG, "mAnimationProgress = " + LeapController.this.mAnimationProgress + ", mVirtualScrollX = " + LeapController.this.mVirtualScrollX);
                }
            }
        }
    }

    public int getSelectPage() {
        return this.mSelectPage;
    }

    public void addLeapListener(LeapListener listener) {
        if (this.mLeapListeners == null) {
            this.mLeapListeners = new ArrayList<>();
        }
        this.mLeapListeners.add(listener);
    }

    @Override // com.htc.launcher.DragLeaper
    public void zoomIn(int selectPage) {
        leaveLeapMode(selectPage);
    }

    @Override // com.htc.launcher.DragLeaper
    public void zoomOut() {
        enterLeapMode();
    }
}
