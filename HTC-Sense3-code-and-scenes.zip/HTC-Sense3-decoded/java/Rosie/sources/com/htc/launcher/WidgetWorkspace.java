package com.htc.launcher;

import android.content.Context;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class WidgetWorkspace {
    static final String DEFAULT_LOCKSCREEN_WALLPAPER = "/data/misc/lockscreen/D_lock_screen_";
    static final String DEFAULT_LOCKSCREEN_WALLPAPER_PORTRAIT = "/data/misc/lockscreen/D_lock_screen_port";
    static final String LOCKSCREEN_ROOT = "/data/misc/lockscreen/";
    static final String LOCKSCREEN_WALLPAPER = "/data/misc/lockscreen/lock_screen_";
    static final String LOCKSCREEN_WALLPAPER_LANDSCAPE = "/data/misc/lockscreen/lock_screen_land";
    static final String LOCKSCREEN_WALLPAPER_PORTRAIT = "/data/misc/lockscreen/lock_screen_port";
    static final int NO_ID = -1;
    static final String PRE_HOME_WALLPAPER = "home_wallpaper_";
    static final String PRE_LOCKSCREEN_WALLPAPER_LANDSCAPE = "/data/misc/lockscreen/lock_screen_land_";
    static final String PRE_LOCKSCREEN_WALLPAPER_PORTRAIT = "/data/misc/lockscreen/lock_screen_port_";
    static final int STATUS_HTC_DEFAULT = 2;
    static final int STATUS_OTHER_DEFAULT = 4;
    static final int STATUS_SAVED = 0;
    static final int STATUS_UNSAVED = 1;
    static final int STATUS_UNSAVED_REMOVED = 3;
    private static String sPreHomeWallpaper;
    String lockscreen_wallpaper_name;
    private String mHomeWallpaper;
    String mWallpaperComponent;
    public int translate_id;
    public int id = -1;
    public String displayName = null;
    int status = 1;
    int ancestor_id = -1;

    public String toString() {
        return this.displayName == null ? "No Name" : this.displayName;
    }

    public String getSystemPortraitLockscreenWallpaper() {
        return WidgetPackageManager.manipulateResourcePath(this.lockscreen_wallpaper_name);
    }

    public String getHomeWallpaper(Context context) {
        if (this.mHomeWallpaper == null) {
            this.mHomeWallpaper = getHomeWallpaper(context, this.id);
        }
        return this.mHomeWallpaper;
    }

    public static String getHomeWallpaper(Context context, int id) {
        if (id >= 0) {
            return context.getFilesDir().toString() + "/" + PRE_HOME_WALLPAPER + id;
        }
        if (sPreHomeWallpaper == null) {
            sPreHomeWallpaper = context.getFilesDir().toString() + "/" + PRE_HOME_WALLPAPER;
        }
        return sPreHomeWallpaper;
    }

    public String getPortraitLockscreenWallpaper() {
        return getPortraitLockscreenWallpaper(this.id);
    }

    public static String getPortraitLockscreenWallpaper(int id) {
        return PRE_LOCKSCREEN_WALLPAPER_PORTRAIT + id;
    }

    public String getLandscapeLockscreenWallpaper() {
        return getLandscapeLockscreenWallpaper(this.id);
    }

    public static String getLandscapeLockscreenWallpaper(int id) {
        return PRE_LOCKSCREEN_WALLPAPER_LANDSCAPE + id;
    }

    public boolean isLiveWallpaper() {
        return this.mWallpaperComponent != null && this.mWallpaperComponent.length() > 0;
    }
}
