package com.htc.launcher;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.TransitionDrawable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import com.android.common.speech.LoggingEvents;
import com.htc.launcher.DragController;
import com.htc.launcher.DragSource;
import com.htc.launcher.custom.CustomResourceUtil;
import com.htc.launcher.settings.SettingUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class DragMenuBar extends RelativeLayout implements DropTarget, DragController.DragListener {
    private static final int ANIMATION_DURATION = 200;
    private static final int ORIENTATION_HORIZONTAL = 1;
    private static final int TRANSITION_DURATION = 250;
    private FocusBtn mCurrentFoucsBtn;
    private DragMenuButton mDeleteButton;
    private DragLayer mDragLayer;
    private View mHandle;
    private Animation mHandleInAnimation;
    private Animation mHandleOutAnimation;
    private AnimationSet mInAnimation;
    private Launcher mLauncher;
    private final int[] mLocation;
    private DisplayMetrics mMetrics;
    private int mOrientation;
    private AnimationSet mOutAnimation;
    private final RectF mRegion;
    private DragMenuButton mSettingButton;
    private TransitionDrawable mTransition;
    private boolean mTrashMode;
    private String mUriSetting;

    private enum BtnStatus {
        on,
        rest
    }

    private enum FocusBtn {
        btnDelete,
        btnSetting
    }

    public DragMenuBar(Context context) {
        super(context);
        this.mLocation = new int[2];
        this.mRegion = new RectF();
    }

    public DragMenuBar(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public DragMenuBar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mLocation = new int[2];
        this.mRegion = new RectF();
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.DragMenuBar, defStyle, 0);
        this.mOrientation = a.getInt(0, 1);
        a.recycle();
        this.mMetrics = getResources().getDisplayMetrics();
        this.mUriSetting = LoggingEvents.EXTRA_CALLING_APP_NAME;
    }

    @Override // android.view.View
    protected void onFinishInflate() {
        super.onFinishInflate();
        View handle = findViewById(R.id.drag_setting);
        this.mTransition = (TransitionDrawable) handle.getBackground();
        this.mCurrentFoucsBtn = FocusBtn.btnSetting;
        try {
            this.mDeleteButton = (DragMenuButton) findViewById(R.id.drag_delete);
            this.mSettingButton = (DragMenuButton) findViewById(R.id.drag_setting);
            Resources res = getContext().getResources();
            this.mSettingButton.setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "rosie_drag_menu_left_selector", R.drawable.rosie_drag_menu_left_selector)));
            this.mSettingButton.setCompoundDrawablesWithIntrinsicBounds(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "edit_setting_icon", R.drawable.edit_setting_icon), 0, 0, 0);
            this.mDeleteButton.setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "rosie_drag_menu_right_selector", R.drawable.rosie_drag_menu_right_selector)));
            this.mDeleteButton.setCompoundDrawablesWithIntrinsicBounds(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "edit_delet_icon", R.drawable.edit_delet_icon), 0, 0, 0);
            setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "navbar", 34079090)));
            updateLayout(this.mOrientation == 1);
        } catch (ClassCastException ex) {
            Log.e("DragMenuBar", "mDeleteText or mSettingText : " + findViewById(R.id.drag_delete) + findViewById(R.id.drag_setting));
            throw ex;
        }
    }

    @Override // com.htc.launcher.DropTarget
    public boolean acceptDrop(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        Logger.d("DragMenuBar", "[EDIT_DEBUG] DragMenuBar.acceptDrop()");
        return isButtonEnable();
    }

    @Override // com.htc.launcher.DropTarget
    public Rect estimateDropLocation(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem, Rect recycle) {
        return null;
    }

    @Override // com.htc.launcher.DropTarget
    public void onDrop(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        Logger.d("DragMenuBar", "[EDIT_DEBUG] DragMenuBar.onDrop()");
        if (getDragCompletedAction() == DragSource.DragCompletedAction.REMOVE) {
            Logger.d("DragMenuBar", "[EDIT_DEBUG] DragMenuBar.onDrop() - REMOVE");
            this.mLauncher.getDesktopItemController().removeItem(source, dragItem.getItemInfo());
        } else if (getDragCompletedAction() == DragSource.DragCompletedAction.SETTING) {
            Logger.d("DragMenuBar", "[EDIT_DEBUG] DragMenuBar.onDrop() - SETTING");
            this.mLauncher.getDesktopItemController().editItem(source, dragItem.getItemInfo());
        } else {
            Logger.d("DragMenuBar", "[EDIT_DEBUG] DragMenuBar.onDrop() - other");
        }
    }

    @Override // com.htc.launcher.DropTarget
    public DragSource.DragCompletedAction getDragCompletedAction() {
        Logger.d("DragMenuBar", "[EDIT_DEBUG] DragMenuBar.getDragCompletedAction()");
        if (this.mCurrentFoucsBtn == FocusBtn.btnSetting) {
            return DragSource.DragCompletedAction.SETTING;
        }
        if (this.mCurrentFoucsBtn == FocusBtn.btnDelete) {
            return DragSource.DragCompletedAction.REMOVE;
        }
        return DragSource.DragCompletedAction.NONE;
    }

    public FocusBtn hitTest(int x, int y) {
        if (this.mOrientation == 1) {
            if (x > this.mMetrics.widthPixels / 2) {
                FocusBtn result = FocusBtn.btnDelete;
                return result;
            }
            FocusBtn result2 = FocusBtn.btnSetting;
            return result2;
        }
        if (y < this.mMetrics.heightPixels / 2) {
            FocusBtn result3 = FocusBtn.btnDelete;
            return result3;
        }
        FocusBtn result4 = FocusBtn.btnSetting;
        return result4;
    }

    public boolean isButtonEnable() {
        return (this.mCurrentFoucsBtn == FocusBtn.btnSetting && this.mUriSetting.length() == 0) ? false : true;
    }

    private void updateMenuIcon(BtnStatus icon) {
        Logger.d("DragMenuBar", "[EDIT_DEBUG] DragMenuBar.updateMenuIcon()");
        if (this.mCurrentFoucsBtn == FocusBtn.btnDelete) {
            if (icon == BtnStatus.on) {
                this.mDeleteButton.setCompoundDrawablesWithIntrinsicBounds(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "con_trash_on", R.drawable.con_trash_on), 0, 0, 0);
                return;
            } else {
                this.mDeleteButton.setCompoundDrawablesWithIntrinsicBounds(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "con_trash_rest", R.drawable.con_trash_rest), 0, 0, 0);
                return;
            }
        }
        if (icon == BtnStatus.on) {
            this.mSettingButton.setCompoundDrawablesWithIntrinsicBounds(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "icon_setting_on", R.drawable.icon_setting_on), 0, 0, 0);
        } else {
            this.mSettingButton.setCompoundDrawablesWithIntrinsicBounds(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "icon_setting_rest", R.drawable.icon_setting_rest), 0, 0, 0);
        }
    }

    @Override // com.htc.launcher.DropTarget
    public void onDragEnter(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        Logger.d("DragMenuBar", "[EDIT_DEBUG] DragMenuBar.onDragEnter()");
        if (hitTest(x, y) == FocusBtn.btnDelete) {
            Logger.d("DragMenuBar", "[EDIT_DEBUG] DragMenuBar.onDragEnter() - btnDelete");
            View handle = findViewById(R.id.drag_delete);
            this.mTransition = (TransitionDrawable) handle.getBackground();
            this.mCurrentFoucsBtn = FocusBtn.btnDelete;
            this.mDragLayer.setDragColor(R.color.delete_color_filter);
            this.mTransition.resetTransition();
            this.mTransition.reverseTransition(TRANSITION_DURATION);
            updateMenuIcon(BtnStatus.on);
            return;
        }
        Logger.d("DragMenuBar", "[EDIT_DEBUG] DragMenuBar.onDragEnter() - other");
        View handle2 = findViewById(R.id.drag_setting);
        this.mTransition = (TransitionDrawable) handle2.getBackground();
        this.mCurrentFoucsBtn = FocusBtn.btnSetting;
        if (isButtonEnable()) {
            Logger.d("DragMenuBar", "[EDIT_DEBUG] DragMenuBar.onDragEnter() - other - 1");
            this.mDragLayer.setDragColor(CustomResourceUtil.getColorResIdentifier(((View) this).mContext, "rosie_setting_color_filter", R.color.setting_color_filter));
            this.mTransition.resetTransition();
            this.mTransition.reverseTransition(TRANSITION_DURATION);
            updateMenuIcon(BtnStatus.on);
            return;
        }
        Logger.d("DragMenuBar", "[EDIT_DEBUG] DragMenuBar.onDragEnter() - other - 2");
        this.mDragLayer.setDragColor(0);
    }

    @Override // com.htc.launcher.DropTarget
    public void onDragOver(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        FocusBtn nextFocusBtn;
        View handle;
        Logger.d("DragMenuBar", "[EDIT_DEBUG] DragMenuBar.onDragOver()");
        if (hitTest(x, y) == FocusBtn.btnDelete) {
            nextFocusBtn = FocusBtn.btnDelete;
            this.mDragLayer.setDragColor(R.color.delete_color_filter);
        } else {
            nextFocusBtn = FocusBtn.btnSetting;
            if (isButtonEnable()) {
                this.mDragLayer.setDragColor(CustomResourceUtil.getColorResIdentifier(((View) this).mContext, "rosie_setting_color_filter", R.color.setting_color_filter));
            } else {
                this.mDragLayer.setDragColor(0);
            }
        }
        if (this.mCurrentFoucsBtn != nextFocusBtn) {
            if (isButtonEnable()) {
                this.mTransition.reverseTransition(TRANSITION_DURATION);
                updateMenuIcon(BtnStatus.rest);
            }
            if (nextFocusBtn == FocusBtn.btnDelete) {
                handle = findViewById(R.id.drag_delete);
            } else {
                handle = findViewById(R.id.drag_setting);
            }
            this.mCurrentFoucsBtn = nextFocusBtn;
            if (isButtonEnable()) {
                this.mTransition = (TransitionDrawable) handle.getBackground();
                this.mTransition.resetTransition();
                this.mTransition.reverseTransition(TRANSITION_DURATION);
                updateMenuIcon(BtnStatus.on);
            }
        }
    }

    @Override // com.htc.launcher.DropTarget
    public void onDragExit(DragSource source, DropTarget target, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        Logger.d("DragMenuBar", "[EDIT_DEBUG] DragMenuBar.onDragExit()");
        if (isButtonEnable()) {
            this.mTransition.reverseTransition(TRANSITION_DURATION);
            updateMenuIcon(BtnStatus.rest);
        }
    }

    @Override // com.htc.launcher.DragController.DragListener
    public void onPreDragStart(Draggee cell, DragSource source, Object info, int dragAction) {
    }

    @Override // com.htc.launcher.DragController.DragListener
    public void onPostDragStart(Draggee cell, DragSource source, Object info, int dragAction) {
        Logger.d("DragMenuBar", "[EDIT_DEBUG] DragMenuBar.onDragStart()");
        this.mUriSetting = LoggingEvents.EXTRA_CALLING_APP_NAME;
        if (SettingUtil.htc_sense >= 2.0f) {
            if ((info instanceof WidgetProxy) && ((WidgetProxy) info).isAddedConfirmed) {
                try {
                    this.mUriSetting = ((WidgetProxy) info).getSettingIntent();
                    if (this.mUriSetting.length() == 0) {
                        this.mSettingButton.setTextColor(-7829368);
                        this.mSettingButton.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_setting_disable, 0, 0, 0);
                    } else {
                        this.mSettingButton.setTextColor(getResources().getColor(R.color.bb_textcolor_normal));
                        this.mSettingButton.setCompoundDrawablesWithIntrinsicBounds(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "icon_setting_rest", R.drawable.icon_setting_rest), 0, 0, 0);
                    }
                } catch (NullPointerException e) {
                    this.mSettingButton.setTextColor(-7829368);
                    this.mSettingButton.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_setting_disable, 0, 0, 0);
                } catch (Exception e2) {
                    Log.e("DragMenuBar", "strage error in OnDragStart");
                }
            } else {
                this.mSettingButton.setTextColor(-7829368);
                this.mSettingButton.setCompoundDrawablesWithIntrinsicBounds(R.drawable.icon_setting_disable, 0, 0, 0);
            }
            if (Launcher.localLOGD) {
                Log.d("Rosie", "[ATS][com.htc.launcher][press_hold_widget][movable]");
            }
            ItemInfo item = (ItemInfo) info;
            if (item != null) {
                this.mLauncher.getDesktopItemController().setLegacyItemToEdit(item);
                this.mTrashMode = true;
                createAnimations();
                int[] location = this.mLocation;
                getLocationOnScreen(location);
                this.mRegion.set(location[0], location[1], (location[0] + ((View) this).mRight) - ((View) this).mLeft, (location[1] + ((View) this).mBottom) - ((View) this).mTop);
                this.mDragLayer.setDeleteRegion(this.mRegion);
                this.mTransition.resetTransition();
            }
        }
    }

    @Override // com.htc.launcher.DragController.DragListener
    public void onDragEnd() {
        Logger.d("DragMenuBar", "[EDIT_DEBUG] DragMenuBar.onDragEnd()");
        if (this.mTrashMode) {
            this.mTrashMode = false;
            this.mDragLayer.setDeleteRegion(null);
            if (this.mOutAnimation == null || this.mHandleInAnimation == null) {
                createAnimations();
            }
            setVisibility(8);
        }
    }

    private void createAnimations() {
        if (this.mInAnimation == null) {
            this.mInAnimation = new FastAnimationSet();
            AnimationSet animationSet = this.mInAnimation;
            animationSet.setInterpolator(new AccelerateInterpolator());
            animationSet.addAnimation(new AlphaAnimation(0.0f, 1.0f));
            if (this.mOrientation == 1) {
                animationSet.addAnimation(new TranslateAnimation(0, 0.0f, 0, 0.0f, 1, 1.0f, 1, 0.0f));
            } else {
                animationSet.addAnimation(new TranslateAnimation(1, 1.0f, 1, 0.0f, 0, 0.0f, 0, 0.0f));
            }
            animationSet.setDuration(200L);
        }
        if (this.mHandleInAnimation == null) {
            if (this.mOrientation == 1) {
                this.mHandleInAnimation = new TranslateAnimation(0, 0.0f, 0, 0.0f, 1, 1.0f, 1, 0.0f);
            } else {
                this.mHandleInAnimation = new TranslateAnimation(1, 1.0f, 1, 0.0f, 0, 0.0f, 0, 0.0f);
            }
            this.mHandleInAnimation.setDuration(200L);
        }
        if (this.mOutAnimation == null) {
            this.mOutAnimation = new FastAnimationSet();
            AnimationSet animationSet2 = this.mOutAnimation;
            animationSet2.setInterpolator(new AccelerateInterpolator());
            animationSet2.addAnimation(new AlphaAnimation(1.0f, 0.0f));
            if (this.mOrientation == 1) {
                animationSet2.addAnimation(new FastTranslateAnimation(0, 0.0f, 0, 0.0f, 1, 0.0f, 1, 1.0f));
            } else {
                animationSet2.addAnimation(new FastTranslateAnimation(1, 0.0f, 1, 1.0f, 0, 0.0f, 0, 0.0f));
            }
            animationSet2.setDuration(200L);
        }
        if (this.mHandleOutAnimation == null) {
            if (this.mOrientation == 1) {
                this.mHandleOutAnimation = new FastTranslateAnimation(0, 0.0f, 0, 0.0f, 1, 0.0f, 1, 1.0f);
            } else {
                this.mHandleOutAnimation = new FastTranslateAnimation(1, 0.0f, 1, 1.0f, 0, 0.0f, 0, 0.0f);
            }
            this.mHandleOutAnimation.setFillAfter(true);
            this.mHandleOutAnimation.setDuration(200L);
        }
    }

    void setLauncher(Launcher launcher) {
        this.mLauncher = launcher;
    }

    void setDragController(DragLayer dragLayer) {
        this.mDragLayer = dragLayer;
    }

    void setHandle(View view) {
        this.mHandle = view;
    }

    private static class FastTranslateAnimation extends TranslateAnimation {
        public FastTranslateAnimation(int fromXType, float fromXValue, int toXType, float toXValue, int fromYType, float fromYValue, int toYType, float toYValue) {
            super(fromXType, fromXValue, toXType, toXValue, fromYType, fromYValue, toYType, toYValue);
        }

        @Override // android.view.animation.Animation
        public boolean willChangeTransformationMatrix() {
            return true;
        }

        @Override // android.view.animation.Animation
        public boolean willChangeBounds() {
            return false;
        }
    }

    private static class FastAnimationSet extends AnimationSet {
        FastAnimationSet() {
            super(false);
        }

        @Override // android.view.animation.AnimationSet, android.view.animation.Animation
        public boolean willChangeTransformationMatrix() {
            return true;
        }

        @Override // android.view.animation.AnimationSet, android.view.animation.Animation
        public boolean willChangeBounds() {
            return false;
        }
    }

    public void updateOrientation(boolean portrait) {
        Resources res = getResources();
        this.mInAnimation = null;
        this.mHandleInAnimation = null;
        this.mOutAnimation = null;
        this.mHandleOutAnimation = null;
        FrameLayout.LayoutParams DeletelParams = (FrameLayout.LayoutParams) getLayoutParams();
        if (portrait) {
            ((ViewGroup.LayoutParams) DeletelParams).height = res.getDimensionPixelSize(R.dimen.button_bar_height);
            ((ViewGroup.LayoutParams) DeletelParams).width = -2;
            DeletelParams.gravity = 81;
            this.mOrientation = 1;
            setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "navbar", 34079090)));
        } else {
            ((ViewGroup.LayoutParams) DeletelParams).width = res.getDimensionPixelSize(R.dimen.button_bar_height);
            ((ViewGroup.LayoutParams) DeletelParams).height = -2;
            DeletelParams.gravity = 21;
            this.mOrientation = 0;
            setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "navbar", 34079090)));
        }
        View deleteHandle = findViewById(R.id.drag_menu_bar_handle);
        RelativeLayout.LayoutParams deleteHandleParams = (RelativeLayout.LayoutParams) deleteHandle.getLayoutParams();
        if (portrait) {
            deleteHandleParams.addRule(15, 0);
            deleteHandleParams.addRule(11, 0);
            deleteHandleParams.addRule(14);
            deleteHandleParams.addRule(12);
        } else {
            deleteHandleParams.addRule(15);
            deleteHandleParams.addRule(11);
            deleteHandleParams.addRule(14, 0);
            deleteHandleParams.addRule(12, 0);
        }
        updateLayout(portrait);
    }

    public void updateLayout(boolean portrait) {
        Resources res = getResources();
        this.mSettingButton.setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "rosie_drag_menu_left_selector", R.drawable.rosie_drag_menu_left_selector)));
        RelativeLayout.LayoutParams settingParams = (RelativeLayout.LayoutParams) this.mSettingButton.getLayoutParams();
        RelativeLayout.LayoutParams settingContentParams = this.mSettingButton.getTextLayoutParams();
        ((ViewGroup.LayoutParams) settingParams).width = res.getDimensionPixelSize(R.dimen.drag_menu_bar_width);
        ((ViewGroup.LayoutParams) settingParams).height = res.getDimensionPixelSize(R.dimen.drag_menu_bar_height);
        if (portrait) {
            settingParams.addRule(3, 0);
            settingParams.addRule(7, 0);
            settingContentParams.addRule(15, 0);
            settingParams.addRule(8, R.id.drag_menu_bar_handle);
            settingParams.setMargins(res.getDimensionPixelOffset(R.dimen.drag_menu_bar_margin_left), 0, 0, res.getDimensionPixelOffset(R.dimen.drag_menu_bar_margin_bottom));
            settingContentParams.addRule(12);
            this.mSettingButton.setTextPadding(0, 0, 0, res.getDimensionPixelOffset(R.dimen.drag_menu_bar_padding_bottom));
            this.mSettingButton.setText(R.string.edit);
        } else {
            settingParams.addRule(9, 0);
            settingParams.addRule(8, 0);
            settingContentParams.addRule(12, 0);
            settingParams.addRule(3, R.id.drag_delete);
            settingParams.addRule(7, R.id.drag_menu_bar_handle);
            settingParams.setMargins(0, 0, res.getDimensionPixelOffset(R.dimen.drag_menu_bar_margin_bottom), res.getDimensionPixelOffset(R.dimen.drag_menu_bar_margin_left));
            settingContentParams.addRule(15);
            this.mSettingButton.setTextPadding(res.getDimensionPixelOffset(R.dimen.drag_menu_bar_left_padding), 0, 0, 0);
            this.mSettingButton.setText(R.string.delete_landscape);
        }
        this.mDeleteButton.setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "rosie_drag_menu_right_selector", R.drawable.rosie_drag_menu_right_selector)));
        RelativeLayout.LayoutParams deleteParams = (RelativeLayout.LayoutParams) this.mDeleteButton.getLayoutParams();
        RelativeLayout.LayoutParams deleteContentParams = this.mDeleteButton.getTextLayoutParams();
        ((ViewGroup.LayoutParams) deleteParams).width = res.getDimensionPixelSize(R.dimen.drag_menu_bar_width);
        ((ViewGroup.LayoutParams) deleteParams).height = res.getDimensionPixelSize(R.dimen.drag_menu_bar_height);
        if (portrait) {
            deleteParams.addRule(7, 0);
            deleteParams.addRule(10, 0);
            deleteContentParams.addRule(15, 0);
            deleteParams.addRule(8, R.id.drag_menu_bar_handle);
            deleteParams.addRule(1, R.id.drag_setting);
            deleteParams.setMargins(res.getDimensionPixelOffset(R.dimen.drag_menu_bar_margin_center), 0, 0, res.getDimensionPixelOffset(R.dimen.drag_menu_bar_margin_bottom));
            deleteContentParams.addRule(12);
            this.mDeleteButton.setTextPadding(0, 0, 0, res.getDimensionPixelOffset(R.dimen.drag_menu_bar_padding_bottom));
            this.mDeleteButton.setText(R.string.delete);
            return;
        }
        deleteParams.addRule(8, 0);
        deleteParams.addRule(1, 0);
        deleteContentParams.addRule(12, 0);
        deleteParams.addRule(7, R.id.drag_menu_bar_handle);
        deleteParams.addRule(10);
        deleteParams.setMargins(0, res.getDimensionPixelOffset(R.dimen.drag_menu_bar_margin_top), res.getDimensionPixelOffset(R.dimen.drag_menu_bar_margin_bottom), res.getDimensionPixelOffset(R.dimen.drag_menu_bar_margin_left));
        deleteContentParams.addRule(15);
        this.mDeleteButton.setTextPadding(res.getDimensionPixelOffset(R.dimen.drag_menu_bar_left_padding), 0, 0, 0);
        this.mDeleteButton.setText(R.string.delete_landscape);
    }

    @Override // com.htc.launcher.DropTarget
    public boolean claimDrop(int x, int y, int[] dropCoordinates) {
        return false;
    }

    public void froceUpdateRemote(Canvas canvas) {
    }
}
