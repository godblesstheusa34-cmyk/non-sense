package com.htc.launcher;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import com.htc.home.WidgetGroupItemInterface;
import com.htc.home.WidgetItemInterface;
import com.htc.launcher.AddAdapter;
import com.htc.launcher.AddAdapter.ListItem;
import com.htc.launcher.settings.SettingUtil;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class WidgetItem {
    private static final String TAG = "Widget";
    public Class<WidgetItemInterface> mClientWidgetItemClass;
    private Context mContext;
    public int mIconResource;
    public int mItemCategory;
    public int mItemType;
    public int mLayoutResource;
    public String mPackageName;
    public int mParentId;
    public String mPluginClassname;
    public int mSpanX;
    public int mSpanY;
    public int mTextResource;
    public String mWidgetName;
    public WidgetPackageManager mWidgetPM;
    public static int ITEM_CAT_NONE = 0;
    public static int ITEM_CAT_GROUP = 1;
    public static int ITEM_CAT_ITEM = 2;
    public static String PROPS_CATEGORY_ID = "category_id";
    public static String PROPS_MAX_INSTANCES = "max_instances";
    private WeakReference<WidgetItemInterface> mClientWidgetItem = new WeakReference<>(null);
    public Properties mProps = new Properties();
    public boolean mObsolete = false;
    private List<WidgetItem> children = new ArrayList();

    public WidgetItem(Context context) {
        this.mContext = context.getApplicationContext();
    }

    public WidgetProxy newWidget() {
        if (Launcher.localLOGD) {
            Log.d("Widget", "creating a widget - " + this.mPluginClassname);
        }
        try {
            return new WidgetProxy(this, getClientWidgetItem());
        } catch (Throwable ex) {
            Log.e("Widget", ex.getMessage(), ex);
            throw new IllegalStateException(ex);
        }
    }

    public WidgetItemInterface getClientWidgetItem() {
        WidgetItemInterface widget = this.mClientWidgetItem.get();
        if (widget != null) {
            return widget;
        }
        try {
            Context widgetContext = WidgetPackageManager.instance(this.mContext).getWidgetPackage(this.mPackageName, this.mContext).mPackageContext;
            Log.d("WidgetItem", "Density of widgetContext: " + widgetContext.getResources().getDisplayMetrics().density);
            if (SettingUtil.isTabletDevice() && widgetContext.getResources().getDisplayMetrics().density == 1.5d && !SettingUtil.isDoubleShot()) {
                Resources res = widgetContext.getResources();
                Configuration cfg = res.getConfiguration();
                DisplayMetrics dm = res.getDisplayMetrics();
                dm.density = 1.0f;
                dm.densityDpi = 160;
                res.updateConfiguration(cfg, dm);
            }
            Class clazz = Class.forName(this.mPluginClassname, true, widgetContext.getClassLoader());
            Constructor constructor = clazz.getConstructor((Class[]) null);
            Object object = constructor.newInstance((Object[]) null);
            if (object instanceof WidgetItemInterface) {
                this.mClientWidgetItem = new WeakReference<>((WidgetItemInterface) object);
                return (WidgetItemInterface) object;
            }
        } catch (ClassNotFoundException e) {
            Log.e("Widget", "Widget Plugin Class not found - " + this.mPluginClassname);
        } catch (NoSuchMethodException e2) {
            Log.e("Widget", "Widget Plugin Class doesn't have default constructor.");
        } catch (Exception e3) {
            Log.e("Widget", e3.getMessage(), e3);
        }
        return null;
    }

    public AddAdapter.ListItem getListItem(AddAdapter addAdapter) {
        Resources resources = getResources();
        addAdapter.getClass();
        AddAdapter.ListItem listItem = addAdapter.new ListItem(resources, this.mTextResource, this.mIconResource, 100);
        listItem.widgetItem = this;
        return listItem;
    }

    public boolean isVisible() {
        return this.mParentId < 0;
    }

    public boolean isGroupItem() {
        return this.mItemCategory == ITEM_CAT_GROUP;
    }

    public WidgetGroupItemInterface getGroupItem() {
        if (!isGroupItem()) {
            throw new IllegalStateException("Not an instance of WidgetGroupItemInterface - " + this.mClientWidgetItem);
        }
        return this.mClientWidgetItem;
    }

    public void addChild(WidgetItem child) {
        this.children.add(child);
    }

    public WidgetItem getChildAt(int index) {
        return this.children.get(index);
    }

    public int getChildCount() {
        return this.children.size();
    }

    public void startVariationOptionActivity(Launcher launcher) {
        int count = getChildCount();
        Bundle hasSpace = new Bundle();
        int spanX = -1;
        int spanY = -1;
        boolean prevHasSpace = false;
        for (int i = 0; i < count; i++) {
            WidgetItem childWidget = getChildAt(i);
            if ((spanX == -1 && spanY == -1) || spanX != childWidget.mSpanX || spanY != childWidget.mSpanY) {
                spanX = childWidget.mSpanX;
                spanY = childWidget.mSpanY;
                prevHasSpace = launcher.getWorkspace().hasRoomForSpan(spanX, spanY);
                hasSpace.putString(childWidget.getUniqueName(), Boolean.toString(prevHasSpace));
                launcher.getWorkspace().invalidateVacant();
            } else {
                hasSpace.putString(childWidget.getUniqueName(), Boolean.toString(prevHasSpace));
            }
        }
        Intent intent = new Intent();
        intent.setComponent(new ComponentName("com.htc.AddProgramWidget", "com.htc.AddProgramWidget.WidgetVariationActivity"));
        intent.putExtra("item_type", this.mItemType);
        intent.putExtra("widget_has_space", hasSpace);
        launcher.startActivityForResult(intent, 500);
    }

    public Resources getResources() {
        try {
            return this.mContext.getPackageManager().getResourcesForApplication(this.mPackageName);
        } catch (PackageManager.NameNotFoundException e) {
            Log.e("Widget", "widget package not found - " + this.mPackageName);
            return this.mContext.getResources();
        }
    }

    public int getCategoryId() {
        if (this.mProps == null) {
            return -1;
        }
        String strCateId = this.mProps.getProperty(PROPS_CATEGORY_ID, "-1");
        return Integer.parseInt(strCateId);
    }

    public int getMaxInstances() {
        if (this.mProps == null) {
            return -1;
        }
        String strCateId = this.mProps.getProperty(PROPS_MAX_INSTANCES, "-1");
        return Integer.parseInt(strCateId);
    }

    public String getUniqueName() {
        return this.mPackageName + "." + this.mWidgetName;
    }

    public static void startWidgetPicker(Launcher launcher, int itemType) {
        String[] rooms = evalRoom2(launcher);
        Intent intent = new Intent();
        intent.setComponent(new ComponentName("com.htc.AddProgramWidget", "com.htc.AddProgramWidget.widgetpicker.WidgetPicker"));
        intent.putExtra("VACANCY_INFO", rooms);
        intent.putExtra("item_type", itemType);
        launcher.startActivityForResult(intent, 500);
    }

    private static String[] evalRoom2(Launcher launcher) {
        int[][] sizes = {new int[]{4, 4}, new int[]{4, 3}, new int[]{4, 2}, new int[]{4, 1}, new int[]{3, 4}, new int[]{3, 3}, new int[]{3, 2}, new int[]{3, 1}, new int[]{2, 4}, new int[]{2, 3}, new int[]{2, 2}, new int[]{2, 1}, new int[]{1, 4}, new int[]{1, 3}, new int[]{1, 2}, new int[]{1, 1}};
        List<String> ret = new ArrayList<>();
        for (int[] size : sizes) {
            launcher.getWorkspace().hasRoomForSpan_ForceUpdate(size[0], size[1]);
            ret.add(size[0] + "x" + size[1]);
        }
        return (String[]) ret.toArray(new String[ret.size()]);
    }

    private static String[] evalRoom(int x, int y, Launcher launcher) {
        boolean hasRoom = launcher.getWorkspace().hasRoomForSpan(x, y);
        if (hasRoom) {
            return new String[]{x + "x" + y};
        }
        if (1 == x && 1 == y) {
            return new String[0];
        }
        if (1 == x) {
            return evalRoom(x, y - 1, launcher);
        }
        if (1 == y) {
            return evalRoom(x - 1, y, launcher);
        }
        String[] left = evalRoom(x - 1, y, launcher);
        String[] right = evalRoom(x, y - 1, launcher);
        Set<String> ret = new HashSet<>();
        for (String str : left) {
            ret.add(str);
        }
        for (String str2 : right) {
            ret.add(str2);
        }
        return (String[]) ret.toArray(new String[ret.size()]);
    }
}
