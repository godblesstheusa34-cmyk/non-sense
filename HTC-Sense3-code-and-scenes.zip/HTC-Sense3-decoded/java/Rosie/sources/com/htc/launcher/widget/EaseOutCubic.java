package com.htc.launcher.widget;

import com.htc.launcher.settings.SettingUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class EaseOutCubic implements EasingFunction {
    private float[] mEaseOutCoefficients;
    boolean mLong;

    public EaseOutCubic() {
        this(false);
    }

    public EaseOutCubic(boolean longDuration) {
        this.mEaseOutCoefficients = new float[5];
        this.mLong = true;
        this.mLong = longDuration;
        System.arraycopy(this.mLong ? SettingUtil.sEaseOutCoefficientsLong : SettingUtil.sEaseOutCoefficientsShort, 0, this.mEaseOutCoefficients, 0, this.mEaseOutCoefficients.length);
    }

    @Override // com.htc.launcher.widget.EasingFunction
    public float currentResult(float v0, float t, float b, float c, float d) {
        float t2 = t / d;
        float ts = t2 * t2;
        float tc = ts * t2;
        return (((this.mEaseOutCoefficients[4] * tc * ts) + (this.mEaseOutCoefficients[3] * ts * ts) + (this.mEaseOutCoefficients[2] * tc) + (this.mEaseOutCoefficients[1] * ts) + (this.mEaseOutCoefficients[0] * t2)) * c) + b;
    }

    public String toString() {
        return getClass().getSimpleName() + "#" + hashCode() + " " + (this.mLong ? "Long" : "Short");
    }
}
