package com.htc.launcher;

import com.htc.content.CarouselProvider;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class AllAppsCarouselProvider extends CarouselProvider {
    static final String AUTHORITY = "com.htc.launcher.AllAppsCarouselProvider";

    public AllAppsCarouselProvider() {
        setupCarousel(AUTHORITY);
    }
}
