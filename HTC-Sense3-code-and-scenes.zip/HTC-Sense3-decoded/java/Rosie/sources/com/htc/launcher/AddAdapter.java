package com.htc.launcher;

import android.app.KeyguardManager;
import android.app.WallpaperInfo;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.android.common.speech.LoggingEvents;
import com.htc.android.rosie.widget.WidgetProvider;
import com.htc.launcher.LauncherSettings;
import com.htc.launcher.custom.CustomResourceUtil;
import com.htc.launcher.fusion.WidgetProviderInfoCollector;
import com.htc.launcher.model.FilterableAndSortableApplicationInfoList;
import com.htc.launcher.settings.SettingUtil;
import com.htc.widget.HtcAbsListView;
import com.htc.widget.HtcListItemSeparable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class AddAdapter extends BaseAdapter {
    public static final int ADAPTER_ASSIGN_PROGRAM = 508;
    public static final int ADAPTER_ASSIGN_SHORTCUT = 509;
    public static final int ADAPTER_CHT_WIDGET = 600;
    public static final int ADAPTER_COMBINED_WIDGET = 503;
    public static final int ADAPTER_EXT_END = 700;
    public static final int ADAPTER_EXT_START = 600;
    public static final int ADAPTER_FOLDER = 506;
    public static final int ADAPTER_HTC_SETTINGS = 504;
    public static final int ADAPTER_LIEVE_FOLDER = 507;
    public static final int ADAPTER_MENU = 500;
    public static final int ADAPTER_PROGRAM = 501;
    public static final int ADAPTER_SHORTCUT = 502;
    private static final String CHT_IMSI = "46692";
    private static final String DOWNLOAD_MANAGER_TEXT = "menu_text";
    public static final int EXCUTE_BOOKMARK_SHORTCUT = 404;
    public static final int EXCUTE_GOOGLE_WIDGET = 401;
    public static final int EXCUTE_LIVE_FOLDER = 403;
    public static final int EXCUTE_PROGRAM = 402;
    public static final int EXCUTE_SHORTCUT = 400;
    private static final String EXTRA_APPLICATION_ID = "com.android.browser.application_id";
    public static final int ITEM_APPLICATION = 0;
    public static final int ITEM_APPWIDGET = 3;
    public static final int ITEM_CATEGORY_CHT_WIDGET = 300;
    public static final int ITEM_CATEGORY_DEFAULT = 100;
    public static final int ITEM_CATEGORY_SETTINGS = 200;
    public static final int ITEM_DONOTHING = -2;
    public static final int ITEM_FOLDER = 5;
    public static final int ITEM_FXWIDGET = 106;
    public static final int ITEM_FXWIDGET_SETTINGS = 107;
    public static final int ITEM_GOOGLE_GADGET = 301;
    public static final int ITEM_LIVE_FOLDER = 4;
    public static final int ITEM_NONE = -1;
    public static final int ITEM_PERSONALIZE = 103;
    public static final int ITEM_PERSONALIZE_ADD_TO_HOME = 105;
    public static final int ITEM_SEPERATOR = 104;
    public static final int ITEM_SETTING_GADGET = 7;
    public static final int ITEM_SHORTCUT = 1;
    public static final int ITEM_TITLE = 200;
    public static final int ITEM_WALLPAPER = 6;
    public static final int ITEM_WIDGET = 100;
    public static final int ITEM_WIDGET_ALL_HTC_PICKER = 102;
    public static final int ITEM_WIDGET_DOWNLOAD_MANAGER = 101;
    private static final int VIEW_TYPE_ALL_WIDGETS = 5;
    private static final int VIEW_TYPE_SEPERATOR = 0;
    private static final int VIEW_TYPE_SETTING = 4;
    private static final int VIEW_TYPE_WITHOUT_SUMMARY = 2;
    private static final int VIEW_TYPE_WITH_RIGHT_ICON = 3;
    private static final int VIEW_TYPE_WITH_SUMMARY = 1;
    static final String WIDGET_DOWNLOAD_MANAGER_ACTIVITY = "com.htc.wdm.activity.WidgetList";
    static final String WIDGET_DOWNLOAD_MANAGER_PACKAGE = "com.htc.wdm";
    private ArrayList<ListItem> mAddMenuItems;
    Drawable[] mExtGroup_icon;
    int[] mExtGroup_id;
    String[] mExtGroup_name;
    private List<WidgetProvider.Info> mFxWidgets;
    private int mGadgetId;
    private AppWidgetManager mGadgetManager;
    private final LayoutInflater mInflater;
    private ArrayList<ListItem> mItems;
    private final Launcher mLauncher;
    private PackageManager mPackageManager;
    private int mPersonalizeSeperatorFontSize;
    private int mShowTitleId;
    private ArrayList<ListItem> maddFuncMenuItems;
    public static boolean localLOGV = false;
    private static String LOG_TAG = "Addapter";
    private static String ITEM_INFO_LOG = "ItemInfo";
    private static final String[] DRM_COLUMNS = {LauncherSettings.Favorites.ID, "_data", "title"};
    private static final String[] MEDIA_COLUMNS = {LauncherSettings.Favorites.ID, "_data", "title"};
    private boolean showCheckLog = false;
    private ArrayList<ListItem> mAddProgramItems = new ArrayList<>();
    private ArrayList<ListItem> mAddShortcutItems = new ArrayList<>();
    private ArrayList<ListItem> mAddCombinedGadgetItems = new ArrayList<>();
    private ArrayList<ListItem> mAddSettingsWidgetItems = new ArrayList<>();
    private ArrayList<ListItem> mAddLiveFolderItems = new ArrayList<>();
    private ArrayList<ListItem> mAddFolderItems = new ArrayList<>();
    private ArrayList<ListItem> mAddCHTItems = new ArrayList<>();
    private ArrayList<ArrayList<ListItem>> mAddEXTItems = null;
    private int[] mTitleStrId = {R.string.menu_personalize, R.string.menu_item_add_shortcut, R.string.menu_item_add_widget, R.string.menu_item_add_google_widget, R.string.menu_item_add_live_folder, R.string.menu_item_add_program, R.string.menu_item_add_folder, R.string.menu_item_add_htc_setting_widgets, R.string.cht_group_add_cht_widget_title};
    private int mExtGroups = 0;

    public class ListItem implements HtcListItemSeparable {
        public int GadgetId;
        public final int actionTag;
        public String className;
        public final Drawable image;
        public Intent intent;
        public ComponentName mComponent;
        private boolean mIsSeperator;
        public int mNextAdapter;
        public String packageName;
        public int priority;
        public String summary;
        public String summaryChangedAction;
        public CharSequence text;
        public WidgetItem widgetItem;

        public ListItem(Resources res, int textResourceId, int imageResourceId, int actionTag) {
            this.priority = 200;
            this.mNextAdapter = -1;
            this.mIsSeperator = false;
            this.text = res.getString(textResourceId);
            if (imageResourceId != -1) {
                this.image = res.getDrawable(imageResourceId);
            } else {
                this.image = null;
            }
            this.actionTag = actionTag;
        }

        public ListItem(Resources res, int textResourceId, int imageResourceId, int actionTag, int nextAdapter) {
            this.priority = 200;
            this.mNextAdapter = -1;
            this.mIsSeperator = false;
            this.text = res.getString(textResourceId);
            if (imageResourceId != -1) {
                this.image = res.getDrawable(imageResourceId);
            } else {
                this.image = null;
            }
            this.actionTag = actionTag;
            this.mNextAdapter = nextAdapter;
        }

        public ListItem(Resources res, String str, Drawable icon, int actionTag) {
            this.priority = 200;
            this.mNextAdapter = -1;
            this.mIsSeperator = false;
            this.text = str;
            this.image = icon;
            this.actionTag = actionTag;
        }

        public ListItem(Resources res, String str, Drawable icon, int actionTag, int nextAdapter) {
            this.priority = 200;
            this.mNextAdapter = -1;
            this.mIsSeperator = false;
            this.text = str;
            if (icon != null) {
                this.image = icon;
            } else {
                this.image = null;
            }
            this.actionTag = actionTag;
            this.mNextAdapter = nextAdapter;
        }

        public ListItem(CharSequence textResource, int actionTag, int priority) {
            this.priority = 200;
            this.mNextAdapter = -1;
            this.mIsSeperator = false;
            this.text = textResource;
            this.image = null;
            this.actionTag = actionTag;
            this.priority = priority;
        }

        public ListItem(CharSequence textResource, Drawable icon, int actionTag, int priority) {
            this.priority = 200;
            this.mNextAdapter = -1;
            this.mIsSeperator = false;
            this.text = textResource;
            this.image = icon;
            this.actionTag = actionTag;
            this.priority = priority;
        }

        public ListItem(WidgetProvider.Info item, int actionTag, int priority) {
            this.priority = 200;
            this.mNextAdapter = -1;
            this.mIsSeperator = false;
            this.text = item.label;
            this.image = item.icon;
            this.mComponent = item.provider;
            this.actionTag = actionTag;
            this.priority = priority;
        }

        public ListItem(WidgetProvider.Info.Style item, int actionTag, int priority) {
            this.priority = 200;
            this.mNextAdapter = -1;
            this.mIsSeperator = false;
            this.text = item.getLabel();
            Drawable drawable = null;
            try {
                String packageName = item.getPackageName();
                Resources res = AddAdapter.this.mPackageManager.getResourcesForApplication(packageName);
                drawable = res.getDrawable(item.getPreviewRes());
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }
            this.image = drawable;
            this.mComponent = item.settings;
            this.summary = item.view.scene;
            this.actionTag = actionTag;
            this.priority = priority;
        }

        public ListItem(Resources res, int text, int icon, int actionTag, int nextAdapter, Intent intent, String summaryChangedAction) {
            this.priority = 200;
            this.mNextAdapter = -1;
            this.mIsSeperator = false;
            this.text = res.getString(text);
            this.image = res.getDrawable(icon);
            this.actionTag = actionTag;
            this.intent = intent;
            this.mNextAdapter = nextAdapter;
            this.summaryChangedAction = summaryChangedAction;
        }

        public ListItem(ApplicationInfo appInfo, int actionTag) {
            this.priority = 200;
            this.mNextAdapter = -1;
            this.mIsSeperator = false;
            this.text = appInfo.title;
            this.mComponent = appInfo.intent.getComponent();
            if (appInfo.icon != null) {
                this.image = appInfo.icon;
            } else {
                this.image = null;
                Log.w(AddAdapter.LOG_TAG, "(224):Program icon is null");
            }
            this.priority = appInfo.priority;
            this.actionTag = actionTag;
        }

        public ListItem(PackageManager pm, ResolveInfo resolveInfo, int actionTag) {
            this.priority = 200;
            this.mNextAdapter = -1;
            this.mIsSeperator = false;
            this.text = resolveInfo.loadLabel(pm);
            if (this.text == null && resolveInfo.activityInfo != null) {
                this.text = resolveInfo.activityInfo.name;
            }
            this.packageName = resolveInfo.activityInfo.applicationInfo.packageName;
            this.className = resolveInfo.activityInfo.name;
            this.image = ResourceUtil.getApplicationIcon(pm, resolveInfo.activityInfo);
            this.priority = resolveInfo.priority;
            this.actionTag = actionTag;
        }

        public boolean isWidget() {
            return this.actionTag == 100 || this.actionTag == 106 || this.actionTag == 3 || this.actionTag == 401;
        }

        public boolean isPersonalizeItem() {
            return this.actionTag == 103 || this.actionTag == 104 || this.actionTag == 105;
        }

        public void setSeperator(boolean isSeperator) {
            this.mIsSeperator = isSeperator;
        }

        public boolean shouldDrawOnThis() {
            return this.mIsSeperator ? false : false;
        }

        public boolean shouldSeparate(Object listitem) {
            if (listitem != null && (listitem instanceof HtcListItemSeparable)) {
                return (this.mIsSeperator && !((ListItem) listitem).mIsSeperator) || (!this.mIsSeperator && ((ListItem) listitem).mIsSeperator);
            }
            return true;
        }
    }

    public AddAdapter(Launcher launcher) {
        this.mGadgetManager = null;
        this.mPackageManager = null;
        this.mShowTitleId = 0;
        this.mLauncher = launcher;
        this.mInflater = (LayoutInflater) this.mLauncher.getSystemService("layout_inflater");
        this.mLauncher.mWidgetsManager.setAddAdapter(this);
        if (this.mPackageManager == null) {
            this.mPackageManager = this.mLauncher.getPackageManager();
        }
        if (this.mGadgetManager == null) {
            this.mGadgetManager = AppWidgetManager.getInstance(this.mLauncher);
        }
        loadExtGroups();
        addMenuItems();
        resetItems();
        this.mShowTitleId = this.mTitleStrId[0];
        this.mItems = this.mAddMenuItems;
        this.mPersonalizeSeperatorFontSize = this.mLauncher.getResources().getDimensionPixelSize(R.dimen.personalize_seperator_font_size);
    }

    public synchronized void resetItems() {
        if (this.showCheckLog) {
            Log.w(LOG_TAG, "resetItems start");
        }
        try {
            this.mFxWidgets = WidgetProviderInfoCollector.getWidgetPackages(this.mLauncher);
        } catch (Exception ex) {
            if (localLOGV) {
                Log.d(LOG_TAG, "HTC Fusion widgets error : " + ex.toString());
            }
        }
        addCHTItems();
        addShortcutItems();
        addCombinedGadgetItems();
        addSettingsWidget();
        addFolder();
        addLiveFolder();
        addEXTItems();
        if (this.showCheckLog) {
            Log.w(LOG_TAG, "resetItems end");
        }
    }

    public void setAdapter(int level, int index, boolean isAssignFunction) {
        if (level == 0) {
            addMenuItems();
            if (isAssignFunction) {
                this.mItems = this.maddFuncMenuItems;
                this.mShowTitleId = this.mTitleStrId[1];
            } else {
                this.mShowTitleId = this.mTitleStrId[0];
                this.mItems = this.mAddMenuItems;
                return;
            }
        }
        if (level > 0) {
            switch (index) {
                case 501:
                case ADAPTER_ASSIGN_PROGRAM /* 508 */:
                    addProgramItems();
                    this.mShowTitleId = this.mTitleStrId[5];
                    this.mItems = this.mAddProgramItems;
                    break;
                case ADAPTER_SHORTCUT /* 502 */:
                case ADAPTER_ASSIGN_SHORTCUT /* 509 */:
                    this.mShowTitleId = this.mTitleStrId[1];
                    this.mItems = this.mAddShortcutItems;
                    break;
                case ADAPTER_COMBINED_WIDGET /* 503 */:
                    this.mShowTitleId = this.mTitleStrId[2];
                    this.mItems = this.mAddCombinedGadgetItems;
                    break;
                case ADAPTER_HTC_SETTINGS /* 504 */:
                    this.mShowTitleId = this.mTitleStrId[7];
                    this.mItems = this.mAddSettingsWidgetItems;
                    break;
                case ADAPTER_FOLDER /* 506 */:
                    this.mShowTitleId = this.mTitleStrId[6];
                    this.mItems = this.mAddFolderItems;
                    break;
                case ADAPTER_LIEVE_FOLDER /* 507 */:
                    this.mShowTitleId = this.mTitleStrId[4];
                    this.mItems = this.mAddLiveFolderItems;
                    break;
                case 600:
                    this.mShowTitleId = this.mTitleStrId[8];
                    this.mItems = this.mAddCHTItems;
                    break;
                default:
                    if (index > 600 && index < 700) {
                        for (int i = 0; i < this.mExtGroups; i++) {
                            if (index == this.mExtGroup_id[i]) {
                                this.mShowTitleId = this.mTitleStrId[0];
                                this.mItems = this.mAddEXTItems.get(i);
                                break;
                            }
                        }
                        break;
                    }
                    break;
            }
        }
    }

    private void addMenuItems() {
        if (this.mAddMenuItems != null) {
            updateSummary();
            return;
        }
        this.mAddMenuItems = new ArrayList<>();
        this.maddFuncMenuItems = new ArrayList<>();
        this.mShowTitleId = this.mTitleStrId[0];
        this.mAddMenuItems.clear();
        Resources res = this.mLauncher.getApplicationContext().getResources();
        this.mAddMenuItems.add(new ListItem(res, R.string.personalize_list_personalize_display, -1, 104, -1));
        this.mAddMenuItems.add(new ListItem(res, R.string.personalize_list_scene, R.drawable.scene, 103, -1, new Intent("com.htc.intent.ACTION_PERSONALIZE_SCENE"), "com.htc.intent.ACTION_PERSONALIZE_SCENE_CHANGED"));
        this.mAddMenuItems.add(new ListItem(res, R.string.personalize_list_skin, R.drawable.skin, 103, -1, new Intent("com.htc.intent.ACTION_PERSONALIZE_SKIN"), "com.htc.intent.ACTION_PERSONALIZE_SKIN_CHANGED"));
        this.mAddMenuItems.add(new ListItem(res, R.string.menu_wallpaper, R.drawable.wallpaper, 103, -1, new Intent("com.htc.intent.ACTION_PERSONALIZE_WALLPAPER"), "com.htc.intent.ACTION_PERSONALIZE_WALLPAPER_CHANGED"));
        if (!SettingUtil.isTabletDevice()) {
            this.mAddMenuItems.add(new ListItem(res, R.string.menu_idlescreen, R.drawable.lockscreen, 103, -1, new Intent("com.htc.intent.ACTION_PERSONALIZE_IDLESCREEN"), "com.htc.intent.ACTION_PERSONALIZE_IDLESCREEN_CHANGED"));
        } else {
            this.mAddMenuItems.add(new ListItem(res, R.string.menu_idlescreen, R.drawable.lockscreen, 103, -1, new Intent("com.htc.idlescreen.shortcut.setting"), "com.htc.intent.ACTION_PERSONALIZE_IDLESCREEN_CHANGED"));
        }
        this.mAddMenuItems.add(new ListItem(res, R.string.personalize_list_add_items_to_home, -1, 104, -1));
        int extTmp = 0;
        if (this.mExtGroups > 0) {
            while (extTmp < this.mExtGroups && this.mExtGroup_id[extTmp] <= 620) {
                this.mAddMenuItems.add(new ListItem(res, this.mExtGroup_name[extTmp].toString(), this.mExtGroup_icon[extTmp], ITEM_PERSONALIZE_ADD_TO_HOME, this.mExtGroup_id[extTmp]));
                extTmp++;
            }
        }
        this.mAddMenuItems.add(new ListItem(res, R.string.personalize_list_add_widget_to_home, R.drawable.widget, ITEM_PERSONALIZE_ADD_TO_HOME, ADAPTER_COMBINED_WIDGET, new Intent(Launcher.ACTION_PERSONALIZE_ADD_WIDGET_TO_HOME), Launcher.ACTION_PERSONALIZE_ADD_WIDGET_TO_HOME_CHANGED));
        if (this.mExtGroups > 0) {
            while (extTmp < this.mExtGroups && this.mExtGroup_id[extTmp] <= 680) {
                this.mAddMenuItems.add(new ListItem(res, this.mExtGroup_name[extTmp].toString(), this.mExtGroup_icon[extTmp], ITEM_PERSONALIZE_ADD_TO_HOME, this.mExtGroup_id[extTmp]));
                extTmp++;
            }
        }
        this.mAddMenuItems.add(new ListItem(res, R.string.personalize_list_add_app_to_home, R.drawable.settings_icon_application, ITEM_PERSONALIZE_ADD_TO_HOME, 501, new Intent(Launcher.ACTION_PERSONALIZE_ADD_APP_TO_HOME), Launcher.ACTION_PERSONALIZE_ADD_APP_TO_HOME_CHANGED));
        if (this.mExtGroups > 0) {
            while (extTmp < this.mExtGroups && this.mExtGroup_id[extTmp] <= 650) {
                this.mAddMenuItems.add(new ListItem(res, this.mExtGroup_name[extTmp].toString(), this.mExtGroup_icon[extTmp], ITEM_PERSONALIZE_ADD_TO_HOME, this.mExtGroup_id[extTmp]));
                extTmp++;
            }
        }
        this.mAddMenuItems.add(new ListItem(res, R.string.personalize_list_add_shortcut_to_home, 34079061, ITEM_PERSONALIZE_ADD_TO_HOME, ADAPTER_SHORTCUT, new Intent(Launcher.ACTION_PERSONALIZE_ADD_SHORTCUT_TO_HOME), Launcher.ACTION_PERSONALIZE_ADD_SHORTCUT_TO_HOME_CHANGED));
        if (this.mExtGroups > 0) {
            while (extTmp < this.mExtGroups && this.mExtGroup_id[extTmp] <= 640) {
                this.mAddMenuItems.add(new ListItem(res, this.mExtGroup_name[extTmp].toString(), this.mExtGroup_icon[extTmp], ITEM_PERSONALIZE_ADD_TO_HOME, this.mExtGroup_id[extTmp]));
                extTmp++;
            }
        }
        this.mAddMenuItems.add(new ListItem(res, R.string.folder_name, 34079058, ITEM_PERSONALIZE_ADD_TO_HOME, ADAPTER_FOLDER, new Intent(Launcher.ACTION_PERSONALIZE_ADD_FOLDER_TO_HOME), Launcher.ACTION_PERSONALIZE_ADD_FOLDER_TO_HOME_CHANGED));
        if (this.mExtGroups > 0) {
            while (extTmp < this.mExtGroups) {
                this.mAddMenuItems.add(new ListItem(res, this.mExtGroup_name[extTmp].toString(), this.mExtGroup_icon[extTmp], ITEM_PERSONALIZE_ADD_TO_HOME, this.mExtGroup_id[extTmp]));
                extTmp++;
            }
        }
        this.mAddMenuItems.add(new ListItem(res, R.string.personalize_list_personalize_sound, -1, 104, -1));
        Intent data = new Intent();
        Bundle bundle = new Bundle();
        bundle.putInt("SDMListType", 1);
        data.putExtras(bundle);
        data.setClassName("com.htc.sdm", "com.htc.sdm.activity.SoundSetList");
        this.mAddMenuItems.add(new ListItem(res, R.string.personalize_list_sound_set, R.drawable.sound_set, 103, -1, data, "com.htc.intent.ACTION_PERSONALIZE_SOUND_SET_CHANGED"));
        if (!SettingUtil.isTabletDevice()) {
            Intent data2 = new Intent();
            Bundle bundle2 = new Bundle();
            bundle2.putInt("SDMListType", 2);
            data2.putExtras(bundle2);
            data2.setClassName("com.htc.sdm", "com.htc.sdm.activity.SoundSetList");
            this.mAddMenuItems.add(new ListItem(res, R.string.personalize_list_ringtone, R.drawable.ringtone, 103, -1, data2, "com.htc.intent.ACTION_PERSONALIZE_RINGTONE_CHANGED"));
        }
        Intent data3 = new Intent();
        new Bundle();
        data3.setClassName("com.htc.sdm", "com.htc.sdm.activity.SDMNotificationList");
        this.mAddMenuItems.add(new ListItem(res, R.string.personalize_list_notification_sound, R.drawable.notification_sound, 103, -1, data3, "com.htc.intent.ACTION_PERSONALIZE_NOTIFICATION_SOUNDS_CHANGED"));
        Intent data4 = new Intent();
        Bundle bundle3 = new Bundle();
        bundle3.putInt("SDMListType", 4);
        data4.putExtras(bundle3);
        data4.setClassName("com.htc.sdm", "com.htc.sdm.activity.SoundSetList");
        this.mAddMenuItems.add(new ListItem(res, R.string.personalize_list_alart, R.drawable.alarm, 103, -1, data4, "com.htc.intent.ACTION_PERSONALIZE_ALARM_CHANGED"));
        updateSummary();
        this.maddFuncMenuItems.add(new ListItem(res, R.string.personalize_list_add_app_to_home, 34079056, ITEM_PERSONALIZE_ADD_TO_HOME, ADAPTER_ASSIGN_PROGRAM, new Intent(Launcher.ACTION_PERSONALIZE_ADD_APP_TO_HOME), Launcher.ACTION_PERSONALIZE_ADD_APP_TO_HOME_CHANGED));
        this.maddFuncMenuItems.add(new ListItem(res, R.string.personalize_list_add_shortcut_to_home, 34079061, ITEM_PERSONALIZE_ADD_TO_HOME, ADAPTER_ASSIGN_SHORTCUT, new Intent(Launcher.ACTION_PERSONALIZE_ADD_SHORTCUT_TO_HOME), Launcher.ACTION_PERSONALIZE_ADD_SHORTCUT_TO_HOME_CHANGED));
    }

    private void addSettingsWidget() {
        this.mShowTitleId = this.mTitleStrId[7];
        final ArrayList<ListItem> list = new ArrayList<>();
        ApplicationManager am = ApplicationManager.instance(this.mLauncher);
        ListItem[] arr$ = this.mLauncher.mWidgetsManager.listListItems(200);
        for (ListItem item : arr$) {
            String packageName = item.widgetItem.mPackageName;
            String widgetName = item.widgetItem.mWidgetName;
            if (localLOGV) {
                Log.d(ITEM_INFO_LOG, "HTC Widget(setting)(" + ((Object) item.text) + "), " + packageName + "/" + widgetName);
            }
            if (!am.inHideCustomizationList(packageName, widgetName, 4)) {
                item.priority = am.getCustomizationListPriority(packageName, widgetName, 4);
                list.add(item);
            }
        }
        if (this.mFxWidgets != null) {
            for (WidgetProvider.Info item2 : this.mFxWidgets) {
                Logger.d(LOG_TAG, "category: " + item2.category);
                if (item2.category.equalsIgnoreCase("settings")) {
                    String packageName2 = item2.provider.getPackageName();
                    String className = item2.provider.getClassName();
                    if (localLOGV) {
                        Log.d(ITEM_INFO_LOG, "FxWidget(setting)(" + ((Object) item2.label) + "), " + packageName2 + "/" + className);
                    }
                    if (!am.inHideCustomizationList(packageName2, className, 5)) {
                        ListItem listItem = new ListItem(item2, ITEM_FXWIDGET, 5);
                        listItem.priority = am.getCustomizationListPriority(packageName2, className, 5);
                        list.add(0, listItem);
                    }
                }
            }
        }
        Collections.sort(list, new Comparator<ListItem>() { // from class: com.htc.launcher.AddAdapter.1
            @Override // java.util.Comparator
            public int compare(ListItem lhs, ListItem rhs) {
                if (lhs.priority < rhs.priority) {
                    return -1;
                }
                if (lhs.priority > rhs.priority) {
                    return 1;
                }
                return Utilities.sCollator.compare(lhs.text, rhs.text);
            }
        });
        this.mLauncher.runOnUiThread(new Runnable() { // from class: com.htc.launcher.AddAdapter.2
            @Override // java.lang.Runnable
            public void run() {
                AddAdapter.this.mAddSettingsWidgetItems.clear();
                AddAdapter.this.mAddSettingsWidgetItems.addAll(list);
            }
        });
    }

    private void addFolder() {
        this.mShowTitleId = this.mTitleStrId[6];
        this.mAddFolderItems.clear();
        Resources res = this.mLauncher.getResources();
        this.mAddFolderItems.add(new ListItem(res, R.string.htc_group_folder_new_folder, 34079058, 5));
        if (this.mPackageManager == null) {
            this.mPackageManager = this.mLauncher.getPackageManager();
        }
        final ArrayList<ListItem> tempList = new ArrayList<>();
        Intent liveFolderIntent = new Intent("android.intent.action.CREATE_LIVE_FOLDER");
        Intent pickIntent = new Intent("android.intent.action.PICK_ACTIVITY");
        pickIntent.putExtra("android.intent.extra.INTENT", liveFolderIntent);
        Intent targetIntent = new Intent("android.intent.action.MAIN", (Uri) null);
        targetIntent.addCategory("android.intent.category.DEFAULT");
        Parcelable parcel = pickIntent.getParcelableExtra("android.intent.extra.INTENT");
        if (parcel instanceof Intent) {
            targetIntent = (Intent) parcel;
        }
        targetIntent.setComponent(null);
        List<ResolveInfo> list = this.mPackageManager.queryIntentActivities(targetIntent, 0);
        Collections.sort(list, new ResolveInfo.DisplayNameComparator(this.mPackageManager));
        int listSize = list.size();
        for (int i = 0; i < listSize; i++) {
            ResolveInfo resolveInfo = list.get(i);
            tempList.add(new ListItem(this.mPackageManager, resolveInfo, EXCUTE_LIVE_FOLDER));
        }
        this.mLauncher.runOnUiThread(new Runnable() { // from class: com.htc.launcher.AddAdapter.3
            @Override // java.lang.Runnable
            public void run() {
                AddAdapter.this.mAddFolderItems.addAll(tempList);
            }
        });
    }

    private void addLiveFolder() {
        this.mShowTitleId = this.mTitleStrId[4];
        this.mAddLiveFolderItems.clear();
        if (this.mPackageManager == null) {
            this.mPackageManager = this.mLauncher.getPackageManager();
        }
        final ArrayList<ListItem> tempList = new ArrayList<>();
        Intent liveFolderIntent = new Intent("android.intent.action.CREATE_LIVE_FOLDER");
        Intent pickIntent = new Intent("android.intent.action.PICK_ACTIVITY");
        pickIntent.putExtra("android.intent.extra.INTENT", liveFolderIntent);
        Intent targetIntent = new Intent("android.intent.action.MAIN", (Uri) null);
        targetIntent.addCategory("android.intent.category.DEFAULT");
        Parcelable parcel = pickIntent.getParcelableExtra("android.intent.extra.INTENT");
        if (parcel instanceof Intent) {
            targetIntent = (Intent) parcel;
        }
        targetIntent.setComponent(null);
        List<ResolveInfo> list = this.mPackageManager.queryIntentActivities(targetIntent, 0);
        Collections.sort(list, new ResolveInfo.DisplayNameComparator(this.mPackageManager));
        int listSize = list.size();
        for (int i = 0; i < listSize; i++) {
            ResolveInfo resolveInfo = list.get(i);
            tempList.add(new ListItem(this.mPackageManager, resolveInfo, EXCUTE_LIVE_FOLDER));
        }
        this.mLauncher.runOnUiThread(new Runnable() { // from class: com.htc.launcher.AddAdapter.4
            @Override // java.lang.Runnable
            public void run() {
                AddAdapter.this.mAddLiveFolderItems.clear();
                AddAdapter.this.mAddLiveFolderItems.addAll(tempList);
            }
        });
    }

    private void addProgramItems() {
        this.mShowTitleId = this.mTitleStrId[5];
        ArrayList<ListItem> tempList = new ArrayList<>();
        FilterableAndSortableApplicationInfoList appInfos = Launcher.getModel().getApplications();
        ArrayList<ApplicationInfo> temp = new ArrayList<>();
        for (int i = 0; i < appInfos.originalSize(); i++) {
            temp.add(appInfos.originalGet(i));
        }
        Collections.sort(temp, FilterableAndSortableApplicationInfoList.ALPHABET);
        Iterator i$ = temp.iterator();
        while (i$.hasNext()) {
            ApplicationInfo appInfo = i$.next();
            tempList.add(new ListItem(appInfo, EXCUTE_PROGRAM));
        }
        this.mAddProgramItems.clear();
        this.mAddProgramItems.addAll(tempList);
    }

    private void addShortcutItems() {
        this.mShowTitleId = this.mTitleStrId[1];
        ApplicationManager am = ApplicationManager.instance(this.mLauncher);
        if (this.mPackageManager == null) {
            this.mPackageManager = this.mLauncher.getPackageManager();
        }
        final ArrayList<ListItem> tempList = new ArrayList<>();
        Intent shortcutIntent = new Intent("android.intent.action.CREATE_SHORTCUT");
        List<ResolveInfo> list = this.mPackageManager.queryIntentActivities(shortcutIntent, 0);
        int listSize = list.size();
        for (int i = 0; i < listSize; i++) {
            ResolveInfo resolveInfo = list.get(i);
            String packageName = resolveInfo.activityInfo.applicationInfo.packageName;
            String className = resolveInfo.activityInfo.name;
            if (!am.inHideCustomizationList(packageName, className, 3) && !packageName.equals("com.android.mms")) {
                resolveInfo.priority = am.getCustomizationListPriority(packageName, className, 3);
                tempList.add(new ListItem(this.mPackageManager, resolveInfo, EXCUTE_SHORTCUT));
            }
        }
        Collections.sort(tempList, new Comparator<ListItem>() { // from class: com.htc.launcher.AddAdapter.5
            @Override // java.util.Comparator
            public int compare(ListItem lhs, ListItem rhs) {
                if (lhs.priority < rhs.priority) {
                    return -1;
                }
                if (lhs.priority > rhs.priority) {
                    return 1;
                }
                return Utilities.sCollator.compare(lhs.text, rhs.text);
            }
        });
        this.mLauncher.runOnUiThread(new Runnable() { // from class: com.htc.launcher.AddAdapter.6
            @Override // java.lang.Runnable
            public void run() {
                AddAdapter.this.mAddShortcutItems.clear();
                AddAdapter.this.mAddShortcutItems.addAll(tempList);
            }
        });
    }

    private void loadExtGroups() {
        Bundle moduleBundle = WidgetPackageManager.getModuleBundle(this.mLauncher.getApplicationContext());
        Bundle extBundle = moduleBundle.getBundle("ext_groups");
        if (extBundle != null) {
            this.mExtGroups = extBundle.size();
            this.mExtGroup_id = new int[this.mExtGroups];
            this.mExtGroup_name = new String[this.mExtGroups];
            this.mExtGroup_icon = new Drawable[this.mExtGroups];
            for (int i = 0; i < this.mExtGroups; i++) {
                String key = "plenty_set" + (i + 1);
                Bundle childBundle = extBundle.getBundle(key);
                int gId = Integer.parseInt(childBundle.getString("group_id"));
                String gName = childBundle.getString("group_name");
                String gIconFileName = childBundle.getString("group_icon");
                this.mExtGroup_id[i] = gId;
                this.mExtGroup_name[i] = gName;
                if (gIconFileName != null) {
                    String gIconFilePath = WidgetPackageManager.manipulateResourcePath(gIconFileName);
                    BitmapDrawable icon = new BitmapDrawable(this.mLauncher.getResources(), gIconFilePath);
                    icon.setTargetDensity(this.mLauncher.getResources().getDisplayMetrics());
                    this.mExtGroup_icon[i] = icon;
                } else {
                    Log.w(LOG_TAG, "Cannot get icon path of customize group (" + gName + ") from customize bundle.");
                    this.mExtGroup_icon[i] = null;
                }
            }
        }
    }

    private void addEXTItems() {
        int priority;
        BitmapDrawable icon;
        String class_name;
        if (this.mExtGroups > 0) {
            Bundle moduleBundle = WidgetPackageManager.getModuleBundle(this.mLauncher.getApplicationContext());
            this.mAddEXTItems = new ArrayList<>(this.mExtGroups);
            for (int i = 0; i < this.mExtGroups; i++) {
                this.mAddEXTItems.add(new ArrayList<>());
            }
            Bundle extBundle = moduleBundle.getBundle("ext_items");
            if (extBundle != null) {
                int mExtItemsSize = extBundle.size();
                if (this.mPackageManager == null) {
                    this.mPackageManager = this.mLauncher.getPackageManager();
                }
                if (this.mGadgetManager == null) {
                    this.mGadgetManager = AppWidgetManager.getInstance(this.mLauncher);
                }
                PackageManager pm = this.mPackageManager;
                Intent intent = new Intent("android.appwidget.action.APPWIDGET_UPDATE");
                List<ResolveInfo> broadcastReceivers = pm.queryBroadcastReceivers(intent, 128);
                int N1 = broadcastReceivers.size();
                List<AppWidgetProviderInfo> appWidgetList = this.mGadgetManager.getInstalledProviders();
                ListItem[] htcWidgetList = this.mLauncher.mWidgetsManager.listListItems(100);
                Intent shortcutIntent = new Intent("android.intent.action.CREATE_SHORTCUT");
                List<ResolveInfo> shortcutList = this.mPackageManager.queryIntentActivities(shortcutIntent, 0);
                Intent mainIntent = new Intent("android.intent.action.MAIN", (Uri) null);
                mainIntent.addCategory("android.intent.category.LAUNCHER");
                List<ResolveInfo> apps = this.mPackageManager.queryIntentActivities(mainIntent, 0);
                for (int j = 0; j < mExtItemsSize; j++) {
                    String key = "plenty_set" + (j + 1);
                    Bundle childBundle = extBundle.getBundle(key);
                    String itemtype = childBundle.getString("itemtype");
                    if (childBundle.getString("group_id") != null) {
                        int group_id = Integer.parseInt(childBundle.getString("group_id"));
                        int group_index = 0;
                        while (group_index < this.mExtGroups && this.mExtGroup_id[group_index] != group_id) {
                            group_index++;
                        }
                        if (group_index != this.mExtGroups) {
                            ArrayList<ListItem> group = this.mAddEXTItems.get(group_index);
                            if ("2".equals(itemtype)) {
                                int N = appWidgetList.size();
                                String package_name = childBundle.getString("package");
                                for (int i2 = 0; i2 < N; i2++) {
                                    AppWidgetProviderInfo info = appWidgetList.get(i2);
                                    String appWidgetPackageName = info.provider.getPackageName();
                                    String appWidgetClassName = info.provider.getClassName();
                                    if (appWidgetPackageName.equals(package_name) && ((class_name = childBundle.getString("class")) == null || class_name.equals(appWidgetClassName))) {
                                        String name = info.label;
                                        int k = 0;
                                        while (true) {
                                            if (k >= N1) {
                                                break;
                                            }
                                            ResolveInfo ri = broadcastReceivers.get(k);
                                            if (!ri.activityInfo.packageName.equals(info.provider.getPackageName()) || !ri.activityInfo.name.equals(info.provider.getClassName())) {
                                                k++;
                                            } else {
                                                name = ri.activityInfo.loadLabel(this.mPackageManager).toString();
                                                break;
                                            }
                                        }
                                        Drawable icon2 = null;
                                        Log.w(LOG_TAG, "info.icon:" + info.icon);
                                        if (info.icon != 0 && (icon2 = pm.getDrawable(info.provider.getPackageName(), info.icon, null)) == null) {
                                            Log.w(LOG_TAG, "Can't load icon drawable 0x" + Integer.toHexString(info.icon) + " for provider: " + info.provider);
                                        }
                                        ListItem listitem = new ListItem(this.mLauncher.getResources(), name, icon2, EXCUTE_GOOGLE_WIDGET);
                                        String priority2 = childBundle.getString("priority");
                                        if (priority2 == null) {
                                            listitem.priority = 200;
                                        } else {
                                            listitem.priority = Integer.parseInt(priority2);
                                        }
                                        listitem.GadgetId = this.mGadgetId;
                                        listitem.mComponent = info.provider;
                                        listitem.packageName = appWidgetPackageName;
                                        listitem.className = appWidgetClassName;
                                        group.add(listitem);
                                    }
                                }
                            } else if ("1".equals(itemtype)) {
                                String package_name2 = childBundle.getString(LauncherSettings.WidgetItemTypes.PACKAGE_NAME);
                                String widget_name = childBundle.getString(LauncherSettings.WidgetItemTypes.WIDGET_NAME);
                                int len$ = htcWidgetList.length;
                                int i$ = 0;
                                while (true) {
                                    if (i$ < len$) {
                                        ListItem item = htcWidgetList[i$];
                                        if (!item.widgetItem.mPackageName.equals(package_name2) || !item.widgetItem.mWidgetName.equals(widget_name)) {
                                            i$++;
                                        } else {
                                            String priority3 = childBundle.getString("priority");
                                            if (priority3 == null) {
                                                item.priority = 200;
                                            } else {
                                                item.priority = Integer.parseInt(priority3);
                                            }
                                            group.add(item);
                                        }
                                    }
                                }
                            } else if ("4".equals(itemtype)) {
                                String url = childBundle.getString("url");
                                String title = childBundle.getString("name");
                                String iconName = childBundle.getString(LauncherSettings.Favorites.ICON);
                                String priorityText = childBundle.getString("priority");
                                if (priorityText == null) {
                                    priority = 200;
                                } else {
                                    priority = Integer.parseInt(priorityText);
                                }
                                if (iconName != null) {
                                    String gIconFilePath = WidgetPackageManager.manipulateResourcePath(iconName);
                                    icon = new BitmapDrawable(this.mLauncher.getResources(), gIconFilePath);
                                    icon.setTargetDensity(this.mLauncher.getResources().getDisplayMetrics());
                                } else {
                                    Log.w(LOG_TAG, "Cannot get bookmark icon path of bookmark(" + title + ") from customize bundle.");
                                    icon = null;
                                }
                                ListItem item2 = new ListItem(title, icon, EXCUTE_BOOKMARK_SHORTCUT, priority);
                                item2.intent = createShortcutIntent(url, title, icon.getBitmap(), null);
                                group.add(item2);
                            } else {
                                String packageName = childBundle.getString("package");
                                Iterator i$2 = shortcutList.iterator();
                                while (true) {
                                    if (!i$2.hasNext()) {
                                        break;
                                    }
                                    ResolveInfo resolveInfo = i$2.next();
                                    if (resolveInfo.activityInfo.applicationInfo.packageName.equals(packageName)) {
                                        String className = childBundle.getString("class");
                                        if (className == null || className.equals(resolveInfo.activityInfo.name)) {
                                            String priority4 = childBundle.getString("priority");
                                            if (priority4 == null) {
                                                resolveInfo.priority = 200;
                                            } else {
                                                resolveInfo.priority = Integer.parseInt(priority4);
                                            }
                                            group.add(new ListItem(this.mPackageManager, resolveInfo, EXCUTE_SHORTCUT));
                                        }
                                    }
                                }
                                Iterator i$3 = apps.iterator();
                                while (true) {
                                    if (i$3.hasNext()) {
                                        ResolveInfo info2 = i$3.next();
                                        if (info2.activityInfo.applicationInfo.packageName.equals(packageName)) {
                                            String className2 = childBundle.getString("class");
                                            if (className2 == null || className2.equals(info2.activityInfo.name)) {
                                                ComponentName componentName = new ComponentName(info2.activityInfo.applicationInfo.packageName, info2.activityInfo.name);
                                                ApplicationInfo application = new ApplicationInfo();
                                                application.setActivity(componentName, 270532608);
                                                application.title = info2.loadLabel(this.mPackageManager);
                                                if (application.title == null) {
                                                    application.title = info2.activityInfo.name;
                                                }
                                                try {
                                                    application.icon = ResourceUtil.getApplicationIcon(pm, info2.activityInfo);
                                                } catch (Resources.NotFoundException e) {
                                                    Log.w(LOG_TAG, "AddAdapter.addEXTItems() - icon not found.");
                                                }
                                                String priority5 = childBundle.getString("priority");
                                                if (priority5 == null) {
                                                    application.priority = 200;
                                                } else {
                                                    application.priority = Integer.parseInt(priority5);
                                                }
                                                TFC.d("VivoWCTGBS_246", "AddAdapter.addEXTItems: title=" + ((Object) application.title) + " pkg=" + info2.activityInfo.applicationInfo.packageName + " priority=" + application.priority + " modified=" + application.lastModifiedTime);
                                                group.add(new ListItem(application, EXCUTE_PROGRAM));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                for (int i3 = 0; i3 < this.mExtGroups; i3++) {
                    Collections.sort(this.mAddEXTItems.get(i3), new Comparator<ListItem>() { // from class: com.htc.launcher.AddAdapter.7
                        @Override // java.util.Comparator
                        public int compare(ListItem lhs, ListItem rhs) {
                            return (lhs.priority >= rhs.priority && lhs.priority > rhs.priority) ? 1 : -1;
                        }
                    });
                }
            }
        }
    }

    private void addCHTItems() {
        final List<ListItem> tempList = new ArrayList<>();
        ListItem[] arr$ = this.mLauncher.mWidgetsManager.listListItems(ITEM_CATEGORY_CHT_WIDGET);
        for (ListItem item : arr$) {
            tempList.add(item);
        }
        Collections.sort(tempList, new Comparator<ListItem>() { // from class: com.htc.launcher.AddAdapter.8
            @Override // java.util.Comparator
            public int compare(ListItem lhs, ListItem rhs) {
                return Utilities.sCollator.compare(lhs.text, rhs.text);
            }
        });
        this.mLauncher.runOnUiThread(new Runnable() { // from class: com.htc.launcher.AddAdapter.9
            @Override // java.lang.Runnable
            public void run() {
                AddAdapter.this.mAddCHTItems.clear();
                AddAdapter.this.mAddCHTItems.addAll(tempList);
            }
        });
    }

    private void addCombinedGadgetItems() {
        this.mShowTitleId = this.mTitleStrId[2];
        ApplicationManager am = ApplicationManager.instance(this.mLauncher);
        final ArrayList<ListItem> tempList = new ArrayList<>();
        ListItem[] arr$ = this.mLauncher.mWidgetsManager.listListItems(100);
        for (ListItem item : arr$) {
            String packageName = item.widgetItem.mPackageName;
            String widgetName = item.widgetItem.mWidgetName;
            if (localLOGV) {
                Log.d(ITEM_INFO_LOG, "HTC Widget(" + ((Object) item.text) + "), " + packageName + "/" + widgetName);
            }
            if (!am.inHideCustomizationList(packageName, widgetName, 4)) {
                item.priority = am.getCustomizationListPriority(packageName, widgetName, 4);
                tempList.add(item);
            }
        }
        if (this.mFxWidgets != null) {
            for (WidgetProvider.Info item2 : this.mFxWidgets) {
                if (item2.category.contains("default")) {
                    String packageName2 = item2.provider.getPackageName();
                    String className = item2.provider.getClassName();
                    if (localLOGV) {
                        Log.d(ITEM_INFO_LOG, "FxWidget(" + ((Object) item2.label) + "), " + packageName2 + "/" + className);
                    }
                    if (!am.inHideCustomizationList(packageName2, className, 5)) {
                        ListItem listItem = new ListItem(item2, ITEM_FXWIDGET, 5);
                        listItem.priority = am.getCustomizationListPriority(packageName2, className, 5);
                        tempList.add(0, listItem);
                    }
                }
            }
        }
        Resources res = this.mLauncher.getResources();
        ListItem settingsItem = new ListItem(res, 34341376, 34079060, -1);
        settingsItem.mNextAdapter = ADAPTER_HTC_SETTINGS;
        tempList.add(settingsItem);
        if (this.mGadgetManager == null) {
            this.mGadgetManager = AppWidgetManager.getInstance(this.mLauncher);
        }
        if (this.mPackageManager == null) {
            this.mPackageManager = this.mLauncher.getPackageManager();
        }
        PackageManager pm = this.mPackageManager;
        Intent intent = new Intent("android.appwidget.action.APPWIDGET_UPDATE");
        List<ResolveInfo> broadcastReceivers = pm.queryBroadcastReceivers(intent, 128);
        int N1 = broadcastReceivers.size();
        List<AppWidgetProviderInfo> installed = this.mGadgetManager.getInstalledProviders();
        int N = installed.size();
        for (int i = 0; i < N; i++) {
            AppWidgetProviderInfo info = installed.get(i);
            String packageName3 = info.provider.getPackageName();
            String className2 = info.provider.getClassName();
            if (localLOGV) {
                Log.d(ITEM_INFO_LOG, "App Widget(" + info.label + "), " + packageName3 + "/" + className2);
            }
            if (!am.inHideCustomizationList(packageName3, className2, 2)) {
                String name = info.label;
                int j = 0;
                while (true) {
                    if (j >= N1) {
                        break;
                    }
                    ResolveInfo ri = broadcastReceivers.get(j);
                    if (!ri.activityInfo.packageName.equals(info.provider.getPackageName()) || !ri.activityInfo.name.equals(info.provider.getClassName())) {
                        j++;
                    } else {
                        name = ri.activityInfo.loadLabel(this.mPackageManager).toString();
                        break;
                    }
                }
                Drawable icon = null;
                Log.w(LOG_TAG, "info.icon:" + info.icon);
                if (info.icon != 0 && (icon = pm.getDrawable(info.provider.getPackageName(), info.icon, null)) == null) {
                    Log.w(LOG_TAG, "Can't load icon drawable 0x" + Integer.toHexString(info.icon) + " for provider: " + info.provider);
                }
                ListItem listitem = new ListItem(this.mLauncher.getResources(), name, icon, EXCUTE_GOOGLE_WIDGET);
                listitem.priority = am.getCustomizationListPriority(packageName3, className2, 2);
                listitem.GadgetId = this.mGadgetId;
                listitem.mComponent = info.provider;
                listitem.packageName = info.provider.getPackageName();
                listitem.className = info.provider.getClassName();
                tempList.add(listitem);
            }
        }
        Collections.sort(tempList, new Comparator<ListItem>() { // from class: com.htc.launcher.AddAdapter.10
            @Override // java.util.Comparator
            public int compare(ListItem lhs, ListItem rhs) {
                if (lhs.priority < rhs.priority) {
                    return -1;
                }
                if (lhs.priority > rhs.priority) {
                    return 1;
                }
                return Utilities.sCollator.compare(lhs.text, rhs.text);
            }
        });
        tempList.add(0, new ListItem(this.mLauncher.getString(R.string.all_htc_widgets), this.mLauncher.getResources().getDrawable(R.drawable.icon_htc_logo), 102, ApplicationManager.ALL_PROGRAM_LIST_HIGHEST_PRIORITY));
        String resourceText = null;
        try {
            if (SettingUtil.sIsCSPackageInstalled) {
                Resources resources = pm.getResourcesForApplication(WIDGET_DOWNLOAD_MANAGER_PACKAGE);
                resourceText = DOWNLOAD_MANAGER_TEXT;
                int textResId = resources.getIdentifier(DOWNLOAD_MANAGER_TEXT, "string", WIDGET_DOWNLOAD_MANAGER_PACKAGE);
                String text = resources.getString(textResId);
                if (localLOGV) {
                    Log.d(LOG_TAG, "text : " + text);
                }
                tempList.add(0, new ListItem(text, 101, ApplicationManager.ALL_PROGRAM_LIST_HIGHEST_PRIORITY));
            }
        } catch (PackageManager.NameNotFoundException e) {
            Log.d(LOG_TAG, "download manager not found : com.htc.wdm");
        } catch (Resources.NotFoundException ex) {
            Log.e(LOG_TAG, "resource not found : " + resourceText, ex);
        }
        this.mLauncher.runOnUiThread(new Runnable() { // from class: com.htc.launcher.AddAdapter.11
            @Override // java.lang.Runnable
            public void run() {
                AddAdapter.this.mAddCombinedGadgetItems.clear();
                AddAdapter.this.mAddCombinedGadgetItems.addAll(tempList);
            }
        });
    }

    public boolean haseNextLevel(int position) {
        return this.mItems.size() > position && this.mItems.get(position).actionTag == -1;
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public int getItemViewType(int position) {
        ListItem item = (ListItem) getItem(position);
        if (item.actionTag == 104 || item.actionTag == 200) {
            return 0;
        }
        if (item.isPersonalizeItem() || item.isWidget()) {
            return 1;
        }
        if (item.actionTag == 101) {
            return 3;
        }
        if (haseNextLevel(position)) {
            return 4;
        }
        if (item.actionTag == 102) {
            return 5;
        }
        return 2;
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public int getViewTypeCount() {
        return 6;
    }

    @Override // android.widget.Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = createView(position, parent);
        }
        ListItem item = (ListItem) getItem(position);
        int viewType = getItemViewType(position);
        if (viewType == 0) {
            TextView folderItemLayout = (TextView) convertView.findViewById(R.id.sub_header_text);
            folderItemLayout.setText(item.text);
            Resources res = this.mLauncher.getApplicationContext().getResources();
            if (res != null) {
                folderItemLayout.setPadding(res.getDimensionPixelSize(R.dimen.personalize_seperator_text_left_margin), 0, 0, 0);
            }
            item.setSeperator(true);
            convertView.setBackgroundResource(CustomResourceUtil.getDrawableResIdentifier(this.mLauncher, "activity_title_bar", R.drawable.activity_title_bar));
            convertView.setTag(item);
        } else if (viewType == 1) {
            if (item.isPersonalizeItem()) {
                ImageView icon = (ImageView) convertView.findViewById(33685530);
                TextView summary = (TextView) convertView.findViewById(33685524);
                TextView title = (TextView) convertView.findViewById(33685520);
                icon.setImageDrawable(item.image);
                title.setText(item.text);
                summary.setText(item.summary);
                convertView.setTag(item);
            } else {
                FrameLayout frameLayout = (FrameLayout) convertView;
                frameLayout.setTag(item);
                TextView textView = (TextView) frameLayout.findViewById(33685520);
                textView.setText(item.text);
                TextView text2View = (TextView) frameLayout.findViewById(33685524);
                switch (item.actionTag) {
                    case 100:
                        text2View.setText("HTC");
                        break;
                    case ITEM_FXWIDGET /* 106 */:
                        text2View.setText("HTC");
                        break;
                    default:
                        text2View.setText("Android");
                        break;
                }
                ImageView imageView = (ImageView) frameLayout.findViewById(33685530);
                if (item.image != null) {
                    imageView.setImageDrawable(item.image);
                } else {
                    imageView.setImageDrawable(this.mLauncher.getResources().getDrawable(R.drawable.ic_launcher_empty));
                    if (localLOGV) {
                        Log.v(LOG_TAG, "AddAdapter(919):List items's icon is null");
                    }
                }
            }
        } else if (viewType == 3) {
            TextView textView2 = (TextView) convertView.findViewById(33685520);
            textView2.setText(item.text);
            ImageView rightIcon = (ImageView) convertView.findViewById(33685531);
            switch (item.actionTag) {
                case 101:
                    rightIcon.setImageResource(CustomResourceUtil.getDrawableResIdentifier(this.mLauncher, "rosie_list_item_right_btn_newapp", R.drawable.list_item_right_btn_newapp));
                    break;
                case 102:
                    rightIcon.setImageResource(CustomResourceUtil.getDrawableResIdentifier(this.mLauncher, "common_more_selected", R.drawable.list_item_right_btn));
                    break;
            }
            convertView.setTag(item);
        } else if (viewType == 4) {
            TextView textView3 = (TextView) convertView.findViewById(33685520);
            textView3.setText(item.text);
            ImageView imageView2 = (ImageView) convertView.findViewById(33685530);
            if (item.image != null) {
                imageView2.setImageDrawable(item.image);
            } else {
                imageView2.setImageDrawable(this.mLauncher.getResources().getDrawable(R.drawable.ic_launcher_empty));
                if (localLOGV) {
                    Log.v(LOG_TAG, "AddAdapter(919):List items's icon is null");
                }
            }
            ((ImageView) convertView.findViewById(33685531)).setImageResource(CustomResourceUtil.getDrawableResIdentifier(this.mLauncher, "common_more", R.drawable.common_more));
            convertView.setTag(item);
        } else if (viewType == 5) {
            TextView textView4 = (TextView) convertView.findViewById(33685520);
            textView4.setText(item.text);
            ImageView imageView3 = (ImageView) convertView.findViewById(33685530);
            if (item.image != null) {
                imageView3.setImageDrawable(item.image);
            } else {
                imageView3.setImageDrawable(this.mLauncher.getResources().getDrawable(R.drawable.ic_launcher_empty));
                if (localLOGV) {
                    Log.v(LOG_TAG, "AddAdapter(919):List items's icon is null");
                }
            }
            convertView.setTag(item);
        } else {
            TextView textView5 = (TextView) convertView.findViewById(33685520);
            ImageView imageView4 = (ImageView) convertView.findViewById(33685530);
            textView5.setText(item.text);
            if (item.image != null) {
                imageView4.setImageDrawable(item.image);
            } else {
                imageView4.setImageDrawable(this.mLauncher.getResources().getDrawable(R.drawable.ic_launcher_empty));
                if (localLOGV) {
                    Log.v(LOG_TAG, "AddAdapter(919):List items's icon is null");
                }
            }
            convertView.setTag(item);
        }
        return convertView;
    }

    private View createView(int position, ViewGroup parent) {
        int viewType = getItemViewType(position);
        switch (viewType) {
            case 0:
                View v = this.mInflater.inflate(R.layout.personalize_list_sub_header, parent, false);
                v.setLayoutParams(new HtcAbsListView.LayoutParams(-1, -2));
                return v;
            case 1:
                View v2 = this.mInflater.inflate(34144361, parent, false);
                TextView textView = (TextView) v2.findViewById(33685520);
                textView.setEllipsize(TextUtils.TruncateAt.MARQUEE);
                textView.setHorizontalFadingEdgeEnabled(true);
                ImageView imageView = (ImageView) v2.findViewById(33685530);
                imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                return v2;
            case 2:
                View v3 = this.mInflater.inflate(34144371, parent, false);
                TextView textView2 = (TextView) v3.findViewById(33685520);
                textView2.setEllipsize(TextUtils.TruncateAt.MARQUEE);
                textView2.setHorizontalFadingEdgeEnabled(true);
                ImageView imageView2 = (ImageView) v3.findViewById(33685530);
                imageView2.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                return v3;
            case 3:
                View v4 = this.mInflater.inflate(34144361, parent, false);
                TextView textView3 = (TextView) v4.findViewById(33685520);
                textView3.setEllipsize(TextUtils.TruncateAt.MARQUEE);
                textView3.setHorizontalFadingEdgeEnabled(true);
                ((TextView) v4.findViewById(33685524)).setVisibility(8);
                ImageView imageView3 = (ImageView) v4.findViewById(33685530);
                imageView3.setVisibility(8);
                ImageView rightIcon = (ImageView) v4.findViewById(33685531);
                rightIcon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                return v4;
            case 4:
                View v5 = this.mInflater.inflate(34144361, parent, false);
                TextView textView4 = (TextView) v5.findViewById(33685520);
                textView4.setEllipsize(TextUtils.TruncateAt.MARQUEE);
                textView4.setHorizontalFadingEdgeEnabled(true);
                ((TextView) v5.findViewById(33685524)).setVisibility(8);
                ImageView imageView4 = (ImageView) v5.findViewById(33685530);
                imageView4.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                ImageView rightIcon2 = (ImageView) v5.findViewById(33685531);
                rightIcon2.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                return v5;
            case 5:
                View v6 = this.mInflater.inflate(34144361, parent, false);
                TextView textView5 = (TextView) v6.findViewById(33685520);
                textView5.setEllipsize(TextUtils.TruncateAt.MARQUEE);
                textView5.setHorizontalFadingEdgeEnabled(true);
                ((TextView) v6.findViewById(33685524)).setVisibility(8);
                ImageView imageView5 = (ImageView) v6.findViewById(33685530);
                imageView5.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                ImageView rightIcon3 = (ImageView) v6.findViewById(33685531);
                rightIcon3.setVisibility(8);
                return v6;
            default:
                return null;
        }
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.mItems.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int position) {
        if (position < getCount()) {
            return this.mItems.get(position);
        }
        Log.w(LOG_TAG, "IndexOutOfBounds on AddAdapter, position = " + position + ", getCount() = " + getCount());
        notifyDataSetChanged();
        return this.mItems.get(0);
    }

    @Override // android.widget.Adapter
    public long getItemId(int position) {
        return position;
    }

    public int getTitleString() {
        return this.mShowTitleId;
    }

    public static boolean checkIfCHT_SIM_Card(Context launcher) {
        TelephonyManager tm = (TelephonyManager) launcher.getSystemService("phone");
        if (tm != null && tm.getSimState() == 5) {
            String simOperator = tm.getSimOperator();
            return simOperator.equals(CHT_IMSI);
        }
        return false;
    }

    @Override // android.widget.BaseAdapter, android.widget.ListAdapter
    public boolean isEnabled(int position) {
        if (((ListItem) getItem(position)).actionTag == 104) {
            return false;
        }
        return super.isEnabled(position);
    }

    public void onSummaryUpdate(Intent intent) {
        String action = intent.getAction();
        Iterator i$ = this.mAddMenuItems.iterator();
        while (i$.hasNext()) {
            ListItem item = i$.next();
            if (action.equals(item.summaryChangedAction)) {
                item.summary = intent.getStringExtra("com.htc.intent.EXTRA_SUMMARY");
                if (localLOGV) {
                    Log.d(LOG_TAG, "update summary, item = " + action + ", summary = " + item.summary);
                }
                notifyDataSetChanged();
            }
        }
    }

    public void updateSummary() {
        long time = System.currentTimeMillis();
        Resources res = this.mLauncher.getResources();
        Iterator i$ = this.mAddMenuItems.iterator();
        while (i$.hasNext()) {
            ListItem item = i$.next();
            if ("com.htc.intent.ACTION_PERSONALIZE_SCENE_CHANGED".equals(item.summaryChangedAction)) {
                item.summary = WidgetWorkspaceManager.instance(this.mLauncher).getCurrentWorkspaceName();
            } else if ("com.htc.intent.ACTION_PERSONALIZE_WALLPAPER_CHANGED".equals(item.summaryChangedAction)) {
                WallpaperManager wallpapaerManager = WallpaperManager.getInstance(this.mLauncher);
                if (wallpapaerManager == null) {
                    CharSequence liveWallpaperName = this.mLauncher.getLiveWallpaperName();
                    if (liveWallpaperName != null) {
                        item.summary = liveWallpaperName.toString();
                    } else {
                        item.summary = res.getString(R.string.summary_default);
                    }
                } else {
                    WallpaperInfo info = wallpapaerManager.getWallpaperInfo();
                    if (info == null) {
                        item.summary = res.getString(R.string.summary_default);
                    } else {
                        item.summary = info.loadLabel(this.mLauncher.getPackageManager()).toString();
                    }
                }
            } else if ("com.htc.intent.ACTION_PERSONALIZE_IDLESCREEN_CHANGED".equals(item.summaryChangedAction)) {
                if (!SettingUtil.isTabletDevice()) {
                    KeyguardManager keyguardManager = (KeyguardManager) this.mLauncher.getSystemService("keyguard");
                    String idleScreenName = keyguardManager.getIdleScreenLabel();
                    if (idleScreenName != null) {
                        item.summary = idleScreenName;
                    } else {
                        item.summary = res.getString(R.string.summary_default);
                    }
                } else {
                    item.summary = res.getString(R.string.lockscreen_choose_shortcut);
                }
            } else if ("com.htc.intent.ACTION_PERSONALIZE_SKIN_CHANGED".equals(item.summaryChangedAction)) {
                item.summary = CustomResourceUtil.getSkinName(this.mLauncher, CustomResourceUtil.getAppliedSkinPackageName());
            } else if (Launcher.ACTION_PERSONALIZE_ADD_WIDGET_TO_HOME_CHANGED.equals(item.summaryChangedAction)) {
                item.summary = res.getString(R.string.summary_add_widget_to_home);
            } else if (Launcher.ACTION_PERSONALIZE_ADD_APP_TO_HOME_CHANGED.equals(item.summaryChangedAction)) {
                item.summary = res.getString(R.string.summary_add_app_to_home);
            } else if (Launcher.ACTION_PERSONALIZE_ADD_SHORTCUT_TO_HOME_CHANGED.equals(item.summaryChangedAction)) {
                item.summary = res.getString(R.string.summary_add_shortcut_to_home);
            } else if (Launcher.ACTION_PERSONALIZE_ADD_FOLDER_TO_HOME_CHANGED.equals(item.summaryChangedAction)) {
                item.summary = res.getString(R.string.summary_add_folder_to_home);
            } else if ("com.htc.intent.ACTION_PERSONALIZE_SOUND_SET_CHANGED".equals(item.summaryChangedAction)) {
                SharedPreferences preferences = this.mLauncher.getSharedPreferences(Launcher.PERSONALIZE_PREFERENCES, 0);
                item.summary = preferences.getString("com.htc.intent.ACTION_PERSONALIZE_SOUND_SET_CHANGED", res.getString(R.string.summary_default));
            } else if ("com.htc.intent.ACTION_PERSONALIZE_RINGTONE_CHANGED".equals(item.summaryChangedAction)) {
                Uri uri = RingtoneManager.getActualDefaultRingtoneUri(this.mLauncher, 1);
                item.summary = getTitle(this.mLauncher, uri, true);
            } else if ("com.htc.intent.ACTION_PERSONALIZE_NOTIFICATION_SOUNDS_CHANGED".equals(item.summaryChangedAction)) {
                Uri uri2 = RingtoneManager.getActualDefaultRingtoneUri(this.mLauncher, 2);
                item.summary = getTitle(this.mLauncher, uri2, true);
            } else if ("com.htc.intent.ACTION_PERSONALIZE_ALARM_CHANGED".equals(item.summaryChangedAction)) {
                Uri uri3 = RingtoneManager.getActualDefaultRingtoneUri(this.mLauncher, 4);
                item.summary = getTitle(this.mLauncher, uri3, true);
            }
        }
        Iterator i$2 = this.maddFuncMenuItems.iterator();
        while (i$2.hasNext()) {
            ListItem item2 = i$2.next();
            if (Launcher.ACTION_PERSONALIZE_ADD_APP_TO_HOME_CHANGED.equals(item2.summaryChangedAction)) {
                item2.summary = res.getString(R.string.summary_add_app_to_home);
            } else if (Launcher.ACTION_PERSONALIZE_ADD_SHORTCUT_TO_HOME_CHANGED.equals(item2.summaryChangedAction)) {
                item2.summary = res.getString(R.string.summary_add_shortcut_to_home);
            }
        }
        if (localLOGV) {
            Log.d(LOG_TAG, "update summaries takes " + (System.currentTimeMillis() - time) + " ms");
        }
    }

    protected Intent createShortcutIntent(String url, String title, Bitmap touchIcon, Bitmap favicon) {
        Intent i = new Intent();
        Intent shortcutIntent = new Intent("android.intent.action.VIEW", Uri.parse(url));
        long urlHash = url.hashCode();
        long uniqueId = (urlHash << 32) | shortcutIntent.hashCode();
        shortcutIntent.putExtra(EXTRA_APPLICATION_ID, Long.toString(uniqueId));
        i.putExtra("android.intent.extra.shortcut.INTENT", shortcutIntent);
        i.putExtra("android.intent.extra.shortcut.NAME", title);
        if (touchIcon != null) {
            int iconSize = this.mLauncher.getResources().getDimensionPixelSize(android.R.dimen.app_icon_size);
            Bitmap bm = Bitmap.createBitmap(iconSize, iconSize, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bm);
            Rect src = new Rect(0, 0, touchIcon.getWidth(), touchIcon.getHeight());
            Rect dest = new Rect(0, 0, bm.getWidth(), bm.getHeight());
            Paint paint = new Paint(1);
            paint.setFilterBitmap(true);
            canvas.drawBitmap(touchIcon, src, dest, paint);
            Path path = new Path();
            path.setFillType(Path.FillType.INVERSE_WINDING);
            RectF rect = new RectF(0.0f, 0.0f, bm.getWidth(), bm.getHeight());
            rect.inset(1.0f, 1.0f);
            path.addRoundRect(rect, 8.0f, 8.0f, Path.Direction.CW);
            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
            canvas.drawPath(path, paint);
            i.putExtra("android.intent.extra.shortcut.ICON", bm);
        } else {
            Log.e(LOG_TAG, "createShortcutIntent(), touchIcon should not be null");
        }
        i.putExtra("duplicate", false);
        return i;
    }

    /* JADX WARN: Removed duplicated region for block: B:13:0x0042  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x010a  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0101  */
    /* JADX WARN: Removed duplicated region for block: B:38:? A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:8:0x0034  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private static String getTitle(Context context, Uri uri, boolean followSettingsUri) {
        String title;
        Cursor cursor;
        Cursor cursor2;
        Throwable th;
        ContentResolver res = context.getContentResolver();
        if (uri != null) {
            String authority = uri.getAuthority();
            if (!"settings".equals(authority)) {
                boolean followSettingsUri2 = "drm".equals(authority);
                if (followSettingsUri2) {
                    try {
                        cursor2 = res.query(uri, DRM_COLUMNS, null, null, null);
                    } catch (Exception e) {
                        if (localLOGV) {
                            Log.e(LOG_TAG, "Error: " + uri.getAuthority() + " not found");
                        }
                        e.printStackTrace();
                        cursor2 = null;
                    }
                } else {
                    if ("media".equals(authority)) {
                        try {
                            cursor2 = res.query(uri, MEDIA_COLUMNS, null, null, null);
                        } catch (Exception e2) {
                            if (localLOGV) {
                                Log.e(LOG_TAG, "Error: " + uri.getAuthority() + " not found");
                            }
                            e2.printStackTrace();
                        }
                    }
                    cursor2 = null;
                }
                if (cursor2 != null) {
                    try {
                        if (cursor2.getCount() == 1) {
                            cursor2.moveToFirst();
                            String title2 = cursor2.getString(2);
                            if (cursor2 != null) {
                                cursor2.close();
                            }
                            return title2;
                        }
                    } catch (Throwable th2) {
                        th = th2;
                        if (cursor2 != null) {
                        }
                    }
                }
                Ringtone ringtone = RingtoneManager.getRingtone(context, uri);
                String title3 = ringtone != null ? ringtone.getTitle(context) : null;
                try {
                    Log.w(LOG_TAG, "We cannot get ringone name from cursor, we can only get title by RingtoneManager");
                    if (cursor2 != null) {
                        cursor2.close();
                        String title4 = title3;
                        cursor = cursor2;
                        title = title4;
                    } else {
                        String title5 = title3;
                        cursor = cursor2;
                        title = title5;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    if (cursor2 != null) {
                        throw th;
                    }
                    cursor2.close();
                    throw th;
                }
            } else if (followSettingsUri) {
                Uri actualUri = RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.getDefaultType(uri));
                String actualTitle = getTitle(context, actualUri, false);
                title = context.getString(android.R.string.db_default_sync_mode, actualTitle);
                cursor = null;
            }
            if (title == null) {
                String title6 = context.getString(android.R.string.decline_remote_bugreport_action);
                title = title6 == null ? LoggingEvents.EXTRA_CALLING_APP_NAME : title6;
            }
            if (cursor == null) {
                cursor.close();
            }
            return title;
        }
        title = null;
        cursor = null;
        if (title == null) {
        }
        if (cursor == null) {
        }
        return title;
    }
}
