package com.htc.launcher;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import com.htc.android.rosie.home.HostWidgetManager;
import com.htc.android.rosie.home.fxcontrol.FxScreen;
import com.htc.android.rosie.home.fxcontrol.FxShortcutButton;
import com.htc.android.rosie.home.fxcontrol.FxWorkspace;
import com.htc.android.rosie.widget.WidgetProvider;
import com.htc.fusion.fx.FxScene;
import com.htc.launcher.CellInfo;
import com.htc.launcher.DragSource;
import com.htc.launcher.Draggee;
import com.htc.launcher.Workspace;
import com.htc.launcher.fusion.WidgetProviderInfoCollector;
import com.htc.launcher.settings.SettingUtil;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class DesktopItemController {
    static final String EXTRA_CUSTOM_WIDGET = "custom_widget";
    static final String EXTRA_SHORTCUT_DUPLICATE = "duplicate";
    public static final String FXWIDGET_PICKER_EXTRA_KEY_PREFIX = "com.htc.launcher.intent";
    public static final String FXWIDGET_PICKER_EXTRA_KEY_PROVIDER_NAME = "com.htc.launcher.intent.EXTRA_KEY_PROVIDER_NAME";
    public static final String FXWIDGET_PICKER_EXTRA_KEY_STYLE_ID = "com.htc.launcher.intent.EXTRA_KEY_STYLE_ID";
    public static final String FXWIDGET_PICKER_EXTRA_KEY_STYLE_NAME = "com.htc.launcher.intent.EXTRA_KEY_STYLE_NAME";
    public static final String FXWIDGET_PICKER_EXTRA_KEY_WIDGET_PROVIDER_ARRAY = "com.htc.launcher.intent.EXTRA_KEY_WIDGET_PROVIDER_ARRAY";
    private static final String LOG_TAG = "DesktopItemController";
    private static final int MSG_BINDING_FXITEMS = 1300;
    private static final int MSG_FLUSH_TASKS = 1301;
    private static final String RUNTIME_STATE_PENDING_ADD_OCCUPIED_CELLS = "launcher.add_occupied_cells";
    static final String SEARCH_WIDGET = "search_widget";
    private static final boolean localLOGD = SettingUtil.localLOGD;
    private TextView mDragView;
    private DragController mDragger;
    private FxItem mFloatingFxItem;
    private FloatingEnv mFxFloatEnv;
    private HostWidgetManager mFxWidgetManager;
    private FxWorkspace mFxWorkspace;
    private Handler mHandler;
    private HandlerThread mHandlerThread;
    private boolean mIsStartDrag;
    private Launcher mLauncher;
    private FloatingEnv mLegacyFloatEnv;
    private ItemInfo mLegacyItemToEdit;
    private SlideController mSlideController;
    private Workspace mWorkspace;
    private final int[] mCellCoordinates = new int[2];
    private final int DELAY_START_ACTIVITY = 150;
    private ArrayList<Runnable> mPendingAddInScreens = new ArrayList<>();
    private ArrayList<Runnable> mPendingAddToFxScreenTasks = new ArrayList<>();
    FxShortcutButton.OnClickListener mOnClickFolderListener = new FxShortcutButton.OnClickListener() { // from class: com.htc.launcher.DesktopItemController.5
        @Override // com.htc.android.rosie.home.fxcontrol.FxShortcutButton.OnClickListener
        public void onClick(FxItem folder) {
            DesktopItemController.this.onClickFolder(folder);
        }
    };
    FxShortcutButton.OnClickListener mOnClickShortcutListener = new FxShortcutButton.OnClickListener() { // from class: com.htc.launcher.DesktopItemController.7
        @Override // com.htc.android.rosie.home.fxcontrol.FxShortcutButton.OnClickListener
        public void onClick(FxItem shortcut) {
            ItemInfo itemInfo = shortcut.getInfo();
            Intent intent = ((ApplicationInfo) itemInfo).intent;
            if (intent != null) {
                ComponentName cmp = intent.getComponent();
                if (cmp != null && "com.htc.searchanywhere/.SearchActivity".equals(cmp.flattenToShortString())) {
                    intent.putExtra("launch_flag", 1);
                }
                RectF rectF = new RectF();
                Rect rect = new Rect();
                DesktopItemController.this.mWorkspace.getCurrentScreen().cellToRect(itemInfo.cellX, itemInfo.cellY, itemInfo.spanX, itemInfo.spanY, rectF);
                rectF.round(rect);
                if (DesktopItemController.localLOGD) {
                    Log.d(DesktopItemController.LOG_TAG, "intent rect:" + rect);
                }
                intent.setSourceBounds(rect);
                DesktopItemController.this.mLauncher.launchAppType = " RS_program_icon";
                DesktopItemController.this.mLauncher.startActivitySafely(intent);
            }
        }
    };
    private int[] mFloatingPos = new int[2];
    private RectF mFloatingBounds = new RectF();
    private DragSource mPickerDragSource = new DragSource() { // from class: com.htc.launcher.DesktopItemController.9
        @Override // com.htc.launcher.DragSource
        public void setDragger(DragController dragger) {
        }

        @Override // com.htc.launcher.DragSource
        public void onDropCompleted(DropTarget target, boolean success) {
            Logger.d(DesktopItemController.LOG_TAG, "[EDIT_DEBUG]# mPickerDragSource.onDropCompleted() success:" + success);
            DesktopItemController.this.poofFxItem();
        }
    };
    public DragSource mPickerDragSourceLegacy = new DragSource() { // from class: com.htc.launcher.DesktopItemController.10
        @Override // com.htc.launcher.DragSource
        public void onDropCompleted(DropTarget target, boolean success) {
            Logger.d(DesktopItemController.LOG_TAG, "[EDIT_DEBUG]# mPickerDragSourceLegacy.onDropCompleted() success(" + success + ")");
            if (!success) {
                removeLayout(DesktopItemController.this.mWorkspace.getLauncher());
            }
            if (DesktopItemController.this.mFloatingFxItem != null) {
                Point p = DesktopItemController.this.mFloatingFxItem.getCellXY();
                DesktopItemController.this.mFloatingFxItem.onDrop(null, p.x, p.y);
                DesktopItemController.this.mLegacyFloatEnv.onPoof(DesktopItemController.this.mFloatingFxItem);
            }
            DesktopItemController.this.poofFxItem();
            cleanUp();
        }

        @Override // com.htc.launcher.DragSource
        public void setDragger(DragController dragger) {
            Logger.d(DesktopItemController.LOG_TAG, "[EDIT_DEBUG] mPickerDragSourceLegacy.setDragger()");
        }

        /* JADX WARN: Multi-variable type inference failed */
        void removeLayout(Launcher launcher) {
            Logger.d(DesktopItemController.LOG_TAG, "[EDIT_DEBUG] mPickerDragSourceLegacy.removeLayout()");
            if (DesktopItemController.this.mFloatingFxItem != null) {
                View content = (View) DesktopItemController.this.mFloatingFxItem.getItem();
                if (content != null) {
                    ItemInfo info = DesktopItemController.this.mFloatingFxItem.getItemInfo();
                    if (info instanceof WidgetProxy) {
                        ((WidgetProxy) info).onLayoutRemoved(launcher);
                    }
                    LauncherModel.deleteItemFromDatabase(launcher, info);
                    return;
                }
                Log.e(DesktopItemController.LOG_TAG, "no view in floating item");
            }
        }

        void cleanUp() {
            Logger.d(DesktopItemController.LOG_TAG, "[EDIT_DEBUG]# mPickerDragSourceLegacy.cleanUp()");
            DesktopItemController.this.mFloatingFxItem = null;
            DesktopItemController.this.mWorkspace.leaveEditMode();
        }
    };
    Handler mOnLeapRearrangeCompleteHandler = new Handler() { // from class: com.htc.launcher.DesktopItemController.11
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            if (DesktopItemController.this.mWorkspace != null) {
                DesktopItemController.this.mWorkspace.onLeapRearrangeComplete((int[]) msg.obj);
            }
        }
    };
    public boolean IS_EXTERNAL_APP_ADDING = false;
    private ArrayList<String> mPendingSyncPackages = new ArrayList<>();
    private ArrayList<String> mTempSyncedPackages = null;

    public interface FloatingEnv {
        boolean onFloat(Draggee draggee, RectF rectF);

        boolean onLand(Draggee draggee, int i, int i2, int i3);

        boolean onPoof(Draggee draggee);
    }

    interface FxWidgetRunnable {
        void run();
    }

    public DesktopItemController(Launcher launcher, Workspace workspace, FxWorkspace fxWorkspace, HostWidgetManager hostWidgetManager, SlideController slideController) {
        this.mLauncher = null;
        this.mWorkspace = null;
        this.mFxWorkspace = null;
        this.mFxWidgetManager = null;
        this.mSlideController = null;
        this.mLauncher = launcher;
        this.mWorkspace = workspace;
        this.mFxWorkspace = fxWorkspace;
        this.mFxWidgetManager = hostWidgetManager;
        this.mSlideController = slideController;
    }

    public void addFxWidget(Intent intent, CellInfo cellInfo, boolean resumeOnCurrentPage) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] addFxWidget() CellInfo:" + cellInfo);
        ComponentName provider = (ComponentName) intent.getParcelableExtra(FXWIDGET_PICKER_EXTRA_KEY_PROVIDER_NAME);
        ComponentName styleName = (ComponentName) intent.getParcelableExtra(FXWIDGET_PICKER_EXTRA_KEY_STYLE_NAME);
        String styleId = intent.getStringExtra(FXWIDGET_PICKER_EXTRA_KEY_STYLE_ID);
        if (SettingUtil.localLOGD) {
            Log.d(LOG_TAG, "FX widget: provider=" + provider + "style=" + styleName);
        }
        if (provider != null && styleName != null) {
            WidgetProvider.Info.Style style = WidgetProviderInfoCollector.getStyleByComponent(this.mLauncher, styleName, styleId);
            if (style == null) {
                Log.e(LOG_TAG, "style definition error: style = null");
                return;
            }
            if (style.view == null) {
                Log.e(LOG_TAG, "style definition error: style.view = null");
                return;
            }
            int spanX = style.view.sx;
            int spanY = style.view.sy;
            int[] xy = this.mCellCoordinates;
            boolean here = findRoomInWorkspace(spanX, spanY, cellInfo, xy);
            intent.removeExtra(FXWIDGET_PICKER_EXTRA_KEY_PROVIDER_NAME);
            intent.removeExtra(FXWIDGET_PICKER_EXTRA_KEY_STYLE_NAME);
            HostWidgetManager.WidgetInfo wi = this.mFxWidgetManager.addWidget(provider, style, -1, -1, -1, intent);
            if (wi == null) {
                Log.e(LOG_TAG, "fail to add Fusion widget: provider=" + provider + ", style=" + style);
                return;
            }
            int w = style.view.sx;
            int h = style.view.sy;
            if (!here) {
                CellInfo vacantInfo = this.mWorkspace.scrollToAvailableScreenForSpan(spanX, spanY);
                if (vacantInfo == null) {
                    Toast.makeText((Context) this.mLauncher, (CharSequence) this.mLauncher.getString(R.string.out_of_space), 0).show();
                    Log.w(LOG_TAG, "fail to add to desktop since its full");
                    return;
                }
                cellInfo.cellX = vacantInfo.cellX;
                cellInfo.cellY = vacantInfo.cellY;
                cellInfo.screen = vacantInfo.screen;
                wi.addToContainer(cellInfo.screen, cellInfo.cellX, cellInfo.cellY);
                if (wi.getStoreId() == -1) {
                    if (SettingUtil.localLOGD) {
                        Log.d(LOG_TAG, "store widget in DB:" + wi);
                    }
                    this.mFxWidgetManager.storeWidgetToDatabase(wi);
                } else {
                    Log.w(LOG_TAG, "Widget already in DB. Will update it!");
                    this.mFxWidgetManager.updateWidgetInDatabase(wi);
                }
                addFxItemToDesktop(wi, cellInfo.screen, cellInfo.cellX, cellInfo.cellY, w, h);
                return;
            }
            int screen = this.mWorkspace.getCurrentScreenIndex();
            wi.addToContainer(screen, xy[0], xy[1]);
            if (wi.getStoreId() == -1) {
                if (SettingUtil.localLOGD) {
                    Log.d(LOG_TAG, "store widget in DB:" + wi);
                }
                this.mFxWidgetManager.storeWidgetToDatabase(wi);
            } else {
                Log.w(LOG_TAG, "Widget already in DB. Will update it!");
                this.mFxWidgetManager.updateWidgetInDatabase(wi);
            }
            if (addFxItemToDesktop(wi, screen, xy[0], xy[1], w, h)) {
                LauncherModel model = Launcher.getModel();
                model.addDesktopItem(new FxItemInfo(wi));
            }
            if (resumeOnCurrentPage) {
                this.mFxWidgetManager.resumeWidgetAt(screen, xy[0], xy[1]);
                return;
            }
            return;
        }
        Log.e(LOG_TAG, "style definition error: provider=" + provider + ", style=" + ((Object) null));
    }

    public boolean startDragFxWidget(DragSource dragScource, FxItem fxItem, RectF bounds) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] startDragFxWidget()");
        putFxItemInTheAir(fxItem, bounds);
        resumeRenderring();
        this.mLauncher.getDragController().prepareDrag(fxItem, dragScource, fxItem.getItemInfo(), 0);
        fxItem.onDrag();
        this.mLauncher.getDragController().startDrag(fxItem, dragScource, fxItem.getItemInfo(), 0);
        return true;
    }

    public boolean startDragAppWidget(DragSource dragSource, LegacyLayout legacyLayout, ItemInfo itemInfo, RectF bounds) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] onStartDragAppWidget()");
        startFloatingLegacyWidget(legacyLayout, dragSource, itemInfo, 0, bounds);
        return true;
    }

    public boolean moveRearrangedItem(Draggee draggeeItem, int dropScreen, int cellX, int cellY, boolean bMoveScene) {
        ItemInfo draggeeItemInfo = draggeeItem.getItemInfo();
        if (draggeeItem.getItemInfo().itemType == 5) {
            this.mFxWidgetManager.moveWidgetAt(draggeeItemInfo.screen, draggeeItemInfo.cellX, draggeeItemInfo.cellY, dropScreen, cellX, cellY);
        }
        draggeeItemInfo.container = -100L;
        draggeeItemInfo.screen = dropScreen;
        draggeeItemInfo.cellX = cellX;
        draggeeItemInfo.cellY = cellY;
        return true;
    }

    public boolean moveFxItem(Draggee draggeeItem, int dropScreen, int cellX, int cellY, boolean bMoveScene) {
        ItemInfo draggeeItemInfo = draggeeItem.getItemInfo();
        if (draggeeItem.getItemInfo().itemType == 5) {
            this.mFxWidgetManager.moveWidgetAt(draggeeItemInfo.screen, draggeeItemInfo.cellX, draggeeItemInfo.cellY, dropScreen, cellX, cellY);
            this.mFxWidgetManager.resumeWidgets(dropScreen);
        }
        if (bMoveScene) {
            Logger.d("Workspace", "[EDIT_DEBUG]# Workspace.dropMove() Before move " + draggeeItemInfo.cellX + "," + draggeeItemInfo.cellY + " | " + cellX + "," + cellY);
            this.mLauncher.getFxWorkspace().resumeItemInScreen(draggeeItem, draggeeItemInfo.screen, dropScreen, cellX, cellY);
            Logger.d("Workspace", "[EDIT_DEBUG]# Workspace.dropMove() After move " + draggeeItemInfo.cellX + "," + draggeeItemInfo.cellY + " | " + cellX + "," + cellY);
        }
        if (draggeeItemInfo.screen != dropScreen && (((draggeeItem instanceof FxItem) || (draggeeItem instanceof Draggee.LegacyDraggee)) && (draggeeItem.getItem() instanceof View))) {
            this.mWorkspace.moveLegacyItem(draggeeItem, draggeeItemInfo.screen, dropScreen);
        }
        LauncherModel.moveItemInDatabase(this.mLauncher, draggeeItemInfo, -100L, dropScreen, cellX, cellY);
        Workspace.Screen target = this.mWorkspace.getScreenAt(dropScreen);
        Logger.d("Workspace", "[EDIT_DEBUG]# Workspace.dropMove() - After SpanX:" + draggeeItemInfo.spanX + " SpanY:" + draggeeItemInfo.spanY);
        target.onDropChildByCell(draggeeItem, draggeeItemInfo.cellX, draggeeItemInfo.cellY, draggeeItemInfo.spanX, draggeeItemInfo.spanY);
        return true;
    }

    private boolean putFxItemInTheAir(FxItem item, RectF pos) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] putFxItemInTheAir()");
        if (this.mFloatingFxItem != null) {
            Log.e(LOG_TAG, "[EDIT_DEBUG] There is already something in the air");
            return false;
        }
        this.mFloatingFxItem = item;
        return this.mFxFloatEnv.onFloat(item, pos);
    }

    public void bindFxWidget(FxItemInfo fxItemInfo) {
        HostWidgetManager.WidgetInfo wi = fxItemInfo.toWidgetInfo();
        if (this.mFxWorkspace.hasFreeRoom(fxItemInfo.screen, new FxScreen.LayoutParams(wi.getX(), wi.getY(), wi.getSpanX(), wi.getSpanY()))) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.bindFxWidget(" + wi.getId() + ")");
            boolean ok = this.mFxWidgetManager.addWidget(wi);
            if (ok) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.bindFxWidget(" + wi.getId() + ") addWidget() ok");
                addFxItemToDesktop(wi, wi.getContainerId(), wi.getX(), wi.getY(), wi.getSpanX(), wi.getSpanY());
                return;
            } else {
                Logger.e(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.bindFxWidget(" + wi.getId() + ") addWidget() failed");
                return;
            }
        }
        Logger.e(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.bindFxWidget(" + wi.getId() + ") no free Room!!");
    }

    private boolean addFxItemToDesktop(FxItem item, int screen, int x, int y, int w, int h) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.addFxItemToDesktop - 1 (" + item.getInfo().id + ")");
        long id = item.getInfo().getId();
        boolean added = this.mFxWorkspace.addItemToScreen(screen, id, item, new FxScreen.LayoutParams(x, y, w, h));
        return added;
    }

    private boolean addFxItemToDesktop(HostWidgetManager.WidgetInfo wi, int screen, int x, int y, int w, int h) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.addFxItemToDesktop - 2 (" + wi.getId() + ")");
        FxItemInfo info = new FxItemInfo(wi);
        FxItem fxItem = FxItem.create(this.mFxWidgetManager.getWidgetScene(wi), info);
        boolean added = addFxItemToDesktop(fxItem, screen, x, y, w, h);
        if (!added) {
            Log.e(LOG_TAG, "fail to add widget:" + wi);
            Logger.d(LOG_TAG, "[EDIT_DEBUG]# DesktopItemController.addFxItemToDesktop - 2 - removeWidget(" + wi.getId() + ")");
            this.mFxWidgetManager.removeWidget(wi.getId());
        }
        return added;
    }

    void addAppWidget(Intent data) {
        int appWidgetId = data.getIntExtra("appWidgetId", -1);
        String customWidget = data.getStringExtra(EXTRA_CUSTOM_WIDGET);
        if (SEARCH_WIDGET.equals(customWidget)) {
            this.mLauncher.getAppWidgetHost().deleteAppWidgetId(appWidgetId);
            addSearch(this.mLauncher.getAddItemCellInfo());
            return;
        }
        AppWidgetProviderInfo appWidget = this.mLauncher.getAppWidgetManager().getAppWidgetInfo(appWidgetId);
        if (appWidget.configure != null) {
            Intent intent = new Intent("android.appwidget.action.APPWIDGET_CONFIGURE");
            intent.setComponent(appWidget.configure);
            intent.putExtra("appWidgetId", appWidgetId);
            this.mLauncher.startActivityForResult(intent, 5);
            return;
        }
        this.mLauncher.onActivityResult(5, -1, data);
    }

    public void addButtonBarItem(ApplicationInfo app) {
        this.mFxWorkspace.addAndBindButtonBarItem(app);
    }

    public void addWidget(Widget info, Intent backIntent, CellInfo cellInfo) {
        View view;
        View view2;
        int[] xy = this.mCellCoordinates;
        int spanX = info.spanX;
        int spanY = info.spanY;
        Log.v(LOG_TAG, "addWidget(), spanX = " + spanX + ", spanY = " + spanY);
        boolean bHaveRoomInCurrentScreen = findRoomInWorkspace(spanX, spanY, cellInfo, xy);
        try {
            if (bHaveRoomInCurrentScreen) {
                LauncherModel.addItemToDatabase(this.mLauncher, info, -100L, this.mWorkspace.getCurrentScreenIndex(), xy[0], xy[1], false);
                if (info instanceof WidgetProxy) {
                    ViewGroup currentScreen = (ViewGroup) this.mWorkspace.getChildAt(this.mWorkspace.getCurrentScreenIndex());
                    view2 = ((WidgetProxy) info).inflate(this.mLauncher, currentScreen, backIntent);
                    ((WidgetProxy) info).fireOnResume();
                } else {
                    view2 = this.mLauncher.getLayoutInflater().inflate(info.layoutResource, (ViewGroup) null);
                }
                view2.setTag(info);
                Launcher.sModel.addDesktopItem(info);
                addLegacyItemToDesktop(view2, info, this.mWorkspace.getCurrentScreenIndex(), xy[0], xy[1], spanX, spanY, !this.mLauncher.isWorkspaceLocked());
                this.mWorkspace.invalidateVacant();
                return;
            }
            CellInfo vacantInfo = this.mWorkspace.scrollToAvailableScreenForSpan(spanX, spanY);
            if (vacantInfo == null) {
                Toast.makeText((Context) this.mLauncher, (CharSequence) this.mLauncher.getString(R.string.out_of_space), 0).show();
                Log.w(LOG_TAG, "fail to add to desktop since its full");
                return;
            }
            info.cellX = vacantInfo.cellX;
            info.cellY = vacantInfo.cellY;
            info.screen = vacantInfo.screen;
            if (info instanceof WidgetProxy) {
                ViewGroup currentScreen2 = (ViewGroup) this.mWorkspace.getChildAt(info.screen);
                view = ((WidgetProxy) info).inflate(this.mLauncher, currentScreen2, backIntent);
                ((WidgetProxy) info).fireOnResume();
            } else {
                view = this.mLauncher.getLayoutInflater().inflate(info.layoutResource, (ViewGroup) null);
            }
            view.setTag(info);
            LauncherModel.addItemToDatabase(this.mLauncher, info, -100L, vacantInfo.screen, vacantInfo.cellX, vacantInfo.cellY, false);
            Launcher.sModel.addDesktopItem(info);
            addLegacyItemToDesktop(view, info, vacantInfo.screen, vacantInfo.cellX, vacantInfo.cellY, spanX, spanY, !this.mLauncher.isWorkspaceLocked());
            this.mWorkspace.invalidateVacant();
        } catch (Throwable th) {
            Log.e(LOG_TAG, "addWidget Error !", th);
        }
    }

    void addSearch(CellInfo cellInfo) {
        Widget info = Widget.makeSearch();
        addWidget(info, null, cellInfo);
    }

    private boolean findRoomInWorkspace(int spanX, int spanY, CellInfo cellInfo, int[] xy) {
        boolean here = findSlot(cellInfo, xy, spanX, spanY);
        if (!here) {
            xy[1] = -1;
            xy[0] = -1;
        }
        return here;
    }

    boolean findSlot(CellInfo cellInfo, int[] xy, int spanX, int spanY) {
        Workspace.Screen screen = this.mWorkspace.getCurrentScreen();
        CellInfo.VacantCell cell = screen.findNearestVacantCellsForSpan(cellInfo, spanX, spanY);
        if (cell == null) {
            return false;
        }
        xy[0] = cell.cellX;
        xy[1] = cell.cellY;
        return true;
    }

    boolean findSingleSlot(CellInfo cellInfo) {
        CellInfo info = this.mLauncher.getAddItemCellInfo();
        if (info != null && info.cellX >= 0 && info.cellY >= 0) {
            cellInfo.cellX = info.cellX;
            cellInfo.cellY = info.cellY;
            return true;
        }
        int[] xy = new int[2];
        if (!findSlot(cellInfo, xy, 1, 1)) {
            return false;
        }
        cellInfo.cellX = xy[0];
        cellInfo.cellY = xy[1];
        return true;
    }

    void addShortcut(Intent intent) {
        String applicationName = this.mLauncher.getResources().getString(R.string.group_applications);
        String shortcutName = intent.getStringExtra("android.intent.extra.shortcut.NAME");
        if (applicationName != null && applicationName.equals(shortcutName)) {
            Intent mainIntent = new Intent("android.intent.action.MAIN", (Uri) null);
            mainIntent.addCategory("android.intent.category.LAUNCHER");
            Intent pickIntent = new Intent("android.intent.action.PICK_ACTIVITY");
            pickIntent.putExtra("android.intent.extra.INTENT", mainIntent);
            this.mLauncher.startActivityForResult(pickIntent, 6);
            return;
        }
        this.mLauncher.startActivityForResult(intent, 1);
    }

    void addLiveFolder(Intent intent) {
        String folderName = this.mLauncher.getResources().getString(R.string.folder_name);
        String shortcutName = intent.getStringExtra("android.intent.extra.shortcut.NAME");
        if (folderName != null && folderName.equals(shortcutName)) {
            addFolder(true);
        } else {
            this.mLauncher.startActivityForResult(intent, 4);
        }
    }

    void addFolder(boolean insertAtFirst) {
        UserFolderInfo folderInfo = new UserFolderInfo();
        folderInfo.title = this.mLauncher.getText(R.string.folder_name);
        CellInfo cellInfo = this.mLauncher.getAddItemCellInfo();
        cellInfo.screen = this.mWorkspace.getCurrentScreenIndex();
        this.mWorkspace.invalidateVacant();
        if (!this.mWorkspace.hasRoomForSpan(1, 1)) {
            this.mWorkspace.invalidateVacant();
            Toast.makeText((Context) this.mLauncher, (CharSequence) this.mLauncher.getString(R.string.out_of_space), 0).show();
            return;
        }
        boolean here = findSingleSlot(cellInfo);
        if (!here) {
            CellInfo vacantInfo = this.mWorkspace.scrollToAvailableScreenForShortcut();
            cellInfo.cellX = vacantInfo.cellX;
            cellInfo.cellY = vacantInfo.cellY;
            cellInfo.screen = vacantInfo.screen;
        }
        LauncherModel.addItemToDatabase(this.mLauncher, folderInfo, -100L, cellInfo.screen, cellInfo.cellX, cellInfo.cellY, false);
        Launcher.sModel.addDesktopItem(folderInfo);
        Launcher.sModel.addFolder(folderInfo);
        addFxShortcutToDesktop(folderInfo);
    }

    void addLegacyItemToDesktop(View view, ItemInfo info, int screen, int x, int y, int w, int h, boolean insertAtFirst) {
        LegacyLayout ll = this.mWorkspace.wrapLegacyView(view);
        this.mWorkspace.addInScreen(ll, screen, x, y, w, h, insertAtFirst);
        this.mWorkspace.invalidateVacant();
    }

    static void setAddedItemViewProperties(View view) {
        view.setFocusable(false);
        view.setDrawingCacheEnabled(true);
        view.buildDrawingCache();
    }

    void completeAddLiveFolder(Intent data, CellInfo cellInfo, boolean insertAtFirst) {
        cellInfo.screen = this.mWorkspace.getCurrentScreenIndex();
        this.mWorkspace.invalidateVacant();
        if (!this.mWorkspace.hasRoomForSpan(1, 1)) {
            this.mWorkspace.invalidateVacant();
            Toast.makeText((Context) this.mLauncher, (CharSequence) this.mLauncher.getString(R.string.out_of_space), 0).show();
            return;
        }
        boolean here = findSingleSlot(cellInfo);
        if (!here) {
            CellInfo vacantInfo = this.mWorkspace.scrollToAvailableScreenForShortcut();
            if (vacantInfo == null) {
                this.mWorkspace.invalidateVacant();
                Toast.makeText((Context) this.mLauncher, (CharSequence) this.mLauncher.getString(R.string.out_of_space), 0).show();
                return;
            } else {
                cellInfo.cellX = vacantInfo.cellX;
                cellInfo.cellY = vacantInfo.cellY;
                cellInfo.screen = vacantInfo.screen;
            }
        }
        LiveFolderInfo info = addLiveFolder(this.mLauncher, data, cellInfo, false);
        if (!this.mLauncher.isRestoring()) {
            Launcher.sModel.addDesktopItem(info);
            addFxShortcutToDesktop(info);
        } else if (Launcher.sModel.isDesktopLoaded()) {
            Launcher.sModel.addDesktopItem(info);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x003a  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0098  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    static LiveFolderInfo addLiveFolder(Context context, Intent data, CellInfo cellInfo, boolean notify) {
        Drawable icon;
        Intent.ShortcutIconResource iconResource;
        Drawable icon2;
        Intent.ShortcutIconResource iconResource2;
        Intent baseIntent = (Intent) data.getParcelableExtra("android.intent.extra.livefolder.BASE_INTENT");
        String name = data.getStringExtra("android.intent.extra.livefolder.NAME");
        Parcelable extra = data.getParcelableExtra("android.intent.extra.livefolder.ICON");
        if (extra == null || !(extra instanceof Intent.ShortcutIconResource)) {
            icon = null;
            iconResource = null;
        } else {
            try {
                iconResource2 = (Intent.ShortcutIconResource) extra;
            } catch (Exception e) {
                iconResource2 = null;
            }
            try {
                PackageManager packageManager = context.getPackageManager();
                Resources resources = packageManager.getResourcesForApplication(iconResource2.packageName);
                int id = resources.getIdentifier(iconResource2.resourceName, null, null);
                icon = ResourceUtil.getDrawable(resources, id);
                iconResource = iconResource2;
            } catch (Exception e2) {
                Log.w(LOG_TAG, "Could not load live folder icon: " + extra);
                icon = null;
                iconResource = iconResource2;
                if (icon != null) {
                }
                LiveFolderInfo info = new LiveFolderInfo();
                info.icon = icon2;
                info.filtered = false;
                info.title = name;
                info.iconResource = iconResource;
                info.uri = data.getData();
                info.baseIntent = baseIntent;
                info.displayMode = data.getIntExtra("android.intent.extra.livefolder.DISPLAY_MODE", 1);
                LauncherModel.addItemToDatabase(context, info, -100L, cellInfo.screen, cellInfo.cellX, cellInfo.cellY, notify);
                Launcher.sModel.addFolder(info);
                return info;
            }
        }
        if (icon != null) {
            Drawable icon3 = context.getResources().getDrawable(34079058);
            icon2 = icon3;
        } else {
            icon2 = icon;
        }
        LiveFolderInfo info2 = new LiveFolderInfo();
        info2.icon = icon2;
        info2.filtered = false;
        info2.title = name;
        info2.iconResource = iconResource;
        info2.uri = data.getData();
        info2.baseIntent = baseIntent;
        info2.displayMode = data.getIntExtra("android.intent.extra.livefolder.DISPLAY_MODE", 1);
        LauncherModel.addItemToDatabase(context, info2, -100L, cellInfo.screen, cellInfo.cellX, cellInfo.cellY, notify);
        Launcher.sModel.addFolder(info2);
        return info2;
    }

    private View createShortcut(ApplicationInfo info) {
        Draggee draggee = info.createItem(this.mLauncher, this.mWorkspace.getCurrentScreen().asViewGroup());
        return (View) draggee.getItem();
    }

    void completeAddApplication(Context context, Intent data, CellInfo cellInfo, boolean insertAtFirst) {
        cellInfo.screen = this.mWorkspace.getCurrentScreenIndexByScrollX();
        Folder openFolder = this.mWorkspace.getOpenFolder();
        if (openFolder != null && (openFolder instanceof UserFolder)) {
            ((UserFolder) openFolder).AddIntoFolder(context, data);
            return;
        }
        if (!SettingUtil.isTabletDevice() || !this.mLauncher.isAddButtonbar()) {
            this.mWorkspace.invalidateVacant();
            if (!this.mWorkspace.hasRoomForSpan(1, 1)) {
                this.mWorkspace.invalidateVacant();
                Toast.makeText((Context) this.mLauncher, (CharSequence) this.mLauncher.getString(R.string.out_of_space), 0).show();
                return;
            }
        }
        ComponentName component = data.getComponent();
        PackageManager packageManager = context.getPackageManager();
        ActivityInfo activityInfo = null;
        try {
            activityInfo = packageManager.getActivityInfo(component, 0);
        } catch (PackageManager.NameNotFoundException e) {
            Log.e(LOG_TAG, "Couldn't find ActivityInfo for selected application", e);
        }
        if (activityInfo != null) {
            ApplicationInfo itemInfo = new ApplicationInfo();
            itemInfo.title = activityInfo.loadLabel(packageManager);
            if (itemInfo.title == null) {
                itemInfo.title = activityInfo.name;
            }
            itemInfo.title = AllAppsGridView.translateAppTitle((String) itemInfo.title, context);
            itemInfo.setActivity(component, 270532608);
            itemInfo.icon = ResourceUtil.getApplicationIcon(packageManager, activityInfo);
            itemInfo.container = -1L;
            if (SettingUtil.isTabletDevice() && this.mLauncher.isAddButtonbar()) {
                this.mFxWorkspace.mButtonBarHandler.addButtonBarAppOrShortcut(itemInfo, this.mLauncher.getMiddleClickButton());
                return;
            }
            boolean here = findSingleSlot(cellInfo);
            if (!here) {
                CellInfo vacantInfo = this.mWorkspace.scrollToAvailableScreenForShortcut();
                if (vacantInfo == null) {
                    this.mWorkspace.invalidateVacant();
                    Toast.makeText((Context) this.mLauncher, (CharSequence) this.mLauncher.getString(R.string.out_of_space), 0).show();
                    return;
                }
                int i = vacantInfo.cellX;
                cellInfo.cellX = i;
                itemInfo.cellX = i;
                int i2 = vacantInfo.cellY;
                cellInfo.cellY = i2;
                itemInfo.cellY = i2;
                int i3 = vacantInfo.screen;
                cellInfo.screen = i3;
                itemInfo.screen = i3;
            }
            LauncherModel.addItemToDatabase(this.mLauncher, itemInfo, -100L, cellInfo.screen, cellInfo.cellX, cellInfo.cellY, false);
            Launcher.sModel.addDesktopItem(itemInfo);
            addFxShortcutToDesktop(itemInfo);
        }
    }

    private View prepareDragView(CharSequence name, Drawable icon) {
        Log.v(LOG_TAG, "prepareDragView(" + ((Object) name) + ", " + icon + ")");
        if (this.mDragView == null) {
            this.mDragView = new TextView(this.mLauncher);
            ViewGroup.LayoutParams lp = new ViewGroup.LayoutParams(-2, -2);
            this.mDragView.setLayoutParams(lp);
            this.mDragView.setEnabled(false);
            this.mDragView.setGravity(17);
        }
        this.mDragView.setText(name);
        this.mDragView.setCompoundDrawablesWithIntrinsicBounds((Drawable) null, icon, (Drawable) null, (Drawable) null);
        if (!this.mDragView.isDrawingCacheEnabled()) {
            this.mDragView.setDrawingCacheEnabled(true);
            this.mDragView.buildDrawingCache();
        }
        return this.mDragView;
    }

    void completeAddShortcut(Intent data, CellInfo cellInfo, boolean insertAtFirst) {
        cellInfo.screen = this.mWorkspace.getCurrentScreenIndexByScrollX();
        if (!SettingUtil.isTabletDevice() || !this.mLauncher.isAddButtonbar()) {
            this.mWorkspace.invalidateVacant();
            if (!this.mWorkspace.hasRoomForSpan(1, 1)) {
                this.mWorkspace.invalidateVacant();
                Toast.makeText((Context) this.mLauncher, (CharSequence) this.mLauncher.getString(R.string.out_of_space), 0).show();
                return;
            }
        }
        boolean here = findSingleSlot(cellInfo);
        if ((!SettingUtil.isTabletDevice() || !this.mLauncher.isAddButtonbar()) && !here) {
            CellInfo vacantInfo = this.mWorkspace.scrollToAvailableScreenForShortcut();
            if (vacantInfo == null) {
                this.mWorkspace.invalidateVacant();
                Toast.makeText((Context) this.mLauncher, (CharSequence) this.mLauncher.getString(R.string.out_of_space), 0).show();
                return;
            } else {
                cellInfo.cellX = vacantInfo.cellX;
                cellInfo.cellY = vacantInfo.cellY;
                cellInfo.screen = vacantInfo.screen;
            }
        }
        ApplicationInfo info = Launcher.addShortcut(this.mLauncher, data, cellInfo, false);
        if (SettingUtil.isTabletDevice() && this.mLauncher.isAddButtonbar()) {
            ApplicationInfo info_tmp = new ApplicationInfo(info);
            LauncherModel.deleteItemFromDatabase(this.mLauncher, info_tmp);
            this.mFxWorkspace.mButtonBarHandler.addButtonBarAppOrShortcut(info, this.mLauncher.getMiddleClickButton());
        } else if (!this.mLauncher.isRestoring()) {
            LauncherModel.addItemToDatabase(this.mLauncher, info, -100L, cellInfo.screen, cellInfo.cellX, cellInfo.cellY, false);
            Launcher.sModel.addDesktopItem(info);
            addFxShortcutToDesktop(info);
        } else if (Launcher.sModel.isDesktopLoaded()) {
            Launcher.sModel.addDesktopItem(info);
        }
    }

    void completeAddAppWidget(Intent data, CellInfo cellInfo, boolean insertAtFirst) {
        Bundle extras = data.getExtras();
        int appWidgetId = extras.getInt("appWidgetId", -1);
        Log.d(LOG_TAG, "dumping extras content=" + extras.toString());
        AppWidgetProviderInfo appWidgetInfo = this.mLauncher.getAppWidgetManager().getAppWidgetInfo(appWidgetId);
        CellLayout layout = (CellLayout) this.mWorkspace.getChildAt(cellInfo.screen);
        int[] spans = layout.rectToCell(appWidgetInfo.minWidth, appWidgetInfo.minHeight);
        this.mWorkspace.invalidateVacant();
        if (!this.mWorkspace.hasRoomForSpan(spans[0], spans[1])) {
            this.mWorkspace.invalidateVacant();
            Toast.makeText((Context) this.mLauncher, (CharSequence) this.mLauncher.getString(R.string.out_of_space), 0).show();
            return;
        }
        LauncherAppWidgetInfo launcherInfo = new LauncherAppWidgetInfo(appWidgetId);
        launcherInfo.spanX = spans[0];
        launcherInfo.spanY = spans[1];
        launcherInfo.appWidgetComponent = appWidgetInfo.provider;
        int[] xy = this.mCellCoordinates;
        boolean here = findSlot(cellInfo, xy, spans[0], spans[1]);
        if (!here) {
            xy[1] = -1;
            xy[0] = -1;
        }
        LauncherModel.addItemToDatabase(this.mLauncher, launcherInfo, -100L, this.mWorkspace.getCurrentScreenIndex(), xy[0], xy[1], false);
        if (here) {
            if (!this.mLauncher.isRestoring()) {
                Launcher.sModel.addDesktopAppWidget(launcherInfo);
                launcherInfo.hostView = this.mLauncher.getAppWidgetHost().createView(this.mLauncher.getApplicationContext(), appWidgetId, appWidgetInfo);
                launcherInfo.hostView.setAppWidget(appWidgetId, appWidgetInfo);
                launcherInfo.hostView.setTag(launcherInfo);
                addLegacyItemToDesktop(launcherInfo.hostView, launcherInfo, this.mWorkspace.getCurrentScreenIndex(), xy[0], xy[1], launcherInfo.spanX, launcherInfo.spanY, insertAtFirst);
                this.mWorkspace.invalidateVacant();
                return;
            }
            if (Launcher.sModel.isDesktopLoaded()) {
                Launcher.sModel.addDesktopAppWidget(launcherInfo);
                return;
            }
            return;
        }
        CellInfo vacantInfo = this.mWorkspace.scrollToAvailableScreenForSpan(launcherInfo.spanX, launcherInfo.spanY);
        if (vacantInfo == null) {
            this.mWorkspace.invalidateVacant();
            Toast.makeText((Context) this.mLauncher, (CharSequence) this.mLauncher.getString(R.string.out_of_space), 0).show();
            return;
        }
        int i = vacantInfo.cellX;
        cellInfo.cellX = i;
        launcherInfo.cellX = i;
        int i2 = vacantInfo.cellY;
        cellInfo.cellY = i2;
        launcherInfo.cellY = i2;
        cellInfo.screen = vacantInfo.screen;
        Launcher.sModel.addDesktopAppWidget(launcherInfo);
        launcherInfo.hostView = this.mLauncher.getAppWidgetHost().createView(this.mLauncher.getApplicationContext(), appWidgetId, appWidgetInfo);
        launcherInfo.hostView.setAppWidget(appWidgetId, appWidgetInfo);
        launcherInfo.hostView.setTag(launcherInfo);
        addLegacyItemToDesktop(launcherInfo.hostView, launcherInfo, cellInfo.screen, cellInfo.cellX, cellInfo.cellY, launcherInfo.spanX, launcherInfo.spanY, insertAtFirst);
        this.mWorkspace.invalidateVacant();
        LauncherModel.deleteItemFromDatabase(this.mLauncher, launcherInfo);
        LauncherModel.addItemToDatabase(this.mLauncher, launcherInfo, -100L, cellInfo.screen, cellInfo.cellX, cellInfo.cellY, false);
    }

    void flushPendingAddInScreens() {
        ensurePendingTaskRunner();
        while (this.mPendingAddInScreens.size() > 0) {
            Runnable pending = this.mPendingAddInScreens.remove(0);
            pending.run();
        }
    }

    void flushPendingAddInFxScreens() {
        if (this.mHandler != null && !this.mHandler.hasMessages(MSG_BINDING_FXITEMS)) {
            this.mHandler.sendEmptyMessage(MSG_BINDING_FXITEMS);
        }
    }

    void ensurePendingTaskRunner() {
        if (this.mHandlerThread == null) {
            this.mHandlerThread = new HandlerThread("mPendingAddToFxScreenTasks");
            this.mHandlerThread.start();
            this.mHandler = new Handler(this.mHandlerThread.getLooper()) { // from class: com.htc.launcher.DesktopItemController.1
                @Override // android.os.Handler
                public void handleMessage(Message msg) {
                    switch (msg.what) {
                        case DesktopItemController.MSG_BINDING_FXITEMS /* 1300 */:
                            Logger.d(DesktopItemController.LOG_TAG, "binding items");
                            DesktopItemController.this.flushTasks(DesktopItemController.this.mPendingAddToFxScreenTasks);
                            DesktopItemController.this.mLauncher.sendMsgDoneAllBinding();
                            break;
                        case DesktopItemController.MSG_FLUSH_TASKS /* 1301 */:
                            Logger.d(DesktopItemController.LOG_TAG, "flush tasks");
                            DesktopItemController.this.flushTasks(DesktopItemController.this.mPendingAddToFxScreenTasks);
                            break;
                    }
                }
            };
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void flushTasks(List<Runnable> tasks) {
        while (true) {
            Runnable next = null;
            synchronized (tasks) {
                if (tasks.size() > 0) {
                    next = tasks.remove(0);
                }
            }
            if (next == null) {
                return;
            } else {
                next.run();
            }
        }
    }

    void schedulePendingTask(Runnable task) {
        ensurePendingTaskRunner();
        synchronized (this.mPendingAddToFxScreenTasks) {
            this.mPendingAddToFxScreenTasks.add(task);
        }
        if (this.mHandler != null && !this.mHandler.hasMessages(MSG_FLUSH_TASKS)) {
            this.mHandler.sendEmptyMessage(MSG_FLUSH_TASKS);
        }
    }

    void addInScreenAsync(final View child, final ItemInfo info, final int screen, final int x, final int y, final int spanX, final int spanY, final boolean insert) {
        this.mPendingAddInScreens.add(new Runnable() { // from class: com.htc.launcher.DesktopItemController.2
            @Override // java.lang.Runnable
            public void run() {
                try {
                    DesktopItemController.this.addLegacyItemToDesktop(child, info, screen, x, y, spanX, spanY, insert);
                    if (child.getTag() instanceof ApplicationInfo) {
                        if (DesktopItemController.localLOGD) {
                            Log.d(DesktopItemController.LOG_TAG, "sending itemAdded - " + child.getTag());
                        }
                        LauncherModel.sendItemAdded(DesktopItemController.this.mLauncher, (ApplicationInfo) child.getTag());
                    }
                } catch (StackOverflowError error) {
                    Log.e(DesktopItemController.LOG_TAG, "StackOverflowError : " + error);
                    Log.e(DesktopItemController.LOG_TAG, "child : " + child);
                    Log.e(DesktopItemController.LOG_TAG, "screen : " + screen);
                    Log.e(DesktopItemController.LOG_TAG, "x : " + x);
                    Log.e(DesktopItemController.LOG_TAG, "y : " + y);
                    if (child.getTag() instanceof WidgetProxy) {
                        WidgetProxy wp = (WidgetProxy) child.getTag();
                        Log.e(DesktopItemController.LOG_TAG, "WidgetView : " + wp.getWidgetView());
                        throw error;
                    }
                    throw error;
                }
            }
        });
    }

    void addWidgetAsync(View view, Widget widget, boolean insert) {
        addInScreenAsync(view, widget, widget.screen, widget.cellX, widget.cellY, widget.spanX, widget.spanY, insert);
    }

    void addFxWidgetAsync(final FxItemInfo fxItemInfo) {
        if (fxItemInfo != null && this.mLauncher != null) {
            this.mPendingAddToFxScreenTasks.add(new Runnable() { // from class: com.htc.launcher.DesktopItemController.3
                @Override // java.lang.Runnable
                public void run() {
                    DesktopItemController.this.bindFxWidget(fxItemInfo);
                }
            });
        }
    }

    private void reloadFxWidgetAsync(final FxItemInfo fxItemInfo) {
        if (fxItemInfo != null && this.mLauncher != null) {
            this.mPendingAddToFxScreenTasks.add(new Runnable() { // from class: com.htc.launcher.DesktopItemController.4
                @Override // java.lang.Runnable
                public void run() {
                    DesktopItemController.this.rebindFxWidget(fxItemInfo);
                }
            });
        }
    }

    void openFolder(FolderInfo folderInfo) {
        Folder openFolder;
        if (folderInfo instanceof UserFolderInfo) {
            openFolder = UserFolder.fromXml(this.mLauncher);
        } else if (folderInfo instanceof LiveFolderInfo) {
            openFolder = LiveFolder.fromXml(this.mLauncher, folderInfo);
        } else {
            return;
        }
        openFolder.setDragger(this.mLauncher.getDragController());
        openFolder.setLauncher(this.mLauncher);
        openFolder.bind(folderInfo);
        folderInfo.opened = true;
        openFolder.setTag(folderInfo);
        Logger.d(LOG_TAG, "[EDIT_DEBUG][FOLDER] openFolder() - folderInfo:" + folderInfo);
        LegacyLayout ll = this.mWorkspace.wrapLegacyView(openFolder);
        this.mWorkspace.addInScreen(ll, folderInfo.screen, 0, 0, -1, -1, true);
        openFolder.onOpen();
        this.mWorkspace.invalidate();
        Logger.d(LOG_TAG, "[EDIT_DEBUG][FOLDER] openFolder() - done");
    }

    void closeFolder() {
        Folder folder = this.mWorkspace.getOpenFolder();
        if (folder != null) {
            closeFolder(folder);
        }
    }

    void closeFolder(Folder folder) {
        folder.getInfo().opened = false;
        ViewGroup parent = (ViewGroup) folder.getParent();
        if (parent != null) {
            if (parent instanceof LegacyLayout) {
                LegacyLayout legacyLayout = (LegacyLayout) parent;
                ViewGroup parent2 = (ViewGroup) legacyLayout.getParent();
                if (parent2 != null) {
                    Logger.d(LOG_TAG, "[EDIT_DEBUG][FOLDER] closeFolder() - legacyLayout.removeView(folder)");
                    legacyLayout.fxDetach();
                    parent2.removeView(legacyLayout);
                }
            } else {
                Logger.d(LOG_TAG, "[EDIT_DEBUG][FOLDER] closeFolder() - parent.removeView(folder)");
                parent.removeView(folder);
            }
        }
        folder.onClose();
        Logger.d("Desktop", "[EDIT_DEBUG][FOLDER] closeFolder() - done");
    }

    public void removeLegacyWidget(View source, ItemInfo item) {
        if (item == null) {
            Log.e(LOG_TAG, "Sould have something to remove!");
            return;
        }
        if (item.container != -1) {
            LauncherModel model = Launcher.getModel();
            if (item.container == -100) {
                if (item instanceof LauncherAppWidgetInfo) {
                    model.removeDesktopAppWidget((LauncherAppWidgetInfo) item);
                } else {
                    if (item instanceof FxItemInfo) {
                        this.mFxWidgetManager.removeWidget(((FxItemInfo) item).widgetId);
                    }
                    model.removeDesktopItem(item);
                }
            } else if (source instanceof UserFolder) {
                UserFolder userFolder = (UserFolder) source;
                model.removeUserFolderItem((UserFolderInfo) userFolder.getInfo(), item);
            }
            if (item instanceof UserFolderInfo) {
                UserFolderInfo userFolderInfo = (UserFolderInfo) item;
                LauncherModel.deleteUserFolderContentsFromDatabase(this.mLauncher, userFolderInfo);
                model.removeUserFolder(userFolderInfo);
            } else if (item instanceof LauncherAppWidgetInfo) {
                LauncherAppWidgetInfo launcherAppWidgetInfo = (LauncherAppWidgetInfo) item;
                LauncherAppWidgetHost appWidgetHost = this.mLauncher.getAppWidgetHost();
                if (appWidgetHost != null && LauncherModel.getAppWidgetCount(this.mLauncher, launcherAppWidgetInfo.appWidgetId) <= 1) {
                    appWidgetHost.deleteAppWidgetId(launcherAppWidgetInfo.appWidgetId);
                }
            }
            if (item instanceof WidgetProxy) {
                ((WidgetProxy) item).onLayoutRemoved(this.mLauncher);
            }
            LauncherModel.deleteItemFromDatabase(this.mLauncher, item);
            WidgetWorkspaceManager.instance().onSceneModified();
            if (Launcher.localLOGD) {
                Log.d("Rosie", "[ATS][proc_Name][press_hold_widget][removed]");
            }
        }
    }

    public void removeItem(DragSource source, ItemInfo item) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.removeItem() - enter");
        if (item == null) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.removeItem() item = null, return!");
            Log.e(LOG_TAG, "Sould have something to remove!");
            return;
        }
        if (item.container != -1) {
            this.mFxWidgetManager.removeFxShortcutItem(item.getId());
            LauncherModel model = Launcher.getModel();
            if (item.container == -100) {
                if (item.cellY == 10) {
                    model.removeButtonItem(item);
                    if (SettingUtil.isDoubleShot()) {
                        this.mLauncher.getFxWorkspace().getCurrentWorkspace().showMiddleBackgroundImageControls(model.getButtonBarOccupied());
                    }
                } else if (item instanceof LauncherAppWidgetInfo) {
                    model.removeDesktopAppWidget((LauncherAppWidgetInfo) item);
                } else {
                    if (item instanceof FxItemInfo) {
                        this.mFxWidgetManager.removeWidget(((FxItemInfo) item).widgetId);
                    }
                    model.removeDesktopItem(item);
                }
            } else if (source instanceof UserFolder) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.removeItem() for UserFolder");
                UserFolder userFolder = (UserFolder) source;
                model.removeUserFolderItem((UserFolderInfo) userFolder.getInfo(), item);
            }
            if (item instanceof UserFolderInfo) {
                UserFolderInfo userFolderInfo = (UserFolderInfo) item;
                LauncherModel.deleteUserFolderContentsFromDatabase(this.mLauncher, userFolderInfo);
                this.mLauncher.removeDropTarget(userFolderInfo.getDropTarget());
                model.removeUserFolder(userFolderInfo);
            } else if (item instanceof LauncherAppWidgetInfo) {
                LauncherAppWidgetInfo launcherAppWidgetInfo = (LauncherAppWidgetInfo) item;
                LauncherAppWidgetHost appWidgetHost = this.mLauncher.getAppWidgetHost();
                if (appWidgetHost != null) {
                    appWidgetHost.deleteAppWidgetId(launcherAppWidgetInfo.appWidgetId);
                }
            }
            if (item instanceof WidgetProxy) {
                ((WidgetProxy) item).onLayoutRemoved(this.mLauncher);
            }
            LauncherModel.deleteItemFromDatabase(this.mLauncher, item);
            WidgetWorkspaceManager.instance().onSceneModified();
            if (Launcher.localLOGD) {
                Log.d("Rosie", "[ATS][proc_Name][press_hold_widget][removed]");
            }
            Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.removeItem() - done");
            return;
        }
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.removeItem() item.container = -1, return!");
    }

    public boolean isItemEditable(ItemInfo item) {
        if (item instanceof FxItemInfo) {
            return this.mFxWidgetManager.isEditable(item.screen, item.cellX, item.cellY);
        }
        return item != null && item.isItemEditable();
    }

    public void editItem(DragSource source, ItemInfo item) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.editItem()");
        if (item != null && item.isItemEditable()) {
            Log.e(LOG_TAG, "edit item");
            if (item instanceof WidgetProxy) {
                setLegacyItemToEdit(item);
                WidgetProxy widget = (WidgetProxy) item;
                Intent intent = null;
                try {
                    intent = Intent.parseUri(widget.getSettingIntent(), 0);
                } catch (URISyntaxException e) {
                    Log.e(LOG_TAG, "cannot launch setting for widget:" + widget + ", intent=" + ((Object) null));
                }
                this.mLauncher.mWorkspace.lock();
                this.mLauncher.startActivityForResult(intent, 501);
                return;
            }
            if ((item instanceof FxItemInfo) && isItemEditable(item)) {
                this.mFxWidgetManager.editWidget(item.screen, item.cellX, item.cellY);
            }
        }
    }

    void setLegacyItemToEdit(ItemInfo itemToEdit) {
        this.mLegacyItemToEdit = itemToEdit;
    }

    void onCompleteEditLegacy(int result, Intent data, CellInfo origin) {
        if (result == -1) {
            if (this.mLegacyItemToEdit != null && (this.mLegacyItemToEdit instanceof WidgetProxy)) {
                Launcher.sModel.removeDesktopItem(this.mLegacyItemToEdit);
                ((WidgetProxy) this.mLegacyItemToEdit).onLayoutRemoved(this.mLauncher);
                LauncherModel.deleteItemFromDatabase(this.mLauncher, this.mLegacyItemToEdit);
                WidgetWorkspaceManager.instance().onSceneModified();
                this.mWorkspace.onDropCompleted(null, true, DragSource.DragCompletedAction.REMOVE);
                this.mWorkspace.setCurrentScreen(this.mLegacyItemToEdit.screen);
                this.mSlideController.snapToScreen(this.mLegacyItemToEdit.screen);
                addWidget(Launcher.sWidgetPackageManager.newWidget(this.mLegacyItemToEdit.itemType, null, -1L), data, origin);
                this.mLegacyItemToEdit = null;
                return;
            }
            return;
        }
        this.mWorkspace.setCurrentScreen(this.mLegacyItemToEdit.screen);
        this.mSlideController.snapToScreen(this.mLegacyItemToEdit.screen);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onClickFolder(final FxItem folder) {
        this.mWorkspace.post(new Runnable() { // from class: com.htc.launcher.DesktopItemController.6
            @Override // java.lang.Runnable
            public void run() {
                FolderInfo folderInfo = (FolderInfo) folder.getInfo();
                Logger.d(DesktopItemController.LOG_TAG, "[EDIT_DEBUG][FOLDER] onClick() - FolderInfo:" + folderInfo);
                if (folderInfo.opened) {
                    Folder openFolder = DesktopItemController.this.mWorkspace.getFolderForTag(folderInfo);
                    if (openFolder != null) {
                        int folderScreen = DesktopItemController.this.mWorkspace.getScreenForView(openFolder);
                        DesktopItemController.this.closeFolder(openFolder);
                        if (folderScreen != DesktopItemController.this.mWorkspace.getCurrentScreenIndex()) {
                            DesktopItemController.this.closeFolder();
                            DesktopItemController.this.openFolder(folderInfo);
                            return;
                        }
                        return;
                    }
                    return;
                }
                DesktopItemController.this.closeFolder();
                DesktopItemController.this.openFolder(folderInfo);
            }
        });
    }

    class LaunchShortcutRunnable implements Runnable {
        Intent mIntent;

        LaunchShortcutRunnable(Intent intent) {
            this.mIntent = intent;
        }

        @Override // java.lang.Runnable
        public void run() {
            DesktopItemController.this.mLauncher.startActivitySafely(this.mIntent);
        }
    }

    public void rebindFxWidget(FxItemInfo fxItemInfo) {
        HostWidgetManager.WidgetInfo wi = fxItemInfo.toWidgetInfo();
        addFxItemToDesktop(wi, wi.getContainerId(), wi.getX(), wi.getY(), wi.getSpanX(), wi.getSpanY());
    }

    public void onConfigurationChanged(Configuration newConfiguration) {
        boolean isPortrait = newConfiguration.orientation == 1;
        if (localLOGD) {
            Log.d(LOG_TAG, "onConfigurationChanged " + (isPortrait ? "portrait" : "landscape"));
        }
        this.mFxWidgetManager.notifyAllWidgetsConfigurationChanged(newConfiguration);
    }

    public FxScene getWidgetScene(int id) {
        return this.mFxWidgetManager.getWidgetScene(id);
    }

    public static void onAppWidgetOrientationChanged(final Launcher launcher, final Workspace workspace, final AppWidgetManager appWidgetManager, final LauncherAppWidgetHost appWidgetHost, int screen, boolean screenOnly) {
        ArrayList<Runnable> pendingActions = new ArrayList<>();
        int counti = workspace.getChildCount();
        for (int i = 0; i < counti; i++) {
            if ((!screenOnly || i == screen) && (screenOnly || i != screen)) {
                View temp = workspace.getChildAt(i);
                if (temp instanceof CellLayout) {
                    final CellLayout cell = (CellLayout) temp;
                    int countj = cell.getChildCount();
                    for (int j = 0; j < countj; j++) {
                        final View view = cell.getChildAt(j);
                        if (view.getTag() instanceof LauncherAppWidgetInfo) {
                            final LauncherAppWidgetInfo item = (LauncherAppWidgetInfo) view.getTag();
                            if (localLOGD) {
                                Log.d(LOG_TAG, "will re-create app widget");
                            }
                            pendingActions.add(new Runnable() { // from class: com.htc.launcher.DesktopItemController.8
                                @Override // java.lang.Runnable
                                public void run() {
                                    AppWidgetProviderInfo appWidgetInfo = appWidgetManager.getAppWidgetInfo(item.appWidgetId);
                                    if (DesktopItemController.localLOGD) {
                                        Log.d(DesktopItemController.LOG_TAG, "re-create app widget - " + (appWidgetInfo == null ? "null" : appWidgetInfo.provider));
                                    }
                                    item.hostView = appWidgetHost.createView(launcher.getApplicationContext(), item.appWidgetId, appWidgetInfo);
                                    item.hostView.setAppWidget(item.appWidgetId, appWidgetInfo);
                                    item.hostView.setTag(item);
                                    item.hostView.setOnLongClickListener(workspace.getOnLongClickListener());
                                    if (view instanceof LegacyLayout) {
                                        if (DesktopItemController.localLOGD) {
                                            Log.d(DesktopItemController.LOG_TAG, "change legacy layout content for app widget - " + (appWidgetInfo == null ? "null" : appWidgetInfo.provider));
                                        }
                                        LegacyLayout ll = (LegacyLayout) view;
                                        item.hostView.setLayoutParams(ll.getTheView().getLayoutParams());
                                        ll.changeView(item.hostView);
                                        return;
                                    }
                                    cell.removeView(view);
                                    launcher.getDesktopItemController().addLegacyItemToDesktop(item.hostView, item, item.screen, item.cellX, item.cellY, item.spanX, item.spanY, true);
                                }
                            });
                        }
                    }
                }
            }
        }
        Iterator i$ = pendingActions.iterator();
        while (i$.hasNext()) {
            Runnable action = i$.next();
            workspace.post(action);
        }
    }

    public FxScene getLegacyScene(long screen, long id) {
        return getLegacyLayoutWithId((int) screen, id);
    }

    private FxScene getLegacyLayoutWithId(int screen, long id) {
        CellLayout cl = (CellLayout) this.mWorkspace.getScreenAt(screen);
        View[] removed = cl.mBackupChildren;
        if (removed == null) {
            return null;
        }
        for (View v : removed) {
            if (v != null && (v instanceof LegacyLayout)) {
                LegacyLayout ll = (LegacyLayout) v;
                ItemInfo info = (ItemInfo) ll.getTheView().getTag();
                if (info.id == id) {
                    return ll.getFxScene();
                }
            }
        }
        return null;
    }

    void setDragger(DragController dragger) {
        this.mDragger = dragger;
    }

    public void startFloating(View view, DragSource from, ItemInfo info, int dragAction) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] startFloatingLegacy()");
        int[] xy = this.mFloatingPos;
        view.getLocationInWindow(xy);
        Log.e(LOG_TAG, "[EDIT_DEBUG] DesktopItemControll.startFloating() floating pos:" + xy[0] + ", " + xy[1]);
        RectF bounds = this.mFloatingBounds;
        bounds.left = xy[0];
        bounds.top = xy[1];
        bounds.right = xy[0] + view.getWidth();
        bounds.bottom = xy[1] + view.getHeight();
        startFloatingLegacy(view, from, info, dragAction, bounds);
    }

    private void clearFloating() {
        if (this.mFloatingFxItem != null) {
            this.mFxFloatEnv.onPoof(this.mFloatingFxItem);
            this.mFloatingFxItem = null;
        }
        this.mFxFloatEnv = null;
        this.mLegacyFloatEnv = null;
    }

    void setFxFloatingEnv(FloatingEnv env) {
        this.mFxFloatEnv = env;
    }

    void setLegacyFloatingEnv(FloatingEnv env) {
        this.mLegacyFloatEnv = env;
    }

    private void startFloatingLegacy(View view, DragSource from, ItemInfo info, int dragAction, RectF bounds) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] startFloatingLegacy()");
        if (this.mFloatingFxItem == null) {
            LegacyLayout ll = this.mWorkspace.wrapLegacyView(view);
            this.mFloatingFxItem = FxItem.create(ll.getFxScene(), ll, info);
            this.mLegacyFloatEnv.onFloat(this.mFloatingFxItem, bounds);
            this.mFxFloatEnv.onFloat(this.mFloatingFxItem, bounds);
            this.mWorkspace.setDraggeeItemInfo(info, this.mFloatingFxItem);
            if (from instanceof FxWorkspace) {
                this.mLauncher.getDragController().prepareDrag(this.mFloatingFxItem, this.mFxWorkspace, info, 0);
            } else {
                this.mLauncher.getDragController().prepareDrag(this.mFloatingFxItem, from, info, 0);
            }
            this.mFloatingFxItem.onDrag();
            if (from instanceof FxWorkspace) {
                this.mLauncher.getDragController().startDrag(this.mFloatingFxItem, this.mFxWorkspace, info, 0);
                return;
            } else {
                this.mLauncher.getDragController().startDrag(this.mFloatingFxItem, from, info, 0);
                return;
            }
        }
        Log.e(LOG_TAG, "There is already someting floating:" + this.mFloatingFxItem.getItem());
    }

    private void startFloatingLegacyWidget(LegacyLayout legacyLayout, DragSource from, ItemInfo info, int dragAction, RectF bounds) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG]# startFloatingLegacyWidget()");
        if (this.mFloatingFxItem != null) {
            resumeRenderring();
            Log.e(LOG_TAG, "There is already someting floating:" + this.mFloatingFxItem.getItem());
            return;
        }
        this.mFloatingFxItem = FxItem.create(legacyLayout.getFxScene(), legacyLayout, info);
        this.mLegacyFloatEnv.onFloat(this.mFloatingFxItem, bounds);
        this.mFxFloatEnv.onFloat(this.mFloatingFxItem, bounds);
        this.mLauncher.getFxWorkspace().freeze(false);
        this.mLauncher.getDragController().prepareDrag(this.mFloatingFxItem, from, info, 0);
        this.mFloatingFxItem.onDrag();
        this.mLauncher.getDragController().startDrag(this.mFloatingFxItem, from, info, 0);
    }

    boolean landFxItem(int container, int x, int y) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.landFxItem() - enter");
        if (this.mFloatingFxItem == null) {
            Log.e(LOG_TAG, "Should have something in the air for landing");
            return false;
        }
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.landFxItem() onLand");
        Point p = this.mFloatingFxItem.getCellXY();
        this.mFloatingFxItem.onDrop(null, p.x, p.y);
        this.mFxFloatEnv.onLand(this.mFloatingFxItem, container, x, y);
        this.mFloatingFxItem = null;
        return true;
    }

    public boolean poofFxItem() {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.poofFxItem()");
        if (this.mFloatingFxItem == null) {
            Log.e(LOG_TAG, "[EDIT_DEBUG] Should have something in the air for poofing");
            return false;
        }
        Point p = this.mFloatingFxItem.getCellXY();
        this.mFloatingFxItem.onDrop(null, p.x, p.y);
        boolean ok = this.mFxFloatEnv.onPoof(this.mFloatingFxItem);
        this.mFloatingFxItem = null;
        return ok;
    }

    public void poofLegacyItem() {
        if (this.mFloatingFxItem != null) {
            Point p = this.mFloatingFxItem.getCellXY();
            this.mFloatingFxItem.onDrop(null, p.x, p.y);
            this.mLegacyFloatEnv.onPoof(this.mFloatingFxItem);
            poofFxItem();
            this.mFloatingFxItem = null;
            this.mWorkspace.leaveEditMode();
        }
    }

    Draggee getFloatingDragge() {
        return this.mFloatingFxItem;
    }

    void destroy() {
        clearFloating();
    }

    public void cleanUpFloatingFxItem() {
        this.mFloatingFxItem = null;
        this.mWorkspace.leaveEditMode();
    }

    public void pauseRenderring() {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.pauseRenderring()");
        this.mFxWorkspace.freeze(true);
    }

    public void resumeRenderring() {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.resumeRenderring()");
        this.mFxWorkspace.freeze(false);
    }

    public void removeDraggedAppIconAddedIntoFolderIcon() {
        this.mWorkspace.removeDraggedAppIconAddedIntoFolderIcon();
    }

    public void onLeapRearrangeComplete(int[] screenMap) {
        Message msg = this.mOnLeapRearrangeCompleteHandler.obtainMessage();
        msg.obj = screenMap;
        this.mOnLeapRearrangeCompleteHandler.sendMessage(msg);
    }

    public void updateWidgetContainerId(List<FxItem> fxItems, int screen) {
        if (fxItems != null) {
            for (FxItem fxItem : fxItems) {
                ItemInfo info = fxItem.getInfo();
                if (info != null) {
                    info.screen = screen;
                    if (info instanceof FxItemInfo) {
                        this.mFxWidgetManager.updateWidgetContainerId(((FxItemInfo) info).widgetId, screen);
                    }
                }
            }
        }
    }

    public void bindFxShortcut(FxShortcutInfo fxShortcutInfo) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.bindFxShortcut()" + fxShortcutInfo.id + "," + ((Object) fxShortcutInfo.title) + "," + fxShortcutInfo.itemType);
        boolean ok = addFxShortcutToDesktop(fxShortcutInfo);
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.bindFxShortcut() ok(" + ok + ")");
    }

    private boolean addFxShortcutToDesktop(FxShortcutInfo info) {
        if (info == null) {
            return false;
        }
        FxItem fxItem = (FxItem) info.createItem(this.mLauncher, null);
        info.setObserver((FxShortcutButton) fxItem);
        boolean added = this.mFxWorkspace.addItemToScreen(info.screen, info.id, fxItem, new FxScreen.LayoutParams(info.cellX, info.cellY, info.spanX, info.spanY));
        if (added) {
            this.mFxWidgetManager.addFxShortcutItem(fxItem);
        }
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.addFxShortcutToDesktop (" + info.id + ") added(" + added + ")");
        Logger.showMeWidget(this.mLauncher, "topic_tag-home_screen-add_icons_shortcuts");
        return added;
    }

    void addFxShortcutAsync(final FxShortcutInfo appItemInfo) {
        if (appItemInfo != null && this.mLauncher != null) {
            this.mPendingAddToFxScreenTasks.add(new Runnable() { // from class: com.htc.launcher.DesktopItemController.12
                @Override // java.lang.Runnable
                public void run() {
                    DesktopItemController.this.bindFxShortcut(appItemInfo);
                }
            });
        }
    }

    public RectF getExternalFloatingBounds(View view) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] getExternalFloatingBounds()");
        int[] xy = new int[2];
        view.getLocationInWindow(xy);
        Log.e(LOG_TAG, "[EDIT_DEBUG] DesktopItemControll.getExternalFloatingBounds() floating pos:" + xy[0] + ", " + xy[1]);
        RectF bounds = new RectF();
        if (SettingUtil.isDoubleShot()) {
            if (this.mLauncher.isPortrait()) {
                bounds.left = xy[0];
                bounds.top = xy[1] - 50;
                bounds.right = bounds.left + view.getWidth();
                bounds.bottom = bounds.top + view.getHeight();
            } else {
                bounds.left = xy[0] - 50;
                bounds.top = xy[1];
                bounds.right = bounds.left + view.getWidth();
                bounds.bottom = bounds.top + view.getHeight();
            }
        } else {
            bounds.left = xy[0] - 30;
            bounds.top = xy[1] - 50;
            bounds.right = bounds.left + view.getWidth();
            bounds.bottom = (xy[1] + view.getHeight()) - 50;
        }
        return bounds;
    }

    public FxScene getFxShortcutScene(long id) {
        if (this.mLauncher == null || this.mLauncher.getWorkspace() == null) {
            return null;
        }
        return this.mFxWidgetManager.getFxShortcutScene(id, this.mLauncher.getWorkspace().isPortrait());
    }

    public FxItem getFxShortcutItem(long id) {
        return this.mFxWidgetManager.getFxShortcutItem(id);
    }

    public void removeShortcutsForPackage(String packageName) {
        ItemInfo info;
        Intent intent;
        ComponentName componentName;
        if (this.mLauncher != null && this.mFxWidgetManager != null && packageName != null) {
            LauncherModel model = Launcher.getModel();
            List<FxItem> shortcutItems = this.mFxWidgetManager.getFxShortcutItems();
            List<FxItem> deletedShortcutItems = new ArrayList<>();
            for (FxItem item : shortcutItems) {
                if (item != null && (info = item.getInfo()) != null) {
                    if (info instanceof UserFolderInfo) {
                        UserFolderInfo folderInfo = (UserFolderInfo) info;
                        ArrayList<ApplicationInfo> contents = folderInfo.contents;
                        ArrayList<ApplicationInfo> toRemove = new ArrayList<>(1);
                        int contentsCount = contents.size();
                        for (int k = 0; k < contentsCount; k++) {
                            ApplicationInfo appInfo = contents.get(k);
                            Intent intent2 = appInfo.intent;
                            ComponentName name = intent2.getComponent();
                            if ("android.intent.action.MAIN".equals(intent2.getAction()) && name != null && packageName.equals(name.getPackageName())) {
                                toRemove.add(appInfo);
                                LauncherModel.deleteItemFromDatabase(this.mLauncher, appInfo);
                            }
                        }
                        contents.removeAll(toRemove);
                    } else if (info.itemType == 0 && (intent = ((ApplicationInfo) info).intent) != null && (componentName = intent.getComponent()) != null && packageName.equals(componentName.getPackageName())) {
                        this.mLauncher.getFxWorkspace().removeItemFromScreen(info.screen, (int) info.id);
                        model.removeDesktopItem(info);
                        LauncherModel.deleteItemFromDatabase(this.mLauncher, info);
                        deletedShortcutItems.add(item);
                    }
                }
            }
            for (FxItem item2 : deletedShortcutItems) {
                if (item2 != null) {
                    shortcutItems.remove(item2);
                    Log.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemControll.removeShortcutsForPackage(" + packageName + ") " + item2.getInfo().screen + ":" + item2.getInfo().cellX + "," + item2.getInfo().cellY + " " + item2.getInfo().spanX + "," + item2.getInfo().spanY);
                }
            }
            deletedShortcutItems.clear();
        }
    }

    public boolean updateShortcutsForPackage(String packageName) {
        ItemInfo info;
        Intent intent;
        ComponentName componentName;
        if (this.mLauncher == null || this.mFxWidgetManager == null || packageName == null) {
            return false;
        }
        List<FxItem> shortcutItems = this.mFxWidgetManager.getFxShortcutItems();
        int successUpdateCount = 0;
        for (FxItem item : shortcutItems) {
            if (item != null && (info = item.getInfo()) != null && info.itemType == 0 && (intent = ((ApplicationInfo) info).intent) != null && (componentName = intent.getComponent()) != null && packageName.equals(componentName.getPackageName())) {
                ApplicationInfo appInfo = (ApplicationInfo) info;
                Drawable icon = Launcher.getModel().getApplicationInfoIcon(this.mLauncher.getPackageManager(), appInfo);
                if (icon == null) {
                    icon = this.mLauncher.getPackageManager().getDefaultActivityIcon();
                }
                if (icon != null && icon != appInfo.icon) {
                    appInfo.icon = Utilities.createIconThumbnail(icon, this.mLauncher);
                    if (appInfo.icon != null) {
                        appInfo.icon.setCallback(null);
                    }
                    appInfo.filtered = true;
                    ((FxShortcutButton) item).setIcon(appInfo.icon);
                }
                successUpdateCount++;
            }
        }
        return successUpdateCount > 0;
    }

    public boolean updateShortcutForPackage(FxItem item, String packageName) {
        Intent intent;
        ComponentName componentName;
        if (this.mLauncher == null || item == null || packageName == null) {
            return false;
        }
        this.mFxWidgetManager.getFxShortcutItems();
        ItemInfo info = item.getInfo();
        if (info != null && (intent = ((ApplicationInfo) info).intent) != null && (componentName = intent.getComponent()) != null && packageName.equals(componentName.getPackageName())) {
            ApplicationInfo appInfo = (ApplicationInfo) info;
            Drawable icon = Launcher.getModel().getApplicationInfoIcon(this.mLauncher.getPackageManager(), appInfo);
            if (icon == null) {
                icon = this.mLauncher.getPackageManager().getDefaultActivityIcon();
            }
            if (icon != null && icon != appInfo.icon) {
                appInfo.icon = Utilities.createIconThumbnail(icon, this.mLauncher);
                if (appInfo.icon != null) {
                    appInfo.icon.setCallback(null);
                }
                appInfo.filtered = true;
                ((FxShortcutButton) item).setIcon(appInfo.icon);
            }
            return true;
        }
        return false;
    }

    public void addPendingSyncPackages(String packageName) {
        synchronized (this.mPendingSyncPackages) {
            this.mPendingSyncPackages.add(packageName);
        }
    }

    void updatePendingSyncPackages() {
        Iterator i$ = this.mPendingSyncPackages.iterator();
        while (i$.hasNext()) {
            String packageName = i$.next();
            if (updateShortcutsForPackage(packageName)) {
                if (this.mTempSyncedPackages == null) {
                    this.mTempSyncedPackages = new ArrayList<>();
                }
                this.mTempSyncedPackages.add(packageName);
            }
        }
        if (this.mTempSyncedPackages != null && this.mTempSyncedPackages.size() > 0) {
            synchronized (this.mPendingSyncPackages) {
                Iterator i$2 = this.mTempSyncedPackages.iterator();
                while (i$2.hasNext()) {
                    this.mPendingSyncPackages.remove(i$2.next());
                }
            }
            this.mTempSyncedPackages.clear();
        }
    }
}
