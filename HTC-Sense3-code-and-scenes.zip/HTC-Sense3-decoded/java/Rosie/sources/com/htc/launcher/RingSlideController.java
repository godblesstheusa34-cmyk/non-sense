package com.htc.launcher;

import android.content.Context;
import android.util.Log;
import com.htc.android.rosie.home.fxcontrol.IPageSinkControl;
import com.htc.launcher.LauncherSettings;
import com.htc.launcher.settings.SettingUtil;
import com.htc.launcher.widget.EaseOutCubic;
import com.htc.launcher.widget.EasingFunction;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class RingSlideController extends SlideController {
    private static final float KEEP_SINKING_SINK = 0.2f;
    private static final float KEEP_SINKING_VELOCITY = 1000.0f;
    private static final String LOG_TAG = RingSlideController.class.getSimpleName();
    private EasingFunction mLongEasingFunction;
    private final IPageSinkControl mSinkControl;
    private int mSnapOffset;
    private int mVelocity;

    public RingSlideController(Context context, Workspace workspace, IPageSinkControl sinkControl) {
        super(context, workspace);
        this.mLongEasingFunction = new EaseOutCubic(true);
        this.mSinkControl = sinkControl;
    }

    @Override // com.htc.launcher.SlideController
    protected int getSnapOffset(int velocityX) {
        int snapOffset;
        int fullRoundScrollVelocity = this.mWorkspace.isPortrait() ? SettingUtil.sFullRoundScrollVelocityPort : SettingUtil.sFullRoundScrollVelocityLand;
        int singlePageScrollVelocity = this.mWorkspace.isPortrait() ? SettingUtil.sSinglePageScrollVelocityPort : SettingUtil.sSinglePageScrollVelocityLand;
        if (this.mWorkspace.isPortrait() && !SettingUtil.sMultiPageScrollOnPortrait) {
            return 1;
        }
        if (velocityX == this.mVelocity) {
            return this.mSnapOffset;
        }
        int velocityX2 = Math.abs(velocityX);
        if (velocityX2 <= singlePageScrollVelocity) {
            snapOffset = 1;
        } else if (velocityX2 >= fullRoundScrollVelocity) {
            snapOffset = SettingUtil.sMaxScrollOffset;
        } else {
            snapOffset = SettingUtil.sMediumScrollOffset;
        }
        if (velocityX2 != 0 && velocityX2 > KEEP_SINKING_VELOCITY && this.mSnapOffset == SettingUtil.sMaxScrollOffset && this.mSinkControl.isSinking() && this.mSinkControl.getSink() > KEEP_SINKING_SINK) {
            snapOffset = this.mSnapOffset;
        }
        return snapOffset;
    }

    @Override // com.htc.launcher.SlideController
    public int getDestinationScreen(int currentTouchScreen, int velocityX) {
        int movementX;
        int originalOffset = getSnapOffset(velocityX);
        int screenX = currentTouchScreen * this.mWorkspace.getWidth();
        if (screenX == 0 && this.mWorkspace.getScrollX() > this.mWorkspace.getWidth()) {
            movementX = (this.mWorkspace.getWidth() * this.mWorkspace.getChildCount()) - this.mWorkspace.getScrollX();
        } else {
            movementX = Math.abs(screenX - this.mWorkspace.getScrollX());
        }
        if (!this.mWorkspace.isPortrait() && movementX > this.mWorkspace.getWidth()) {
            originalOffset++;
        }
        int snapOffset = originalOffset;
        if (SettingUtil.localLOGD) {
            Log.d(LOG_TAG, "getDestinationScreen(" + currentTouchScreen + ", " + velocityX + ") getSnapOffset() = " + snapOffset);
        }
        if (snapOffset > SettingUtil.sWorkspaceScreenCount) {
            snapOffset %= SettingUtil.sWorkspaceScreenCount;
        }
        float sinkExtent = (originalOffset - 1) / (SettingUtil.sMaxScrollOffset - 1);
        this.mSinkControl.startSink(sinkExtent);
        if (originalOffset > 1) {
            this.mWorkspace.beginFling();
        }
        this.mSnapOffset = originalOffset;
        this.mVelocity = velocityX;
        if (velocityX > 0) {
            if (currentTouchScreen - snapOffset < 0) {
                return this.mWorkspace.getChildCount() + (currentTouchScreen - snapOffset);
            }
            return currentTouchScreen - snapOffset;
        }
        if (currentTouchScreen + snapOffset >= this.mWorkspace.getChildCount()) {
            return (currentTouchScreen + snapOffset) % this.mWorkspace.getChildCount();
        }
        return currentTouchScreen + snapOffset;
    }

    @Override // com.htc.launcher.SlideController
    protected int getDeltaXForSnapScreen(int currentScreen, int nextScreen, int velocity) {
        int newX;
        int delta;
        int snapOffset = getSnapOffset(velocity);
        int loop = 0;
        if (snapOffset > SettingUtil.sWorkspaceScreenCount) {
            loop = (snapOffset / SettingUtil.sWorkspaceScreenCount) - 1;
            int i = snapOffset % SettingUtil.sWorkspaceScreenCount;
        }
        if (this.mWorkspace.isPortrait() && !SettingUtil.sMultiPageScrollOnPortrait) {
            if (velocity > 0) {
                newX = nextScreen * this.mWorkspace.getWidth();
                int currentX = this.mWorkspace.getScrollX();
                if (newX < currentX) {
                    delta = newX - currentX;
                } else {
                    delta = (newX - (this.mWorkspace.getChildCount() * this.mWorkspace.getWidth())) - currentX;
                }
            } else if (velocity < 0) {
                newX = nextScreen * this.mWorkspace.getWidth();
                int currentX2 = this.mWorkspace.getScrollX();
                if (newX > currentX2) {
                    delta = newX - currentX2;
                } else {
                    delta = newX + ((this.mWorkspace.getWidth() * this.mWorkspace.getChildCount()) - currentX2);
                }
            } else {
                if (nextScreen == 0) {
                    if (this.mWorkspace.getScrollX() > this.mWorkspace.getWidth() * (this.mWorkspace.getChildCount() - 1)) {
                        newX = this.mWorkspace.getChildCount() * this.mWorkspace.getWidth();
                    } else {
                        newX = nextScreen * this.mWorkspace.getWidth();
                    }
                } else {
                    newX = nextScreen * this.mWorkspace.getWidth();
                }
                delta = newX - this.mWorkspace.getScrollX();
            }
        } else if (velocity > 0) {
            newX = nextScreen * this.mWorkspace.getWidth();
            int currentX3 = this.mWorkspace.getScrollX();
            if (newX < currentX3) {
                delta = newX - currentX3;
            } else {
                delta = (newX - (this.mWorkspace.getChildCount() * this.mWorkspace.getWidth())) - currentX3;
            }
        } else if (velocity < 0) {
            newX = nextScreen * this.mWorkspace.getWidth();
            int currentX4 = this.mWorkspace.getScrollX();
            if (newX > currentX4) {
                delta = newX - currentX4;
            } else {
                delta = newX + ((this.mWorkspace.getWidth() * this.mWorkspace.getChildCount()) - currentX4);
            }
        } else {
            if (nextScreen == 0) {
                if (this.mWorkspace.getScrollX() > this.mWorkspace.getWidth() * (this.mWorkspace.getChildCount() - 2)) {
                    newX = this.mWorkspace.getChildCount() * this.mWorkspace.getWidth();
                } else {
                    newX = nextScreen * this.mWorkspace.getWidth();
                }
            } else {
                newX = nextScreen * this.mWorkspace.getWidth();
            }
            delta = newX - this.mWorkspace.getScrollX();
        }
        if (delta > 0) {
            delta += this.mWorkspace.getWidth() * loop * SettingUtil.sWorkspaceScreenCount;
        } else if (delta < 0) {
            delta -= (this.mWorkspace.getWidth() * loop) * SettingUtil.sWorkspaceScreenCount;
        }
        if (SettingUtil.localLOGD) {
            Log.d(LOG_TAG, "v: " + velocity + ", nx: " + newX + ", x: " + this.mWorkspace.getScrollX() + ", c: " + currentScreen + ", n: " + nextScreen + ", d: " + delta);
        }
        return delta;
    }

    @Override // com.htc.launcher.SlideController
    public float scrollXConverter(float x) {
        if (x < 0.0f) {
            return (this.mWorkspace.getWidth() * this.mWorkspace.getChildCount()) + x;
        }
        return x >= ((float) (this.mWorkspace.getWidth() * this.mWorkspace.getChildCount())) ? x - (this.mWorkspace.getWidth() * this.mWorkspace.getChildCount()) : x;
    }

    @Override // com.htc.launcher.SlideController
    public void snapToDestination() {
        int screenWidth = this.mWorkspace.getWidth();
        int whichScreen = (this.mWorkspace.getScrollX() + (screenWidth / 2)) / screenWidth;
        if (whichScreen >= this.mWorkspace.getChildCount()) {
            whichScreen %= this.mWorkspace.getChildCount();
        }
        this.mSinkControl.startRise();
        snapToScreen(whichScreen, 0);
    }

    @Override // com.htc.launcher.SlideController
    protected void startScrollByVelocityX(int delta, int velocityX) {
        int duration;
        if (SettingUtil.sFixedScrollVelocity) {
            EasingFunction ef = this.mEasingFunction;
            if (this.mWorkspace.isPortrait() && !SettingUtil.sMultiPageScrollOnPortrait) {
                duration = SettingUtil.sFixedScrollDurationPort;
            } else {
                int snapOffset = getSnapOffset(velocityX);
                if (snapOffset >= SettingUtil.sMaxScrollOffset) {
                    duration = this.mWorkspace.isPortrait() ? SettingUtil.sMaxScrollRoundDurationPort : SettingUtil.sMaxScrollRoundDurationLand;
                } else if (snapOffset >= SettingUtil.sMediumScrollOffset) {
                    duration = this.mWorkspace.isPortrait() ? SettingUtil.sMediumScrollRoundDurationPort : SettingUtil.sMediumScrollRoundDurationLand;
                } else {
                    duration = (this.mWorkspace.isPortrait() ? SettingUtil.sFixedScrollDurationPort : SettingUtil.sFixedScrollDurationLand) * snapOffset;
                }
                if (snapOffset > SettingUtil.sMediumScrollOffset) {
                    ef = this.mLongEasingFunction;
                }
                if (SettingUtil.localLOGD) {
                    Log.d(LOG_TAG, "startScrollByVelocityX  velocityX " + velocityX + ", snapOffset: " + snapOffset + ", duration: " + duration + ", ef: " + ef);
                }
            }
            startSlide(this.mWorkspace.getScrollX(), 0, delta, 0, duration, ef);
            return;
        }
        startSlide(this.mWorkspace.getScrollX(), 0, delta, 0, (int) (Math.abs((delta * LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK) / velocityX) * SettingUtil.sEaseOutBackDuration), this.mEasingFunction);
    }

    @Override // com.htc.launcher.SlideController
    public int snapToDefaultScreen(int whichScreen) {
        int deltaScreen;
        this.mWorkspace.beginFling();
        this.mWorkspace.beginScroll(true, whichScreen);
        int whichScreen2 = Math.max(0, Math.min(whichScreen, this.mWorkspace.getChildCount() - 1));
        this.mWorkspace.setNextScreen(whichScreen2);
        int pageCount = SettingUtil.getScreenCount();
        int current = this.mWorkspace.getCurrentScreenIndex();
        if (current > whichScreen2) {
            int left = current - whichScreen2;
            int right = pageCount - left;
            if (left <= right) {
                deltaScreen = -left;
            } else {
                deltaScreen = right;
            }
        } else if (whichScreen2 > current) {
            int right2 = whichScreen2 - current;
            int left2 = pageCount - right2;
            if (left2 <= right2) {
                deltaScreen = -left2;
            } else {
                deltaScreen = right2;
            }
        } else {
            deltaScreen = 0;
        }
        int delta = deltaScreen * this.mWorkspace.getWidth();
        float sinkExtent = (Math.abs(deltaScreen) - 1) / SettingUtil.sWorkspaceScreenCount;
        this.mSinkControl.startSink(sinkExtent);
        int duration = (int) Math.max(Math.abs(delta) * 1.5d * Workspace.sScrollSpeedScale, 640.0d);
        if (SettingUtil.localLOGD) {
            Log.d("Workspace", "snapToScreen Duration = " + duration + ", delta = " + delta + ", mScrollSpeedScale = " + Workspace.sScrollSpeedScale);
        }
        startSlide(this.mWorkspace.getScrollX(), 0, delta, 0, duration, this.mEasingFunction);
        return duration;
    }

    @Override // com.htc.launcher.SlideController
    protected int getCurrentScreenIndexByScrollX() {
        int width = this.mWorkspace.getWidth();
        int child = this.mWorkspace.getChildCount();
        if (width <= 0 || child == 0) {
            return this.mWorkspace.getCurrentScreenIndex();
        }
        int page = (this.mWorkspace.getScrollX() + (width / 2)) / width;
        if (page >= child) {
            page %= child;
        }
        return page;
    }

    @Override // com.htc.launcher.SlideController
    public boolean scrollLeft() {
        if (this.mWorkspace.getNextScreen() == -1 && isSlideFinish()) {
            this.mSinkControl.startSink(0.0f);
            if (this.mWorkspace.getCurrentScreenIndex() > 0) {
                snapToScreen(this.mWorkspace.getCurrentScreenIndex() - 1);
            } else if (this.mWorkspace.getCurrentScreenIndex() == 0) {
                snapToScreen(this.mWorkspace.getChildCount() - 1, 2000);
            }
            return true;
        }
        return false;
    }

    @Override // com.htc.launcher.SlideController
    public boolean scrollRight() {
        if (this.mWorkspace.getNextScreen() != -1 || !isSlideFinish()) {
            return false;
        }
        this.mSinkControl.startSink(0.0f);
        if (this.mWorkspace.getCurrentScreenIndex() < this.mWorkspace.getChildCount() - 1) {
            snapToScreen(this.mWorkspace.getCurrentScreenIndex() + 1);
        } else if (this.mWorkspace.getCurrentScreenIndex() == this.mWorkspace.getChildCount() - 1) {
            snapToScreen(0, -2000);
        }
        return true;
    }

    @Override // com.htc.launcher.SlideController
    protected float getKeepSinkVelocity() {
        return KEEP_SINKING_VELOCITY;
    }

    @Override // com.htc.launcher.SlideController
    protected boolean isSinking() {
        return this.mSinkControl.isSinking() && this.mSinkControl.getSink() > KEEP_SINKING_SINK;
    }

    @Override // com.htc.launcher.SlideController
    protected void onScrollProgress(float progress) {
        this.mSinkControl.setScrollProgress(progress);
    }

    @Override // com.htc.launcher.SlideController
    protected void onScrollEnd() {
        this.mSnapOffset = 0;
        this.mVelocity = 0;
    }
}
