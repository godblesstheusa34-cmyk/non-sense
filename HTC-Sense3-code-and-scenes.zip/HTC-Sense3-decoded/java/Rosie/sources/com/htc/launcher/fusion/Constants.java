package com.htc.launcher.fusion;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public final class Constants {

    static final class IntentAction {
        static final String UPDATE_WIDGET = "com.htc.android.rosie.home.intent.action.UPDATE_WIDGET";
        static final String WIDGET_DISCOVERED = "com.htc.android.rosie.home.intent.action.WIDGET_DISCOVERD";

        IntentAction() {
        }
    }

    private Constants() {
    }
}
