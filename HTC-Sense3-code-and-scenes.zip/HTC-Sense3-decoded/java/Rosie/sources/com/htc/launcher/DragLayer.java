package com.htc.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.SystemClock;
import android.os.Vibrator;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import com.android.common.speech.LoggingEvents;
import com.htc.android.rosie.home.fxcontrol.FxDropTarget;
import com.htc.android.rosie.home.fxcontrol.FxScreen;
import com.htc.launcher.DesktopItemController;
import com.htc.launcher.DragController;
import com.htc.launcher.DragSource;
import com.htc.launcher.settings.PointerLocation;
import com.htc.launcher.settings.SettingUtil;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class DragLayer extends FrameLayout implements DragController, DesktopItemController.FloatingEnv {
    private static final int ANIMATION_SCALE_UP_DURATION = 110;
    private static final int BOUNDARY_OF_DRAGGING = 20;
    private static final int CONTINUOUS_SCROLL_DELAY = 1000;
    private static final int DRAG_SENSITIVITY = 4;
    private static final boolean LOG_DRAW = false;
    private static final String LOG_TAG = "DragLayer";
    private static final int MOVE_DISTANCE = 25;
    private static final boolean PROFILE_DRAWING_DURING_DRAG = false;
    private static final int SCROLL_DELAY = 400;
    private static final int SCROLL_LEFT = 0;
    private static final int SCROLL_OUTSIDE_ZONE = 0;
    private static final int SCROLL_RIGHT = 1;
    private static final int SCROLL_WAITING_IN_ZONE = 1;
    private static final int SCROLL_ZONE = 40;
    private static final int TABLET_LANDSCAPE_SCROLL_ZONE = 150;
    private final int SCROLLCOUNTDOWNSAMPLE_NUM;
    private final int SCROLLCOUNTDOWNSAMPLE_THRESHOLD;
    private Paint debugPaint;
    private Paint debugPaint2;
    private boolean isDragHintShow;
    private boolean isLeftArrowEnable;
    private boolean isRightArrowEnable;
    View[] mBackupChildren;
    private boolean mChangePage;
    private Rect mDirtyRect;
    private DragSource.DragCompletedAction mDragCompletedAction;
    private float mDragControlOffsetX;
    private float mDragControlOffsetY;
    private RectF mDragControlRect;
    private View mDragHint;
    private TextView mDragHintMessage;
    private Draggee mDragItem;
    private DragLeaper mDragLeaper;
    private Paint mDragPaint;
    private RectF mDragRect;
    private RectF mDragRegion;
    private DragScroller mDragScroller;
    private DragSource mDragSource;
    private boolean mDragging;
    private final int[] mDropCoordinates;
    private List<DropTarget> mDropTargets;
    private DropTarget mFolderIconDropTarget;
    private boolean mHitDrag;
    private Rect mHitRect;
    private View mIgnoredDropTarget;
    private boolean mIsInDragRegion;
    private DropTarget mLastDropTarget;
    private float mLastMotionX;
    private float mLastMotionY;
    private Launcher mLauncher;
    private View mLeftKey;
    private List<DragController.DragListener> mListeners;
    private float mMotionDownX;
    private float mMotionDownY;
    private boolean mMovedSinceDragStart;
    private View mOriginator;
    private PointerLocation mPointerLocation;
    private Rect mRect;
    private View mRightKey;
    private final float[] mScrollCountDownSample;
    private int mScrollCountDownSampleIndex;
    private ScrollMonitor mScrollMonitor;
    private ScrollRunnable mScrollRunnable;
    private int mScrollState;
    private boolean mShouldDrop;
    private float mTouchOffsetX;
    private float mTouchOffsetY;
    private final Paint mTrashPaint;
    private final Vibrator mVibrator;
    public static final boolean localLOGD = SettingUtil.localLOGD;
    private static final boolean DEBUG_TOUCH = false;
    private static float DRAG_SCALE = 24.0f;

    /* JADX WARN: Multi-variable type inference failed */
    public DragLayer(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mDragging = false;
        this.mChangePage = false;
        this.mDragItem = null;
        this.mDropTargets = new ArrayList();
        this.mDragRect = new RectF();
        this.mHitRect = new Rect();
        this.mDirtyRect = new Rect();
        this.mDropCoordinates = new int[2];
        this.mVibrator = new Vibrator();
        this.mMotionDownX = 0.0f;
        this.mMotionDownY = 0.0f;
        this.mHitDrag = false;
        this.mMovedSinceDragStart = true;
        this.mScrollState = 0;
        this.mScrollRunnable = new ScrollRunnable();
        this.mTrashPaint = new Paint();
        this.SCROLLCOUNTDOWNSAMPLE_NUM = 5;
        this.SCROLLCOUNTDOWNSAMPLE_THRESHOLD = 12;
        this.mScrollCountDownSample = new float[5];
        this.mScrollCountDownSampleIndex = 0;
        this.isLeftArrowEnable = false;
        this.isRightArrowEnable = false;
        this.mBackupChildren = null;
        this.mRect = null;
        this.mLauncher = (Launcher) context;
        int srcColor = context.getResources().getColor(R.color.delete_color_filter);
        DRAG_SCALE = context.getResources().getInteger(R.integer.drag_scale);
        this.mTrashPaint.setColorFilter(new PorterDuffColorFilter(srcColor, PorterDuff.Mode.SRC_ATOP));
        if (SettingUtil.isTabletDevice()) {
            resetScrollCountDownSample();
        }
        initButtonBarArea();
    }

    private void offsetDescendantRectToMyCoords(RectF r) {
        int padding;
        if (getResources().getConfiguration().orientation == 2) {
            padding = getResources().getDimensionPixelSize(R.dimen.workspace_screen_cl_long_axis_start_padding);
        } else {
            padding = getResources().getDimensionPixelSize(R.dimen.workspace_screen_cl_short_axis_start_padding);
        }
        r.left += padding;
        r.right += padding;
    }

    @Override // com.htc.launcher.DragController
    public void prepareDrag(Draggee dragItem, DragSource source, Object dragInfo, int dragAction) {
        if (this.mListeners != null) {
            for (DragController.DragListener listener : this.mListeners) {
                listener.onPreDragStart(dragItem, source, dragInfo, dragAction);
            }
        }
    }

    @Override // com.htc.launcher.DragController
    public void startDrag(Draggee dragItem, DragSource source, Object dragInfo, int dragAction) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DragLayer.startDrag() source:" + source);
        RectF r = this.mDragRect;
        r.set(dragItem.getRectInPixels());
        this.mTouchOffsetX = this.mMotionDownX - r.left;
        this.mTouchOffsetY = this.mMotionDownY - r.top;
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DragLayer.startDrag() fakeTouchDown() source:" + source);
        this.mDragItem = dragItem;
        RectF controlRect = new RectF(r);
        this.mDragControlOffsetX = (controlRect.width() - r.width()) / 2.0f;
        this.mDragControlOffsetY = (controlRect.height() - r.height()) / 2.0f;
        initDragControlRect((this.mScrollX + r.left) - this.mDragControlOffsetX, (this.mScrollY + r.top) - this.mDragControlOffsetY, r.width(), r.height());
        if (this.mListeners != null) {
            for (DragController.DragListener listener : this.mListeners) {
                listener.onPostDragStart(dragItem, source, dragInfo, dragAction);
            }
        }
        this.mDragPaint = null;
        this.mDragging = true;
        this.mShouldDrop = true;
        this.mDragSource = source;
        this.mMovedSinceDragStart = false;
        this.mIsInDragRegion = false;
        this.mHitDrag = true;
        if ((source instanceof Workspace) || (source instanceof AllAppsView)) {
            int[] coordinates = this.mDropCoordinates;
            DropTarget dropTarget = findDropTarget((int) this.mLastMotionX, (int) this.mLastMotionY, coordinates);
            if (dropTarget != null) {
                dropTarget.onDragEnter(this.mDragSource, coordinates[0], coordinates[1], (int) this.mTouchOffsetX, (int) this.mTouchOffsetY, this.mDragItem);
            }
        }
        invalidate();
        this.mDragItem.getItem();
        this.mVibrator.vibrate(35L);
        fakeTouchMove();
    }

    private void fakeTouchDown() {
        long time = SystemClock.uptimeMillis();
        this.mLauncher.mFxWorkspace.onTouch(this, MotionEvent.obtain(time, time, 0, this.mLastMotionX, this.mLastMotionY, 0));
    }

    private void fakeTouchMove() {
        long time = SystemClock.uptimeMillis();
        this.mLauncher.mFxWorkspace.onTouch(this, MotionEvent.obtain(time, time, 2, this.mLastMotionX, this.mLastMotionY, 0));
    }

    private void initDragControlRect(float x, float y, float w, float h) {
        if (this.mDragControlRect == null) {
            this.mDragControlRect = new RectF();
        }
        this.mDragControlRect.set(x, y, x + w, y + h);
    }

    @Override // com.htc.launcher.DesktopItemController.FloatingEnv
    public boolean onFloat(Draggee item, RectF pos) {
        int l;
        int t;
        int r;
        int b;
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DragLayer.onFloat()");
        ItemInfo info = item.getItemInfo();
        View view = (View) item.getItem();
        int[] wh = new int[2];
        this.mLauncher.getWorkspace().getWidthHeightForSpan(info.spanX, info.spanY, wh);
        if (view.getLayoutParams() == null) {
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2);
            lp.gravity = 17;
            view.setLayoutParams(lp);
        }
        if (view.getParent() == null) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] DragLayer.onFloat() View's parent is null, addView()!!");
        } else {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] DragLayer.onFloat() View's parent != null");
        }
        measureChildWithMargins(view, View.MeasureSpec.makeMeasureSpec(wh[0], 1073741824), 0, View.MeasureSpec.makeMeasureSpec(wh[1], 1073741824), 0);
        if (pos != null) {
            l = (int) pos.left;
            t = (int) pos.top;
            r = (int) pos.right;
            b = (int) pos.bottom;
        } else {
            int r2 = view.getMeasuredWidth();
            int b2 = view.getMeasuredHeight();
            l = (getWidth() - r2) / 2;
            t = (getHeight() - b2) / 2;
            r = r2 + l;
            b = b2 + t;
        }
        view.layout(l, t, r, b);
        if (!view.isDrawingCacheEnabled()) {
            view.setDrawingCacheEnabled(true);
        }
        if (info.itemType == 0 || info.itemType == 1) {
            this.mLauncher.getWorkspace().closeAllOpenLiveFolder();
        } else {
            this.mLauncher.getWorkspace().closeAllOpenFolder();
        }
        initDragControlRect(l, t, r - l, b - t);
        view.buildDrawingCache();
        return true;
    }

    @Override // com.htc.launcher.DesktopItemController.FloatingEnv
    public boolean onLand(Draggee item, int container, int x, int y) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DragLayer.onLand()");
        return onPoof(item);
    }

    @Override // com.htc.launcher.DesktopItemController.FloatingEnv
    public boolean onPoof(Draggee item) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DragLayer.onPoof()");
        if (item == null) {
            return false;
        }
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DragLayer.onPoof() ItemInfo:" + item.getItemInfo());
        if ((item.getItemInfo() instanceof FxItemInfo) || (item.getItemInfo() instanceof FxShortcutInfo)) {
            return true;
        }
        View view = (View) item.getItem();
        if (view == null || view.getParent() != this) {
            return false;
        }
        removeView(view);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchKeyEvent(KeyEvent event) {
        return this.mDragging || super.dispatchKeyEvent(event);
    }

    private boolean[][] getOccupiedBitmap() {
        FxScreen screen = this.mLauncher.getFxWorkspace().getScreen(this.mLauncher.getWorkspace().getCurrentScreenIndex());
        return screen.getOccupiedCells();
    }

    private void showGrid(Canvas canvas) {
        if (this.debugPaint == null) {
            this.debugPaint = new Paint();
            this.debugPaint.setColor(-16711681);
            this.debugPaint.setStrokeWidth(4.0f);
            this.debugPaint.setStyle(Paint.Style.STROKE);
        }
        if (this.debugPaint2 == null) {
            this.debugPaint2 = new Paint();
            this.debugPaint2.setColor(-65536);
            this.debugPaint2.setStrokeWidth(2.0f);
            this.debugPaint2.setStyle(Paint.Style.STROKE);
        }
        if (this.mRect != null) {
            canvas.drawRect(this.mRect, this.debugPaint);
        }
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                Rect rect = new Rect();
                rect.left = i * TABLET_LANDSCAPE_SCROLL_ZONE;
                rect.top = j * 235;
                rect.right = rect.left + TABLET_LANDSCAPE_SCROLL_ZONE;
                rect.bottom = rect.top + 235;
                canvas.drawRect(rect, this.debugPaint);
                if (getOccupiedBitmap()[i][j]) {
                    canvas.drawText("0", rect.left + (TABLET_LANDSCAPE_SCROLL_ZONE / 2), rect.top + (TABLET_LANDSCAPE_SCROLL_ZONE / 2), this.debugPaint);
                } else {
                    canvas.drawText("x", rect.left + (TABLET_LANDSCAPE_SCROLL_ZONE / 2), rect.top + (235 / 2), this.debugPaint2);
                }
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void dispatchDraw(Canvas canvas) {
        Logger.d("FolderIcon", "[EDIT_DEBUG] FolderIcon - DragLayer.dispatchDraw()");
        this.mScrollMonitor.startDispatchDraw();
        if (this.mDragging && this.mDragItem != null) {
            drawChild(canvas, this.mDragHint, getDrawingTime());
            Object obj = this.mDragItem.getItem();
            if (obj instanceof View) {
                drawChild(canvas, (View) obj, getDrawingTime());
            }
        } else {
            super.dispatchDraw(canvas);
        }
        if (this.mLastDropTarget != null && this.mFolderIconDropTarget != null && this.mFolderIconDropTarget != this.mLastDropTarget) {
            if (this.mLastDropTarget instanceof FolderIcon) {
                this.mFolderIconDropTarget = this.mLastDropTarget;
            } else {
                this.mFolderIconDropTarget = null;
            }
        }
        if (SettingUtil.sIsEnablePointerLocation && this.mPointerLocation != null) {
            this.mPointerLocation.DrawPointerLocation(canvas);
        }
        this.mScrollMonitor.endDispatchDraw();
    }

    void abortDrag() {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DragLayer.abortDrag()");
        if (this.mShouldDrop) {
            this.mShouldDrop = false;
            endDrag();
            this.mDragSource.onDropCompleted(null, false);
        }
    }

    private void endDrag() {
        Logger.d(LOG_TAG, "[EDIT_DEBUG]# DragLayer.endDrag() mDragging:" + this.mDragging);
        if (this.mDragging) {
            this.mDragControlRect = null;
            this.mDragging = false;
            if (this.mDragItem != null) {
                this.mDragItem = null;
            }
            if (this.mOriginator != null) {
                this.mOriginator.setVisibility(0);
                this.mOriginator = null;
            }
            if (this.mListeners != null) {
                for (DragController.DragListener listener : this.mListeners) {
                    listener.onDragEnd();
                }
            }
        }
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        int action = ev.getAction();
        float x = ev.getX();
        float y = ev.getY();
        switch (action) {
            case 0:
                this.mMotionDownX = x;
                this.mLastMotionX = x;
                this.mMotionDownY = y;
                this.mLastMotionY = y;
                this.mLauncher.mFxWorkspace.updateMotionDown(x, y);
                this.mLastDropTarget = null;
                break;
            case 1:
                boolean isDropOk = drop(x, y);
                if (this.mShouldDrop && isDropOk) {
                    this.mShouldDrop = false;
                    Logger.d(LOG_TAG, "[EDIT_DEBUG]# DragLayer.onInterceptTouchEvent().MotionEvent.UP endDrag()");
                    endDrag();
                    break;
                }
                break;
            case 3:
                abortDrag();
                break;
        }
        return this.mDragging;
    }

    private boolean isInRegion(DropTarget dropTarget) {
        if (this.mDragRegion == null) {
            return false;
        }
        return dropTarget instanceof FxDropTarget;
    }

    private void filterOutOfScreenEvent(MotionEvent ev) {
        if (localLOGD) {
            int edgeFlags = ev.getEdgeFlags();
            if ((edgeFlags & 1) == 1) {
                Log.w(LOG_TAG, "touch event above screen top");
            } else if ((edgeFlags & 2) == 2) {
                Log.w(LOG_TAG, "touch event below screen bottom");
            }
        }
        float x = ev.getX();
        float y = ev.getY();
        float top = this.mDragHint == null ? 0.0f : this.mDragHint.getHeight();
        float bottom = getMeasuredHeight();
        if (y < top) {
            Log.w(LOG_TAG, "touch outside screen: " + x + "," + y);
            ev.setLocation(x, top);
        }
        if (y > bottom) {
            Log.w(LOG_TAG, "touch outside screen: " + x + "," + y);
            ev.setLocation(x, bottom);
        }
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent ev) {
        if (!this.mDragging) {
            return false;
        }
        if (ev.getPointerCount() > 1 || (ev.getPointerCount() == 1 && ev.getPointerId(0) != 0)) {
            if (localLOGD) {
                Log.d(LOG_TAG, "multiple touch detected, ignore");
            }
            return false;
        }
        filterOutOfScreenEvent(ev);
        int action = ev.getAction();
        float x = ev.getX();
        float y = ev.getY();
        switch (action) {
            case 0:
                this.mLastMotionX = x;
                this.mMotionDownX = x;
                this.mLastMotionY = y;
                this.mMotionDownY = y;
                this.mChangePage = false;
                this.mScrollState = isInScrollZone(x);
                this.mTouchOffsetX = x - this.mDragControlRect.left;
                this.mTouchOffsetY = y - this.mDragControlRect.top;
                this.mHitDrag = isTouchOnDragControl(x, y);
                break;
            case 1:
                if (!this.mHitDrag) {
                    float diffX = x - this.mMotionDownX;
                    float diffY = y - this.mMotionDownY;
                    if (Math.abs(diffX) > Math.abs(diffY)) {
                        if ((-diffX) > 25.0f) {
                            this.mDragScroller.scrollRight();
                        } else if (diffX > 25.0f) {
                            this.mDragScroller.scrollLeft();
                        }
                    }
                    return true;
                }
                removeCallbacks(this.mScrollRunnable);
                if (this.mShouldDrop && this.mHitDrag) {
                    Logger.d(LOG_TAG, "[EDIT_DEBUG] DragLayer.onTouchEvent().MotionEvent.UP drop(" + x + "," + y + ") DragSource:" + this.mDragSource);
                    boolean isDrag = drop(x, y);
                    Logger.d(LOG_TAG, "[EDIT_DEBUG] DragLayer.onTouchEvent().MotionEvent.UP drop(" + x + "," + y + ")=" + isDrag + " mMovedSinceDragStart:" + this.mMovedSinceDragStart);
                    if (isDrag || (!this.mMovedSinceDragStart && this.mDragSource == this.mLauncher.getWorkspace())) {
                        this.mShouldDrop = false;
                        Logger.d(LOG_TAG, "[EDIT_DEBUG] DragLayer.onTouchEvent().MotionEvent.UP drop() endDrag()");
                        endDrag();
                        if (!this.mMovedSinceDragStart) {
                            this.mDragSource.onDropCompleted(null, false);
                        }
                    } else {
                        Logger.d(LOG_TAG, "[EDIT_DEBUG] DragLayer.onTouchEvent().MotionEvent.UP drop() else");
                    }
                    return true;
                }
                break;
            case 2:
                if (this.mHitDrag) {
                    this.mMovedSinceDragStart = true;
                    float dx = x - this.mLastMotionX;
                    float dy = y - this.mLastMotionY;
                    this.mLastMotionX = x;
                    this.mLastMotionY = y;
                    float left = limitDragMoveX(this.mDragControlRect.left + dx);
                    float top = limitDragMoveY(this.mDragControlRect.top + dy);
                    if (left != this.mDragControlRect.left + dx || top != this.mDragControlRect.top + dy) {
                        return true;
                    }
                    this.mTouchOffsetX = x - left;
                    this.mTouchOffsetY = y - top;
                    Rect rect = this.mDirtyRect;
                    rect.set((int) this.mDragControlRect.left, (int) this.mDragControlRect.top, (int) this.mDragControlRect.right, (int) this.mDragControlRect.bottom);
                    this.mDragControlRect.offsetTo(left, top);
                    rect.union((int) (this.mDragControlRect.left - 1.0f), (int) (this.mDragControlRect.top - 1.0f), (int) (this.mDragControlRect.right + 1.0f), (int) (this.mDragControlRect.bottom + 1.0f));
                    int[] coordinates = this.mDropCoordinates;
                    DropTarget dropTarget = findDropTarget((int) x, (int) y, coordinates);
                    fireDropEvent(dropTarget, coordinates);
                    if (dropTarget != null && (dropTarget instanceof FolderIcon) && this.mFolderIconDropTarget == null) {
                        this.mFolderIconDropTarget = dropTarget;
                    }
                    this.mLastDropTarget = dropTarget;
                    boolean wasInDragRegion = this.mIsInDragRegion;
                    this.mIsInDragRegion = isInRegion(dropTarget);
                    if (!wasInDragRegion && this.mIsInDragRegion) {
                        this.mDragPaint = this.mTrashPaint;
                    } else if (wasInDragRegion && !this.mIsInDragRegion) {
                        this.mDragPaint = null;
                    }
                    if (this.mIsInDragRegion) {
                        cancelScrollCountDown();
                        break;
                    } else {
                        startScrollCountDownIfNeeded(x);
                        break;
                    }
                }
                break;
            case 3:
                abortDrag();
                break;
        }
        if (!this.mHitDrag) {
            return true;
        }
        this.mLauncher.mFxWorkspace.onTouch(this, ev);
        return true;
    }

    private boolean isTouchOnDragControl(float x, float y) {
        int dragItemleft = (int) this.mDragControlRect.left;
        int dragItemtop = (int) this.mDragControlRect.top;
        if (x < dragItemleft || x > dragItemleft + this.mDragControlRect.width() || y < dragItemtop || y > dragItemtop + this.mDragControlRect.height()) {
            return false;
        }
        return true;
    }

    private float limitDragMoveX(float left) {
        int width = (int) this.mDragControlRect.width();
        if (left < 20 - ((width * 3) / 4)) {
            left = 20 - ((width * 3) / 4);
        }
        if (width + left > (getWidth() + ((width * 3) / 4)) - 20) {
            return ((getWidth() + ((width * 3) / 4)) - width) - 20;
        }
        return left;
    }

    private float limitDragMoveY(float top) {
        int height = (int) this.mDragControlRect.height();
        int dragHintHeight = this.mDragHint == null ? 50 : this.mDragHint.getHeight();
        if (top < (dragHintHeight + 20) - ((height * 3) / 4)) {
            Log.e(LOG_TAG, "limit Y top");
            top = (dragHintHeight + 20) - ((height * 3) / 4);
        }
        if (height + top > getHeight() + ((height * 3) / 4)) {
            Log.e(LOG_TAG, "limit Y bottom");
            return (getHeight() + ((height * 3) / 4)) - height;
        }
        return top;
    }

    private void fireDropEvent(DropTarget target, int[] coordinates) {
        if (target != null) {
            if (this.mLastDropTarget == target) {
                target.onDragOver(this.mDragSource, coordinates[0], coordinates[1], (int) this.mTouchOffsetX, (int) this.mTouchOffsetY, this.mDragItem);
                return;
            }
            if (this.mLastDropTarget != null) {
                this.mLastDropTarget.onDragExit(this.mDragSource, target, coordinates[0], coordinates[1], (int) this.mTouchOffsetX, (int) this.mTouchOffsetY, this.mDragItem);
            }
            target.onDragEnter(this.mDragSource, coordinates[0], coordinates[1], (int) this.mTouchOffsetX, (int) this.mTouchOffsetY, this.mDragItem);
            return;
        }
        if (this.mLastDropTarget != null) {
            this.mLastDropTarget.onDragExit(this.mDragSource, target, coordinates[0], coordinates[1], (int) this.mTouchOffsetX, (int) this.mTouchOffsetY, this.mDragItem);
        }
    }

    private int getScrollZone() {
        return (getResources().getConfiguration().orientation == 2 && SettingUtil.isTabletDevice()) ? TABLET_LANDSCAPE_SCROLL_ZONE : SCROLL_ZONE;
    }

    private int isInScrollZone(float x) {
        int iScrollZone = getScrollZone();
        return (x < ((float) iScrollZone) || x > ((float) (getWidth() - iScrollZone))) ? 1 : 0;
    }

    private void resetScrollCountDownSample() {
        for (int i = 0; i < this.mScrollCountDownSample.length; i++) {
            this.mScrollCountDownSample[i] = -1.0f;
        }
        this.mScrollCountDownSampleIndex = 0;
    }

    private void logScrollCountDownX(float x) {
        this.mScrollCountDownSample[this.mScrollCountDownSampleIndex] = x;
        this.mScrollCountDownSampleIndex++;
        if (this.mScrollCountDownSampleIndex >= this.mScrollCountDownSample.length) {
            this.mScrollCountDownSampleIndex = 0;
        }
    }

    private void startScrollCountDownIfNeededForTablet(float x) {
        int iScrollZone = getScrollZone();
        float iDragSensitivity = 4.0f;
        float rectWidth = this.mDragControlRect.right - this.mDragControlRect.left;
        if (rectWidth >= getWidth() / 2) {
            iDragSensitivity = 4.0f - 2.0f;
        } else if (rectWidth < getWidth() / 3) {
            iDragSensitivity = (float) (4.0f + 0.5d);
        }
        if (iDragSensitivity <= 1.0f) {
            Logger.w(LOG_TAG, "iDragSensitivity <= 1, set drag sensitivity as default");
            iDragSensitivity = 4.0f;
        }
        if (x < iScrollZone || (this.mDragControlRect != null && ((this.mDragControlRect.left * (iDragSensitivity - 1.0f)) + this.mDragControlRect.right) / iDragSensitivity < 0.0f)) {
            boolean bCancel = false;
            for (int i = 0; i < this.mScrollCountDownSample.length; i++) {
                if (this.mScrollCountDownSample[i] != -1.0f && x - this.mScrollCountDownSample[i] > 12.0f) {
                    bCancel = true;
                }
            }
            if (true == bCancel) {
                Logger.d(LOG_TAG, "cancelScrollCountDown when detect user moving right to scroll zone");
                this.mScrollState = 1;
                cancelScrollCountDown();
                return;
            }
            logScrollCountDownX(x);
            if (this.mScrollState == 0) {
                this.mScrollState = 1;
                this.mScrollRunnable.setDirection(0);
                postDelayed(this.mScrollRunnable, this.mChangePage ? 1000L : 400L);
                this.mChangePage = true;
            }
            if (this.mDragScroller instanceof Workspace) {
                ((Workspace) this.mDragScroller).enableShowVacantRect(false);
                return;
            }
            return;
        }
        if (x > getWidth() - iScrollZone || (this.mDragControlRect != null && (this.mDragControlRect.left + (this.mDragControlRect.right * (iDragSensitivity - 1.0f))) / iDragSensitivity > getWidth())) {
            boolean bCancel2 = false;
            for (int i2 = 0; i2 < this.mScrollCountDownSample.length; i2++) {
                if (this.mScrollCountDownSample[i2] != -1.0f && this.mScrollCountDownSample[i2] - x > 12.0f) {
                    bCancel2 = true;
                }
            }
            if (true == bCancel2) {
                Logger.d(LOG_TAG, "cancelScrollCountDown when detect user moving left to scroll zone");
                this.mScrollState = 1;
                cancelScrollCountDown();
                return;
            }
            logScrollCountDownX(x);
            if (this.mScrollState == 0) {
                this.mScrollState = 1;
                this.mScrollRunnable.setDirection(1);
                postDelayed(this.mScrollRunnable, this.mChangePage ? 1000L : 400L);
                this.mChangePage = true;
            }
            if (this.mDragScroller instanceof Workspace) {
                ((Workspace) this.mDragScroller).enableShowVacantRect(false);
                return;
            }
            return;
        }
        cancelScrollCountDown();
    }

    private void startScrollCountDownIfNeeded(float x) {
        if (SettingUtil.isTabletDevice()) {
            startScrollCountDownIfNeededForTablet(x);
            return;
        }
        int iScrollZone = getScrollZone();
        if (x < iScrollZone || (this.mDragControlRect != null && ((this.mDragControlRect.left * 3.0f) + this.mDragControlRect.right) / 4.0f < 0.0f)) {
            if (this.mScrollState == 0) {
                this.mScrollState = 1;
                this.mScrollRunnable.setDirection(0);
                postDelayed(this.mScrollRunnable, this.mChangePage ? 1000L : 400L);
                this.mChangePage = true;
            }
            if (this.mDragScroller instanceof Workspace) {
                ((Workspace) this.mDragScroller).enableShowVacantRect(false);
                return;
            }
            return;
        }
        if (x > getWidth() - iScrollZone || (this.mDragControlRect != null && (this.mDragControlRect.left + (this.mDragControlRect.right * 3.0f)) / 4.0f > getWidth())) {
            if (this.mScrollState == 0) {
                this.mScrollState = 1;
                this.mScrollRunnable.setDirection(1);
                postDelayed(this.mScrollRunnable, this.mChangePage ? 1000L : 400L);
                this.mChangePage = true;
            }
            if (this.mDragScroller instanceof Workspace) {
                ((Workspace) this.mDragScroller).enableShowVacantRect(false);
                return;
            }
            return;
        }
        cancelScrollCountDown();
    }

    private void cancelScrollCountDown() {
        if (this.mScrollState == 1) {
            this.mScrollState = 0;
            this.mScrollRunnable.setDirection(1);
            removeCallbacks(this.mScrollRunnable);
            this.mChangePage = false;
        }
        if (this.mDragScroller instanceof Workspace) {
            ((Workspace) this.mDragScroller).enableShowVacantRect(true);
        }
        if (SettingUtil.isTabletDevice()) {
            resetScrollCountDownSample();
        }
    }

    @Override // com.htc.launcher.DragController
    public void setDragCompleteAction(DragSource.DragCompletedAction action) {
        this.mDragCompletedAction = action;
    }

    @Override // com.htc.launcher.DragController
    public DragSource.DragCompletedAction getDragCompleteAction() {
        return this.mDragCompletedAction;
    }

    void setDragColor(int color) {
        if (color == 0) {
            this.mTrashPaint.setColorFilter(new PorterDuffColorFilter(0, PorterDuff.Mode.SRC_ATOP));
        } else {
            int srcColor = this.mLauncher.getResources().getColor(color);
            this.mTrashPaint.setColorFilter(new PorterDuffColorFilter(srcColor, PorterDuff.Mode.SRC_ATOP));
        }
    }

    private boolean drop(float x, float y) {
        if (this.mDragItem == null) {
            return false;
        }
        invalidate();
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DragLayer.drop(" + x + "," + y + ") - enter");
        int[] coordinates = this.mDropCoordinates;
        DropTarget dropTarget = findDropTarget((int) x, (int) y, coordinates);
        if (dropTarget != null) {
            this.mDragItem.getItemInfo();
            dropTarget.onDragExit(this.mDragSource, dropTarget, coordinates[0], coordinates[1], (int) this.mTouchOffsetX, (int) this.mTouchOffsetY, this.mDragItem);
            if (dropTarget.acceptDrop(this.mDragSource, coordinates[0], coordinates[1], (int) this.mTouchOffsetX, (int) this.mTouchOffsetY, this.mDragItem)) {
                this.mLauncher.getDesktopItemController().pauseRenderring();
                Logger.d(LOG_TAG, "[EDIT_DEBUG] DragLayer.drop() - dropTarget.onDrop()");
                dropTarget.onDrop(this.mDragSource, coordinates[0], coordinates[1], (int) this.mTouchOffsetX, (int) this.mTouchOffsetY, this.mDragItem);
                Logger.d(LOG_TAG, "[EDIT_DEBUG] DragLayer.drop() - mDragSource.onDropCompleted(true)");
                this.mDragSource.onDropCompleted(dropTarget, true);
                this.mDragCompletedAction = DragSource.DragCompletedAction.NONE;
                if (!this.mLauncher.getDesktopItemController().IS_EXTERNAL_APP_ADDING) {
                    this.mLauncher.getDesktopItemController().resumeRenderring();
                }
                return true;
            }
            if (dropTarget.getClass().equals(FolderIcon.class)) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG] DragLayer.drop() - mDragSource.onDropCompleted(false)");
                this.mDragSource.onDropCompleted(dropTarget, false);
                return true;
            }
        }
        this.mDragCompletedAction = DragSource.DragCompletedAction.NONE;
        if (!this.mLauncher.getDesktopItemController().IS_EXTERNAL_APP_ADDING) {
            this.mLauncher.getDesktopItemController().resumeRenderring();
        }
        return false;
    }

    private boolean isDragOverRegion(DropTarget target) {
        if (!isInRegion(target) || this.mDragControlRect == null) {
            return false;
        }
        if (getResources().getConfiguration().orientation == 1) {
            int threadshold = ((int) (this.mDragControlRect.top + (this.mDragControlRect.bottom * 3.0f))) / 4;
            if (threadshold <= target.getTop()) {
                return false;
            }
            return true;
        }
        int threadshold2 = ((int) (this.mDragControlRect.left + (this.mDragControlRect.right * 3.0f))) / 4;
        if (threadshold2 <= target.getLeft()) {
            return false;
        }
        return true;
    }

    private DropTarget findDropTarget(int x, int y, int[] dropCoordinates) {
        Rect r = this.mHitRect;
        List<DropTarget> dropTargets = this.mDropTargets;
        int count = dropTargets.size();
        for (int i = count - 1; i >= 0; i--) {
            DropTarget target = dropTargets.get(i);
            if (target.claimDrop(x, y, dropCoordinates)) {
                return target;
            }
            if ((target instanceof Workspace) && isButtonBarAreaContains(x, y)) {
                return null;
            }
            target.getHitRect(r);
            target.getLocationOnScreen(dropCoordinates);
            r.offset(dropCoordinates[0] - target.getLeft(), dropCoordinates[1] - target.getTop());
            if (y == getMeasuredHeight()) {
                y--;
            }
            if (r.contains(x, y)) {
                dropCoordinates[0] = x - dropCoordinates[0];
                dropCoordinates[1] = y - dropCoordinates[1];
                if ((target instanceof Workspace) || this.mDragSource == null || this.mDragItem == null) {
                    return target;
                }
                if (target.acceptDrop(this.mDragSource, dropCoordinates[0], dropCoordinates[1], (int) this.mTouchOffsetX, (int) this.mTouchOffsetY, this.mDragItem)) {
                    Logger.d(LOG_TAG, "accept-->x:" + x + " y:" + y + " rect:" + r);
                    return target;
                }
            }
        }
        return null;
    }

    public void setDragScoller(DragScroller scroller) {
        this.mDragScroller = scroller;
    }

    public void setDragLeaper(DragLeaper leaper) {
        this.mDragLeaper = leaper;
    }

    @Override // com.htc.launcher.DragController
    public void setDragListener(DragController.DragListener l) {
        if (this.mListeners == null) {
            this.mListeners = new ArrayList();
        }
        if (!this.mListeners.contains(l)) {
            this.mListeners.add(l);
        }
    }

    @Override // com.htc.launcher.DragController
    public void removeDragListener(DragController.DragListener l) {
        if (this.mListeners != null) {
            this.mListeners.remove(l);
        }
    }

    public void addDropTarget(DropTarget target) {
        Logger.d(LoggingEvents.EXTRA_CALLING_APP_NAME, "[EDIT_DEBUG] addDropTarget[" + this.mDropTargets.size() + "]=" + target);
        this.mDropTargets.add(target);
    }

    public void removeDropTarget(DropTarget target) {
        this.mDropTargets.remove(target);
    }

    void setIgnoredDropTarget(View view) {
        this.mIgnoredDropTarget = view;
    }

    void setDeleteRegion(RectF region) {
        this.mDragRegion = region;
    }

    private class ScrollRunnable implements Runnable {
        private int mDirection;

        ScrollRunnable() {
        }

        @Override // java.lang.Runnable
        public void run() {
            if (DragLayer.this.mDragScroller != null) {
                if (this.mDirection == 0) {
                    DragLayer.this.mDragScroller.scrollLeft();
                } else {
                    DragLayer.this.mDragScroller.scrollRight();
                }
                DragLayer.this.mScrollState = 0;
            }
        }

        void setDirection(int direction) {
            this.mDirection = direction;
        }
    }

    public void showDragHint(boolean show) {
        this.isDragHintShow = show;
        if (show) {
            this.mDragHint.setVisibility(0);
            this.mDragHint.setDrawingCacheEnabled(true);
            return;
        }
        this.mDragHint.setVisibility(8);
        this.mDragHint.setDrawingCacheEnabled(false);
        this.isLeftArrowEnable = false;
        this.isRightArrowEnable = false;
        setLeftArrowEnable(false);
        setRightArrowEnable(false);
    }

    public void setLeftArrowEnable(boolean enable) {
        if (enable) {
            this.isLeftArrowEnable = true;
            ((ImageView) this.mLeftKey).setVisibility(0);
        } else {
            this.isLeftArrowEnable = false;
            ((ImageView) this.mLeftKey).setVisibility(4);
        }
    }

    public void setRightArrowEnable(boolean enable) {
        if (enable) {
            this.isRightArrowEnable = true;
            ((ImageView) this.mRightKey).setVisibility(0);
        } else {
            this.isRightArrowEnable = false;
            ((ImageView) this.mRightKey).setVisibility(4);
        }
    }

    public boolean isDragging() {
        return this.mDragging;
    }

    public void setDragHintMessage(int resid) {
        if (this.mDragHintMessage != null) {
            this.mDragHintMessage.setText(resid);
        }
    }

    public void setDragHintBackground(int resid) {
        this.mDragHint.setBackgroundResource(resid);
    }

    void initialDragHint() {
        this.mDragHint = findViewById(R.id.drag_hint_area);
        this.mLeftKey = this.mDragHint.findViewById(R.id.left_arrow);
        this.mRightKey = this.mDragHint.findViewById(R.id.right_arrow);
        this.mDragHintMessage = (TextView) this.mDragHint.findViewById(R.id.message);
    }

    public void setScrollMonitor(ScrollMonitor scrollMonitor) {
        this.mScrollMonitor = scrollMonitor;
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (SettingUtil.sIsEnablePointerLocation) {
            if (this.mPointerLocation == null) {
                this.mPointerLocation = new PointerLocation(getWidth(), getHeight());
            }
            this.mPointerLocation.PointerLocationTouchEvent(ev);
        }
        int action = ev.getAction();
        if (DEBUG_TOUCH) {
            if (action == 0) {
                Log.d(LOG_TAG, "touch event action ACTION_DOWN");
            } else if (action == 1) {
                Log.d(LOG_TAG, "touch event action ACTION_UP");
            } else if (action == 3) {
                Log.d(LOG_TAG, "touch event action ACTION_CANCEL");
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    public void tempRemoveChildren() {
        int count = getChildCount();
        this.mBackupChildren = new View[count];
        boolean[] removeViews = new boolean[count];
        for (int i = 0; i < count; i++) {
            View child = getChildAt(i);
            if (child == this.mLauncher.mWorkspace) {
                removeViews[i] = true;
            } else if (child == this.mLauncher.mDrawer) {
                removeViews[i] = true;
            } else if (child == this.mLauncher.mFxWorkspace) {
                removeViews[i] = false;
            } else {
                this.mBackupChildren[i] = child;
                removeViews[i] = true;
            }
        }
        for (int i2 = count - 1; i2 >= 0; i2--) {
            if (removeViews[i2]) {
                removeViewAt(i2);
            }
        }
        addView(this.mLauncher.mWorkspace);
        addView(this.mLauncher.mDrawer);
        this.mLauncher.mWorkspace.tempRemoveChildren();
    }

    public void restoreRemovedChildren() {
        if (this.mBackupChildren != null) {
            for (int i = 0; i < this.mBackupChildren.length; i++) {
                if (this.mBackupChildren[i] != null) {
                    View child = this.mBackupChildren[i];
                    if (child == this.mLauncher.mFxWorkspace) {
                        addView(child, 0);
                    } else if (child == this.mLauncher.mBottomBarArea) {
                        addView(child, 2);
                    } else {
                        addView(child);
                    }
                }
            }
            this.mBackupChildren = null;
        }
    }

    private void initButtonBarArea() {
        if (this.mRect == null && this.mLauncher != null) {
            this.mRect = new Rect();
            this.mRect.left = this.mLauncher.getResources().getDimensionPixelSize(R.dimen.button_bar_area_left);
            this.mRect.right = this.mLauncher.getResources().getDimensionPixelSize(R.dimen.button_bar_area_right);
            this.mRect.top = this.mLauncher.getResources().getDimensionPixelSize(R.dimen.button_bar_area_top);
            this.mRect.bottom = this.mLauncher.getResources().getDimensionPixelSize(R.dimen.button_bar_area_bottom);
            Logger.d(LoggingEvents.EXTRA_CALLING_APP_NAME, "[EDIT_DEBUG] DragLayer.initButtonBarArea(" + this.mRect.left + "," + this.mRect.top + "," + this.mRect.right + "," + this.mRect.bottom + ")");
        }
    }

    private boolean isButtonBarAreaContains(int x, int y) {
        if (this.mRect == null) {
            return false;
        }
        return this.mRect.contains(x, y);
    }
}
