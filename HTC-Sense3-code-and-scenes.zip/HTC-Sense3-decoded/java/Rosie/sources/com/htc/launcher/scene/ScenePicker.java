package com.htc.launcher.scene;

import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.database.DataSetObserver;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.SystemProperties;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.htc.launcher.Launcher;
import com.htc.launcher.LauncherIntent;
import com.htc.launcher.R;
import com.htc.launcher.WidgetWorkspaceManager;
import com.htc.launcher.config.DeviceFlag;
import com.htc.launcher.custom.CustomResourceUtil;
import com.htc.launcher.settings.SettingUtil;
import com.htc.launcher.widget.HtcSimpleSeparable;
import com.htc.util.skin.HtcSkinUtil;
import com.htc.widget.AdapterView;
import com.htc.widget.DecorFlow;
import com.htc.widget.HtcAdapterView;
import com.htc.widget.HtcAlertDialog;
import com.htc.widget.HtcListView;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class ScenePicker extends Activity implements HtcAdapterView.OnItemClickListener, AdapterView.OnItemClickListener {
    private static final int DELETE_MODE = 2;
    private static final int DIALOG_DELETE_SCENE_ID = 1;
    private static final int DIALOG_MAXIMUM_SCENE_ID = 3;
    private static final int DIALOG_NEW_SCENE_ID = 0;
    private static final int DIALOG_RENAME_SCENE_ID = 2;
    static final String KEY_SCENE_IS_PICKER_MODE = "scene_picker_mode";
    static final int LIST_MODE = 200;
    private static final int MENU_ADD_ID = 3;
    private static final int MENU_DELETE_ID = 4;
    static final int MENU_DELETE_MODE = 300;
    public static final int MENU_PICKER_LIST_VIEW_ID = 1;
    public static final int MENU_PICKER_PANEL_VIEW_ID = 2;
    private static final int MENU_RENAME_SCENE_ID = 5;
    static final int PANEL_MODE = 100;
    public static final String PREF_KEY_FLING_RATIO = "PICKER_FLING_RATIO";
    private static final int REQUEST_CODE = 900;
    private static final int SELECT_MODE = 0;
    private static final String TAG = "ListPicker";
    private static final boolean localLOG = false;
    protected ScenePickerAdapter mAdapter;
    private Bitmap mBackground;
    private DecorFlow mGalleryView;
    private View mHeaderView;
    private InstalledSceneReceiver mInstalledSceneReceiver;
    private Button mLeftButton;
    private RelativeLayout mListLayout;
    private HtcListView mListView;
    private View mPanelLayout;
    private SharedPreferences mPreferences;
    private TextView mSceneCountTextView;
    private TextView mSceneName;
    private int mSelectId;
    private boolean mIsPanelView = true;
    private int mCurrentMode = 0;
    private boolean mIsShowHeaderView = false;
    private int mnOrientation = 0;

    @Override // android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        Bundle extra;
        super.onCreate(savedInstanceState);
        SharedPreferences pref = getSharedPreferences("launcher", 0);
        if (!pref.getBoolean("resumed", false)) {
            launchHome();
            return;
        }
        requestWindowFeature(1);
        setContentView(R.layout.list_picker);
        int bgId = HtcSkinUtil.getDrawableResIdentifier(this, "common_app_bkg", 34080439);
        getWindow().setBackgroundDrawableResource(bgId);
        int sceneId = -1;
        Intent initialIntent = getIntent();
        if (initialIntent != null && (extra = initialIntent.getExtras()) != null) {
            sceneId = extra.getInt(DownloadSceneReceiver.EXTRA_DOWNLOAD_SCENE_ID, -1);
        }
        this.mPreferences = getSharedPreferences("launcher", 0);
        this.mAdapter = new ScenePickerAdapter(this);
        initUI();
        if (this.mGalleryView != null && sceneId >= 0) {
            this.mGalleryView.setSelection(this.mAdapter.getSceneIndexById(sceneId));
        }
    }

    private void initUI() {
        setContentView(R.layout.list_picker);
        initPanelPicker();
        initListPicker();
        this.mAdapter.setViewMode(true);
        this.mPanelLayout.setVisibility(0);
        this.mListLayout.setVisibility(8);
        switchMode(0);
    }

    @Override // android.app.Activity
    protected void onNewIntent(Intent intent) {
        Bundle extra;
        if (intent != null && (extra = intent.getExtras()) != null) {
            int sceneId = extra.getInt(DownloadSceneReceiver.EXTRA_DOWNLOAD_SCENE_ID, -1);
            if (this.mGalleryView != null && sceneId >= 0) {
                this.mGalleryView.setSelection(this.mAdapter.getSceneIndexById(sceneId));
            }
        }
    }

    @Override // android.app.Activity
    protected void onStop() {
        if (this.mAdapter != null && this.mAdapter.getCount() == 0) {
            WidgetWorkspaceManager wm = WidgetWorkspaceManager.instance(this);
            int currentSceneId = wm.newWorkspace(NewSceneActivity.generateHint(this));
            Intent intent = new Intent();
            intent.setAction(LauncherIntent.ACTION_THEME_CHANGE);
            intent.putExtra("workspace_id", currentSceneId);
            sendBroadcast(intent);
        }
        super.onStop();
    }

    @Override // android.app.Activity
    protected void onStart() {
        super.onStart();
        this.mIsPanelView = this.mPreferences.getBoolean(KEY_SCENE_IS_PICKER_MODE, true);
        if (this.mIsPanelView) {
            this.mAdapter.setViewMode(true);
            this.mPanelLayout.setVisibility(0);
            this.mListLayout.setVisibility(8);
        } else {
            this.mAdapter.setViewMode(false);
            this.mPanelLayout.setVisibility(8);
            this.mListLayout.setVisibility(0);
        }
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        if (this.mInstalledSceneReceiver != null) {
            unregisterReceiver(this.mInstalledSceneReceiver);
        }
        this.mInstalledSceneReceiver = null;
        super.onDestroy();
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Log.d(TAG, "onConfigurationChanged " + newConfig.orientation);
        initUI();
        setOrientation(newConfig.orientation);
    }

    private void setOrientation(int nOrientation) {
        if (this.mnOrientation == nOrientation) {
            Log.v(TAG, "same orientation, return");
        } else {
            this.mnOrientation = nOrientation;
            this.mAdapter.setOrientation(nOrientation);
        }
    }

    private void initPanelPicker() {
        this.mPanelLayout = findViewById(R.id.panel_picker_layout);
        this.mPanelLayout.setBackgroundDrawable(new FastBitmapDrawable(getResources(), this.mBackground));
        View background = this.mPanelLayout.findViewById(R.id.button_bar_background);
        if (background != null && background.getBackground() != null) {
            Drawable d = background.getBackground();
            if (d instanceof BitmapDrawable) {
                ((BitmapDrawable) d).setGravity(80);
            }
        }
        this.mGalleryView = this.mPanelLayout.findViewById(R.id.panel_picker_gallery);
        this.mGalleryView.setAdapter(this.mAdapter);
        this.mGalleryView.setSelection(this.mAdapter.getSceneIndexById(this.mAdapter.getSelectSceneId()));
        this.mGalleryView.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() { // from class: com.htc.launcher.scene.ScenePicker.1
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ScenePicker.this.mAdapter.setSelectSceneId((int) ScenePicker.this.mGalleryView.getItemIdAtPosition(position));
                if (ScenePicker.this.mGalleryView.getItemIdAtPosition(position) == ScenePicker.this.mAdapter.getCurrentSceneId()) {
                    ScenePicker.this.mSceneName.setText(ScenePicker.this.mAdapter.getItemName(id) + " " + ScenePicker.this.getResources().getString(R.string.label_current));
                } else {
                    ScenePicker.this.mSceneName.setText(ScenePicker.this.mAdapter.getItemName(id));
                }
                ScenePicker.this.mSceneCountTextView.setText((position + 1) + "/" + ScenePicker.this.mAdapter.getCount());
            }

            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        this.mGalleryView.setOnItemClickListener(this);
        this.mGalleryView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() { // from class: com.htc.launcher.scene.ScenePicker.2
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                if (ScenePicker.this.mCurrentMode == 0) {
                    for (int i = 0; i < ScenePicker.this.mAdapter.getCount(); i++) {
                        ScenePickerItem item = (ScenePickerItem) ScenePicker.this.mAdapter.getItem(i);
                        if (item.getId() == id) {
                            ScenePicker.this.createRenameSceneDialog(item);
                            return true;
                        }
                    }
                    ScenePicker.this.createRenameSceneDialog((ScenePickerItem) ScenePicker.this.mAdapter.getItem((int) id));
                    return true;
                }
                return false;
            }
        });
        this.mGalleryView.setFlingRatio(0.6f);
        this.mAdapter.registerDataSetObserver(new DataSetObserver() { // from class: com.htc.launcher.scene.ScenePicker.3
            @Override // android.database.DataSetObserver
            public void onChanged() {
                if (ScenePicker.this.mLeftButton != null) {
                    if (ScenePicker.this.mAdapter.getCount() > 0) {
                        ScenePicker.this.mLeftButton.setEnabled(true);
                    } else {
                        ScenePicker.this.mLeftButton.setEnabled(false);
                    }
                }
                super.onChanged();
            }
        });
        changePanelViewToDeleteMode(false);
        registerReceivers();
    }

    private float getFlingRatio() {
        try {
            float ret = Float.parseFloat(SystemProperties.get(PREF_KEY_FLING_RATIO));
            return ret;
        } catch (Exception e) {
            return 0.6f;
        }
    }

    private void registerReceivers() {
        if (this.mInstalledSceneReceiver == null) {
            this.mInstalledSceneReceiver = new InstalledSceneReceiver();
        }
        IntentFilter filter = new IntentFilter(DownloadSceneReceiver.ACTION_DOWNLOAD_SCENE_SAVED);
        filter.addAction(DownloadSceneReceiver.ACTION_UPDATE_SCENE);
        registerReceiver(this.mInstalledSceneReceiver, filter);
    }

    private void changePanelViewToDeleteMode(boolean isDeleteMode) {
        String titleName;
        Button mLeftButton;
        if (this.mPanelLayout == null) {
            this.mPanelLayout = findViewById(R.id.panel_picker_layout);
        }
        if (isDeleteMode) {
            titleName = getResources().getString(R.string.delete_scene_title);
        } else {
            titleName = getResources().getString(R.string.picker_title_scenes);
        }
        ((TextView) this.mPanelLayout.findViewById(R.id.panel_picker_title)).setText(titleName);
        this.mSceneName = (TextView) this.mPanelLayout.findViewById(R.id.panel_picker_name);
        this.mSceneCountTextView = (TextView) this.mPanelLayout.findViewById(R.id.panel_picker_count);
        if (isDeleteMode && this.mAdapter.getCount() > 0) {
            int currentSelectIndex = this.mGalleryView.getSelectedItemPosition();
            this.mAdapter.addDeleteIndex(currentSelectIndex);
            this.mAdapter.notifyDataSetChanged();
        }
        if (!isDeleteMode && this.mAdapter.getCount() == 0) {
            this.mSceneName.setText((CharSequence) null);
            this.mSceneCountTextView.setText((CharSequence) null);
        }
        View buttonBarTwoButton = this.mPanelLayout.findViewById(R.id.panel_picker_button_bar);
        View buttonBarOneButton = this.mPanelLayout.findViewById(R.id.panel_picker_button_bar_one_button);
        if (SettingUtil.sIsCSPackageInstalled) {
            buttonBarTwoButton.setVisibility(0);
            buttonBarOneButton.setVisibility(8);
            mLeftButton = (Button) buttonBarTwoButton.findViewById(33685505);
        } else if (isDeleteMode) {
            buttonBarTwoButton.setVisibility(0);
            buttonBarOneButton.setVisibility(8);
            mLeftButton = (Button) buttonBarTwoButton.findViewById(33685505);
        } else {
            buttonBarTwoButton.setVisibility(8);
            buttonBarOneButton.setVisibility(0);
            mLeftButton = (Button) buttonBarOneButton.findViewById(33685505);
        }
        if (isDeleteMode) {
            if (this.mAdapter.getCount() > 0) {
                mLeftButton.setText(getResources().getString(34341372) + " (" + this.mAdapter.getDeleteItemCount() + ")");
                mLeftButton.setEnabled(true);
            } else {
                mLeftButton.setText(getResources().getString(34341372) + " (0)");
                mLeftButton.setEnabled(false);
            }
            mLeftButton.setOnClickListener(new View.OnClickListener() { // from class: com.htc.launcher.scene.ScenePicker.4
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    ScenePicker.this.showDialog(1);
                }
            });
        } else {
            mLeftButton.setText(R.string.picker_btn_apply);
            mLeftButton.setEnabled(true);
            mLeftButton.setOnClickListener(new View.OnClickListener() { // from class: com.htc.launcher.scene.ScenePicker.5
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    ScenePicker.this.mAdapter.setSelectSceneId((int) ScenePicker.this.mGalleryView.getSelectedItemId());
                    ScenePicker.this.mAdapter.onApply();
                    ScenePicker.this.launchHome();
                }
            });
        }
        Button rightButton = (Button) this.mPanelLayout.findViewById(33685507);
        if (isDeleteMode) {
            rightButton.setText(34341181);
            rightButton.setOnClickListener(new View.OnClickListener() { // from class: com.htc.launcher.scene.ScenePicker.6
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    ScenePicker.this.switchMode(0);
                }
            });
        } else {
            rightButton.setText(R.string.picker_btn_get_more);
            rightButton.setOnClickListener(new View.OnClickListener() { // from class: com.htc.launcher.scene.ScenePicker.7
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    ScenePicker.this.startBrowserHtcDirect();
                }
            });
        }
    }

    private void initListPicker() {
        if (this.mListLayout == null) {
            this.mListLayout = (RelativeLayout) findViewById(R.id.list_picker_main_layout);
        }
        View buttonBarBackground = this.mListLayout.findViewById(R.id.button_bar_background);
        if (buttonBarBackground != null && buttonBarBackground.getBackground() != null) {
            Drawable d = buttonBarBackground.getBackground();
            if (d instanceof BitmapDrawable) {
                ((BitmapDrawable) d).setGravity(80);
            }
        }
        this.mAdapter.setViewMode(false);
        this.mListView = this.mListLayout.findViewById(R.id.picker_list);
        this.mListView.setSelector(CustomResourceUtil.getDrawableResIdentifier(getBaseContext(), "rosie_list_selector", R.drawable.list_selector));
        if (this.mIsShowHeaderView) {
            this.mHeaderView = getLayoutInflater().inflate(R.layout.scene_list_title, (ViewGroup) null);
            ((TextView) this.mHeaderView.findViewById(R.id.scene_list_title_name)).setText(R.string.picker_item_add_theme);
            this.mHeaderView.setTag(new HtcSimpleSeparable("isHeader"));
        }
        this.mListView.setFillEmpty(false);
        this.mListView.setOnItemClickListener(this);
        this.mListView.setItemsCanFocus(true);
        this.mListView.setOnItemLongClickListener(new HtcAdapterView.OnItemLongClickListener() { // from class: com.htc.launcher.scene.ScenePicker.8
            public boolean onItemLongClick(HtcAdapterView<?> parent, View view, int position, long id) {
                if (ScenePicker.this.mCurrentMode != 0 || position < 0) {
                    return false;
                }
                ScenePicker.this.createRenameSceneDialog((ScenePickerItem) ScenePicker.this.mAdapter.getItem(position));
                return true;
            }
        });
        this.mListView.setRoundedCornerEnabled(true, false);
        changeListViewToDeleteMode(false);
    }

    private void changeListViewToDeleteMode(boolean isDeleteMode) {
        String titleName;
        Button mLeftButton;
        if (this.mListLayout == null) {
            this.mListLayout = (RelativeLayout) findViewById(R.id.list_picker_main_layout);
        }
        if (isDeleteMode) {
            titleName = getResources().getString(R.string.delete_scene_title);
        } else {
            titleName = getResources().getString(R.string.picker_title_scenes);
        }
        ((TextView) this.mListLayout.findViewById(33685587)).setText(titleName);
        ((TextView) this.mListLayout.findViewById(33685588)).setText(titleName);
        View buttonBarTwoButton = this.mListLayout.findViewById(R.id.list_picker_button_bar);
        View buttonBarOneButton = this.mListLayout.findViewById(R.id.list_picker_button_bar_one_button);
        if (SettingUtil.sIsCSPackageInstalled) {
            buttonBarTwoButton.setVisibility(0);
            buttonBarOneButton.setVisibility(8);
            mLeftButton = (Button) buttonBarTwoButton.findViewById(33685505);
        } else if (isDeleteMode) {
            buttonBarTwoButton.setVisibility(0);
            buttonBarOneButton.setVisibility(8);
            mLeftButton = (Button) buttonBarTwoButton.findViewById(33685505);
        } else {
            buttonBarTwoButton.setVisibility(8);
            buttonBarOneButton.setVisibility(0);
            mLeftButton = (Button) buttonBarOneButton.findViewById(33685505);
        }
        if (isDeleteMode) {
            mLeftButton.setText(getResources().getString(34341372) + " (0)");
            mLeftButton.setEnabled(false);
            mLeftButton.setOnClickListener(new View.OnClickListener() { // from class: com.htc.launcher.scene.ScenePicker.9
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    ScenePicker.this.showDialog(1);
                }
            });
        } else {
            mLeftButton.setText(R.string.picker_btn_apply);
            mLeftButton.setEnabled(true);
            mLeftButton.setOnClickListener(new View.OnClickListener() { // from class: com.htc.launcher.scene.ScenePicker.10
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    ScenePicker.this.mAdapter.onApply();
                    ScenePicker.this.launchHome();
                }
            });
        }
        Button rightButton = (Button) buttonBarTwoButton.findViewById(33685507);
        if (isDeleteMode) {
            rightButton.setText(34341181);
            rightButton.setOnClickListener(new View.OnClickListener() { // from class: com.htc.launcher.scene.ScenePicker.11
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    ScenePicker.this.switchMode(0);
                }
            });
        } else {
            rightButton.setText(R.string.picker_btn_get_more);
            rightButton.setOnClickListener(new View.OnClickListener() { // from class: com.htc.launcher.scene.ScenePicker.12
                @Override // android.view.View.OnClickListener
                public void onClick(View v) {
                    ScenePicker.this.startBrowserHtcDirect();
                }
            });
        }
        if (isDeleteMode) {
            this.mListView.setChoiceMode(2);
            if (this.mIsShowHeaderView && this.mListView.getHeaderViewsCount() > 0) {
                this.mListView.removeHeaderView(this.mHeaderView);
            }
            this.mListView.setAdapter(this.mAdapter);
            return;
        }
        this.mListView.setChoiceMode(1);
        if (this.mIsShowHeaderView && this.mListView.getHeaderViewsCount() == 0) {
            this.mListView.setAdapter((ListAdapter) null);
            this.mListView.addHeaderView(this.mHeaderView);
        }
        this.mListView.setAdapter(this.mAdapter);
    }

    public class OptionMenuItem {
        public int icon;
        public int name;

        public OptionMenuItem() {
        }
    }

    public void onItemClick(HtcAdapterView<?> parent, View view, int position, long id) {
        if (!this.mIsPanelView) {
            if (this.mCurrentMode == 0) {
                if (this.mIsShowHeaderView) {
                    if (position == 0) {
                        showDialog(0);
                    } else {
                        this.mAdapter.setSelectSceneId((int) this.mAdapter.getItemId(position));
                    }
                } else {
                    this.mAdapter.setSelectSceneId((int) this.mAdapter.getItemId(position));
                }
                this.mAdapter.notifyDataSetInvalidated();
                return;
            }
            if (this.mCurrentMode == 2) {
                this.mAdapter.addDeleteIndex(position);
                this.mAdapter.notifyDataSetChanged();
                Button leftButton = (Button) this.mListLayout.findViewById(33685505);
                int deleteItemCount = this.mAdapter.getDeleteItemCount();
                leftButton.setText(getResources().getString(34341372) + " (" + deleteItemCount + ")");
                if (deleteItemCount > 0) {
                    leftButton.setEnabled(true);
                } else {
                    leftButton.setEnabled(false);
                }
            }
        }
    }

    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if (this.mIsPanelView) {
            if (this.mCurrentMode == 0) {
                this.mAdapter.setSelectSceneId((int) this.mGalleryView.getSelectedItemId());
                this.mAdapter.onApply();
                launchHome();
            } else if (this.mCurrentMode == 2) {
                this.mAdapter.addDeleteIndex(position);
                this.mAdapter.notifyDataSetChanged();
                Button leftButton = (Button) this.mPanelLayout.findViewById(33685505);
                int deleteItemCount = this.mAdapter.getDeleteItemCount();
                leftButton.setText(getResources().getString(34341372) + " (" + deleteItemCount + ")");
                if (deleteItemCount > 0) {
                    leftButton.setEnabled(true);
                } else {
                    leftButton.setEnabled(false);
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startNewSceneActivity() {
        if (this.mAdapter != null && this.mAdapter.getCount() >= 20) {
            showDialog(3);
            return;
        }
        Intent intent = new Intent();
        intent.setAction(NewSceneActivity.ACTION_NEW_ITEM);
        intent.putExtra(NewSceneActivity.KEY_LAUNCH_MODE, 0);
        startActivityForResult(intent, 100);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startBrowserHtcDirect() {
        Intent intent = new Intent();
        intent.setComponent(new ComponentName("com.htc.AddProgramWidget", "com.htc.AddProgramWidget.olrespicker.OnlineResPicker"));
        intent.putExtra("RES_TYPE", 8);
        intent.putExtra("CATE_ID", -999L);
        if (this.mIsPanelView) {
            intent.putExtra("VIEW_ASPECT", "THUMBNAIL");
        } else {
            intent.putExtra("VIEW_ASPECT", "LIST");
        }
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, R.string.activity_not_found, 0).show();
        } catch (SecurityException e2) {
            Toast.makeText(this, R.string.activity_not_found, 0).show();
            Log.e(TAG, "Launcher does not have the permission to launch " + intent + ". Make sure to create a MAIN intent-filter for the corresponding activity or use the exported attribute for this activity.", e2);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startRenameSceneActivity() {
        Intent intent = new Intent();
        intent.setAction(NewSceneActivity.ACTION_NEW_ITEM);
        intent.putExtra(NewSceneActivity.KEY_LAUNCH_MODE, 1);
        intent.putExtra(NewSceneActivity.KEY_SELECT_ID, this.mSelectId);
        startActivityForResult(intent, 100);
    }

    @Override // android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        int scene;
        int scene2;
        if (requestCode == 100) {
            if (resultCode == 2) {
                this.mAdapter.update();
                this.mAdapter.updateSceneName();
                if (this.mAdapter.getCurrentSceneId() == this.mGalleryView.getSelectedItemId()) {
                    this.mSceneName.setText(this.mAdapter.getItemName(this.mGalleryView.getSelectedItemId()) + " " + getResources().getString(R.string.label_current));
                } else {
                    this.mSceneName.setText(this.mAdapter.getItemName(this.mGalleryView.getSelectedItemId()));
                }
                this.mSceneCountTextView.setText((this.mGalleryView.getSelectedItemPosition() + 1) + "/" + this.mAdapter.getCount());
            } else if (resultCode == 4) {
                if (data != null && data.hasExtra(NewSceneActivity.DELETE_SCENE_ID) && (scene2 = data.getIntExtra(NewSceneActivity.DELETE_SCENE_ID, -1)) != -1) {
                    if (scene2 == this.mAdapter.getCurrentSceneId()) {
                        this.mAdapter.setSelectSceneId(this.mSelectId);
                        this.mAdapter.onApply();
                        String sceneName = this.mAdapter.getItemName(this.mGalleryView.getSelectedItemId()) + " " + getResources().getString(R.string.label_current);
                        this.mSceneName.setText(sceneName);
                    }
                    this.mAdapter.onDelete(scene2);
                    this.mAdapter.notifyDataSetChanged();
                    this.mAdapter.updateSceneName();
                }
                this.mSceneCountTextView.setText((this.mGalleryView.getSelectedItemPosition() + 1) + "/" + this.mAdapter.getCount());
            } else if (resultCode == 5) {
                if (data != null && data.hasExtra(NewSceneActivity.DELETE_SCENE_ID) && (scene = data.getIntExtra(NewSceneActivity.DELETE_SCENE_ID, -1)) != -1) {
                    this.mAdapter.onDelete(scene);
                }
                launchHome();
            } else if (resultCode == 3) {
                launchHome();
            }
        } else if (requestCode == REQUEST_CODE) {
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override // android.app.Activity
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuItem item = menu.add(0, 3, 0, R.string.picker_menu_add_scene);
        item.setIcon(34079517);
        MenuItem item2 = menu.add(200, 2, 1, R.string.picker_menu_panel_view);
        item2.setIcon(R.drawable.icon_menu_3d_panel);
        if (!DeviceFlag.isTabletDevice()) {
            MenuItem item3 = menu.add(100, 1, 1, R.string.all_apps_menu_layout_list);
            item3.setIcon(34079530);
        }
        MenuItem item4 = menu.add(300, 4, 2, 34341372);
        item4.setIcon(34079523);
        MenuItem item5 = menu.add(0, 5, 2, R.string.picker_option_menu_rename);
        item5.setIcon(34079524);
        return true;
    }

    @Override // android.app.Activity
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 1:
            case 2:
                switchView();
                break;
            case 3:
                startNewSceneActivity();
                return true;
            case 4:
                switchMode(2);
                return true;
            case 5:
                this.mSelectId = this.mAdapter.getSelectSceneId();
                startRenameSceneActivity();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override // android.app.Activity
    public boolean onPrepareOptionsMenu(Menu menu) {
        if (this.mIsPanelView) {
            menu.setGroupVisible(200, false);
            menu.setGroupVisible(100, true);
        } else {
            menu.setGroupVisible(100, false);
            menu.setGroupVisible(200, true);
        }
        if (this.mAdapter.getCount() == 0) {
            menu.setGroupEnabled(300, false);
        } else {
            menu.setGroupEnabled(300, true);
        }
        MenuItem item = menu.findItem(5);
        if (item != null) {
            int selectedIndex = this.mAdapter.getSceneIndexById(this.mAdapter.getSelectSceneId());
            if (this.mAdapter.getCount() == 0 || selectedIndex < 0 || selectedIndex >= this.mAdapter.getCount()) {
                item.setEnabled(false);
            } else {
                item.setEnabled(true);
            }
        }
        if (this.mCurrentMode != 0) {
            return false;
        }
        return super.onPrepareOptionsMenu(menu);
    }

    private void switchView() {
        if (this.mIsPanelView) {
            if (this.mListLayout == null) {
                initListPicker();
            }
            this.mIsPanelView = false;
            this.mAdapter.setViewMode(false);
            this.mPanelLayout.setVisibility(8);
            this.mListLayout.setVisibility(0);
            this.mAdapter.notifyDataSetChanged();
        } else {
            if (this.mPanelLayout == null) {
                initPanelPicker();
            }
            this.mIsPanelView = true;
            this.mAdapter.setViewMode(true);
            this.mPanelLayout.setVisibility(0);
            this.mListLayout.setVisibility(8);
            this.mAdapter.notifyDataSetChanged();
        }
        Intent intent = new Intent(SceneModeChangeReceiver.ACTION_ASPECT_CHANGED);
        intent.putExtra(SceneModeChangeReceiver.EXTRA_ASPECT_ISTHUMB, this.mIsPanelView);
        sendBroadcast(intent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void switchMode(int whichMode) {
        if (this.mIsPanelView) {
            switch (whichMode) {
                case 0:
                    this.mCurrentMode = 0;
                    this.mAdapter.setAdapterMode(0);
                    changePanelViewToDeleteMode(false);
                    break;
                case 2:
                    this.mCurrentMode = 2;
                    this.mAdapter.setAdapterMode(1);
                    changePanelViewToDeleteMode(true);
                    break;
            }
        }
        switch (whichMode) {
            case 0:
                this.mCurrentMode = 0;
                this.mAdapter.setAdapterMode(0);
                changeListViewToDeleteMode(false);
                break;
            case 2:
                this.mCurrentMode = 2;
                this.mAdapter.setAdapterMode(1);
                changeListViewToDeleteMode(true);
                break;
        }
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode != 4 || this.mCurrentMode == 0) {
            return super.onKeyUp(keyCode, event);
        }
        switchMode(0);
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void launchHome() {
        String category;
        UiModeManager uiModeMgr = (UiModeManager) getSystemService("uimode");
        switch (uiModeMgr.getCurrentModeType()) {
            case 2:
                category = "android.intent.category.DESK_DOCK";
                break;
            case 3:
                category = "android.intent.category.CAR_DOCK";
                break;
            default:
                category = "android.intent.category.HOME";
                break;
        }
        Intent intent = new Intent("android.intent.action.MAIN");
        intent.addCategory(category);
        intent.addFlags(268435456);
        startActivity(intent);
        finish();
    }

    @Override // android.app.Activity
    protected Dialog onCreateDialog(int id, Bundle args) {
        switch (id) {
            case 0:
                return new HtcAlertDialog.Builder(this).setTitle(R.string.picker_menu_add_scene).setItems(R.array.add_scene_dialog_items, new DialogInterface.OnClickListener() { // from class: com.htc.launcher.scene.ScenePicker.13
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                ScenePicker.this.startNewSceneActivity();
                                break;
                            case 1:
                                ScenePicker.this.startBrowserHtcDirect();
                                break;
                        }
                    }
                }).create();
            case 1:
                return new HtcAlertDialog.Builder(this).setTitle(34341372).setIcon(android.R.drawable.ic_dialog_alert).setMessage(R.string.picker_dialog_content_message).setPositiveButton(34341180, new DialogInterface.OnClickListener() { // from class: com.htc.launcher.scene.ScenePicker.15
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        if (ScenePicker.this.mAdapter.onDelete() && ScenePicker.this.mAdapter.getCount() != 0) {
                            Intent intent = new Intent();
                            intent.setAction(LauncherIntent.ACTION_THEME_CHANGE);
                            intent.putExtra("workspace_id", ((ScenePickerItem) ScenePicker.this.mAdapter.getItem(0)).getId());
                            intent.putExtra(Launcher.EXTRA_AUTO_SAVE, false);
                            ScenePicker.this.sendBroadcast(intent);
                            if (ScenePicker.this.mIsPanelView) {
                                ScenePicker.this.mGalleryView.setSelection(0);
                            }
                        }
                        ScenePicker.this.mAdapter.notifyDataSetChanged();
                        ScenePicker.this.switchMode(0);
                    }
                }).setNegativeButton(34341181, new DialogInterface.OnClickListener() { // from class: com.htc.launcher.scene.ScenePicker.14
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).create();
            case 2:
            default:
                return super.onCreateDialog(id, args);
            case 3:
                return new HtcAlertDialog.Builder(this).setTitle(R.string.dialog_title_maximun_scene).setMessage(R.string.dialog_content_maximun_scene).setNegativeButton(34341180, new DialogInterface.OnClickListener() { // from class: com.htc.launcher.scene.ScenePicker.16
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).create();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void createRenameSceneDialog(ScenePickerItem item) {
        this.mSelectId = item.getId();
        HtcAlertDialog renameSceneDialog = new HtcAlertDialog.Builder(this).setTitle(item.getName()).setItems(R.array.rename_scene_dialog_items, new DialogInterface.OnClickListener() { // from class: com.htc.launcher.scene.ScenePicker.17
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0:
                        ScenePicker.this.startRenameSceneActivity();
                        break;
                }
            }
        }).create();
        renameSceneDialog.show();
    }

    private class InstalledSceneReceiver extends BroadcastReceiver {
        private InstalledSceneReceiver() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            ScenePicker.this.mAdapter.update();
        }
    }
}
