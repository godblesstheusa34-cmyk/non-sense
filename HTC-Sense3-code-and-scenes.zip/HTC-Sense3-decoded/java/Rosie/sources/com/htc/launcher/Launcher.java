package com.htc.launcher;

import android.app.AlertDialog;
import android.app.Application;
import android.app.Dialog;
import android.app.IWallpaperManager;
import android.app.KeyguardManager;
import android.app.ProgressDialog;
import android.app.SearchManager;
import android.app.StatusBarManager;
import android.app.WallpaperInfo;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentQueryMap;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Debug;
import android.os.FileUtils;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.MessageQueue;
import android.os.Parcelable;
import android.os.Process;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.os.SystemProperties;
import android.provider.Settings;
import android.telephony.PhoneNumberUtils;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.Selection;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.TextKeyListener;
import android.util.Log;
import android.util.LogPrinter;
import android.view.Display;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.common.Search;
import com.android.common.speech.LoggingEvents;
import com.android.internal.telephony.ITelephony;
import com.htc.android.rosie.home.HostWidgetManager;
import com.htc.android.rosie.home.fxcontrol.FxPathFinder;
import com.htc.android.rosie.home.fxcontrol.FxSceneManager;
import com.htc.android.rosie.home.fxcontrol.FxScreen;
import com.htc.android.rosie.home.fxcontrol.FxWorkspace;
import com.htc.android.rosie.home.fxcontrol.UnlockAnimationListener;
import com.htc.fusion.fx.FxSkinUtility;
import com.htc.launcher.AddAdapter;
import com.htc.launcher.AddWidgetLayout;
import com.htc.launcher.DragController;
import com.htc.launcher.LauncherSettings;
import com.htc.launcher.LeapController;
import com.htc.launcher.Manifest;
import com.htc.launcher.Workspace;
import com.htc.launcher.custom.CustomResourceUtil;
import com.htc.launcher.model.FilterableAndSortableApplicationInfoList;
import com.htc.launcher.scene.DownloadSceneReceiver;
import com.htc.launcher.scene.NewSceneActivity;
import com.htc.launcher.scene.ScenePickerAdapter;
import com.htc.launcher.scene.XmlUtils;
import com.htc.launcher.search.SearchPickerActivity;
import com.htc.launcher.settings.SettingUtil;
import com.htc.launcher.widget.ButtonBar;
import com.htc.launcher.widget.FunctionBar;
import com.htc.launcher.widget.SlidingDrawer;
import com.htc.util.skin.HtcSkinUtil;
import com.htc.utils.ulog.ReusableULogData;
import com.htc.utils.ulog.ULog;
import com.htc.widget.CarouselInternalActivity;
import com.htc.widget.HtcAdapterView;
import com.htc.widget.HtcAlertDialog;
import com.htc.widget.SearchBoxView;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import java.util.Set;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public final class Launcher extends CarouselInternalActivity implements LeapController.LeapListener, View.OnLongClickListener, View.OnTouchListener {
    static final /* synthetic */ boolean $assertionsDisabled;
    static final String ACTION_HIDE_WEATHER_WALLPAPER = "com.htc.weatherwallpaper.service.intent.action.HIDE_WEATHER_WALLPAPER";
    public static final String ACTION_PERSONALIZE_ADD_APP_TO_HOME = "com.htc.intent.ACTION_PERSONALIZE_ADD_APP_TO_HOME";
    public static final String ACTION_PERSONALIZE_ADD_APP_TO_HOME_CHANGED = "com.htc.intent.ACTION_PERSONALIZE_ADD_APP_TO_HOME_CHANGED";
    public static final String ACTION_PERSONALIZE_ADD_FOLDER_TO_HOME = "com.htc.intent.ACTION_PERSONALIZE_ADD_FOLDER_TO_HOME";
    public static final String ACTION_PERSONALIZE_ADD_FOLDER_TO_HOME_CHANGED = "com.htc.intent.ACTION_PERSONALIZE_ADD_FOLDER_TO_HOME_CHANGED";
    public static final String ACTION_PERSONALIZE_ADD_SHORTCUT_TO_HOME = "com.htc.intent.ACTION_PERSONALIZE_ADD_SHORTCUT_TO_HOME";
    public static final String ACTION_PERSONALIZE_ADD_SHORTCUT_TO_HOME_CHANGED = "com.htc.intent.ACTION_PERSONALIZE_ADD_SHORTCUT_TO_HOME_CHANGED";
    public static final String ACTION_PERSONALIZE_ADD_WIDGET_TO_HOME = "com.htc.intent.ACTION_PERSONALIZE_ADD_WIDGET_TO_HOME";
    public static final String ACTION_PERSONALIZE_ADD_WIDGET_TO_HOME_CHANGED = "com.htc.intent.ACTION_PERSONALIZE_ADD_WIDGET_TO_HOME_CHANGED";
    public static final String ACTION_SILDER_STATE = "com.htc.launcher.ThemeChooser.action.silder_change";
    public static final String[] ACTION_SUMMARY_CHANGES;
    static final String ACTION_WEATHER_ANIMATION_DONE = "com.htc.weatherwallpaper.service.intent.action.WEATHER_WALLPAPER_DISMISS";
    private static final int ANIMATION_DURATION = 100;
    static final int APPWIDGET_HOST_ID = 9999;
    static final String AUTHORITY = "com.htc.launcher.AllAppsCarouselProvider";
    private static final long BACKGROUND_GO_DELAY = 10000;
    public static final String CASE_FOTA_UPGRADE = "com.htc.FOTA_UPGRADE";
    public static final String CATEGORY_SEARCH = "com.htc.launcher.intent.category.SEARCH";
    private static final int CREATE_SCENE_PREVIEW = 24;
    public static final boolean DEBUG_DB_OBSERVER = true;
    public static final String DEBUG_DB_TAG = "RosieDbDebug";
    private static final boolean DEBUG_USER_INTERFACE = false;
    private static final int DIALOG_CREATE_SHORTCUT = 1;
    private static final int DIALOG_CREATE_WALLPAPER = 102;
    public static final int DIALOG_PROGRESS = 100;
    static final int DIALOG_RENAME_FOLDER = 2;
    private static final int DIALOG_SORT_OPTION = 103;
    private static final int DISMISS_LOADING = 1008;
    private static final int DRAWER_MODE_ADD_TO_HOME = 1;
    private static final int DRAWER_MODE_ALL_APPS = 0;
    private static final int ERROR_MESSAGE_DURATION = 1000;
    public static final String EXTRA_AUTO_SAVE = "extra_auto_save";
    public static final String EXTRA_OPEN_PERSONALIZE = "open_personalize";
    public static final String EXTRA_SILDER_STATE = "silder_state";
    private static final int FINISHED_LOADING_TASK = 2;
    public static final boolean FLAG_WEATHER_WALLPAPER_PAUSE_WAIDGET = true;
    static final boolean GREEN_LIGHT = true;
    public static final String INTENT_LOADING_COMPLETE = "com.htc.launcher.intent.LOADING_COMPLETE";
    public static final String INTENT_RESUMED = "com.htc.launcher.intent.RESUMED";
    private static final String KEY_CURRENT_SKIN_NAME = "current_skin_name";
    public static final String KEY_CUSTOMIZED_REASON = "com.htc.CUSTOMIZED_REASON";
    private static final String KEY_LOCALE = "locale";
    private static final String KEY_MCC = "mcc";
    private static final String KEY_MNC = "mnc";
    public static final String KEY_SCENE_PREVIEW_LAND_INVALIDATE = "scene_preview_land_invalidate";
    public static final String KEY_SCENE_PREVIEW_PORT_INVALIDATE = "scene_preview_port_invalidate";
    public static final String KEY_TUTORIAL_NOTICE = "tutorial_notice";
    static final String LAUNCH_FLAG = "launch_flag";
    static final int LAUNCH_FROM_ALL_APPS = 3;
    public static final int LAUNCH_FROM_DESKTOP = 1;
    private static final int LAUNCH_FROM_HARD_KEY = 2;
    private static final boolean LOG_BACKGROUND_TRAFFIC = false;
    private static final String LOG_BACKGROUND_TRAFFIC_TAG = "Background traffic light";
    private static final String LOG_MEM = "RosieMEM";
    static final String LOG_TAG = "Rosie";
    private static final int MENU_ADD = 2;
    private static final int MENU_ALL_APPS_FIND = 9;
    private static final int MENU_ALL_APPS_LAYOUT_GRID = 8;
    private static final int MENU_ALL_APPS_LAYOUT_LIST = 7;
    private static final int MENU_ALL_APPS_REMOVE = 10;
    private static final int MENU_ALL_APPS_SEARCH = 14;
    private static final int MENU_ALL_APPS_SHARING = 13;
    private static final int MENU_ALL_APPS_SORT = 11;
    private static final int MENU_ALL_PROGRAM = 12;
    private static final int MENU_GROUP_ADD = 1;
    private static final int MENU_GROUP_ALL_APPS = 2;
    private static final int MENU_NOTIFICATIONS = 5;
    private static final int MENU_PERSONALIZE = 15;
    private static final int MENU_RINGONE = 16;
    private static final int MENU_SEARCH = 4;
    private static final int MENU_SETTINGS = 6;
    private static final int MENU_WALLPAPER_SETTINGS = 3;
    private static final int MSG_ALLOW_MOVE_TO_DEFAULT_SCREEN = 1002;
    private static final int MSG_CLOSE_ADD_TO_HOME = 1000;
    private static final int MSG_CREATE_SCENE_PREVIEW = 1009;
    private static final int MSG_FINISH_BIND_FXWIDGET = 1006;
    private static final int MSG_HIDE_SCROLLER = 1005;
    private static final int MSG_KEY_LONG_PRESS_TIMEOUT = 1004;
    private static final int MSG_REFRESH_ADD_TO_HOME = 1001;
    private static final int MSG_UNLOCK_ENTER_THUMBNAIL_MODE = 1003;
    private static final int NAVIGATING = 1;
    private static final int NOTIFY_DATA_SET_CHANGED = 1007;
    private static final int NO_NAVIGATION = 0;
    static final int NUMBER_CELLS_X = 4;
    static final int NUMBER_CELLS_Y = 4;
    public static final String PERSONALIZE_PREFERENCES = "PersonalizeSummary";
    public static final String PREFERENCES = "launcher";
    private static final boolean PROFILE_DRAWER = false;
    private static final boolean PROFILE_ORIENTATION = false;
    private static final boolean PROFILE_ROTATE = false;
    private static final boolean PROFILE_STARTUP = false;
    private static final String PROP_NAVI_MODE = "com.htc.laputa.NaviMode";
    static final boolean RED_LIGHT = false;
    private static final int REQUEST_CHOOSE_STYLE = 100;
    static final int REQUEST_CREATE_APPWIDGET = 5;
    static final int REQUEST_CREATE_LIVE_FOLDER = 4;
    static final int REQUEST_CREATE_SHORTCUT = 1;
    static final int REQUEST_PICK_APPLICATION = 6;
    private static final int REQUEST_PICK_APPWIDGET = 9;
    private static final int REQUEST_PICK_BOOKMARK_SHORTCUT = 11;
    private static final int REQUEST_PICK_FXWIDGET = 12;
    private static final int REQUEST_PICK_LIVE_FOLDER = 8;
    private static final int REQUEST_PICK_NOTIFICATION_SOUND = 14;
    private static final int REQUEST_PICK_RINGTONE = 13;
    private static final int REQUEST_PICK_SETTINGWIDGET = 10;
    private static final int REQUEST_PICK_SHORTCUT = 7;
    public static final int REQUEST_SETTING_OPTION = 501;
    public static final int REQUEST_VARIATION_OPTION = 500;
    private static final String RUNTIME_STATE_ALL_APPS_FOLDER = "launcher.all_apps_folder";
    private static final String RUNTIME_STATE_CURRENT_SCREEN = "launcher.current_screen";
    private static final String RUNTIME_STATE_PENDING_ADD_CELL_X = "launcher.add_cellX";
    private static final String RUNTIME_STATE_PENDING_ADD_CELL_Y = "launcher.add_cellY";
    private static final String RUNTIME_STATE_PENDING_ADD_COUNT_X = "launcher.add_countX";
    private static final String RUNTIME_STATE_PENDING_ADD_COUNT_Y = "launcher.add_countY";
    private static final String RUNTIME_STATE_PENDING_ADD_OCCUPIED_CELLS = "launcher.add_occupied_cells";
    private static final String RUNTIME_STATE_PENDING_ADD_SCREEN = "launcher.add_screen";
    private static final String RUNTIME_STATE_PENDING_ADD_SPAN_X = "launcher.add_spanX";
    private static final String RUNTIME_STATE_PENDING_ADD_SPAN_Y = "launcher.add_spanY";
    private static final String RUNTIME_STATE_PENDING_FOLDER_RENAME = "launcher.rename_folder";
    private static final String RUNTIME_STATE_PENDING_FOLDER_RENAME_ID = "launcher.rename_folder_id";
    private static final String RUNTIME_STATE_SLIDING_ALL_PROGRAM = "launcher.sliding_all_apps";
    private static final String RUNTIME_STATE_USER_FOLDERS = "launcher.user_folder";
    private static final String SCREEN_CACHE_SRC = "/data/data/com.htc.launcher/files/screen_cache.png";
    private static final String SCREEN_CACHE_SRC_LAND = "/data/data/com.htc.launcher/files/screen_cache_land.png";
    static final String SEARCHANYWHERE_ACTIVITY = "com.htc.searchanywhere/.SearchActivity";
    public static final String STATUS_BAR_TAP_EVENT = "com.android.server.status.StatusBarView.STATUS_BAR_TAP_EVENT";
    private static final boolean USE_BACKGROUND_TRAFFIC_LIGHT = false;
    private static final int WAIT_LAUNCH_TIMEOUT = 1000;
    private static final int WALLPAPER_SELECTED_HOME = 0;
    private static final int WALLPAPER_SELECTED_LOCK_SCREEN = 1;
    public static final int WIDGET_ID_OFFSET = 10000;
    public static Intent dataBackup;
    public static boolean ifAddButtonbar;
    public static boolean localLOGD;
    private static CharSequence mLiveWallpaperName;
    private static int mMiddleClickButton;
    private static int mProgramListId;
    public static CellInfo mSettingWidgetCellInfo;
    private static int mUiMode;
    public static boolean needActivityResult;
    public static int requestCodeBackup;
    public static int resultCodeBackup;
    private static final Intent sBackgroundGoIntent;
    private static final Intent sBackgroundStopIntent;
    private static CustomizationChangeReceiver sCustomizationReceiver;
    public static LauncherAppWidgetHost sDefaultAppWidgetHost;
    private static FxPathFinder sFxPathFinder;
    private static FxSceneManager sFxSceneManager;
    private static KeyguardManager sKeyguardManager;
    private static final Object sLock;
    static final LauncherModel sModel;
    static OrientationMonitor sOrientationMonitor;
    public static WeakReference<Launcher> sRefLauncher;
    private static int sScreen;
    static boolean sUseWallpaperService;
    static Bitmap sWallpaper;
    private static WallpaperIntentReceiver sWallpaperReceiver;
    private static final Intent sWeatherAnimationDoneIntent;
    protected static WidgetPackageManager sWidgetPackageManager;
    private final int RAISED_PRIORITY;
    long a;
    private boolean ask2NotifyHint;
    AppTabType currentAppTab;
    private boolean forceBuildCache;
    private boolean isButtonCanPress;
    private boolean isKeyguardOnWhenOnResume;
    public boolean isNeedLaunchAddToHome;
    private boolean isShowAllProgramSearchBar;
    private boolean isSupportLandscape;
    private boolean isUakKeyProcessed;
    private Comparator<? super ApplicationInfo> lastComparator4AllAppsTab;
    private WeakReference<Dialog> lastDialog;
    private String lastTabTag;
    private int lastUakKeyCode;
    public String launchAppType;
    private boolean mActivityLaunched;
    private boolean mAddHtcWidgetByOtherActivity;
    private CellInfo mAddItemCellInfo;
    private View mAllAppsBar;
    EditText mAllAppsBarEditText;
    AllAppsView mAllAppsView;
    private LauncherAppWidgetHost mAppWidgetHost;
    private AppWidgetManager mAppWidgetManager;
    private final ContentObserver mAppWidgetResetObserver;
    ApplicationsAdapter mApplicationsAdapter;
    private final BroadcastReceiver mApplicationsReceiver;
    private final Runnable mBackgroundGo;
    private boolean mBackgroundTrafficLight;
    private BroadcastReceiver mBackgroundTrafficLightReceiver;
    private DesktopBinder mBinder;
    FunctionBar mBottomBarArea;
    private ButtonBarCache mButtonBarCache;
    private ButtonBar mButtons;
    private final int[] mCellCoordinates;
    private boolean mChangingOrientation;
    private ContentQueryMap mContentQueryMap;
    private View mControl;
    private Animation mControlInAnimation;
    private Animation mControlOutAnimation;
    private Handler mCreateScenePreviewHandler;
    private HandlerThread mCreateScenePreviewThread;
    String mCurrentLocale;
    int mCurrentMcc;
    int mCurrentMnc;
    private int mCurrentOrientation;
    private SpannableStringBuilder mDefaultKeySsb;
    private DeleteZone mDeleteZone;
    public DesktopItemController mDesktopItemController;
    private boolean mDesktopLocked;
    private boolean mDestroyed;
    private boolean mDestroying;
    private DragLayer mDragLayer;
    private DragMenuBar mDragMenuBar;
    public SlidingDrawer mDrawer;
    private int mDrawerContentId;
    private TextView mDrawerTitle;
    private TextView mDrawerTitleShade;
    private Runnable mEmptyRunnable;
    private int mFinishLoading;
    private FolderInfo mFolderInfo;
    private boolean mFreezeTilt;
    private boolean mFreezeable;
    private HostWidgetManager mFxWidgetManager;
    public FxWorkspace mFxWorkspace;
    private View mHandleView;
    final Handler mHandler;
    private final HtcWidgetUpdateReceiver mHtcWidgetUpdateReceiver;
    private LayoutInflater mInflater;
    private ArrayList<Long> mIntervals;
    boolean mIsAllProgramSliding;
    private boolean mIsAllowMoveToDefaultScreen;
    private boolean mIsConfigurationChanged;
    boolean mIsEstimateSlidingDrawer;
    private boolean mIsInComingCall;
    private boolean mIsLauncherAddtoHome;
    boolean mIsLauncherAllProgram;
    private boolean mIsListAdapterReady;
    private boolean mIsLoading;
    private boolean mIsLockEnterThumbnailMode;
    private boolean mIsMenuKeyDown;
    boolean mIsOpenPersonalizeBySetting;
    private boolean mIsOpenSlideWhenLeaveLaunch;
    private boolean mIsPause;
    private boolean mIsPressHomeKey;
    private boolean mIsRessumeNeedCloseSliderAndStartActivity;
    private boolean mIsSearchCategory;
    private boolean mIsShowTutorialNotice;
    private boolean mIsTouchDownNeedCacheBtn;
    private boolean mIsWorkspaceChanging;
    private final KeyguardIntentReceiver mKeyguardIntentReceiver;
    private long mLauncherLeftTime;
    private LeapController mLeapController;
    private AddListAdapter mListAdapter;
    private long mLoadingTime;
    private CellInfo mMenuAddInfo;
    private boolean mNeedLiveWallpaperSpin;
    private Configuration mNewConfig;
    private final ContentObserver mObserver;
    private boolean mOnConfigChangedReloading;
    private boolean mOnConfigurationChanged;
    private boolean mOnOrientationChange;
    private Set<Menu> mOptionsMenuChanged;
    private ArrayList<Runnable> mOrientationChangedRunnables;
    private OrientationIdleHandler mOrientationIdleHandler;
    private boolean mPageSelect;
    private boolean mPauseByLoaders;
    private Runnable mPrepareScreensCache;
    private int mPrepareScreensCacheIndex;
    private int mPriority;
    private AddWidgetLayout mProgramListLayout;
    private Runnable mResetLaunchState;
    private boolean mRestoring;
    private Bundle mSavedInstanceState;
    private Bundle mSavedState;
    private final SceneCleanReceiver mSceneCleanReceiver;
    private ScreenReceiver mScreenReceiver;
    private ScrollMonitor mScrollMonitor;
    private SensorManager mSensorManager;
    int mSettingWallpaper;
    private Cursor mSettingsCursor;
    private SilderReceiver mSilderReceiver;
    private boolean mSkipUiModeChange;
    private boolean mSkipUnlockAnimation;
    private SlideController mSlideController;
    long mStartDrawingThreadTime;
    long mStartDrawingTime;
    long mStartOrientation;
    private final SummaryReceiver mSummaryReceiver;
    private final ThemeChangeReceiver mThemeChangeReceiver;
    private ArrayList<Long> mThreadIntervals;
    private boolean mTiltEnabled;
    private ExSensorEventListener mTiltListener;
    private List<TiltObserver> mTiltObservers;
    private Sensor mTiltSensor;
    private boolean mTiltSettingEnable;
    private TiltSettingsObserver mTiltSettingsObserver;
    private HashMap<WeakReference<View>, Object> mTutorialNoticeViews;
    private ArrayList<Long> mTwoStartIntervals;
    RosieUnlockAnimationListener mUnlockAnimListener;
    private boolean mWaitingForResult;
    private BroadcastReceiver mWeatherAnimationNotify;
    private boolean mWeatherAnimationNotifyRegistered;
    private WidgetTilter mWidgetTilter;
    protected WidgetsManager mWidgetsManager;
    private boolean mWillLeave;
    private boolean mWindowFocus;
    public Workspace mWorkspace;
    private int orientationCount;
    private RosiePhoneStateListener phoneStateListener;
    private final Runnable registerTelephonyManager;
    private boolean showLoadingCursor;
    private TelephonyManager telephonyManager;

    enum AppTabType {
        allApp,
        frequent,
        downloaded,
        unknown
    }

    public interface TiltObserver {
        void onTilt(float f, float f2);
    }

    static {
        $assertionsDisabled = !Launcher.class.desiredAssertionStatus();
        localLOGD = SettingUtil.localLOGD;
        sModel = new LauncherModel();
        sLock = new Object();
        sScreen = Workspace.getDefaultScreenIndex();
        sWidgetPackageManager = null;
        sDefaultAppWidgetHost = null;
        sRefLauncher = new WeakReference<>(null);
        mProgramListId = R.id.content_grid;
        mSettingWidgetCellInfo = null;
        needActivityResult = false;
        requestCodeBackup = 0;
        resultCodeBackup = 0;
        dataBackup = null;
        sUseWallpaperService = true;
        mMiddleClickButton = -1;
        ifAddButtonbar = false;
        mUiMode = 0;
        sBackgroundStopIntent = new Intent("com.htc.content.Intent.ACTION_BACKGROUND_OP_STOP");
        sBackgroundGoIntent = new Intent("com.htc.content.Intent.ACTION_BACKGROUND_OP_GO");
        sWeatherAnimationDoneIntent = new Intent(ACTION_WEATHER_ANIMATION_DONE);
        ACTION_SUMMARY_CHANGES = new String[]{"com.htc.intent.ACTION_PERSONALIZE_SCENE_CHANGED", "com.htc.intent.ACTION_PERSONALIZE_WALLPAPER_CHANGED", "com.htc.intent.ACTION_PERSONALIZE_SKIN_CHANGED", ACTION_PERSONALIZE_ADD_WIDGET_TO_HOME_CHANGED, ACTION_PERSONALIZE_ADD_APP_TO_HOME_CHANGED, ACTION_PERSONALIZE_ADD_SHORTCUT_TO_HOME_CHANGED, ACTION_PERSONALIZE_ADD_FOLDER_TO_HOME_CHANGED, "com.htc.intent.ACTION_PERSONALIZE_SOUND_SET_CHANGED", "com.htc.intent.ACTION_PERSONALIZE_RINGTONE_CHANGED", "com.htc.intent.ACTION_PERSONALIZE_NOTIFICATION_SOUNDS_CHANGED", "com.htc.intent.ACTION_PERSONALIZE_ALARM_CHANGED"};
    }

    static /* synthetic */ int access$3108(Launcher x0) {
        int i = x0.mPrepareScreensCacheIndex;
        x0.mPrepareScreensCacheIndex = i + 1;
        return i;
    }

    static /* synthetic */ int access$8112(Launcher x0, int x1) {
        int i = x0.mFinishLoading + x1;
        x0.mFinishLoading = i;
        return i;
    }

    static /* synthetic */ int access$8910(Launcher x0) {
        int i = x0.orientationCount;
        x0.orientationCount = i - 1;
        return i;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Launcher() {
        super(AUTHORITY);
        this.forceBuildCache = false;
        this.mApplicationsReceiver = new ApplicationsIntentReceiver();
        this.mObserver = new FavoritesChangeObserver();
        this.mAppWidgetResetObserver = new AppWidgetResetObserver();
        this.mIsSearchCategory = false;
        this.mHtcWidgetUpdateReceiver = new HtcWidgetUpdateReceiver();
        this.mKeyguardIntentReceiver = new KeyguardIntentReceiver();
        this.mThemeChangeReceiver = new ThemeChangeReceiver();
        this.mSceneCleanReceiver = new SceneCleanReceiver();
        this.mSummaryReceiver = new SummaryReceiver();
        this.mWidgetsManager = null;
        this.showLoadingCursor = false;
        this.mIsLoading = true;
        this.mCurrentOrientation = -1;
        this.mStartOrientation = -1L;
        this.mWillLeave = false;
        this.mIsShowTutorialNotice = false;
        this.mDesktopItemController = null;
        this.mOrientationChangedRunnables = new ArrayList<>();
        this.mCellCoordinates = new int[2];
        this.mDesktopLocked = true;
        this.mDefaultKeySsb = null;
        this.mDestroying = false;
        this.mDestroyed = false;
        this.mOptionsMenuChanged = new HashSet();
        this.mOnConfigChangedReloading = false;
        this.mIsEstimateSlidingDrawer = false;
        this.mIsAllProgramSliding = false;
        this.mStartDrawingTime = 0L;
        this.mIntervals = new ArrayList<>();
        this.mThreadIntervals = new ArrayList<>();
        this.mTwoStartIntervals = new ArrayList<>();
        this.currentAppTab = AppTabType.allApp;
        this.launchAppType = LoggingEvents.EXTRA_CALLING_APP_NAME;
        this.mSilderReceiver = new SilderReceiver();
        this.mIsListAdapterReady = false;
        this.mIsPause = false;
        this.isNeedLaunchAddToHome = false;
        this.isShowAllProgramSearchBar = false;
        this.mAddHtcWidgetByOtherActivity = false;
        this.mIsLauncherAllProgram = false;
        this.mIsLauncherAddtoHome = false;
        this.mIsTouchDownNeedCacheBtn = false;
        this.mIsPressHomeKey = false;
        this.mDrawerContentId = 0;
        this.mIsAllowMoveToDefaultScreen = true;
        this.mIsRessumeNeedCloseSliderAndStartActivity = false;
        this.mIsOpenSlideWhenLeaveLaunch = false;
        this.mIsLockEnterThumbnailMode = false;
        this.mHandler = new LauncherHandler();
        this.isUakKeyProcessed = false;
        this.mLauncherLeftTime = 0L;
        this.orientationCount = 0;
        this.mIsMenuKeyDown = false;
        this.mApplicationsAdapter = null;
        this.mOnOrientationChange = false;
        this.mOnConfigurationChanged = false;
        this.mSkipUiModeChange = false;
        this.isSupportLandscape = false;
        this.mIsConfigurationChanged = false;
        this.mChangingOrientation = false;
        this.mFinishLoading = 0;
        this.mLoadingTime = 0L;
        this.lastDialog = null;
        this.mCurrentLocale = LoggingEvents.EXTRA_CALLING_APP_NAME;
        this.mSettingsCursor = null;
        this.a = 0L;
        this.mBackgroundTrafficLight = true;
        this.mBackgroundGo = new Runnable() { // from class: com.htc.launcher.Launcher.3
            @Override // java.lang.Runnable
            public void run() {
                Launcher.this.setBackgroundTrafficLight(true);
            }
        };
        this.registerTelephonyManager = new Runnable() { // from class: com.htc.launcher.Launcher.4
            @Override // java.lang.Runnable
            public void run() {
                Logger.d(Launcher.LOG_TAG, "[ROSIE_INIT] registerTelephonyManager() - get telephonyManager");
                if (Launcher.this.telephonyManager == null) {
                    Launcher.this.telephonyManager = (TelephonyManager) Launcher.this.getSystemService("phone");
                    if (Launcher.this.telephonyManager != null) {
                        Launcher.this.telephonyManager.listen(Launcher.this.phoneStateListener, 32);
                    } else {
                        Logger.e(Launcher.LOG_TAG, "cannot get telephonyManager");
                    }
                }
            }
        };
        this.isKeyguardOnWhenOnResume = false;
        this.RAISED_PRIORITY = -8;
        this.mPriority = Process.getThreadPriority(Process.myTid());
        this.mPauseByLoaders = false;
        this.mFreezeable = true;
        this.isButtonCanPress = true;
        this.lastComparator4AllAppsTab = FilterableAndSortableApplicationInfoList.ALPHABET;
        this.mBackgroundTrafficLightReceiver = new BroadcastReceiver() { // from class: com.htc.launcher.Launcher.9
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent data) {
            }
        };
        this.mIsOpenPersonalizeBySetting = false;
        this.mTutorialNoticeViews = null;
        this.mPrepareScreensCacheIndex = 0;
        this.mPrepareScreensCache = new Runnable() { // from class: com.htc.launcher.Launcher.10
            @Override // java.lang.Runnable
            public void run() {
                int count = Launcher.this.mWorkspace.getChildCount();
                if (Launcher.this.mPrepareScreensCacheIndex < count) {
                    Launcher.access$3108(Launcher.this);
                }
                if (Launcher.this.mPrepareScreensCacheIndex != count) {
                    Launcher.this.runInNextEvLoop(this);
                } else {
                    end();
                }
            }

            private void end() {
                Launcher.this.mIsLoading = false;
                if (Launcher.this.mFxWorkspace != null) {
                    Launcher.this.mFxWorkspace.show();
                    Launcher.this.mFxWorkspace.updateInitFrame();
                    Launcher.this.mFxWorkspace.changeScreensVisibility(true);
                }
                if (Launcher.localLOGD) {
                    Log.d(Launcher.LOG_TAG, " loading time total: " + (System.currentTimeMillis() - Launcher.this.mLoadingTime));
                }
                Launcher.this.mWorkspace.drawAllScreens();
                Launcher.this.mWorkspace.unlock();
                if (!Launcher.this.isKeyguardOnWhenOnResume && !Launcher.this.mIsPause) {
                    Launcher.this.mFxWidgetManager.resumeWidgets(Launcher.getScreen());
                }
                Launcher.this.mOnConfigChangedReloading = false;
                Launcher.this.mPrepareScreensCacheIndex = 0;
                if (Launcher.localLOGD) {
                    Log.d(Launcher.LOG_TAG, "Send intent(com.htc.launcher.intent.LOADING_COMPLETE)");
                }
                Intent intent = new Intent(Launcher.INTENT_LOADING_COMPLETE);
                Launcher.this.sendBroadcast(intent);
                Thread thread = new Thread() { // from class: com.htc.launcher.Launcher.10.1
                    @Override // java.lang.Thread, java.lang.Runnable
                    public void run() {
                        Settings.System.putInt(Launcher.this.getContentResolver(), "rosie_complete_loading", 1);
                    }
                };
                thread.start();
                Launcher.this.getDesktopItemController().updatePendingSyncPackages();
                Launcher.this.mHandler.sendEmptyMessageDelayed(Launcher.DISMISS_LOADING, 200L);
            }
        };
        this.mActivityLaunched = false;
        this.mResetLaunchState = new Runnable() { // from class: com.htc.launcher.Launcher.11
            @Override // java.lang.Runnable
            public void run() {
                Launcher.this.mActivityLaunched = false;
            }
        };
        this.mIsWorkspaceChanging = false;
        this.ask2NotifyHint = false;
        this.mOrientationIdleHandler = new OrientationIdleHandler();
        this.mEmptyRunnable = new Runnable() { // from class: com.htc.launcher.Launcher.21
            @Override // java.lang.Runnable
            public void run() {
            }
        };
        this.mPageSelect = false;
        this.mWeatherAnimationNotify = new BroadcastReceiver() { // from class: com.htc.launcher.Launcher.26
            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent data) {
                if (Launcher.localLOGD) {
                    Log.d(Launcher.LOG_TAG, "get weather wallpaper stop receive");
                }
                if (!Launcher.this.mIsPause) {
                    Launcher.this.mWidgetsManager.fireVisible(Launcher.this.mWorkspace.getCurrentScreenIndex());
                }
            }
        };
        this.mWeatherAnimationNotifyRegistered = false;
        this.mSettingWallpaper = 0;
        this.mIsInComingCall = false;
        this.phoneStateListener = new RosiePhoneStateListener();
        this.mTiltSettingsObserver = null;
        this.mTiltEnabled = false;
        this.mTiltObservers = new ArrayList();
        this.mTiltListener = new ExSensorEventListener();
        this.mFreezeTilt = false;
        this.mWidgetTilter = new WidgetTilter();
        this.mSkipUnlockAnimation = false;
        this.mNeedLiveWallpaperSpin = false;
        this.lastTabTag = null;
    }

    public DesktopItemController getDesktopItemController() {
        return this.mDesktopItemController;
    }

    public CellInfo getAddItemCellInfo() {
        return this.mAddItemCellInfo;
    }

    public boolean isRestoring() {
        return this.mRestoring;
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onCreate(Bundle savedInstanceState) {
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - enter");
        OperatorTabManager.getInstance().setContext(this);
        setResources(OperatorTabManager.getInstance().getResources());
        setGId(1);
        this.isSupportLandscape = SettingUtil.isSupportLandscape();
        try {
            File file = new File("/data/data/", "AllProgramSliding");
            if (file.exists()) {
                this.mIsEstimateSlidingDrawer = true;
                if (localLOGD) {
                    Log.d("Handle buttons", "enable All program Sliding estimation");
                }
            }
        } catch (Exception e) {
        }
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - get Collator");
        Utilities.sCollator = Collator.getInstance(getResources().getConfiguration().locale);
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - get sKeyguardManager");
        if (sKeyguardManager == null) {
            sKeyguardManager = (KeyguardManager) getSystemService("keyguard");
        }
        this.mCurrentOrientation = getResources().getConfiguration().orientation;
        sRefLauncher = new WeakReference<>(this);
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - SettingUtil.loadSettings()");
        SettingUtil.loadSettings(this);
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - new ScrollMonitor(this)");
        this.mScrollMonitor = new ScrollMonitor(this);
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - new OrientationMonitor(this)");
        sOrientationMonitor = new OrientationMonitor(this);
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - mHandler.getLooper().setMessageLogging()");
        if (SettingUtil.sIsEnableLoopLog) {
            this.mHandler.getLooper().setMessageLogging(new LogPrinter(2, LOG_TAG));
        }
        new RootAsyncTask();
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - selectWallpaperConfig()");
        selectWallpaperConfig();
        if (SettingUtil.forceRGB32Window()) {
            getWindow().setFormat(-3);
        }
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - super.onCreate()");
        super.onCreate(savedInstanceState);
        this.mInflater = getLayoutInflater();
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - FxSkinUtility.loadSkinResource()");
        FxSkinUtility.loadSkinResource(this, getResources().getConfiguration().orientation);
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - get AppWidgetManager instance()");
        this.mAppWidgetManager = AppWidgetManager.getInstance(this);
        this.showLoadingCursor = true;
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - lockOrientation()");
        lockOrientation();
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - getDefaultAppWidgetHostInstance()");
        this.mAppWidgetHost = getDefaultAppWidgetHostInstance(this);
        this.mAppWidgetHost.startListening();
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - checkLocale()");
        boolean isLocaleChanged = checkLocale(this);
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - getDefaultDisplay()");
        Display display = getWindowManager().getDefaultDisplay();
        sFxPathFinder = FxPathFinder.getInstance(display);
        sFxSceneManager = FxSceneManager.getInstance(display);
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - setWallpaperDimension()");
        setWallpaperDimension(display);
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - getWindow()");
        Window window = getWindow();
        WindowManager.LayoutParams attr = window.getAttributes();
        attr.flags |= 256;
        attr.flags |= 134217728;
        window.setAttributes(attr);
        setContentView(R.layout.launcher);
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - setupViews()");
        setupViews();
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - initTutorialNotice()");
        initTutorialNotice();
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - registerIntentReceivers()");
        registerIntentReceivers();
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - registerContentObservers()");
        registerContentObservers();
        runInNextEvLoop(this.registerTelephonyManager);
        this.mSavedState = savedInstanceState;
        if (this.mSavedState != null) {
            this.mSavedState.putBoolean(RUNTIME_STATE_ALL_APPS_FOLDER, false);
        }
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - restoreState()");
        restoreState(this.mSavedState);
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - new WidgetsManager()");
        this.mWidgetsManager = new WidgetsManager();
        this.mWidgetsManager.setWidgetPackageManager(WidgetPackageManager.instanceNoScan());
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - new HostWidgetManager()");
        if (this.mFxWidgetManager == null) {
            this.mFxWidgetManager = new HostWidgetManager(new HostActivityBridge(this, this.mFxWorkspace.getViewObject()));
        }
        WidgetPackageManager.instanceNoScan().setFxWidgetManager(this.mFxWidgetManager);
        XmlUtils.instance().setFxWidgetManager(this.mFxWidgetManager);
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - new DesktopItemController()");
        if (this.mDesktopItemController == null) {
            this.mDesktopItemController = new DesktopItemController(this, this.mWorkspace, this.mFxWorkspace, this.mFxWidgetManager, this.mSlideController);
            this.mDesktopItemController.setLegacyFloatingEnv(this.mDragLayer);
            this.mDesktopItemController.setFxFloatingEnv(this.mFxWorkspace);
        }
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - startLoaders()");
        startLoaders(isLocaleChanged);
        if (!this.mRestoring) {
            this.mPauseByLoaders = true;
        }
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - new SpannableStringBuilder");
        this.mDefaultKeySsb = new SpannableStringBuilder();
        Selection.setSelection(this.mDefaultKeySsb, 0);
        window.setBackgroundDrawable(null);
        window.getDecorView().setBackgroundDrawable(null);
        this.mTiltSettingsObserver = new TiltSettingsObserver();
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - new TiltSettingQueryAsyncTask.execute");
        new TiltSettingQueryAsyncTask().execute(new Void[0]);
        loadLocaleAndSimConfigs();
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.onCreate() - exit");
    }

    private class TiltSettingQueryAsyncTask extends AsyncTask<Void, Void, Void> {
        private TiltSettingQueryAsyncTask() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Void doInBackground(Void... Void) {
            Launcher.this.loadSettings();
            return null;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Void result) {
            if (Launcher.this.mSettingsCursor != null) {
                Launcher.this.addTiltSettingObserver();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void loadSettings() {
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.loadSettings() - enter");
        this.mSettingsCursor = getContentResolver().query(Settings.System.CONTENT_URI, null, "(name=?)", new String[]{"htc_3d_home_screen"}, null);
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.loadSettings() - exit");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void addTiltSettingObserver() {
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.addSettingObserver() - enter");
        this.mContentQueryMap = new ContentQueryMap(this.mSettingsCursor, "name", true, null);
        this.mContentQueryMap.addObserver(this.mTiltSettingsObserver);
        this.mTiltSettingEnable = Settings.System.getBoolean(getContentResolver(), "htc_3d_home_screen", this.mTiltSettingEnable);
        this.mTiltListener.reset();
        this.mWidgetTilter.reset();
        Logger.d(LOG_TAG, "[ROSIE_INIT] Launcher.addSettingObserver() - exit");
    }

    public static synchronized LauncherAppWidgetHost getDefaultAppWidgetHostInstance(Context ctx) {
        LauncherAppWidgetHost launcherAppWidgetHost;
        synchronized (Launcher.class) {
            if (sDefaultAppWidgetHost == null) {
                sDefaultAppWidgetHost = new LauncherAppWidgetHost(ctx.getApplicationContext(), APPWIDGET_HOST_ID);
            }
            launcherAppWidgetHost = sDefaultAppWidgetHost;
        }
        return launcherAppWidgetHost;
    }

    private void selectWallpaperConfig() {
        if (sUseWallpaperService) {
            sUseWallpaperService = SystemProperties.getBoolean("persist.debug.rosie.wall", true);
            if (localLOGD) {
                Log.d(LOG_TAG, "use wallpaper service:" + sUseWallpaperService);
            }
        }
        if (sUseWallpaperService) {
            getWindow().addFlags(1048576);
            getWindow().setFormat(-3);
        }
    }

    protected void onStop() {
        if (this.mDragLayer != null) {
            this.mDragLayer.abortDrag();
        }
        super.onStop();
    }

    private void initTutorialNotice() {
        SharedPreferences preferences = getSharedPreferences("launcher", 0);
        Configuration configuration = getResources().getConfiguration();
        this.mIsShowTutorialNotice = preferences.getBoolean(KEY_TUTORIAL_NOTICE, true);
        if (localLOGD) {
            Log.d(LOG_TAG, "initTutorialNotice() , mIsShowTutorialNotice = " + this.mIsShowTutorialNotice);
        }
        if (this.mIsShowTutorialNotice) {
            showTutorialNotice();
        } else {
            hideTutorialNotice();
        }
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("locale", configuration.locale.toString());
        editor.putInt(KEY_MCC, configuration.mcc);
        editor.putInt(KEY_MNC, configuration.mcc);
        try {
            editor.apply();
        } catch (Exception e) {
        }
    }

    public static int getScreen() {
        int i;
        synchronized (sLock) {
            i = sScreen;
        }
        return i;
    }

    static void setScreen(int screen) {
        synchronized (sLock) {
            sScreen = screen;
        }
    }

    private void startLoaders(boolean configChanged) {
        boolean loadApplications = sModel.loadApplications(true, this, configChanged);
        sModel.loadUserItems(configChanged ? false : true, this, configChanged, loadApplications);
        Log.d(DEBUG_DB_TAG, "startLoaders(" + configChanged + ")");
        this.mRestoring = false;
    }

    private void setWallpaperDimension(Display display) {
        int hintWidth;
        int hintHeight;
        IBinder binder = ServiceManager.getService("wallpaper");
        IWallpaperManager wallpaperService = IWallpaperManager.Stub.asInterface(binder);
        if (SettingUtil.isTabletDevice()) {
            Display display2 = getWindowManager().getDefaultDisplay();
            int maxDimension = Math.max(display2.getWidth(), display2.getHeight());
            hintHeight = maxDimension;
            hintWidth = maxDimension;
        } else {
            boolean isPortrait = display.getWidth() < display.getHeight();
            int width = isPortrait ? display.getWidth() : display.getHeight();
            int height = isPortrait ? display.getHeight() : display.getWidth();
            hintWidth = width * SettingUtil.sWallpaperScreensSpan;
            hintHeight = height;
        }
        try {
            wallpaperService.setDimensionHints(hintWidth, hintHeight);
        } catch (RemoteException e) {
        }
    }

    private void addInterval(long duration) {
        this.mIntervals.add(Long.valueOf(duration));
    }

    private void addThreadInterval(long duration) {
        this.mThreadIntervals.add(Long.valueOf(duration));
    }

    private void addTwoStartInterval(long duration) {
        this.mTwoStartIntervals.add(Long.valueOf(duration));
    }

    protected void startDispatchDraw() {
        if (this.mIsAllProgramSliding) {
            this.a = this.mStartDrawingTime;
            this.mStartDrawingTime = System.currentTimeMillis();
            this.mStartDrawingThreadTime = Debug.threadCpuTimeNanos() / 1000000;
            addTwoStartInterval(this.mStartDrawingTime - this.a);
        }
    }

    protected void endDispatchDraw() {
        if (this.mIsAllProgramSliding) {
            long currentTime = System.currentTimeMillis();
            long currentThreadTime = Debug.threadCpuTimeNanos() / 1000000;
            long dt = currentTime - this.mStartDrawingTime;
            long thread_dt = currentThreadTime - this.mStartDrawingThreadTime;
            addInterval(dt);
            addThreadInterval(thread_dt);
        }
    }

    protected void writeAllProgramLogs(StringBuffer buffer) {
        StringBuffer LogBuf = new StringBuffer();
        long total = 0;
        LogBuf.append("Time intervals: \n");
        for (int i = 0; i < this.mIntervals.size(); i++) {
            long interval = this.mIntervals.get(i).longValue();
            total += interval;
            LogBuf.append(interval).append("\t");
        }
        LogBuf.append("\nThread intervals: \n");
        for (int i2 = 0; i2 < this.mThreadIntervals.size(); i2++) {
            LogBuf.append(this.mThreadIntervals.get(i2)).append("\t");
        }
        LogBuf.append("\nCPU intervals: \n");
        for (int i3 = 0; i3 < this.mTwoStartIntervals.size(); i3++) {
            LogBuf.append(this.mTwoStartIntervals.get(i3)).append("\t");
        }
        LogBuf.append("\nDumpProcess: \n");
        LogBuf.append(buffer).append("\n");
        final String fs = LogBuf.toString();
        Thread thread = new Thread() { // from class: com.htc.launcher.Launcher.1
            @Override // java.lang.Thread, java.lang.Runnable
            public void run() {
                Process.setThreadPriority(19);
                try {
                    String filename = "/data/misc/AllProgramSlidingLogs_" + System.currentTimeMillis();
                    BufferedWriter out = new BufferedWriter(new FileWriter(filename, true));
                    out.write(fs);
                    out.close();
                } catch (IOException e) {
                    Log.e(Launcher.LOG_TAG, e.getMessage(), e);
                }
            }
        };
        thread.start();
        this.mThreadIntervals.clear();
        this.mTwoStartIntervals.clear();
        this.mIntervals.clear();
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onActivityResult(final int requestCode, final int resultCode, final Intent data) {
        int appWidgetId;
        if (this.mOnOrientationChange && (requestCode == 501 || requestCode == 500 || requestCode == 1)) {
            needActivityResult = true;
            requestCodeBackup = requestCode;
            resultCodeBackup = resultCode;
            dataBackup = data;
            return;
        }
        needActivityResult = false;
        requestCodeBackup = 0;
        resultCodeBackup = 0;
        dataBackup = null;
        if (requestCode == 13 || requestCode == 14) {
            if (resultCode == -1) {
                onPickItem(requestCode, data);
                return;
            }
            return;
        }
        if (!this.mAddHtcWidgetByOtherActivity) {
            closeAllApplications();
        }
        if (requestCode != 7 && data != null) {
            closeAllApplications();
        }
        if (resultCode == -1) {
            switch (requestCode) {
                case 5:
                case LoggingEvents.VoiceIme.CANCEL_DURING_ERROR /* 12 */:
                case 500:
                    Logger.showMeWidget(this, "topic_tag-home_screen-widgets");
                    break;
            }
        }
        if (!this.mFxWidgetManager.dispatchActivityResult(requestCode, resultCode, data)) {
            if (requestCode >= 10000) {
                runInNextEvLoop(new Runnable() { // from class: com.htc.launcher.Launcher.2
                    @Override // java.lang.Runnable
                    public void run() {
                        Launcher.this.onWidgetActivityResult(requestCode, resultCode, data);
                    }
                });
            } else if (requestCode == 501) {
                this.mDesktopItemController.onCompleteEditLegacy(resultCode, data, mSettingWidgetCellInfo);
                this.mWorkspace.unlock();
                this.mWaitingForResult = false;
                mSettingWidgetCellInfo = null;
                if (localLOGD) {
                    Log.d(LOG_TAG, "[ATS][com.htc.launcher][press_hold_widget][edited]");
                    return;
                }
                return;
            }
            if (data != null || this.mAddHtcWidgetByOtherActivity) {
                if (resultCode == -1) {
                    if (this.mAddItemCellInfo == null) {
                        this.mAddItemCellInfo = this.mWorkspace.findAllVacantCells(null);
                    }
                    onPickItem(requestCode, data);
                } else if (requestCode == 9 && resultCode == 0 && data != null && (appWidgetId = data.getIntExtra("appWidgetId", -1)) != -1) {
                    this.mAppWidgetHost.deleteAppWidgetId(appWidgetId);
                }
                this.mWaitingForResult = false;
            }
        }
    }

    class AddFxWidgetRunnable implements Runnable {
        CellInfo mCellInfo;
        Intent mIntent;

        public AddFxWidgetRunnable(Intent intent, CellInfo info) {
            this.mIntent = intent;
            this.mCellInfo = info;
        }

        @Override // java.lang.Runnable
        public void run() {
            Launcher.this.mDesktopItemController.addFxWidget(this.mIntent, this.mCellInfo, true);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void onPickItem(int request, Intent data) {
        switch (request) {
            case 1:
                if (data != null) {
                    this.mDesktopItemController.completeAddShortcut(data, this.mAddItemCellInfo, !this.mDesktopLocked);
                    break;
                }
                break;
            case 4:
                this.mDesktopItemController.completeAddLiveFolder(data, this.mAddItemCellInfo, !this.mDesktopLocked);
                break;
            case 5:
                this.mDesktopItemController.completeAddAppWidget(data, this.mAddItemCellInfo, !this.mDesktopLocked);
                break;
            case 6:
                this.mDesktopItemController.completeAddApplication(this, data, this.mAddItemCellInfo, !this.mDesktopLocked);
                break;
            case 7:
                this.mDesktopItemController.addShortcut(data);
                break;
            case LoggingEvents.VoiceIme.SWIPE_HINT_DISPLAYED /* 8 */:
                this.mDesktopItemController.addLiveFolder(data);
                break;
            case LoggingEvents.VoiceIme.PUNCTUATION_HINT_DISPLAYED /* 9 */:
                this.mDesktopItemController.addAppWidget(data);
                break;
            case LoggingEvents.VoiceIme.CANCEL_DURING_WORKING /* 11 */:
                this.mDesktopItemController.completeAddShortcut(data, this.mAddItemCellInfo, !this.mDesktopLocked);
                break;
            case LoggingEvents.VoiceIme.CANCEL_DURING_ERROR /* 12 */:
                if ((getResources().getConfiguration().orientation == 1) == FxWorkspace.isPortrait()) {
                    this.mDesktopItemController.addFxWidget(data, this.mAddItemCellInfo, false);
                    break;
                } else {
                    if (localLOGD) {
                        Logger.d(LOG_TAG, "REQUEST_PICK_FXWIDGET when orientation changed");
                    }
                    this.mOrientationChangedRunnables.add(new AddFxWidgetRunnable(data, this.mAddItemCellInfo));
                    break;
                }
            case LoggingEvents.VoiceIme.ERROR /* 13 */:
                RingtoneManager.setActualDefaultRingtoneUri(this, 1, (Uri) data.getExtra("android.intent.extra.ringtone.PICKED_URI"));
                break;
            case LoggingEvents.VoiceIme.START /* 14 */:
                RingtoneManager.setActualDefaultRingtoneUri(this, 2, (Uri) data.getExtra("android.intent.extra.ringtone.PICKED_URI"));
                break;
            case 500:
                int itemType = data.getIntExtra("item_type", -1);
                boolean waitForActivityResult = data.getBooleanExtra("waitForActivityResult", false);
                if (itemType > 0) {
                    Intent backIntent = null;
                    if (waitForActivityResult) {
                        backIntent = data;
                    }
                    if (this.isSupportLandscape) {
                        this.mOrientationIdleHandler.flush();
                    }
                    this.mDesktopItemController.addWidget(sWidgetPackageManager.newWidget(itemType, null, -1L), backIntent, this.mAddItemCellInfo);
                    break;
                }
                break;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void runInNextEvLoop(Runnable runnable) {
        this.mHandler.post(runnable);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onWidgetActivityResult(int requestCode, int resultCode, Intent data) {
        if (localLOGD) {
            Log.d(LOG_TAG, "requestCode(widgetId + OFFSET) - " + requestCode);
        }
        ArrayList<ItemInfo> items = sModel.getDesktopItems();
        if (items != null) {
            Iterator i$ = items.iterator();
            while (i$.hasNext()) {
                ItemInfo item = i$.next();
                if (item.id + BACKGROUND_GO_DELAY == requestCode && (item instanceof WidgetProxy)) {
                    ((WidgetProxy) item).onActivityResult(requestCode, resultCode, data);
                    return;
                }
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void onWindowFocusChanged(boolean focus) {
        if (focus) {
            WallpaperManager wallpaperMgr = WallpaperManager.getInstance(this);
            if (this.mNeedLiveWallpaperSpin && !this.mChangingOrientation) {
                wallpaperMgr.pauseWallpaper(this.mWorkspace.getWindowToken(), true);
            } else {
                wallpaperMgr.pauseWallpaper(this.mWorkspace.getWindowToken(), false);
                wallpaperMgr.sendWallpaperCommand(this.mWorkspace.getWindowToken(), "com.htc.android.wallpaper.resume", 0, 0, 0, null);
            }
            this.mNeedLiveWallpaperSpin = false;
        }
        this.mWindowFocus = focus;
        if (localLOGD) {
            Log.d(LOG_TAG, "Activity.onWindowFocusChanged " + focus + ", c? " + this.mChangingOrientation);
        }
        Workspace ws = getWorkspace();
        if (ws != null) {
            if (focus) {
                ws.setDescendantFocusability(131072);
            } else {
                ws.setDescendantFocusability(393216);
                stop3DAnimation(true);
            }
        }
    }

    void setBackgroundTrafficLight(boolean light) {
    }

    private void showTrafficLight(boolean light) {
    }

    private void runDelayed(Runnable action, long delayMillis) {
        if (this.mHandler != null) {
            this.mHandler.removeCallbacks(action);
            this.mHandler.postDelayed(action, delayMillis);
            return;
        }
        throw new IllegalStateException();
    }

    private void cancelDelayed(Runnable action) {
        if (this.mHandler != null) {
            this.mHandler.removeCallbacks(action);
            return;
        }
        throw new IllegalStateException();
    }

    public void onLowMemory() {
        if (this.mFxWorkspace != null) {
            this.mFxWorkspace.onLowMemory();
        }
        Log.w(LOG_TAG, "TODO: onLowMemory()");
        super.onLowMemory();
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onResume() {
        this.mDragLayer.getParent().requestLayout();
        this.mDragLayer.requestLayout();
        if (localLOGD) {
            Logger.d(LOG_TAG, "Launcher onResume()");
        }
        long begin = System.currentTimeMillis();
        this.mIsPause = false;
        if (this.mActivityLaunched) {
            Logger.d(LOG_TAG, "Launch done.");
            cancelDelayed(this.mResetLaunchState);
            this.mResetLaunchState.run();
        }
        this.isUakKeyProcessed = false;
        this.lastUakKeyCode = 0;
        if (this.mIsConfigurationChanged) {
            changeOrientation();
        } else if (!this.mChangingOrientation) {
            if (localLOGD) {
                Logger.d(LOG_TAG, "onResume handleOrientationChangedPendingTask");
            }
            handleOrientationChangedPendingTask();
        }
        this.mIsRessumeNeedCloseSliderAndStartActivity = false;
        super.onResume();
        if (!this.isSupportLandscape && getResources().getConfiguration().orientation == 2) {
            Logger.e(LOG_TAG, "orientation error, it is caused by framework do something wrong");
        }
        clearLaputaNavigateFlag();
        if (!this.mIsPressHomeKey) {
            Intent intent = new Intent(INTENT_RESUMED);
            sendBroadcast(intent);
        }
        boolean loadingOnResume = this.showLoadingCursor;
        if (this.showLoadingCursor) {
            this.showLoadingCursor = false;
            if (this.mFxWorkspace != null) {
                this.mFxWorkspace.hide();
            }
            if (localLOGD) {
                this.mLoadingTime = System.currentTimeMillis();
            }
            showDialog(100);
            this.mIsLoading = true;
        }
        if (this.mWillLeave) {
            this.mWillLeave = false;
        }
        if (this.mRestoring) {
            startLoaders(false);
        }
        if (this.mSavedState != null) {
            this.mSavedState.getBoolean(RUNTIME_STATE_ALL_APPS_FOLDER, false);
            this.mSavedState.getInt(RUNTIME_STATE_SLIDING_ALL_PROGRAM, 0);
        }
        boolean resumeByHomeKey = this.mIsPressHomeKey;
        this.mWorkspace.onRestoreInstanceState();
        this.mWorkspace.onResume();
        this.mWorkspace.getCurrentScreenIndexByScrollX();
        if (localLOGD) {
            Logger.d(LOG_TAG, "onResume() [onRestoreInstanceState] : diff - " + (System.currentTimeMillis() - begin));
        }
        this.mIsPressHomeKey = false;
        this.mAddHtcWidgetByOtherActivity = false;
        if (this.mIsSearchCategory) {
            this.mIsSearchCategory = false;
            if (localLOGD) {
                Logger.d(LOG_TAG, "OnResume: The intent is a Search category.");
            }
            onSearchRequested();
        }
        if (sKeyguardManager.keyguardIsShowing()) {
            if (localLOGD && localLOGD) {
                Logger.d(LOG_TAG, "keyguardIsShowing");
            }
            this.isKeyguardOnWhenOnResume = true;
            this.mWidgetsManager.onActivityResume(this, 50);
            this.mFxWidgetManager.onResumeInKeyguard(getScreen());
            this.mScrollMonitor.refreshFile();
            if (this.mLeapController.isLeapMode()) {
                this.mLeapController.endLeapMode();
            }
            this.mFxWorkspace.freeze(false);
            if (showUnlockAnimation()) {
                this.mFxWorkspace.show();
                this.mSlideController.stopSlide();
                if (this.mWorkspace.isDoingScroll()) {
                    this.mFxWorkspace.resetSink();
                    this.mWorkspace.setCurrentScreen(getScreen());
                    this.mWorkspace.endScroll();
                }
                this.mFxWorkspace.prepareUnlockAnimation(true);
            }
        } else {
            if (localLOGD) {
                Logger.d(LOG_TAG, "not keyguardIsShowing");
            }
            this.isKeyguardOnWhenOnResume = false;
            if (!this.mDrawer.isOpened()) {
                onResumeWhenKeyguardOff(resumeByHomeKey ? null : this);
                if (!resumeByHomeKey) {
                    this.mFxWidgetManager.resumeWidgets(getScreen());
                }
            } else {
                this.mIsRessumeNeedCloseSliderAndStartActivity = true;
            }
            this.mFxWorkspace.freeze(false);
        }
        if (!this.mDrawer.isOpened()) {
            this.mWorkspace.setIsRootNamespace(false);
        }
        PendingUIUpdate.instance().endScroll();
        if (this.mDrawer.isOpened() && this.mDrawerContentId == 1 && this.mListAdapter != null && this.mListAdapter.getLevel() == 0) {
            Thread thread = new Thread() { // from class: com.htc.launcher.Launcher.5
                @Override // java.lang.Thread, java.lang.Runnable
                public void run() {
                    Launcher.this.mListAdapter.updateSummary();
                    if (Launcher.this.mHandler != null) {
                        Launcher.this.mHandler.sendMessage(Launcher.this.mHandler.obtainMessage(Launcher.NOTIFY_DATA_SET_CHANGED));
                    }
                }
            };
            thread.start();
        }
        if (!loadingOnResume) {
            enableTilt(true);
        }
        if (this.mIsInComingCall) {
            this.mFxWorkspace.playPhoneAnim();
        }
        sModel.refreshUsageStats(this, true);
        SharedPreferences pref = getSharedPreferences("launcher", 0);
        pref.edit().putBoolean("resumed", true).apply();
        if (localLOGD) {
            Logger.d(LOG_TAG, "onResume() [finished] : diff - " + (System.currentTimeMillis() - begin));
        }
    }

    protected void onResumeWhenKeyguardOff(Launcher launcher) {
        this.mWidgetsManager.onActivityResume(launcher);
    }

    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (localLOGD) {
            Log.i(LOG_TAG, "Leaving");
        }
        this.mWillLeave = true;
    }

    void raisePriority(boolean raise) {
    }

    public boolean canFreeze() {
        return this.mFreezeable;
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected void onPause() {
        if (localLOGD) {
            Log.d(LOG_TAG, "Launcher onPause()");
        }
        this.mIsPause = true;
        this.mFreezeable = true;
        long begin = System.currentTimeMillis();
        this.isKeyguardOnWhenOnResume = false;
        boolean isInTabEditMode = this.lastTabTag != null;
        if (isInTabEditMode) {
            onTabEndSliding(this.lastTabTag);
        }
        PendingUIUpdate.instance().beginScroll();
        if (this.mPauseByLoaders) {
            this.mPauseByLoaders = false;
        }
        super.onPause();
        this.mIsRessumeNeedCloseSliderAndStartActivity = false;
        if (this.mDrawer.isOpened()) {
            android.app.WallpaperManager.getInstance(this).sendWallpaperCommand(this.mWorkspace.getWindowToken(), "com.htc.android.wallpaper.resume", 0, 0, 0, null);
        } else {
            closeDrawer(false);
        }
        this.mWidgetsManager.onActivityPause(this);
        dumpMemory();
        stop3DAnimation();
        if (this.mIsAllowMoveToDefaultScreen) {
            this.mSlideController.stopSlide();
            if (this.mWorkspace.isDoingScroll()) {
                this.mFxWorkspace.resetSink();
                this.mWorkspace.setCurrentScreen(getScreen());
                this.mWorkspace.endScroll();
            }
        }
        if (this.mWillLeave) {
            this.mLeapController.endLeapMode();
        } else {
            this.mLeapController.endAnimation();
        }
        this.mWorkspace.enableScroll(true);
        this.mWorkspace.onPause();
        raisePriority(false);
        this.mLauncherLeftTime = System.currentTimeMillis();
        this.mFxWorkspace.freeze(true);
        this.mFxWidgetManager.pauseWidgets(getScreen(), true);
        enableTilt(false);
        if (this.mIsInComingCall) {
            this.mFxWorkspace.stopPhoneAnim();
        }
        if (localLOGD) {
            Log.d(LOG_TAG, "onPause() [finished] : diff - " + (System.currentTimeMillis() - begin));
        }
    }

    private void dumpMemory() {
        if (localLOGD) {
            Runtime runtime = Runtime.getRuntime();
            if (localLOGD) {
                Log.d(LOG_MEM, "VM free memory : " + runtime.freeMemory());
            }
            if (localLOGD) {
                Log.d(LOG_MEM, "VM max memory : " + runtime.maxMemory());
            }
            if (localLOGD) {
                Log.d(LOG_MEM, "VM total memory : " + runtime.totalMemory());
            }
        }
    }

    public Object onRetainNonConfigurationInstance() {
        if (this.mBinder != null) {
            this.mBinder.mTerminate = true;
            return null;
        }
        return null;
    }

    private boolean acceptFilter() {
        InputMethodManager inputManager = (InputMethodManager) getSystemService("input_method");
        return !inputManager.isFullscreenMode();
    }

    public boolean onKeyUp(int keyCode, KeyEvent event) {
        boolean handled = super.onKeyUp(keyCode, event);
        if (keyCode == 4) {
            if (this.mDrawer.isOpened() && !this.mIsLauncherAddtoHome && this.isShowAllProgramSearchBar) {
                enableAppsSearch(false, null);
            }
        } else if (this.mDrawer.isOpened() && !this.isShowAllProgramSearchBar && event.isPrintingKey()) {
            if (!this.mIsLauncherAddtoHome) {
                if (localLOGD) {
                    Log.d(LOG_TAG, "Enable all app search, char is " + event.getDisplayLabel());
                }
                enableAppsSearch(true, event.getDisplayLabel() + LoggingEvents.EXTRA_CALLING_APP_NAME);
                if (SettingUtil.isUAKSupported() && this.lastUakKeyCode == keyCode) {
                    this.mHandler.removeMessages(MSG_KEY_LONG_PRESS_TIMEOUT);
                    this.isUakKeyProcessed = false;
                    this.lastUakKeyCode = 0;
                }
                return true;
            }
        } else if (SettingUtil.isUAKSupported() && keyCode >= 29 && keyCode <= 54 && !this.mIsMenuKeyDown) {
            if (!this.isUakKeyProcessed && !this.isShowAllProgramSearchBar && this.mHandler.hasMessages(MSG_KEY_LONG_PRESS_TIMEOUT)) {
                if (localLOGD) {
                    Log.d(LOG_TAG, "Enable UAK key launch, keyCode " + keyCode);
                }
                this.mHandler.removeMessages(MSG_KEY_LONG_PRESS_TIMEOUT);
                Intent uakIntent = new Intent("ACTION_UAK_TRIGGLE");
                uakIntent.putExtra("EXTRA_UAK_KEY_TYPE", (keyCode - 29) + 97);
                uakIntent.putExtra("EXTRA_UAK_KEY_EVENT_LONGPRESS", false);
                sendBroadcast(uakIntent);
                return true;
            }
            if (this.lastUakKeyCode == keyCode) {
                this.isUakKeyProcessed = false;
                this.lastUakKeyCode = 0;
            }
            return true;
        }
        return handled;
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        Intent intent;
        if (this.mDrawer.isOpened() && this.mDrawerContentId == 0 && (keyCode == 20 || keyCode == 19)) {
            final View searchBar = (ViewGroup) findViewById(R.id.search_bar);
            View allAppsContent = this.mAllAppsView.findViewById(this.mAllAppsView.getContentView());
            final InputMethodManager imm = (InputMethodManager) getSystemService("input_method");
            boolean hideSoftKeyboard = false;
            if ((allAppsContent.hasFocus() && keyCode == 19 && this.isShowAllProgramSearchBar) || (getCarouselHost().hasFocus() && keyCode == 19 && this.mApplicationsAdapter.getCount() == 0 && this.isShowAllProgramSearchBar)) {
                searchBar.requestFocus();
                searchBar.requestFocusFromTouch();
            } else if ((searchBar.hasFocus() && keyCode == 20 && this.mApplicationsAdapter.getCount() != 0) || (getCarouselHost().hasFocus() && keyCode == 19 && this.mApplicationsAdapter.getCount() != 0)) {
                allAppsContent.requestFocus();
                allAppsContent.requestFocusFromTouch();
                hideSoftKeyboard = true;
            } else if ((allAppsContent.hasFocus() && keyCode == 20) || (searchBar.hasFocus() && keyCode == 20 && this.mApplicationsAdapter.getCount() == 0)) {
                getCarouselWidget().requestFocus();
                getCarouselWidget().requestFocusFromTouch();
                hideSoftKeyboard = true;
            } else if (this.mApplicationsAdapter.getCount() == 0 && keyCode == 19 && this.isShowAllProgramSearchBar) {
                searchBar.requestFocus();
                searchBar.requestFocusFromTouch();
            } else if (this.mApplicationsAdapter.getCount() == 0) {
                getCarouselWidget().requestFocus();
                getCarouselWidget().requestFocusFromTouch();
                hideSoftKeyboard = true;
            } else {
                allAppsContent.requestFocus();
                allAppsContent.requestFocusFromTouch();
                hideSoftKeyboard = true;
            }
            if (hideSoftKeyboard) {
                runDelayed(new Runnable() { // from class: com.htc.launcher.Launcher.6
                    @Override // java.lang.Runnable
                    public void run() {
                        imm.hideSoftInputFromWindow(searchBar.getWindowToken(), 0);
                    }
                }, 400L);
            }
            return true;
        }
        boolean handled = super.onKeyDown(keyCode, event);
        if (!handled && acceptFilter() && keyCode != 66) {
            if (SettingUtil.isUAKSupported() && !this.mIsMenuKeyDown && !this.isShowAllProgramSearchBar && !this.mDrawer.isOpened() && !handled && keyCode >= 29 && keyCode <= 54 && !this.mHandler.hasMessages(MSG_KEY_LONG_PRESS_TIMEOUT) && !this.isUakKeyProcessed) {
                if (localLOGD) {
                    Log.d(LOG_TAG, "Send UAK key long press timeout message , keyCode " + keyCode);
                }
                this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(MSG_KEY_LONG_PRESS_TIMEOUT, keyCode, 0), 1500L);
            }
            boolean gotKey = TextKeyListener.getInstance().onKeyDown(this.mWorkspace, this.mDefaultKeySsb, keyCode, event);
            if (gotKey && this.mDefaultKeySsb != null && this.mDefaultKeySsb.length() > 0) {
                if (hardwareKeySmartGoogleSearch(keyCode, event)) {
                    return true;
                }
                String str = this.mDefaultKeySsb.toString();
                boolean isDialable = true;
                int count = str.length();
                int i = 0;
                while (true) {
                    if (i >= count) {
                        break;
                    }
                    if (PhoneNumberUtils.isReallyDialable(str.charAt(i))) {
                        i++;
                    } else {
                        isDialable = false;
                        break;
                    }
                }
                if (isDialable) {
                    intent = new Intent("android.intent.action.DIAL", Uri.fromParts("tel", str, null));
                } else {
                    intent = new Intent("com.android.contacts.action.FILTER_CONTACTS");
                    intent.putExtra("com.android.contacts.extra.FILTER_TEXT", str);
                }
                intent.addFlags(270532608);
                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                }
                this.mDefaultKeySsb.clear();
                this.mDefaultKeySsb.clearSpans();
                Selection.setSelection(this.mDefaultKeySsb, 0);
                return true;
            }
        }
        return handled;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void restoreState(Bundle savedState) {
        if (savedState != null && this.mWorkspace != null) {
            int currentScreen = savedState.getInt(RUNTIME_STATE_CURRENT_SCREEN, -1);
            if (currentScreen > -1) {
                this.mWorkspace.setCurrentScreen(currentScreen);
            }
            int addScreen = savedState.getInt(RUNTIME_STATE_PENDING_ADD_SCREEN, -1);
            if (addScreen > -1) {
                Log.d(DEBUG_DB_TAG, "restoreState(), addScreen = " + addScreen);
                this.mAddItemCellInfo = new CellInfo();
                CellInfo addItemCellInfo = this.mAddItemCellInfo;
                addItemCellInfo.valid = true;
                addItemCellInfo.screen = addScreen;
                addItemCellInfo.cellX = savedState.getInt(RUNTIME_STATE_PENDING_ADD_CELL_X);
                addItemCellInfo.cellY = savedState.getInt(RUNTIME_STATE_PENDING_ADD_CELL_Y);
                addItemCellInfo.spanX = savedState.getInt(RUNTIME_STATE_PENDING_ADD_SPAN_X);
                addItemCellInfo.spanY = savedState.getInt(RUNTIME_STATE_PENDING_ADD_SPAN_Y);
                addItemCellInfo.findVacantCellsFromOccupied(savedState.getBooleanArray(RUNTIME_STATE_PENDING_ADD_OCCUPIED_CELLS), savedState.getInt(RUNTIME_STATE_PENDING_ADD_COUNT_X), savedState.getInt(RUNTIME_STATE_PENDING_ADD_COUNT_Y));
                this.mRestoring = true;
            }
            boolean renameFolder = savedState.getBoolean(RUNTIME_STATE_PENDING_FOLDER_RENAME, false);
            if (renameFolder) {
                long id = savedState.getLong(RUNTIME_STATE_PENDING_FOLDER_RENAME_ID);
                this.mFolderInfo = sModel.getFolderById(this, id);
                this.mRestoring = true;
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void setupViews() {
        this.mDragLayer = (DragLayer) findViewById(R.id.drag_layer);
        this.mDragLayer.initialDragHint();
        DragLayer dragLayer = this.mDragLayer;
        dragLayer.setScrollMonitor(this.mScrollMonitor);
        this.mWorkspace = (Workspace) dragLayer.findViewById(R.id.workspace);
        this.mWorkspace.registerScrollStateChangedListener(new WorkspaceScrollListener());
        this.mFxWorkspace = (FxWorkspace) dragLayer.findViewById(R.id.fx_workspace);
        if (SettingUtil.usesRingSlide()) {
            this.mSlideController = new RingSlideController(this, this.mWorkspace, this.mFxWorkspace.getPageSinkControl());
        } else {
            this.mSlideController = new SlideController(this, this.mWorkspace);
        }
        this.mWorkspace.setSlideController(this.mSlideController);
        this.mLeapController = new LeapController(this, this.mWorkspace);
        this.mLeapController.addLeapAnimationPlayer(this.mFxWorkspace.getLeapAnimationPlayer());
        this.mLeapController.addLeapListener(this.mFxWorkspace.getLeapListener());
        this.mLeapController.addLeapListener(this);
        this.mLeapController.addLeapAnimationPlayer(this.mWorkspace);
        this.mWorkspace.setLeapController(this.mLeapController);
        setupFxViews();
        if (this.mFxWorkspace != null) {
            this.mFxWorkspace.hide();
        }
        Workspace workspace = this.mWorkspace;
        workspace.setScrollMonitor(this.mScrollMonitor);
        if (localLOGD) {
            Log.d(LOG_TAG, "sScreenCount : " + SettingUtil.getScreenCount());
        }
        if (SettingUtil.getScreenCount() > 0) {
            int currentChildCount = this.mWorkspace.getChildCount();
            if (currentChildCount > SettingUtil.getScreenCount()) {
                for (int i = currentChildCount - 1; i >= SettingUtil.getScreenCount(); i--) {
                    this.mWorkspace.removeViewAt(i);
                }
            } else if (currentChildCount < SettingUtil.getScreenCount()) {
                LayoutInflater inflater = getLayoutInflater();
                for (int i2 = currentChildCount; i2 < SettingUtil.getScreenCount(); i2++) {
                    View view = inflater.inflate(R.layout.workspace_screen, (ViewGroup) null);
                    this.mWorkspace.addView(view);
                }
            }
        }
        this.mDrawer = (SlidingDrawer) dragLayer.findViewById(R.id.drawer);
        SlidingDrawer drawer = this.mDrawer;
        this.mAllAppsView = (AllAppsView) drawer.findViewById(R.id.all_apps_view);
        this.mDeleteZone = (DeleteZone) dragLayer.findViewById(R.id.delete_zone);
        this.mDragMenuBar = (DragMenuBar) dragLayer.findViewById(R.id.drag_menu_bar);
        this.mHandleView = drawer.findViewById(R.id.all_apps);
        ((ViewGroup) this.mHandleView).getChildAt(0).setBackgroundResource(HtcSkinUtil.getDrawableResIdentifier(this, "common_titlebar_sublevel_static", R.drawable.common_titlebar_sublevel_static));
        findViewById(R.id.search_bar).setBackgroundResource(HtcSkinUtil.getDrawableResIdentifier(this, "common_titlebar_sublevel_static_middle", R.drawable.common_titlebar_sublevel_static_middle));
        this.mDrawerTitle = (TextView) this.mHandleView.findViewById(33685587);
        this.mDrawerTitleShade = (TextView) this.mHandleView.findViewById(33685588);
        this.mAllAppsBar = findViewById(R.id.search_bar);
        this.mAllAppsBar.setVisibility(8);
        SearchListener searchListener = new SearchListener();
        SearchBoxView searchBox = this.mAllAppsBar.findViewById(33685959);
        if (searchBox != null && searchBox.getTextField() != null) {
            searchBox.getTextField().addTextChangedListener(searchListener);
        }
        ImageView iv = (ImageView) findViewById(33685958);
        if (iv != null) {
            iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            iv.setImageResource(R.drawable.settings_icon_application);
            iv.setVisibility(0);
            int size = getResources().getDimensionPixelSize(R.dimen.searchbar_icon_size);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
            iv.setLayoutParams(lp);
        }
        drawer.lock();
        DrawerManager drawerManager = new DrawerManager();
        drawer.setOnDrawerOpenListener(drawerManager);
        drawer.setOnDrawerCloseListener(drawerManager);
        drawer.setOnDrawerScrollListener(drawerManager);
        drawer.setVisibility(4);
        this.mAllAppsView.setLauncher(this);
        this.mAllAppsView.inited = false;
        this.mAllAppsView.setDragger(dragLayer);
        this.mAllAppsView.setTabsVisible(true);
        this.mAllAppsView.setContentView(mProgramListId);
        for (ViewGroup c : this.mAllAppsView.getAllContents()) {
            if (c instanceof AddWidgetLayout) {
                this.mProgramListLayout = (AddWidgetLayout) c;
                this.mProgramListLayout.updateContentView(false);
                if (this.mDrawerTitle != null && this.mDrawerTitleShade != null) {
                    this.mProgramListLayout.setTitleTextView(this.mDrawerTitle, this.mDrawerTitleShade);
                }
            }
        }
        workspace.setOnLongClickListener(this);
        workspace.setDragger(dragLayer);
        workspace.setLauncher(this);
        loadWallpaper();
        if (!SettingUtil.isLiveWallaperSupported()) {
            String currentSkin = CustomResourceUtil.getSkinName(this, CustomResourceUtil.getAppliedSkinPackageName());
            if (!this.mOnConfigChangedReloading && currentSkin != null && currentSkin.equals(getSharedPreferences("launcher", 0).getString(KEY_CURRENT_SKIN_NAME, currentSkin))) {
                WidgetWorkspaceManager manager = WidgetWorkspaceManager.instance(this);
                manager.loadHomeWallpaper(this);
            }
        }
        this.mDeleteZone.setLauncher(this);
        this.mDeleteZone.setDragController(dragLayer);
        this.mDragMenuBar.setLauncher(this);
        this.mDragMenuBar.setDragController(dragLayer);
        View buttonBar = findViewById(R.id.buttons);
        this.mDeleteZone.setHandle(buttonBar);
        this.mDragMenuBar.setHandle(buttonBar);
        dragLayer.setIgnoredDropTarget(this.mAllAppsView);
        dragLayer.setDragListener(new DragController.DragListener() { // from class: com.htc.launcher.Launcher.7
            @Override // com.htc.launcher.DragController.DragListener
            public void onPreDragStart(Draggee cell, DragSource source, Object info, int dragAction) {
                InputMethodManager imm = (InputMethodManager) Launcher.this.getSystemService("input_method");
                imm.hideSoftInputFromWindow(Launcher.this.getWindow().getAttributes().token, 0);
                Launcher.this.freezeTilt(true);
                Launcher.this.mTiltListener.reset();
                Launcher.this.mWidgetTilter.reset();
                Launcher.this.mWidgetTilter.mSurpressScroll = true;
            }

            @Override // com.htc.launcher.DragController.DragListener
            public void onPostDragStart(Draggee cell, DragSource source, Object info, int dragAction) {
            }

            @Override // com.htc.launcher.DragController.DragListener
            public void onDragEnd() {
                Launcher.this.mTiltListener.reset();
                Launcher.this.mWidgetTilter.mSurpressScroll = false;
                Launcher.this.mWidgetTilter.reset();
                Launcher.this.freezeTilt(false);
            }
        });
        dragLayer.setDragScoller(workspace);
        dragLayer.setDragListener(workspace);
        dragLayer.setDragListener(this.mDeleteZone);
        dragLayer.setDragListener(this.mDragMenuBar);
        dragLayer.setDragListener(this.mFxWorkspace);
        this.mBottomBarArea = (FunctionBar) findViewById(R.id.bottombar);
        this.mBottomBarArea.setOnTouchListener(this.mFxWorkspace);
        this.mBottomBarArea.setOnLongClick(this.mFxWorkspace);
        this.mFxWorkspace.setDragger(dragLayer);
        this.mDragLayer.addDropTarget(workspace);
        if (SettingUtil.isDoubleShot()) {
            setup2DButtonBarViews();
        }
        List<DropTarget> fxDropTargets = this.mFxWorkspace.getDropTargets();
        for (DropTarget t : fxDropTargets) {
            this.mDragLayer.addDropTarget(t);
        }
    }

    private void setupFxViews() {
        this.mWorkspace.registerScrollStateChangedListener(this.mFxWorkspace);
        this.mWorkspace.redirectTouchTo(this.mFxWorkspace);
        int N = SettingUtil.getScreenCount();
        for (int i = 0; i < N; i++) {
            if (!$assertionsDisabled && !(this.mWorkspace.getChildAt(i) instanceof CellLayout)) {
                throw new AssertionError();
            }
            CellLayout cl = (CellLayout) this.mWorkspace.getChildAt(i);
            if (SettingUtil.isSupportLandscape()) {
                if (isPortrait()) {
                    cl.setOccupiedDelegation(this.mFxWorkspace.getCurrentWorkspace().getScreen(i), true);
                    cl.setOccupiedDelegation(this.mFxWorkspace.getAnotherWorkspace().getScreen(i), false);
                } else {
                    cl.setOccupiedDelegation(this.mFxWorkspace.getCurrentWorkspace().getScreen(i), false);
                    cl.setOccupiedDelegation(this.mFxWorkspace.getAnotherWorkspace().getScreen(i), true);
                }
            } else {
                cl.setOccupiedDelegation(this.mFxWorkspace.getCurrentWorkspace().getScreen(i), true);
            }
        }
        this.mUnlockAnimListener = new RosieUnlockAnimationListener(this.mWorkspace, this.mFxWorkspace);
        this.mFxWorkspace.setUnlockAnimationListener(this.mUnlockAnimListener);
        this.mFxWorkspace.setEditModeListener(new RosieEditModeListener());
        registerTiltObserver(this.mWidgetTilter);
        this.mSlideController.registerSlideListener(this.mWidgetTilter);
        this.mWorkspace.registerScrollStateChangedListener(this.mWidgetTilter);
        this.mSlideController.registerSlideListener(this.mFxWorkspace);
    }

    public void updateButtonBarViews() {
        ArrayList<ItemInfo> buttonBarItems = sModel.getButtonBarItems();
        for (int i = 0; i < buttonBarItems.size(); i++) {
            ApplicationInfo app = (ApplicationInfo) buttonBarItems.get(i);
            this.mDesktopItemController.addButtonBarItem(app);
        }
        update2DButtonBarViews();
    }

    public void update2DButtonBarViews() {
        if (SettingUtil.isDoubleShot()) {
            this.mButtons.update2DButtonBarViews();
            getFxWorkspace().getCurrentWorkspace().showMiddleBackgroundImageControls(sModel.getButtonBarOccupied());
        }
    }

    private void ButtonBarViews_UpdateOrientation() {
        if (SettingUtil.isDoubleShot()) {
            this.mButtons.ButtonBarViews_UpdateOrientation();
        }
    }

    private void setup2DButtonBarViews() {
        this.mControl = (ViewGroup) findViewById(R.id.control);
        this.mButtons = (ButtonBar) this.mControl.findViewById(R.id.buttons);
        this.mButtons.setFocusDelegate(this.mWorkspace);
        this.mButtonBarCache = (ButtonBarCache) this.mControl.findViewById(R.id.button_bar_catch);
        this.mButtons.setLauncher(this);
        this.mButtons.setControl(this.mControl);
        this.mButtons.setButtonBar(this.mButtons);
        this.mButtons.setup2DButtonBarViews();
        this.mButtons.setOnTouchListener(this.mFxWorkspace);
        this.mButtons.setOnLongClick(this.mFxWorkspace);
    }

    public void startCallActivity() {
        ITelephony phone = ITelephony.Stub.asInterface(ServiceManager.checkService("phone"));
        boolean isInCall = false;
        if (localLOGD) {
            Log.w("Handle buttons", "is phone null? " + (phone == null));
        }
        if (phone != null) {
            try {
                isInCall = phone.isOffhook();
            } catch (RemoteException e) {
                isInCall = false;
            }
        }
        if (isInCall) {
            try {
                phone.showCallScreen();
            } catch (Exception e2) {
            }
        } else {
            Intent intent = new Intent("android.intent.action.CALL_BUTTON");
            startActivitySafely(intent);
        }
    }

    private class WorkspaceScrollListener implements Workspace.OnScrollStateChangedListener {
        WallpaperManager mWallpaperMgr;

        /* JADX WARN: Multi-variable type inference failed */
        public WorkspaceScrollListener() {
            this.mWallpaperMgr = WallpaperManager.getInstance(Launcher.this);
        }

        @Override // com.htc.launcher.Workspace.OnScrollStateChangedListener
        public void onBeginFling() {
        }

        @Override // com.htc.launcher.Workspace.OnScrollStateChangedListener
        public void onBeginScroll(boolean isSnap, int begin, int end) {
            Launcher.this.mFxWidgetManager.pauseWidgets(Launcher.getScreen(), false);
            Launcher.this.freezeTilt(true);
            Launcher.this.stop3DAnimation();
            if (SettingUtil.isTabletDevice() && !this.mWallpaperMgr.isCircularWallpaper()) {
                this.mWallpaperMgr.pauseWallpaper(Launcher.this.mWorkspace.getWindowToken(), true);
            }
            if (Launcher.this.mWorkspace.getWindowToken() != null) {
                InputMethodManager imm = (InputMethodManager) Launcher.this.getSystemService("input_method");
                imm.hideSoftInputFromWindow(Launcher.this.mWorkspace.getWindowToken(), 0);
            }
        }

        @Override // com.htc.launcher.Workspace.OnScrollStateChangedListener
        public void onEndScroll() {
            Launcher.this.mFxWidgetManager.resumeWidgets(Launcher.getScreen());
            Launcher.this.freezeTilt(false);
            Launcher.this.stop3DAnimation();
            if (SettingUtil.isTabletDevice() && !this.mWallpaperMgr.isCircularWallpaper()) {
                this.mWallpaperMgr.pauseWallpaper(Launcher.this.mWorkspace.getWindowToken(), false);
            }
        }

        @Override // com.htc.launcher.Workspace.OnScrollStateChangedListener
        public void updateSnapInfo(int endScreen, int snapOffset) {
        }
    }

    private class SearchListener implements TextWatcher {
        private SearchListener() {
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable text) {
            if (Launcher.this.isShowAllProgramSearchBar) {
                Launcher.this.mApplicationsAdapter.getList().search(text.toString());
                Launcher.this.mApplicationsAdapter.notifyDataSetChanged();
            }
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
        }
    }

    public void checkButtonBar() {
        if (this.forceBuildCache) {
            this.forceBuildCache = false;
        }
    }

    public LauncherAppWidgetHost getAppWidgetHost() {
        return this.mAppWidgetHost;
    }

    private static Intent createShortcutIntent(String url, String title, Bitmap touchIcon) {
        Intent i = new Intent();
        Intent shortcutIntent = new Intent("android.intent.action.VIEW", Uri.parse(url));
        i.putExtra("android.intent.extra.shortcut.INTENT", shortcutIntent);
        i.putExtra("android.intent.extra.shortcut.NAME", title);
        i.putExtra("android.intent.extra.shortcut.ICON", touchIcon);
        return i;
    }

    public AppWidgetManager getAppWidgetManager() {
        return this.mAppWidgetManager;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void handleOrientationChangedPendingTask() {
        if (localLOGD) {
            Logger.d(LOG_TAG, String.format("handleOrientationChangedPendingTask %d pending tasks", Integer.valueOf(this.mOrientationChangedRunnables.size())));
        }
        Iterator i$ = this.mOrientationChangedRunnables.iterator();
        while (i$.hasNext()) {
            Runnable runnable = i$.next();
            this.mHandler.post(runnable);
        }
        this.mOrientationChangedRunnables.clear();
    }

    class AddShortcutRunnable implements Runnable {
        Intent mData;

        AddShortcutRunnable(Intent data) {
            this.mData = data;
        }

        @Override // java.lang.Runnable
        public void run() {
            CellInfo cell = new CellInfo();
            cell.cellX = 0;
            cell.cellY = 0;
            cell.spanX = 1;
            cell.spanY = 1;
            Launcher.this.mAddItemCellInfo = null;
            Launcher.this.mDesktopItemController.completeAddShortcut(this.mData, cell, false);
        }
    }

    static void installShortcut(Intent data) {
        if (sRefLauncher.get() != null) {
            Launcher launcher = sRefLauncher.get();
            if ((launcher.getResources().getConfiguration().orientation == 1) == FxWorkspace.isPortrait()) {
                Handler handler = launcher.mHandler;
                launcher.getClass();
                handler.post(launcher.new AddShortcutRunnable(data));
            } else {
                if (localLOGD) {
                    Logger.d(LOG_TAG, "installShortcut when orientation changed");
                }
                launcher.getClass();
                AddShortcutRunnable runnable = launcher.new AddShortcutRunnable(data);
                launcher.mOrientationChangedRunnables.add(runnable);
            }
        }
    }

    static ApplicationInfo addShortcut(Context context, Intent data, CellInfo cellInfo, boolean notify) {
        boolean filtered;
        boolean filtered2;
        Intent.ShortcutIconResource iconResource;
        Drawable icon;
        Intent intent = (Intent) data.getParcelableExtra("android.intent.extra.shortcut.INTENT");
        String name = data.getStringExtra("android.intent.extra.shortcut.NAME");
        Bitmap bitmap = (Bitmap) data.getParcelableExtra("android.intent.extra.shortcut.ICON");
        Intent.ShortcutIconResource iconResource2 = null;
        if (bitmap != null) {
            if (SettingUtil.isTabletDevice()) {
                icon = new FastBitmapDrawable(Utilities.createBitmapThumbnail(bitmap, context), true);
                filtered2 = false;
            } else {
                icon = new FastBitmapDrawable(Utilities.createBitmapThumbnail(bitmap, context));
                filtered2 = true;
            }
            filtered = true;
            iconResource = null;
        } else {
            Parcelable extra = data.getParcelableExtra("android.intent.extra.shortcut.ICON_RESOURCE");
            if (extra != null && (extra instanceof Intent.ShortcutIconResource)) {
                try {
                    iconResource2 = (Intent.ShortcutIconResource) extra;
                    PackageManager packageManager = context.getPackageManager();
                    Resources resources = packageManager.getResourcesForApplication(iconResource2.packageName);
                    int id = resources.getIdentifier(iconResource2.resourceName, null, null);
                    Drawable icon2 = resources.getDrawable(id);
                    filtered2 = false;
                    iconResource = iconResource2;
                    icon = icon2;
                    filtered = false;
                } catch (Exception e) {
                    Log.w(LOG_TAG, "Could not load shortcut icon: " + extra);
                }
            }
            filtered = false;
            filtered2 = false;
            iconResource = iconResource2;
            icon = null;
        }
        Drawable icon3 = icon == null ? context.getPackageManager().getDefaultActivityIcon() : icon;
        ApplicationInfo info = new ApplicationInfo();
        info.icon = icon3;
        info.filtered = filtered2;
        info.title = name;
        info.intent = intent;
        info.customIcon = filtered;
        info.iconResource = iconResource;
        return info;
    }

    static void updateItem(long itemId, Bitmap icon, Intent intent, String title) {
        ArrayList<ItemInfo> infos = sModel.getDesktopItems();
        if (infos != null) {
            Logger.d(LoggingEvents.EXTRA_CALLING_APP_NAME, "UPDATE - Launcher.updateItem()");
            ItemInfo[] items = (ItemInfo[]) infos.toArray(new ItemInfo[0]);
            int i = 0;
            while (true) {
                int i2 = i;
                int i3 = items.length;
                if (i2 >= i3) {
                    break;
                }
                ItemInfo item = items[i2];
                if (item != null && item.id == itemId) {
                    if (item instanceof ApplicationInfo) {
                        Logger.d(LoggingEvents.EXTRA_CALLING_APP_NAME, "ITEM - UPDATE - Launcher.updateItem[" + i2 + "]=" + item);
                        updateApplicationUI(icon, intent, title, item);
                    } else {
                        Log.w(LOG_TAG, "item is not either application or shortcut : " + itemId);
                    }
                } else if (item instanceof UserFolderInfo) {
                    ItemInfo[] item1s = (ItemInfo[]) ((UserFolderInfo) item).contents.toArray(new ItemInfo[0]);
                    int j = 0;
                    boolean needUpdateUI = false;
                    while (true) {
                        int j2 = j;
                        int j3 = item1s.length;
                        if (j2 >= j3) {
                            break;
                        }
                        ItemInfo folderItemInfo = item1s[j2];
                        if (folderItemInfo.id == itemId) {
                            if (folderItemInfo instanceof FxShortcutInfo) {
                                updateApplicationUI(icon, intent, title, folderItemInfo);
                                needUpdateUI = true;
                            } else {
                                Log.w(LOG_TAG, "item is not either application or shortcut : " + itemId);
                            }
                        }
                        j = j2 + 1;
                    }
                    if (needUpdateUI) {
                        ((UserFolderInfo) item).notifyDataChanged();
                    }
                }
                i = i2 + 1;
            }
            Logger.d(LoggingEvents.EXTRA_CALLING_APP_NAME, "UPDATE - Launcher.updateItem() update custom shortcut");
            ArrayList<ItemInfo> buttonBarItems = sModel.getButtonBarItems();
            if (buttonBarItems != null) {
                int i4 = 0;
                while (true) {
                    int i5 = i4;
                    int i6 = buttonBarItems.size();
                    if (i5 < i6) {
                        ApplicationInfo app = (ApplicationInfo) buttonBarItems.get(i5);
                        if (app != null && app.id == itemId) {
                            updateCustomItemUI(icon, intent, title, app);
                        }
                        i4 = i5 + 1;
                    } else {
                        return;
                    }
                }
            }
        }
    }

    private static void updateApplicationUI(Bitmap icon, Intent intent, String title, ItemInfo item) {
        ApplicationInfo appInfo = (ApplicationInfo) item;
        if (icon != null) {
            appInfo.icon = new FastBitmapDrawable(icon);
        }
        appInfo.filtered = true;
        appInfo.customIcon = true;
        if (title != null) {
            appInfo.title = title;
        }
        if (intent != null) {
            appInfo.intent = intent;
        }
        appInfo.notifyIconUpdate();
    }

    private static void updateCustomItemUI(Bitmap icon, Intent intent, String title, ApplicationInfo app) {
        if (app != null) {
            app.icon = new FastBitmapDrawable(icon);
        }
        app.filtered = true;
        app.customIcon = true;
        if (title != null) {
            app.title = title;
        }
        if (intent != null) {
            app.intent = intent;
        }
        PendingUIUpdate.instance().postPending((int) app.id, new CustomShortcutUpdateRunnable(app));
    }

    private static class CustomShortcutUpdateRunnable implements Runnable {
        private WeakReference<ApplicationInfo> mRefApp;

        public CustomShortcutUpdateRunnable(ApplicationInfo app) {
            this.mRefApp = new WeakReference<>(app);
        }

        @Override // java.lang.Runnable
        public void run() {
            if (this.mRefApp.get() != null) {
                ApplicationInfo app = this.mRefApp.get();
                Logger.d(Launcher.LOG_TAG, "[CUSTOM_SHORTCUT] UPDATE - CustomShortcutUpdateRunnable(" + app.cellX + ",Title(" + ((Object) app.title) + ")");
                Launcher launcher = Launcher.sRefLauncher.get();
                launcher.getFxWorkspace().mButtonBarHandler.setDynamicImageAndText(app, app.cellX);
                if (SettingUtil.isDoubleShot()) {
                    launcher.update2DButtonBarViews();
                    return;
                }
                return;
            }
            Logger.e(Launcher.LOG_TAG, "The custom shortcut item is GC.");
        }
    }

    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent.getCategories() != null && intent.getCategories().contains(CATEGORY_SEARCH)) {
            if (localLOGD) {
                Log.d(LOG_TAG, "OnNewIntent: The intent is a Search category.");
            }
            this.mIsSearchCategory = true;
        }
        resetMiddleButton();
        if ("android.intent.action.MAIN".equals(intent.getAction())) {
            getWindow().closeAllPanels();
            try {
                dismissDialog(1);
                this.mWorkspace.unlock();
            } catch (Exception e) {
            }
            try {
                dismissDialog(103);
                this.mWorkspace.unlock();
            } catch (Exception e2) {
            }
            try {
                dismissDialog(2);
                this.mWorkspace.unlock();
            } catch (Exception e3) {
            }
            try {
                dismissDialog(102);
                this.mWorkspace.unlock();
            } catch (Exception e4) {
            }
            if (System.currentTimeMillis() - this.mLauncherLeftTime < 400) {
                if (this.mPageSelect) {
                    this.mIsPressHomeKey = true;
                    this.mLeapController.leaveLeapMode(Workspace.getDefaultScreenIndex());
                } else if (mUiMode == 2) {
                    this.mWorkspace.showDefaultScreen();
                    Workspace workspace = this.mWorkspace;
                    setScreen(Workspace.getDefaultScreenIndex());
                    mUiMode = 0;
                } else if (!this.mWorkspace.isDefaultScreenShowing()) {
                    if (!this.mSkipUiModeChange) {
                        if (this.mIsAllowMoveToDefaultScreen) {
                            this.mIsAllowMoveToDefaultScreen = false;
                            this.mHandler.removeMessages(1002);
                            this.mWorkspace.drawScreens(this.mWorkspace.getCurrentScreenIndex());
                            this.mWidgetTilter.mSurpressScroll = true;
                            this.mWidgetTilter.reset();
                            int duration = this.mWorkspace.moveToDefaultScreen();
                            this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(1002), duration);
                        }
                        this.mIsPressHomeKey = true;
                    }
                } else if (SettingUtil.sIsHomeToThumbnail && canEnableLeapMode() && !this.mSkipUiModeChange) {
                    this.mWorkspace.drawScreens(Workspace.getDefaultScreenIndex());
                    ReusableULogData uLogData = ReusableULogData.obtain();
                    uLogData.setAppId("com.htc.launcher").setCategory("leap_view");
                    uLogData.addData("leapview_launch", "key");
                    if (localLOGD) {
                        Log.d(LOG_TAG, "HTC user profiling     leapview_launch     true,key");
                    }
                    ULog.log(uLogData);
                    uLogData.recycle();
                    this.mLeapController.enterLeapMode();
                    this.mIsPressHomeKey = true;
                }
                closeDrawer();
                IBinder token = getWindow().getAttributes().token;
                if (token != null) {
                    InputMethodManager imm = (InputMethodManager) getSystemService("input_method");
                    imm.hideSoftInputFromWindow(token, 0);
                }
                this.mSkipUiModeChange = false;
            } else if (this.mPageSelect) {
                this.mLeapController.leaveLeapMode(Workspace.getDefaultScreenIndex());
            } else {
                boolean openPersonalize = intent.getBooleanExtra(EXTRA_OPEN_PERSONALIZE, false);
                this.mWidgetsManager.onActivityNewIntent(this);
                if (!this.mWorkspace.isDefaultScreenShowing() && !openPersonalize) {
                    this.mWorkspace.showDefaultScreen();
                    Workspace workspace2 = this.mWorkspace;
                    setScreen(Workspace.getDefaultScreenIndex());
                    this.mWorkspace.getChildAt(Workspace.getDefaultScreenIndex()).requestFocus();
                    this.mWorkspace.doNotRestoreCurrentScreen();
                }
                if (openPersonalize && !this.mIsLoading) {
                    onOpenPersonalize();
                } else {
                    closeDrawer(false);
                }
            }
            if (this.mDragLayer != null) {
                this.mDragLayer.abortDrag();
            }
            boolean isInTabEditMode = this.lastTabTag != null;
            if (isInTabEditMode) {
                onTabEndSliding(this.lastTabTag);
            }
        }
    }

    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        this.mSavedInstanceState = savedInstanceState;
    }

    protected void onSaveInstanceState(Bundle outState) {
        Dialog dialog;
        long begin = System.currentTimeMillis();
        if (this.lastDialog != null && (dialog = this.lastDialog.get()) != null && dialog.isShowing()) {
            dismissDialog(2);
            if (localLOGD) {
                Log.d(LOG_TAG, "Launcher.onSaveInstanceState: dismissDialog");
            }
        }
        outState.putInt(RUNTIME_STATE_CURRENT_SCREEN, this.mWorkspace.getCurrentScreenIndex());
        ArrayList<Folder> folders = this.mWorkspace.getOpenFolders();
        if (folders.size() > 0) {
            int count = folders.size();
            long[] ids = new long[count];
            for (int i = 0; i < count; i++) {
                FolderInfo info = folders.get(i).getInfo();
                ids[i] = info.id;
            }
            outState.putLongArray(RUNTIME_STATE_USER_FOLDERS, ids);
        } else {
            super.onSaveInstanceState(outState);
        }
        if (this.mDrawer.isOpened()) {
            outState.putBoolean(RUNTIME_STATE_ALL_APPS_FOLDER, true);
            outState.putInt(RUNTIME_STATE_SLIDING_ALL_PROGRAM, this.mDrawerContentId);
        }
        if (this.mAddItemCellInfo != null && this.mAddItemCellInfo.valid && this.mWaitingForResult) {
            CellInfo addItemCellInfo = this.mAddItemCellInfo;
            CellLayout layout = (CellLayout) this.mWorkspace.getChildAt(addItemCellInfo.screen);
            outState.putInt(RUNTIME_STATE_PENDING_ADD_SCREEN, addItemCellInfo.screen);
            outState.putInt(RUNTIME_STATE_PENDING_ADD_CELL_X, addItemCellInfo.cellX);
            outState.putInt(RUNTIME_STATE_PENDING_ADD_CELL_Y, addItemCellInfo.cellY);
            outState.putInt(RUNTIME_STATE_PENDING_ADD_SPAN_X, addItemCellInfo.spanX);
            outState.putInt(RUNTIME_STATE_PENDING_ADD_SPAN_Y, addItemCellInfo.spanY);
            outState.putInt(RUNTIME_STATE_PENDING_ADD_COUNT_X, layout.getCountX());
            outState.putInt(RUNTIME_STATE_PENDING_ADD_COUNT_Y, layout.getCountY());
            outState.putBooleanArray(RUNTIME_STATE_PENDING_ADD_OCCUPIED_CELLS, layout.getOccupiedCells());
        }
        if (this.mFolderInfo != null && this.mWaitingForResult) {
            outState.putBoolean(RUNTIME_STATE_PENDING_FOLDER_RENAME, true);
            outState.putLong(RUNTIME_STATE_PENDING_FOLDER_RENAME_ID, this.mFolderInfo.id);
        }
        if (localLOGD) {
            Log.d(LOG_TAG, "onSaveInstanceState() [finished] : diff - " + (System.currentTimeMillis() - begin));
        }
    }

    public void onDestroy() {
        if (localLOGD) {
            Log.d(LOG_TAG, "onDestroy");
        }
        this.mDestroying = true;
        if (this.mContentQueryMap != null) {
            this.mContentQueryMap.deleteObserver(this.mTiltSettingsObserver);
        }
        synchronized (this.mTiltObservers) {
            this.mTiltObservers.clear();
        }
        InputMethodManager imm = (InputMethodManager) getSystemService("input_method");
        if (imm != null) {
            imm.startGettingWindowFocus(null);
            if (this.mWorkspace != null) {
                imm.windowDismissed(this.mWorkspace.getWindowToken());
            }
        }
        this.mWorkspace.onDestroy();
        super.onDestroy();
        PendingUIUpdate.reset();
        if (this.mFxWidgetManager != null) {
            this.mFxWidgetManager.finish();
            this.mFxWidgetManager = null;
        }
        this.mWidgetsManager.onDestory();
        this.mWidgetsManager.onActivityDestroy();
        try {
            this.mAppWidgetHost.stopListening();
        } catch (NullPointerException ex) {
            Log.w(LOG_TAG, "problem while stopping AppWidgetHost during Launcher destruction", ex);
        }
        TextKeyListener.getInstance().release();
        this.mDesktopItemController.destroy();
        for (Object obj : this.mAllAppsView.getAllContents()) {
            if (obj instanceof AllAppsListView) {
                ((AllAppsListView) obj).clearTextFilter();
                ((AllAppsListView) obj).setAdapter(null);
            }
            if (obj instanceof AllAppsGridView) {
                ((AllAppsGridView) obj).clearTextFilter();
                ((AllAppsGridView) obj).setAdapter(null);
            }
            if (obj instanceof AddWidgetLayout) {
                ((AddWidgetLayout) obj).setAdapter((AddListAdapter) null);
            }
        }
        sModel.unbind();
        sModel.abortLoaders();
        getContentResolver().unregisterContentObserver(this.mObserver);
        getContentResolver().unregisterContentObserver(this.mAppWidgetResetObserver);
        unregisterReceiver(this.mApplicationsReceiver);
        unregisterReceiver(this.mKeyguardIntentReceiver);
        unregisterReceiver(this.mThemeChangeReceiver);
        unregisterReceiver(this.mSceneCleanReceiver);
        unregisterReceiver(this.mHtcWidgetUpdateReceiver);
        unregisterReceiver(this.mSummaryReceiver);
        unregisterWeatherAnimationNotify();
        unregisterReceiver(this.mSilderReceiver);
        if (this.telephonyManager != null) {
            this.telephonyManager.listen(this.phoneStateListener, 0);
        } else {
            cancelDelayed(this.registerTelephonyManager);
        }
        sRefLauncher = new WeakReference<>(null);
        this.mDestroyed = true;
        this.mIsEstimateSlidingDrawer = false;
        Process.killProcess(Process.myPid());
    }

    public void startActivityForResult(Intent intent, int requestCode) {
        this.mWaitingForResult = true;
        try {
            super.startActivityForResult(intent, requestCode);
        } catch (Exception e) {
            Log.e(LOG_TAG, "can't start activity: " + intent.getAction() + " cause:" + e.getMessage());
            this.mWaitingForResult = false;
        }
    }

    public void startSearch(String initialQuery, boolean selectInitialQuery, Bundle appSearchData, boolean globalSearch) {
        String searchEngine = getSearchEngine();
        if (localLOGD) {
            Log.d(LOG_TAG, "startSearch: searchEngine=" + searchEngine);
        }
        if (!"default".equals(searchEngine) && !SearchPickerActivity.SEARCHANYWHERE_INTENT.equals(searchEngine)) {
            Intent intent = new Intent(searchEngine);
            try {
                startActivity(intent);
                return;
            } catch (Exception e) {
                Log.e(LOG_TAG, "startSearch: e=" + e);
            }
        }
        if (appSearchData == null) {
            appSearchData = new Bundle();
            appSearchData.putString(Search.SOURCE, "launcher-search");
        }
        super.startSearch(initialQuery, selectInitialQuery, appSearchData, globalSearch);
    }

    private String getSearchEngine() {
        SharedPreferences preferences = getSharedPreferences("launcher", 0);
        String ret = preferences.getString(SearchPickerActivity.SEARCH_ENGINE, null);
        if (ret == null || ret.length() == 0) {
            Log.w(LOG_TAG, "getSearchEngine: no data in local preferences, sync with system settings");
            ret = Settings.System.getString(getContentResolver(), SearchPickerActivity.SEARCH_ENGINE);
            if (ret == null || ret.length() == 0) {
                Log.w(LOG_TAG, "getSearchEngine: no data in settings! fall back to default");
                ret = SearchPickerActivity.default_Search_Engine;
                Settings.System.putString(getContentResolver(), SearchPickerActivity.SEARCH_ENGINE, ret);
            }
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString(SearchPickerActivity.SEARCH_ENGINE, ret);
            editor.apply();
        }
        return ret;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public boolean onCreateOptionsMenu(Menu menu) {
        if (this.mDesktopLocked) {
            return false;
        }
        super.onCreateOptionsMenu(menu);
        menu.add(0, 12, 0, R.string.all_apps).setIcon(R.drawable.icon_menu_all_programs);
        menu.add(0, 5, 0, R.string.menu_notifications).setIcon(R.drawable.icon_menu_notifications).setAlphabeticShortcut('N');
        menu.add(1, 15, 0, R.string.menu_personalize).setIcon(R.drawable.icon_menu_theme).setAlphabeticShortcut('P');
        menu.add(0, 3, 0, R.string.menu_wallpaper).setIcon(R.drawable.icon_menu_wallpaper).setAlphabeticShortcut('W');
        if (SettingUtil.isTabletDevice()) {
            menu.add(0, 4, 0, 34341176).setIcon(34079539).setAlphabeticShortcut('s');
        } else {
            menu.add(0, 16, 0, R.string.menu_ringtones).setIcon(R.drawable.icon_menu_set_ringtone).setAlphabeticShortcut('R');
        }
        menu.add(0, 6, 0, 34341376).setIcon(34079542);
        menu.add(2, 7, 0, R.string.all_apps_menu_layout_list).setIcon(34079530).setAlphabeticShortcut('L');
        menu.add(2, 8, 0, R.string.all_apps_menu_layout_grid).setIcon(34079526).setAlphabeticShortcut('G');
        menu.add(2, 10, 2, R.string.all_apps_menu_remove_application).setIcon(34079523).setAlphabeticShortcut('D');
        menu.add(2, 11, 3, 34341175).setIcon(34079544).setAlphabeticShortcut('S');
        if (SettingUtil.isTabletDevice()) {
            menu.add(2, 14, 4, 34341176).setIcon(34079539).setAlphabeticShortcut('s');
        }
        AppSharing.addIfExists(this, menu, 2, 13, 1);
        this.mOptionsMenuChanged.add(menu);
        return true;
    }

    public boolean onPrepareOptionsMenu(Menu menu) {
        if (this.mIsLauncherAddtoHome || this.mDragLayer.isDragging() || this.mIsWorkspaceChanging || this.mPageSelect || this.lastTabTag != null) {
            return false;
        }
        this.mMenuAddInfo = this.mWorkspace.findAllVacantCells(null);
        if (!this.mOptionsMenuChanged.contains(menu)) {
            menu.clear();
            onCreateOptionsMenu(menu);
        }
        super.onPrepareOptionsMenu(menu);
        boolean allApps = this.mDrawer.isOpened();
        menu.setGroupVisible(0, !allApps);
        menu.setGroupVisible(1, !allApps);
        menu.setGroupVisible(2, allApps);
        if (allApps) {
            MenuItem l = menu.findItem(7);
            MenuItem g = menu.findItem(8);
            MenuItem s = menu.findItem(11);
            boolean listView = mProgramListId == 2131099651;
            l.setVisible(!listView);
            g.setVisible(listView);
            s.setVisible(AllAppsView.TAB_ALLAPPS.equals(this.mAllAppsView.getCurrentTab()));
        }
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        this.mIsMenuKeyDown = false;
        switch (item.getItemId()) {
            case 2:
            case 15:
                removeTutorialNotice();
                prepareAddToHomeContent();
                prepareCurrentScreenCache();
                changeDrawerContentById(R.id.content_add_to_home);
                onClickAddtoHome(null);
                return true;
            case 3:
                startCreateScenePreviewThread(false);
                if (SettingUtil.isLiveWallaperSupported()) {
                    startWallpaper();
                } else {
                    showDialog(102);
                }
                return true;
            case 4:
                onSearchRequested();
                return true;
            case 5:
                showNotifications();
                return true;
            case 6:
                Intent settings = new Intent("android.settings.SETTINGS");
                settings.setFlags(270532608);
                startActivitySafely(settings);
                return true;
            case 7:
                setAllAppsLayout(false);
                return true;
            case LoggingEvents.VoiceIme.SWIPE_HINT_DISPLAYED /* 8 */:
                setAllAppsLayout(true);
                return true;
            case LoggingEvents.VoiceIme.PUNCTUATION_HINT_DISPLAYED /* 9 */:
                enableAppsSearch(true, null);
                return true;
            case 10:
                startActivitySafely(new Intent("android.settings.MANAGE_APPLICATIONS_SETTINGS"));
                return true;
            case LoggingEvents.VoiceIme.CANCEL_DURING_WORKING /* 11 */:
                if (this.mApplicationsAdapter == null || this.mApplicationsAdapter.getList() == null) {
                    if (localLOGD) {
                        Log.d(LOG_TAG, "MENU_ALL_APPS_SORT mApplicationsAdapter = " + this.mApplicationsAdapter);
                    }
                    if (this.mApplicationsAdapter != null && localLOGD) {
                        Log.d(LOG_TAG, "MENU_ALL_APPS_SORT mApplicationsAdapter.getList() = " + this.mApplicationsAdapter.getList());
                    }
                    return true;
                }
                showDialog(103);
                return true;
            case LoggingEvents.VoiceIme.CANCEL_DURING_ERROR /* 12 */:
                onClickAllProgram();
                return true;
            case LoggingEvents.VoiceIme.ERROR /* 13 */:
                AppSharing.onItemSelected(this);
                return true;
            case LoggingEvents.VoiceIme.START /* 14 */:
                enableAppsSearch(true, null);
                return true;
            case 16:
                Intent data = new Intent();
                Bundle bundle = new Bundle();
                bundle.putInt("SDMListType", 2);
                data.putExtras(bundle);
                data.setClassName("com.htc.sdm", "com.htc.sdm.activity.SoundSetList");
                startActivity(data);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void enableAppsSearch(boolean enable, String input) {
        if (this.mAllAppsBar != null) {
            SearchBoxView search = this.mAllAppsBar.findViewById(33685959);
            final InputMethodManager imm = (InputMethodManager) getSystemService("input_method");
            if (enable) {
                View allappsView = this.mDrawer.findViewById(R.id.content_list);
                ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) allappsView.getLayoutParams();
                mlp.topMargin = getResources().getDimensionPixelOffset(R.dimen.allapps_list_topmargin_in_search);
                allappsView.setLayoutParams(mlp);
                this.mAllAppsBar.setVisibility(0);
                final EditText edit = search.getTextField();
                edit.setHint(getResources().getString(R.string.all_apps_search_text_hint));
                edit.requestFocus();
                this.mAllAppsBarEditText = edit;
                if (input != null) {
                    edit.setText(input);
                    edit.setSelection(1, 1);
                    this.mApplicationsAdapter.getList().search(input);
                    this.mApplicationsAdapter.notifyDataSetChanged();
                }
                edit.postDelayed(new Runnable() { // from class: com.htc.launcher.Launcher.8
                    @Override // java.lang.Runnable
                    public void run() {
                        imm.showSoftInput(edit, 0);
                    }
                }, 400L);
            } else {
                if (search != null && search.getTextField() != null) {
                    search.getTextField().setText(LoggingEvents.EXTRA_CALLING_APP_NAME);
                    imm.hideSoftInputFromWindow(search.getWindowToken(), 0);
                }
                this.mAllAppsBar.setVisibility(8);
                View allappsView2 = this.mDrawer.findViewById(R.id.content_list);
                ViewGroup.MarginLayoutParams mlp2 = (ViewGroup.MarginLayoutParams) allappsView2.getLayoutParams();
                mlp2.topMargin = 0;
                allappsView2.setLayoutParams(mlp2);
            }
            this.isShowAllProgramSearchBar = enable;
        }
    }

    private void setAllAppsLayout(boolean gridView) {
        if (gridView) {
            mProgramListId = R.id.content_grid;
        } else {
            mProgramListId = R.id.content_list;
        }
        if (SettingUtil.isDoubleShot()) {
            this.mAllAppsView.setTabsVisible(false);
        } else {
            this.mAllAppsView.setTabsVisible(true);
        }
        this.mAllAppsView.setContentView(mProgramListId);
        if (!gridView) {
            AllAppsListView listView = (AllAppsListView) this.mAllAppsView.findViewById(R.id.content_list);
            listView.setFastScrollEnabled(listView.isFastScrollAllowed());
        }
    }

    private void changeDrawerContentById(int LayoutId) {
        boolean showTabs;
        if (LayoutId == 2131099653) {
            this.mDrawerContentId = 1;
            this.mDrawerTitle.setText(R.string.menu_personalize);
            this.mDrawerTitleShade.setText(R.string.menu_personalize);
            showTabs = false;
        } else {
            showTabs = true;
            this.mDrawerContentId = 0;
            this.mDrawerTitle.setText(R.string.all_apps);
            this.mDrawerTitleShade.setText(R.string.all_apps);
            if (this.mApplicationsAdapter.currentOperatorTab != null) {
                updateAllAppsStatus(this.mApplicationsAdapter.currentOperatorTab.getClassifier().toString());
            } else {
                updateAllAppsStatus(this.mAllAppsView.getCurrentTab());
            }
        }
        if (SettingUtil.isDoubleShot()) {
            this.mAllAppsView.setTabsVisible(false);
        } else {
            this.mAllAppsView.setTabsVisible(showTabs);
        }
        this.mAllAppsView.setContentView(LayoutId);
        this.mAllAppsView.scrollTo(0, 0);
    }

    void updateAllAppsStatus(String tabId) {
        int stringResId;
        Resources res = getResources();
        this.mApplicationsAdapter.currentOperatorTab = null;
        if (FilterableAndSortableApplicationInfoList.ALL_APPS == this.mApplicationsAdapter.getList().getClassifier()) {
            this.lastComparator4AllAppsTab = this.mApplicationsAdapter.getList().getComparator();
        }
        if (AllAppsView.TAB_ALLAPPS.equals(tabId) || tabId == null) {
            stringResId = R.string.all_apps_tab_all_apps;
            this.currentAppTab = AppTabType.allApp;
            if (this.mApplicationsAdapter != null) {
                this.mApplicationsAdapter.getList().sort(this.lastComparator4AllAppsTab);
                this.mApplicationsAdapter.getList().classify(FilterableAndSortableApplicationInfoList.ALL_APPS);
            }
        } else if (AllAppsView.TAB_DOWNLOADED.equals(tabId)) {
            stringResId = R.string.all_apps_tab_downloaded;
            this.currentAppTab = AppTabType.downloaded;
            if (this.mApplicationsAdapter != null) {
                this.mApplicationsAdapter.getList().sort(FilterableAndSortableApplicationInfoList.NEWEST_FIRST);
                this.mApplicationsAdapter.getList().classify(FilterableAndSortableApplicationInfoList.DOWNLOADED);
            }
        } else if (AllAppsView.TAB_FREQUENT.equals(tabId)) {
            stringResId = R.string.all_apps_tab_frequent;
            this.currentAppTab = AppTabType.frequent;
            if (this.mApplicationsAdapter != null) {
                this.mApplicationsAdapter.getList().sort(FilterableAndSortableApplicationInfoList.FREQUENTLY_USED_FIRST);
                this.mApplicationsAdapter.getList().classify(FilterableAndSortableApplicationInfoList.ONE_PAGE_EVER_USED);
            }
        } else {
            this.currentAppTab = AppTabType.unknown;
            OperatorTabManager opTabManager = OperatorTabManager.getInstance();
            OperatorTab opTab = null;
            for (int i = 0; i < opTabManager.getOperatorTabCount(); i++) {
                opTab = opTabManager.getOperatorTabByIndex(i);
                if (opTab.getClassifier().toString().equals(tabId)) {
                    break;
                }
                opTab = null;
            }
            if (opTab != null) {
                stringResId = opTabManager.getResources().getLabelResId(opTab);
                if (this.mApplicationsAdapter != null) {
                    this.mApplicationsAdapter.getList().sort(opTab.getAppComparator());
                    this.mApplicationsAdapter.getList().classify(opTab.getClassifier());
                }
                this.mApplicationsAdapter.currentOperatorTab = opTab;
                res = opTabManager.getResources();
            } else {
                TFC.assertTrue("invalid tabId=" + tabId, false);
                return;
            }
        }
        boolean onPersonalize = this.mIsOpenPersonalizeBySetting;
        if (!onPersonalize) {
            this.mDrawerTitle.setText(res.getString(stringResId));
            this.mDrawerTitleShade.setText(res.getString(stringResId));
        }
        AllAppsListView listView = (AllAppsListView) this.mAllAppsView.findViewById(R.id.content_list);
        listView.setFastScrollEnabled(listView.isFastScrollAllowed());
        if (this.mApplicationsAdapter != null) {
            this.mApplicationsAdapter.notifyDataSetChanged();
        }
        if (this.mDrawer.isOpened() && this.mAllAppsView.getContentView() == 2131099652) {
            AllAppsGridView pageView = (AllAppsGridView) this.mAllAppsView.findViewById(R.id.content_grid);
            pageView.scrollToPage(pageView.getCurrentPage(), 0);
        }
    }

    public boolean onSearchRequested() {
        if (localLOGD) {
            Log.d("Steven", "On Search request");
        }
        if (this.mDrawer.isOpened()) {
            if (!this.mIsLauncherAddtoHome) {
                if (this.lastTabTag == null) {
                    if (this.isShowAllProgramSearchBar) {
                        enableAppsSearch(false, null);
                    } else {
                        enableAppsSearch(true, null);
                    }
                }
                return false;
            }
            closeOptionsMenu();
            startSearch(null, false, null, true);
            return true;
        }
        if (!this.mPageSelect && this.mWorkspace.snapToSearch()) {
            closeDrawer(true);
            return true;
        }
        closeOptionsMenu();
        startSearch(null, false, null, true);
        return true;
    }

    public boolean onGoogleSearchRequested() {
        if (localLOGD) {
            Log.d(LOG_TAG, "On Google Search: The intent is a Search category.");
        }
        return super.onSearchRequested();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void removeShortcutsForPackage(String packageName) {
        if (packageName != null && packageName.length() > 0) {
            this.mWorkspace.removeShortcutsForPackage(packageName);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateShortcutsForPackage(String packageName) {
        if (packageName != null && packageName.length() > 0) {
            this.mWorkspace.updateShortcutsForPackage(packageName);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateApplicationIconForPackage(String packageName) {
        if (packageName != null && packageName.length() > 0) {
            this.mWorkspace.updateApplicationIconForPackage(packageName);
        }
    }

    private void showNotifications() {
        StatusBarManager statusBar = (StatusBarManager) getSystemService("statusbar");
        Log.w(LOG_TAG, "Launcher.java->showNotifications(), is statusbar Null? " + (statusBar == null));
        if (statusBar != null) {
            statusBar.expand();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startWallpaper() {
        Intent pickIntent = new Intent("android.intent.action.SET_WALLPAPER_DIALOG");
        pickIntent.putExtra("IS_LIVE_WALLPAPER", true);
        startActivity(pickIntent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startWallpaperNoLiveWallpaper() {
        Intent pickIntent = new Intent("android.intent.action.SET_WALLPAPER_DIALOG");
        startActivity(pickIntent);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void startLockScreenWallpaper() {
        Intent pickIntent = new Intent("android.intent.action.SET_WALLPAPER_DIALOG");
        pickIntent.putExtra("IS_SELECT_LOCKSCREEN", true);
        startActivity(pickIntent);
    }

    private void registerIntentReceivers() {
        WallpaperIntentReceiver.mLauncher = new WeakReference<>(this);
        if (sCustomizationReceiver == null) {
            Application application = getApplication();
            sCustomizationReceiver = new CustomizationChangeReceiver();
            application.registerReceiver(sCustomizationReceiver, new IntentFilter("android.htc.intent.action.CUSTOMIZATION_CHANGE"));
        }
        IntentFilter filter = new IntentFilter("android.intent.action.PACKAGE_ADDED");
        filter.addAction("android.intent.action.PACKAGE_REMOVED");
        filter.addAction("android.intent.action.PACKAGE_CHANGED");
        filter.addDataScheme("package");
        registerReceiver(this.mApplicationsReceiver, filter);
        IntentFilter filter2 = new IntentFilter();
        filter2.addAction("android.intent.action.EXTERNAL_APPLICATIONS_AVAILABLE");
        filter2.addAction("android.intent.action.EXTERNAL_APPLICATIONS_UNAVAILABLE");
        registerReceiver(this.mApplicationsReceiver, filter2);
        IntentFilter userPresentFilter = new IntentFilter("android.intent.action.USER_PRESENT");
        userPresentFilter.addAction("android.intent.action.SCREEN_OFF");
        registerReceiver(this.mKeyguardIntentReceiver, userPresentFilter);
        IntentFilter themeChangeFilter = new IntentFilter(LauncherIntent.ACTION_THEME_CHANGE);
        registerReceiver(this.mThemeChangeReceiver, themeChangeFilter);
        IntentFilter themeCleanFilter = new IntentFilter("com.htc.launcher.action.scene_clean");
        registerReceiver(this.mSceneCleanReceiver, themeCleanFilter, Manifest.permission.CLEAN_SCENE, null);
        IntentFilter sliderFilter = new IntentFilter(ACTION_SILDER_STATE);
        registerReceiver(this.mSilderReceiver, sliderFilter);
        IntentFilter htcWidgetUpdateFilter = new IntentFilter("com.htc.launcher.action.htcWidgetUpdate");
        registerReceiver(this.mHtcWidgetUpdateReceiver, htcWidgetUpdateFilter);
        IntentFilter personalizeChangeFilter = new IntentFilter();
        String[] arr$ = ACTION_SUMMARY_CHANGES;
        for (String action : arr$) {
            personalizeChangeFilter.addAction(action);
        }
        registerReceiver(this.mSummaryReceiver, personalizeChangeFilter);
        registerWeatherAnimationNotify();
    }

    private void registerContentObservers() {
        ContentResolver resolver = getContentResolver();
        resolver.registerContentObserver(LauncherSettings.Favorites.CONTENT_URI, true, this.mObserver);
        resolver.registerContentObserver(LauncherProvider.CONTENT_APPWIDGET_RESET_URI, true, this.mAppWidgetResetObserver);
    }

    private boolean handleDirectionalKey(KeyEvent event) {
        View widgetView;
        int keyCode = event.getKeyCode();
        View view = this.mWorkspace.getFocusedChild();
        if ((view instanceof CellLayout) && (widgetView = ((CellLayout) view).getFocusedChild()) != null && (widgetView.getTag() instanceof WidgetProxy)) {
            WidgetProxy proxy = (WidgetProxy) widgetView.getTag();
            if (proxy.getWidgetView().isHandleDirectionalKey()) {
                return super.dispatchKeyEvent(event);
            }
        }
        switch (keyCode) {
            case LoggingEvents.VoiceIme.IME_TEXT_ACCEPTED /* 21 */:
                if (localLOGD) {
                    Log.d("Steven", "(3425) LeftKey received");
                }
                this.mWorkspace.scrollLeft();
                return true;
            case NewSceneActivity.DIALOG_INVALIDATE_SCENE_NAME /* 22 */:
                if (localLOGD) {
                    Log.d("Steven", "(3429) LeftKey received");
                }
                this.mWorkspace.scrollRight();
                return true;
            default:
                return false;
        }
    }

    public boolean dispatchTouchEvent(MotionEvent event) {
        TFC.d(LOG_TAG, "dispatchTouchEvent: event=" + event);
        int action = event.getAction();
        switch (action) {
            case 0:
                stop3DAnimation();
                this.mWidgetTilter.surpressSensor(true);
                break;
            case 1:
                this.mWidgetTilter.surpressSensor(false);
                break;
        }
        return super.dispatchTouchEvent(event);
    }

    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == 0) {
            switch (event.getKeyCode()) {
                case 3:
                    closeDrawer();
                    return true;
                case 4:
                    this.mDragLayer.abortDrag();
                    this.mWorkspace.leaveEditMode();
                    if (isDrawerDown()) {
                        this.mDesktopItemController.closeFolder();
                    }
                    if (this.mIsLauncherAddtoHome) {
                        if (this.mListAdapter.getLevel() > 0) {
                            this.mListAdapter.callback();
                            this.mProgramListLayout.doCheckTitle();
                            this.mProgramListLayout.postInvalidate();
                        } else if (this.mIsOpenPersonalizeBySetting) {
                            this.mIsOpenPersonalizeBySetting = false;
                            Intent settings = new Intent("android.settings.SETTINGS");
                            settings.setFlags(270532608);
                            startActivitySafely(settings);
                            onCloseDrawer();
                        } else {
                            this.mAllAppsView.clearFocus();
                            this.mDrawer.animateClose();
                            this.mBottomBarArea.setOnTouchListener(this.mFxWorkspace);
                            resetMiddleButton();
                        }
                    } else {
                        boolean isInTabEditMode = this.lastTabTag != null;
                        if (isInTabEditMode) {
                            super.dispatchKeyEvent(event);
                            onTabEndSliding(this.lastTabTag);
                        } else if (this.isShowAllProgramSearchBar) {
                            enableAppsSearch(false, null);
                        } else {
                            closeDrawer();
                        }
                    }
                    if (this.mPageSelect) {
                        this.mLeapController.leaveLeapMode();
                    }
                    return true;
                case LoggingEvents.VoiceIme.VOICE_INPUT_SETTING_ENABLED /* 19 */:
                case LoggingEvents.VoiceIme.VOICE_INPUT_SETTING_DISABLED /* 20 */:
                case LoggingEvents.VoiceIme.IME_TEXT_ACCEPTED /* 21 */:
                case NewSceneActivity.DIALOG_INVALIDATE_SCENE_NAME /* 22 */:
                    if (!this.mDrawer.isOpened() && ((this.mWorkspace.isEditing() || this.mWorkspace.getOpenFolder() == null || this.mWorkspace.getFocusedChild() == null) && this.mFxWorkspace.getFocusedChild() == null)) {
                        return handleDirectionalKey(event);
                    }
                    break;
                case 79:
                    stop3DAnimation();
                    break;
                case 82:
                    if (!this.mIsMenuKeyDown) {
                        this.mIsMenuKeyDown = true;
                        break;
                    } else {
                        return true;
                    }
            }
        } else if (event.getAction() == 1 && event.getKeyCode() == 82) {
            this.mIsMenuKeyDown = false;
        }
        boolean ret = false;
        if (84 != event.getKeyCode() || 1 != event.getAction()) {
            ret = super.dispatchKeyEvent(event);
        }
        return ret;
    }

    public void onKeyDownToRequestSearch(String str) {
        if (this.mDrawer.isOpened()) {
            if (!this.mIsLauncherAddtoHome) {
                if (!this.isShowAllProgramSearchBar) {
                    enableAppsSearch(true, null);
                    return;
                }
                return;
            }
            closeOptionsMenu();
        }
        startSearch(str, false, null, true);
    }

    public void onCloseDrawer() {
        this.mDrawer.setVisibility(4);
        if (SettingUtil.isDoubleShot()) {
            this.mControl.setVisibility(8);
        }
        this.mDrawer.close();
    }

    public void onOpenPersonalize() {
        if (localLOGD) {
            Log.d(LOG_TAG, "onOpenPersonalize()");
        }
        this.mIsOpenPersonalizeBySetting = true;
        changeDrawerContentById(R.id.content_add_to_home);
        prepareAddToHomeContent();
        this.mAddItemCellInfo = null;
        this.mDrawer.setVisibility(0);
        this.mDrawer.open();
        this.mIsLauncherAddtoHome = true;
    }

    private void closeDrawer() {
        closeDrawer(true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void closeDrawer(boolean animated) {
        if (!this.mDrawer.isMoving()) {
            this.mIsLauncherAddtoHome = false;
            this.mIsLauncherAllProgram = false;
        }
        if (this.mDrawer.isOpened()) {
            if (this.isShowAllProgramSearchBar) {
                enableAppsSearch(false, null);
            }
            if (animated) {
                this.mDrawer.animateClose();
            } else {
                this.mDrawer.close();
            }
            if (this.mDrawer.hasFocus()) {
                this.mWorkspace.getChildAt(this.mWorkspace.getCurrentScreenIndex()).requestFocus();
            }
        }
    }

    void onFavoritesChanged() {
        this.mDesktopLocked = true;
        this.mDrawer.lock();
        removeWidgetsAndLoadUserItems(false, this, false, false, -1, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onAppWidgetReset() {
        if (this.mAppWidgetHost != null) {
            this.mAppWidgetHost.startListening();
        }
    }

    private void setAllAppsAdapter(ApplicationsAdapter adapter) {
        for (Object obj : this.mAllAppsView.getAllContents()) {
            if (obj instanceof AllAppsListView) {
                ((AllAppsListView) obj).setAdapter(adapter);
            }
            if (obj instanceof AllAppsGridView) {
                ((AllAppsGridView) obj).setAdapter(adapter);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    void onDesktopItemsLoaded() {
        if (!this.mDestroyed) {
            if (localLOGD && localLOGD) {
                Log.d("Home", "setting grid adapter");
            }
            this.mApplicationsAdapter = getModel().getApplicationsAdapter();
            this.mIsListAdapterReady = true;
            if (this.mListAdapter == null || this.mOnConfigChangedReloading) {
                this.mListAdapter = new AddListAdapter(this, this, false);
            }
            for (ViewGroup c : this.mAllAppsView.getAllContents()) {
                if (c instanceof AddWidgetLayout) {
                    ((AddWidgetLayout) c).setAdapter(this.mListAdapter);
                    ((AddWidgetLayout) c).setAddWidgetListener(new AddToHomeItemClickListener());
                    ((AddWidgetLayout) c).setPersonalizeOnItemClickListener(new PersonalizeOnItemClickListener());
                }
            }
            setAllAppsAdapter(this.mApplicationsAdapter);
            bindDesktopItems();
            if (SettingUtil.isTabletDevice()) {
                updateButtonBarViews();
            }
        }
    }

    public void refreshAddToHomeAdapter() {
        if (this.mHandler != null) {
            this.mHandler.sendEmptyMessageDelayed(1001, 10L);
        }
    }

    private void bindDesktopItems() {
        ArrayList<ItemInfo> shortcuts = sModel.getDesktopItems();
        ArrayList<LauncherAppWidgetInfo> appWidgets = sModel.getDesktopAppWidgets();
        if (shortcuts != null && appWidgets != null) {
            Workspace workspace = this.mWorkspace;
            int count = workspace.getChildCount();
            for (int i = 0; i < count; i++) {
                View childView = workspace.getChildAt(i);
                if (childView instanceof ViewGroup) {
                    ((ViewGroup) childView).removeAllViewsInLayout();
                }
            }
            if (this.mBinder != null) {
                this.mBinder.mTerminate = true;
            }
            this.mBinder = new DesktopBinder(this, shortcuts, appWidgets);
            this.mBinder.startBindingItems();
        }
    }

    private void showTutorialNotice(int screen) {
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showTutorialNotice() {
        if (this.mIsShowTutorialNotice && this.mFxWorkspace != null) {
            this.mFxWorkspace.showTipBubble();
        }
    }

    private void hideTutorialNotice() {
        if (this.mFxWorkspace != null) {
            this.mFxWorkspace.hideTipBubble();
        }
    }

    public void removeTutorialNotice() {
        if (localLOGD) {
            Log.d(LOG_TAG, "removeTutorialNotice() , mIsShowTutorialNotice = " + this.mIsShowTutorialNotice);
        }
        if (this.mIsShowTutorialNotice) {
            this.mIsShowTutorialNotice = false;
            SharedPreferences preferences = getSharedPreferences("launcher", 0);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean(KEY_TUTORIAL_NOTICE, false);
            editor.apply();
            if (localLOGD && localLOGD) {
                Log.d(LOG_TAG, "removing tutorial notice.");
            }
            hideTutorialNotice();
            this.mTutorialNoticeViews = null;
        }
    }

    private int findEmptyScreen(int from, int inc) {
        int i = from;
        while (i >= 0 && i < this.mWorkspace.getChildCount()) {
            View temp = this.mWorkspace.getChildAt(i);
            if (temp instanceof CellLayout) {
                CellLayout cell = (CellLayout) temp;
                if (cell.getChildCount() == 0) {
                    return i;
                }
            }
            i += inc;
        }
        return -1;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void bindItems(DesktopBinder binder, ArrayList<ItemInfo> shortcuts, int start, int count) {
        Workspace workspace = this.mWorkspace;
        boolean z = this.mDesktopLocked;
        int end = Math.min(start + 200, count);
        int i = start;
        while (i < end) {
            ItemInfo item = shortcuts.get(i);
            switch (item.itemType) {
                case 0:
                case 1:
                case 2:
                case 3:
                    this.mDesktopItemController.addFxShortcutAsync((FxShortcutInfo) item);
                    break;
                case 4:
                default:
                    if (!(item instanceof WidgetProxy)) {
                        break;
                    } else {
                        binder.addHtcWidget((WidgetProxy) item);
                        break;
                    }
                case 5:
                    this.mDesktopItemController.addFxWidgetAsync((FxItemInfo) item);
                    break;
            }
            i++;
        }
        if (end >= count) {
            finishBindDesktopItems();
            binder.startBindingHtcWidgets();
            binder.startBindingAppWidgetsWhenIdle();
            return;
        }
        binder.obtainMessage(1, i, count).sendToTarget();
    }

    private void finishBindDesktopItems() {
        if (this.mSavedState != null) {
            if (!this.mWorkspace.restoreFocus()) {
                this.mWorkspace.getChildAt(this.mWorkspace.getCurrentScreenIndex()).requestFocus();
            }
            long[] userFolders = this.mSavedState.getLongArray(RUNTIME_STATE_USER_FOLDERS);
            if (userFolders != null) {
                for (long folderId : userFolders) {
                    FolderInfo info = sModel.findFolderById(folderId);
                    if (info != null) {
                        this.mDesktopItemController.openFolder(info);
                    }
                }
                Folder openFolder = this.mWorkspace.getOpenFolder();
                if (openFolder != null) {
                    openFolder.requestFocus();
                }
            }
            boolean allApps = this.mSavedState.getBoolean(RUNTIME_STATE_ALL_APPS_FOLDER, false);
            if (allApps) {
                int drawerMode = this.mSavedState.getInt(RUNTIME_STATE_SLIDING_ALL_PROGRAM, 0);
                switch (drawerMode) {
                    case 0:
                        changeDrawerContentById(mProgramListId);
                        break;
                    case 1:
                        changeDrawerContentById(R.id.content_add_to_home);
                        break;
                }
                this.mDrawer.setVisibility(0);
                this.mDrawer.open();
                this.mDrawer.requestFocus();
            }
            this.mSavedState = null;
        }
        if (this.mSavedInstanceState != null) {
            super.onRestoreInstanceState(this.mSavedInstanceState);
            this.mWorkspace.restoreFocus();
            this.mSavedInstanceState = null;
        }
        if (this.mDrawer.isOpened() && !this.mDrawer.hasFocus()) {
            this.mDrawer.requestFocus();
        }
        this.mDesktopLocked = false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void bindAppWidgets(DesktopBinder binder, LinkedList<LauncherAppWidgetInfo> appWidgets) {
        Workspace workspace = this.mWorkspace;
        boolean desktopLocked = this.mDesktopLocked;
        if (!appWidgets.isEmpty()) {
            LauncherAppWidgetInfo item = appWidgets.removeFirst();
            int appWidgetId = item.appWidgetId;
            AppWidgetProviderInfo appWidgetInfo = this.mAppWidgetManager.getAppWidgetInfo(appWidgetId);
            item.hostView = this.mAppWidgetHost.createView(getApplicationContext(), appWidgetId, appWidgetInfo);
            if (localLOGD && localLOGD) {
                Log.d(LOG_TAG, String.format("about to setAppWidget for id=%d, info=%s", Integer.valueOf(appWidgetId), appWidgetInfo));
            }
            item.hostView.setAppWidget(appWidgetId, appWidgetInfo);
            item.hostView.setTag(item);
            this.mDesktopItemController.addLegacyItemToDesktop(item.hostView, item, item.screen, item.cellX, item.cellY, item.spanX, item.spanY, !desktopLocked);
        }
        if (appWidgets.isEmpty()) {
            finishBindDesktopAppWidgets();
        } else {
            binder.obtainMessage(2).sendToTarget();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void finishBindDesktopAppWidgets() {
        if (localLOGD) {
            Log.d(LOG_TAG, "finishBindDesktopAppWidgets");
        }
        SharedPreferences preferences = getSharedPreferences("launcher", 0);
        String currentSkin = CustomResourceUtil.getSkinName(this, CustomResourceUtil.getAppliedSkinPackageName());
        if (currentSkin != null && !currentSkin.equals(preferences.getString(KEY_CURRENT_SKIN_NAME, currentSkin))) {
            android.app.WallpaperManager wm = android.app.WallpaperManager.getInstance(this);
            WallpaperInfo wallpaperInfo = wm.getWallpaperInfo();
            if (wallpaperInfo == null) {
                if (localLOGD) {
                    Log.d(LOG_TAG, "skin changed to " + currentSkin + " and apply static wallpaper");
                }
                Drawable drawable = wm.getDrawable();
                WidgetWorkspaceManager manager = WidgetWorkspaceManager.instance(this);
                manager.saveHomeWallpaper(((BitmapDrawable) drawable).getBitmap().copy(Bitmap.Config.ARGB_8888, false), new SaveWallpaperCompleteListener());
            } else {
                if (localLOGD) {
                    Log.d(LOG_TAG, "skin changed to " + currentSkin + " and apply live wallpaper " + ((Object) wallpaperInfo.loadLabel(getPackageManager())));
                }
                String componentName = wallpaperInfo.getComponent().flattenToString();
                if (componentName != null) {
                    WidgetWorkspaceManager wwm = WidgetWorkspaceManager.instance();
                    if (!componentName.equals(wwm.getCurrentWallpaperComponent())) {
                        wwm.setWallpaperComponent(wwm.getCurrentWorkspaceId(), componentName);
                    }
                }
            }
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString(KEY_CURRENT_SKIN_NAME, currentSkin);
            editor.apply();
        } else if (preferences.getString(KEY_CURRENT_SKIN_NAME, null) == null) {
            SharedPreferences.Editor editor2 = preferences.edit();
            editor2.putString(KEY_CURRENT_SKIN_NAME, currentSkin);
            editor2.apply();
        }
        if (this.mIsWorkspaceChanging) {
            WidgetWorkspaceManager manager2 = WidgetWorkspaceManager.instance(this);
            manager2.loadHomeWallpaper(this);
            this.mIsWorkspaceChanging = false;
            this.mWorkspace.unlock();
        }
        this.mFinishLoading++;
        if (this.mFinishLoading >= 2) {
            finishLoading();
        }
    }

    DragController getDragController() {
        return this.mDragLayer;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void onClickPhone() {
        removeTutorialNotice();
        if (localLOGD) {
            Log.w("Handle buttons", "try startCallActivity ");
        }
        try {
            startCallActivity();
        } catch (Exception e) {
            Toast.makeText((Context) this, R.string.phone, LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK).show();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void startActivitySafely(Intent intent) {
        try {
            synchronized (this) {
                if (this.mActivityLaunched) {
                    Logger.w(LOG_TAG, "Ignoring starting of " + intent);
                } else {
                    intent.addFlags(268435456);
                    startActivity(intent);
                    this.mActivityLaunched = true;
                    cancelDelayed(this.mResetLaunchState);
                    runDelayed(this.mResetLaunchState, 1000L);
                    if (intent.getComponent() != null && intent.getComponent().getPackageName() != null) {
                        ReusableULogData uLogData = ReusableULogData.obtain();
                        uLogData.setAppId("com.htc.launcher").setCategory("app_launch");
                        uLogData.addData(LoggingEvents.VoiceIme.EXTRA_TEXT_MODIFIED_TYPE, this.launchAppType);
                        if (localLOGD) {
                            Log.d(LOG_TAG, "HTC user profiling     type     " + this.launchAppType);
                        }
                        this.launchAppType = null;
                        uLogData.addData("app", intent.getComponent().getPackageName());
                        if (localLOGD) {
                            Log.d(LOG_TAG, "HTC user profiling     app     " + intent.getComponent().getPackageName());
                        }
                        ULog.log(uLogData);
                        uLogData.recycle();
                    }
                }
            }
        } catch (ActivityNotFoundException e) {
            Toast.makeText((Context) this, R.string.activity_not_found, 0).show();
        } catch (SecurityException e2) {
            Toast.makeText((Context) this, R.string.activity_not_found, 0).show();
            Log.e(LOG_TAG, "Launcher does not have the permission to launch " + intent + ". Make sure to create a MAIN intent-filter for the corresponding activity or use the exported attribute for this activity.", e2);
        }
    }

    Drawable getDefaultWallpaper() {
        return getWallpaper();
    }

    void loadWallpaper() {
        if (!SettingUtil.isLiveWallaperSupported()) {
            if (sWallpaper == null) {
                Drawable drawable = getDefaultWallpaper();
                if (drawable instanceof BitmapDrawable) {
                    sWallpaper = ((BitmapDrawable) drawable).getBitmap();
                } else {
                    throw new IllegalStateException("The wallpaper must be a BitmapDrawable.");
                }
            }
            runOnUiThread(new Runnable() { // from class: com.htc.launcher.Launcher.12
                @Override // java.lang.Runnable
                public void run() {
                    Launcher.this.mWorkspace.loadWallpaper(Launcher.sWallpaper);
                }
            });
        }
    }

    boolean isWorkspaceLocked() {
        return this.mDesktopLocked;
    }

    private boolean isTutorialView(View v) {
        if (v.getTag() instanceof String) {
            String checkStr = v.getTag().toString();
            if (checkStr.equals(KEY_TUTORIAL_NOTICE)) {
                return true;
            }
        }
        return false;
    }

    private CellInfo findCellInfo(View v) {
        while (v != null) {
            try {
                if (v instanceof CellLayout) {
                    break;
                }
                v = (View) v.getParent();
            } catch (Exception e) {
                Log.i(LOG_TAG, String.format("findCellInfo exception:", e.toString()));
                return null;
            }
        }
        return (CellInfo) v.getTag();
    }

    private boolean isValidCellInfo(CellInfo cellInfo) {
        return this.mWorkspace.isValidCellInfo(cellInfo);
    }

    private boolean isEmptyCell(CellInfo cellInfo) {
        FxScreen screen = this.mFxWorkspace.getScreen(this.mWorkspace.getCurrentScreenIndex());
        return !screen.findItemInCell(cellInfo);
    }

    @Override // android.view.View.OnLongClickListener
    public boolean onLongClick(View v) {
        if (localLOGD) {
            Log.d(LOG_TAG, "onLongClick:" + v);
        }
        if (v == null) {
            return true;
        }
        if (this.mDesktopLocked) {
            return false;
        }
        boolean bTutorial = isTutorialView(v);
        removeTutorialNotice();
        if (this.mLeapController.isLeapMode()) {
            return true;
        }
        CellInfo cellInfo = findCellInfo(v);
        if (cellInfo == null) {
            return false;
        }
        if (!this.mWorkspace.allowLongPress()) {
            return true;
        }
        if (this.mDragLayer.isDragging()) {
            Log.e(LOG_TAG, "Illegal state: long click while dragging");
            return false;
        }
        boolean onEmptySpace = isEmptyCell(cellInfo);
        if (onEmptySpace || bTutorial) {
            onClickAddtoHome(cellInfo);
            return true;
        }
        if (cellInfo.item instanceof Folder) {
            return false;
        }
        boolean isCellValid = isValidCellInfo(cellInfo);
        if (!isCellValid) {
            return false;
        }
        mSettingWidgetCellInfo = cellInfo;
        if (localLOGD) {
            Log.d(LOG_TAG, "[EDIT_DEBUG] onLongClick() mWorkspace.startDrag()");
        }
        this.mWorkspace.startDrag(cellInfo);
        return true;
    }

    public static LauncherModel getModel() {
        return sModel;
    }

    public void closeAllApplications() {
        this.mIsLauncherAddtoHome = false;
        this.mIsLauncherAllProgram = false;
        this.mDrawer.close();
        this.mBottomBarArea.setOnTouchListener(this.mFxWorkspace);
    }

    View getDrawerHandle() {
        return this.mHandleView;
    }

    public void setBottomBarAreaVisibility(int visibility) {
        this.mBottomBarArea.setVisibility(visibility);
    }

    public boolean isOnOrientationChange() {
        return this.mOnOrientationChange;
    }

    public boolean isOnConfigurationChanged() {
        return this.mOnConfigurationChanged;
    }

    boolean isDrawerDown() {
        return (this.mDrawer.isMoving() || this.mDrawer.isOpened()) ? false : true;
    }

    boolean isDrawerUp() {
        return this.mDrawer.isOpened() && !this.mDrawer.isMoving();
    }

    boolean isDrawerMoving() {
        return this.mDrawer.isMoving();
    }

    public Workspace getWorkspace() {
        return this.mWorkspace;
    }

    @Deprecated
    View getApplicationsGrid() {
        return null;
    }

    private class NoSearchProgressDialog extends ProgressDialog {
        public NoSearchProgressDialog(Context context) {
            super(context);
        }

        @Override // android.app.Dialog, android.view.Window.Callback
        public boolean onSearchRequested() {
            return false;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case 1:
                return new CreateShortcut().createDialog();
            case 2:
                return new RenameFolder().createDialog();
            case 100:
                SharedPreferences preferences = getSharedPreferences(WidgetPackageManager.REFERENCES, 0);
                boolean scanDone = preferences.getBoolean(GeneralPurposeReceiver.PREF_SCAN_DONE, false);
                NoSearchProgressDialog progressDialog = new NoSearchProgressDialog(this);
                progressDialog.setMessage(getResources().getString(scanDone ? 34341027 : R.string.msg_long_waiting));
                progressDialog.setIndeterminate(true);
                progressDialog.setCancelable(false);
                return progressDialog;
            case 102:
                try {
                    HtcAlertDialog.Builder builder = new HtcAlertDialog.Builder(this);
                    builder.setTitle(R.string.chooser_apply_wallpaper);
                    View textEntryView = View.inflate(this, R.layout.scenes_chooser, null);
                    textEntryView.setBackgroundColor(-1);
                    ListView list = (ListView) textEntryView.findViewById(R.id.themes_list);
                    AddWallpaperDialogAdapter adapter = new AddWallpaperDialogAdapter(this);
                    list.setVerticalFadingEdgeEnabled(false);
                    list.setAdapter((ListAdapter) adapter);
                    list.setItemsCanFocus(false);
                    list.setChoiceMode(1);
                    list.setOnItemClickListener(new AdapterView.OnItemClickListener() { // from class: com.htc.launcher.Launcher.13
                        @Override // android.widget.AdapterView.OnItemClickListener
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id2) {
                            switch (position) {
                                case 0:
                                    Launcher.this.startWallpaperNoLiveWallpaper();
                                    break;
                                case 1:
                                    Launcher.this.startLockScreenWallpaper();
                                    break;
                            }
                            Launcher.this.dismissDialog(102);
                        }
                    });
                    builder.setView(textEntryView, 0, 0, 0, 0);
                    return builder.create();
                } catch (Exception e) {
                    e.printStackTrace();
                    break;
                }
            case 103:
                break;
            default:
                return super.onCreateDialog(id);
        }
        if (this.mApplicationsAdapter == null || this.mApplicationsAdapter.getList() == null) {
            return null;
        }
        int currentSort = 0;
        if (this.mApplicationsAdapter != null) {
            if (FilterableAndSortableApplicationInfoList.ALPHABET.equals(this.mApplicationsAdapter.getList().getComparator())) {
                currentSort = 0;
            } else if (FilterableAndSortableApplicationInfoList.NEWEST_FIRST.equals(this.mApplicationsAdapter.getList().getComparator())) {
                currentSort = 1;
            } else {
                currentSort = 2;
            }
        }
        return new HtcAlertDialog.Builder(this).setTitle(34341177).setSingleChoiceItems(R.array.app_sort, currentSort, new DialogInterface.OnClickListener() { // from class: com.htc.launcher.Launcher.14
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0:
                        Launcher.this.mApplicationsAdapter.getList().sort(FilterableAndSortableApplicationInfoList.ALPHABET);
                        break;
                    case 1:
                        Launcher.this.mApplicationsAdapter.getList().sort(FilterableAndSortableApplicationInfoList.NEWEST_FIRST);
                        break;
                    case 2:
                        Launcher.this.mApplicationsAdapter.getList().sort(FilterableAndSortableApplicationInfoList.OLDEST_FIRST);
                        break;
                }
                ApplicationsAdapter applicationList = Launcher.getModel().getApplicationsAdapter();
                applicationList.notifyDataSetChanged();
                Launcher.this.dismissDialog(103);
                if (2131099651 == Launcher.mProgramListId) {
                    AllAppsListView listView = (AllAppsListView) Launcher.this.mAllAppsView.findViewById(R.id.content_list);
                    listView.setFastScrollEnabled(listView.isFastScrollAllowed());
                }
            }
        }).create();
    }

    protected void onPrepareDialog(int id, Dialog dialog) {
        switch (id) {
            case 1:
                this.mWorkspace.lock();
                break;
            case 2:
                this.lastDialog = new WeakReference<>(dialog);
                this.mWorkspace.lock();
                EditText input = (EditText) dialog.findViewById(R.id.folder_name);
                if (this.mFolderInfo != null) {
                    CharSequence text = this.mFolderInfo.title;
                    input.setText(text);
                    input.setSelection(0, text.length());
                }
                input.setSingleLine();
                break;
        }
    }

    void showRenameDialog(FolderInfo info) {
        this.mFolderInfo = info;
        this.mWaitingForResult = true;
        showDialog(2);
    }

    private class RenameFolder {
        private EditText mInput;

        private RenameFolder() {
        }

        Dialog createDialog() {
            Launcher.this.mWaitingForResult = true;
            View layout = View.inflate(Launcher.this, R.layout.rename_folder, null);
            this.mInput = (EditText) layout.findViewById(R.id.folder_name);
            int colorID = CustomResourceUtil.getColorResIdentifier(Launcher.this.getBaseContext(), "app_selection_highlight", 0);
            if (colorID != 0) {
                this.mInput.setHighlightColor(Launcher.this.getResources().getColor(colorID));
            }
            HtcAlertDialog.Builder htcBuilder = new HtcAlertDialog.Builder(Launcher.this);
            htcBuilder.setIcon(0);
            htcBuilder.setTitle(Launcher.this.getString(R.string.rename_folder_title));
            htcBuilder.setCancelable(true);
            htcBuilder.setNegativeButton(Launcher.this.getString(34341181), new DialogInterface.OnClickListener() { // from class: com.htc.launcher.Launcher.RenameFolder.1
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialog, int which) {
                    RenameFolder.this.cleanup();
                }
            });
            htcBuilder.setPositiveButton(Launcher.this.getString(34341180), new DialogInterface.OnClickListener() { // from class: com.htc.launcher.Launcher.RenameFolder.2
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialog, int which) {
                    RenameFolder.this.changeFolderName();
                }
            });
            htcBuilder.setView(layout);
            HtcAlertDialog create = htcBuilder.create();
            if (create != null) {
                create.setOnDismissListener(new DialogInterface.OnDismissListener() { // from class: com.htc.launcher.Launcher.RenameFolder.3
                    @Override // android.content.DialogInterface.OnDismissListener
                    public void onDismiss(DialogInterface dialog) {
                        if (Launcher.localLOGD) {
                            Log.d("Steven", "Dialog canceled");
                        }
                        RenameFolder.this.cleanup();
                    }
                });
            }
            return create;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void changeFolderName() {
            String name = this.mInput.getText().toString();
            if (!TextUtils.isEmpty(name)) {
                Launcher.this.mFolderInfo = Launcher.sModel.findFolderById(Launcher.this.mFolderInfo.id);
                if (Launcher.this.mFolderInfo != null) {
                    Launcher.this.mFolderInfo.title = name;
                    LauncherModel.updateItemInDatabase(Launcher.this, Launcher.this.mFolderInfo);
                    if (!Launcher.this.mDesktopLocked) {
                        FxItem fxItem = Launcher.this.getDesktopItemController().getFxShortcutItem(Launcher.this.mFolderInfo.getId());
                        if (fxItem == null) {
                            Launcher.this.mDesktopLocked = true;
                            Launcher.this.mDrawer.lock();
                            Launcher.sModel.loadUserItems(false, Launcher.this, false, false);
                            Log.d(Launcher.DEBUG_DB_TAG, "Launcher.changeFolderName() --> loadUserItems(false, launcher, false, false)");
                        } else {
                            ((FolderIcon) fxItem).setTitle(name);
                        }
                    } else {
                        Launcher.this.mDrawer.lock();
                        Launcher.sModel.loadUserItems(false, Launcher.this, false, false);
                        Log.d(Launcher.DEBUG_DB_TAG, "Launcher.changeFolderName(), mDesktopLocked --> loadUserItems(false, launcher, false, false)");
                    }
                } else {
                    cleanup();
                    return;
                }
            }
            cleanup();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void cleanup() {
            Launcher.this.mWorkspace.unlock();
            Launcher.this.dismissDialog(2);
            Launcher.this.mWaitingForResult = false;
            Launcher.this.mFolderInfo = null;
        }
    }

    private class AddToHomeItemClickListener implements AddWidgetLayout.OnAddWidgetListener {
        private AddToHomeItemClickListener() {
        }

        private void cleanup() {
            Launcher.this.mWorkspace.unlock();
        }

        @Override // com.htc.launcher.AddWidgetLayout.OnAddWidgetListener
        public void onItemClick(HtcAdapterView<?> parent, View view, int position, long id) {
            cleanup();
            Object tag = view.getTag();
            if (tag instanceof AddAdapter.ListItem) {
                AddAdapter.ListItem item = (AddAdapter.ListItem) tag;
                switch (item.actionTag) {
                    case 3:
                        int gadgetId = Launcher.this.mAppWidgetHost.allocateAppWidgetId();
                        Intent pickIntent = new Intent("com.htc.test.gadgetactivity");
                        pickIntent.putExtra("android.intent.extra.TITLE", Launcher.this.getString(R.string.menu_item_add_google_widget));
                        pickIntent.putExtra("appWidgetId", gadgetId);
                        Launcher.this.startActivityForResult(pickIntent, 9);
                        break;
                    case 5:
                        if (Launcher.this.mAddItemCellInfo == null) {
                            Launcher.this.mAddItemCellInfo = Launcher.this.mWorkspace.findAllVacantCells(null);
                        }
                        Launcher.this.mDesktopItemController.addFolder(!Launcher.this.mDesktopLocked);
                        Launcher.this.closeDrawer(false);
                        try {
                            Launcher.this.dismissDialog(1);
                            break;
                        } catch (Exception e) {
                            return;
                        }
                    case 100:
                        pickWidget(item);
                        break;
                    case 101:
                        Launcher.this.mAddHtcWidgetByOtherActivity = true;
                        Intent intent = new Intent();
                        intent.setComponent(new ComponentName("com.htc.wdm", "com.htc.wdm.activity.WidgetList"));
                        Launcher.this.startActivity(intent);
                        break;
                    case 102:
                        Launcher.this.mAddHtcWidgetByOtherActivity = true;
                        pickAllFxWidget();
                        break;
                    case AddAdapter.ITEM_FXWIDGET /* 106 */:
                        pickFxWidget(item);
                        break;
                    case AddAdapter.EXCUTE_SHORTCUT /* 400 */:
                        Launcher.this.mAddHtcWidgetByOtherActivity = true;
                        Intent shortcutIntent = new Intent("android.intent.action.CREATE_SHORTCUT");
                        Intent intent2 = new Intent(shortcutIntent);
                        intent2.setClassName(item.packageName, item.className);
                        Launcher.this.onActivityResult(7, -1, intent2);
                        break;
                    case AddAdapter.EXCUTE_GOOGLE_WIDGET /* 401 */:
                        int gadgetId2 = Launcher.this.mAppWidgetHost.allocateAppWidgetId();
                        Intent result = new Intent();
                        result.putExtra("appWidgetId", gadgetId2);
                        Launcher.this.onActivityResult(7, 0, result);
                        Intent pickIntent2 = new Intent("com.htc.test.gadgetactivity");
                        pickIntent2.putExtra("android.intent.extra.TITLE", Launcher.this.getString(R.string.menu_item_add_google_widget));
                        pickIntent2.putExtra("appWidgetId", gadgetId2);
                        pickIntent2.putExtra("Excute", 1);
                        pickIntent2.putExtra("packagename", item.packageName);
                        pickIntent2.putExtra("classname", item.className);
                        Launcher.this.startActivityForResult(pickIntent2, 9);
                        break;
                    case AddAdapter.EXCUTE_PROGRAM /* 402 */:
                        Launcher.this.closeDrawer(false);
                        Intent mainIntent = new Intent("android.intent.action.MAIN", (Uri) null);
                        mainIntent.addCategory("android.intent.category.LAUNCHER");
                        Intent intent3 = new Intent(mainIntent);
                        intent3.setComponent(item.mComponent);
                        Launcher.this.onActivityResult(6, -1, intent3);
                        break;
                    case AddAdapter.EXCUTE_LIVE_FOLDER /* 403 */:
                        Intent liveFolderIntent = new Intent("android.intent.action.CREATE_LIVE_FOLDER");
                        Intent intent4 = new Intent(liveFolderIntent);
                        intent4.setClassName(item.packageName, item.className);
                        Launcher.this.onActivityResult(8, -1, intent4);
                        break;
                    case AddAdapter.EXCUTE_BOOKMARK_SHORTCUT /* 404 */:
                        Launcher.this.closeDrawer(false);
                        Launcher.this.onActivityResult(11, -1, item.intent);
                        break;
                }
            }
        }

        private void pickWidget(AddAdapter.ListItem item) {
            try {
                if (Launcher.localLOGD) {
                    Log.v(Launcher.LOG_TAG, "Launcher: AddList onItemClick() item.widgetItem.isGroupItem() = " + item.widgetItem.isGroupItem());
                }
                if (item.widgetItem.isGroupItem()) {
                    Launcher.this.mAddHtcWidgetByOtherActivity = true;
                    WidgetItem.startWidgetPicker(Launcher.this, item.widgetItem.mItemType);
                } else {
                    Launcher.this.mAddHtcWidgetByOtherActivity = true;
                    WidgetItem.startWidgetPicker(Launcher.this, item.widgetItem.mItemType);
                }
            } catch (Throwable ex) {
                handleError(ex);
            }
        }

        private void pickFxWidget(AddAdapter.ListItem item) {
            Intent intent = new Intent();
            intent.setComponent(new ComponentName("com.htc.AddProgramWidget", "com.htc.AddProgramWidget.fusionwidget.StyleChooser"));
            ComponentName[] p = {item.mComponent};
            try {
                intent.putExtra(DesktopItemController.FXWIDGET_PICKER_EXTRA_KEY_WIDGET_PROVIDER_ARRAY, p);
                Launcher.this.startActivityForResult(intent, 12);
            } catch (Throwable ex) {
                handleError(ex);
            }
            Launcher.this.mAddHtcWidgetByOtherActivity = true;
        }

        private void pickAllFxWidget() {
            Intent intent = new Intent();
            intent.setComponent(new ComponentName("com.htc.AddProgramWidget", "com.htc.AddProgramWidget.fusionwidget.StyleChooser"));
            try {
                Launcher.this.startActivityForResult(intent, 12);
            } catch (Throwable ex) {
                handleError(ex);
            }
            Launcher.this.mAddHtcWidgetByOtherActivity = true;
        }

        private void handleError(Throwable exception) {
            Launcher.this.mAddHtcWidgetByOtherActivity = false;
            Log.e(Launcher.LOG_TAG, exception.getMessage(), exception);
            Toast.makeText((Context) Launcher.this, (CharSequence) Launcher.this.getString(R.string.widget_error_text), 0).show();
        }
    }

    private class CreateShortcut implements DialogInterface.OnClickListener, DialogInterface.OnCancelListener {
        private AddAdapter mAdapter;

        private CreateShortcut() {
        }

        Dialog createDialog() {
            Launcher.this.mWaitingForResult = true;
            this.mAdapter = new AddAdapter(Launcher.this);
            AlertDialog.Builder builder = new AlertDialog.Builder(Launcher.this);
            builder.setTitle(Launcher.this.getString(R.string.add_to_home));
            builder.setAdapter(this.mAdapter, this);
            builder.setInverseBackgroundForced(true);
            AlertDialog dialog = builder.create();
            dialog.setOnCancelListener(this);
            return dialog;
        }

        @Override // android.content.DialogInterface.OnCancelListener
        public void onCancel(DialogInterface dialog) {
            Launcher.this.mWaitingForResult = false;
            cleanup();
        }

        private void cleanup() {
            Launcher.this.mWorkspace.unlock();
            Launcher.this.dismissDialog(1);
        }

        @Override // android.content.DialogInterface.OnClickListener
        public void onClick(DialogInterface dialog, int which) {
            Resources res = Launcher.this.getResources();
            cleanup();
            switch (which) {
                case 1:
                    Bundle bundle = new Bundle();
                    ArrayList<String> shortcutNames = new ArrayList<>();
                    shortcutNames.add(res.getString(R.string.group_applications));
                    bundle.putStringArrayList("android.intent.extra.shortcut.NAME", shortcutNames);
                    ArrayList<Intent.ShortcutIconResource> shortcutIcons = new ArrayList<>();
                    shortcutIcons.add(Intent.ShortcutIconResource.fromContext(Launcher.this, 34079056));
                    bundle.putParcelableArrayList("android.intent.extra.shortcut.ICON_RESOURCE", shortcutIcons);
                    Intent pickIntent = new Intent("android.intent.action.PICK_ACTIVITY");
                    pickIntent.putExtra("android.intent.extra.INTENT", new Intent("android.intent.action.CREATE_SHORTCUT"));
                    pickIntent.putExtra("android.intent.extra.TITLE", Launcher.this.getText(R.string.title_select_shortcut));
                    pickIntent.putExtras(bundle);
                    Launcher.this.startActivityForResult(pickIntent, 7);
                    break;
                case 3:
                    int appWidgetId = Launcher.this.mAppWidgetHost.allocateAppWidgetId();
                    Intent pickIntent2 = new Intent("android.appwidget.action.APPWIDGET_PICK");
                    pickIntent2.putExtra("appWidgetId", appWidgetId);
                    ArrayList<AppWidgetProviderInfo> customInfo = new ArrayList<>();
                    AppWidgetProviderInfo info = new AppWidgetProviderInfo();
                    info.provider = new ComponentName(Launcher.this.getPackageName(), "XXX.YYY");
                    info.label = Launcher.this.getString(34341176);
                    info.icon = R.drawable.ic_search_widget;
                    customInfo.add(info);
                    pickIntent2.putParcelableArrayListExtra("customInfo", customInfo);
                    ArrayList<Bundle> customExtras = new ArrayList<>();
                    Bundle b = new Bundle();
                    b.putString("custom_widget", "search_widget");
                    customExtras.add(b);
                    pickIntent2.putParcelableArrayListExtra("customExtras", customExtras);
                    Launcher.this.startActivityForResult(pickIntent2, 9);
                    break;
                case 4:
                    Bundle bundle2 = new Bundle();
                    ArrayList<String> shortcutNames2 = new ArrayList<>();
                    shortcutNames2.add(res.getString(R.string.folder_name));
                    bundle2.putStringArrayList("android.intent.extra.shortcut.NAME", shortcutNames2);
                    ArrayList<Intent.ShortcutIconResource> shortcutIcons2 = new ArrayList<>();
                    shortcutIcons2.add(Intent.ShortcutIconResource.fromContext(Launcher.this, 34079058));
                    bundle2.putParcelableArrayList("android.intent.extra.shortcut.ICON_RESOURCE", shortcutIcons2);
                    Intent pickIntent3 = new Intent("android.intent.action.PICK_ACTIVITY");
                    pickIntent3.putExtra("android.intent.extra.INTENT", new Intent("android.intent.action.CREATE_LIVE_FOLDER"));
                    pickIntent3.putExtra("android.intent.extra.TITLE", Launcher.this.getText(R.string.title_select_live_folder));
                    pickIntent3.putExtras(bundle2);
                    Launcher.this.startActivityForResult(pickIntent3, 8);
                    break;
                case 6:
                    Launcher.this.startWallpaper();
                    break;
            }
        }
    }

    void setCurrentWorkspace(int workspaceId, boolean autoSave) {
        setCurrentWorkspace(workspaceId, true, autoSave);
    }

    void setCurrentWorkspace(int workspaceId, boolean isNeedBackLightEffect, boolean autoSave) {
        setCurrentWorkspace(workspaceId, isNeedBackLightEffect, false, autoSave);
    }

    /* JADX WARN: Multi-variable type inference failed */
    void setCurrentWorkspace(final int workspaceId, boolean isNeedBackLightEffect, boolean forceReload, boolean autoSave) {
        WidgetWorkspaceManager manager = WidgetWorkspaceManager.instance(this);
        int oldId = manager.getCurrentWorkspaceId();
        if (autoSave) {
            if (localLOGD) {
                Log.d(LOG_TAG, "duplicate current scene to workspace " + oldId);
            }
            LauncherModel.duplicateAllItems(this, 0, oldId);
        }
        if (manager.setCurrentWorkspace(workspaceId) || forceReload) {
            this.mWorkspace.leaveEditMode();
            this.mIsWorkspaceChanging = true;
            this.mWorkspace.lock();
            if (localLOGD) {
                Log.d(LOG_TAG, "setCurrentWorkspace , removeTutorialNotice() , mIsShowTutorialNotice = " + this.mIsShowTutorialNotice);
            }
            removeTutorialNotice();
            if (this.mFxWorkspace != null) {
                this.mFxWorkspace.showAllScreens();
                this.mFxWorkspace.thawAllScreens();
                this.mFxWorkspace.hide();
            }
            this.mIsLoading = true;
            lockOrientation();
            showDialog(100);
            if (SettingUtil.isLiveWallaperSupported()) {
                manager.changeHomeWallpaper(this);
            } else {
                manager.changeHomeWallpaper(this);
                manager.changeLockscreenWallpaper();
            }
            Thread thread = new Thread() { // from class: com.htc.launcher.Launcher.15
                @Override // java.lang.Thread, java.lang.Runnable
                public void run() {
                    LauncherModel.backupAllItems(Launcher.this);
                    LauncherModel.deleteAllItemsFromDatabase(Launcher.this, 0);
                    LauncherModel.duplicateAllItems(Launcher.this, workspaceId, 0);
                    Launcher.this.runOnUiThread(new Runnable() { // from class: com.htc.launcher.Launcher.15.1
                        @Override // java.lang.Runnable
                        public void run() {
                            Launcher.this.removeWidgetsAndLoadUserItems(false, Launcher.this, false, false, Workspace.getDefaultScreenIndex(), false);
                        }
                    });
                }
            };
            thread.start();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    void removeWidgetsAndLoadUserItems(boolean isLaunching, Launcher launcher, boolean localeChanged, boolean loadApplications, int toScreen, boolean reloadWallpaper) {
        boolean desktopLocked = isWorkspaceLocked();
        this.mDesktopLocked = true;
        sWidgetPackageManager.removeAllWidgetLayout(this);
        ArrayList<LauncherAppWidgetInfo> appWidgets = sModel.getDesktopAppWidgets();
        if (appWidgets != null) {
            Iterator i$ = appWidgets.iterator();
            while (i$.hasNext()) {
                LauncherAppWidgetInfo info = i$.next();
                if (info.isTWM_Widget()) {
                    this.mAppWidgetHost.deleteAppWidgetId(info.appWidgetId);
                    info.appWidgetId = -1;
                }
            }
        }
        this.mDesktopLocked = desktopLocked;
        Workspace workspace = this.mWorkspace;
        workspace.clear();
        this.mFxWorkspace.removeAllItems();
        this.mFxWidgetManager.removeAllWidgets();
        if (toScreen >= 0) {
            setScreen(toScreen);
            this.mWorkspace.setCurrentScreen(toScreen);
        }
        workspace.requestLayout();
        if ((getResources().getConfiguration().orientation == 1) == FxWorkspace.isPortrait()) {
            lockOrientation();
            sModel.loadUserItems(false, this, false, false);
        } else {
            if (localLOGD) {
                Logger.d(LOG_TAG, "removeWidgetsAndLoadUserItems when orientation changed");
            }
            this.mOrientationChangedRunnables.add(new Runnable() { // from class: com.htc.launcher.Launcher.16
                @Override // java.lang.Runnable
                public void run() {
                    Launcher.this.lockOrientation();
                    Launcher.sModel.loadUserItems(false, Launcher.this, false, false);
                }
            });
        }
        Log.d(DEBUG_DB_TAG, "removeWidgetsAndLoadUserItems() --> loadUserItems(false, launcher, true, false)");
        if (reloadWallpaper) {
            WidgetWorkspaceManager manager = WidgetWorkspaceManager.instance(this);
            manager.loadHomeWallpaper(launcher);
        }
    }

    private class ApplicationsIntentReceiver extends BroadcastReceiver {
        private ApplicationsIntentReceiver() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (Launcher.localLOGD) {
                Log.d("HomeLoaders", "application intent received: " + action);
            }
            if (Launcher.localLOGD) {
                Log.d("HomeLoaders", "  --> " + intent.getData());
            }
            Logger.d(LoggingEvents.EXTRA_CALLING_APP_NAME, "UPDATE - Launcher.onReceive(" + intent.getAction() + ")");
            if ("android.intent.action.PACKAGE_ADDED".equals(action) || "android.intent.action.PACKAGE_CHANGED".equals(action) || "android.intent.action.PACKAGE_REMOVED".equals(action)) {
                String packageName = intent.getData().getSchemeSpecificPart();
                boolean replacing = intent.getBooleanExtra("android.intent.extra.REPLACING", false);
                if (!"android.intent.action.PACKAGE_CHANGED".equals(action)) {
                    if ("android.intent.action.PACKAGE_REMOVED".equals(action)) {
                        if (!replacing) {
                            Launcher.this.removeShortcutsForPackage(packageName);
                            if (Launcher.localLOGD) {
                                Log.d("HomeLoaders", "  --> remove package");
                            }
                            Launcher.sModel.removePackage(Launcher.this, packageName);
                        }
                    } else if (!replacing) {
                        if (Launcher.localLOGD) {
                            Log.d("HomeLoaders", "  --> add package");
                        }
                        Launcher.sModel.addPackage(Launcher.this, packageName);
                    } else {
                        if (Launcher.localLOGD) {
                            Log.d("HomeLoaders", "  --> update package " + packageName);
                        }
                        if (Launcher.sModel.syncPackage(Launcher.this, packageName)) {
                            Launcher.this.removeShortcutsForPackage(packageName);
                        }
                        Launcher.this.updateShortcutsForPackage(packageName);
                    }
                    Launcher.this.removeDialog(1);
                } else {
                    if (Launcher.localLOGD) {
                        Log.d("HomeLoaders", "  --> sync package " + packageName);
                    }
                    if (Launcher.sModel.syncPackage(Launcher.this, packageName)) {
                        Launcher.this.removeShortcutsForPackage(packageName);
                    }
                }
            } else if ("android.intent.action.EXTERNAL_APPLICATIONS_AVAILABLE".equals(action)) {
                String[] packages = intent.getStringArrayExtra("android.intent.extra.changed_package_list");
                if (packages != null && packages.length != 0) {
                    for (String packageName2 : packages) {
                        if (!Launcher.sModel.syncPackage(Launcher.this, packageName2)) {
                            Launcher.this.getDesktopItemController().addPendingSyncPackages(packageName2);
                        }
                        Launcher.this.updateApplicationIconForPackage(packageName2);
                    }
                    if (Launcher.localLOGD) {
                        Log.d("HomeLoaders", " External app available  --> startLoaders: packages.length = " + packages.length);
                    }
                } else {
                    return;
                }
            } else if ("android.intent.action.EXTERNAL_APPLICATIONS_UNAVAILABLE".equals(action)) {
                String[] packages2 = intent.getStringArrayExtra("android.intent.extra.changed_package_list");
                if (packages2 != null && packages2.length != 0) {
                    for (String packageName3 : packages2) {
                        Launcher.sModel.syncPackage(Launcher.this, packageName3);
                        Launcher.this.updateApplicationIconForPackage(packageName3);
                    }
                    if (Launcher.localLOGD) {
                        Log.d("HomeLoaders", " External app unavailable  --> startLoaders: packages.length = " + packages2.length);
                    }
                } else {
                    return;
                }
            }
            Thread thread = new Thread("resetaddtohomeadapter") { // from class: com.htc.launcher.Launcher.ApplicationsIntentReceiver.1
                @Override // java.lang.Thread, java.lang.Runnable
                public void run() {
                    Process.setThreadPriority(19);
                    Log.d("HomeLoaders", "get install or remove message so do change adapter");
                    if (Launcher.this.mListAdapter != null) {
                        Launcher.this.mListAdapter.resetItems();
                        Launcher.this.runInNextEvLoop(new Runnable() { // from class: com.htc.launcher.Launcher.ApplicationsIntentReceiver.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                Launcher.this.mListAdapter.notifyDataSetChanged();
                            }
                        });
                    }
                }
            };
            thread.start();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onKeyguardOff() {
        if (this.isKeyguardOnWhenOnResume) {
            this.isKeyguardOnWhenOnResume = false;
            this.mWidgetsManager.onActivityPause(this, 50);
            onResumeWhenKeyguardOff(this);
        }
    }

    private class KeyguardIntentReceiver extends BroadcastReceiver {
        private KeyguardIntentReceiver() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if (Launcher.localLOGD) {
                Log.d(Launcher.LOG_TAG, "keyguard intent received: " + intent.getAction());
            }
            if ("android.intent.action.USER_PRESENT".equals(intent.getAction())) {
                if (Launcher.localLOGD) {
                    Log.d(Launcher.LOG_TAG, "UnlockAnimation, skip? " + Launcher.this.mSkipUnlockAnimation + ", rotating? " + Launcher.this.mChangingOrientation);
                }
                if (Launcher.this.showUnlockAnimation() && !Launcher.this.mSkipUnlockAnimation && !Launcher.this.mChangingOrientation) {
                    Launcher.this.mNeedLiveWallpaperSpin = true;
                    Launcher.this.mFxWorkspace.unlockAnimation();
                    Launcher.this.mFxWorkspace.setUnlockframeFlag(false);
                } else {
                    Launcher.this.mWorkspace.setCurrentScreen(Launcher.getScreen());
                    Launcher.this.onKeyguardOff();
                    if (!Launcher.this.mIsPause) {
                        Launcher.this.mFxWidgetManager.onUserPresent(Launcher.this.mWorkspace.getCurrentScreenIndex(), !Launcher.this.mDrawer.isOpened());
                        Launcher.this.mFxWidgetManager.resumeWidgets(Launcher.this.mWorkspace.getCurrentScreenIndex());
                    }
                    if (!Launcher.this.mChangingOrientation) {
                        Launcher.this.mFxWorkspace.changeScreensVisibility(true);
                    } else {
                        Launcher.this.mFxWorkspace.setCurrentScreen(Launcher.getScreen(), Launcher.this.mWorkspace.getWidth());
                        WallpaperManager.getInstance(Launcher.this).pauseWallpaper(Launcher.this.mWorkspace.getWindowToken(), false);
                    }
                    Launcher.this.mFxWorkspace.show();
                }
                Launcher.this.mSkipUnlockAnimation = false;
                return;
            }
            if ("android.intent.action.SCREEN_OFF".equals(intent.getAction()) && Launcher.this.mDragLayer != null) {
                Launcher.this.mDragLayer.abortDrag();
            }
        }
    }

    private class ThemeChangeReceiver extends BroadcastReceiver {
        private ThemeChangeReceiver() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if (Launcher.localLOGD) {
                Log.d("Home", "ThemeChange intent received: " + intent.getAction());
            }
            if (LauncherIntent.ACTION_THEME_CHANGE.equals(intent.getAction()) && !Launcher.this.mDestroying) {
                int workspaceId = intent.getIntExtra("workspace_id", -1);
                boolean backlighteffect = intent.getBooleanExtra(LauncherIntent.EXTRA_BACKLIGHT_EFFECT, true);
                boolean autoSave = intent.getBooleanExtra(Launcher.EXTRA_AUTO_SAVE, true);
                Launcher.this.mWorkspace.setCurrentScreen(Workspace.getDefaultScreenIndex());
                if (workspaceId > 0) {
                    Launcher.this.setCurrentWorkspace(workspaceId, backlighteffect, autoSave);
                }
            }
        }
    }

    private class SceneCleanReceiver extends BroadcastReceiver {
        private SceneCleanReceiver() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if (Launcher.localLOGD && Launcher.localLOGD) {
                Log.d(Launcher.LOG_TAG, "ThemeClean intent received: " + intent.getAction());
            }
            if ("com.htc.launcher.action.scene_clean".equals(intent.getAction()) && !Launcher.this.mDestroying) {
                WidgetWorkspaceManager wm = WidgetWorkspaceManager.instance(context);
                WidgetWorkspace[] workspaces = wm.listWorkspace();
                for (WidgetWorkspace workspace : workspaces) {
                    if (workspace.status != 2) {
                        if (Launcher.localLOGD) {
                            Log.d(Launcher.LOG_TAG, "cleanning workspace - " + workspace.displayName);
                        }
                        wm.removeWorkspace(workspace, true);
                    }
                }
                Launcher.this.setCurrentWorkspace(1, true, true);
            }
        }
    }

    private class SilderReceiver extends BroadcastReceiver {
        private SilderReceiver() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if (Launcher.localLOGD) {
                Log.d("Home", "SilderReceiver received: " + intent.getAction());
            }
            boolean silderState = intent.getBooleanExtra(Launcher.EXTRA_SILDER_STATE, true);
            if (!silderState) {
                Launcher.this.mIsLauncherAddtoHome = false;
                Launcher.this.onCloseDrawer();
            } else {
                Launcher.this.onOpenPersonalize();
            }
        }
    }

    private class SummaryReceiver extends BroadcastReceiver {
        private SummaryReceiver() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if (Launcher.this.mListAdapter != null) {
                Launcher.this.mListAdapter.onSummaryUpdate(intent);
            }
        }
    }

    boolean isSceneDirty() {
        SharedPreferences preferences = getSharedPreferences("launcher", 0);
        if (isPortrait() && preferences.getBoolean(KEY_SCENE_PREVIEW_PORT_INVALIDATE, true)) {
            return true;
        }
        return !isPortrait() && preferences.getBoolean(KEY_SCENE_PREVIEW_LAND_INVALIDATE, true);
    }

    public void startCreateScenePreviewThread(boolean wallpaperOnly) {
        if (localLOGD) {
            Log.d(LOG_TAG, "+startCreateScenePreviewThread(), wallpaperOnly? " + wallpaperOnly);
        }
        if (isSceneDirty()) {
            if (wallpaperOnly || (this.mWorkspace.isCurrentScreenHomeScreen() && !this.mIsPause && !this.mDragLayer.isDragging() && !this.mWorkspace.isDoingScroll() && !this.mLeapController.isLeapMode())) {
                if (this.mCreateScenePreviewThread == null) {
                    this.mCreateScenePreviewThread = new HandlerThread("CreateScenePreviewThread", 10);
                    this.mCreateScenePreviewThread.start();
                    this.mCreateScenePreviewHandler = new Handler(this.mCreateScenePreviewThread.getLooper()) { // from class: com.htc.launcher.Launcher.17
                        @Override // android.os.Handler
                        public void handleMessage(Message msg) {
                            if (msg.what == Launcher.CREATE_SCENE_PREVIEW) {
                                Launcher.this.createScenePreview((Bitmap) msg.obj);
                            }
                        }
                    };
                }
                Bitmap snapshot = null;
                if (!wallpaperOnly) {
                    try {
                        snapshot = this.mFxWorkspace.captureScreenShot();
                    } catch (Exception e) {
                        Log.e(LOG_TAG, "captureScreenShot exception");
                    }
                } else if (isPortrait()) {
                    snapshot = decodeFile(SCREEN_CACHE_SRC);
                } else {
                    snapshot = decodeFile(SCREEN_CACHE_SRC_LAND);
                }
                Bitmap screenCache = null;
                if (snapshot != null) {
                    try {
                        screenCache = Bitmap.createBitmap(snapshot);
                    } catch (Exception e2) {
                        Log.e(LOG_TAG, "createBitmap exception");
                    }
                }
                if (wallpaperOnly || screenCache != null) {
                    if (this.mCreateScenePreviewHandler != null) {
                        try {
                            this.mCreateScenePreviewHandler.removeMessages(CREATE_SCENE_PREVIEW);
                            Message msg = this.mCreateScenePreviewHandler.obtainMessage(CREATE_SCENE_PREVIEW, screenCache);
                            this.mCreateScenePreviewHandler.sendMessage(msg);
                            return;
                        } catch (Exception e3) {
                            e3.printStackTrace();
                            return;
                        }
                    }
                    return;
                }
                Log.e(LOG_TAG, "snapshot failed");
            }
        }
    }

    public static Bitmap decodeFile(String pathName) {
        Bitmap image = null;
        try {
            image = BitmapFactory.decodeFile(pathName);
        } catch (NullPointerException e) {
            System.gc();
            return null;
        } catch (Exception e2) {
            System.gc();
            return null;
        } catch (OutOfMemoryError e3) {
            System.gc();
        }
        return image;
    }

    private class FavoritesChangeObserver extends ContentObserver {
        public FavoritesChangeObserver() {
            super(new Handler());
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean selfChange) {
            Launcher.this.onFavoritesChanged();
        }
    }

    private class AppWidgetResetObserver extends ContentObserver {
        public AppWidgetResetObserver() {
            super(new Handler());
        }

        @Override // android.database.ContentObserver
        public void onChange(boolean selfChange) {
            Launcher.this.onAppWidgetReset();
        }
    }

    private class HtcWidgetUpdateReceiver extends BroadcastReceiver {
        private HtcWidgetUpdateReceiver() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(final Context context, Intent intent) {
            final String packageName = intent.getStringExtra("package");
            if (Launcher.localLOGD) {
                Log.d(Launcher.LOG_TAG, "widget updated, packageName - " + packageName);
            }
            Thread thread = new Thread("widget_updated_thread") { // from class: com.htc.launcher.Launcher.HtcWidgetUpdateReceiver.1
                @Override // java.lang.Thread, java.lang.Runnable
                public void run() {
                    Process.setThreadPriority(19);
                    WidgetPackageManager.instance(context).scanWidgetItems(context, packageName);
                    Log.d("HomeLoaders", "get HTC widget updated message so do change adapter");
                    if (Launcher.this.mListAdapter != null) {
                        Launcher.this.mListAdapter.resetItems();
                        Launcher.this.runInNextEvLoop(new Runnable() { // from class: com.htc.launcher.Launcher.HtcWidgetUpdateReceiver.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                Launcher.this.mListAdapter.notifyDataSetChanged();
                            }
                        });
                    }
                }
            };
            thread.start();
        }
    }

    public static class WallpaperIntentReceiver extends BroadcastReceiver {
        public static boolean isOOBE = false;
        public static WeakReference<Launcher> mLauncher;

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if (Launcher.localLOGD) {
                Log.d(Launcher.LOG_TAG, "WallpaperIntentReceiver.onReceive()");
            }
            if (mLauncher == null) {
                isOOBE = true;
                if (Launcher.localLOGD) {
                    Log.d(Launcher.LOG_TAG, "WallpaperIntentReceiver.isOOBE - " + isOOBE);
                    return;
                }
                return;
            }
            if (Launcher.localLOGD) {
                Log.d(Launcher.LOG_TAG, "WallpaperIntentReceiver.isOOBE - " + isOOBE);
            }
            if (SettingUtil.isLiveWallaperSupported() && mLauncher != null) {
                WallpaperInfo info = WallpaperManager.getInstance(null).updateWallpaperInfo();
                if (info != null) {
                    CharSequence unused = Launcher.mLiveWallpaperName = info.loadLabel(context.getPackageManager());
                }
                Launcher launcher = mLauncher.get();
                if (launcher != null) {
                    if (Launcher.localLOGD) {
                        Log.d(Launcher.LOG_TAG, "launcher.mSettingWallpaper - " + launcher.mSettingWallpaper);
                    }
                    if (launcher.mSettingWallpaper <= 0) {
                        if (launcher.mIsLoading) {
                            if (Launcher.localLOGD) {
                                Log.d(Launcher.LOG_TAG, "launcher.mIsLoading - " + launcher.mSettingWallpaper);
                                return;
                            }
                            return;
                        }
                        String componentName = intent.getStringExtra("android.intent.extra.changed_component_name");
                        if (componentName != null) {
                            WidgetWorkspaceManager wwm = WidgetWorkspaceManager.instance();
                            if (!componentName.equals(wwm.getCurrentWallpaperComponent())) {
                                wwm.setWallpaperComponent(wwm.getCurrentWorkspaceId(), componentName);
                                launcher.invalidateScenePreviews();
                                launcher.startCreateScenePreviewThread(true);
                                return;
                            }
                            return;
                        }
                    } else {
                        launcher.mSettingWallpaper--;
                        return;
                    }
                }
            }
            if (Launcher.localLOGD) {
                Log.d(Launcher.LOG_TAG, "Load the wallpaper from the ApplicationContext");
            }
            android.app.WallpaperManager wm = android.app.WallpaperManager.getInstance(context);
            Drawable drawable = wm.getDrawable();
            if (drawable instanceof BitmapDrawable) {
                if (!SettingUtil.isLiveWallaperSupported()) {
                    Launcher.sWallpaper = ((BitmapDrawable) drawable).getBitmap();
                }
                if (mLauncher != null) {
                    WidgetWorkspaceManager manager = WidgetWorkspaceManager.instance(context);
                    Bitmap copy = ((BitmapDrawable) drawable).getBitmap().copy(Bitmap.Config.ARGB_8888, false);
                    Launcher launcher2 = mLauncher.get();
                    launcher2.getClass();
                    manager.saveHomeWallpaper(copy, launcher2.new SaveWallpaperCompleteListener());
                    return;
                }
                return;
            }
            throw new IllegalStateException("The wallpaper must be a BitmapDrawable.");
        }
    }

    public class SaveWallpaperCompleteListener {
        public SaveWallpaperCompleteListener() {
        }

        public void onSaveWallpaperCompleted() {
            Launcher.this.startCreateScenePreviewThread(true);
        }
    }

    private static class CustomizationChangeReceiver extends BroadcastReceiver {
        private static String TAG = "CustomizationChangeReceiver";

        private CustomizationChangeReceiver() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if (Launcher.localLOGD) {
                Log.d(TAG, "Receiving CustomizationChange.");
            }
            if (Launcher.localLOGD) {
                Log.d(TAG, "KEY_CUSTOMIZED_REASON:" + intent.getStringExtra("KEY_CUSTOMIZED_REASON"));
            }
            String reason = intent.getStringExtra(Launcher.KEY_CUSTOMIZED_REASON);
            if (reason == null || !Launcher.CASE_FOTA_UPGRADE.equals(reason)) {
                SharedPreferences preferences = context.getSharedPreferences(WidgetPackageManager.REFERENCES, 0);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putBoolean(WidgetPackageManager.PREF_KEY_INIT, false);
                editor.apply();
                if (Launcher.localLOGD) {
                    Log.d(TAG, "Reset workspaces.");
                }
                new File(WidgetWorkspace.getHomeWallpaper(context, -1)).delete();
                ContentResolver contentResolver = context.getContentResolver();
                contentResolver.update(LauncherSettings.getSpecialAction("_init_workspaces"), null, null, null);
                if (Launcher.localLOGD) {
                    Log.d(TAG, "(Rosie self-restart)Process.myPid() - " + Process.myPid());
                }
                Process.killProcess(Process.myPid());
            }
        }
    }

    private class ScreenReceiver extends BroadcastReceiver {
        private ScreenReceiver() {
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            if (Launcher.localLOGD && Launcher.localLOGD) {
                Log.d("ScreenReceiver", "receive " + intent.getAction());
            }
            String action = intent.getAction();
            if (action.equals("android.intent.action.SCREEN_OFF")) {
            }
        }
    }

    private class DrawerManager implements SlidingDrawer.OnDrawerOpenListener, SlidingDrawer.OnDrawerCloseListener, SlidingDrawer.OnDrawerScrollListener {
        private boolean mOpen;

        private DrawerManager() {
        }

        @Override // com.htc.launcher.widget.SlidingDrawer.OnDrawerOpenListener
        public void onDrawerOpened() {
            if (Launcher.this.mIsAllProgramSliding) {
                Launcher.this.mIsAllProgramSliding = false;
            }
            Launcher.this.mIsRessumeNeedCloseSliderAndStartActivity = false;
            if (!this.mOpen) {
                this.mOpen = true;
                Launcher.this.mDrawer.postInvalidate();
            }
            android.app.WallpaperManager.getInstance(Launcher.this).sendWallpaperCommand(Launcher.this.mWorkspace.getWindowToken(), "com.htc.android.wallpaper.pause", 0, 0, 0, null);
            Launcher.this.mAllAppsView.destroyDrawingCache();
            Launcher.this.mWorkspace.setIsRootNamespace(true);
            for (Object obj : Launcher.this.mAllAppsView.getAllContents()) {
                if (obj instanceof AllAppsGridView) {
                    ((AllAppsGridView) obj).setFocusable(true);
                }
            }
            if (Launcher.this.getResources().getConfiguration().hardKeyboardHidden != 1 || Launcher.this.mIsLauncherAddtoHome) {
            }
            Launcher.this.stop3DAnimation();
            UpdateShortcutReceiver.registerObserver(Launcher.this.mApplicationsAdapter);
            if (!Launcher.this.ask2NotifyHint) {
                Launcher.this.ask2NotifyHint = true;
                Intent intent = new Intent("com.htc.launcher.action.ACTION_ITEM_ADDED");
                intent.putExtra("favorite_item_id", -1);
                intent.putExtra("favorite_intent", "component=com.htc.android.mail/.MailListTab");
                Launcher.this.sendBroadcast(intent);
            }
            Launcher.this.mFxWidgetManager.pauseAllWidgets(false);
            Launcher.this.freezeTilt(true);
            if (Launcher.this.mIsLauncherAddtoHome) {
                Launcher.this.startCreateScenePreviewThread(false);
                Launcher.this.mFxWorkspace.freeze(true);
            }
        }

        @Override // com.htc.launcher.widget.SlidingDrawer.OnDrawerCloseListener
        public void onDrawerClosed() {
            Launcher.this.mBottomBarArea.setOnTouchListener(Launcher.this.mFxWorkspace);
            if (this.mOpen) {
                this.mOpen = false;
            }
            android.app.WallpaperManager.getInstance(Launcher.this).sendWallpaperCommand(Launcher.this.mWorkspace.getWindowToken(), "com.htc.android.wallpaper.resume", 0, 0, 0, null);
            Launcher.this.mAllAppsView.removeDragView();
            Launcher.this.enableAppsSearch(false, null);
            Launcher.this.mDrawer.setVisibility(4);
            Launcher.this.mDrawer.setFocusable(false);
            Launcher.this.mWorkspace.setIsRootNamespace(false);
            Launcher.this.mWorkspace.setDrawingCacheEnabled(false);
            Launcher.this.mWorkspace.setAlwaysDrawnWithCacheEnabled(false);
            Log.w(Launcher.LOG_TAG, "mAddHtcWidgetByOtherActivity = " + Launcher.this.mAddHtcWidgetByOtherActivity + ", mIsOpenSlideWhenLeaveLaunch = " + Launcher.this.mIsOpenSlideWhenLeaveLaunch);
            if (Launcher.this.mIsRessumeNeedCloseSliderAndStartActivity || (!Launcher.this.mAddHtcWidgetByOtherActivity && !Launcher.this.mIsOpenSlideWhenLeaveLaunch)) {
                Launcher.this.mWidgetsManager.onActivityResume(Launcher.this, 40);
            }
            Launcher.this.mIsRessumeNeedCloseSliderAndStartActivity = false;
            Launcher.this.mIsOpenSlideWhenLeaveLaunch = false;
            Launcher.this.mIsOpenPersonalizeBySetting = false;
            if (Launcher.this.isNeedLaunchAddToHome) {
                Launcher.this.isNeedLaunchAddToHome = false;
                Launcher.this.onClickAddtoHome(null);
            }
            Launcher.this.mIsLauncherAddtoHome = false;
            Launcher.this.mIsLauncherAllProgram = false;
            Launcher.this.closeOptionsMenu();
            UpdateShortcutReceiver.unregisterObserver();
            Launcher.this.mFxWidgetManager.resumeWidgets(Launcher.getScreen());
            Launcher.this.freezeTilt(false);
            Launcher.this.mFxWorkspace.changeScreensVisibility(true);
            Launcher.this.mFxWorkspace.freeze(false);
            if (SettingUtil.isDoubleShot()) {
                Launcher.this.mControl.setVisibility(8);
            }
        }

        @Override // com.htc.launcher.widget.SlidingDrawer.OnDrawerScrollListener
        public void onScrollStarted() {
        }

        @Override // com.htc.launcher.widget.SlidingDrawer.OnDrawerScrollListener
        public void onScrollEnded() {
        }
    }

    private static class DesktopBinder extends Handler implements MessageQueue.IdleHandler {
        static final int HTCWIDGETS_COUNT = 1;
        static final int ITEMS_COUNT = 200;
        static final int MESSAGE_BIND_APPWIDGETS = 2;
        static final int MESSAGE_BIND_HTCWIDGETS = 256;
        static final int MESSAGE_BIND_ITEMS = 1;
        private final LinkedList<LauncherAppWidgetInfo> mAppWidgets;
        private final WeakReference<Launcher> mLauncher;
        private final ArrayList<ItemInfo> mShortcuts;
        public volatile boolean mTerminate = false;
        private final ArrayList<WidgetProxy> mHtcWidgets = new ArrayList<>();

        DesktopBinder(Launcher launcher, ArrayList<ItemInfo> shortcuts, ArrayList<LauncherAppWidgetInfo> appWidgets) {
            this.mLauncher = new WeakReference<>(launcher);
            this.mShortcuts = shortcuts;
            int currentScreen = launcher.mWorkspace.getCurrentScreenIndex();
            int size = appWidgets.size();
            this.mAppWidgets = new LinkedList<>();
            for (int i = 0; i < size; i++) {
                LauncherAppWidgetInfo appWidgetInfo = appWidgets.get(i);
                if (appWidgetInfo.screen == currentScreen) {
                    this.mAppWidgets.addFirst(appWidgetInfo);
                } else {
                    this.mAppWidgets.addLast(appWidgetInfo);
                }
            }
        }

        public void startBindingItems() {
            obtainMessage(1, 0, this.mShortcuts.size()).sendToTarget();
        }

        public void startBindingAppWidgetsWhenIdle() {
            MessageQueue messageQueue = Looper.myQueue();
            messageQueue.addIdleHandler(this);
        }

        @Override // android.os.MessageQueue.IdleHandler
        public boolean queueIdle() {
            startBindingAppWidgets();
            return false;
        }

        public void startBindingAppWidgets() {
            obtainMessage(2).sendToTarget();
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            Launcher launcher = this.mLauncher.get();
            if (launcher != null && !this.mTerminate) {
                switch (msg.what) {
                    case 1:
                        launcher.bindItems(this, this.mShortcuts, msg.arg1, msg.arg2);
                        break;
                    case 2:
                        launcher.bindAppWidgets(this, this.mAppWidgets);
                        break;
                    case MESSAGE_BIND_HTCWIDGETS /* 256 */:
                        bindHtcWidgets(this, this.mHtcWidgets, msg.arg1, msg.arg2);
                        break;
                }
            }
        }

        public void startBindingHtcWidgets() {
            obtainMessage(MESSAGE_BIND_HTCWIDGETS, 0, this.mHtcWidgets.size()).sendToTarget();
        }

        public void addHtcWidget(WidgetProxy proxy) {
            if (proxy.screen == Launcher.sScreen) {
                this.mHtcWidgets.add(0, proxy);
            } else {
                this.mHtcWidgets.add(proxy);
            }
        }

        private void bindHtcWidgets(DesktopBinder binder, ArrayList<WidgetProxy> htcWidgets, int start, int count) {
            Launcher launcher = this.mLauncher.get();
            if (launcher != null) {
                Workspace workspace = launcher.mWorkspace;
                int screen = workspace.getCurrentScreenIndex();
                boolean desktopLocked = launcher.mDesktopLocked;
                int end = Math.min(start + 1, count);
                int i = start;
                while (i < end) {
                    WidgetProxy item = htcWidgets.get(i);
                    try {
                        View view2 = item.inflate(launcher, (ViewGroup) workspace.getChildAt(screen), false);
                        view2.setTag(item);
                        launcher.getDesktopItemController().addWidgetAsync(view2, item, !desktopLocked);
                    } catch (Exception ex) {
                        Log.e(Launcher.LOG_TAG, "error found in - " + item.getWidgetView());
                        Log.e(Launcher.LOG_TAG, ex.getMessage(), ex);
                    }
                    i++;
                }
                if (end >= count) {
                    launcher.finishBindDesktopHtcWidgets();
                } else {
                    binder.obtainMessage(MESSAGE_BIND_HTCWIDGETS, i, count).sendToTarget();
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void finishBindDesktopHtcWidgets() {
        this.mDesktopItemController.flushPendingAddInScreens();
        runInNextEvLoop(new Runnable() { // from class: com.htc.launcher.Launcher.18
            @Override // java.lang.Runnable
            public void run() {
                Launcher.this.mDesktopItemController.flushPendingAddInFxScreens();
            }
        });
    }

    private boolean hardwareKeySmartSearchintDialer(int keyCode) {
        return false;
    }

    private boolean hardwareKeySmartGoogleSearch(int keyCode, KeyEvent event) {
        return false;
    }

    private Intent getHardwareKeySmartSearchIntent(int keyCode) {
        Intent intent = new Intent();
        intent.setClassName("com.android.htccontacts", "com.android.htccontacts.HtcDialer");
        intent.putExtra("HardwareKeySmartSearch", true);
        intent.putExtra("HardwareKeySmartSearchKeyCode", keyCode);
        return intent;
    }

    boolean isLauncherDestroyed() {
        return this.mDestroyed;
    }

    public void setlocalLOGD(boolean enable) {
        localLOGD = enable;
    }

    public void onClickAllProgram() {
        if (localLOGD) {
            Log.d(LOG_TAG, "onClickAllProgram()");
        }
        if (this.mDrawer.isMoving()) {
            if (localLOGD) {
                Log.w("Handle buttons", " left_btn.mDrawer.isMoving() =  " + this.mDrawer.isMoving());
                return;
            }
            return;
        }
        removeTutorialNotice();
        changeDrawerContentById(mProgramListId);
        this.mIsAllProgramSliding = true;
        if (localLOGD) {
            Log.d("Handle buttons", "all program sliding up");
        }
        this.mAllAppsBar.setVisibility(8);
        this.mHandleView.setLayoutParams(new ViewGroup.LayoutParams(-1, ((ViewGroup) this.mHandleView).getChildAt(0).getBackground().getIntrinsicHeight()));
        this.mIsLauncherAllProgram = !this.mIsLauncherAllProgram;
        if (this.mDrawer.isOpened()) {
            this.mAllAppsView.clearFocus();
            this.mDrawer.animateClose();
            this.mBottomBarArea.setOnTouchListener(this.mFxWorkspace);
            this.mIsLauncherAddtoHome = false;
            return;
        }
        this.mAllAppsView.initTabs();
        onOpenDrawer();
        if (SettingUtil.isDoubleShot()) {
            this.mControl.setVisibility(0);
        }
        ReusableULogData uLogData = ReusableULogData.obtain();
        uLogData.setAppId("com.htc.launcher").setCategory("user_action");
        uLogData.addData("allapp_launch", "true");
        if (localLOGD) {
            Log.d(LOG_TAG, "HTC user profiling     allapp_launch     true");
        }
        ULog.log(uLogData);
        uLogData.recycle();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void onClickAddtoHome(CellInfo cellInfo) {
        if (localLOGD) {
            Log.d(LOG_TAG, "onClickAddtoHome()");
        }
        if (this.mIsListAdapterReady) {
            if (cellInfo == null) {
                cellInfo = this.mWorkspace.findAllVacantCells(null);
                this.mMenuAddInfo = cellInfo;
            }
            this.mWorkspace.setAllowLongPress(false);
            changeDrawerContentById(R.id.content_add_to_home);
            if (mMiddleClickButton == -1) {
                prepareAddToHomeContent();
            }
            if (cellInfo != null) {
                this.mWaitingForResult = true;
            }
            this.mAddItemCellInfo = cellInfo;
            if (this.mListAdapter == null) {
                this.mListAdapter = new AddListAdapter(this, this, false);
                this.mProgramListLayout.setAdapter(this.mListAdapter);
                this.mProgramListLayout.setAddWidgetListener(new AddToHomeItemClickListener());
                this.mProgramListLayout.setPersonalizeOnItemClickListener(new PersonalizeOnItemClickListener());
            }
            this.mIsLauncherAddtoHome = !this.mIsLauncherAddtoHome;
            if (this.mDrawer.isOpened()) {
                this.mAllAppsView.clearFocus();
                this.mDrawer.animateClose();
                this.mBottomBarArea.setOnTouchListener(this.mFxWorkspace);
                this.mIsLauncherAllProgram = false;
                return;
            }
            onOpenDrawer();
        }
    }

    private void onClickTmoPersonalize(CellInfo cellInfo) {
        Intent iIntent = new Intent();
        iIntent.setComponent(new ComponentName("com.android.settings", "com.android.settings.framework.activity.personalize.HtcPersonalizeSettingsProxy"));
        startActivity(iIntent);
    }

    private void onOpenDrawer() {
        if (this.mIsLauncherAddtoHome && isSceneDirty()) {
            this.mTiltListener.reset();
            this.mSlideController.stopSlide();
            this.mFxWorkspace.resetSink();
            this.mWorkspace.setCurrentScreen(getScreen());
        } else {
            runDelayed(new Runnable() { // from class: com.htc.launcher.Launcher.19
                @Override // java.lang.Runnable
                public void run() {
                    Launcher.this.mFxWorkspace.freeze(true);
                }
            }, 50L);
        }
        freezeTilt(true);
        this.mWidgetsManager.onActivityPause(this, 40);
        closeOptionsMenu();
        this.mDrawer.setVisibility(0);
        this.mAllAppsView.requestFocus();
        this.mDrawer.animateOpen();
        this.mBottomBarArea.setOnTouchListener(null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void lockOrientation() {
    }

    private void unlockOrientation() {
    }

    public void finishLoading() {
        this.mWorkspace.requestLayout();
        this.mFinishLoading = 0;
        this.mPrepareScreensCacheIndex = 0;
        this.mPrepareScreensCache.run();
        invalidateScenePreviews();
        unlockOrientation();
    }

    private class LauncherHandler extends Handler {
        private LauncherHandler() {
        }

        @Override // android.os.Handler
        public void handleMessage(Message m) {
            switch (m.what) {
                case LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK /* 1000 */:
                    if (Launcher.this.mListAdapter != null) {
                        Launcher.this.mListAdapter.reset(false);
                    }
                    Launcher.this.mIsOpenSlideWhenLeaveLaunch = true;
                    if (Launcher.this.mDrawer.isOpened()) {
                        Launcher.this.closeAllApplications();
                        break;
                    }
                    break;
                case 1001:
                    Launcher.this.mListAdapter.notifyDataSetChanged();
                    break;
                case 1002:
                    Launcher.this.mIsAllowMoveToDefaultScreen = true;
                    Launcher.this.mWidgetTilter.mSurpressScroll = false;
                    break;
                case Launcher.MSG_UNLOCK_ENTER_THUMBNAIL_MODE /* 1003 */:
                    Launcher.this.mIsLockEnterThumbnailMode = false;
                    break;
                case Launcher.MSG_KEY_LONG_PRESS_TIMEOUT /* 1004 */:
                    Intent uakIntent = new Intent("ACTION_UAK_TRIGGLE");
                    uakIntent.putExtra("EXTRA_UAK_KEY_TYPE", (m.arg1 - 29) + 97);
                    uakIntent.putExtra("EXTRA_UAK_KEY_EVENT_LONGPRESS", true);
                    Launcher.this.sendBroadcast(uakIntent);
                    Launcher.this.isUakKeyProcessed = true;
                    Launcher.this.lastUakKeyCode = m.arg1;
                    break;
                case Launcher.MSG_FINISH_BIND_FXWIDGET /* 1006 */:
                    Launcher.access$8112(Launcher.this, 1);
                    if (Launcher.this.mFinishLoading >= 2) {
                        Launcher.this.finishLoading();
                        break;
                    }
                    break;
                case Launcher.NOTIFY_DATA_SET_CHANGED /* 1007 */:
                    Launcher.this.mListAdapter.notifyDataSetChanged();
                    break;
                case Launcher.DISMISS_LOADING /* 1008 */:
                    Launcher.this.mHandler.sendEmptyMessageDelayed(Launcher.MSG_CREATE_SCENE_PREVIEW, 2000L);
                    Launcher.this.removeDialog(100);
                    Launcher.this.enableTilt(true);
                    break;
                case Launcher.MSG_CREATE_SCENE_PREVIEW /* 1009 */:
                    Launcher.this.startCreateScenePreviewThread(false);
                    break;
            }
        }
    }

    private void prepareAddToHomeContent() {
        this.mListAdapter.reset(false);
        this.mProgramListLayout.doCheckTitle();
    }

    private void prepareCurrentScreenCache() {
        runInNextEvLoop(new Runnable() { // from class: com.htc.launcher.Launcher.20
            @Override // java.lang.Runnable
            public void run() {
                Launcher.this.mWorkspace.setWillNotCacheDrawing(false);
                Launcher.this.mWorkspace.setDrawingCacheEnabled(true);
                Launcher.this.mWorkspace.setAlwaysDrawnWithCacheEnabled(true);
            }
        });
    }

    @Override // android.view.View.OnTouchListener
    public boolean onTouch(View view, MotionEvent arg1) {
        Log.d(LOG_TAG, "isButtonCanPress: " + this.isButtonCanPress + ", mIsListAdapterReady:" + this.mIsListAdapterReady);
        if (this.isButtonCanPress && this.mIsListAdapterReady) {
            if ((arg1.getAction() == 0 || this.mIsTouchDownNeedCacheBtn) && !this.mDrawer.isMoving()) {
                switch (view.getId()) {
                    case R.id.left_btn /* 2131099661 */:
                        if (arg1.getAction() == 0) {
                            prepareCurrentScreenCache();
                            changeDrawerContentById(mProgramListId);
                            this.mIsTouchDownNeedCacheBtn = true;
                            stop3DAnimation();
                            break;
                        } else if (arg1.getAction() == 1) {
                            this.mIsTouchDownNeedCacheBtn = false;
                            Rect hidArea = new Rect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
                            if (!hidArea.contains((int) arg1.getX(), (int) arg1.getY())) {
                            }
                        }
                        break;
                    case R.id.right_btn /* 2131099662 */:
                        if (arg1.getAction() == 0) {
                            if (this.mListAdapter != null) {
                                this.mListAdapter.setHeightPriority();
                            }
                            if (!this.mDrawer.isOpened()) {
                                prepareCurrentScreenCache();
                                changeDrawerContentById(R.id.content_add_to_home);
                                prepareAddToHomeContent();
                            }
                            this.mIsTouchDownNeedCacheBtn = true;
                            stop3DAnimation();
                            break;
                        } else if (arg1.getAction() == 1) {
                            this.mIsTouchDownNeedCacheBtn = false;
                            Rect hidArea2 = new Rect(0, 0, view.getRight() - view.getLeft(), view.getBottom() - view.getTop());
                            if (!hidArea2.contains((int) arg1.getX(), (int) arg1.getY())) {
                            }
                        }
                        break;
                }
                return false;
            }
            return true;
        }
        return true;
    }

    void onOrientationChanged(boolean portrait) {
        allProgramUpdateOrientation(portrait);
        if (this.isSupportLandscape) {
            sOrientationMonitor.onOrientationChanged(true);
        }
        if (portrait) {
            this.mBottomBarArea.setLayoutParams(new FrameLayout.LayoutParams(-1, (int) getResources().getDimension(R.dimen.launcher_control_height), 81));
        } else {
            this.mBottomBarArea.setLayoutParams(new FrameLayout.LayoutParams((int) getResources().getDimension(R.dimen.launcher_control_height), -1, 21));
        }
    }

    private void allProgramUpdateOrientation(boolean portrait) {
        AllAppsGridView gridView = (AllAppsGridView) this.mAllAppsView.findViewById(R.id.content_grid);
        gridView.updateOrientation(portrait);
        AllAppsListView listView = (AllAppsListView) this.mAllAppsView.findViewById(R.id.content_list);
        listView.updateOrientation(portrait);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void onConfigurationChanged(Configuration newConfig) {
        if (localLOGD) {
            Profiler.start();
        }
        if (localLOGD) {
            Log.d("Rotate.Performance", "+onConfigurationChanged");
        }
        this.mStartOrientation = System.currentTimeMillis();
        this.mFreezeable = false;
        if (this.mSlideController != null) {
            this.mSlideController.stopSlide();
        }
        this.mOnConfigurationChanged = true;
        mUiMode = newConfig.uiMode & 15;
        sOrientationMonitor.onConfigurationChanged();
        super.onConfigurationChanged(newConfig);
        if ((newConfig.uiMode & 3) == 3) {
            this.mSkipUiModeChange = true;
        }
        if (this.mCurrentMcc != newConfig.mcc || this.mCurrentMnc != newConfig.mnc) {
            onSimChanged(newConfig.mcc, newConfig.mnc);
        }
        if (!this.mCurrentLocale.equals(newConfig.locale.toString())) {
            this.mCurrentLocale = newConfig.locale.toString();
            saveLocaleAndSimConfigs();
            Utilities.sCollator = Collator.getInstance(newConfig.locale);
            try {
                dismissDialog(102);
                removeDialog(102);
            } catch (IllegalArgumentException e) {
            }
            showDialog(100);
            this.mOnConfigChangedReloading = true;
            this.mOptionsMenuChanged.clear();
            this.mPageSelect = false;
            this.mWorkspace.removeAllViewsRecursively();
            this.mDragLayer.removeAllViews();
            System.gc();
            setContentView(R.layout.launcher);
            setupViews();
            this.mWidgetsManager.onActivityDestroy();
            boolean loadApplications = sModel.loadApplications(true, this, true);
            sModel.loadUserItems(false, this, true, loadApplications);
            Log.d(DEBUG_DB_TAG, "onConfigurationChanged() --> loadUserItems(false, launcher, true, " + loadApplications + ")");
        }
        if (this.isSupportLandscape && this.mCurrentOrientation != newConfig.orientation) {
            this.mChangingOrientation = true;
            stop3DAnimation();
            this.mDragLayer.abortDrag();
            this.mWorkspace.leaveEditMode();
            if (this.mLeapController.isLeapMode()) {
                this.mLeapController.endLeapMode();
                this.mLeapController.cancelGesture();
            }
            this.mCurrentOrientation = newConfig.orientation;
            sOrientationMonitor.addOnConfigurationChanged();
            sDefaultAppWidgetHost.startListening();
            if (this.mIsShowTutorialNotice) {
                hideTutorialNotice();
            }
            this.orientationCount++;
            if (localLOGD) {
                if (this.mOnOrientationChange) {
                    Log.d(LOG_TAG, "too soon to enter orientation change again");
                }
                Log.d(LOG_TAG, "orientationCount = " + this.orientationCount);
            }
            if (!this.mOnOrientationChange) {
                this.mWorkspace.restoreRemovedChildren(-1, false);
                this.mDragLayer.restoreRemovedChildren();
            }
            this.mNewConfig = newConfig;
            if (!this.mOnOrientationChange) {
                this.mDragLayer.tempRemoveChildren();
            }
            if (this.mIsLauncherAddtoHome || this.mIsLauncherAllProgram) {
                allProgramUpdateOrientation(this.mCurrentOrientation == 1);
                this.mOrientationIdleHandler.reset(this.mWorkspace.getCurrentScreenIndex(), 1);
                this.mFxWorkspace.freeze(false);
            } else {
                this.mOrientationIdleHandler.reset(this.mWorkspace.getCurrentScreenIndex(), 0);
                this.mDrawer.setVisibility(8);
                this.mOrientationIdleHandler.doStageOne();
            }
            this.mWorkspace.setVisibility(4);
            this.mOnOrientationChange = true;
            Looper.myQueue().addIdleHandler(this.mOrientationIdleHandler);
            this.mWorkspace.mFirstLayout = true;
            FxSkinUtility.loadSkinResource(this, newConfig.orientation);
            if (SettingUtil.isDoubleShot()) {
                ButtonBarViews_UpdateOrientation();
                getFxWorkspace().getCurrentWorkspace().showMiddleBackgroundImageControls(sModel.getButtonBarOccupied());
            }
        } else {
            this.mFreezeable = true;
        }
        this.mOnConfigurationChanged = false;
        if (localLOGD) {
            Log.d(LOG_TAG, ">> onConfigurationChanged()");
            Profiler.stop(false, "onConfigurationChanged: ");
        }
    }

    private void changeOrientation() {
        if (localLOGD) {
            Log.d(LOG_TAG, "changeOrientation()");
        }
        this.mIsConfigurationChanged = false;
        this.mOnOrientationChange = false;
        stop3DAnimation();
        this.mDragLayer.abortDrag();
        this.mWorkspace.leaveEditMode();
        if (this.mLeapController != null && this.mLeapController.isLeapMode()) {
            this.mLeapController.endLeapMode();
        }
        if (this.mSlideController != null) {
            this.mSlideController.stopSlide();
        }
        if (this.mNewConfig != null) {
            this.mCurrentOrientation = this.mNewConfig.orientation;
        } else {
            this.mCurrentOrientation = getResources().getConfiguration().orientation;
        }
        sOrientationMonitor.addOnConfigurationChanged();
        sDefaultAppWidgetHost.startListening();
        if (this.mIsShowTutorialNotice) {
            hideTutorialNotice();
        }
        this.orientationCount++;
        if (localLOGD) {
            if (this.mOnOrientationChange) {
                Log.d(LOG_TAG, "too soon to enter orientation change again");
            }
            Log.d(LOG_TAG, "orientationCount = " + this.orientationCount);
        }
        if (!this.mOnOrientationChange) {
            this.mWorkspace.restoreRemovedChildren(-1, false);
            this.mDragLayer.restoreRemovedChildren();
        }
        if (this.mIsLauncherAddtoHome || this.mIsLauncherAllProgram) {
            this.mOrientationIdleHandler.reset(this.mWorkspace.getCurrentScreenIndex(), 1);
        } else {
            this.mOrientationIdleHandler.reset(this.mWorkspace.getCurrentScreenIndex(), 0);
        }
        if (!this.mOnOrientationChange) {
            this.mDragLayer.tempRemoveChildren();
        }
        this.mWorkspace.setVisibility(4);
        this.mOnOrientationChange = true;
        Looper.myQueue().addIdleHandler(this.mOrientationIdleHandler);
        this.mWorkspace.mFirstLayout = true;
    }

    class OrientationIdleHandler implements MessageQueue.IdleHandler {
        static final int MODE_SCROLLBAR_FIRST = 1;
        static final int MODE_WORKSPACE_FIRST = 0;
        int mStage = 3;
        int mCurrentScreen = 0;
        int mMode = 0;

        OrientationIdleHandler() {
        }

        public void reset(int currentPage, int mode) {
            this.mStage = 0;
            this.mCurrentScreen = currentPage;
            this.mMode = mode;
        }

        public void flush() {
            while (queueIdle()) {
            }
        }

        @Override // android.os.MessageQueue.IdleHandler
        public boolean queueIdle() {
            if (Launcher.localLOGD) {
                Log.d("Rotate.Performance", "queueIdle: " + this.mStage + ", mCurrentScreen: " + this.mCurrentScreen);
            }
            if (this.mMode == 0) {
                if (Launcher.localLOGD) {
                    Log.d(Launcher.LOG_TAG, ">> queueIdle + " + this.mStage);
                }
                switch (this.mStage) {
                    case 0:
                        if (Launcher.localLOGD) {
                            Profiler.stop(false, "First Frame: ");
                            break;
                        }
                        break;
                    case 1:
                        if (Launcher.localLOGD) {
                            Profiler.stop(false, "queueIdle - 1: ");
                        }
                        doScrollbar();
                        break;
                    case 2:
                        if (Launcher.localLOGD) {
                            Profiler.stop(false, "queueIdle - 2: ");
                        }
                        doWorkspace(false);
                        doWidgetOrientationChangeComplete();
                        Launcher.this.mWorkspace.updateBubbleText(Launcher.this.mCurrentOrientation, this.mCurrentScreen, false);
                        Launcher.this.onOrientationChangeEnd();
                        Launcher.sOrientationMonitor.end();
                        Launcher.this.mWorkspace.drawAllScreens();
                        Launcher.this.mFreezeable = true;
                        Launcher.this.mFxWorkspace.changeScreensVisibility(true);
                        Launcher.this.mWorkspace.unlock();
                        Launcher.this.mDrawer.setVisibility(4);
                        break;
                    case 3:
                        if (!Launcher.this.mFxWorkspace.checkUnlockFrameSet()) {
                            Launcher.this.mFxWorkspace.pulseFreezeAllScreens();
                        }
                        if (Launcher.localLOGD) {
                            Profiler.stop(false, "queueIdle - 3: ");
                        }
                        if (Launcher.this.mIsShowTutorialNotice) {
                            Launcher.this.showTutorialNotice();
                            break;
                        }
                        break;
                    case 4:
                        if (Launcher.localLOGD) {
                            Profiler.stop(false, "queueIdle - 4: ");
                        }
                        if (Launcher.needActivityResult) {
                            Launcher.this.onActivityResult(Launcher.requestCodeBackup, Launcher.resultCodeBackup, Launcher.dataBackup);
                            Launcher.requestCodeBackup = 0;
                            Launcher.resultCodeBackup = 0;
                            Launcher.dataBackup = null;
                            Launcher.needActivityResult = false;
                        }
                        Launcher.this.freezeTilt(false);
                        break;
                    case 5:
                        if (Launcher.localLOGD) {
                            Profiler.stop(false, "queueIdle - 5: handleOrientationChangedPendingTask");
                        }
                        Launcher.this.handleOrientationChangedPendingTask();
                        break;
                    default:
                        if (Launcher.localLOGD) {
                            Profiler.stop(false, "queueIdle - end: ");
                        }
                        Launcher.access$8910(Launcher.this);
                        Launcher.this.mChangingOrientation = false;
                        Launcher.this.freezeTilt(false);
                        return false;
                }
                if (Launcher.localLOGD) {
                    Log.d(Launcher.LOG_TAG, ">> queueIdle - " + this.mStage);
                }
            } else {
                if (Launcher.localLOGD) {
                    Log.d(Launcher.LOG_TAG, ">> queueIdle + " + this.mStage);
                }
                switch (this.mStage) {
                    case 0:
                        Launcher.this.mDesktopItemController.onConfigurationChanged(Launcher.this.mNewConfig);
                        Launcher.this.enableTilt(false);
                        Launcher.this.mWorkspace.updateOrientation(Launcher.this.mCurrentOrientation == 1);
                        doScrollbar();
                        if (Launcher.this.isShowAllProgramSearchBar && Launcher.this.mAllAppsBarEditText != null) {
                            InputMethodManager imm = (InputMethodManager) Launcher.this.getSystemService("input_method");
                            imm.focusIn(Launcher.this.mAllAppsBarEditText);
                            break;
                        }
                        break;
                    case 1:
                        Launcher.this.removeDropTargetsOfDropBar();
                        Launcher.this.mFxWorkspace.updateFxWorkspace(Launcher.this.mNewConfig);
                        Launcher.this.mTiltListener.reset();
                        Launcher.this.mWidgetTilter.reset();
                        Launcher.this.mWorkspace.setCurrentScreen(this.mCurrentScreen);
                        doWorkspace(true);
                        Launcher.this.mWorkspace.updateBubbleText(Launcher.this.mCurrentOrientation, this.mCurrentScreen, true);
                        break;
                    case 2:
                        Launcher.this.mFxWorkspace.populateOtherScreens();
                        doWorkspace(false);
                        doWidgetOrientationChangeComplete();
                        Launcher.this.mWorkspace.updateBubbleText(Launcher.this.mCurrentOrientation, this.mCurrentScreen, false);
                        Launcher.this.getDropTargetsOfDropBar();
                        Launcher.this.onOrientationChangeEnd();
                        Launcher.sOrientationMonitor.end();
                        Launcher.this.mFreezeable = true;
                        Launcher.this.mWorkspace.unlock();
                        break;
                    case 3:
                        if (!Launcher.this.mFxWorkspace.checkUnlockFrameSet()) {
                            Launcher.this.mFxWorkspace.pulseFreezeAllScreens();
                        }
                        if (Launcher.this.mIsShowTutorialNotice) {
                            Launcher.this.showTutorialNotice();
                            break;
                        }
                        break;
                    case 4:
                        if (Launcher.needActivityResult) {
                            Launcher.this.onActivityResult(Launcher.requestCodeBackup, Launcher.resultCodeBackup, Launcher.dataBackup);
                            Launcher.requestCodeBackup = 0;
                            Launcher.resultCodeBackup = 0;
                            Launcher.dataBackup = null;
                            Launcher.needActivityResult = false;
                            break;
                        }
                        break;
                    case 5:
                        Launcher.this.handleOrientationChangedPendingTask();
                        break;
                    default:
                        Launcher.access$8910(Launcher.this);
                        Launcher.this.mTiltListener.reset();
                        Launcher.this.enableTilt(true);
                        Launcher.this.mChangingOrientation = false;
                        return false;
                }
                if (Launcher.localLOGD) {
                    Log.d(Launcher.LOG_TAG, ">> queueIdle - " + this.mStage);
                }
            }
            this.mStage++;
            Launcher.this.mWorkspace.post(Launcher.this.mEmptyRunnable);
            return true;
        }

        private void doWidgetOrientationChangeComplete() {
            if (Launcher.localLOGD) {
                Profiler.stop(false, "onOrientationChangeComplete + : ");
            }
            Launcher.this.mFxWidgetManager.onOrientationChangeComplete(this.mCurrentScreen);
            int N = SettingUtil.getScreenCount();
            for (int i = 0; i < N; i++) {
                if (i != this.mCurrentScreen) {
                    Launcher.this.mFxWidgetManager.onOrientationChangeComplete(i);
                }
            }
            if (Launcher.localLOGD) {
                Profiler.stop(false, "onOrientationChangeComplete - : ");
            }
        }

        private void doScrollbar() {
            Launcher.this.mDragLayer.restoreRemovedChildren();
            Launcher.this.onOrientationChanged(Launcher.this.mCurrentOrientation == 1);
        }

        private void doWorkspace(boolean screenOnly) {
            Launcher.this.mWorkspace.restoreRemovedChildren(this.mCurrentScreen, screenOnly);
            Launcher.this.mWidgetsManager.onOrientationChanged(Launcher.this, Launcher.this.mWorkspace, Launcher.this.mCurrentOrientation, this.mCurrentScreen, screenOnly);
            DesktopItemController desktopItemController = Launcher.this.mDesktopItemController;
            DesktopItemController.onAppWidgetOrientationChanged(Launcher.this, Launcher.this.mWorkspace, Launcher.this.mAppWidgetManager, Launcher.this.mAppWidgetHost, this.mCurrentScreen, screenOnly);
        }

        void doStageOne() {
            Launcher.this.mDesktopItemController.onConfigurationChanged(Launcher.this.mNewConfig);
            Launcher.this.freezeTilt(true);
            Launcher.this.removeDropTargetsOfDropBar();
            Launcher.this.mFxWorkspace.updateFxWorkspace(Launcher.this.mNewConfig);
            Launcher.this.mTiltListener.reset();
            Launcher.this.mWidgetTilter.reset();
            Launcher.this.mWorkspace.setCurrentScreen(this.mCurrentScreen);
            Launcher.this.mWorkspace.updateOrientation(Launcher.this.mCurrentOrientation == 1);
            doWorkspace(true);
            Launcher.this.mWorkspace.updateBubbleText(Launcher.this.mCurrentOrientation, this.mCurrentScreen, true);
            Launcher.this.getDropTargetsOfDropBar();
        }
    }

    private void onSimChanged(int newMcc, int newMnc) {
        this.mCurrentMcc = newMcc;
        this.mCurrentMnc = newMnc;
        saveLocaleAndSimConfigs();
        Thread thread1 = new Thread() { // from class: com.htc.launcher.Launcher.22
            @Override // java.lang.Thread, java.lang.Runnable
            public void run() {
                Launcher.this.updateApplicationListAfterMccMncChanged();
            }
        };
        thread1.start();
        Thread thread2 = new Thread() { // from class: com.htc.launcher.Launcher.23
            @Override // java.lang.Thread, java.lang.Runnable
            public void run() {
                ContentResolver contentResolver = Launcher.this.getContentResolver();
                PackageManager manager = Launcher.this.getPackageManager();
                LauncherModel.updateShortcutLabels(contentResolver, manager);
                Launcher.this.updateShortcutsAfterMccMncChanged();
            }
        };
        thread2.start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateApplicationListAfterMccMncChanged() {
        CharSequence title;
        PackageManager packageManager = getPackageManager();
        if (packageManager != null) {
            FilterableAndSortableApplicationInfoList appList = getModel().getApplications();
            for (int i = 0; i < appList.originalSize(); i++) {
                ApplicationInfo app = appList.originalGet(i);
                ActivityInfo activityInfo = null;
                if (app != null) {
                    try {
                        if (app.intent != null) {
                            activityInfo = packageManager.getActivityInfo(app.intent.getComponent(), 0);
                        }
                    } catch (PackageManager.NameNotFoundException e) {
                        Log.e(LOG_TAG, "Couldn't find ActivityInfo for selected application", e);
                    }
                }
                if (activityInfo != null && (title = activityInfo.loadLabel(packageManager)) != null && !title.equals(app.title)) {
                    app.title = title;
                }
            }
        }
        runOnUiThread(new Runnable() { // from class: com.htc.launcher.Launcher.24
            @Override // java.lang.Runnable
            public void run() {
                ApplicationsAdapter applicationList = Launcher.getModel().getApplicationsAdapter();
                applicationList.notifyDataSetChanged();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void updateShortcutsAfterMccMncChanged() {
        CharSequence title;
        PackageManager packageManager = getPackageManager();
        for (int i = 0; i < this.mWorkspace.getChildCount(); i++) {
            View childView = this.mWorkspace.getChildAt(i);
            if (childView instanceof CellLayout) {
                CellLayout cell = (CellLayout) childView;
                for (int j = 0; j < cell.getChildCount(); j++) {
                    final View view = cell.getChildAt(j);
                    Object tag = view.getTag();
                    if (tag instanceof ApplicationInfo) {
                        final ApplicationInfo appInfo = (ApplicationInfo) tag;
                        if (appInfo.itemType == 0) {
                            if (localLOGD) {
                                Log.d(LOG_TAG, "before update - " + ((Object) appInfo.title));
                            }
                            ActivityInfo activityInfo = null;
                            try {
                                activityInfo = packageManager.getActivityInfo(appInfo.intent.getComponent(), 0);
                            } catch (PackageManager.NameNotFoundException e) {
                                Log.e(LOG_TAG, "Couldn't find ActivityInfo for selected application", e);
                            }
                            if (activityInfo != null && (title = AllAppsGridView.translateAppTitle((String) activityInfo.loadLabel(packageManager), this)) != null && !title.equals(appInfo.title)) {
                                appInfo.title = title;
                                LauncherModel.updateItemInDatabase(this, appInfo);
                                if (localLOGD) {
                                    Log.d(LOG_TAG, "after update - " + ((Object) appInfo.title));
                                }
                                if (view instanceof TextView) {
                                    runOnUiThread(new Runnable() { // from class: com.htc.launcher.Launcher.25
                                        @Override // java.lang.Runnable
                                        public void run() {
                                            ((TextView) view).setText(appInfo.title);
                                            if (Launcher.localLOGD) {
                                                Log.d(Launcher.LOG_TAG, "update UI - " + ((Object) appInfo.title));
                                            }
                                        }
                                    });
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    void showSearchDialog(String initialQuery, boolean selectInitialQuery, Bundle appSearchData, boolean globalSearch) {
        if (initialQuery == null) {
            initialQuery = getTypedText();
            clearTypedText();
        }
        if (appSearchData == null) {
            appSearchData = new Bundle();
            appSearchData.putString(Search.SOURCE, "launcher-search");
        }
        SearchManager searchManager = (SearchManager) getSystemService("search");
        searchManager.startSearch(initialQuery, selectInitialQuery, getComponentName(), appSearchData, globalSearch);
    }

    private String getTypedText() {
        return this.mDefaultKeySsb.toString();
    }

    private void clearTypedText() {
        this.mDefaultKeySsb.clear();
        this.mDefaultKeySsb.clearSpans();
        Selection.setSelection(this.mDefaultKeySsb, 0);
    }

    /* JADX WARN: Multi-variable type inference failed */
    void enablePageSelect(boolean enable) {
        if (enable) {
        }
        this.mPageSelect = enable;
        if (enable) {
            stop3DAnimation();
            android.app.WallpaperManager.getInstance(this).sendWallpaperCommand(this.mWorkspace.getWindowToken(), "com.htc.android.wallpaper.partial_pause", 0, 0, 0, null);
        } else {
            if (this.mControlInAnimation == null) {
            }
            android.app.WallpaperManager.getInstance(this).sendWallpaperCommand(this.mWorkspace.getWindowToken(), "com.htc.android.wallpaper.partial_resume", 0, 0, 0, null);
        }
    }

    public boolean canEnableLeapMode() {
        return (!this.mWindowFocus || !isDrawerDown() || this.mDragLayer == null || this.mDragLayer.isDragging() || !this.mWorkspace.canEnableThumbnailMode() || this.mIsLockEnterThumbnailMode || this.mOnOrientationChange || this.mUnlockAnimListener.mAnimating) ? false : true;
    }

    public void stop3DAnimation() {
        stop3DAnimation(false);
    }

    public void stop3DAnimation(boolean bResumeWidgets) {
        stopService(new Intent(ACTION_HIDE_WEATHER_WALLPAPER));
        if (bResumeWidgets) {
            this.mWidgetsManager.fireVisible(this.mWorkspace.getCurrentScreenIndex());
        }
    }

    private void registerWeatherAnimationNotify() {
        if (!this.mWeatherAnimationNotifyRegistered) {
            IntentFilter intentFilter = new IntentFilter(ACTION_WEATHER_ANIMATION_DONE);
            registerReceiver(this.mWeatherAnimationNotify, intentFilter);
            this.mWeatherAnimationNotifyRegistered = true;
        }
    }

    private void unregisterWeatherAnimationNotify() {
        if (this.mWeatherAnimationNotifyRegistered) {
            unregisterReceiver(this.mWeatherAnimationNotify);
            this.mWeatherAnimationNotifyRegistered = false;
        }
    }

    public void setWallpaper(Bitmap bitmap) throws IOException {
        if (localLOGD) {
            Log.d(LOG_TAG, "setWallpaper(Bitmap) - " + this.mSettingWallpaper);
        }
        if (SettingUtil.isLiveWallaperSupported()) {
            this.mSettingWallpaper++;
        }
        super.setWallpaper(bitmap);
    }

    public void setWallpaper(InputStream data) throws IOException {
        if (localLOGD) {
            Log.d(LOG_TAG, "setWallpaper(InputStream) - " + this.mSettingWallpaper);
        }
        if (SettingUtil.isLiveWallaperSupported()) {
            this.mSettingWallpaper++;
        }
        super.setWallpaper(data);
    }

    private boolean checkLocale(Context context) {
        String oldLocale = getSharedPreferences("launcher", 0).getString("locale", null);
        if (oldLocale == null) {
            return false;
        }
        String curLocale = context.getResources().getConfiguration().locale.toString();
        return !oldLocale.equals(curLocale);
    }

    private void clearLaputaNavigateFlag() {
        int mode = Settings.System.getInt(getContentResolver(), PROP_NAVI_MODE, 0);
        if (mode != 0) {
            if (localLOGD) {
                Log.d(LOG_TAG, "reset Laputa Navigation mode");
            }
            Settings.System.putInt(getContentResolver(), PROP_NAVI_MODE, 0);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void createScenePreview(Bitmap screenCache) {
        boolean isPortrait;
        String screenCacheFileName;
        String sharedPreferencesKeyPreviewInvalidate;
        if (localLOGD) {
            Log.d(LOG_TAG, "createScenePreview: " + screenCache);
        }
        if (screenCache != null && !screenCache.isRecycled()) {
            isPortrait = screenCache.getHeight() > screenCache.getWidth();
        } else {
            isPortrait = isPortrait();
        }
        int screenWidth = isPortrait ? SettingUtil.getScreenShortAxisLength() : SettingUtil.getScreenLongAxisLength();
        int screenHeight = isPortrait ? SettingUtil.getScreenLongAxisLength() : SettingUtil.getScreenShortAxisLength();
        if (isPortrait) {
            screenCacheFileName = SCREEN_CACHE_SRC;
            sharedPreferencesKeyPreviewInvalidate = KEY_SCENE_PREVIEW_PORT_INVALIDATE;
        } else {
            screenCacheFileName = SCREEN_CACHE_SRC_LAND;
            sharedPreferencesKeyPreviewInvalidate = KEY_SCENE_PREVIEW_LAND_INVALIDATE;
        }
        int sceneId = WidgetWorkspaceManager.instance(this).getCurrentWorkspaceId();
        String sceneFileName = ScenePickerAdapter.getSceneFileName(isPortrait, sceneId);
        boolean isPreviewInvalidate = true;
        long startTime = System.currentTimeMillis();
        if (screenCache == null || screenCache.isRecycled()) {
            if (localLOGD) {
                Log.d(LOG_TAG, "null screen cache!");
            }
            try {
                screenCache = BitmapFactory.decodeFile(screenCacheFileName);
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (screenCache == null) {
                if (localLOGD) {
                    Log.d(LOG_TAG, "no screen cache file found");
                    return;
                }
                return;
            }
        }
        try {
            Resources res = getResources();
            Paint paint = new Paint();
            paint.setFilterBitmap(true);
            float panelWidth = res.getDimension(R.dimen.panel_item_width);
            float panelHeight = res.getDimension(R.dimen.panel_item_height) - res.getDimension(R.dimen.panel_item_shadow_height);
            float panelMarginLeft = res.getDimension(R.dimen.panel_item_margin_left);
            float panelMarginRight = res.getDimension(R.dimen.panel_item_margin_right);
            float scaleX = ((panelWidth - panelMarginLeft) - panelMarginRight) / screenWidth;
            float scaleY = panelHeight / screenHeight;
            float thumbnailWidth = res.getDimension(R.dimen.scene_picker_list_item_thumbnail_width);
            float thumbnailHeight = res.getDimension(R.dimen.scene_picker_list_item_height);
            Bitmap previewBitmap = Bitmap.createBitmap((int) panelWidth, (int) panelHeight, Bitmap.Config.ARGB_8888);
            Canvas previewCanvas = new Canvas(previewBitmap);
            previewCanvas.scale(scaleX, scaleY);
            drawWallpaperOnCanvas(this, previewCanvas, screenWidth, screenHeight);
            BitmapDrawable statusBar = (BitmapDrawable) res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(getBaseContext(), "statusbar_background_l", R.drawable.status_bar));
            Bitmap statusBarBitmap = statusBar.getBitmap();
            float ratio = screenWidth / statusBarBitmap.getWidth();
            int saveState = previewCanvas.save();
            previewCanvas.scale(ratio, ratio);
            previewCanvas.drawBitmap(statusBarBitmap, panelMarginLeft / scaleX, 0.0f, paint);
            previewCanvas.restoreToCount(saveState);
            previewCanvas.drawBitmap(screenCache, 0.0f, 0.0f, paint);
            Bitmap thumbnailBitmap = Bitmap.createBitmap((int) thumbnailWidth, (int) thumbnailHeight, Bitmap.Config.ARGB_8888);
            Canvas thumbnailCanvas = new Canvas(thumbnailBitmap);
            thumbnailCanvas.scale(thumbnailWidth / panelWidth, thumbnailHeight / panelHeight);
            thumbnailCanvas.drawBitmap(previewBitmap, 0.0f, 0.0f, paint);
            int currentPriority = Process.getThreadPriority(Process.myTid());
            try {
                Process.setThreadPriority(-4);
                FileOutputStream out = new FileOutputStream(sceneFileName);
                previewBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                out.flush();
                out.close();
                FileOutputStream cellLayoutCache = new FileOutputStream(screenCacheFileName);
                screenCache.compress(Bitmap.CompressFormat.PNG, 100, cellLayoutCache);
                cellLayoutCache.flush();
                cellLayoutCache.close();
                FileUtils.setPermissions(screenCacheFileName, 438, -1, -1);
            } catch (Exception e2) {
                Log.e(LOG_TAG, "write failed");
                e2.printStackTrace();
            } finally {
                screenCache.recycle();
                Process.setThreadPriority(currentPriority);
            }
            isPreviewInvalidate = false;
        } catch (RuntimeException ex) {
            Log.e(LOG_TAG, "draw failed");
            ex.printStackTrace();
        }
        SharedPreferences preferences = getSharedPreferences("launcher", 0);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(sharedPreferencesKeyPreviewInvalidate, isPreviewInvalidate);
        editor.apply();
        if (!isPreviewInvalidate) {
            Intent notifySceneChangeIntent = new Intent(DownloadSceneReceiver.ACTION_UPDATE_SCENE);
            sendBroadcast(notifySceneChangeIntent);
            if (localLOGD) {
                Log.d(LOG_TAG, "create scene preview takes " + (System.currentTimeMillis() - startTime) + " ms");
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:27:0x006a  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0110  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    private static void drawWallpaperOnCanvas(Context context, Canvas canvas, int width, int height) {
        boolean isLiveWallpaper;
        BitmapDrawable wallpaperDrawable;
        BitmapDrawable wallpaperDrawable2;
        WidgetWorkspaceManager wwm = WidgetWorkspaceManager.instance(context);
        String wallpaperComponent = wwm.getCurrentWallpaperComponent();
        if (wallpaperComponent != null) {
            ComponentName componentName = ComponentName.unflattenFromString(wallpaperComponent);
            PackageManager pm = context.getPackageManager();
            ResolveInfo info = null;
            Intent intent = new Intent("android.service.wallpaper.WallpaperService");
            List<ResolveInfo> list = pm.queryIntentServices(intent, 128);
            int listSize = list.size();
            for (int i = 0; i < listSize; i++) {
                ResolveInfo resolveInfo = list.get(i);
                if (resolveInfo != null && componentName != null && componentName.getClassName().equals(resolveInfo.serviceInfo.name)) {
                    info = resolveInfo;
                }
            }
            if (info != null) {
                try {
                    WallpaperInfo wallpaperInfo = new WallpaperInfo(context, info);
                    if (wallpaperInfo != null) {
                        wallpaperInfo.loadLabel(pm);
                        String liveWallpaperImagePath = wwm.getCurrentLiveWallpaperFileName(wallpaperInfo.getServiceName());
                        Bitmap liveWallpaperImageBitmap = BitmapFactory.decodeFile(liveWallpaperImagePath);
                        if (liveWallpaperImageBitmap == null) {
                            BitmapDrawable wallpaperDrawable3 = (BitmapDrawable) wallpaperInfo.loadThumbnail(pm);
                            wallpaperDrawable = wallpaperDrawable3;
                        } else {
                            wallpaperDrawable = new BitmapDrawable(context.getResources(), liveWallpaperImageBitmap);
                        }
                        isLiveWallpaper = true;
                    } else {
                        android.app.WallpaperManager wallpaperManager = android.app.WallpaperManager.getInstance(context);
                        wallpaperDrawable = (BitmapDrawable) wallpaperManager.getDrawable();
                        isLiveWallpaper = true;
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    isLiveWallpaper = false;
                    wallpaperDrawable = null;
                } catch (XmlPullParserException e2) {
                    e2.printStackTrace();
                }
                if (isLiveWallpaper) {
                    BitmapDrawable wallpaperDrawable4 = new BitmapDrawable(context.getResources(), BitmapFactory.decodeFile(wwm.getCurrentStaticWallpaperFileName()));
                    wallpaperDrawable2 = wallpaperDrawable4;
                } else {
                    wallpaperDrawable2 = wallpaperDrawable;
                }
                Bitmap wallpaperBitmap = wallpaperDrawable2.getBitmap();
                if (wallpaperDrawable2 == null && wallpaperBitmap != null) {
                    Rect srcRect = new Rect(0, 0, wallpaperBitmap.getWidth(), wallpaperBitmap.getHeight());
                    Rect dstRect = new Rect(0, 0, width, height);
                    int width2 = srcRect.width();
                    int height2 = dstRect.width();
                    int dx = (width2 - height2) / 2;
                    int dy = (srcRect.height() - dstRect.height()) / 2;
                    if (localLOGD) {
                        Log.d(LOG_TAG, "dx:" + dx + " dy:" + dy);
                    }
                    srcRect.inset(Math.max(0, dx), Math.max(0, dy));
                    canvas.drawBitmap(wallpaperBitmap, srcRect, dstRect, (Paint) null);
                    return;
                }
            }
        }
        isLiveWallpaper = false;
        wallpaperDrawable = null;
        if (isLiveWallpaper) {
        }
        Bitmap wallpaperBitmap2 = wallpaperDrawable2.getBitmap();
        if (wallpaperDrawable2 == null) {
        }
    }

    public class PersonalizeOnItemClickListener implements HtcAdapterView.OnItemClickListener {
        public PersonalizeOnItemClickListener() {
        }

        public void onItemClick(HtcAdapterView<?> parent, View view, int position, long id) {
            AddAdapter.ListItem item = (AddAdapter.ListItem) view.getTag();
            Intent intent = item.intent;
            String action = intent.getAction();
            if (action != null && action.equals("com.htc.intent.ACTION_PERSONALIZE_ADD_TO_HOME")) {
                Launcher.this.mAddHtcWidgetByOtherActivity = true;
                Launcher.this.onClickAddtoHome(null);
                return;
            }
            if (action != null && action.equals("com.htc.intent.ACTION_PERSONALIZE_WALLPAPER")) {
                Launcher.this.mAddHtcWidgetByOtherActivity = true;
                if (SettingUtil.isLiveWallaperSupported()) {
                    Launcher.this.startWallpaper();
                    return;
                } else {
                    Launcher.this.showDialog(102);
                    return;
                }
            }
            if (action == null || !action.equals("android.intent.action.RINGTONE_PICKER")) {
                Launcher.this.mAddHtcWidgetByOtherActivity = true;
                Launcher.this.startActivitySafely(item.intent);
            } else if (intent.getIntExtra("android.intent.extra.ringtone.TYPE", 1) == 1) {
                intent.putExtra("android.intent.extra.ringtone.EXISTING_URI", RingtoneManager.getActualDefaultRingtoneUri(Launcher.this, 1));
                Launcher.this.startActivityForResult(intent, 13);
            } else {
                intent.putExtra("android.intent.extra.ringtone.EXISTING_URI", RingtoneManager.getActualDefaultRingtoneUri(Launcher.this, 2));
                Launcher.this.startActivityForResult(intent, 14);
            }
        }
    }

    public CharSequence getLiveWallpaperName() {
        return mLiveWallpaperName;
    }

    public void setLiveWallpaperName(CharSequence LiveWallpaperName) {
        mLiveWallpaperName = LiveWallpaperName;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public void onOrientationChangeEnd() {
        if (localLOGD) {
            Log.d(LOG_TAG, "onOrientationChanged End");
        }
        if (this.isSupportLandscape) {
            android.app.WallpaperManager.getInstance(this).sendWallpaperCommand(this.mWorkspace.getWindowToken(), "com.htc.android.wallpaper.resume", 0, 0, 0, null);
            WallpaperManager.getInstance(this).pauseWallpaper(this.mWorkspace.getWindowToken(), false);
        } else {
            this.mStartOrientation = -1L;
            sOrientationMonitor.onOrientationChanged(false);
        }
        this.mOnOrientationChange = false;
        this.mWorkspace.setVisibility(0);
    }

    public void invalidateScenePreviews() {
        SharedPreferences preferences = getSharedPreferences("launcher", 0);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(KEY_SCENE_PREVIEW_PORT_INVALIDATE, true);
        editor.putBoolean(KEY_SCENE_PREVIEW_LAND_INVALIDATE, true);
        editor.apply();
    }

    public class RosieUnlockAnimationListener extends UnlockAnimationListener {
        boolean mAnimating;
        WallpaperManager mWallpaperMgr;

        /* JADX WARN: Multi-variable type inference failed */
        public RosieUnlockAnimationListener(Workspace workspace, FxWorkspace fxWorkspace) {
            super(workspace, fxWorkspace);
            this.mAnimating = false;
            this.mWallpaperMgr = WallpaperManager.getInstance(Launcher.this);
        }

        @Override // com.htc.android.rosie.home.fxcontrol.UnlockAnimationListener, com.htc.android.rosie.home.fxcontrol.FxWorkspace.IUnlockAnimationListener
        public void onAnimationStart() {
            super.onAnimationStart();
            this.mAnimating = true;
        }

        @Override // com.htc.android.rosie.home.fxcontrol.UnlockAnimationListener, com.htc.android.rosie.home.fxcontrol.FxWorkspace.IUnlockAnimationListener
        public void onAnimationEnd() {
            this.mAnimating = false;
            Launcher.this.onKeyguardOff();
            this.mWallpaperMgr.pauseWallpaper(Launcher.this.mWorkspace.getWindowToken(), false);
            if (Launcher.this.mFxWidgetManager != null) {
                Launcher.this.mFxWidgetManager.onUserPresent(Launcher.this.mWorkspace.getCurrentScreenIndex(), !Launcher.this.mDrawer.isOpened());
                Launcher.this.mFxWidgetManager.resumeWidgets(Launcher.getScreen());
            }
            super.onAnimationEnd();
        }
    }

    public class RosiePhoneStateListener extends PhoneStateListener {
        public RosiePhoneStateListener() {
        }

        @Override // android.telephony.PhoneStateListener
        public void onCallStateChanged(int state, String incomingNumber) {
            if (Launcher.localLOGD) {
                Logger.d(Launcher.LOG_TAG, "RosiePhoneStateListener - onCallStateChanged state:" + state + "incomingNumber:" + incomingNumber);
            }
            if (state == 2) {
                Launcher.this.mFxWorkspace.playPhoneAnim();
                Launcher.this.mIsInComingCall = true;
            } else if (state == 0) {
                Launcher.this.mIsInComingCall = false;
                Launcher.this.mFxWorkspace.stopPhoneAnim();
            }
            super.onCallStateChanged(state, incomingNumber);
        }
    }

    private final class TiltSettingsObserver implements Observer {
        private TiltSettingsObserver() {
        }

        @Override // java.util.Observer
        public void update(Observable o, Object arg) {
            Launcher.this.mTiltSettingEnable = Settings.System.getBoolean(Launcher.this.getContentResolver(), "htc_3d_home_screen", Launcher.this.mTiltSettingEnable);
            if (Launcher.this.mTiltSettingEnable) {
                Launcher.this.mTiltListener.reset();
                Launcher.this.mWidgetTilter.reset();
            } else {
                Launcher.this.enableTilt(false);
                Launcher.this.mTiltListener.reset();
                Launcher.this.mWidgetTilter.reset();
            }
        }
    }

    public void registerTiltObserver(TiltObserver observer) {
        synchronized (this.mTiltObservers) {
            if (this.mTiltObservers != null && !this.mTiltObservers.contains(observer)) {
                this.mTiltObservers.add(observer);
            }
        }
    }

    public void unregisterTiltObserver(TiltObserver observer) {
        synchronized (this.mTiltObservers) {
            if (this.mTiltObservers != null) {
                this.mTiltObservers.remove(observer);
            }
        }
    }

    class ExSensorEventListener implements SensorEventListener {
        private static final float FILTERING = 0.1f;
        private static final float GRAVITY_RANGE = 19.6133f;
        private static final String LOG_TAG = "SensorEvent";
        private static final float ONE_MINUS_FILTERING = 0.9f;
        private static final float TILT_THRESHOLD = 1.0f;
        private static final float TIME_THRESHOLD = 2.0E9f;
        private float mAnchorTilt;
        private float mEventValue;
        private float mFrameAt;
        private float mFrameGap;
        private float mLastTilt;
        private long mLastTimestamp;
        private float mTilt;
        private final float RECOVERY_RATE = TILT_THRESHOLD;
        private final float RECOVERY_COUNT_TIMES = 500.0f;
        private final float RECOVERY_COUNT_RANGE = 500.0f;
        private final DecelerateInterpolator mInterpolator = new DecelerateInterpolator(40.0f);
        private float mRecoveryFrameCount = 0.0f;
        private boolean mResetAnchor = true;

        ExSensorEventListener() {
        }

        private float getPowerInterpolation(float input) {
            return Math.max(Math.min(this.mInterpolator.getInterpolation(input), TILT_THRESHOLD), 0.0f);
        }

        @Override // android.hardware.SensorEventListener
        public void onSensorChanged(SensorEvent event) {
            if (Launcher.this.mTiltEnabled && !Launcher.this.mFreezeTilt && event.sensor.getType() == 1) {
                this.mEventValue = Launcher.this.isPortrait() ? event.values[0] : event.values[1];
                if (this.mResetAnchor) {
                    this.mAnchorTilt = this.mEventValue;
                    this.mResetAnchor = false;
                    return;
                }
                if (Math.abs(this.mEventValue) >= 1.5f || Math.abs(this.mFrameAt - 0.5f) >= 1.0E-4d) {
                    if (Launcher.this.mTiltSettingEnable) {
                        this.mTilt = this.mEventValue - this.mAnchorTilt;
                    }
                    if (Math.abs(this.mTilt - this.mLastTilt) >= TILT_THRESHOLD) {
                        if (this.mRecoveryFrameCount != 0.0f) {
                            if (Launcher.localLOGD) {
                                Log.d(LOG_TAG, "anchor_change");
                            }
                            this.mLastTilt = (this.mFrameAt * GRAVITY_RANGE) - 9.80665f;
                            this.mAnchorTilt = this.mEventValue - this.mLastTilt;
                            this.mRecoveryFrameCount = 0.0f;
                            this.mTilt = this.mEventValue - this.mAnchorTilt;
                        }
                        this.mLastTimestamp = event.timestamp;
                        this.mTilt = (this.mTilt * FILTERING) + (this.mLastTilt * ONE_MINUS_FILTERING);
                        this.mLastTilt = this.mTilt;
                        this.mFrameAt = Math.min(Math.max((this.mTilt + 9.80665f) / GRAVITY_RANGE, 0.0f), TILT_THRESHOLD);
                        synchronized (Launcher.this.mTiltObservers) {
                            if (Launcher.this.mTiltObservers != null) {
                                for (TiltObserver r : Launcher.this.mTiltObservers) {
                                    r.onTilt(this.mFrameAt, TILT_THRESHOLD);
                                }
                                return;
                            }
                            return;
                        }
                    }
                    if (this.mRecoveryFrameCount <= 0.0f) {
                        if (event.timestamp - this.mLastTimestamp > TIME_THRESHOLD) {
                            if (Launcher.localLOGD) {
                                Log.d(LOG_TAG, "recoveryEvent_begin");
                            }
                            this.mRecoveryFrameCount = TILT_THRESHOLD;
                            this.mFrameGap = this.mFrameAt - 0.5f;
                            return;
                        }
                        return;
                    }
                    if (this.mRecoveryFrameCount <= 500.0f && this.mFrameAt != 0.5f) {
                        synchronized (Launcher.this.mTiltObservers) {
                            if (Launcher.this.mTiltObservers != null) {
                                for (TiltObserver r2 : Launcher.this.mTiltObservers) {
                                    this.mFrameAt = (this.mFrameGap * (TILT_THRESHOLD - getPowerInterpolation(this.mRecoveryFrameCount / 500.0f))) + 0.5f;
                                    r2.onTilt(this.mFrameAt, TILT_THRESHOLD);
                                }
                                this.mRecoveryFrameCount += TILT_THRESHOLD;
                                return;
                            }
                            return;
                        }
                    }
                    if (Launcher.localLOGD) {
                        Log.d(LOG_TAG, "recoveryEvent_done");
                    }
                    synchronized (Launcher.this.mTiltObservers) {
                        if (Launcher.this.mTiltObservers != null) {
                            for (TiltObserver r3 : Launcher.this.mTiltObservers) {
                                r3.onTilt(0.5f, TILT_THRESHOLD);
                            }
                            this.mRecoveryFrameCount = 0.0f;
                            this.mFrameGap = 0.0f;
                            this.mLastTilt = 0.0f;
                            this.mAnchorTilt = this.mEventValue;
                        }
                    }
                }
            }
        }

        public void reset() {
            this.mFrameAt = 0.5f;
            float f = (this.mFrameAt * GRAVITY_RANGE) - 9.80665f;
            this.mTilt = f;
            this.mLastTilt = f;
            this.mResetAnchor = true;
            this.mFrameGap = 0.0f;
            this.mRecoveryFrameCount = 0.0f;
            synchronized (Launcher.this.mTiltObservers) {
                if (Launcher.this.mTiltObservers != null) {
                    for (TiltObserver r : Launcher.this.mTiltObservers) {
                        r.onTilt(this.mFrameAt, TILT_THRESHOLD);
                    }
                }
            }
        }

        @Override // android.hardware.SensorEventListener
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void enableTilt(boolean enable) {
        if (this.mTiltEnabled != enable && this.mTiltSettingEnable == enable) {
            if (enable) {
                if (this.mSensorManager == null) {
                    this.mSensorManager = (SensorManager) getSystemService("sensor");
                    if (localLOGD) {
                        Logger.d(LOG_TAG, "new a SensorManager for enableTilt");
                    }
                    Logger.showStack(10, LOG_TAG);
                    if (this.mSensorManager == null) {
                        return;
                    }
                }
                if (this.mTiltSensor == null) {
                    this.mTiltSensor = this.mSensorManager.getDefaultSensor(1);
                    if (this.mTiltSensor == null) {
                        return;
                    }
                }
                enable = this.mSensorManager.registerListener(this.mTiltListener, this.mTiltSensor, 1);
            } else if (this.mSensorManager != null && this.mTiltSensor != null) {
                this.mSensorManager.unregisterListener(this.mTiltListener, this.mTiltSensor);
                this.mTiltSensor = null;
                this.mSensorManager = null;
            } else {
                return;
            }
            this.mTiltEnabled = enable;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void freezeTilt(boolean freeze) {
        this.mFreezeTilt = freeze;
    }

    public void flattenWidgets(int screen) {
        this.mWidgetTilter.flattenWidgets(screen);
    }

    private class WidgetTilter implements TiltObserver, Workspace.OnScrollStateChangedListener, Workspace.OnSlideListener {
        private static final float DEFAULT_SCROLL_VALUE = 0.0f;
        private static final float DEFAULT_TILT_VALUE = 0.5f;
        private static final float SCROLLING_MAX_TILT = 0.85f;
        private boolean mAdjustTilt;
        private int mLastScroll;
        private boolean mNeedDir;
        private int mNeighbor;
        private int mScreen;
        private float mScrollValue;
        private boolean mSurpressScroll;
        private boolean mSurpresseSensor;
        private float mTiltValue;

        private WidgetTilter() {
            this.mTiltValue = DEFAULT_TILT_VALUE;
            this.mScrollValue = DEFAULT_SCROLL_VALUE;
            this.mNeighbor = 0;
            this.mNeedDir = false;
            this.mAdjustTilt = SettingUtil.isTabletDevice();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void surpressSensor(boolean surpress) {
            this.mSurpresseSensor = surpress;
        }

        @Override // com.htc.launcher.Launcher.TiltObserver
        public void onTilt(float value, float speed) {
            if (needsUpdate() && !this.mSurpresseSensor) {
                this.mTiltValue = value;
                tiltWidgets(false);
            }
        }

        @Override // com.htc.launcher.Workspace.OnSlideListener
        public void onScrollTo(float x, float y, int scrollRange, int screenWidth) {
            if (Launcher.this.mWorkspace != null && screenWidth != 0) {
                int floorX = (int) x;
                int currentScreen = floorX / screenWidth;
                this.mScreen = currentScreen;
                if (needsUpdate() && !this.mSurpressScroll) {
                    this.mScrollValue = Math.abs((floorX % screenWidth) / screenWidth);
                    if (this.mNeedDir) {
                        this.mNeedDir = false;
                    }
                    this.mLastScroll = floorX;
                    tiltWidgets(true);
                }
            }
        }

        @Override // com.htc.launcher.Workspace.OnSlideListener
        public void onFling(int x, int begin, int end) {
        }

        @Override // com.htc.launcher.Workspace.OnSlideListener
        public void onTouch(MotionEvent ev, int x) {
        }

        @Override // com.htc.launcher.Workspace.OnScrollStateChangedListener
        public void onBeginFling() {
        }

        @Override // com.htc.launcher.Workspace.OnScrollStateChangedListener
        public void onBeginScroll(boolean isSnap, int begin, int end) {
            this.mNeedDir = true;
            this.mNeighbor = 1;
        }

        @Override // com.htc.launcher.Workspace.OnScrollStateChangedListener
        public void onEndScroll() {
            this.mNeighbor = 0;
            this.mSurpressScroll = false;
        }

        private boolean needsUpdate() {
            return true;
        }

        public boolean isTilting() {
            return (this.mTiltValue == DEFAULT_TILT_VALUE && this.mScrollValue == DEFAULT_SCROLL_VALUE) ? false : true;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void reset() {
            if (Launcher.localLOGD) {
                Log.d("widget tilter", "reset");
            }
            this.mTiltValue = DEFAULT_TILT_VALUE;
            this.mScrollValue = DEFAULT_SCROLL_VALUE;
            if (Launcher.this.mFxWidgetManager != null) {
                int N = SettingUtil.getScreenCount();
                for (int i = 0; i < N; i++) {
                    Launcher.this.mFxWidgetManager.tiltWidgets(i, DEFAULT_SCROLL_VALUE);
                }
            }
        }

        private float adjustTiltValue(float value) {
            return value;
        }

        public void flattenOtherWidgets(int current, int neibor) {
            for (int i = 0; i < SettingUtil.sWorkspaceScreenCount; i++) {
                if (i != current && i != current) {
                    Launcher.this.mFxWidgetManager.tiltWidgets(i, DEFAULT_SCROLL_VALUE);
                }
            }
        }

        public void flattenWidgets(int screen) {
            Launcher.this.mFxWidgetManager.tiltWidgets(screen, DEFAULT_SCROLL_VALUE);
        }

        private void tiltWidgets(boolean forScrolling) {
            float value;
            if (Launcher.this.mWorkspace != null && Launcher.this.mFxWidgetManager != null) {
                int screen = this.mScreen;
                float value2 = Math.abs(this.mTiltValue - DEFAULT_TILT_VALUE);
                if (Launcher.this.isPortrait()) {
                    value = value2 + ((1.0f - value2) * Math.abs(this.mScrollValue));
                } else {
                    value = ((float) Math.sin((((1.0f - value2) * Math.abs(this.mScrollValue)) + value2) * 3.141592653589793d)) / 2.0f;
                }
                float value3 = Math.min(1.0f, Math.max(value, DEFAULT_SCROLL_VALUE));
                if (screen >= 0 && screen < SettingUtil.getScreenCount()) {
                    Launcher.this.mFxWidgetManager.tiltWidgets(screen, forScrolling ? adjustTiltValue(value3) : value3);
                }
                if (this.mNeighbor != 0) {
                    int screen2 = screen + this.mNeighbor;
                    if (SettingUtil.usesRingSlide() && screen2 == SettingUtil.getScreenCount()) {
                        screen2 = 0;
                    }
                    if (screen2 >= 0 && screen2 < SettingUtil.getScreenCount()) {
                        if (Launcher.this.isPortrait()) {
                            value3 = Math.max(1.0f - value3, Math.abs(this.mTiltValue - DEFAULT_TILT_VALUE));
                        }
                        Launcher.this.mFxWidgetManager.tiltWidgets(screen2, forScrolling ? adjustTiltValue(value3) : value3);
                    }
                }
            }
        }

        @Override // com.htc.launcher.Workspace.OnScrollStateChangedListener
        public void updateSnapInfo(int endScreen, int snapOffset) {
        }
    }

    public FxWorkspace getFxWorkspace() {
        return this.mFxWorkspace;
    }

    @Override // com.htc.launcher.LeapController.LeapListener
    public void beginLeap(int selectPage) {
        enableTilt(false);
        this.mTiltListener.reset();
        this.mWidgetTilter.reset();
        this.mFxWidgetManager.pauseWidgets(getScreen(), false);
        enablePageSelect(true);
        raisePriority(true);
    }

    @Override // com.htc.launcher.LeapController.LeapListener
    public void endLeap(int selectPage) {
        setScreen(selectPage);
        this.mLeapController.cancelGesture();
        enablePageSelect(false);
        raisePriority(false);
        this.mTiltListener.reset();
        enableTilt(true);
        this.mWidgetsManager.fireVisible(selectPage);
        this.mFxWidgetManager.resumeWidgets(getScreen());
    }

    @Override // com.htc.launcher.LeapController.LeapListener
    public void onAnimationStateChanged(boolean playing, LeapController.ZoomDirection direction) {
        if (playing) {
            this.mWidgetsManager.fireVisible(-1);
        } else if (SettingUtil.sIsRealTimeThumbnailMode && direction == LeapController.ZoomDirection.ZOOM_OUT) {
            this.mWidgetsManager.fireAllVisible();
        }
    }

    @Override // com.htc.launcher.LeapController.LeapListener
    public void onLongPress() {
    }

    public int findPanelFromFxWorkspace(float x, float y) {
        return this.mFxWorkspace.findNearestLeapPanel(x, y);
    }

    public Bundle getSavedState() {
        return this.mSavedState;
    }

    public boolean isPortrait() {
        return !SettingUtil.isSupportLandscape() || getResources().getConfiguration().orientation == 1;
    }

    public static String getFxPath() {
        return sFxPathFinder.getPath().get();
    }

    public static FxSceneManager getFxSceneManager() {
        return sFxSceneManager;
    }

    public boolean isLoading() {
        return this.mIsLoading;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean showUnlockAnimation() {
        return (this.mIsPause || this.mIsLoading || this.mDrawer.isOpened() || (this.mLeapController != null && this.mLeapController.isLeapMode())) ? false : true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void getDropTargetsOfDropBar() {
        List<DropTarget> fxDropTargets = this.mFxWorkspace.getDropTargets();
        for (DropTarget t : fxDropTargets) {
            this.mDragLayer.addDropTarget(t);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void removeDropTargetsOfDropBar() {
        List<DropTarget> fxDropTargets = this.mFxWorkspace.getDropTargets();
        for (DropTarget t : fxDropTargets) {
            this.mDragLayer.removeDropTarget(t);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void liveWallpaperSpin() {
        this.mNeedLiveWallpaperSpin = false;
        android.app.WallpaperManager.getInstance(this).sendWallpaperCommand(this.mWorkspace.getWindowToken(), "com.htc.livewallpaper.UNLOCK_SPIN", 0, 0, 0, null);
    }

    public void addButtonbarItems(int clickButton) {
        ifAddButtonbar = true;
        mMiddleClickButton = clickButton;
        if (this.mListAdapter != null) {
            this.mListAdapter.setHeightPriority();
        }
        if (!this.mDrawer.isOpened()) {
            prepareCurrentScreenCache();
            changeDrawerContentById(R.id.content_add_to_home);
            prepareAddToButtonbarContent();
        }
        addItems();
    }

    private void prepareAddToButtonbarContent() {
        this.mListAdapter.reset(true);
        this.mProgramListLayout.doCheckTitle();
    }

    private void addItems() {
        this.mMenuAddInfo = this.mWorkspace.findAllVacantCells(null);
        onClickAddtoHome(this.mMenuAddInfo);
        this.mWorkspace.invalidateVacant();
    }

    public boolean isAddButtonbar() {
        return mMiddleClickButton != -1;
    }

    public int getMiddleClickButton() {
        return mMiddleClickButton;
    }

    public void resetMiddleButton() {
        mMiddleClickButton = -1;
    }

    private void saveLocaleAndSimConfigs() {
        SharedPreferences preferences = getSharedPreferences("launcher", 0);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("locale", this.mCurrentLocale);
        editor.putInt(KEY_MCC, this.mCurrentMcc);
        editor.putInt(KEY_MNC, this.mCurrentMnc);
        editor.apply();
        if (localLOGD) {
            Log.d(LOG_TAG, "save Locale: " + this.mCurrentLocale + ", mcc: " + this.mCurrentMcc + ", mnc: " + this.mCurrentMnc);
        }
    }

    private void loadLocaleAndSimConfigs() {
        SharedPreferences preferences = getSharedPreferences("launcher", 0);
        this.mCurrentLocale = preferences.getString("locale", null);
        this.mCurrentMcc = preferences.getInt(KEY_MCC, -1);
        this.mCurrentMnc = preferences.getInt(KEY_MNC, -1);
        if (localLOGD) {
            Log.d(LOG_TAG, "load Locale: " + this.mCurrentLocale + ", mcc: " + this.mCurrentMcc + ", mnc: " + this.mCurrentMnc);
        }
    }

    public void sendMsgDoneAllBinding() {
        if (localLOGD && localLOGD) {
            Log.d(LOG_TAG, "sendMsgFinishBindFxWidget " + this.mFinishLoading);
        }
        if (this.mHandler != null) {
            this.mHandler.sendMessage(this.mHandler.obtainMessage(MSG_FINISH_BIND_FXWIDGET));
        }
    }

    public void addDropTarget(DropTarget dropTarget) {
        if (this.mDragLayer != null) {
            this.mDragLayer.addDropTarget(dropTarget);
        }
    }

    public void removeDropTarget(DropTarget dropTarget) {
        Logger.d(LoggingEvents.EXTRA_CALLING_APP_NAME, "Launcher.removeDropTarget(" + dropTarget + ")");
        this.mDragLayer.removeDropTarget(dropTarget);
    }

    public void onTabEndSliding(String endTag) {
        this.lastTabTag = null;
        hideHandle(false);
        super.onTabEndSliding(endTag);
    }

    public void onTabStartSliding(String startTag) {
        super.onTabStartSliding(startTag);
        hideHandle(true);
        this.lastTabTag = startTag;
        enableAppsSearch(false, null);
    }

    private void hideHandle(boolean hide) {
        if (hide) {
            ViewGroup.LayoutParams lp = this.mHandleView.getLayoutParams();
            lp.height = 0;
            this.mHandleView.setLayoutParams(lp);
            View allappsView = this.mDrawer.findViewById(R.id.content_grid);
            ViewGroup.MarginLayoutParams mlp = (ViewGroup.MarginLayoutParams) allappsView.getLayoutParams();
            mlp.topMargin = ((ViewGroup) this.mHandleView).getChildAt(0).getBackground().getIntrinsicHeight();
            allappsView.setLayoutParams(mlp);
            this.mDrawer.findViewById(R.id.content_list).setPadding(0, ((ViewGroup) this.mHandleView).getChildAt(0).getBackground().getIntrinsicHeight(), 0, 0);
            return;
        }
        ViewGroup.LayoutParams lp2 = this.mHandleView.getLayoutParams();
        lp2.height = ((ViewGroup) this.mHandleView).getChildAt(0).getBackground().getIntrinsicHeight();
        this.mHandleView.setLayoutParams(lp2);
        View allappsView2 = this.mDrawer.findViewById(R.id.content_grid);
        ViewGroup.MarginLayoutParams mlp2 = (ViewGroup.MarginLayoutParams) allappsView2.getLayoutParams();
        mlp2.topMargin = 0;
        allappsView2.setLayoutParams(mlp2);
        this.mDrawer.findViewById(R.id.content_list).setPadding(0, 0, 0, 0);
    }

    public class RosieEditModeListener implements FxWorkspace.IEditModeListener {
        public RosieEditModeListener() {
        }

        @Override // com.htc.android.rosie.home.fxcontrol.FxWorkspace.IEditModeListener
        public void onPreEnterEditMode() {
        }

        @Override // com.htc.android.rosie.home.fxcontrol.FxWorkspace.IEditModeListener
        public void onPostEnterEditMode() {
        }

        @Override // com.htc.android.rosie.home.fxcontrol.FxWorkspace.IEditModeListener
        public void onPreLeaveEditMode() {
            Launcher.this.update2DButtonBarViews();
        }

        @Override // com.htc.android.rosie.home.fxcontrol.FxWorkspace.IEditModeListener
        public void onPostLeaveEditMode() {
            Launcher.this.mHandler.post(new Runnable() { // from class: com.htc.launcher.Launcher.RosieEditModeListener.1
                @Override // java.lang.Runnable
                public void run() {
                    if (Launcher.this.mWidgetTilter.isTilting()) {
                        if (Launcher.localLOGD) {
                            Logger.d(Launcher.LOG_TAG, "onPostLeaveEditMode widget is tilting");
                        }
                    } else if (Launcher.this.mWorkspace.isDoingScroll()) {
                        if (Launcher.localLOGD) {
                            Logger.d(Launcher.LOG_TAG, "onPostLeaveEditMode workspace is tilting");
                        }
                    } else {
                        Launcher.this.startCreateScenePreviewThread(false);
                        Launcher.this.update2DButtonBarViews();
                    }
                }
            });
        }
    }

    private class RootAsyncTask extends AsyncTask<Void, Void, Void> {
        private RootAsyncTask() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Void doInBackground(Void... Void) {
            return null;
        }
    }

    public int getOrientation() {
        return this.mCurrentOrientation;
    }

    public void resetForSinkFadeOut() {
        Logger.d(LOG_TAG, "[SCREEN_FADE] Launcher.resetForSinkFadeOut");
        this.mTiltListener.reset();
        this.mWidgetTilter.reset();
    }
}
