package com.htc.launcher.config;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class DeviceFlag {
    public static boolean isTabletDevice() {
        return false;
    }
}
