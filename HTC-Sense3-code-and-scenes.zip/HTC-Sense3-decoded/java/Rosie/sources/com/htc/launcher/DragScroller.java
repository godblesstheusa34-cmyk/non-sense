package com.htc.launcher;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public interface DragScroller {
    void scrollLeft();

    void scrollRight();
}
