package com.htc.launcher.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class FunctionBar extends View implements View.OnLongClickListener {
    private View.OnLongClickListener mOnLongClickListener;
    private View.OnTouchListener mOnTouchListener;

    public FunctionBar(Context context) {
        super(context);
        setOnLongClickListener(this);
    }

    public FunctionBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        setOnLongClickListener(this);
    }

    public FunctionBar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        setOnLongClickListener(this);
    }

    @Override // android.view.View
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (this.mOnTouchListener != null) {
            MotionEvent newEv = MotionEvent.obtain(event);
            newEv.setLocation(event.getX() + getLeft(), event.getY() + getTop());
            this.mOnTouchListener.onTouch(this, newEv);
        }
        return super.dispatchTouchEvent(event);
    }

    @Override // android.view.View
    public void setOnTouchListener(View.OnTouchListener touchListener) {
        this.mOnTouchListener = touchListener;
    }

    public void setOnLongClick(View.OnLongClickListener longClickListener) {
        this.mOnLongClickListener = longClickListener;
    }

    @Override // android.view.View.OnLongClickListener
    public boolean onLongClick(View arg0) {
        if (this.mOnLongClickListener != null) {
            this.mOnLongClickListener.onLongClick(arg0);
            return false;
        }
        return false;
    }
}
