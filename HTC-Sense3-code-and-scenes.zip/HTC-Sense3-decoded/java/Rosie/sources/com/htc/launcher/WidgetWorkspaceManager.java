package com.htc.launcher;

import android.app.IWallpaperManager;
import android.app.WallpaperInfo;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.FileUtils;
import android.os.IBinder;
import android.os.Process;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.util.Log;
import com.android.common.speech.LoggingEvents;
import com.htc.home.Scene;
import com.htc.launcher.Launcher;
import com.htc.launcher.LauncherSettings;
import com.htc.launcher.settings.SettingUtil;
import com.htc.utils.ulog.ReusableULogData;
import com.htc.utils.ulog.ULog;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class WidgetWorkspaceManager {
    public static final String ACTION_SCENE_MODIFIED = "com.htc.launcher.action.scene_modified";
    public static final String PREF_CURRENT_WORKSPACE = "CurrentWorkspace";
    private static final String TAG = "WidgetWorkspaceManager";
    private Context mAppContext;
    private WidgetWorkspace mCurrentWorkspace;
    private IWallpaperManager mWallpaperManager;
    private ArrayList<WidgetWorkspace> mWidgetWorkspaces;
    public static final Object sBitmapFactorySync = new Object();
    private static final boolean localLOGV = SettingUtil.localLOGD;
    private static WidgetWorkspaceManager sInstance = new WidgetWorkspaceManager();
    private static boolean initialized = false;
    private SceneObject mSceneObject = new SceneObject();
    private final boolean DEFAULT_LIVE_WALLPAPER = false;

    private class SceneObject implements Scene {
        private SceneObject() {
        }

        public String getDisplayName() {
            return WidgetWorkspaceManager.this.mCurrentWorkspace.displayName;
        }

        public int getId() {
            return WidgetWorkspaceManager.this.mCurrentWorkspace.id;
        }

        public int ordinal() {
            return WidgetWorkspaceManager.this.mWidgetWorkspaces.indexOf(WidgetWorkspaceManager.this.mCurrentWorkspace);
        }
    }

    private WidgetWorkspaceManager() {
    }

    public static synchronized WidgetWorkspaceManager instance() {
        WidgetWorkspaceManager instance;
        synchronized (WidgetWorkspaceManager.class) {
            instance = instance(null);
        }
        return instance;
    }

    public static synchronized WidgetWorkspaceManager instance(Context context) {
        WidgetWorkspaceManager widgetWorkspaceManager;
        synchronized (WidgetWorkspaceManager.class) {
            if (!initialized) {
                sInstance.mWidgetWorkspaces = new ArrayList<>();
                sInstance.mAppContext = context.getApplicationContext();
                sInstance.reset(context);
                initialized = true;
            }
            widgetWorkspaceManager = sInstance;
        }
        return widgetWorkspaceManager;
    }

    public void reset(Context context) {
        ContentResolver contentResolver = context.getContentResolver();
        Cursor c = contentResolver.query(LauncherSettings.WidgetWorkspace.CONTENT_URI, null, null, null, "created desc ");
        if (c == null) {
            Log.w(TAG, "WidgetWorkspaceManager cursor is null");
            return;
        }
        try {
            int idIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ID);
            int displayNameIndex = c.getColumnIndexOrThrow("display_name");
            int statusIndex = c.getColumnIndexOrThrow(LauncherSettings.WidgetWorkspace.STATUS);
            int ancestorIdIndex = c.getColumnIndexOrThrow(LauncherSettings.WidgetWorkspace.ANCESTOR_ID);
            int lockscreenWallpaperIdIndex = c.getColumnIndexOrThrow(LauncherSettings.WidgetWorkspace.LOCKSCREEN_WALLPAPER_NAME);
            int translateIndex = c.getColumnIndexOrThrow(LauncherSettings.WidgetWorkspace.TRANSLATE_ID);
            int wallpaperComponentIndex = c.getColumnIndex(LauncherSettings.WidgetWorkspace.WALLPAPER_COMPONENT);
            this.mWidgetWorkspaces.clear();
            while (c.moveToNext()) {
                WidgetWorkspace workspace = new WidgetWorkspace();
                workspace.id = c.getInt(idIndex);
                workspace.displayName = c.getString(displayNameIndex);
                workspace.status = c.getInt(statusIndex);
                workspace.ancestor_id = c.getInt(ancestorIdIndex);
                workspace.lockscreen_wallpaper_name = c.getString(lockscreenWallpaperIdIndex);
                workspace.translate_id = c.getInt(translateIndex);
                if (SettingUtil.isLiveWallaperSupported()) {
                    workspace.mWallpaperComponent = c.getString(wallpaperComponentIndex);
                }
                if (workspace.displayName.length() > 50) {
                    workspace.displayName = "get Mojibake from DB please check DB";
                    Logger.e(TAG, "workspace.displayName");
                }
                this.mWidgetWorkspaces.add(workspace);
            }
            addSuffixToDuplicatedSceneName(contentResolver);
            if (localLOGV) {
                Log.d(TAG, "Total workspace loaded : " + this.mWidgetWorkspaces.size());
            }
            SharedPreferences preferences = context.getSharedPreferences(WidgetPackageManager.REFERENCES, 0);
            int currentWorkspace = preferences.getInt(PREF_CURRENT_WORKSPACE, -1);
            if (currentWorkspace == -1) {
                setCurrentWorkspace(1);
            } else {
                setCurrentWorkspace(currentWorkspace);
            }
            Thread thread = new Thread("changeFirstLockscreenWallpaper") { // from class: com.htc.launcher.WidgetWorkspaceManager.1
                @Override // java.lang.Thread, java.lang.Runnable
                public void run() {
                    WidgetWorkspaceManager.this.copyLockscreenFile(WidgetWorkspaceManager.this.mCurrentWorkspace.getSystemPortraitLockscreenWallpaper(), "/data/misc/lockscreen/D_lock_screen_port");
                    Intent themeChangedIntent = new Intent("com.htc.launcher.lockscreen.WallpaperChanged");
                    WidgetWorkspaceManager.this.mAppContext.sendBroadcast(themeChangedIntent);
                    if (WidgetWorkspaceManager.localLOGV) {
                        Log.d(WidgetWorkspaceManager.TAG, "lockscreen wallpaper changed.");
                    }
                }
            };
            thread.start();
            IBinder b = ServiceManager.getService("wallpaper");
            this.mWallpaperManager = IWallpaperManager.Stub.asInterface(b);
        } finally {
            try {
                c.close();
            } catch (Exception ex) {
                if (localLOGV) {
                    Log.d(TAG, "WidgetWorkspaceManager.init DB close() failed - " + ex.getMessage());
                }
            }
        }
    }

    private void addSuffixToDuplicatedSceneName(ContentResolver contentResolver) {
        String firstSceneName = this.mWidgetWorkspaces.get(0).displayName;
        boolean isSceneNameDuplicated = false;
        int sceneSuffix = 1;
        for (int i = this.mWidgetWorkspaces.size() - 1; i > 0; i--) {
            if (this.mWidgetWorkspaces.get(i).displayName.contains(firstSceneName)) {
                isSceneNameDuplicated = true;
                if (this.mWidgetWorkspaces.get(i).displayName.length() > firstSceneName.length()) {
                    String suffix = this.mWidgetWorkspaces.get(i).displayName.substring(firstSceneName.length() + 1);
                    try {
                        sceneSuffix = Integer.parseInt(suffix);
                    } catch (Exception e) {
                        isSceneNameDuplicated = false;
                    }
                }
            }
        }
        if (isSceneNameDuplicated) {
            String newSceneName = firstSceneName + " " + (sceneSuffix + 1);
            this.mWidgetWorkspaces.get(0).displayName = newSceneName;
            ContentValues values = new ContentValues();
            values.put("display_name", this.mWidgetWorkspaces.get(0).displayName);
            contentResolver.update(LauncherSettings.WidgetWorkspace.getContentUri(this.mWidgetWorkspaces.get(0).id, false), values, null, null);
        }
    }

    public void initialCurrentWorkspace(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(WidgetPackageManager.REFERENCES, 0);
        int currentWorkspace = preferences.getInt(PREF_CURRENT_WORKSPACE, -1);
        if (currentWorkspace == -1) {
            setCurrentWorkspace(1);
        } else {
            setCurrentWorkspace(currentWorkspace);
        }
    }

    void refresh(Context context, ArrayList<WidgetWorkspace> widgetWorkspaces) {
        if (widgetWorkspaces != null) {
            ContentResolver contentResolver = this.mAppContext.getContentResolver();
            contentResolver.delete(LauncherSettings.WidgetWorkspace.CONTENT_URI, null, null);
            this.mWidgetWorkspaces = widgetWorkspaces;
            ArrayList<ContentValues> pendingInserts = new ArrayList<>();
            Iterator i$ = widgetWorkspaces.iterator();
            while (i$.hasNext()) {
                WidgetWorkspace widgetworkspace = i$.next();
                ContentValues values = new ContentValues();
                values.put(LauncherSettings.Favorites.ID, Integer.valueOf(widgetworkspace.id));
                values.put("display_name", widgetworkspace.displayName);
                values.put(LauncherSettings.WidgetWorkspace.CREATED, Long.valueOf(-System.currentTimeMillis()));
                values.put(LauncherSettings.WidgetWorkspace.STATUS, Integer.valueOf(widgetworkspace.status));
                values.put(LauncherSettings.WidgetWorkspace.ANCESTOR_ID, Integer.valueOf(widgetworkspace.ancestor_id));
                values.put(LauncherSettings.WidgetWorkspace.TRANSLATE_ID, Integer.valueOf(widgetworkspace.translate_id));
                values.put(LauncherSettings.WidgetWorkspace.LOCKSCREEN_WALLPAPER_NAME, widgetworkspace.lockscreen_wallpaper_name);
                if (localLOGV) {
                    Log.v(TAG, "refresh(), add " + widgetworkspace.displayName + " into DB, ANDCESTOR_ID = " + widgetworkspace.ancestor_id + ", TRANSLATE_ID = " + widgetworkspace.translate_id);
                }
                pendingInserts.add(values);
            }
            contentResolver.bulkInsert(LauncherSettings.WidgetWorkspace.CONTENT_URI, (ContentValues[]) pendingInserts.toArray(new ContentValues[0]));
            if (this.mCurrentWorkspace != null) {
                this.mCurrentWorkspace.id = -1;
            }
            changeLockscreenWallpaper();
        }
        translateDisplayName(context);
    }

    public boolean containDisplayName(String name) {
        Iterator i$ = this.mWidgetWorkspaces.iterator();
        while (i$.hasNext()) {
            WidgetWorkspace ws = i$.next();
            if (ws.displayName.equals(name)) {
                return true;
            }
        }
        return false;
    }

    public synchronized boolean isCurrentUnsaved() {
        return this.mCurrentWorkspace.status == 1;
    }

    public synchronized void onSceneModified() {
        if (Launcher.getScreen() == SettingUtil.getDefaultScreenIndex()) {
            SharedPreferences preferences = this.mAppContext.getSharedPreferences("launcher", 0);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean(Launcher.KEY_SCENE_PREVIEW_PORT_INVALIDATE, true);
            editor.putBoolean(Launcher.KEY_SCENE_PREVIEW_LAND_INVALIDATE, true);
            editor.apply();
        }
    }

    public void saveUnsavedWorkspace(String displayName) {
        Iterator i$ = this.mWidgetWorkspaces.iterator();
        while (i$.hasNext()) {
            WidgetWorkspace ws = i$.next();
            if (ws.status == 1) {
                ws.status = 0;
                ws.displayName = displayName;
                ContentResolver cr = this.mAppContext.getContentResolver();
                ContentValues values = new ContentValues();
                values.put(LauncherSettings.WidgetWorkspace.STATUS, Integer.valueOf(ws.status));
                values.put("display_name", ws.displayName);
                cr.update(LauncherSettings.WidgetWorkspace.getContentUri(ws.id, false), values, null, null);
                LauncherModel.duplicateAllItems(this.mAppContext, 0, ws.id);
                LauncherModel.adjustItemOrigId(this.mAppContext, ws.id);
                saveWallPaper(ws, values, cr);
            }
        }
    }

    public void saveWallPaper(WidgetWorkspace ws, ContentValues values, ContentResolver cr) {
        RemoteException ex;
        if (SettingUtil.isLiveWallaperSupported()) {
            try {
                WallpaperInfo info = this.mWallpaperManager.getWallpaperInfo();
                if (info == null) {
                    File srcFile = new File(WidgetWorkspace.getHomeWallpaper(this.mAppContext, -1));
                    File destFile = new File(ws.getHomeWallpaper(this.mAppContext));
                    FileUtils.copyFile(srcFile, destFile);
                } else if (info.getComponent() != null) {
                    ContentValues values2 = new ContentValues();
                    try {
                        ws.mWallpaperComponent = info.getComponent().flattenToString();
                        values2.put(LauncherSettings.WidgetWorkspace.WALLPAPER_COMPONENT, ws.mWallpaperComponent);
                        cr.update(LauncherSettings.WidgetWorkspace.getContentUri(ws.id, false), values2, null, null);
                    } catch (RemoteException e) {
                        ex = e;
                        Log.w(TAG, ex.getMessage(), ex);
                    }
                }
            } catch (RemoteException e2) {
                ex = e2;
            }
        } else {
            File srcFile2 = new File(WidgetWorkspace.getHomeWallpaper(this.mAppContext, -1));
            File destFile2 = new File(ws.getHomeWallpaper(this.mAppContext));
            FileUtils.copyFile(srcFile2, destFile2);
            copyLockscreenFile("/data/misc/lockscreen/lock_screen_port", ws.getPortraitLockscreenWallpaper());
            copyLockscreenFile("/data/misc/lockscreen/lock_screen_land", ws.getLandscapeLockscreenWallpaper());
        }
    }

    public int deleteUnsavedAndChangeScene(int nextWorkspaceId) {
        int nextBeskShotWorkspaceId = -1;
        Iterator i$ = this.mWidgetWorkspaces.iterator();
        while (true) {
            if (!i$.hasNext()) {
                break;
            }
            WidgetWorkspace ws = i$.next();
            if (ws.status == 1) {
                nextBeskShotWorkspaceId = removeWorkspace(ws);
                break;
            }
        }
        if (nextWorkspaceId < 0) {
            return nextBeskShotWorkspaceId;
        }
        Launcher launcher = Launcher.sRefLauncher.get();
        if (launcher != null) {
            launcher.setCurrentWorkspace(nextWorkspaceId, true);
        }
        return nextWorkspaceId;
    }

    public void translateDisplayName(Context context) {
        int translate_id;
        String[] names = context.getResources().getStringArray(R.array.default_workspace_names);
        ContentValues values = new ContentValues();
        Iterator i$ = this.mWidgetWorkspaces.iterator();
        while (i$.hasNext()) {
            WidgetWorkspace ws = i$.next();
            if (localLOGV) {
                Log.v(TAG, "status = " + ws.status + ", displayname = " + ws.displayName + ", translate_id = " + ws.translate_id);
            }
            if (ws.status == 2 && (translate_id = ws.translate_id) > 0 && translate_id <= names.length) {
                if (localLOGV) {
                    Log.v(TAG, "translate " + ws.displayName + " -> " + names[translate_id]);
                }
                ws.displayName = names[translate_id];
                values.put(LoggingEvents.EXTRA_CALLING_APP_NAME + ws.id, ws.displayName);
            }
        }
        if (values.size() > 0) {
            ContentResolver contentResolver = this.mAppContext.getContentResolver();
            contentResolver.update(LauncherSettings.getSpecialAction("_scene_name_locale_change"), values, null, null);
        }
    }

    public int findScene(String name) {
        Iterator i$ = this.mWidgetWorkspaces.iterator();
        while (i$.hasNext()) {
            WidgetWorkspace ws = i$.next();
            if (ws.displayName.equals(name)) {
                return ws.id;
            }
        }
        return -1;
    }

    public void setDisplayName(int workspaceId, String newName) {
        if (newName != null) {
            Iterator i$ = this.mWidgetWorkspaces.iterator();
            while (i$.hasNext()) {
                WidgetWorkspace ws = i$.next();
                if (ws.id == workspaceId && !newName.equals(ws.displayName)) {
                    ws.displayName = newName;
                    ContentResolver contentResolver = this.mAppContext.getContentResolver();
                    ContentValues values = new ContentValues();
                    values.put("display_name", ws.displayName);
                    contentResolver.update(LauncherSettings.WidgetWorkspace.getContentUri(ws.id, false), values, null, null);
                }
            }
        }
    }

    public boolean setWallpaperComponent(int workspaceId, String component) {
        if (component == null) {
            return false;
        }
        Iterator i$ = this.mWidgetWorkspaces.iterator();
        while (i$.hasNext()) {
            WidgetWorkspace ws = i$.next();
            if (ws.id == workspaceId && !component.equals(ws.mWallpaperComponent)) {
                ws.mWallpaperComponent = component;
                ContentResolver contentResolver = this.mAppContext.getContentResolver();
                ContentValues values = new ContentValues();
                values.put(LauncherSettings.WidgetWorkspace.WALLPAPER_COMPONENT, ws.mWallpaperComponent);
                contentResolver.update(LauncherSettings.WidgetWorkspace.getContentUri(ws.id, false), values, null, null);
                return true;
            }
        }
        return false;
    }

    public String getCurrentWallpaperComponent() {
        return this.mCurrentWorkspace.mWallpaperComponent;
    }

    public String getCurrentStaticWallpaperFileName() {
        int sceneId = getCurrentWorkspaceId();
        String staticWallpaperFileName = String.format("/data/data/com.htc.launcher/files/home_wallpaper_%d", Integer.valueOf(sceneId));
        return staticWallpaperFileName;
    }

    public String getCurrentLiveWallpaperFileName(String serviceName) {
        String liveWallpaperFormat = WidgetPackageManager.manipulateResourcePath("%s.png");
        String staticWallpaperFileName = String.format(liveWallpaperFormat, serviceName);
        return staticWallpaperFileName;
    }

    public int newWorkspace(String sceneName) {
        WidgetWorkspace workspace = new WidgetWorkspace();
        workspace.displayName = sceneName;
        workspace.ancestor_id = -1;
        workspace.translate_id = -1;
        workspace.lockscreen_wallpaper_name = this.mCurrentWorkspace.lockscreen_wallpaper_name;
        workspace.status = 0;
        if (SettingUtil.isLiveWallaperSupported()) {
            workspace.mWallpaperComponent = null;
        }
        addWorkspace(workspace);
        File src = new File(WidgetPackageManager.manipulateResourcePath("color.jpg"));
        File dest = new File("/data/data/com.htc.launcher/files/home_wallpaper_" + workspace.id);
        FileUtils.copyFile(src, dest);
        if (this.mCurrentWorkspace.id == workspace.id) {
            this.mCurrentWorkspace.id = -1;
        }
        return workspace.id;
    }

    private void addWorkspace(WidgetWorkspace ws) {
        ContentResolver contentResolver = this.mAppContext.getContentResolver();
        ContentValues values = new ContentValues();
        values.put("display_name", ws.displayName);
        values.put(LauncherSettings.WidgetWorkspace.CREATED, Long.valueOf(System.currentTimeMillis()));
        values.put(LauncherSettings.WidgetWorkspace.STATUS, Integer.valueOf(ws.status));
        values.put(LauncherSettings.WidgetWorkspace.ANCESTOR_ID, Integer.valueOf(ws.ancestor_id));
        values.put(LauncherSettings.WidgetWorkspace.TRANSLATE_ID, Integer.valueOf(ws.translate_id));
        values.put(LauncherSettings.WidgetWorkspace.LOCKSCREEN_WALLPAPER_NAME, ws.lockscreen_wallpaper_name);
        if (SettingUtil.isLiveWallaperSupported()) {
            values.put(LauncherSettings.WidgetWorkspace.WALLPAPER_COMPONENT, ws.mWallpaperComponent);
        }
        Uri result = contentResolver.insert(LauncherSettings.WidgetWorkspace.CONTENT_URI, values);
        if (result != null) {
            ws.id = Integer.parseInt(result.getPathSegments().get(1));
        }
        this.mWidgetWorkspaces.add(0, ws);
    }

    int removeWorkspace(WidgetWorkspace ws) {
        return removeWorkspace(ws, false);
    }

    public int removeWorkspace(WidgetWorkspace ws, boolean findBestShot) {
        this.mWidgetWorkspaces.remove(ws);
        ContentResolver contentResolver = this.mAppContext.getContentResolver();
        contentResolver.delete(LauncherSettings.WidgetWorkspace.getContentUri(ws.id, false), null, null);
        if (ws.status == 1) {
            ws.status = 3;
            Log.w(TAG, "removeWorkspace ws=000");
            contentResolver.delete(LauncherSettings.Favorites.CONTENT_URI_NO_NOTIFICATION, "workspace_id=0", null);
        } else {
            Log.w(TAG, "removeWorkspace ws=" + ws.id);
            contentResolver.delete(LauncherSettings.Favorites.CONTENT_URI_NO_NOTIFICATION, "workspace_id=" + ws.id, null);
        }
        new File(ws.getHomeWallpaper(this.mAppContext)).delete();
        new File(ws.getPortraitLockscreenWallpaper()).delete();
        new File(ws.getLandscapeLockscreenWallpaper()).delete();
        if (ws.id == this.mCurrentWorkspace.id || findBestShot) {
            new File("/data/misc/lockscreen/lock_screen_port").delete();
            new File("/data/misc/lockscreen/lock_screen_land").delete();
            if (this.mWidgetWorkspaces.size() > 0) {
                return this.mWidgetWorkspaces.get(0).id;
            }
            return -1;
        }
        return this.mCurrentWorkspace.id;
    }

    public int getCurrentWorkspaceId() {
        if (this.mCurrentWorkspace != null) {
            return this.mCurrentWorkspace.id;
        }
        return -1;
    }

    public String getCurrentWorkspaceName() {
        if (this.mCurrentWorkspace != null) {
            return this.mCurrentWorkspace.displayName;
        }
        return null;
    }

    public WidgetWorkspace getWidgetWorkspace(int id) {
        Iterator i$ = this.mWidgetWorkspaces.iterator();
        while (i$.hasNext()) {
            WidgetWorkspace ws = i$.next();
            if (ws.id == id) {
                return ws;
            }
        }
        return null;
    }

    public WidgetWorkspace getWidgetWorkspace(String displayName, boolean ignoreCase) {
        Iterator i$ = this.mWidgetWorkspaces.iterator();
        while (i$.hasNext()) {
            WidgetWorkspace ws = i$.next();
            if (ignoreCase) {
                if (ws.displayName.equalsIgnoreCase(displayName)) {
                    return ws;
                }
            } else if (ws.displayName.equals(displayName)) {
                return ws;
            }
        }
        return null;
    }

    public boolean setCurrentWorkspace(int workspaceId) {
        String output;
        if (this.mCurrentWorkspace != null && this.mCurrentWorkspace.id == workspaceId) {
            return false;
        }
        if (localLOGV) {
            Log.d(TAG, "setCurrentWorkspace : " + workspaceId);
        }
        Iterator i$ = this.mWidgetWorkspaces.iterator();
        while (true) {
            if (!i$.hasNext()) {
                break;
            }
            WidgetWorkspace workspace = i$.next();
            if (workspace.id == workspaceId) {
                this.mCurrentWorkspace = workspace;
                break;
            }
        }
        if (this.mCurrentWorkspace == null) {
            if (this.mWidgetWorkspaces.size() == 0) {
                Log.w("Rosie", "setCurrentWorkspace abnormal: mWidgetWorkspaces is empty");
                this.mWidgetWorkspaces.add(new WidgetWorkspace());
            }
            this.mCurrentWorkspace = this.mWidgetWorkspaces.get(0);
        }
        ReusableULogData uLogData = ReusableULogData.obtain();
        uLogData.setAppId("com.htc.launcher").setCategory("scene");
        Context context = (Context) Launcher.sRefLauncher.get();
        if (context == null) {
            context = this.mAppContext;
        }
        String[] names = context.getResources().getStringArray(R.array.original_workspace_names);
        int translate_id = this.mCurrentWorkspace.translate_id;
        if (translate_id > 0 && translate_id <= names.length) {
            output = names[translate_id];
        } else {
            output = this.mCurrentWorkspace.displayName;
        }
        uLogData.addData("scene_ID", this.mCurrentWorkspace.displayName);
        if (localLOGV) {
            Log.d(TAG, "HTC user profiling     SceneID     " + output);
        }
        ULog.log(uLogData);
        uLogData.recycle();
        if (localLOGV) {
            Log.d(TAG, "Broadcast new scene name. ==> " + this.mCurrentWorkspace.displayName);
        }
        Intent intent = new Intent("com.htc.intent.ACTION_PERSONALIZE_SCENE_CHANGED");
        intent.putExtra("com.htc.intent.EXTRA_SUMMARY", this.mCurrentWorkspace.displayName);
        this.mAppContext.sendBroadcast(intent);
        final SharedPreferences preferences = this.mAppContext.getSharedPreferences(WidgetPackageManager.REFERENCES, 0);
        Thread thread = new Thread(new Runnable() { // from class: com.htc.launcher.WidgetWorkspaceManager.2
            @Override // java.lang.Runnable
            public void run() {
                Process.setThreadPriority(19);
                SharedPreferences.Editor editor = preferences.edit();
                if (editor == null) {
                    if (WidgetWorkspaceManager.localLOGV) {
                        Log.d(WidgetWorkspaceManager.TAG, "editor is null (366).");
                    }
                } else {
                    editor.putInt(WidgetWorkspaceManager.PREF_CURRENT_WORKSPACE, WidgetWorkspaceManager.this.mCurrentWorkspace.id);
                    editor.apply();
                }
            }
        });
        thread.start();
        return true;
    }

    public WidgetWorkspace[] listWorkspace() {
        if (this.mWidgetWorkspaces == null) {
            return new WidgetWorkspace[0];
        }
        if (!isCurrentUnsaved()) {
            if (SettingUtil.isLiveWallaperSupported()) {
                try {
                    WallpaperInfo info = this.mWallpaperManager.getWallpaperInfo();
                    if (localLOGV) {
                        Log.d(TAG, "wallpaper info : " + info);
                    }
                    if ((!this.mCurrentWorkspace.isLiveWallpaper() || info == null || info.getComponent() == null || !this.mCurrentWorkspace.mWallpaperComponent.equals(info.getComponent().flattenToString())) && (this.mCurrentWorkspace.isLiveWallpaper() || info != null)) {
                        onSceneModified();
                    }
                } catch (RemoteException ex) {
                    Log.w(TAG, ex.getMessage(), ex);
                }
            } else if (!fileEqual("/data/misc/lockscreen/lock_screen_port", this.mCurrentWorkspace.getPortraitLockscreenWallpaper()) || !fileEqual("/data/misc/lockscreen/lock_screen_land", this.mCurrentWorkspace.getLandscapeLockscreenWallpaper())) {
                onSceneModified();
            }
        }
        return (WidgetWorkspace[]) this.mWidgetWorkspaces.toArray(new WidgetWorkspace[0]);
    }

    private static boolean fileEqual(String src, String dest) {
        File srcFile = new File(src);
        File destFile = new File(dest);
        return srcFile.lastModified() == destFile.lastModified();
    }

    public void saveHomeWallpaper(final Bitmap bitmap, final Launcher.SaveWallpaperCompleteListener listener) {
        Thread thread = new Thread("saveHomeWallpaper") { // from class: com.htc.launcher.WidgetWorkspaceManager.3
            @Override // java.lang.Thread, java.lang.Runnable
            public void run() {
                if (SettingUtil.isLiveWallaperSupported()) {
                    WidgetWorkspaceManager.this.setWallpaperComponent(WidgetWorkspaceManager.this.mCurrentWorkspace.id, LoggingEvents.EXTRA_CALLING_APP_NAME);
                }
                WidgetWorkspaceManager.this.writeBitmap(bitmap, WidgetWorkspace.getHomeWallpaper(WidgetWorkspaceManager.this.mAppContext, -1) + "temp");
                WidgetWorkspaceManager.this.writeBitmap(bitmap, WidgetWorkspace.getHomeWallpaper(WidgetWorkspaceManager.this.mAppContext, WidgetWorkspaceManager.this.getCurrentWorkspaceId()) + "temp");
                File defaultWallpaper = new File(WidgetWorkspace.getHomeWallpaper(WidgetWorkspaceManager.this.mAppContext, -1));
                File defaultWallpaperTemp = new File(WidgetWorkspace.getHomeWallpaper(WidgetWorkspaceManager.this.mAppContext, -1) + "temp");
                if (defaultWallpaper.exists()) {
                    defaultWallpaper.delete();
                }
                defaultWallpaperTemp.renameTo(defaultWallpaper);
                File sceneWallpaper = new File(WidgetWorkspace.getHomeWallpaper(WidgetWorkspaceManager.this.mAppContext, WidgetWorkspaceManager.this.getCurrentWorkspaceId()));
                File sceneWallpaperTemp = new File(WidgetWorkspace.getHomeWallpaper(WidgetWorkspaceManager.this.mAppContext, WidgetWorkspaceManager.this.getCurrentWorkspaceId()) + "temp");
                if (sceneWallpaper.exists()) {
                    sceneWallpaper.delete();
                }
                sceneWallpaperTemp.renameTo(sceneWallpaper);
                WidgetWorkspaceManager.this.onSceneModified();
                listener.onSaveWallpaperCompleted();
                bitmap.recycle();
            }
        };
        thread.start();
    }

    public void loadHomeWallpaper(final Launcher launcher) {
        Thread thread = new Thread("loadHomeWallpaper") { // from class: com.htc.launcher.WidgetWorkspaceManager.4
            @Override // java.lang.Thread, java.lang.Runnable
            public void run() {
                WidgetWorkspaceManager wm = WidgetWorkspaceManager.instance();
                int workspaceId = wm.getCurrentWorkspaceId();
                WidgetWorkspace workspace = wm.getWidgetWorkspace(workspaceId);
                if (workspace != null && workspace.isLiveWallpaper()) {
                    Intent intent = new Intent("com.htc.rosie.ACTION_SET_WALLPAPER_COMPONENT");
                    intent.putExtra(LauncherSettings.WidgetWorkspace.WALLPAPER_COMPONENT, workspace.mWallpaperComponent);
                    launcher.sendBroadcast(intent);
                    return;
                }
                try {
                    FileInputStream is = new FileInputStream(WidgetWorkspace.getHomeWallpaper(WidgetWorkspaceManager.this.mAppContext, -1));
                    launcher.mSettingWallpaper++;
                    android.app.WallpaperManager.getInstance(launcher).setStream(is);
                } catch (IOException e) {
                    Log.e(WidgetWorkspaceManager.TAG, "WidgetWorkspaceManager.loadHomeWallpaper", e);
                }
            }
        };
        thread.start();
    }

    public void changeHomeWallpaper(final Launcher launcher) {
        Thread thread = new Thread("changeHomeWallpaper") { // from class: com.htc.launcher.WidgetWorkspaceManager.5
            @Override // java.lang.Thread, java.lang.Runnable
            public void run() {
                File destFile = new File(WidgetWorkspace.getHomeWallpaper(launcher, -1));
                destFile.delete();
                if (!SettingUtil.isLiveWallaperSupported() || !WidgetWorkspaceManager.this.mCurrentWorkspace.isLiveWallpaper()) {
                    File srcFile = new File(WidgetWorkspaceManager.this.mCurrentWorkspace.getHomeWallpaper(launcher));
                    FileUtils.copyFile(srcFile, destFile);
                }
            }
        };
        thread.start();
    }

    public void changeLockscreenWallpaper() {
        Thread thread = new Thread("changeLockscreenWallpaper") { // from class: com.htc.launcher.WidgetWorkspaceManager.6
            @Override // java.lang.Thread, java.lang.Runnable
            public void run() {
                File destPortFile = new File("/data/misc/lockscreen/lock_screen_port");
                destPortFile.delete();
                File destLandFile = new File("/data/misc/lockscreen/lock_screen_land");
                destLandFile.delete();
                WidgetWorkspaceManager.this.copyLockscreenFile(WidgetWorkspaceManager.this.mCurrentWorkspace.getPortraitLockscreenWallpaper(), "/data/misc/lockscreen/lock_screen_port");
                WidgetWorkspaceManager.this.copyLockscreenFile(WidgetWorkspaceManager.this.mCurrentWorkspace.getLandscapeLockscreenWallpaper(), "/data/misc/lockscreen/lock_screen_land");
                WidgetWorkspaceManager.this.copyLockscreenFile(WidgetWorkspaceManager.this.mCurrentWorkspace.getSystemPortraitLockscreenWallpaper(), "/data/misc/lockscreen/D_lock_screen_port");
                Intent themeChangedIntent = new Intent("com.htc.launcher.lockscreen.WallpaperChanged");
                WidgetWorkspaceManager.this.mAppContext.sendBroadcast(themeChangedIntent);
                if (WidgetWorkspaceManager.localLOGV) {
                    Log.d(WidgetWorkspaceManager.TAG, "lockscreen wallpaper changed.");
                }
            }
        };
        thread.start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void copyLockscreenFile(String src, String dest) {
    }

    private Bitmap loadBitmap(String filename) {
        Bitmap decodeFile;
        if (filename == null) {
            return null;
        }
        if (localLOGV) {
            Log.d(TAG, "loading bitmap : " + filename);
        }
        File file = new File(filename);
        if (!file.exists()) {
            return null;
        }
        synchronized (sBitmapFactorySync) {
            decodeFile = BitmapFactory.decodeFile(filename);
        }
        return decodeFile;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void writeBitmap(Bitmap bitmap, String filename) {
        if (bitmap != null) {
            try {
                if (localLOGV) {
                    Log.d(TAG, "saving bitmap : " + filename);
                }
                FileOutputStream out = new FileOutputStream(filename);
                synchronized (sBitmapFactorySync) {
                    boolean success = bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
                    if (localLOGV) {
                        Log.d(TAG, "saved bitmap : " + success);
                    }
                }
                out.flush();
                out.close();
            } catch (IOException e) {
                Log.w(TAG, "Could not save bitmap : " + filename);
            }
        }
    }

    public int size() {
        if (this.mWidgetWorkspaces == null) {
            return 0;
        }
        return this.mWidgetWorkspaces.size();
    }

    public Scene getCurrentScene() {
        return this.mSceneObject;
    }
}
