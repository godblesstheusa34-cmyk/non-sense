package com.htc.launcher;

import android.content.Context;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class WidgetPackage {
    private WidgetLayoutInfalter mLayoutInflater;
    public Context mPackageContext;

    public WidgetLayoutInfalter getLayoutInflater() {
        if (this.mLayoutInflater == null) {
            this.mLayoutInflater = new WidgetLayoutInfalter(this.mPackageContext);
        }
        return this.mLayoutInflater;
    }
}
