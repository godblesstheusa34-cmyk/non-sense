package com.htc.launcher.widget;

import android.content.Context;
import android.view.ViewConfiguration;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class HtcScroller {
    private static final int DEFAULT_DURATION = 250;
    private static final int FLING_MODE = 1;
    private static final int SCROLL_MODE = 0;
    private boolean mAborted;
    private float mCoeffX;
    private float mCoeffY;
    private int mCurrX;
    private float mCurrXHp;
    private int mCurrY;
    private float mCurrYHp;
    private final float mDeceleration;
    private float mDeltaX;
    private float mDeltaY;
    private int mDuration;
    private float mDurationReciprocal;
    private EasingFunction mEasingFunction;
    private int mFinalX;
    private int mFinalY;
    private boolean mFinished;
    private Interpolator mInterpolator;
    private int mMaxX;
    private int mMaxY;
    private int mMinX;
    private int mMinY;
    private int mMode;
    private long mStartTime;
    private int mStartX;
    private int mStartY;
    private float mVelocity;
    private float mViscousFluidNormalize;
    private float mViscousFluidScale;

    public HtcScroller(Context context) {
        this(context, null);
    }

    public HtcScroller(Context context, Interpolator interpolator) {
        this.mCoeffX = 0.0f;
        this.mCoeffY = 1.0f;
        this.mFinished = true;
        this.mInterpolator = interpolator;
        float ppi = context.getResources().getDisplayMetrics().density * 160.0f;
        this.mDeceleration = 385.826f * ppi * ViewConfiguration.getScrollFriction();
    }

    public final boolean isFinished() {
        return this.mFinished;
    }

    public final void forceFinished(boolean finished) {
        this.mFinished = finished;
    }

    public final int getDuration() {
        return this.mDuration;
    }

    public final int getCurrX() {
        return this.mCurrX;
    }

    public final int getCurrY() {
        return this.mCurrY;
    }

    public final float getHighPrecisionCurrX() {
        return this.mCurrXHp;
    }

    public final float getHighPrecisionCurrY() {
        return this.mCurrYHp;
    }

    public final int getStartX() {
        return this.mStartX;
    }

    public final int getStartY() {
        return this.mStartY;
    }

    public final int getFinalX() {
        return this.mFinalX;
    }

    public final int getFinalY() {
        return this.mFinalY;
    }

    public final float getScrollingProgress() {
        if (this.mDeltaX == 0.0f) {
            return 0.0f;
        }
        return (this.mCurrX - this.mStartX) / this.mDeltaX;
    }

    public boolean computeScrollOffset() {
        float x;
        if (this.mFinished) {
            return false;
        }
        int timePassed = (int) (AnimationUtils.currentAnimationTimeMillis() - this.mStartTime);
        if (timePassed < this.mDuration) {
            switch (this.mMode) {
                case 0:
                    float x2 = timePassed * this.mDurationReciprocal;
                    if (this.mEasingFunction != null) {
                        this.mCurrXHp = this.mEasingFunction.currentResult(0.0f, timePassed, this.mStartX, this.mDeltaX, this.mDuration);
                        this.mCurrYHp = this.mEasingFunction.currentResult(0.0f, timePassed, this.mStartY, this.mDeltaY, this.mDuration);
                        this.mCurrX = Math.round(this.mCurrXHp);
                        this.mCurrY = Math.round(this.mCurrYHp);
                        break;
                    } else {
                        if (this.mInterpolator == null) {
                            x = viscousFluid(x2);
                        } else {
                            x = this.mInterpolator.getInterpolation(x2);
                        }
                        this.mCurrX = this.mStartX + Math.round(this.mDeltaX * x);
                        this.mCurrY = this.mStartY + Math.round(this.mDeltaY * x);
                        if (this.mCurrX == this.mFinalX && this.mCurrY == this.mFinalY) {
                            this.mFinished = true;
                            break;
                        }
                    }
                    break;
                case 1:
                    float timePassedSeconds = timePassed / 1000.0f;
                    float distance = (this.mVelocity * timePassedSeconds) - (((this.mDeceleration * timePassedSeconds) * timePassedSeconds) / 2.0f);
                    this.mCurrX = this.mStartX + Math.round(this.mCoeffX * distance);
                    this.mCurrX = Math.min(this.mCurrX, this.mMaxX);
                    this.mCurrX = Math.max(this.mCurrX, this.mMinX);
                    this.mCurrY = this.mStartY + Math.round(this.mCoeffY * distance);
                    this.mCurrY = Math.min(this.mCurrY, this.mMaxY);
                    this.mCurrY = Math.max(this.mCurrY, this.mMinY);
                    if (this.mCurrX == this.mFinalX && this.mCurrY == this.mFinalY) {
                        this.mFinished = true;
                        break;
                    }
                    break;
            }
        } else {
            this.mCurrX = this.mFinalX;
            this.mCurrY = this.mFinalY;
            this.mFinished = true;
        }
        return true;
    }

    public void startScroll(int startX, int startY, int dx, int dy) {
        startScroll(startX, startY, dx, dy, DEFAULT_DURATION);
    }

    public void startScroll(int startX, int startY, int dx, int dy, int duration) {
        this.mMode = 0;
        this.mAborted = false;
        this.mFinished = false;
        this.mDuration = duration;
        this.mStartTime = AnimationUtils.currentAnimationTimeMillis();
        this.mStartX = startX;
        this.mStartY = startY;
        this.mFinalX = startX + dx;
        this.mFinalY = startY + dy;
        this.mDeltaX = dx;
        this.mDeltaY = dy;
        this.mDurationReciprocal = 1.0f / this.mDuration;
        this.mViscousFluidScale = 8.0f;
        this.mViscousFluidNormalize = 1.0f;
        this.mViscousFluidNormalize = 1.0f / viscousFluid(1.0f);
        this.mEasingFunction = null;
    }

    public void startScroll(int startX, int startY, int dx, int dy, int duration, EasingFunction function) {
        this.mMode = 0;
        this.mEasingFunction = function;
        this.mAborted = false;
        this.mFinished = false;
        this.mDuration = duration;
        this.mStartTime = AnimationUtils.currentAnimationTimeMillis();
        this.mStartX = startX;
        this.mStartY = startY;
        this.mFinalX = startX + dx;
        this.mFinalY = startY + dy;
        this.mDeltaX = dx;
        this.mDeltaY = dy;
        this.mDurationReciprocal = 1.0f / this.mDuration;
        this.mViscousFluidScale = 8.0f;
        this.mViscousFluidNormalize = 1.0f;
        this.mViscousFluidNormalize = 1.0f / viscousFluid(1.0f);
    }

    public void fling(int startX, int startY, int velocityX, int velocityY, int minX, int maxX, int minY, int maxY) {
        this.mMode = 1;
        this.mFinished = false;
        float velocity = (float) Math.hypot(velocityX, velocityY);
        this.mVelocity = velocity;
        this.mDuration = (int) ((1000.0f * velocity) / this.mDeceleration);
        this.mStartTime = AnimationUtils.currentAnimationTimeMillis();
        this.mStartX = startX;
        this.mStartY = startY;
        this.mCoeffX = velocity == 0.0f ? 1.0f : velocityX / velocity;
        this.mCoeffY = velocity == 0.0f ? 1.0f : velocityY / velocity;
        int totalDistance = (int) ((velocity * velocity) / (2.0f * this.mDeceleration));
        this.mMinX = minX;
        this.mMaxX = maxX;
        this.mMinY = minY;
        this.mMaxY = maxY;
        this.mFinalX = Math.round(totalDistance * this.mCoeffX) + startX;
        this.mFinalX = Math.min(this.mFinalX, this.mMaxX);
        this.mFinalX = Math.max(this.mFinalX, this.mMinX);
        this.mFinalY = Math.round(totalDistance * this.mCoeffY) + startY;
        this.mFinalY = Math.min(this.mFinalY, this.mMaxY);
        this.mFinalY = Math.max(this.mFinalY, this.mMinY);
        this.mEasingFunction = null;
    }

    private float viscousFluid(float x) {
        float x2;
        float x3 = x * this.mViscousFluidScale;
        if (x3 < 1.0f) {
            x2 = x3 - (1.0f - ((float) Math.exp(-x3)));
        } else {
            x2 = 0.36787945f + ((1.0f - 0.36787945f) * (1.0f - ((float) Math.exp(1.0f - x3))));
        }
        return x2 * this.mViscousFluidNormalize;
    }

    public void abortAnimation() {
        this.mCurrX = this.mFinalX;
        this.mCurrY = this.mFinalY;
        this.mFinished = true;
        this.mAborted = true;
    }

    public void extendDuration(int extend) {
        int passed = timePassed();
        this.mDuration = passed + extend;
        this.mDurationReciprocal = 1.0f / this.mDuration;
        this.mFinished = false;
    }

    public int timePassed() {
        return (int) (AnimationUtils.currentAnimationTimeMillis() - this.mStartTime);
    }

    public void setFinalX(int newX) {
        this.mFinalX = newX;
        this.mDeltaX = this.mFinalX - this.mStartX;
        this.mFinished = false;
    }

    public void setFinalY(int newY) {
        this.mFinalY = newY;
        this.mDeltaY = this.mFinalY - this.mStartY;
        this.mFinished = false;
    }

    public boolean isAborted() {
        return this.mAborted;
    }
}
