package com.htc.launcher;

import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.ViewGroup;
import com.android.common.speech.LoggingEvents;
import com.htc.android.rosie.home.fxcontrol.FxShortcutButton;
import com.htc.launcher.LauncherSettings;
import com.htc.launcher.settings.SettingUtil;
import java.lang.ref.WeakReference;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class FxShortcutInfo extends ItemInfo {
    boolean customIcon;
    String customizeAppId;
    boolean filtered;
    public Drawable icon;
    Intent.ShortcutIconResource iconResource;
    public Intent intent;
    public boolean isDownloaded;
    public long lastModifiedTime;
    public int launchCount;
    private WeakReference<Observer> mObserver;
    public String packageName;
    public int priority;
    public CharSequence title;

    public interface Observer {
        void onIconUpdate(int i, Drawable drawable, CharSequence charSequence);
    }

    public FxShortcutInfo() {
        this.priority = 200;
        this.lastModifiedTime = 0L;
        this.isDownloaded = false;
        this.launchCount = 0;
        this.packageName = LoggingEvents.EXTRA_CALLING_APP_NAME;
        this.customizeAppId = LoggingEvents.EXTRA_CALLING_APP_NAME;
        this.itemType = 1;
    }

    public FxShortcutInfo(FxShortcutInfo info) {
        super(info);
        this.priority = 200;
        this.lastModifiedTime = 0L;
        this.isDownloaded = false;
        this.launchCount = 0;
        this.packageName = LoggingEvents.EXTRA_CALLING_APP_NAME;
        this.customizeAppId = LoggingEvents.EXTRA_CALLING_APP_NAME;
        this.title = info.title.toString();
        this.intent = new Intent(info.intent);
        if (info.iconResource != null) {
            this.iconResource = new Intent.ShortcutIconResource();
            this.iconResource.packageName = info.iconResource.packageName;
            this.iconResource.resourceName = info.iconResource.resourceName;
        }
        this.icon = info.icon;
        this.filtered = info.filtered;
        this.customIcon = info.customIcon;
    }

    final void setActivity(ComponentName className, int launchFlags) {
        this.intent = new Intent("android.intent.action.MAIN");
        this.intent.addCategory("android.intent.category.LAUNCHER");
        this.intent.setComponent(className);
        this.intent.setFlags(launchFlags);
        this.itemType = 0;
    }

    @Override // com.htc.launcher.ItemInfo
    void onAddToDatabase(ContentValues values) {
        super.onAddToDatabase(values);
        String titleStr = this.title != null ? this.title.toString() : null;
        values.put("title", titleStr);
        String uri = this.intent != null ? this.intent.toUri(0) : null;
        values.put("intent", uri);
        if (this.customIcon) {
            values.put(LauncherSettings.Favorites.ICON_TYPE, (Integer) 1);
            Bitmap bitmap = ((FastBitmapDrawable) this.icon).getBitmap();
            Rect dst = ((FastBitmapDrawable) this.icon).getDstRect();
            if (dst != null && SettingUtil.isTabletDevice()) {
                int utilWidthHeight = Utilities.getIconWidthHeight();
                Log.d("ApplicationInfo", "onAddToDatabase customerIcon width" + bitmap.getWidth() + ", Utilities.getIconWidthHeight: " + utilWidthHeight);
                writeBitmap(values, Bitmap.createScaledBitmap(bitmap, utilWidthHeight, utilWidthHeight, true));
                return;
            }
            writeBitmap(values, bitmap);
            return;
        }
        values.put(LauncherSettings.Favorites.ICON_TYPE, (Integer) 0);
        if (this.iconResource == null) {
            if (this.intent != null && this.intent.getComponent() != null) {
                values.put(LauncherSettings.Favorites.ICON_PACKAGE, this.intent.getComponent().getPackageName());
                if (this.iconname != null) {
                    values.put(LauncherSettings.Favorites.ICON_RESOURCE, this.iconname);
                    return;
                }
                return;
            }
            return;
        }
        values.put(LauncherSettings.Favorites.ICON_PACKAGE, this.iconResource.packageName);
        values.put(LauncherSettings.Favorites.ICON_RESOURCE, this.iconResource.resourceName);
    }

    @Override // com.htc.launcher.ItemInfo
    public String toString() {
        return ((Object) this.title) + " " + super.toString();
    }

    public String toDebugString() {
        return ((Object) this.title) + " [" + this.packageName + " / " + this.customizeAppId + "] (" + this.launchCount + ")";
    }

    public void setObserver(Observer observer) {
        this.mObserver = new WeakReference<>(observer);
    }

    public void notifyIconUpdate() {
        Observer observer;
        Logger.d(LoggingEvents.EXTRA_CALLING_APP_NAME, "ITEM - NotifyUpdate:" + this);
        if (this.mObserver != null && (observer = this.mObserver.get()) != null) {
            observer.onIconUpdate((int) this.id, this.icon, this.title);
        }
    }

    @Override // com.htc.launcher.ItemInfo
    public String getUlog() {
        String appTitle = "none";
        if (this.title != null) {
            appTitle = this.title.toString();
        }
        String ret = appTitle + ", shortcut, " + this.screen + ", " + this.cellX + ", " + this.cellY + ", " + this.spanX + ", " + this.spanY;
        return ret;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // com.htc.launcher.ItemInfo
    public Draggee createItem(Launcher launcher, ViewGroup container) {
        this.title = AllAppsGridView.translateAppTitle((String) this.title, launcher);
        FxShortcutButton favorite = new FxShortcutButton(this, launcher.getOrientation());
        if (!this.filtered) {
            if (this.icon != null) {
                this.icon = Utilities.createIconThumbnail(this.icon, launcher);
            }
            this.filtered = true;
        }
        favorite.setContents(this.icon, this.title);
        favorite.setOnClickListener(launcher.getDesktopItemController().mOnClickShortcutListener);
        return favorite;
    }

    @Override // com.htc.launcher.ItemInfo
    public boolean isItemEditable() {
        return false;
    }

    @Override // com.htc.launcher.ItemInfo
    public long getId() {
        return this.id;
    }
}
