package com.htc.launcher;

import android.app.Activity;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class RestrictLauncher extends Activity {
}
