package com.htc.launcher;

import android.content.Context;
import android.os.Debug;
import android.util.Log;
import com.android.common.speech.LoggingEvents;
import com.htc.launcher.settings.SettingUtil;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class ScrollMonitor {
    public static final boolean MONITOR_LOGS = true;
    private static final String SCROLL_BEGIN = "[ScrollKPI]";
    private static final String TRACE_PATH = "/sdcard/rosie_scroll";
    private long mBeginScrollTime;
    private Context mContext;
    private int mCurrentPage;
    private int mDeltaX;
    private long mDrawingWorkspaceThreadTime;
    private long mDrawingWorkspaceTime;
    private long mLastDrawingThreadTime;
    private long mLastDrawingTime;
    private int mLastScrollX;
    private FileOutputStream mPointsOutput;
    private Recorder mRecorder;
    private FileOutputStream mScrollLogOutput;
    private boolean mScrollMonitor;
    private long mStartDrawingThreadTime;
    private long mStartDrawingTime;
    private long mStartDrawingWorkspace;
    private long mStartDrawingWorkspaceThreadTime;
    public static boolean localLOGV = true;
    private static boolean isUseTraceView = false;
    public static boolean ENABLE_LOOP_LOG = false;
    private boolean isMonitoring = false;
    private boolean mIsFirstDraw = false;
    private boolean mIsTouchDraw = false;
    private boolean mHasErrorPattern = false;
    private boolean mHasWarnPattern = false;
    private boolean mHasVerbosePattern = false;
    private int mLastMotionX = ApplicationManager.ALL_PROGRAM_LIST_HIGHEST_PRIORITY;

    public ScrollMonitor(Context context) {
        this.mScrollMonitor = false;
        this.mContext = context;
        File file = new File("/data/data/", "ScrollMonitor");
        if (file.exists()) {
            this.mScrollMonitor = true;
            if (localLOGV) {
                Log.d(SCROLL_BEGIN, "enable ScrollMonitor");
            }
            File file2 = new File(TRACE_PATH);
            if (!file2.exists()) {
                file2.mkdirs();
            }
        }
        File file3 = new File("/data/data/", "TraceView");
        if (file3.exists()) {
            isUseTraceView = true;
            if (localLOGV) {
                Log.d(SCROLL_BEGIN, "enable traceView");
            }
        }
        File file4 = new File("/data/data", "PointerTracker");
        if (file4.exists()) {
            SettingUtil.sIsEnablePointerLocation = true;
            if (localLOGV) {
                Log.d(SCROLL_BEGIN, "enable PointerTracker");
            }
        }
    }

    public void startOfBeginScroll() {
        this.isMonitoring = true;
        this.mIsFirstDraw = true;
        this.mHasErrorPattern = false;
        this.mHasWarnPattern = false;
        this.mHasVerbosePattern = false;
        if (this.mScrollMonitor) {
            long currentTime = System.currentTimeMillis();
            try {
                this.mScrollLogOutput = this.mContext.openFileOutput("scroll_performance.txt", 32768);
                File points = new File(TRACE_PATH, "points" + currentTime + ".txt");
                this.mPointsOutput = new FileOutputStream(points);
            } catch (FileNotFoundException e) {
                Log.e(SCROLL_BEGIN, "SD card not ready, check if sdcard is inserted and mounted. Check sd card is full or not.");
                this.mPointsOutput = null;
            }
            if (isUseTraceView) {
                try {
                    Debug.startMethodTracing("/sdcard/rosie_scroll/rosie_scroll_" + currentTime + ".trace");
                } catch (RuntimeException e2) {
                    Log.e(SCROLL_BEGIN, "SD card not ready, check if sdcard is inserted and mounted. Check sd card is full or not.");
                }
            }
            long currentTime2 = System.currentTimeMillis();
            long currentThreadTime = Debug.threadCpuTimeNanos() / 1000000;
            this.mRecorder = new Recorder();
            this.mBeginScrollTime = currentTime2;
            this.mLastDrawingTime = currentTime2;
            this.mLastDrawingThreadTime = currentThreadTime;
        }
    }

    public void endOfBeginScroll(int scrollX) {
        if (this.mScrollMonitor && this.isMonitoring) {
            long initialTime = System.currentTimeMillis() - this.mBeginScrollTime;
            Log.i(SCROLL_BEGIN, "beginScroll() [startX] = [" + scrollX + "], cost " + initialTime + " ms");
            this.mRecorder.setInitialTime(initialTime);
        }
    }

    public void end() {
        if (this.isMonitoring) {
            this.isMonitoring = false;
            if (this.mScrollMonitor) {
                if (isUseTraceView) {
                    try {
                        Debug.stopMethodTracing();
                    } catch (RuntimeException e) {
                        Log.e(SCROLL_BEGIN, "SD card not ready, check if sdcard is inserted and mounted. Check sd card is full or not.");
                    }
                }
                Log.d(SCROLL_BEGIN, LoggingEvents.EXTRA_CALLING_APP_NAME + this.mRecorder);
                StringBuffer buffer = new StringBuffer();
                buffer.append(this.mRecorder.getOutputString());
                try {
                    this.mScrollLogOutput.write(buffer.toString().getBytes());
                    this.mScrollLogOutput.close();
                    if (this.mPointsOutput != null) {
                        this.mPointsOutput.write(this.mRecorder.getPoints().getBytes());
                        this.mPointsOutput.close();
                    }
                } catch (IOException e2) {
                    if (localLOGV) {
                        Log.d(SCROLL_BEGIN, e2.getMessage(), e2);
                    }
                }
            }
        }
    }

    public void startDispatchDraw() {
        if (this.mScrollMonitor && this.isMonitoring) {
            this.mStartDrawingTime = System.currentTimeMillis();
            this.mStartDrawingThreadTime = Debug.threadCpuTimeNanos() / 1000000;
        }
    }

    public void endDispatchDraw() {
        if (this.mScrollMonitor && this.isMonitoring) {
            long currentTime = System.currentTimeMillis();
            long currentThreadTime = Debug.threadCpuTimeNanos() / 1000000;
            long dt = currentTime - this.mLastDrawingTime;
            long thread_dt = currentThreadTime - this.mLastDrawingThreadTime;
            long totalDrawingTime = currentTime - this.mStartDrawingTime;
            long totalDrawingThreadTime = currentThreadTime - this.mStartDrawingThreadTime;
            long drawingWorkspaceTime = this.mDrawingWorkspaceTime;
            long drawingWorkspaceThreadTime = this.mDrawingWorkspaceThreadTime;
            if (isUseTraceView) {
                if (this.mIsFirstDraw) {
                    if (thread_dt > 100) {
                        Log.e(SCROLL_BEGIN, "[dx, dt] = [" + this.mDeltaX + "," + dt + "(" + thread_dt + ")], [currentPage] = " + this.mCurrentPage + ", cost " + totalDrawingTime + "(" + totalDrawingThreadTime + ") ms, draw workspace cost " + drawingWorkspaceTime + "(" + drawingWorkspaceThreadTime + ") ms - first draw");
                        this.mHasErrorPattern = true;
                    } else if (dt > 200) {
                        Log.w(SCROLL_BEGIN, "[dx, dt] = [" + this.mDeltaX + "," + dt + "(" + thread_dt + ")], [currentPage] = " + this.mCurrentPage + ", cost " + totalDrawingTime + "(" + totalDrawingThreadTime + ") ms, draw workspace cost " + drawingWorkspaceTime + "(" + drawingWorkspaceThreadTime + ") ms - first draw");
                        this.mHasWarnPattern = true;
                    } else {
                        Log.d(SCROLL_BEGIN, "[dx, dt] = [" + this.mDeltaX + "," + dt + "(" + thread_dt + ")], [currentPage] = " + this.mCurrentPage + ", cost " + totalDrawingTime + "(" + totalDrawingThreadTime + ") ms, draw workspace cost " + drawingWorkspaceTime + "(" + drawingWorkspaceThreadTime + ") ms - first draw");
                    }
                } else if (this.mIsTouchDraw) {
                    if (thread_dt > 60) {
                        Log.e(SCROLL_BEGIN, "[dx, dt] = [" + this.mDeltaX + "," + dt + "(" + thread_dt + ")], [currentPage] = " + this.mCurrentPage + ", cost " + totalDrawingTime + "(" + totalDrawingThreadTime + ") ms, draw workspace cost " + drawingWorkspaceTime + "(" + drawingWorkspaceThreadTime + ") ms - touch draw");
                        this.mHasErrorPattern = true;
                    } else if (dt > 100) {
                        Log.w(SCROLL_BEGIN, "[dx, dt] = [" + this.mDeltaX + "," + dt + "(" + thread_dt + ")], [currentPage] = " + this.mCurrentPage + ", cost " + totalDrawingTime + "(" + totalDrawingThreadTime + ") ms, draw workspace cost " + drawingWorkspaceTime + "(" + drawingWorkspaceThreadTime + ") ms - touch draw");
                        this.mHasWarnPattern = true;
                    } else {
                        Log.d(SCROLL_BEGIN, "[dx, dt] = [" + this.mDeltaX + "," + dt + "(" + thread_dt + ")], [currentPage] = " + this.mCurrentPage + ", cost " + totalDrawingTime + "(" + totalDrawingThreadTime + ") ms, draw workspace cost " + drawingWorkspaceTime + "(" + drawingWorkspaceThreadTime + ") ms - touch draw");
                    }
                } else if (drawingWorkspaceThreadTime > 39) {
                    Log.v(SCROLL_BEGIN, "[dx, dt] = [" + this.mDeltaX + "," + dt + "(" + thread_dt + ")], [currentPage] = " + this.mCurrentPage + ", cost " + totalDrawingTime + "(" + totalDrawingThreadTime + ") ms, draw workspace cost " + drawingWorkspaceTime + "(" + drawingWorkspaceThreadTime + ") ms - first draw");
                    this.mHasVerbosePattern = true;
                } else if (thread_dt > 40) {
                    Log.e(SCROLL_BEGIN, "[dx, dt] = [" + this.mDeltaX + "," + dt + "(" + thread_dt + ")], [currentPage] = " + this.mCurrentPage + ", cost " + totalDrawingTime + "(" + totalDrawingThreadTime + ") ms, draw workspace cost " + drawingWorkspaceTime + "(" + drawingWorkspaceThreadTime + ") ms");
                    this.mHasErrorPattern = true;
                } else if (dt > 50) {
                    Log.w(SCROLL_BEGIN, "[dx, dt] = [" + this.mDeltaX + "," + dt + "(" + thread_dt + ")], [currentPage] = " + this.mCurrentPage + ", cost " + totalDrawingTime + "(" + totalDrawingThreadTime + ") ms, draw workspace cost " + drawingWorkspaceTime + "(" + drawingWorkspaceThreadTime + ") ms");
                    this.mHasWarnPattern = true;
                } else {
                    Log.d(SCROLL_BEGIN, "[dx, dt] = [" + this.mDeltaX + "," + dt + "(" + thread_dt + ")], [currentPage] = " + this.mCurrentPage + ", cost " + totalDrawingTime + "(" + totalDrawingThreadTime + ") ms, draw workspace cost " + drawingWorkspaceTime + "(" + drawingWorkspaceThreadTime + ") ms");
                }
            } else if (this.mIsFirstDraw) {
                if (thread_dt > 50) {
                    Log.e(SCROLL_BEGIN, "[dx, dt] = [" + this.mDeltaX + "," + dt + "(" + thread_dt + ")], [currentPage] = " + this.mCurrentPage + ", cost " + totalDrawingTime + "(" + totalDrawingThreadTime + ") ms, draw workspace cost " + drawingWorkspaceTime + "(" + drawingWorkspaceThreadTime + ") ms - first draw");
                    this.mHasErrorPattern = true;
                } else if (dt > 120) {
                    Log.w(SCROLL_BEGIN, "[dx, dt] = [" + this.mDeltaX + "," + dt + "(" + thread_dt + ")], [currentPage] = " + this.mCurrentPage + ", cost " + totalDrawingTime + "(" + totalDrawingThreadTime + ") ms, draw workspace cost " + drawingWorkspaceTime + "(" + drawingWorkspaceThreadTime + ") ms - first draw");
                    this.mHasWarnPattern = true;
                } else {
                    Log.d(SCROLL_BEGIN, "[dx, dt] = [" + this.mDeltaX + "," + dt + "(" + thread_dt + ")], [currentPage] = " + this.mCurrentPage + ", cost " + totalDrawingTime + "(" + totalDrawingThreadTime + ") ms, draw workspace cost " + drawingWorkspaceTime + "(" + drawingWorkspaceThreadTime + ") ms - first draw");
                }
            } else if (this.mIsTouchDraw) {
                if (thread_dt > 40) {
                    Log.e(SCROLL_BEGIN, "[dx, dt] = [" + this.mDeltaX + "," + dt + "(" + thread_dt + ")], [currentPage] = " + this.mCurrentPage + ", cost " + totalDrawingTime + "(" + totalDrawingThreadTime + ") ms, draw workspace cost " + drawingWorkspaceTime + "(" + drawingWorkspaceThreadTime + ") ms - touch draw");
                    this.mHasErrorPattern = true;
                } else if (dt > 100) {
                    Log.w(SCROLL_BEGIN, "[dx, dt] = [" + this.mDeltaX + "," + dt + "(" + thread_dt + ")], [currentPage] = " + this.mCurrentPage + ", cost " + totalDrawingTime + "(" + totalDrawingThreadTime + ") ms, draw workspace cost " + drawingWorkspaceTime + "(" + drawingWorkspaceThreadTime + ") ms - touch draw");
                    this.mHasWarnPattern = true;
                } else {
                    Log.d(SCROLL_BEGIN, "[dx, dt] = [" + this.mDeltaX + "," + dt + "(" + thread_dt + ")], [currentPage] = " + this.mCurrentPage + ", cost " + totalDrawingTime + "(" + totalDrawingThreadTime + ") ms, draw workspace cost " + drawingWorkspaceTime + "(" + drawingWorkspaceThreadTime + ") ms - touch draw");
                }
            } else if (drawingWorkspaceThreadTime > 30) {
                Log.v(SCROLL_BEGIN, "[dx, dt] = [" + this.mDeltaX + "," + dt + "(" + thread_dt + ")], [currentPage] = " + this.mCurrentPage + ", cost " + totalDrawingTime + "(" + totalDrawingThreadTime + ") ms, draw workspace cost " + drawingWorkspaceTime + "(" + drawingWorkspaceThreadTime + ") ms - first draw");
                this.mHasVerbosePattern = true;
            } else if (thread_dt > 30) {
                Log.e(SCROLL_BEGIN, "[dx, dt] = [" + this.mDeltaX + "," + dt + "(" + thread_dt + ")], [currentPage] = " + this.mCurrentPage + ", cost " + totalDrawingTime + "(" + totalDrawingThreadTime + ") ms, draw workspace cost " + drawingWorkspaceTime + "(" + drawingWorkspaceThreadTime + ") ms");
                this.mHasErrorPattern = true;
            } else if (dt > 40) {
                Log.w(SCROLL_BEGIN, "[dx, dt] = [" + this.mDeltaX + "," + dt + "(" + thread_dt + ")], [currentPage] = " + this.mCurrentPage + ", cost " + totalDrawingTime + "(" + totalDrawingThreadTime + ") ms, draw workspace cost " + drawingWorkspaceTime + "(" + drawingWorkspaceThreadTime + ") ms");
                this.mHasWarnPattern = true;
            } else {
                Log.d(SCROLL_BEGIN, "[dx, dt] = [" + this.mDeltaX + "," + dt + "(" + thread_dt + ")], [currentPage] = " + this.mCurrentPage + ", cost " + totalDrawingTime + "(" + totalDrawingThreadTime + ") ms, draw workspace cost " + drawingWorkspaceTime + "(" + drawingWorkspaceThreadTime + ") ms");
            }
            this.mLastDrawingTime = System.currentTimeMillis();
            this.mLastDrawingThreadTime = Debug.threadCpuTimeNanos() / 1000000;
            if (this.mDeltaX != 0) {
                this.mRecorder.addInterval(dt);
                this.mRecorder.addMovement(this.mDeltaX);
                this.mRecorder.addThreadInterval(thread_dt);
            }
            this.mIsFirstDraw = false;
            this.mIsTouchDraw = false;
        }
    }

    public void startDrawWorkspace() {
        if (this.mScrollMonitor && this.isMonitoring) {
            this.mStartDrawingWorkspace = System.currentTimeMillis();
            this.mStartDrawingWorkspaceThreadTime = Debug.threadCpuTimeNanos() / 1000000;
        }
    }

    public void endDrawWorkspace(int scrollX, int currentPage) {
        if (this.mScrollMonitor && this.isMonitoring) {
            this.mDrawingWorkspaceTime = System.currentTimeMillis() - this.mStartDrawingWorkspace;
            this.mDrawingWorkspaceThreadTime = (Debug.threadCpuTimeNanos() / 1000000) - this.mStartDrawingWorkspaceThreadTime;
            this.mDeltaX = scrollX - this.mLastScrollX;
            this.mCurrentPage = currentPage;
            this.mLastScrollX = scrollX;
        }
    }

    public void onTouchEvent(int action, int parm1, int param2) {
        if (this.mScrollMonitor && this.isMonitoring) {
            if (action == 2) {
                if (this.mRecorder != null) {
                    this.mRecorder.actionMove();
                }
                Log.i(SCROLL_BEGIN, "ACTION_MOVE, scrollTo(" + parm1 + "), [compensate] = " + param2);
                if (this.mLastMotionX == parm1) {
                    this.mLastDrawingTime = System.currentTimeMillis();
                    this.mLastDrawingThreadTime = Debug.threadCpuTimeNanos() / 1000000;
                }
                this.mLastMotionX = parm1;
            } else if (action == 1) {
                Log.i(SCROLL_BEGIN, "ACTION_UP, velocity = " + parm1 + ", delatX = " + param2);
                if (this.mRecorder != null) {
                    this.mRecorder.actionUp();
                }
                this.mLastMotionX = Integer.MAX_VALUE;
            } else if (action == 3) {
                Log.i(SCROLL_BEGIN, "ACTION_CANCEL");
                this.mLastMotionX = Integer.MAX_VALUE;
            }
            this.mIsTouchDraw = true;
        }
    }

    public void onInterceptTouchEvent(int action, int params) {
        if (this.mScrollMonitor) {
            if (action == 2) {
                Log.i(SCROLL_BEGIN, "ACTION_MOVE, not start move deltaX = " + params);
            } else if (action == 1) {
                Log.i(SCROLL_BEGIN, "ACTION_UP, onInterceptTouchEvent()");
            } else if (action == 0) {
                Log.i(SCROLL_BEGIN, "ACTION_DOWN, currentScreen = " + params);
            } else if (action == 3) {
                Log.i(SCROLL_BEGIN, "ACTION_CANCEL, onInterceptTouchEvent()");
            }
            this.mIsTouchDraw = true;
        }
    }

    private class Recorder {
        private boolean isOnTouch;
        private long mInitialTime;
        private ArrayList<Long> mIntervals;
        private ArrayList<Integer> mMovement;
        private ArrayList<Long> mThreadIntervals;
        private int mTouchPointsCount;

        private Recorder() {
            this.mTouchPointsCount = 0;
            this.isOnTouch = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void addInterval(long duration) {
            if (this.mIntervals == null) {
                this.mIntervals = new ArrayList<>();
            }
            this.mIntervals.add(Long.valueOf(duration));
            if (this.isOnTouch) {
                this.mTouchPointsCount++;
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void addThreadInterval(long duration) {
            if (this.mThreadIntervals == null) {
                this.mThreadIntervals = new ArrayList<>();
            }
            this.mThreadIntervals.add(Long.valueOf(duration));
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void addMovement(int movement) {
            if (this.mMovement == null) {
                this.mMovement = new ArrayList<>();
            }
            this.mMovement.add(Integer.valueOf(movement));
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setInitialTime(long initialTime) {
            this.mInitialTime = initialTime;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void actionUp() {
            this.isOnTouch = false;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void actionMove() {
            this.isOnTouch = true;
        }

        public String toString() {
            int size = this.mIntervals == null ? 0 : this.mIntervals.size();
            if (size == 0) {
                return "no scroll";
            }
            long total = 0;
            long touchPointTotal = 0;
            long unTouchPointTotal = 0;
            long max = 0;
            long min = 2147483647L;
            for (int i = 0; i < this.mIntervals.size(); i++) {
                long interval = this.mIntervals.get(i).longValue();
                total += interval;
                if (interval > max) {
                    max = interval;
                }
                if (interval < min) {
                    min = interval;
                }
                if (i < this.mTouchPointsCount) {
                    touchPointTotal += interval;
                } else {
                    unTouchPointTotal += interval;
                }
            }
            long touchAvg = this.mTouchPointsCount == 0 ? 0L : touchPointTotal / this.mTouchPointsCount;
            long unTouchAvg = unTouchPointTotal / (size - this.mTouchPointsCount);
            long avg = total / size;
            long firstDraw = this.mIntervals.get(0).longValue();
            String output = "first draw = " + firstDraw + ", avg = " + avg + ", touch avg = " + touchAvg + ", untouch avg = " + unTouchAvg + ", max = " + max + ", min = " + min + ", initial time = " + this.mInitialTime;
            return output;
        }

        public String getPoints() {
            StringBuffer output = new StringBuffer();
            int size = this.mIntervals == null ? 0 : this.mIntervals.size();
            if (size == 0) {
                output.append("no scroll");
            } else {
                for (int i = 0; i < size; i++) {
                    output.append(this.mIntervals.get(i));
                    output.append("\t");
                    output.append(this.mThreadIntervals.get(i));
                    output.append("\t");
                    output.append(this.mMovement.get(i));
                    output.append("\n");
                }
            }
            return output.toString();
        }

        public String getOutputString() {
            int size = this.mIntervals == null ? 0 : this.mIntervals.size();
            if (size == 0) {
                return "no scroll";
            }
            long total = 0;
            long touchPointTotal = 0;
            long unTouchPointTotal = 0;
            long max = 0;
            long min = 2147483647L;
            for (int i = 0; i < this.mIntervals.size(); i++) {
                long interval = this.mIntervals.get(i).longValue();
                total += interval;
                if (interval > max) {
                    max = interval;
                }
                if (interval < min) {
                    min = interval;
                }
                if (i < this.mTouchPointsCount) {
                    touchPointTotal += interval;
                } else {
                    unTouchPointTotal += interval;
                }
            }
            long touchAvg = this.mTouchPointsCount == 0 ? 0L : touchPointTotal / this.mTouchPointsCount;
            long unTouchAvg = unTouchPointTotal / (size - this.mTouchPointsCount);
            long avg = total / size;
            long firstDraw = this.mIntervals.get(0).longValue();
            int hasErrorPattern = ScrollMonitor.this.mHasErrorPattern ? 1 : 0;
            int hasWarnPattern = ScrollMonitor.this.mHasWarnPattern ? 1 : 0;
            int hasVerbosePattern = ScrollMonitor.this.mHasVerbosePattern ? 1 : 0;
            String output = LoggingEvents.EXTRA_CALLING_APP_NAME + firstDraw + "\t" + avg + "\t" + touchAvg + "\t" + unTouchAvg + "\t" + max + "\t" + min + "\t" + this.mInitialTime + "\t" + hasErrorPattern + "\t" + hasWarnPattern + "\t" + hasVerbosePattern + "\n";
            return output;
        }
    }

    public void refreshFile() {
        if (this.mScrollMonitor) {
            try {
                this.mScrollLogOutput = this.mContext.openFileOutput("scroll_performance.txt", 0);
                StringBuffer buffer = new StringBuffer();
                buffer.append("first draw\t");
                buffer.append("avg\t");
                buffer.append("touch avg\t");
                buffer.append("unTouch avg\t");
                buffer.append("max\t");
                buffer.append("min\t");
                buffer.append("initial time\t");
                buffer.append("widget fail\t");
                buffer.append("BG fail\n");
                this.mScrollLogOutput.write(buffer.toString().getBytes());
                this.mScrollLogOutput.close();
            } catch (FileNotFoundException e) {
                Log.e(SCROLL_BEGIN, e.getMessage(), e);
            } catch (IOException e2) {
                Log.e(SCROLL_BEGIN, e2.getMessage(), e2);
            }
        }
    }

    public void showZeroLog(int scrollX, int currentPage) {
        if (this.mScrollMonitor && this.isMonitoring) {
            long currentTime = System.currentTimeMillis();
            long dt = currentTime - this.mLastDrawingTime;
            long totalDrawingTime = currentTime - this.mStartDrawingTime;
            long drawingWorkspaceTime = this.mDrawingWorkspaceTime;
            Log.d(SCROLL_BEGIN, "[dx, dt] = [0," + dt + "], [currentPage] = " + currentPage + ", cost " + totalDrawingTime + " ms, draw workspace cost " + drawingWorkspaceTime + " ms");
            this.mLastDrawingTime = System.currentTimeMillis();
            this.mLastDrawingThreadTime = Debug.threadCpuTimeNanos() / 1000000;
        }
    }

    public void showDrawingTime(long drawScreenCacheTime, long drawThumbnailCacheTime) {
        Log.d(SCROLL_BEGIN, "drawScreenCache takes " + drawScreenCacheTime + "ms, drawThumbnailCache takes " + drawThumbnailCacheTime + "ms");
    }
}
