package com.htc.launcher;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public final class Manifest {

    public static final class permission {
        public static final String CLEAN_SCENE = "com.htc.launcher.permission.CLEAN_SCENE";
        public static final String INSTALL_SHORTCUT = "com.android.launcher.permission.INSTALL_SHORTCUT";
        public static final String READ_SETTINGS = "com.htc.launcher.permission.READ_SETTINGS";
        public static final String UNINSTALL_SHORTCUT = "com.android.launcher.permission.UNINSTALL_SHORTCUT";
        public static final String UPDATE_SHORTCUT = "com.htc.launcher.permission.UPDATE_SHORTCUT";
        public static final String WRITE_SETTINGS = "com.htc.launcher.permission.WRITE_SETTINGS";
    }
}
