package com.htc.launcher.widget;

import com.htc.launcher.settings.SettingUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class EaseInBack implements EasingFunction {
    @Override // com.htc.launcher.widget.EasingFunction
    public float currentResult(float v0, float t, float b, float c, float d) {
        float t2 = t / d;
        float ts = t2 * t2;
        float tc = ts * t2;
        return (((SettingUtil.sEaseInBackCoefficients[4] * tc * ts) + (SettingUtil.sEaseInBackCoefficients[3] * ts * ts) + (SettingUtil.sEaseInBackCoefficients[2] * tc) + (SettingUtil.sEaseInBackCoefficients[1] * ts) + (SettingUtil.sEaseInBackCoefficients[0] * t2)) * c) + b;
    }
}
