package com.htc.launcher.widget;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class EaseLinear implements EasingFunction {
    @Override // com.htc.launcher.widget.EasingFunction
    public float currentResult(float v0, float t, float b, float c, float d) {
        return (c * (t / d)) + b;
    }
}
