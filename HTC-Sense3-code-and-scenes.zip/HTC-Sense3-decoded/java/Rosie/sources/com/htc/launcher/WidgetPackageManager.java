package com.htc.launcher;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.WallpaperInfo;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.FileUtils;
import android.os.IBinder;
import android.os.Process;
import android.os.RemoteException;
import android.os.SystemProperties;
import android.util.Log;
import com.android.common.speech.LoggingEvents;
import com.htc.android.rosie.home.HostWidgetManager;
import com.htc.clientprofileservice.Group;
import com.htc.clientprofileservice.IClientProfileCallback;
import com.htc.clientprofileservice.IClientProfileService;
import com.htc.clientprofileservice.MyPhonebook;
import com.htc.clientprofileservice.Profile;
import com.htc.clientprofileservice.Sncdata;
import com.htc.launcher.Launcher;
import com.htc.launcher.LauncherSettings;
import com.htc.launcher.config.FavoriteData;
import com.htc.launcher.scene.ScenePickerAdapter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.Set;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class WidgetPackageManager {
    private static final String COMMUNITY_ACCOUNT = "community";
    private static final String COMMUNITY_ACCOUNT_TYPE = "com.htc.android.myphonebook";
    private static final String CUSTOMIZATION_URI_STRING = "content://customization_settings/SettingTable/application_Launcher";
    public static final String DRAWABLE_TOKEN = "Local_";
    public static final int ITEM_TYPE_OFFSET = 1100;
    public static final String LIVE_TOKEN = "Live_";
    private static final String MAIL_ACCOUNT = "mail";
    private static final String NOTES_ACCOUNT = "notes";
    private static final String PREFIX_PROPERTY = "property.";
    public static final String PREF_KEY_INIT = "Initialized";
    public static final String REFERENCES = "WidgetPackageManager";
    private static final String SCENE_NAME_LIST_KEY = "scene_list";
    private static final String SOCIAL_ACCOUNT = "social";
    private static final String TAG = "Widget";
    private static final String WALLPAPER_ROOT_PATH = "/system/customize/resource/";
    static final String WIDGET_UTILITY_PACKAGE = "com.htc.AddProgramWidget";
    private static final boolean localLOGV = false;
    private HostWidgetManager mFxWidgetManager;
    private static WidgetPackageManager sInstance = new WidgetPackageManager();
    private static boolean initialized = false;
    protected ArrayList<WidgetProxy> mWidgets = new ArrayList<>();
    private HashMap<Long, WidgetProxy> mWidgetsMap = new HashMap<>();
    private HashMap<String, WidgetPackage> mWidgetPackageMap = new HashMap<>();
    private ArrayList<WidgetItem> mWidgetItemList = new ArrayList<>();
    private HashMap<Integer, WidgetItem> mWidgetItemMap = new HashMap<>();
    private HashMap<String, WidgetItem> mWidgetItemStringMap = new HashMap<>();
    WidgetCategoryManager mCategoryManager = new WidgetCategoryManager();
    private boolean mHasSocialAccount = false;
    private boolean mHasMailAccount = false;
    private boolean mHasCommunityAccount = false;
    private boolean mHasNoteAccount = false;
    String[] mCustomizeSceneName = null;
    String mSceneTitleName = null;

    private WidgetPackageManager() {
    }

    public static WidgetPackageManager instanceNoScan() {
        return sInstance;
    }

    public static synchronized WidgetPackageManager instance(Context context) {
        WidgetPackageManager widgetPackageManager;
        synchronized (WidgetPackageManager.class) {
            if (!initialized) {
                sInstance.checkScanDone(context);
                sInstance.scanWidgetItems(context, null);
                sInstance.init(context);
                initialized = true;
            }
            widgetPackageManager = sInstance;
        }
        return widgetPackageManager;
    }

    public ArrayList<WidgetItem> getWidgetItemList(int categoryId) {
        return this.mCategoryManager.getItems(categoryId);
    }

    public void setFxWidgetManager(HostWidgetManager manager) {
        this.mFxWidgetManager = manager;
    }

    private void checkScanDone(Context context) {
        synchronized (GeneralPurposeReceiver.syncScanDone) {
            SharedPreferences preferences = context.getSharedPreferences(REFERENCES, 0);
            boolean scanDone = preferences.getBoolean(GeneralPurposeReceiver.PREF_SCAN_DONE, false);
            String prefBuildNo = preferences.getString(GeneralPurposeReceiver.PREF_BUILD_NO, "None");
            String systemBuildNo = SystemProperties.get("ro.build.description");
            if (!scanDone) {
                Intent intent = new Intent("com.htc.rosie.ACTION_START_SCAN_HTC_WIDGET");
                context.sendBroadcast(intent);
                try {
                    GeneralPurposeReceiver.syncScanDone.wait(60000L);
                } catch (InterruptedException e) {
                }
            } else if (!prefBuildNo.equals(systemBuildNo)) {
                Intent intent2 = new Intent("com.htc.rosie.ACTION_START_UPDATE_HTC_WIDGET");
                context.sendBroadcast(intent2);
                try {
                    GeneralPurposeReceiver.syncScanDone.wait(60000L);
                } catch (InterruptedException e2) {
                }
            }
        }
    }

    private void init(Context context) {
        Bundle moduleBundle = getModuleBundle(context);
        String[] names = context.getResources().getStringArray(R.array.default_workspace_names);
        this.mCustomizeSceneName = new String[names.length];
        for (int i = 0; i < names.length; i++) {
            int i_1 = i + 1;
            this.mCustomizeSceneName[i] = loadCustomizedWorkspaceName(moduleBundle, i_1);
        }
        loadSceneSettings(moduleBundle);
    }

    private String loadCustomizedWorkspaceName(Bundle moduleBundle, int index) {
        String key = index + "_widgets_name";
        Bundle sceneNameBundle = moduleBundle.getBundle(key);
        if (sceneNameBundle == null) {
            return null;
        }
        String sceneName = sceneNameBundle.getString("scene_name");
        return sceneName;
    }

    private void loadSceneSettings(Bundle moduleBundle) {
        Bundle sceneBundle = moduleBundle.getBundle("scene");
        if (sceneBundle != null) {
            this.mSceneTitleName = sceneBundle.getString("scene_title_name");
        }
    }

    void scanWidgetItems(Context context, String packageName) {
        Cursor cursor;
        WidgetItem parentItem;
        WidgetWorkspaceManager.instance(context);
        ContentResolver cr = context.getContentResolver();
        if (packageName == null) {
            cursor = cr.query(LauncherSettings.WidgetItemTypes.CONTENT_URI, null, "item_category!=0", null, "parent_id ASC");
        } else {
            WidgetItem[] items = (WidgetItem[]) this.mWidgetItemList.toArray(new WidgetItem[0]);
            for (WidgetItem item : items) {
                if (packageName.equals(item.mPackageName)) {
                    this.mWidgetItemList.remove(item);
                    this.mWidgetItemMap.remove(Integer.valueOf(item.mItemType));
                    this.mCategoryManager.unbindCategory(item);
                    this.mWidgetItemStringMap.remove(item.mPackageName + item.mWidgetName);
                }
            }
            cursor = cr.query(LauncherSettings.WidgetItemTypes.CONTENT_URI, null, "item_category!=0 AND package_name=?", new String[]{packageName}, "parent_id ASC");
        }
        if (cursor == null) {
            Log.e("Widget", "scanWidgetItems(" + packageName + "), cannot get cursor. The widget list may be empty.");
            return;
        }
        int idxId = cursor.getColumnIndex(LauncherSettings.Favorites.ID);
        int idxPackageName = cursor.getColumnIndex(LauncherSettings.WidgetItemTypes.PACKAGE_NAME);
        int idxPluginClassname = cursor.getColumnIndex(LauncherSettings.WidgetItemTypes.PLUGIN_CLASSNAME);
        int idxWidgetName = cursor.getColumnIndex(LauncherSettings.WidgetItemTypes.WIDGET_NAME);
        int idxItemCategory = cursor.getColumnIndex(LauncherSettings.WidgetItemTypes.ITEM_CATEGORY);
        int idxParentId = cursor.getColumnIndex(LauncherSettings.WidgetItemTypes.PARENT_ID);
        int idxTextResource = cursor.getColumnIndex(LauncherSettings.WidgetItemTypes.TEXT_RESOURCE);
        int idxIconResource = cursor.getColumnIndex(LauncherSettings.WidgetItemTypes.ICON_RESOURCE);
        int idxSpanX = cursor.getColumnIndex(LauncherSettings.WidgetItemTypes.SPAN_X);
        int idxSpanY = cursor.getColumnIndex(LauncherSettings.WidgetItemTypes.SPAN_Y);
        int idxLayoutResource = cursor.getColumnIndex(LauncherSettings.WidgetItemTypes.LAYOUT_RESOURCE);
        int idxExtraProperties = cursor.getColumnIndex(LauncherSettings.WidgetItemTypes.EXTRA_PROPERTIES);
        while (cursor.moveToNext()) {
            try {
                WidgetItem item2 = new WidgetItem(context);
                item2.mItemType = cursor.getInt(idxId);
                item2.mPackageName = cursor.getString(idxPackageName);
                item2.mPluginClassname = cursor.getString(idxPluginClassname);
                item2.mWidgetName = cursor.getString(idxWidgetName);
                item2.mItemCategory = cursor.getInt(idxItemCategory);
                item2.mTextResource = cursor.getInt(idxTextResource);
                item2.mIconResource = cursor.getInt(idxIconResource);
                item2.mSpanX = cursor.getInt(idxSpanX);
                item2.mSpanY = cursor.getInt(idxSpanY);
                item2.mLayoutResource = cursor.getInt(idxLayoutResource);
                item2.mParentId = cursor.getInt(idxParentId);
                try {
                    ByteArrayInputStream in = new ByteArrayInputStream(cursor.getBlob(idxExtraProperties));
                    ObjectInputStream in2 = new ObjectInputStream(in);
                    item2.mProps = (Properties) in2.readObject();
                } catch (Exception e) {
                }
                this.mWidgetItemList.add(item2);
                this.mWidgetItemMap.put(Integer.valueOf(item2.mItemType), item2);
                this.mCategoryManager.bindCategory(item2);
                this.mWidgetItemStringMap.put(item2.mPackageName + item2.mWidgetName, item2);
                if (item2.mParentId > 0 && (parentItem = this.mWidgetItemMap.get(Integer.valueOf(item2.mParentId))) != null) {
                    parentItem.addChild(item2);
                }
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void initFavorites(Launcher launcher, LauncherModel model) {
        final SharedPreferences preferences = launcher.getSharedPreferences(REFERENCES, 0);
        boolean initialized2 = preferences.getBoolean(PREF_KEY_INIT, false);
        if (!initialized2) {
            LauncherModel.deleteAllItemsFromDatabase(launcher);
            WidgetWorkspaceManager wm = WidgetWorkspaceManager.instance(launcher);
            Bundle moduleBundle = getModuleBundle(launcher);
            ArrayList<WidgetWorkspace> widgetWorkspaces = initSceneName(moduleBundle, launcher, wm);
            wm.refresh(launcher, widgetWorkspaces);
            initAccount(launcher);
            for (int i = 0; i < wm.size(); i++) {
                int i_1 = i + 1;
                initFavoriteShortcuts(moduleBundle, launcher, i_1);
                initFavoriteWidgets(moduleBundle, launcher, i_1);
                initFavoriteFxWidgets(moduleBundle, launcher, i_1);
                initFavoriteAppWidgets(moduleBundle, launcher, i_1);
                initWallpaper(moduleBundle, launcher, i_1);
            }
            wm.initialCurrentWorkspace(launcher);
            LauncherModel.duplicateAllItems(launcher, 1, 0);
            wm.loadHomeWallpaper(launcher);
            Thread thread = new Thread(new Runnable() { // from class: com.htc.launcher.WidgetPackageManager.1
                @Override // java.lang.Runnable
                public void run() {
                    Process.setThreadPriority(19);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putBoolean(WidgetPackageManager.PREF_KEY_INIT, true);
                    editor.apply();
                }
            });
            thread.start();
        }
    }

    static Bundle getModuleBundle(Context context) {
        ContentResolver cr = context.getContentResolver();
        Uri uri = Uri.parse(CUSTOMIZATION_URI_STRING);
        Cursor c = cr.query(uri, null, null, null, null);
        if (c != null) {
            try {
                if (c.moveToFirst()) {
                    int idValue = c.getColumnIndexOrThrow(LoggingEvents.VoiceSearch.EXTRA_QUERY_UPDATED_VALUE);
                    byte[] buffer = c.getBlob(idValue);
                    Bundle bundle = Utilities.byteArrayToBundle(buffer);
                    return bundle;
                }
            } finally {
                if (c != null) {
                    c.close();
                }
            }
        }
        if (c != null) {
            c.close();
        }
        Log.w("Widget", "no module bundle found = " + c);
        return new Bundle();
    }

    private String getPresetWallpaperKey(int workspaceId) {
        return workspaceId + "_wallpaper";
    }

    private void writeBitmap(Bitmap bitmap, String filename) {
        if (bitmap != null) {
            try {
                FileOutputStream out = new FileOutputStream(filename);
                synchronized (WidgetWorkspaceManager.sBitmapFactorySync) {
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
                }
                out.flush();
                out.close();
            } catch (IOException e) {
                Log.w("Widget", "Could not save bitmap : " + filename);
            }
        }
    }

    private void initWallpaper(Bundle moduleBundle, Context context, int workspaceId) {
        String key = getPresetWallpaperKey(workspaceId);
        if (Launcher.WallpaperIntentReceiver.isOOBE) {
            android.app.WallpaperManager wm = android.app.WallpaperManager.getInstance(context);
            WallpaperInfo wallpaperInfo = wm.getWallpaperInfo();
            if (wallpaperInfo == null) {
                Drawable drawable = wm.getDrawable();
                if (drawable instanceof BitmapDrawable) {
                    Bitmap WallpaperBitmap = ((BitmapDrawable) drawable).getBitmap();
                    if (workspaceId == 1) {
                        writeBitmap(WallpaperBitmap, WidgetWorkspace.getHomeWallpaper(context, -1));
                    }
                    writeBitmap(WallpaperBitmap, WidgetWorkspace.getHomeWallpaper(context, workspaceId));
                } else {
                    throw new IllegalStateException("The wallpaper must be a BitmapDrawable.");
                }
            } else {
                String componentName = wallpaperInfo.getComponent().flattenToString();
                if (componentName != null) {
                    WidgetWorkspaceManager wwm = WidgetWorkspaceManager.instance();
                    wwm.setWallpaperComponent(workspaceId, componentName);
                }
            }
            Launcher.WallpaperIntentReceiver.isOOBE = false;
            return;
        }
        Bundle wallpaperBundle = moduleBundle.getBundle(key);
        if (wallpaperBundle != null) {
            String value = wallpaperBundle.getString("image");
            if (value.startsWith(DRAWABLE_TOKEN)) {
                String source = value.substring(DRAWABLE_TOKEN.length());
                try {
                    PackageManager pm = context.getPackageManager();
                    Resources resources = pm.getResourcesForApplication(WIDGET_UTILITY_PACKAGE);
                    int DrawableResId = resources.getIdentifier(source, "drawable", WIDGET_UTILITY_PACKAGE);
                    Drawable WallpaperDrawable = resources.getDrawable(DrawableResId);
                    if (WallpaperDrawable instanceof BitmapDrawable) {
                        Bitmap WallpaperBitmap2 = ((BitmapDrawable) WallpaperDrawable).getBitmap();
                        if (workspaceId == 1) {
                            writeBitmap(WallpaperBitmap2, WidgetWorkspace.getHomeWallpaper(context, -1));
                        }
                        writeBitmap(WallpaperBitmap2, WidgetWorkspace.getHomeWallpaper(context, workspaceId));
                        return;
                    }
                    throw new IllegalStateException("The wallpaper must be a BitmapDrawable.");
                } catch (PackageManager.NameNotFoundException e) {
                    return;
                } catch (Resources.NotFoundException ex) {
                    Log.e("Steven", "resource not found : " + source, ex);
                    return;
                }
            }
            if (value.startsWith(LIVE_TOKEN)) {
                String component = value.substring(LIVE_TOKEN.length());
                WidgetWorkspaceManager.instance(context).setWallpaperComponent(workspaceId, component);
                return;
            }
            String source2 = manipulateResourcePath(value);
            if (workspaceId == 1) {
                String target = WidgetWorkspace.getHomeWallpaper(context, -1);
                File dest = new File(target);
                if (!dest.exists()) {
                    FileUtils.copyFile(new File(source2), new File(target));
                }
            }
            FileUtils.copyFile(new File(source2), new File(WidgetWorkspace.getHomeWallpaper(context, workspaceId)));
            return;
        }
        Log.w("Widget", "no wallpaper for - " + key);
    }

    private String getPresetShortcutKey(int workspaceId) {
        return workspaceId + "_shortcuts";
    }

    private ArrayList<WidgetWorkspace> initSceneName(Bundle moduleBundle, Context context, WidgetWorkspaceManager wm) {
        Bundle sceneNameListBundle = moduleBundle.getBundle(SCENE_NAME_LIST_KEY);
        if (sceneNameListBundle == null) {
            return null;
        }
        ArrayList<WidgetWorkspace> widgetWorkspaces = new ArrayList<>();
        if (sceneNameListBundle != null) {
            int size = sceneNameListBundle.size();
            for (int i = 0; i < size; i++) {
                String key = "plenty_set" + (i + 1);
                Bundle sceneNameBundle = sceneNameListBundle.getBundle(key);
                String[] names = context.getResources().getStringArray(R.array.original_workspace_names);
                String sceneNameString = sceneNameBundle.getString("scenename");
                if (sceneNameString.length() > 50) {
                    sceneNameString = "get Mojibake from sceneNameBundle";
                    Logger.e("Widget", "workspace.displayName");
                }
                String lockscreenWallpaper = sceneNameBundle.getString(LauncherSettings.WidgetWorkspace.LOCKSCREEN_WALLPAPER_NAME);
                WidgetWorkspace wws = new WidgetWorkspace();
                wws.translate_id = -1;
                int j = 0;
                while (true) {
                    if (j >= names.length) {
                        break;
                    }
                    if (!sceneNameString.equals(names[j])) {
                        j++;
                    } else {
                        wws.translate_id = j;
                        break;
                    }
                }
                wws.id = i + 1;
                wws.ancestor_id = i + 1;
                wws.displayName = sceneNameString;
                wws.status = 2;
                wws.lockscreen_wallpaper_name = lockscreenWallpaper;
                widgetWorkspaces.add(wws);
                File filesFolder = new File("/data/data/com.htc.launcher/files");
                if (!filesFolder.exists()) {
                    boolean success = filesFolder.mkdir();
                    if (success) {
                        FileUtils.setPermissions("/data/data/com.htc.launcher/files", 493, -1, -1);
                    }
                }
                String scenePreviewLarge = sceneNameBundle.getString("scene_preview_large");
                if (scenePreviewLarge != null) {
                    String source = manipulateResourcePath(scenePreviewLarge);
                    String target = ScenePickerAdapter.PREVIEW_PATH + wws.id + ".png";
                    FileUtils.copyFile(new File(source), new File(target));
                }
                String scenePreviewLargeLand = sceneNameBundle.getString("scene_preview_large_land");
                if (scenePreviewLargeLand != null) {
                    String source2 = manipulateResourcePath(scenePreviewLargeLand);
                    String target2 = ScenePickerAdapter.PREVIEW_PATH_LAND + wws.id + ".png";
                    FileUtils.copyFile(new File(source2), new File(target2));
                }
            }
        }
        return widgetWorkspaces;
    }

    private void initFavoriteShortcuts(Bundle moduleBundle, Context context, int workspaceId) {
        String key = getPresetShortcutKey(workspaceId);
        Bundle shortcutsBundle = moduleBundle.getBundle(key);
        if (shortcutsBundle != null) {
            int size = shortcutsBundle.size();
            for (int i = 0; i < size; i++) {
                String key2 = "plenty_set" + (i + 1);
                Bundle childBundle = shortcutsBundle.getBundle(key2);
                String showCondition = childBundle.getString("show");
                String hideCondition = childBundle.getString("hide");
                if (shouldShowItem(showCondition, hideCondition)) {
                    FavoriteData favdata = new FavoriteData();
                    favdata.packageName = childBundle.getString("package");
                    favdata.className = childBundle.getString("class");
                    favdata.url = childBundle.getString("url");
                    favdata.title = childBundle.getString("title");
                    favdata.icon = childBundle.getString(LauncherSettings.Favorites.ICON);
                    favdata.removable = childBundle.getInt("removable");
                    favdata.workspaceId = workspaceId;
                    String value = childBundle.getString("itemtype");
                    if (value != null) {
                        favdata.itemtype = Integer.parseInt(value);
                    }
                    String value2 = childBundle.getString(LauncherSettings.Favorites.SCREEN);
                    if (value2 != null) {
                        favdata.screen = Integer.parseInt(value2);
                    }
                    String value3 = childBundle.getString("x");
                    if (value3 != null) {
                        favdata.x = Integer.parseInt(value3);
                    }
                    String value4 = childBundle.getString("y");
                    if (value4 != null) {
                        favdata.y = Integer.parseInt(value4);
                    }
                    switch (favdata.itemtype) {
                        case 0:
                            ApplicationInfo app = LauncherModel.getApplication(favdata, context);
                            if (app != null) {
                                LauncherModel.initAddItemToDatabase(context, app, -100L, app.screen, app.cellX, app.cellY, false);
                                break;
                            } else {
                                Log.d("Widget", "Application: getApplication fail");
                                break;
                            }
                        case 1:
                            ApplicationInfo app2 = LauncherModel.getShortcut(favdata, context);
                            if (app2 != null) {
                                LauncherModel.initAddItemToDatabase(context, app2, -100L, app2.screen, app2.cellX, app2.cellY, false);
                                break;
                            } else {
                                Log.d("Widget", "Shortcut: getShortcut fail");
                                break;
                            }
                    }
                }
            }
        }
    }

    protected static class OperatorServiceCheck implements ServiceConnection {
        static IClientProfileCallback mProfileResponse;
        static IClientProfileService mProfileService;
        public static int mServiceSubscribe = -1;
        static boolean mForceRun = false;

        OperatorServiceCheck(boolean forceRun) {
            mForceRun = forceRun;
        }

        @Override // android.content.ServiceConnection
        public void onServiceConnected(ComponentName name, IBinder boundService) {
            boolean isPass;
            if (-1 == mServiceSubscribe || mForceRun) {
                mProfileService = IClientProfileService.Stub.asInterface(boundService);
                try {
                    if (mProfileService != null) {
                    }
                    mProfileService.registerCallback(new IClientProfileCallback.Stub() { // from class: com.htc.launcher.WidgetPackageManager.OperatorServiceCheck.1
                        public void capabilitiesSubmitted(boolean result) throws RemoteException {
                        }

                        public void profileModified(boolean result) throws RemoteException {
                        }

                        public void myPhonebookRetrieved(MyPhonebook mpb) throws RemoteException {
                            if (mpb == null) {
                                OperatorServiceCheck.mServiceSubscribe = 0;
                            } else if (mpb.isNabProvisioningStatus() || mpb.isCmtUiSubscribed()) {
                                OperatorServiceCheck.mServiceSubscribe = 1;
                            } else {
                                OperatorServiceCheck.mServiceSubscribe = 0;
                            }
                        }

                        public void profileRetrieved(Profile profile) throws RemoteException {
                        }

                        public void sncdataRetrieved(Sncdata data) throws RemoteException {
                        }

                        public void myGroupsRetrieved(List<Group> myGroups) throws RemoteException {
                        }

                        public void serverNotified(int opcode, boolean result) throws RemoteException {
                        }
                    });
                    if (mProfileService != null) {
                        int count = 0;
                        while (true) {
                            isPass = mProfileService.isProfileDataCached();
                            if (isPass || count >= 6) {
                                break;
                            }
                            try {
                                Thread.sleep(500L);
                            } catch (InterruptedException e) {
                            }
                            count++;
                        }
                        if (isPass) {
                            mProfileService.retrieveMyPhonebook(false);
                        }
                    }
                } catch (RemoteException e2) {
                }
            }
        }

        @Override // android.content.ServiceConnection
        public void onServiceDisconnected(ComponentName name) {
            mProfileService = null;
        }
    }

    public boolean hasCommunityAccount(Context context) {
        return (-1 == OperatorServiceCheck.mServiceSubscribe || OperatorServiceCheck.mServiceSubscribe == 0) ? false : true;
    }

    private void initAccount(Context context) {
        AccountManager acocuntManager = AccountManager.get(context);
        Account[] accounts = acocuntManager.getAccounts();
        if (accounts != null) {
            for (Account account : accounts) {
                if ("com.htc.socialnetwork.flickr".equals(account.type) || "com.htc.socialnetwork.facebook".equals(account.type) || "com.htc.socialnetwork.plurk".equals(account.type) || "com.htc.htctwitter".equals(account.type) || "com.htc.twitter".equals(account.type)) {
                    this.mHasSocialAccount = true;
                }
                if ("com.htc.android.mail.eas".equals(account.type) || "com.htc.android.mail".equals(account.type)) {
                    this.mHasMailAccount = true;
                } else if ("com.htc.notes.account".equals(account.type)) {
                    this.mHasNoteAccount = true;
                }
            }
        }
        this.mHasCommunityAccount = hasCommunityAccount(context);
    }

    private String getTwitterWidgetKey(int workspaceId) {
        return workspaceId + "_twitter_widgets";
    }

    private String getDefaultKey(int workspaceId) {
        return workspaceId + "_widgets";
    }

    private void initFavoriteWidgets(Bundle moduleBundle, Context context, int workspaceId) {
        Bundle widgetsBundle;
        if (this.mHasSocialAccount) {
            String key = getTwitterWidgetKey(workspaceId);
            widgetsBundle = moduleBundle.getBundle(key);
            if (widgetsBundle == null) {
                String key2 = getDefaultKey(workspaceId);
                widgetsBundle = moduleBundle.getBundle(key2);
            }
        } else {
            String key3 = getDefaultKey(workspaceId);
            widgetsBundle = moduleBundle.getBundle(key3);
        }
        if (widgetsBundle != null) {
            int size = widgetsBundle.size();
            for (int i = 0; i < size; i++) {
                String key4 = "plenty_set" + (i + 1);
                Bundle childBundle = widgetsBundle.getBundle(key4);
                String showCondition = childBundle.getString("show");
                String hideCondition = childBundle.getString("hide");
                if (shouldShowItem(showCondition, hideCondition)) {
                    String packageName = childBundle.getString(LauncherSettings.WidgetItemTypes.PACKAGE_NAME);
                    String widgetName = childBundle.getString(LauncherSettings.WidgetItemTypes.WIDGET_NAME);
                    WidgetItem item = getWidgetItem(packageName, widgetName);
                    if (item == null) {
                        Log.w("Widget", "package/widget not found : " + packageName + "/" + widgetName);
                    } else {
                        try {
                            String screen = childBundle.getString(LauncherSettings.Favorites.SCREEN);
                            int intScreen = Integer.parseInt(screen);
                            String cellX = childBundle.getString("cell_x");
                            int intCellX = Integer.parseInt(cellX);
                            String cellY = childBundle.getString("cell_y");
                            int intCellY = Integer.parseInt(cellY);
                            Widget widget = item.newWidget();
                            widget.workspaceId = workspaceId;
                            initWidgetProperties(widget, childBundle);
                            LauncherModel.initAddItemToDatabase(context, widget, -100L, intScreen, intCellX, intCellY, false);
                        } catch (Exception e) {
                            Log.w("Widget", "package/widget fail to added : " + packageName + "/" + widgetName);
                        }
                    }
                }
            }
        }
    }

    private void initWidgetProperties(Widget widget, Bundle bundle) throws IOException {
        Properties props = null;
        Set<String> ketSet = bundle.keySet();
        for (String key : ketSet) {
            if (key != null && key.startsWith(PREFIX_PROPERTY)) {
                if (props == null) {
                    props = new Properties();
                }
                String realKey = key.substring(PREFIX_PROPERTY.length());
                String value = bundle.getString(key);
                props.setProperty(realKey, value);
            }
        }
        if (props != null) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            ObjectOutputStream out2 = new ObjectOutputStream(out);
            out2.writeObject(props);
            widget.props = out.toByteArray();
        }
    }

    private void initFxWidgetProperties(FxItemInfo info, Bundle bundle) throws IOException {
        Properties props = null;
        Set<String> ketSet = bundle.keySet();
        for (String key : ketSet) {
            if (key != null && key.startsWith(PREFIX_PROPERTY)) {
                if (props == null) {
                    props = new Properties();
                }
                String realKey = key.substring(PREFIX_PROPERTY.length());
                String value = bundle.getString(key);
                props.setProperty(realKey, value);
            }
        }
        if (props != null) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            ObjectOutputStream out2 = new ObjectOutputStream(out);
            out2.writeObject(props);
            info.data = out.toByteArray();
        }
    }

    private String getPresetFxAppWidgetKey(int workspaceId) {
        return workspaceId + "_fx_widgets";
    }

    private void initFavoriteFxWidgets(Bundle moduleBundle, Context context, int workspaceId) {
        Bundle widgetsBundle;
        if (this.mHasSocialAccount) {
            String key = getTwitterWidgetKey(workspaceId);
            widgetsBundle = moduleBundle.getBundle(key);
            if (widgetsBundle == null) {
                String key2 = getPresetFxAppWidgetKey(workspaceId);
                widgetsBundle = moduleBundle.getBundle(key2);
            }
        } else {
            String key3 = getPresetFxAppWidgetKey(workspaceId);
            widgetsBundle = moduleBundle.getBundle(key3);
        }
        if (widgetsBundle != null) {
            int size = widgetsBundle.size();
            for (int i = 0; i < size; i++) {
                String key4 = "plenty_set" + (i + 1);
                Bundle childBundle = widgetsBundle.getBundle(key4);
                String showCondition = childBundle.getString("show");
                String hideCondition = childBundle.getString("hide");
                if (shouldShowItem(showCondition, hideCondition)) {
                    String packageName = childBundle.getString(LauncherSettings.WidgetItemTypes.PACKAGE_NAME);
                    String providerName = packageName + "/" + childBundle.getString("provider_name");
                    String widgetName = packageName + "/" + childBundle.getString(LauncherSettings.WidgetItemTypes.WIDGET_NAME);
                    String screen = childBundle.getString(LauncherSettings.Favorites.SCREEN);
                    String cellX = childBundle.getString("cell_x");
                    String cellY = childBundle.getString("cell_y");
                    String spanX = childBundle.getString(LauncherSettings.WidgetItemTypes.SPAN_X);
                    String spanY = childBundle.getString(LauncherSettings.WidgetItemTypes.SPAN_Y);
                    try {
                        FxItemInfo fxInfo = new FxItemInfo(providerName, widgetName);
                        fxInfo.widgetId = this.mFxWidgetManager.allocWidgetId();
                        fxInfo.data = null;
                        fxInfo.screen = Integer.parseInt(screen);
                        fxInfo.cellX = Integer.parseInt(cellX);
                        fxInfo.cellY = Integer.parseInt(cellY);
                        fxInfo.spanX = Integer.parseInt(spanX);
                        fxInfo.spanY = Integer.parseInt(spanY);
                        fxInfo.workspaceId = workspaceId;
                        initFxWidgetProperties(fxInfo, childBundle);
                        LauncherModel.initAddItemToDatabase(context, fxInfo, -100L, fxInfo.screen, fxInfo.cellX, fxInfo.cellY, false);
                    } catch (Exception e) {
                        Log.w("Widget", "package/widget fail to added : " + packageName + "/" + widgetName);
                    }
                }
            }
        }
    }

    private String getPresetAppWidgetKey(Context context, int workspaceId) {
        return workspaceId + "_app_widgets";
    }

    private void initFavoriteAppWidgets(Bundle moduleBundle, Context context, int workspaceId) {
        String key = getPresetAppWidgetKey(context, workspaceId);
        ContentResolver cr = context.getContentResolver();
        Bundle widgetsBundle = moduleBundle.getBundle(key);
        if (widgetsBundle != null) {
            int size = widgetsBundle.size();
            ArrayList<ComponentName> bindTargets = new ArrayList<>();
            ArrayList<Integer> bindSources = new ArrayList<>();
            boolean allocatedAppWidgets = false;
            ArrayList<ContentValues> pendingInserts = new ArrayList<>();
            for (int i = 0; i < size; i++) {
                ContentValues values = new ContentValues();
                String key2 = "plenty_set" + (i + 1);
                Bundle childBundle = widgetsBundle.getBundle(key2);
                String showCondition = childBundle.getString("show");
                String hideCondition = childBundle.getString("hide");
                if (shouldShowItem(showCondition, hideCondition)) {
                    String packageName = childBundle.getString(LauncherSettings.WidgetItemTypes.PACKAGE_NAME);
                    String appwidgetProvider = childBundle.getString("app_widget_provider");
                    String screen = childBundle.getString(LauncherSettings.Favorites.SCREEN);
                    int intScreen = Integer.parseInt(screen);
                    String cellX = childBundle.getString("cell_x");
                    int intCellX = Integer.parseInt(cellX);
                    String cellY = childBundle.getString("cell_y");
                    int intCellY = Integer.parseInt(cellY);
                    String spanX = childBundle.getString(LauncherSettings.WidgetItemTypes.SPAN_X);
                    int intSpanX = Integer.parseInt(spanX);
                    String spanY = childBundle.getString(LauncherSettings.WidgetItemTypes.SPAN_Y);
                    int intSpanY = Integer.parseInt(spanY);
                    LauncherAppWidgetInfo info = new LauncherAppWidgetInfo(-1);
                    info.appWidgetComponent = new ComponentName(packageName, appwidgetProvider);
                    if (!info.isTWM_Widget()) {
                        info.appWidgetId = Launcher.sDefaultAppWidgetHost.allocateAppWidgetId();
                        bindSources.add(Integer.valueOf(info.appWidgetId));
                        bindTargets.add(info.appWidgetComponent);
                        allocatedAppWidgets = true;
                    }
                    try {
                        values.put(LauncherSettings.Favorites.ITEM_TYPE, (Integer) 4);
                        values.put("container", (Integer) (-100));
                        values.put(LauncherSettings.Favorites.SCREEN, Integer.valueOf(intScreen));
                        values.put(LauncherSettings.Favorites.CELLX, Integer.valueOf(intCellX));
                        values.put(LauncherSettings.Favorites.CELLY, Integer.valueOf(intCellY));
                        values.put(LauncherSettings.Favorites.SPANX, Integer.valueOf(intSpanX));
                        values.put(LauncherSettings.Favorites.SPANY, Integer.valueOf(intSpanY));
                        values.put("appWidgetId", Integer.valueOf(info.appWidgetId));
                        values.put("workspace_id", Integer.valueOf(workspaceId));
                        values.put("intent", info.appWidgetComponent.flattenToString());
                        pendingInserts.add(values);
                    } catch (RuntimeException ex) {
                        Log.e("Widget", "Problem allocating appWidgetId", ex);
                    }
                }
            }
            cr.bulkInsert(LauncherSettings.Favorites.CONTENT_URI_NO_NOTIFICATION, (ContentValues[]) pendingInserts.toArray(new ContentValues[0]));
            if (allocatedAppWidgets) {
                int[] sourceArray = new int[bindSources.size()];
                for (int i2 = 0; i2 < bindSources.size(); i2++) {
                    sourceArray[i2] = bindSources.get(i2).intValue();
                }
                launchAppWidgetBinder(context, sourceArray, bindTargets);
            }
        }
    }

    public static void launchAppWidgetBinder(Context context, int[] bindSources, ArrayList<ComponentName> bindTargets) {
        Intent intent = new Intent();
        intent.setComponent(new ComponentName(WIDGET_UTILITY_PACKAGE, "com.htc.AddProgramWidget.LauncherAppWidgetBinder"));
        intent.setFlags(268435456);
        Bundle extras = new Bundle();
        extras.putIntArray("com.android.launcher.settings.bindsources", bindSources);
        extras.putParcelableArrayList("com.android.launcher.settings.bindtargets", bindTargets);
        intent.putExtras(extras);
        context.startActivity(intent);
    }

    public WidgetItem getWidgetItem(String packageName, String widgetName) {
        return this.mWidgetItemStringMap.get(packageName + widgetName);
    }

    public WidgetItem getWidgetItem(int itemType) {
        return this.mWidgetItemMap.get(Integer.valueOf(itemType));
    }

    public WidgetProxy newWidget(int itemType, Context context, long widgetId) {
        WidgetProxy proxy;
        if (widgetId != -1 && (proxy = this.mWidgetsMap.get(Long.valueOf(widgetId))) != null) {
            return proxy;
        }
        WidgetItem item = this.mWidgetItemMap.get(Integer.valueOf(itemType));
        if (item == null && itemType >= 1100) {
            removeWidgetsFromDB(context, widgetId);
            return null;
        }
        if (item != null) {
            return item.newWidget();
        }
        return null;
    }

    public static void removeWidgetsFromDB(Context context, long widgetId) {
        if (context != null && widgetId >= 0) {
            ContentResolver contentResolver = context.getContentResolver();
            Log.w("Widget", "removeWidgetsFromDB id=" + widgetId);
            contentResolver.delete(LauncherSettings.Favorites.getContentUri(widgetId, false), null, null);
        }
    }

    public int getWidgetCountOnWorkspace(WidgetItem item) {
        LauncherModel model = Launcher.getModel();
        if (model == null) {
            return 0;
        }
        int count = 0;
        ArrayList<ItemInfo> itemInfos = model.getDesktopItems();
        if (itemInfos == null) {
            return 0;
        }
        ItemInfo[] arrayItemInfo = (ItemInfo[]) itemInfos.toArray(new ItemInfo[0]);
        for (ItemInfo itemInfo : arrayItemInfo) {
            if (item.mItemType == itemInfo.itemType) {
                count++;
            }
        }
        return count;
    }

    public void addWidgetsOnWorkspace(WidgetProxy wProxy) {
        if (!this.mWidgets.contains(wProxy)) {
            wProxy.getWidgetItem();
            this.mWidgets.add(wProxy);
            this.mWidgetsMap.put(Long.valueOf(wProxy.id), wProxy);
        }
    }

    public void removeWidgetsOnWorkspace(WidgetProxy wProxy) {
        wProxy.getWidgetItem();
        this.mWidgetsMap.remove(Long.valueOf(wProxy.id));
        this.mWidgets.remove(wProxy);
    }

    public void removeAllWidgetLayout(Launcher activity) {
        while (this.mWidgets.size() > 0) {
            WidgetProxy proxy = this.mWidgets.remove(0);
            proxy.onLayoutRemoved(activity);
        }
        this.mWidgetsMap.clear();
    }

    public synchronized WidgetPackage getWidgetPackage(String packageName, Context context) {
        WidgetPackage widgetPackage;
        WidgetPackage wPackage = this.mWidgetPackageMap.get(packageName);
        if (wPackage != null) {
            widgetPackage = wPackage;
        } else {
            if (context != null) {
                WidgetPackage wPackage2 = new WidgetPackage();
                try {
                    wPackage2.mPackageContext = context.createPackageContext(packageName, 3);
                    this.mWidgetPackageMap.put(packageName, wPackage2);
                    widgetPackage = wPackage2;
                } catch (PackageManager.NameNotFoundException e) {
                    Log.e("Widget", "widget package not found - " + packageName);
                }
            }
            Log.e("Widget", "no context is given for create WidgetPackage instance (shall not happen) - " + packageName);
            widgetPackage = null;
        }
        return widgetPackage;
    }

    private boolean shouldShowItem(String showCondition, String hideCondition) {
        if (showCondition == null) {
            if (hideCondition == null) {
                return true;
            }
            if (this.mHasSocialAccount && hideCondition.contains(SOCIAL_ACCOUNT)) {
                return false;
            }
            if (this.mHasMailAccount && hideCondition.contains(MAIL_ACCOUNT)) {
                return false;
            }
            if (this.mHasCommunityAccount && hideCondition.contains(COMMUNITY_ACCOUNT)) {
                return false;
            }
            return (!this.mHasMailAccount && this.mHasNoteAccount && hideCondition.contains(NOTES_ACCOUNT)) ? false : true;
        }
        if (this.mHasSocialAccount && showCondition.contains(SOCIAL_ACCOUNT)) {
            return true;
        }
        if (this.mHasMailAccount && showCondition.contains(MAIL_ACCOUNT)) {
            return true;
        }
        if (this.mHasCommunityAccount && showCondition.contains(COMMUNITY_ACCOUNT)) {
            return true;
        }
        if (this.mHasNoteAccount) {
            if (hideCondition != null && hideCondition.contains(MAIL_ACCOUNT) && this.mHasMailAccount) {
                return false;
            }
            if (showCondition.contains(NOTES_ACCOUNT)) {
                return true;
            }
        }
        return false;
    }

    public static String manipulateResourcePath(String fileName) {
        return (fileName == null || !fileName.startsWith(File.separator)) ? WALLPAPER_ROOT_PATH + fileName : fileName;
    }
}
