package com.htc.launcher;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.htc.launcher.OperatorTabManager;
import com.htc.launcher.custom.CustomResourceUtil;
import com.htc.widget.CarouselHost;
import com.htc.widget.CarouselWidget;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
class AllAppsView extends FrameLayout implements DragSource {
    public static final String TAB_ALLAPPS = "tab_allapps";
    public static final String TAB_DOWNLOADED = "tab_downloaded";
    public static final String TAB_FREQUENT = "tab_frequent";
    public static final String TAG = "AllAppsView";
    private int currentContentView;
    boolean inited;
    private String mCurrentTab;
    private TextView mDrag;
    private DragController mDragger;
    private Launcher mLauncher;
    private int mMotionX;
    private int mMotionY;
    private int mOffsetX;
    private int mOffsetY;
    private View mTabContent;
    private CarouselHost mTabHost;
    private CarouselWidget mTabSwitch;
    private int[] mXy;

    interface Content {
        void setContainer(AllAppsView allAppsView);
    }

    public AllAppsView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mCurrentTab = TAB_ALLAPPS;
        this.inited = false;
        this.currentContentView = -1;
        this.mXy = new int[2];
    }

    @Override // android.view.View
    protected void onFinishInflate() {
        super.onFinishInflate();
        for (int i = 0; i < getChildCount(); i++) {
            KeyEvent.Callback childAt = getChildAt(i);
            if (childAt instanceof Content) {
                Content c = (Content) childAt;
                c.setContainer(this);
            }
        }
        this.mTabContent = findViewById(android.R.id.tabcontent);
    }

    public synchronized void initTabs() {
        if (!this.inited) {
            TFC.d(TAG, "initTabs:");
            this.inited = true;
            OperatorTabManager opTabManager = OperatorTabManager.getInstance();
            opTabManager.reload();
            if (opTabManager.getOperatorTabCount() > 0 && opTabManager.getOperatorTabByIndex(0).getInitOrder() == 0) {
                addOperatorTab(this.mTabHost, opTabManager.getOperatorTabByIndex(0));
            }
            Intent intent = new Intent("com.htc.launcher.CarouselDummyActivity");
            intent.putExtra(CarouselDummyActivity.EXTRA_TAB, TAB_ALLAPPS);
            this.mTabHost.addTab(TAB_ALLAPPS, this.mLauncher, R.string.all_apps_tab_all_apps, CustomResourceUtil.getDrawableResIdentifier(getContext(), "common_icon_my_apps_rest", 34079566), CustomResourceUtil.getDrawableResIdentifier(getContext(), "common_icon_my_apps_on", 34079565), CustomResourceUtil.getDrawableResIdentifier(getContext(), "common_icon_overlay_others", 34079666), intent, 101);
            if (opTabManager.getOperatorTabCount() > 0 && 1 == opTabManager.getOperatorTabByIndex(0).getInitOrder()) {
                addOperatorTab(this.mTabHost, opTabManager.getOperatorTabByIndex(0));
            }
            Intent intent2 = new Intent("com.htc.launcher.CarouselDummyActivity");
            intent2.putExtra(CarouselDummyActivity.EXTRA_TAB, TAB_FREQUENT);
            this.mTabHost.addTab(TAB_FREQUENT, this.mLauncher, R.string.all_apps_tab_frequent, CustomResourceUtil.getDrawableResIdentifier(getContext(), "common_icon_starred_rest", 34079772), CustomResourceUtil.getDrawableResIdentifier(getContext(), "common_icon_starred_on", 34079771), CustomResourceUtil.getDrawableResIdentifier(getContext(), "common_icon_overlay_starred", 34079681), intent2, 101);
            if (opTabManager.getOperatorTabCount() > 0 && 2 == opTabManager.getOperatorTabByIndex(0).getInitOrder()) {
                addOperatorTab(this.mTabHost, opTabManager.getOperatorTabByIndex(0));
            }
            Intent intent3 = new Intent("com.htc.launcher.CarouselDummyActivity");
            intent3.putExtra(CarouselDummyActivity.EXTRA_TAB, TAB_DOWNLOADED);
            this.mTabHost.addTab(TAB_DOWNLOADED, this.mLauncher, R.string.all_apps_tab_downloaded, CustomResourceUtil.getDrawableResIdentifier(getContext(), "common_icon_rss_downloads_rest", 34079745), CustomResourceUtil.getDrawableResIdentifier(getContext(), "common_icon_rss_downloads_on", 34079744), CustomResourceUtil.getDrawableResIdentifier(getContext(), "common_icon_overlay_downloads", 34079622), intent3, 101);
            if (opTabManager.getOperatorTabCount() > 0 && 3 <= opTabManager.getOperatorTabByIndex(0).getInitOrder()) {
                addOperatorTab(this.mTabHost, opTabManager.getOperatorTabByIndex(0));
            }
        }
    }

    private void addOperatorTab(CarouselHost carouselHost, OperatorTab opTab) {
        OperatorTabManager.OperatorTabResources opTabRes = OperatorTabManager.getInstance().getResources();
        TFC.d(TAG, "addOperatorTab: opTab=" + opTab);
        this.mTabHost.addTab(opTab.getId(), this.mLauncher, opTabRes.getLabelResId(opTab), opTabRes.getRestIconResId(opTab), opTabRes.getOnIconResId(opTab), opTabRes.getOverlayIconResId(opTab), opTab.getIntent(), opTab.getInitPlace());
    }

    int getContentView() {
        return this.currentContentView;
    }

    void setContentView(int id) {
        this.currentContentView = id;
        for (int i = 0; i < getChildCount(); i++) {
            CarouselHost childAt = getChildAt(i);
            if (this.mTabHost != childAt) {
                if (childAt.getId() == id) {
                    childAt.setVisibility(0);
                } else {
                    childAt.setVisibility(8);
                }
            }
        }
        this.mTabHost.setVisibility(0);
        invalidate();
    }

    List<ViewGroup> getAllContents() {
        List<ViewGroup> views = new ArrayList<>();
        for (int i = 0; i < getChildCount(); i++) {
            CarouselHost childAt = getChildAt(i);
            if (childAt != this.mDrag && childAt != this.mTabHost) {
                views.add((ViewGroup) childAt);
            }
        }
        return views;
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        this.mMotionX = (int) ev.getX();
        this.mMotionY = (int) ev.getY();
        return false;
    }

    View prepareDragView(CharSequence name, Drawable icon) {
        if (this.mDrag == null) {
            this.mDrag = new TextView(getContext());
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2);
            this.mDrag.setLayoutParams(lp);
            this.mDrag.setEnabled(false);
            this.mDrag.setGravity(1);
        }
        this.mDrag.setText(name);
        this.mDrag.setTextColor(-1);
        this.mDrag.setCompoundDrawablesWithIntrinsicBounds((Drawable) null, icon, (Drawable) null, (Drawable) null);
        if (this.mOffsetX == 0) {
            measureChildWithMargins(this.mDrag, 0, 0, 0, 0);
            this.mOffsetX = this.mDrag.getMeasuredWidth() / 2;
            this.mOffsetY = this.mDrag.getMeasuredHeight() / 2;
            getLocationInWindow(this.mXy);
        }
        int x = this.mMotionX + this.mXy[0];
        int y = this.mMotionY + this.mXy[1];
        this.mDrag.layout(x - this.mOffsetX, y - this.mOffsetY, this.mOffsetX + x, this.mOffsetY + y);
        if (!this.mDrag.isDrawingCacheEnabled()) {
            this.mDrag.setDrawingCacheEnabled(true);
            this.mDrag.buildDrawingCache();
        }
        return this.mDrag;
    }

    Launcher getLauncher() {
        return this.mLauncher;
    }

    void setLauncher(Launcher launcher) {
        this.mLauncher = launcher;
        this.mTabSwitch = this.mLauncher.getCarouselWidget();
        this.mTabHost = this.mLauncher.getCarouselHost();
    }

    DragController getDragger() {
        return this.mDragger;
    }

    @Override // com.htc.launcher.DragSource
    public void setDragger(DragController dragger) {
        this.mDragger = dragger;
    }

    @Override // com.htc.launcher.DragSource
    public void onDropCompleted(DropTarget target, boolean success) {
        Logger.d(TAG, "[EDIT_DEBUG] AllAppsView.onDropComplete(" + target + "," + success + ")");
        this.mLauncher.getDesktopItemController().poofFxItem();
        if (this.mDrag.getParent() != null) {
            ((ViewGroup) this.mDrag.getParent()).removeView(this.mDrag);
        }
        this.mDrag.setTag(null);
    }

    protected void removeDragView() {
    }

    public void setTabsVisible(boolean visible) {
        this.mTabSwitch.setVisibility(visible ? 0 : 8);
        this.mTabHost.setVisibility(visible ? 0 : 8);
        findViewById(R.id.carousel_tab_background).setVisibility(visible ? 0 : 8);
        if (this.mTabContent != null) {
            this.mTabContent.setVisibility(visible ? 0 : 8);
        }
    }

    public String getCurrentTab() {
        return this.mTabHost.getCurrentTabTag();
    }
}
