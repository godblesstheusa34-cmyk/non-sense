package com.htc.launcher;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.View;
import com.htc.gl.Instance;
import com.htc.home.HostActivity;
import com.htc.home.HostInterface;
import com.htc.home.Scene;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Properties;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class WidgetHostHandle extends HostActivity implements HostInterface {
    public static final String TAG = "Widget";
    public static boolean localLOGV = false;
    private boolean mEnableScroll;
    private Widget mWidget;

    public WidgetHostHandle(Widget widget, Context base) {
        super(base);
        this.mEnableScroll = true;
        this.mWidget = widget;
    }

    public Properties load() {
        if (this.mWidget.props == null) {
            return null;
        }
        try {
            ByteArrayInputStream in = new ByteArrayInputStream(this.mWidget.props);
            ObjectInputStream in2 = new ObjectInputStream(in);
            Properties props = (Properties) in2.readObject();
            return props;
        } catch (Exception e) {
            if (localLOGV) {
                Log.d(TAG, e.getMessage(), e);
            }
            return null;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public boolean store(Properties props) {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            ObjectOutputStream out2 = new ObjectOutputStream(out);
            out2.writeObject(props);
            this.mWidget.props = out.toByteArray();
            LauncherModel.updateItemInDatabase(this, this.mWidget);
            return true;
        } catch (Exception e) {
            if (localLOGV) {
                Log.d(TAG, e.getMessage(), e);
            }
            return false;
        }
    }

    public Scene getCurrentScene() {
        return WidgetWorkspaceManager.instance().getCurrentScene();
    }

    public boolean onLongClick(View view) {
        Object obj = (Activity) ((HostActivity) this).mActivityRef.get();
        if (obj instanceof Launcher) {
            return ((Launcher) obj).onLongClick(view);
        }
        return false;
    }

    public void enableScroll(boolean enable) {
        this.mEnableScroll = enable;
        Object obj = (Activity) ((HostActivity) this).mActivityRef.get();
        if (obj instanceof Launcher) {
            ((Launcher) obj).getWorkspace().enableScroll(enable);
        }
    }

    public boolean isEnableScroll() {
        return this.mEnableScroll;
    }

    public void onViewInvalidated(View view) {
        Log.e(TAG, "(Deprecated) onViewInvalidated() was called by " + view);
    }

    public void enableGLDrawing(View client, boolean enable) {
        Log.e(TAG, "(Deprecated) enableGLDrawing() was called by " + client);
    }

    public void attach3DObject(Instance instance) {
        Log.e("Rosie_3D", "WidgetHost, (Deprecated) attach3DObject");
    }

    public void detach3DObject(Instance instance) {
        Log.e("Rosie_3D", "WidgetHost, (Deprecated) detach3DObject");
    }

    public void requestRender() {
        Log.e("Rosie_3D", "WidgetHost, (Deprecated) requestRender");
    }

    public void requestPlayAnimation(String AnimName, int frame) {
        Log.e("Rosie_3D", "WidgetHost, (Deprecated) requestPlayAnimation");
    }

    public boolean requestShowWeatherWallpaper(int condition, int icon_x, int icon_y, int icon_w, int icon_h) {
        Log.e("Haolang", "WidgetHost, (Deprecated) requestShowWeatherWallpaper condition = " + condition);
        return false;
    }

    public void requestStopRender() {
        Log.e("Haolang", "WidgetHost, (Deprecated) requestStopRender");
    }
}
