package com.htc.launcher;

import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.htc.launcher.LauncherSettings;
import java.lang.reflect.Array;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class InstallShortcutReceiver extends BroadcastReceiver {
    private static final int INSTALL_SHORTCUT = 100;
    private static final String LOG_TAG = "InstallShortcutReceiver";
    private static final boolean localLOGV = false;
    private static Handler sHandler;
    private static HandlerThread sHandlerThread;

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent data) {
        if (sHandlerThread == null) {
            sHandlerThread = new HandlerThread("InstallShortcutHandler", 10);
            sHandlerThread.start();
            sHandler = new InstallShortcutHandler(sHandlerThread.getLooper());
        }
        Message msg = sHandler.obtainMessage(100);
        msg.obj = new InstallShortcutInfo(context, data);
        sHandler.sendMessage(msg);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static boolean installShortcut(Context context, Intent data) {
        Intent intent = (Intent) data.getParcelableExtra("android.intent.extra.shortcut.INTENT");
        String name = data.getStringExtra("android.intent.extra.shortcut.NAME");
        if (intent.getAction() == null) {
            intent.setAction("android.intent.action.VIEW");
        }
        boolean duplicate = data.getBooleanExtra("duplicate", true);
        if (duplicate || !LauncherModel.shortcutExists(context, name, intent)) {
            Log.d(Launcher.DEBUG_DB_TAG, "installShortcut(), " + data.getStringExtra("android.intent.extra.shortcut.NAME"));
            Launcher.installShortcut(data);
        }
        return true;
    }

    private static boolean findEmptyCell(Context context, int[] xy, int screen) {
        boolean[][] occupied = (boolean[][]) Array.newInstance((Class<?>) Boolean.TYPE, 4, 4);
        ContentResolver cr = context.getContentResolver();
        Cursor c = cr.query(LauncherSettings.Favorites.CONTENT_URI, new String[]{LauncherSettings.Favorites.CELLX, LauncherSettings.Favorites.CELLY, LauncherSettings.Favorites.SPANX, LauncherSettings.Favorites.SPANY}, "screen=? AND workspace_id=0 ", new String[]{String.valueOf(screen)}, null);
        int cellXIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.CELLX);
        int cellYIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.CELLY);
        int spanXIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.SPANX);
        int spanYIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.SPANY);
        while (c.moveToNext()) {
            try {
                int cellX = c.getInt(cellXIndex);
                int cellY = c.getInt(cellYIndex);
                int spanX = c.getInt(spanXIndex);
                int spanY = c.getInt(spanYIndex);
                for (int x = cellX; x < cellX + spanX && x < 4; x++) {
                    for (int y = cellY; y < cellY + spanY && y < 4; y++) {
                        occupied[x][y] = true;
                    }
                }
            } catch (Exception e) {
                c.close();
                return false;
            } catch (Throwable th) {
                c.close();
                throw th;
            }
        }
        c.close();
        return CellInfo.findVacantCell(xy, 1, 1, 4, 4, occupied);
    }

    private static class InstallShortcutHandler extends Handler {
        public InstallShortcutHandler(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == 100) {
                InstallShortcutInfo info = (InstallShortcutInfo) msg.obj;
                Context context = info.mContext;
                Intent data = info.mIntent;
                InstallShortcutReceiver.installShortcut(context, data);
            }
        }
    }

    private static class InstallShortcutInfo {
        private Context mContext;
        private Intent mIntent;

        public InstallShortcutInfo(Context context, Intent intent) {
            this.mContext = context;
            this.mIntent = intent;
        }
    }
}
