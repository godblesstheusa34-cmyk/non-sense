package com.htc.launcher;

import android.content.ContentValues;
import android.view.ViewGroup;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
class UserFolderInfo extends FolderInfo {
    ArrayList<ApplicationInfo> contents = new ArrayList<>();
    DropTarget mDropTarget = null;
    private WeakReference<Observer> mObserver;

    public interface Observer {
        void onDataChanged();
    }

    UserFolderInfo() {
        this.itemType = 2;
    }

    public void add(ApplicationInfo item) {
        this.contents.add(item);
    }

    public void remove(ApplicationInfo item) {
        this.contents.remove(item);
    }

    @Override // com.htc.launcher.FxShortcutInfo, com.htc.launcher.ItemInfo
    void onAddToDatabase(ContentValues values) {
        super.onAddToDatabase(values);
        values.put("title", ((FolderInfo) this).title.toString());
    }

    public void setObserver(Observer observer) {
        this.mObserver = new WeakReference<>(observer);
    }

    public void notifyDataChanged() {
        Observer observer;
        if (this.mObserver != null && (observer = this.mObserver.get()) != null) {
            observer.onDataChanged();
        }
    }

    @Override // com.htc.launcher.FxShortcutInfo, com.htc.launcher.ItemInfo
    public Draggee createItem(Launcher launcher, ViewGroup container) {
        return FolderIcon.fromXml(R.layout.folder_icon, launcher, container, this);
    }

    @Override // com.htc.launcher.FxShortcutInfo, com.htc.launcher.ItemInfo
    public long getId() {
        return this.id;
    }

    public void setDropTarget(DropTarget dropTarget) {
        this.mDropTarget = dropTarget;
    }

    public DropTarget getDropTarget() {
        return this.mDropTarget;
    }
}
