package com.htc.launcher;

import android.content.Context;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.TextView;
import com.htc.fusion.fx.FxScene;
import com.htc.launcher.custom.CustomResourceUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class Folder extends LinearLayout implements DragSource, AdapterView.OnItemLongClickListener, AdapterView.OnItemClickListener, View.OnClickListener, View.OnLongClickListener {
    private boolean mCloneInfo;
    protected Button mCloseButton;
    protected AbsListView mContent;
    protected ApplicationInfo mDragItem;
    protected DragController mDragger;
    protected FolderInfo mInfo;
    protected Launcher mLauncher;
    private int mMotionX;
    private int mMotionY;
    private int[] mXy;

    public Folder(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mXy = new int[2];
        setAlwaysDrawnWithCacheEnabled(false);
    }

    @Override // android.view.View
    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mContent = (AbsListView) findViewById(R.id.content);
        this.mContent.setSelector(CustomResourceUtil.getDrawableResIdentifier(this.mContext, "rosie_grid_selector", R.drawable.grid_selector));
        this.mContent.setOnItemClickListener(this);
        this.mContent.setOnItemLongClickListener(this);
        this.mCloseButton = (Button) findViewById(R.id.close);
        this.mCloseButton.setBackgroundDrawable(getContext().getResources().getDrawable(CustomResourceUtil.getDrawableResIdentifier(this.mContext, "rosie_box_launcher_top", R.drawable.box_launcher_top)));
        this.mCloseButton.setOnClickListener(this);
        this.mCloseButton.setOnLongClickListener(this);
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView parent, View v, int position, long id) {
        Logger.d("DesktopItem", "[EDIT_DEBUG] Folder.onItemClick() position:" + position + ", id:" + id);
        ApplicationInfo app = (ApplicationInfo) parent.getItemAtPosition(position);
        if (app != null && app.intent != null) {
            int[] pos = new int[2];
            v.getLocationOnScreen(pos);
            app.intent.setSourceBounds(new Rect(pos[0], pos[1], pos[0] + v.getWidth(), pos[1] + v.getHeight()));
            this.mLauncher.launchAppType = "RS_folder";
            this.mLauncher.startActivitySafely(app.intent);
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View v) {
        Logger.d("DesktopItem", "[EDIT_DEBUG] Folder.onClick()");
        this.mLauncher.getDesktopItemController().closeFolder(this);
    }

    @Override // android.view.View.OnLongClickListener
    public boolean onLongClick(View v) {
        Logger.d("DesktopItem", "[EDIT_DEBUG] Folder.onLongClick()");
        this.mLauncher.getDesktopItemController().closeFolder(this);
        this.mLauncher.showRenameDialog(this.mInfo);
        return true;
    }

    @Override // android.widget.AdapterView.OnItemLongClickListener
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        Logger.d("DesktopItem", "[EDIT_DEBUG] Folder.onItemLongClick()");
        if (!view.isInTouchMode()) {
            return false;
        }
        this.mDragItem = (ApplicationInfo) parent.getItemAtPosition(position);
        ApplicationInfo app = new ApplicationInfo(this.mDragItem);
        setVisibility(8);
        ApplicationInfo app2 = new ApplicationInfo(app);
        FxItem fxItem = (FxItem) app2.createItem(this.mLauncher, null);
        Logger.d("AllAppsGridView", "[APPS] Info:" + fxItem.getInfo());
        FxScene scene = fxItem.getScene();
        int width = (int) scene.getSize().x;
        int height = (int) scene.getSize().y;
        this.mLauncher.getDesktopItemController().startDragFxWidget(this, fxItem, prepareBounds(width, height));
        Logger.d("DesktopItem", "[EDIT_DEBUG] Folder.onItemLongClick() id:" + app2.id);
        this.mLauncher.getDesktopItemController().closeFolder(this);
        return true;
    }

    void setCloneInfo(boolean cloneInfo) {
        this.mCloneInfo = cloneInfo;
    }

    @Override // com.htc.launcher.DragSource
    public void setDragger(DragController dragger) {
        this.mDragger = dragger;
    }

    @Override // com.htc.launcher.DragSource
    public void onDropCompleted(DropTarget target, boolean success) {
    }

    void setContentAdapter(ListAdapter adapter) {
        this.mContent.setAdapter((AbsListView) adapter);
    }

    void setLauncher(Launcher launcher) {
        this.mLauncher = launcher;
    }

    FolderInfo getInfo() {
        return this.mInfo;
    }

    void onOpen() {
        this.mContent.requestLayout();
    }

    void onClose() {
        Workspace workspace = this.mLauncher.getWorkspace();
        workspace.getChildAt(workspace.getCurrentScreenIndex()).requestFocus();
    }

    void bind(FolderInfo info) {
        this.mInfo = info;
        this.mCloseButton.setText(info.title);
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        this.mMotionX = (int) ev.getX();
        this.mMotionY = (int) ev.getY();
        Logger.d("Folder", "[EDIT_DEBUG] Folder.onInterceptTouchEvent(" + this.mMotionX + "," + this.mMotionY + ")");
        return false;
    }

    private View prepareDragView(AdapterView<?> parent, View view, int position) {
        View view2 = view.findViewById(R.id.name);
        TextView ret = new TextView(getContext());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        ret.setLayoutParams(lp);
        ret.setEnabled(false);
        ret.setGravity(17);
        ret.setTag(view2.getTag());
        ret.setTextColor(-1);
        ret.setText(((TextView) view2).getText());
        ret.setCompoundDrawablesWithIntrinsicBounds((Drawable) null, ((TextView) view2).getCompoundDrawables()[1], (Drawable) null, (Drawable) null);
        measureChildWithMargins(ret, 0, 0, 0, 0);
        int mOffsetX = ret.getMeasuredWidth() / 2;
        int mOffsetY = ret.getMeasuredHeight() / 2;
        getLocationInWindow(this.mXy);
        int x = this.mMotionX + this.mXy[0];
        int y = this.mMotionY + this.mXy[1];
        ret.layout(x - mOffsetX, y - mOffsetY, x + mOffsetX, y + mOffsetY);
        if (!ret.isDrawingCacheEnabled()) {
            ret.setDrawingCacheEnabled(true);
            ret.buildDrawingCache();
        }
        return ret;
    }

    RectF prepareBounds(int width, int height) {
        RectF bounds = new RectF();
        int mOffsetX = width / 2;
        int mOffsetY = height / 2;
        getLocationInWindow(this.mXy);
        int x = this.mMotionX + this.mXy[0];
        int y = this.mMotionY + this.mXy[1];
        bounds.left = x - mOffsetX;
        bounds.top = y - mOffsetY;
        bounds.right = x + mOffsetX;
        bounds.bottom = y + mOffsetY;
        return bounds;
    }
}
