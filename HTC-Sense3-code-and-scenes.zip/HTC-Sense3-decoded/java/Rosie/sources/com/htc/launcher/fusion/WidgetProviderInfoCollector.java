package com.htc.launcher.fusion;

import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;
import com.htc.android.rosie.widget.ProviderInfoHelper;
import com.htc.android.rosie.widget.WidgetProvider;
import com.htc.launcher.fusion.FxWigetProviderMetaData;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public final class WidgetProviderInfoCollector {
    private static final String LOG_TAG = WidgetProviderInfoCollector.class.getSimpleName();
    public static final Intent WIDGET_INTENT = new Intent("com.htc.android.rosie.home.intent.action.UPDATE_WIDGET");

    public static List<WidgetProvider.Info> getWidgetPackages(Context context) {
        String[] projection = ProviderInfoHelper.getProjection(ProviderInfoHelper.DbProjection.INFO);
        Uri widgetProvider = FxWigetProviderMetaData.FxWidgetTableMedata.CONTENT_URI;
        Cursor cur = context.getContentResolver().query(widgetProvider, projection, null, null, null);
        PackageManager pm = context.getPackageManager();
        List<WidgetProvider.Info> widgets = ProviderInfoHelper.fromCusor(pm, cur);
        cur.close();
        return widgets;
    }

    public static List<WidgetProvider.Info.Style> getWidgetStyles(Context context, List<WidgetProvider.Info> providers) {
        if (providers == null || providers.size() <= 0) {
            return null;
        }
        List<WidgetProvider.Info.Style> list = new ArrayList<>();
        for (WidgetProvider.Info i : providers) {
            List<WidgetProvider.Info.Style> styles = getStylesByProviderComponent(context, i.provider);
            if (styles != null && styles.size() > 0) {
                list.addAll(styles);
            }
        }
        return list;
    }

    public static List<WidgetProvider.Info.Style> getStylesByProviderComponent(Context context, ComponentName name) {
        List<WidgetProvider.Info.Style> list = new ArrayList<>();
        StringBuilder selBuilder = new StringBuilder();
        PackageManager pm = context.getPackageManager();
        ContentResolver cr = context.getContentResolver();
        selBuilder.setLength(0);
        selBuilder.append(ProviderInfoHelper.DbColumn.PROVIDER.name).append(" = '").append(name.flattenToShortString()).append("'");
        Cursor c = cr.query(FxWigetProviderMetaData.FxWidgetTableMedata.CONTENT_URI, ProviderInfoHelper.getProjection(ProviderInfoHelper.DbProjection.STYLE), selBuilder.toString(), null, null);
        if (!c.moveToFirst()) {
            c.close();
            return null;
        }
        do {
            WidgetProvider.Info.Style s = ProviderInfoHelper.styleAtCursor(pm, c);
            if (s != null) {
                list.add(s);
            }
        } while (c.moveToNext());
        c.close();
        return list;
    }

    public static WidgetProvider.Info.Style getStyleByComponent(Context context, ComponentName name, String id) {
        StringBuilder selBuilder = new StringBuilder();
        PackageManager pm = context.getPackageManager();
        ContentResolver cr = context.getContentResolver();
        selBuilder.setLength(0);
        selBuilder.append(ProviderInfoHelper.DbColumn.STYLE_COMP_NAME.name).append(" = '").append(name.flattenToShortString()).append("'");
        if (id != null) {
            selBuilder.append(" AND ").append(ProviderInfoHelper.DbColumn.STYLE_TYPE_ID.name).append(" = '").append(id).append("'");
        }
        Cursor c = cr.query(FxWigetProviderMetaData.FxWidgetTableMedata.CONTENT_URI, ProviderInfoHelper.getProjection(ProviderInfoHelper.DbProjection.STYLE), selBuilder.toString(), null, null);
        if (!c.moveToFirst()) {
            Log.d(LOG_TAG, "component not recognized!");
            return null;
        }
        if (c.getCount() > 1) {
            Log.d(LOG_TAG, "more than one style shared the same component! Return the first one found.");
        }
        WidgetProvider.Info.Style s = ProviderInfoHelper.styleAtCursor(pm, c);
        c.close();
        return s;
    }
}
