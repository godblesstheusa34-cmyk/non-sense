package com.htc.launcher.widget;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public interface EasingFunction {
    public static final float INTERPOLATE_PI = 3.14159f;

    float currentResult(float f, float f2, float f3, float f4, float f5);
}
