package com.htc.launcher;

import java.util.ArrayList;
import java.util.HashMap;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class WidgetCategoryManager {
    private HashMap<Integer, Category> mCategoryMap = new HashMap<>();

    public static class Category {
        int mCategoryId;
        int mIconResId;
        int mTextResId;
        private ArrayList<WidgetItem> mWidgetItems = new ArrayList<>();
    }

    public Category[] listCategories() {
        return (Category[]) this.mCategoryMap.values().toArray(new Category[0]);
    }

    public void bindCategory(WidgetItem item) {
        int origCatId = item.getCategoryId();
        Category category = getOrCreateCategory(translateCatId(origCatId));
        category.mWidgetItems.add(item);
    }

    public void unbindCategory(WidgetItem item) {
        int origCatId = item.getCategoryId();
        Category category = getOrCreateCategory(translateCatId(origCatId));
        category.mWidgetItems.remove(item);
    }

    private static int translateCatId(int original) {
        switch (original) {
            case 200:
                return 200;
            case AddAdapter.ITEM_CATEGORY_CHT_WIDGET /* 300 */:
                return AddAdapter.ITEM_CATEGORY_CHT_WIDGET;
            default:
                return 100;
        }
    }

    public static Category createCategory(int catId) {
        Category category = new Category();
        switch (catId) {
            case 200:
                category.mCategoryId = 200;
                return category;
            case AddAdapter.ITEM_CATEGORY_CHT_WIDGET /* 300 */:
                category.mCategoryId = AddAdapter.ITEM_CATEGORY_CHT_WIDGET;
                return category;
            default:
                category.mCategoryId = 100;
                return category;
        }
    }

    public boolean hasCategory(int catId) {
        Category category = this.mCategoryMap.get(Integer.valueOf(catId));
        return category != null;
    }

    public ArrayList<WidgetItem> getItems(int catId) {
        Category category = this.mCategoryMap.get(Integer.valueOf(catId));
        return category != null ? category.mWidgetItems : new ArrayList<>();
    }

    private synchronized Category getOrCreateCategory(int catId) {
        Category category;
        category = this.mCategoryMap.get(Integer.valueOf(catId));
        if (category == null) {
            category = createCategory(catId);
            this.mCategoryMap.put(Integer.valueOf(category.mCategoryId), category);
        }
        return category;
    }
}
