package com.htc.launcher;

import android.content.Context;
import android.content.Intent;
import android.os.Process;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public final class AddListAdapter extends BaseAdapter {
    public static boolean localLOGV = false;
    private boolean isAddAdapterReady;
    private Launcher mLauncher;
    private LoadAddAdapterThread mLoadAddAdapterThread;
    private AddAdapter mAdapter = null;
    private int mLevel = 0;
    private boolean mIsAssignFunction = false;
    private int[] mSelected = new int[10];
    private int[] mKeepPosition = new int[10];

    public interface OnAddAdapterListener {
        void onItemSelected();
    }

    public AddListAdapter(Launcher launcher, Context context, boolean forFolder) {
        this.isAddAdapterReady = false;
        this.mLauncher = null;
        this.mLoadAddAdapterThread = null;
        this.mLauncher = launcher;
        for (int i = 0; i < this.mKeepPosition.length; i++) {
            this.mKeepPosition[i] = 0;
        }
        if (this.mAdapter == null) {
            this.isAddAdapterReady = false;
            this.mLoadAddAdapterThread = new LoadAddAdapterThread();
            this.mLoadAddAdapterThread.start();
        }
    }

    public void setHeightPriority() {
        if (this.mLoadAddAdapterThread.isAlive()) {
            this.mLoadAddAdapterThread.needUpSpeed();
        }
    }

    class LoadAddAdapterThread extends Thread {
        private int mTid = -1;

        LoadAddAdapterThread() {
        }

        public void needUpSpeed() {
            if (this.mTid != -1) {
                Process.setThreadPriority(this.mTid, -2);
            }
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            if (AddListAdapter.this.mLauncher == null) {
                Log.e("AddListAdapter", "LoadAddAdapterThread run but mLauncher is null.");
                return;
            }
            this.mTid = Process.myTid();
            Process.setThreadPriority(19);
            AddListAdapter.this.mAdapter = new AddAdapter(AddListAdapter.this.mLauncher);
            AddListAdapter.this.isAddAdapterReady = true;
            AddListAdapter.this.mLauncher.refreshAddToHomeAdapter();
        }
    }

    public void resetItems() {
        if (this.isAddAdapterReady && this.mAdapter != null) {
            this.mAdapter.resetItems();
        }
    }

    @Override // android.widget.Adapter
    public Object getItem(int idx) {
        return Integer.valueOf(idx);
    }

    @Override // android.widget.Adapter
    public int getCount() {
        if (this.isAddAdapterReady && this.mAdapter != null) {
            return this.mAdapter.getCount();
        }
        return 0;
    }

    public int getTitleString() {
        if (!this.isAddAdapterReady) {
            return R.string.menu_personalize;
        }
        if (this.mAdapter != null) {
            return this.mAdapter.getTitleString();
        }
        return 0;
    }

    @Override // android.widget.Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        if (this.isAddAdapterReady) {
            return this.mAdapter.getView(position, convertView, parent);
        }
        return null;
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public int getItemViewType(int position) {
        if (this.mAdapter == null) {
            return 0;
        }
        return this.mAdapter.getItemViewType(position);
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public int getViewTypeCount() {
        return 6;
    }

    @Override // android.widget.Adapter
    public long getItemId(int arg0) {
        return 0L;
    }

    public void setClick(int selectedId, int position) {
        if (this.isAddAdapterReady) {
            this.mLevel++;
            this.mSelected[this.mLevel] = selectedId;
            this.mKeepPosition[this.mLevel] = position;
            this.mAdapter.setAdapter(this.mLevel, selectedId, this.mIsAssignFunction);
            notifyDataSetChanged();
        }
    }

    public void callback() {
        if (this.isAddAdapterReady) {
            this.mLevel--;
            this.mAdapter.setAdapter(this.mLevel, this.mSelected[this.mLevel], this.mIsAssignFunction);
            notifyDataSetChanged();
        }
    }

    public int getKeepPosition() {
        if (this.mAdapter == null) {
            return 0;
        }
        int keepPosition = 0;
        if (this.mLevel + 1 > 0 && this.mLevel + 1 < this.mKeepPosition.length) {
            keepPosition = this.mKeepPosition[this.mLevel + 1];
            if (keepPosition < 0 || keepPosition > this.mAdapter.getCount()) {
                keepPosition = 0;
            }
            this.mKeepPosition[this.mLevel + 1] = 0;
        }
        if (this.mLevel == 0) {
            return 0;
        }
        return keepPosition;
    }

    public void reset(boolean isAssignFunction) {
        this.mIsAssignFunction = isAssignFunction;
        if (this.isAddAdapterReady) {
            this.mLevel = 0;
            if (!this.mIsAssignFunction) {
                this.mLauncher.resetMiddleButton();
            }
            this.mAdapter.setAdapter(this.mLevel, 0, this.mIsAssignFunction);
            notifyDataSetChanged();
        }
    }

    public int getLevel() {
        return this.mLevel;
    }

    public void updateSummary() {
        if (this.mAdapter != null) {
            this.mAdapter.updateSummary();
        }
    }

    public void onSummaryUpdate(Intent intent) {
        if (this.mAdapter != null) {
            this.mAdapter.onSummaryUpdate(intent);
        }
    }

    @Override // android.widget.BaseAdapter, android.widget.ListAdapter
    public boolean isEnabled(int position) {
        if (this.mAdapter != null) {
            return this.mAdapter.isEnabled(position);
        }
        return true;
    }
}
