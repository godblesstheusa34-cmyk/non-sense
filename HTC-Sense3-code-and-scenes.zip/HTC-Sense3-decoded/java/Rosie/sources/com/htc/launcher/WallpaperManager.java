package com.htc.launcher;

import android.app.WallpaperInfo;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import com.htc.launcher.settings.SettingUtil;
import java.util.Arrays;
import java.util.List;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class WallpaperManager {
    private static List<String> mCircularWallpapers;
    private static List<String> mCustomPauseWallpapers;
    private static android.app.WallpaperManager mSys;
    private boolean mIsCircularWallpaper;
    private boolean mIsCustomPauseWallpaper;
    private Bitmap mWallpaper;
    private int mWallpaperHeight;
    private boolean mWallpaperLoaded;
    private int mWallpaperWidth;
    private float mXOffset;
    public static String COMMAND_WALLPAPER_PAUSE = "com.htc.launcher.COMMAND_WALLPAPER_PAUSE";
    public static String COMMAND_WALLPAPER_RESUME = "com.htc.launcher.COMMAND_WALLPAPER_RESUME";
    private static WallpaperManager mWallpaperManager = new WallpaperManager();

    private WallpaperManager() {
    }

    public static WallpaperManager getInstance(Context context) {
        if (Launcher.sUseWallpaperService && mSys == null) {
            mSys = android.app.WallpaperManager.getInstance(context);
            mCircularWallpapers = Arrays.asList(context.getResources().getStringArray(R.array.circular_wallpapers));
            mCustomPauseWallpapers = Arrays.asList(context.getResources().getStringArray(R.array.custom_pause_wallpapers));
            mWallpaperManager.updateWallpaperInfo();
        }
        return mWallpaperManager;
    }

    public void setWallpaperOffsetSteps(float xSteps, float ySteps) {
        if (mSys != null) {
            mSys.setWallpaperOffsetSteps(xSteps, ySteps);
        }
    }

    public void setWallpaperOffsets(IBinder token, float xOffset, float yOffset) {
        if (SettingUtil.usesRingSlide()) {
            if (!isCircularWallpaper()) {
                xOffset = 0.5f;
            }
            yOffset = 0.5f;
        }
        if (mSys != null) {
            mSys.setWallpaperOffsets(token, xOffset, yOffset);
        }
        this.mXOffset = xOffset;
    }

    public void onMeasure(Context context, int width, int height, int widthMeasureSpec, int heightMeasureSpec) {
        if (this.mWallpaperLoaded) {
            this.mWallpaperLoaded = false;
            this.mWallpaper = Utilities.centerToFit(this.mWallpaper, width, View.MeasureSpec.getSize(heightMeasureSpec), context);
            this.mWallpaperWidth = this.mWallpaper.getWidth();
            this.mWallpaperHeight = this.mWallpaper.getHeight();
        }
    }

    public void sendWallpaperCommand(IBinder windowToken, String action, int x, int y, int z, Bundle extras) {
        if (mSys != null) {
            mSys.sendWallpaperCommand(windowToken, action, x, y, z, extras);
        }
    }

    public void drawWallpaper(Canvas canvas, int screenWidth, int scrollX, int top, int bottom, Paint paint) {
    }

    public void setStaticWallpaper(Bitmap wallpaper) {
        if (wallpaper != this.mWallpaper) {
            this.mWallpaper = wallpaper;
            this.mWallpaperLoaded = true;
        }
    }

    public boolean isCircularWallpaper() {
        return this.mIsCircularWallpaper;
    }

    public void pauseWallpaper(IBinder binder, boolean pauseOrResume) {
        Log.d("Wallpaper", "pauseWallpaper: " + pauseOrResume);
        if (SettingUtil.shouldFreezeWallpaper() && mSys != null) {
            if (isCustomPauseWallpaper()) {
                mSys.sendWallpaperCommand(binder, pauseOrResume ? COMMAND_WALLPAPER_PAUSE : COMMAND_WALLPAPER_RESUME, 0, 0, 0, null);
            } else {
                mSys.sendWallpaperCommand(binder, pauseOrResume ? "android.wallpaper.stop.render" : "android.wallpaper.resume.render", 0, 0, 0, null);
            }
        }
    }

    public boolean isCustomPauseWallpaper() {
        return this.mIsCustomPauseWallpaper;
    }

    public WallpaperInfo updateWallpaperInfo() {
        if (mSys == null) {
            return null;
        }
        WallpaperInfo info = mSys.getWallpaperInfo();
        if (info != null && mCircularWallpapers != null && mCircularWallpapers.contains(info.getServiceName())) {
            this.mIsCircularWallpaper = true;
        } else {
            this.mIsCircularWallpaper = false;
        }
        if (info != null && mCustomPauseWallpapers != null && mCustomPauseWallpapers.contains(info.getServiceName())) {
            this.mIsCustomPauseWallpaper = true;
        } else {
            this.mIsCustomPauseWallpaper = false;
        }
        Log.d("Wallpaper", "info: " + (info != null ? info.getServiceName() : "null") + ", circular? " + this.mIsCircularWallpaper + ", customPause? " + this.mIsCustomPauseWallpaper);
        return info;
    }

    public WallpaperInfo getWallpaperInfo() {
        if (mSys == null) {
            return null;
        }
        return mSys.getWallpaperInfo();
    }
}
