package com.htc.launcher.config;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class FavoriteData {
    public static final int ITEM_APPLICATION = 0;
    public static final int ITEM_SHORTCUT = 1;
    public String className;
    public String icon;
    public String packageName;
    public int removable;
    public int screen;
    public String title;
    public String url;
    public int x;
    public int y;
    public int itemtype = 1;
    public int workspaceId = 1;
}
