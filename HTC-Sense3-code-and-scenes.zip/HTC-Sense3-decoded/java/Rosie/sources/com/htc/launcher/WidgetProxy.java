package com.htc.launcher;

import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import com.android.common.speech.LoggingEvents;
import com.htc.home.WidgetItemInterface;
import com.htc.home.WidgetViewInterface;
import com.htc.home.WidgetVisibilityObserver;
import java.lang.ref.WeakReference;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class WidgetProxy extends Widget {
    private static final String TAG = "Widget";
    private static final boolean localLOGV = false;
    private WidgetItemInterface mClientWidgetItem;
    private WidgetViewInterface mClientWidgetView;
    private WeakReference<Launcher> mRefLauncher;
    public WidgetVisibilityObserver mVisibilityObserver;
    private WidgetHostHandle mWidgetHostHandle;
    private WidgetItem mWidgetItem;
    private WidgetPackage mWidgetPackage;
    public boolean isAddedConfirmed = false;
    View mView = null;

    public WidgetProxy(WidgetItem widgetItem, WidgetItemInterface clientWidgetItem) {
        this.mWidgetItem = widgetItem;
        this.mClientWidgetItem = clientWidgetItem;
        this.mWidgetPackage = WidgetPackageManager.instanceNoScan().getWidgetPackage(this.mWidgetItem.mPackageName, null);
        this.itemType = widgetItem.mItemType;
        long begin = System.currentTimeMillis();
        try {
            this.mClientWidgetView = this.mClientWidgetItem.createWidgetView();
            if (this.mClientWidgetView instanceof WidgetVisibilityObserver) {
                this.mVisibilityObserver = this.mClientWidgetView;
            }
        } catch (Throwable th) {
            Log.e("Widget", "onLayoutInflated Error !", th);
        } finally {
            long end = System.currentTimeMillis();
            long j = end - begin;
        }
        if (this.mClientWidgetView == null) {
            throw new IllegalStateException("return null when createWidgetView");
        }
        this.spanX = this.mClientWidgetView.getSpanX();
        this.spanY = this.mClientWidgetView.getSpanY();
        this.layoutResource = this.mClientWidgetView.getLayoutResource();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void onLayoutInflated(Launcher launcher, View view, Intent backIntent) {
        if (!launcher.isLauncherDestroyed()) {
            long begin = System.currentTimeMillis();
            try {
                if (this.mWidgetHostHandle == null) {
                    this.mWidgetHostHandle = new WidgetHostHandle(this, launcher.getApplicationContext());
                }
                this.mWidgetHostHandle.attachActivity(launcher);
                this.mClientWidgetView.setHost(this.mWidgetHostHandle);
                this.mClientWidgetView.setHostActivity(this.mWidgetHostHandle);
                this.mRefLauncher = new WeakReference<>(launcher);
                this.mView = view;
                this.mClientWidgetView.onLayoutInflated(view, ((int) this.id) + Launcher.WIDGET_ID_OFFSET, backIntent);
            } catch (Throwable th) {
                Log.e("Widget", "onLayoutInflated Error !", th);
            } finally {
                long end = System.currentTimeMillis();
                long j = end - begin;
            }
            launcher.mWidgetsManager.addWidgetsOnWorkspace(this);
        }
    }

    public void onLayoutRemoved(Launcher activity) {
        long begin = System.currentTimeMillis();
        try {
            this.mClientWidgetView.onLayoutRemoved();
            this.mView = null;
        } catch (Throwable th) {
            Log.e("Widget", "onLayoutRemoved Error !", th);
        } finally {
            long end = System.currentTimeMillis();
            long j = end - begin;
        }
        activity.mWidgetsManager.removeWidgetsOnWorkspace(this);
        this.mClientWidgetView = null;
        this.mVisibilityObserver = null;
    }

    public View inflate(Launcher activity, ViewGroup root, Intent backIntent) {
        long begin = System.currentTimeMillis();
        try {
            WidgetLayoutInfalter inflater = this.mWidgetPackage.getLayoutInflater();
            View view = inflater.inflate(this.layoutResource, root, false);
            onLayoutInflated(activity, view, backIntent);
            return view;
        } finally {
            long end = System.currentTimeMillis();
            long j = end - begin;
        }
    }

    public void fireOnResume() {
        this.isAddedConfirmed = true;
        this.mVisibilityObserver.fireOnResume(10);
    }

    public String getSettingIntent() {
        if (this.mVisibilityObserver == null) {
            return null;
        }
        return this.mVisibilityObserver.getSettingIntent();
    }

    public View inflate(Launcher activity, ViewGroup root, boolean attachToRoot) {
        long begin = System.currentTimeMillis();
        try {
            WidgetLayoutInfalter inflater = this.mWidgetPackage.getLayoutInflater();
            View view = inflater.inflate(this.layoutResource, root, attachToRoot);
            onLayoutInflated(activity, view, null);
            if (this.mVisibilityObserver != null && this.mVisibilityObserver.getNotifyType() != 40) {
                if (Launcher.getScreen() == this.screen) {
                    this.mVisibilityObserver.fireOnResume(10);
                } else {
                    this.mVisibilityObserver.fireOnPause(10);
                }
            }
            this.isAddedConfirmed = true;
            return view;
        } finally {
            long end = System.currentTimeMillis();
            long j = end - begin;
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {
            this.mClientWidgetView.onActivityResult(requestCode, resultCode, data);
        } catch (Throwable ex) {
            Log.e("Widget", "onActivityResult Error !", ex);
        }
    }

    public void onActivityDestroy() {
        this.isAddedConfirmed = false;
        if (this.mRefLauncher != null) {
            this.mClientWidgetView.onActivityDestroy();
            this.mRefLauncher = null;
        }
    }

    public String getName() {
        return this.mClientWidgetItem.getName();
    }

    public WidgetItem getWidgetItem() {
        return this.mWidgetItem;
    }

    public WidgetViewInterface getWidgetView() {
        return this.mClientWidgetView;
    }

    public int getScreen() {
        return this.screen;
    }

    @Override // com.htc.launcher.ItemInfo
    public String getUlog() {
        String ret = WidgetPackageManager.instanceNoScan().getWidgetItem(this.itemType).mPackageName + ", htcwidget, " + this.screen + ", " + this.cellX + ", " + this.cellY + ", " + this.spanX + ", " + this.spanY;
        if (this.screen < 0 || this.screen > max_screen) {
            return LoggingEvents.EXTRA_CALLING_APP_NAME;
        }
        return ret;
    }

    @Override // com.htc.launcher.ItemInfo
    public boolean isItemEditable() {
        String setting = getSettingIntent();
        return setting != null && setting.length() > 0;
    }

    @Override // com.htc.launcher.ItemInfo
    public void editItem() {
    }
}
