package com.htc.launcher;

import android.appwidget.AppWidgetHostView;
import android.content.ComponentName;
import android.content.ContentValues;
import android.view.ViewGroup;
import com.android.common.speech.LoggingEvents;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
class LauncherAppWidgetInfo extends ItemInfo {
    int appWidgetId;
    AppWidgetHostView hostView = null;
    ComponentName appWidgetComponent = null;

    LauncherAppWidgetInfo(int appWidgetId) {
        this.itemType = 4;
        this.appWidgetId = appWidgetId;
    }

    @Override // com.htc.launcher.ItemInfo
    void onAddToDatabase(ContentValues values) {
        super.onAddToDatabase(values);
        values.put("appWidgetId", Integer.valueOf(this.appWidgetId));
        values.put("intent", this.appWidgetComponent.flattenToString());
    }

    @Override // com.htc.launcher.ItemInfo
    public String toString() {
        return Integer.toString(this.appWidgetId);
    }

    @Override // com.htc.launcher.ItemInfo
    public String getUlog() {
        String appTitle = "none";
        if (this.appWidgetComponent != null) {
            appTitle = this.appWidgetComponent.flattenToShortString();
        }
        String ret = appTitle + ", shortcut, " + this.screen + ", " + this.cellX + ", " + this.cellY + ", " + this.spanX + ", " + this.spanY;
        if (this.screen < 0 || this.screen > max_screen) {
            return LoggingEvents.EXTRA_CALLING_APP_NAME;
        }
        return ret;
    }

    public boolean isTWM_Widget() {
        String currentWidgetName = this.appWidgetComponent.flattenToString();
        return currentWidgetName.equals("com.taiwanmobile.pt.stock/com.taiwanmobile.pt.stock.appwidget.StockWidget") || currentWidgetName.equals("com.taiwanmobile.pt.news/com.taiwanmobile.pt.news.appwidget.newsWidget");
    }

    @Override // com.htc.launcher.ItemInfo
    public Draggee createItem(Launcher launcher, ViewGroup container) {
        return null;
    }

    @Override // com.htc.launcher.ItemInfo
    public long getId() {
        return this.appWidgetId;
    }
}
