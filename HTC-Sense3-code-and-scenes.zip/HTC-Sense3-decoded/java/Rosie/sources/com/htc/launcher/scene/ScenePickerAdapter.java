package com.htc.launcher.scene;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckedTextView;
import android.widget.ImageView;
import com.android.common.speech.LoggingEvents;
import com.htc.launcher.LauncherIntent;
import com.htc.launcher.R;
import com.htc.launcher.WidgetWorkspace;
import com.htc.launcher.WidgetWorkspaceManager;
import com.htc.launcher.custom.CustomResourceUtil;
import com.htc.launcher.widget.HtcSimpleSeparable;
import com.htc.widget.DecorFlow;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class ScenePickerAdapter extends BaseAdapter {
    public static final int DELETE_MODE = 1;
    public static final String ICON_PATH = "/data/data/com.htc.launcher/files/scenes_picker_list_";
    public static final String ICON_PATH_LAND = "/data/data/com.htc.launcher/files/scenes_picker_list_land_";
    private static final long INVALID_ID = -1;
    private static final int NOTIFIED_DATASET_CHANGED = 100;
    public static final String PREVIEW_PATH = "/data/data/com.htc.launcher/files/scenes_picker_";
    public static final String PREVIEW_PATH_LAND = "/data/data/com.htc.launcher/files/scenes_picker_land_";
    public static final int SELECT_MODE = 0;
    public static final String STRING_FORMAT_ICON_PATH = "/data/data/com.htc.launcher/files/scenes_picker_list_%d.png";
    public static final String STRING_FORMAT_ICON_PATH_LAND = "/data/data/com.htc.launcher/files/scenes_picker_list_land_%d.png";
    public static final String STRING_FORMAT_PREVIEW_PATH = "/data/data/com.htc.launcher/files/scenes_picker_%d.png";
    public static final String STRING_FORMAT_PREVIEW_PATH_LAND = "/data/data/com.htc.launcher/files/scenes_picker_land_%d.png";
    private static final String TAG = "ScenePickerAdapter";
    private static final int VIEW_TYPE_DELETE_ITEM = 3;
    private static final int VIEW_TYPE_GALLERY_DELETE_ITEM = 5;
    private static final int VIEW_TYPE_GALLERY_ITEM = 4;
    private static final int VIEW_TYPE_SELECTED_ITEM = 1;
    private static final int VIEW_TYPE_UNDELETE_ITEM = 2;
    private static final int VIEW_TYPE_UNSELECTED_ITEM = 0;
    private static final boolean localLOGV = true;
    private static ArrayList<ScenePickerItem> mItems;
    private static WidgetWorkspaceManager mWidgetWorkspaceManager;
    private Context mContext;
    private int mCurrentSceneId;
    private LayoutInflater mInflater;
    private boolean mIsPanelMode;
    private int mSelectSceneId;
    private LauncherHandler mHandler = new LauncherHandler();
    private int mCurrentMode = 0;
    private boolean mIsDeleteCurrentScene = false;

    public ScenePickerAdapter(Context context) {
        this.mInflater = (LayoutInflater) context.getSystemService("layout_inflater");
        this.mContext = context;
        mWidgetWorkspaceManager = WidgetWorkspaceManager.instance(this.mContext);
        init();
    }

    public void update() {
        if (mItems == null) {
            init();
            return;
        }
        WidgetWorkspaceManager wm = WidgetWorkspaceManager.instance(this.mContext);
        System.currentTimeMillis();
        WidgetWorkspace[] widgetWorkspaces = wm.listWorkspace();
        int currentSceneId = wm.getCurrentWorkspaceId();
        Log.d(TAG, "currentSceneId = " + currentSceneId);
        int size = widgetWorkspaces.length;
        ArrayList<ScenePickerItem> tempItems = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            int sceneId = widgetWorkspaces[i].id;
            boolean sceneExist = false;
            Iterator i$ = mItems.iterator();
            while (true) {
                if (!i$.hasNext()) {
                    break;
                }
                ScenePickerItem scene = i$.next();
                if (scene.getId() == sceneId) {
                    if (sceneId == currentSceneId) {
                        mItems.remove(scene);
                        ScenePickerItem item = new ScenePickerItem(widgetWorkspaces[i].displayName, widgetWorkspaces[i].id, null, null, widgetWorkspaces[i].translate_id);
                        item.setPreview(getPanelViewBitmap(this.mContext, item, true));
                        item.setIcon(getPanelViewBitmap(this.mContext, item, false));
                        item.setMarked(scene.isMarked());
                        tempItems.add(item);
                        this.mCurrentSceneId = sceneId;
                    } else {
                        tempItems.add(scene);
                        mItems.remove(scene);
                    }
                    sceneExist = true;
                }
            }
            if (!sceneExist) {
                ScenePickerItem item2 = new ScenePickerItem(widgetWorkspaces[i].displayName, widgetWorkspaces[i].id, null, null, widgetWorkspaces[i].translate_id);
                item2.setPreview(getPanelViewBitmap(this.mContext, item2, true));
                item2.setIcon(getPanelViewBitmap(this.mContext, item2, false));
                tempItems.add(item2);
                Log.d(TAG, "create scene " + item2.getId() + LoggingEvents.EXTRA_CALLING_APP_NAME);
            }
        }
        if (mItems.size() != 0) {
            Log.d(TAG, "There are still " + mItems.size() + " scenes do not copy to tempItems");
        }
        mItems = tempItems;
        notifyDataSetChanged();
    }

    private void init() {
        WidgetWorkspaceManager wm = WidgetWorkspaceManager.instance(this.mContext);
        long startTime = System.currentTimeMillis();
        WidgetWorkspace[] widgetWorkspaces = wm.listWorkspace();
        int currentSceneId = wm.getCurrentWorkspaceId();
        Log.d(TAG, "currentSceneId = " + currentSceneId);
        int size = widgetWorkspaces.length;
        mItems = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            mItems.add(new ScenePickerItem(widgetWorkspaces[i].displayName, widgetWorkspaces[i].id, null, null, widgetWorkspaces[i].translate_id));
            Log.d(TAG, "widgetWorkspaces[" + i + "], displayName = " + widgetWorkspaces[i].displayName + ", id = " + widgetWorkspaces[i].id + ",  widgetWorkspaces[i].translate_id = " + widgetWorkspaces[i].translate_id);
            if (currentSceneId == widgetWorkspaces[i].id) {
                this.mSelectSceneId = currentSceneId;
                this.mCurrentSceneId = currentSceneId;
            }
        }
        notifyDataSetChanged();
        Log.d(TAG, "initial data takes " + (System.currentTimeMillis() - startTime) + " ms");
    }

    private void startLoadImage() {
        PreviewLoader previewLoader = new PreviewLoader();
        previewLoader.start();
    }

    private class PreviewLoader extends Thread {
        private PreviewLoader() {
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            long startTime = System.currentTimeMillis();
            super.run();
            for (int i = 0; i < ScenePickerAdapter.mItems.size(); i++) {
                ScenePickerItem item = (ScenePickerItem) ScenePickerAdapter.mItems.get(i);
                item.setPreview(ScenePickerAdapter.getPanelViewBitmap(ScenePickerAdapter.this.mContext, item, true));
                item.setIcon(ScenePickerAdapter.getPanelViewBitmap(ScenePickerAdapter.this.mContext, item, false));
            }
            ScenePickerAdapter.this.mHandler.sendEmptyMessage(100);
            Log.d(ScenePickerAdapter.TAG, "load preview image complete takes " + (System.currentTimeMillis() - startTime) + " ms");
        }
    }

    @Override // android.widget.Adapter
    public int getCount() {
        if (mItems == null) {
            return 0;
        }
        return mItems.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int position) {
        if (mItems == null || position >= mItems.size()) {
            return null;
        }
        return mItems.get(position);
    }

    @Override // android.widget.Adapter
    public long getItemId(int position) {
        return (mItems == null || position >= mItems.size()) ? INVALID_ID : mItems.get(position).getId();
    }

    public String getItemName(long id) {
        if (mItems == null) {
            return null;
        }
        for (int i = 0; i < mItems.size(); i++) {
            if (mItems.get(i).getId() == id) {
                return mItems.get(i).getName();
            }
        }
        return null;
    }

    @Override // android.widget.Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        View temp;
        View temp2;
        if (mItems == null) {
            return null;
        }
        if (this.mIsPanelMode) {
            if (convertView != null) {
                temp2 = convertView;
            } else {
                temp2 = this.mInflater.inflate(R.layout.panel_picker_item, (ViewGroup) null);
                PanelViewHolder viewHolder = new PanelViewHolder();
                viewHolder.mImageView = (ImageView) temp2.findViewById(R.id.panel_picker_preview);
                viewHolder.mDeleteIcon = (ImageView) temp2.findViewById(R.id.panel_picker_delete);
                temp2.setTag(viewHolder);
                temp2.setLayoutParams(new DecorFlow.LayoutParams(-2, -2));
                switch (getItemViewType(position)) {
                    case 4:
                        viewHolder.mDeleteIcon.setVisibility(8);
                        viewHolder.mImageView.setAlpha(255);
                        viewHolder.mImageView.setBackgroundColor(-16777216);
                        break;
                    case 5:
                        viewHolder.mDeleteIcon.setVisibility(0);
                        viewHolder.mImageView.setAlpha(127);
                        viewHolder.mImageView.setBackgroundColor(-16777216);
                        break;
                }
            }
            PanelViewHolder viewHolder2 = (PanelViewHolder) temp2.getTag();
            Bitmap tmp = mItems.get(position).getPreview();
            if (tmp == null) {
                tmp = getPanelViewBitmap(this.mContext, mItems.get(position), true);
                mItems.get(position).setPreview(tmp);
            }
            switch (getItemViewType(position)) {
                case 4:
                    viewHolder2.mImageView.setImageDrawable(new FastBitmapDrawable(this.mContext.getResources(), tmp));
                    break;
                case 5:
                    viewHolder2.mImageView.setImageDrawable(new BitmapDrawable(this.mContext.getResources(), tmp));
                    break;
            }
            return temp2;
        }
        if (convertView != null) {
            temp = convertView;
        } else {
            temp = this.mInflater.inflate(R.layout.scene_list_item, (ViewGroup) null);
            ListViewHolder viewHolder3 = new ListViewHolder("notHeader");
            viewHolder3.mImageView = (ImageView) temp.findViewById(R.id.scene_list_item_icon);
            viewHolder3.mCheckedTextView = (CheckedTextView) temp.findViewById(R.id.scene_list_item_name);
            int markID = CustomResourceUtil.getDrawableResIdentifier(this.mContext, "common_radiobutton", 0);
            if (markID != 0) {
                viewHolder3.mCheckedTextView.setCheckMarkDrawable(markID);
            }
            switch (getItemViewType(position)) {
                case 0:
                    viewHolder3.mCheckedTextView.setChecked(false);
                    break;
                case 1:
                    viewHolder3.mCheckedTextView.setChecked(true);
                    break;
                case 2:
                    viewHolder3.mCheckedTextView.setCheckMarkDrawable(34078740);
                    break;
                case 3:
                    viewHolder3.mCheckedTextView.setCheckMarkDrawable(34078740);
                    viewHolder3.mCheckedTextView.setChecked(true);
                    break;
            }
            temp.setTag(viewHolder3);
        }
        ListViewHolder viewHolder4 = (ListViewHolder) temp.getTag();
        ScenePickerItem info = mItems.get(position);
        Bitmap tmp2 = info.getIcon();
        if (tmp2 == null) {
            Bitmap tmp3 = getPanelViewBitmap(this.mContext, mItems.get(position), false);
            mItems.get(position).setIcon(tmp3);
        }
        viewHolder4.mImageView.setImageDrawable(new FastBitmapDrawable(this.mContext.getResources(), info.getIcon()));
        viewHolder4.mCheckedTextView.setText(info.getName());
        return temp;
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public int getItemViewType(int position) {
        if (this.mIsPanelMode) {
            return (this.mCurrentMode != 0 && mItems.get(position).isMarked()) ? 5 : 4;
        }
        if (this.mCurrentMode == 0) {
            if (getItemId(position) == this.mSelectSceneId) {
                return 1;
            }
            return 0;
        }
        if (mItems.get(position).isMarked()) {
            return 3;
        }
        return 2;
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public int getViewTypeCount() {
        return 6;
    }

    private class ListViewHolder extends HtcSimpleSeparable {
        private CheckedTextView mCheckedTextView;
        private ImageView mImageView;

        public ListViewHolder(String id, boolean drawOnThis) {
            super(id, drawOnThis);
        }

        public ListViewHolder(String id) {
            super(id);
        }
    }

    private class PanelViewHolder {
        private ImageView mDeleteIcon;
        private ImageView mImageView;

        private PanelViewHolder() {
        }
    }

    public void onApply() {
        if (this.mSelectSceneId != this.mCurrentSceneId) {
            Intent intent = new Intent();
            intent.setAction(LauncherIntent.ACTION_THEME_CHANGE);
            intent.putExtra("workspace_id", this.mSelectSceneId);
            Log.d(TAG, "Apply scene " + this.mSelectSceneId);
            this.mContext.sendBroadcast(intent);
        }
    }

    public boolean onDelete(int id) {
        for (int i = 0; i < mItems.size(); i++) {
            ScenePickerItem item = mItems.get(i);
            if (id == item.id) {
                File deleteScene = new File(PREVIEW_PATH + item.id + ".png");
                if (deleteScene.exists()) {
                    deleteScene.delete();
                }
                File deleteScene2 = new File(ICON_PATH + item.id + ".png");
                if (deleteScene2.exists()) {
                    deleteScene2.delete();
                }
                File deleteScene3 = new File(PREVIEW_PATH_LAND + item.id + ".png");
                if (deleteScene3.exists()) {
                    deleteScene3.delete();
                }
                File deleteScene4 = new File(ICON_PATH_LAND + item.id + ".png");
                if (deleteScene4.exists()) {
                    deleteScene4.delete();
                }
                mWidgetWorkspaceManager.removeWorkspace(mWidgetWorkspaceManager.getWidgetWorkspace(item.id), false);
                Log.d(TAG, "delete scene(" + item.id + "):" + item.name);
            }
        }
        for (int i2 = mItems.size() - 1; i2 >= 0; i2--) {
            ScenePickerItem item2 = mItems.get(i2);
            if (id == item2.id) {
                if (this.mCurrentSceneId == item2.id) {
                    this.mCurrentSceneId = this.mSelectSceneId;
                }
                mItems.remove(item2);
            }
        }
        return false;
    }

    public boolean onDelete() {
        int initialId = mWidgetWorkspaceManager.getCurrentWorkspaceId();
        this.mIsDeleteCurrentScene = false;
        for (int i = 0; i < mItems.size(); i++) {
            ScenePickerItem item = mItems.get(i);
            if (item.isMarked()) {
                int sceneId = item.getId();
                if (initialId == sceneId) {
                    this.mIsDeleteCurrentScene = true;
                }
                String previewPathForPortrait = String.format(STRING_FORMAT_PREVIEW_PATH, Integer.valueOf(sceneId));
                String iconPathForPortrait = String.format(STRING_FORMAT_ICON_PATH, Integer.valueOf(sceneId));
                String previewPathForLandscape = String.format(STRING_FORMAT_PREVIEW_PATH_LAND, Integer.valueOf(sceneId));
                String iconPathForLandscape = String.format(STRING_FORMAT_ICON_PATH_LAND, Integer.valueOf(sceneId));
                File deleteScene = new File(previewPathForPortrait);
                if (deleteScene.exists()) {
                    deleteScene.delete();
                }
                File deleteScene2 = new File(iconPathForPortrait);
                if (deleteScene2.exists()) {
                    deleteScene2.delete();
                }
                File deleteScene3 = new File(previewPathForLandscape);
                if (deleteScene3.exists()) {
                    deleteScene3.delete();
                }
                File deleteScene4 = new File(iconPathForLandscape);
                if (deleteScene4.exists()) {
                    deleteScene4.delete();
                }
                mWidgetWorkspaceManager.removeWorkspace(mWidgetWorkspaceManager.getWidgetWorkspace(sceneId), false);
                Log.d(TAG, "delete scene(" + sceneId + "):" + item.getName());
            }
        }
        for (int i2 = mItems.size() - 1; i2 >= 0; i2--) {
            ScenePickerItem item2 = mItems.get(i2);
            if (item2.isMarked()) {
                mItems.remove(item2);
            }
        }
        if (this.mIsDeleteCurrentScene) {
            if (mItems.size() == 0) {
                this.mSelectSceneId = -1;
            } else {
                this.mSelectSceneId = mItems.get(0).getId();
                this.mCurrentSceneId = this.mSelectSceneId;
            }
            Log.d(TAG, "delete current scene, current scene id change to " + this.mCurrentSceneId);
        }
        return this.mIsDeleteCurrentScene;
    }

    public void setAdapterMode(int mode) {
        this.mCurrentMode = mode;
        Iterator i$ = mItems.iterator();
        while (i$.hasNext()) {
            ScenePickerItem item = i$.next();
            item.setMarked(false);
        }
        notifyDataSetChanged();
    }

    public void addDeleteIndex(int index) {
        mItems.get(index).setMarked(!mItems.get(index).isMarked());
    }

    public int getDeleteItemCount() {
        int i = 0;
        Iterator i$ = mItems.iterator();
        while (i$.hasNext()) {
            ScenePickerItem item = i$.next();
            if (item.isMarked()) {
                i++;
            }
        }
        return i;
    }

    public static Bitmap createReflectedImage(Bitmap originalImage) {
        int width = originalImage.getWidth();
        int height = originalImage.getHeight();
        Matrix matrix = new Matrix();
        matrix.preScale(1.0f, -1.0f);
        Bitmap reflectionImage = Bitmap.createBitmap(originalImage, 0, height / 2, width, height / 2, matrix, false);
        Bitmap bitmapWithReflection = Bitmap.createBitmap(width, ((height * 3) / 16) + height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmapWithReflection);
        canvas.drawBitmap(originalImage, 0.0f, 0.0f, (Paint) null);
        Paint defaultPaint = new Paint();
        canvas.drawRect(0.0f, height, width, height + 0, defaultPaint);
        canvas.drawBitmap(reflectionImage, 0.0f, height + 0, (Paint) null);
        Paint paint = new Paint();
        LinearGradient shader = new LinearGradient(0.0f, originalImage.getHeight(), 0.0f, bitmapWithReflection.getHeight() + 0, 1895825407, 16777215, Shader.TileMode.CLAMP);
        paint.setShader(shader);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        canvas.drawRect(0.0f, height, width, bitmapWithReflection.getHeight() + 0, paint);
        Log.d(TAG, "bitmapWithReflection(" + bitmapWithReflection.getWidth() + ", " + bitmapWithReflection.getHeight() + "), originalImage(" + originalImage.getWidth() + ", " + originalImage.getHeight() + ")");
        return bitmapWithReflection;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static Bitmap getPanelViewBitmap(Context context, ScenePickerItem item, boolean isPanelMode) {
        String pathFormat;
        if (isPortrait(context)) {
            pathFormat = isPanelMode ? STRING_FORMAT_PREVIEW_PATH : STRING_FORMAT_ICON_PATH;
        } else {
            pathFormat = isPanelMode ? STRING_FORMAT_PREVIEW_PATH_LAND : STRING_FORMAT_ICON_PATH_LAND;
        }
        String path = String.format(pathFormat, Integer.valueOf(item.getId()));
        Bitmap src = BitmapFactory.decodeFile(path);
        if (isPanelMode) {
            if (src == null) {
                Drawable d = context.getResources().getDrawable(isPanelMode ? 2130837548 : 2130837613);
                src = ((BitmapDrawable) d).getBitmap();
            }
            Bitmap reflectBitmap = createReflectedImage(src);
            return reflectBitmap;
        }
        if (src == null) {
            String pathFormat2 = isPortrait(context) ? STRING_FORMAT_PREVIEW_PATH : STRING_FORMAT_PREVIEW_PATH_LAND;
            String path2 = String.format(pathFormat2, Integer.valueOf(item.getId()));
            src = BitmapFactory.decodeFile(path2);
            if (src == null) {
                Drawable d2 = context.getResources().getDrawable(isPanelMode ? 2130837548 : 2130837613);
                src = ((BitmapDrawable) d2).getBitmap();
            }
        }
        return src;
    }

    private static boolean isPortrait(Context context) {
        int orientation = context.getResources().getConfiguration().orientation;
        return orientation == 1;
    }

    public static String getSceneFileName(boolean isPortrait, int sceneId) {
        String fileNameFormat;
        if (isPortrait) {
            fileNameFormat = STRING_FORMAT_PREVIEW_PATH;
        } else {
            fileNameFormat = STRING_FORMAT_PREVIEW_PATH_LAND;
        }
        String fileName = String.format(fileNameFormat, Integer.valueOf(sceneId));
        return fileName;
    }

    private class LauncherHandler extends Handler {
        private LauncherHandler() {
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            if (msg.what == 100) {
                ScenePickerAdapter.this.notifyDataSetChanged();
            }
            super.handleMessage(msg);
        }
    }

    public void setViewMode(boolean isPanelMode) {
        this.mIsPanelMode = isPanelMode;
    }

    public void updateSceneName() {
        Iterator i$ = mItems.iterator();
        while (i$.hasNext()) {
            ScenePickerItem item = i$.next();
            item.setName(mWidgetWorkspaceManager.getWidgetWorkspace(item.getId()).displayName);
        }
        notifyDataSetChanged();
    }

    public void setSelectSceneId(int selectSceneId) {
        this.mSelectSceneId = selectSceneId;
    }

    public int getSelectSceneId() {
        return this.mSelectSceneId;
    }

    public int getCurrentSceneId() {
        return this.mCurrentSceneId;
    }

    public int getSceneIndexById(int id) {
        for (int i = 0; i < mItems.size(); i++) {
            ScenePickerItem item = mItems.get(i);
            if (item.getId() == id) {
                return i;
            }
        }
        return -1;
    }

    public void setOrientation(int nOrientation) {
        init();
        notifyDataSetChanged();
    }
}
