package com.htc.launcher;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class ApplicationInfo extends FxShortcutInfo {
    public ApplicationInfo() {
        this.itemType = 1;
    }

    public ApplicationInfo(ApplicationInfo info) {
        super(info);
    }
}
