package com.htc.launcher;

import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Process;
import android.util.Log;
import com.htc.launcher.LauncherSettings;
import java.net.URISyntaxException;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class UninstallShortcutReceiver extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(final Context context, final Intent data) {
        Thread thread = new Thread() { // from class: com.htc.launcher.UninstallShortcutReceiver.1
            @Override // java.lang.Thread, java.lang.Runnable
            public void run() {
                Process.setThreadPriority(19);
                UninstallShortcutReceiver.this.uninstallShortcut(context, data);
            }
        };
        thread.start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void uninstallShortcut(Context context, Intent data) {
        Intent intent = (Intent) data.getParcelableExtra("android.intent.extra.shortcut.INTENT");
        String name = data.getStringExtra("android.intent.extra.shortcut.NAME");
        boolean duplicate = data.getBooleanExtra("duplicate", true);
        if (intent != null && name != null) {
            ContentResolver cr = context.getContentResolver();
            Cursor c = cr.query(LauncherSettings.Favorites.CONTENT_URI, new String[]{LauncherSettings.Favorites.ID, "intent"}, "title=? AND workspace_id=0 ", new String[]{name}, null);
            int intentIndex = c.getColumnIndexOrThrow("intent");
            int idIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ID);
            boolean changed = false;
            while (c.moveToNext()) {
                try {
                    try {
                        if (intent.filterEquals(Intent.parseUri(c.getString(intentIndex), 0))) {
                            long id = c.getLong(idIndex);
                            Uri uri = LauncherSettings.Favorites.getContentUri(id, false);
                            cr.delete(uri, null, null);
                            WidgetWorkspaceManager.instance(context).onSceneModified();
                            changed = true;
                            if (!duplicate) {
                                break;
                            }
                        } else {
                            continue;
                        }
                    } catch (URISyntaxException e) {
                    }
                } catch (Throwable th) {
                    c.close();
                    throw th;
                }
            }
            c.close();
            Log.d(Launcher.DEBUG_DB_TAG, "uninstallShortcut(), name = " + name);
            if (changed) {
                cr.notifyChange(LauncherSettings.Favorites.CONTENT_URI, null);
            }
        }
    }
}
