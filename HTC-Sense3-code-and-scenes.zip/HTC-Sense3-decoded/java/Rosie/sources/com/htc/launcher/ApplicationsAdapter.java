package com.htc.launcher;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.SparseIntArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.SectionIndexer;
import android.widget.TextView;
import com.htc.launcher.model.FilterableAndSortableApplicationInfoList;
import com.htc.launcher.settings.SettingUtil;
import com.htc.widget.HtcListView;
import java.text.Collator;
import java.util.ArrayList;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class ApplicationsAdapter extends BaseAdapter implements SectionIndexer {
    public static final int FILTER_ALLAPPS = 0;
    public static final int FILTER_DOWNLOADED = 1;
    public static final int FILTER_FREQUENT = 2;
    public static final int FILTER_OPERATOR_TAB = 3;
    public static final String TAG = "ApplicationsAdapter";
    public static final boolean localLOGV = false;
    private SparseIntArray mAlphaMap;
    private String[] mAlphabet;
    private Collator mCollator;
    private final Context mContext;
    private final LayoutInflater mInflater;
    private final FilterableAndSortableApplicationInfoList mList;
    int ITEMS_PER_ROW = 4;
    int ROWS_PER_PAGE = 4;
    int ITEMS_PER_PAGE = this.ITEMS_PER_ROW * this.ROWS_PER_PAGE;
    OperatorTab currentOperatorTab = null;

    private static class ViewHolder {
        ImageView icon;
        TextView name;

        private ViewHolder() {
        }
    }

    public ApplicationsAdapter(Context context, FilterableAndSortableApplicationInfoList apps) {
        this.mContext = context;
        this.mInflater = LayoutInflater.from(context);
        this.mList = apps;
        init();
    }

    public ApplicationsAdapter(Context context, ArrayList<ApplicationInfo> contents) {
        this.mContext = context;
        this.mInflater = LayoutInflater.from(context);
        this.mList = new FilterableAndSortableApplicationInfoList(contents);
        init();
    }

    private void init() {
        String alphabetString = this.mContext.getString(android.R.string.display_rotation_camera_compat_toast_in_multi_window);
        this.mAlphabet = new String[alphabetString.length()];
        for (int i = 0; i < this.mAlphabet.length; i++) {
            this.mAlphabet[i] = String.valueOf(alphabetString.charAt(i));
        }
        this.mAlphaMap = new SparseIntArray(26);
        this.mCollator = Collator.getInstance();
        this.mCollator.setStrength(0);
        Resources res = this.mContext.getResources();
        this.ITEMS_PER_ROW = res.getInteger(R.integer.allprogram_grid_columns);
        this.ROWS_PER_PAGE = res.getInteger(R.integer.allprogram_grid_rows);
        this.ITEMS_PER_PAGE = this.ITEMS_PER_ROW * this.ROWS_PER_PAGE;
    }

    public FilterableAndSortableApplicationInfoList getList() {
        return this.mList;
    }

    private View newView(Context context, ViewGroup parent) {
        View view;
        ViewHolder holder = new ViewHolder();
        if (parent instanceof HtcListView) {
            view = this.mInflater.inflate(34144371, parent, false);
            holder.name = (TextView) view.findViewById(33685520);
            holder.icon = (ImageView) view.findViewById(33685530);
            holder.icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        } else if (parent instanceof AllAppsGridView) {
            view = this.mInflater.inflate(R.layout.application_boxed, parent, false);
            holder.name = (TextView) view.findViewById(R.id.name);
        } else {
            view = this.mInflater.inflate(R.layout.app_in_folder, parent, false);
            holder.name = (TextView) view.findViewById(R.id.name);
        }
        view.setTag(holder);
        return view;
    }

    @Override // android.widget.Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        ApplicationInfo info = getItem(position);
        if (convertView == null) {
            convertView = newView(this.mContext, parent);
        }
        if (!info.filtered) {
            info.icon = Utilities.createIconThumbnail(info.icon, this.mContext);
            info.filtered = true;
        }
        ViewHolder holder = (ViewHolder) convertView.getTag();
        if (parent instanceof HtcListView) {
            holder.name.setText(info.title);
            holder.icon.setImageDrawable(info.icon);
        } else if (parent instanceof AllAppsGridView) {
            holder.name.setCompoundDrawablesWithIntrinsicBounds((Drawable) null, info.icon, (Drawable) null, (Drawable) null);
            holder.name.setText(info.title);
            if (position < 4) {
            }
            if (position % this.ITEMS_PER_PAGE >= this.ITEMS_PER_PAGE - this.ITEMS_PER_ROW) {
                int currentPage = position / this.ITEMS_PER_PAGE;
                int totalPage = ((getCount() + this.ITEMS_PER_PAGE) - 1) / this.ITEMS_PER_PAGE;
                if (currentPage != totalPage - 1) {
                    if (!SettingUtil.isDoubleShot()) {
                        convertView.setBackgroundResource(R.drawable.all_apps_divider);
                    }
                } else {
                    convertView.setBackgroundDrawable(null);
                }
                convertView.setPadding(0, this.mContext.getResources().getDimensionPixelOffset(R.dimen.application_boxed_padtop_lastrow), 0, 0);
            } else if (position % this.ITEMS_PER_PAGE < this.ITEMS_PER_ROW) {
                convertView.setBackgroundDrawable(null);
                convertView.setPadding(0, this.mContext.getResources().getDimensionPixelOffset(R.dimen.application_boxed_padtop_firstrow), 0, 0);
            } else {
                convertView.setBackgroundDrawable(null);
                convertView.setPadding(0, this.mContext.getResources().getDimensionPixelOffset(R.dimen.application_boxed_padtop_otherrows), 0, 0);
            }
        } else {
            holder.name.setCompoundDrawablesWithIntrinsicBounds((Drawable) null, info.icon, (Drawable) null, (Drawable) null);
            holder.name.setText(info.title);
        }
        return convertView;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        if (this.mList == null) {
            return 0;
        }
        return this.mList.size();
    }

    @Override // android.widget.Adapter
    public ApplicationInfo getItem(int position) {
        if (this.mList != null && position >= 0 && position < this.mList.size()) {
            return this.mList.get(position);
        }
        notifyDataSetChanged();
        return null;
    }

    @Override // android.widget.Adapter
    public long getItemId(int arg0) {
        return arg0;
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public boolean hasStableIds() {
        return false;
    }

    @Override // android.widget.SectionIndexer
    public int getPositionForSection(int arg0) {
        if (this.mAlphabet == null || arg0 <= 0) {
            return 0;
        }
        if (arg0 >= this.mAlphabet.length) {
            arg0 = this.mAlphabet.length - 1;
        }
        int count = getCount();
        int start = 0;
        int end = count;
        String letter = this.mAlphabet[arg0].toUpperCase();
        int key = letter.charAt(0);
        int pos = this.mAlphaMap.get(key, ApplicationManager.ALL_PROGRAM_LIST_HIGHEST_PRIORITY);
        if (Integer.MIN_VALUE != pos) {
            if (pos >= 0) {
                return pos;
            }
            end = -pos;
        }
        if (arg0 > 0) {
            int prevLetter = this.mAlphabet[arg0 - 1].toString().charAt(0);
            int prevLetterPos = this.mAlphaMap.get(prevLetter, ApplicationManager.ALL_PROGRAM_LIST_HIGHEST_PRIORITY);
            if (prevLetterPos != Integer.MIN_VALUE) {
                start = Math.abs(prevLetterPos);
            }
        }
        int pos2 = (end + start) / 2;
        while (true) {
            if (pos2 < end) {
                String curName = getItem(pos2).toString();
                if (curName == null) {
                    if (pos2 == 0) {
                        break;
                    }
                    pos2--;
                } else {
                    int curLetter = Character.toUpperCase(curName.charAt(0));
                    if (curLetter != key) {
                        int curPos = this.mAlphaMap.get(curLetter, ApplicationManager.ALL_PROGRAM_LIST_HIGHEST_PRIORITY);
                        if (curPos == Integer.MIN_VALUE || Math.abs(curPos) > pos2) {
                            this.mAlphaMap.put(curLetter, -pos2);
                        }
                        if (this.mCollator.compare(curName, letter) < 0) {
                            start = pos2 + 1;
                            if (start >= count) {
                                pos2 = count;
                                break;
                            }
                        } else {
                            end = pos2;
                        }
                        pos2 = (start + end) / 2;
                    } else {
                        if (start == pos2) {
                            break;
                        }
                        end = pos2;
                        pos2 = (start + end) / 2;
                    }
                }
            } else {
                break;
            }
        }
        this.mAlphaMap.put(key, pos2);
        return pos2;
    }

    @Override // android.widget.SectionIndexer
    public int getSectionForPosition(int arg0) {
        return 0;
    }

    @Override // android.widget.SectionIndexer
    public Object[] getSections() {
        return this.mAlphabet;
    }
}
