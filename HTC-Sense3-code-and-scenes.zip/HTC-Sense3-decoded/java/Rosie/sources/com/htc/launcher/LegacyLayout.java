package com.htc.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;
import com.android.common.speech.LoggingEvents;
import com.htc.android.rosie.home.fxcontrol.FxScreen;
import com.htc.android.rosie.home.fxcontrol.FxWorkspace;
import com.htc.fusion.fx.FxScene;
import com.htc.fusion.fx.FxSceneLoader;
import com.htc.fusion.fx.controls.FxStreamingTexture;
import com.htc.launcher.settings.SettingUtil;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class LegacyLayout extends FrameLayout {
    private static final int FUTURE_WAIT_TIME = 500;
    private static final int MSG_RETRY = 268435456;
    private static final String REMOTE_CONTROL_NAME = "remote";
    private static final String TAG = "LegacyLayout";
    private int mCount;
    private Region mDirtyRgn;
    private Rect mFrame;
    private FxSceneControl mFxSceneControl;
    private int mFxScreen;
    private long mNeedsDraw;
    private Paint mOutlinePaint;
    private boolean mPressed;
    private Workspace mWorkspace;
    private static Set<LegacyLayout> sPendingViews = new HashSet();
    private static Handler sH = new Handler() { // from class: com.htc.launcher.LegacyLayout.1
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case LegacyLayout.MSG_RETRY /* 268435456 */:
                    LegacyLayout.flushPendingDraw();
                    break;
            }
        }
    };
    private static int sFlushCount = 0;

    private static class AttachScene implements Runnable {
        private LegacyLayout mLL;

        private AttachScene(LegacyLayout ll) {
            this.mLL = ll;
        }

        @Override // java.lang.Runnable
        public void run() {
            FxSceneControl sc = this.mLL.mFxSceneControl;
            boolean isPortrait = this.mLL.mWorkspace.isPortrait();
            if (isPortrait) {
                if (!sc.mAttachedP) {
                    sc.mAttachedP = sc.attachInner();
                    sc.mAttachedP = true;
                }
            } else if (!sc.mAttachedL) {
                sc.mAttachedL = sc.attachInner();
                sc.mAttachedL = true;
            }
            Logger.d(LegacyLayout.TAG, this.mLL + " scene attached");
            Runnable draw = new Runnable() { // from class: com.htc.launcher.LegacyLayout.AttachScene.1
                @Override // java.lang.Runnable
                public void run() {
                    AttachScene.this.mLL.invalidate();
                    AttachScene.this.mLL = null;
                }
            };
            View v = this.mLL.getTheView();
            if (v != null) {
                v.post(draw);
            } else {
                this.mLL.post(draw);
            }
        }
    }

    private class FxSceneControl {
        boolean mAttachedL;
        boolean mAttachedP;
        Future<Bitmap> mBufferL;
        Future<Bitmap> mBufferP;
        String mFxPathL;
        String mFxPathP;
        int mMyId;
        FxStreamingTexture mRemoteL;
        FxStreamingTexture mRemoteP;
        FxScene mSceneL;
        FxScene mSceneP;

        private FxSceneControl(Workspace workspace, int w, int h, int id) {
            String[] m10s = workspace.getLauncher().getResources().getStringArray(R.array.legacy_widget_containers);
            int index = ((w - 1) * 4) + (h - 1);
            this.mFxPathP = "port/scenes/" + m10s[index];
            this.mFxPathL = "land/scenes/" + m10s[index];
            this.mMyId = id;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public FxScene getScene(boolean isPortrait) {
            if (isPortrait) {
                if (this.mSceneP == null) {
                    this.mSceneP = FxScene.create(this.mFxPathP, true);
                    this.mRemoteP = this.mSceneP.findControl(LegacyLayout.REMOTE_CONTROL_NAME);
                    this.mBufferP = this.mRemoteP.backBuffer();
                }
                return this.mSceneP;
            }
            if (this.mSceneL == null) {
                this.mSceneL = FxScene.create(this.mFxPathL, true);
                this.mRemoteL = this.mSceneL.findControl(LegacyLayout.REMOTE_CONTROL_NAME);
                this.mBufferL = this.mRemoteL.backBuffer();
            }
            return this.mSceneL;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public Future<Bitmap> getBuffer(boolean isPortrait) {
            if (isPortrait && this.mAttachedP) {
                return this.mBufferP;
            }
            if (!isPortrait && this.mAttachedL) {
                return this.mBufferL;
            }
            return null;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void swap(Future<Bitmap> buffer) {
            if (buffer == this.mBufferP) {
                this.mRemoteP.swap();
                this.mBufferP = this.mRemoteP.backBuffer();
            } else if (buffer == this.mBufferL) {
                this.mRemoteL.swap();
                this.mBufferL = this.mRemoteL.backBuffer();
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public boolean attachToScreen() {
            LegacyLayout.this.mWorkspace.getLauncher().getDesktopItemController().schedulePendingTask(new AttachScene());
            return true;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public boolean attachInner() {
            View v = LegacyLayout.this.getTheView();
            if (v != null) {
                ItemInfo info = LegacyLayout.this.getItemInfo(v);
                int cellX = info.cellX;
                int cellY = info.cellY;
                int spanX = info.spanX;
                int spanY = info.spanY;
                if (LegacyLayout.this.isFolder()) {
                    cellX = 0;
                    cellY = 0;
                    spanX = 4;
                    spanY = 4;
                }
                Logger.d("attachInner", "id: " + info.id + " screen:" + info.screen + " cx:" + cellX + " cy:" + cellY);
                FxScreen.LayoutParams layout = new FxScreen.LayoutParams(cellX, cellY, spanX, spanY);
                FxScene scene = LegacyLayout.this.getFxScene();
                if (v instanceof Folder) {
                    Logger.d(LegacyLayout.TAG, "[FOLDER] attachInner() id: " + info.id + " screen:" + info.screen + " cx:" + cellX + " cy:" + cellY + " sx:" + spanX + " sy:" + spanY);
                    FxScreen fxScreen = LegacyLayout.this.getFxScreen(info.screen);
                    if (fxScreen.setFolder(info.id, scene)) {
                        LegacyLayout.this.mFxScreen = info.screen;
                        return true;
                    }
                } else {
                    Logger.d(LegacyLayout.TAG, "[FOLDER] attachInner() addItemToScreen()");
                    FxItem fxItem = FxItem.create(scene, LegacyLayout.this, info);
                    if (LegacyLayout.this.getFxWorkspace().addItemToScreen(info.screen, info.id, fxItem, layout)) {
                        LegacyLayout.this.mFxScreen = info.screen;
                        return true;
                    }
                }
                return false;
            }
            return false;
        }

        private void detach() {
            LegacyLayout.this.fxDetach();
            this.mAttachedL = false;
            this.mAttachedP = false;
        }

        private void reset() {
            this.mSceneL = null;
            this.mSceneP = null;
            this.mRemoteL = null;
            this.mRemoteP = null;
            this.mBufferL = null;
            this.mBufferP = null;
        }
    }

    public LegacyLayout(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mWorkspace = null;
        this.mFxScreen = -1;
        this.mOutlinePaint = new Paint();
        this.mFrame = new Rect();
        this.mNeedsDraw = 1L;
        this.mDirtyRgn = new Region();
        this.mCount = 0;
    }

    public LegacyLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mWorkspace = null;
        this.mFxScreen = -1;
        this.mOutlinePaint = new Paint();
        this.mFrame = new Rect();
        this.mNeedsDraw = 1L;
        this.mDirtyRgn = new Region();
        this.mCount = 0;
    }

    public LegacyLayout(Context context) {
        super(context);
        this.mWorkspace = null;
        this.mFxScreen = -1;
        this.mOutlinePaint = new Paint();
        this.mFrame = new Rect();
        this.mNeedsDraw = 1L;
        this.mDirtyRgn = new Region();
        this.mCount = 0;
    }

    public LegacyLayout(Workspace workspace, View view, ViewGroup.LayoutParams params) {
        super(view.getContext());
        this.mWorkspace = null;
        this.mFxScreen = -1;
        this.mOutlinePaint = new Paint();
        this.mFrame = new Rect();
        this.mNeedsDraw = 1L;
        this.mDirtyRgn = new Region();
        this.mCount = 0;
        ItemInfo info = getItemInfo(view);
        if (info != null) {
            Logger.d(TAG, "[ROSIE_DEBUG] LegacyLayout. LegacyLayout() - addView(" + info.id + " in " + info.screen + ") params is null(" + (params == null) + ") - enter");
        }
        addView(view, params);
        setLayoutParams(params);
        this.mWorkspace = workspace;
        Logger.d(TAG, this + "set tag:" + view.getTag());
        setTag(view.getTag());
        Logger.d(TAG, "[ROSIE_DEBUG] LegacyLayout. LegacyLayout() - addView() - exit");
        if (isFolder()) {
            ensureFx(4, 4);
        } else {
            ensureFx(info.spanX, info.spanY);
        }
    }

    public FxScene getFxScene() {
        if (this.mFxSceneControl != null) {
            return this.mFxSceneControl.getScene(this.mWorkspace.isPortrait());
        }
        return null;
    }

    private Future<Bitmap> getBuffer() {
        return this.mFxSceneControl.getBuffer(this.mWorkspace.isPortrait());
    }

    private void ensureFx(int spanX, int spanY) {
        if (this.mFxSceneControl == null) {
            this.mFxSceneControl = new FxSceneControl(this.mWorkspace, spanX, spanY, hashCode());
        }
    }

    @Deprecated
    private void fxAttach(int screen, View view, int id, int cellX, int cellY, int spanX, int spanY) {
        Logger.d(TAG, "[ROSIE_DEBUG] LegacyLayout. fxAttach() - begin");
        FxScreen fxScreen = getFxScreen(screen);
        if (fxScreen != null) {
            if (isFolder()) {
                cellX = 0;
                cellY = 0;
                spanX = 4;
                spanY = 4;
            }
            ensureFx(spanX, spanY);
            FxScreen.LayoutParams layout = new FxScreen.LayoutParams(cellX, cellY, spanX, spanY);
            FxScene scene = getFxScene();
            if (view instanceof Folder) {
                if (fxScreen.setFolder(id, scene)) {
                    this.mFxScreen = screen;
                }
            } else {
                FxItem fxItem = FxItem.create(scene, this, (ItemInfo) getTag());
                if (fxScreen.addItem(id, fxItem, layout)) {
                    this.mFxScreen = screen;
                }
            }
            Logger.d(TAG, "[ROSIE_DEBUG] LegacyLayout. fxAttach() - exit");
            return;
        }
        Logger.d(TAG, "[ROSIE_DEBUG] LegacyLayout. fxAttach() - fxScreen = null");
    }

    @Override // android.view.ViewGroup
    protected void detachAllViewsFromParent() {
        Logger.d(TAG, "[ROSIE_DEBUG] detachAllViewsFromParent()");
        super.detachAllViewsFromParent();
    }

    @Override // android.view.ViewGroup
    protected void detachViewFromParent(int index) {
        Logger.d(TAG, "[ROSIE_DEBUG] detachViewFromParent()");
        super.detachViewFromParent(index);
    }

    @Override // android.view.ViewGroup
    protected void detachViewFromParent(View child) {
        Logger.d(TAG, "[ROSIE_DEBUG] detachViewFromParent()");
        super.detachViewFromParent(child);
    }

    @Override // android.view.ViewGroup
    protected void detachViewsFromParent(int start, int count) {
        Logger.d(TAG, "[ROSIE_DEBUG] detachViewsFromParent()");
        super.detachViewsFromParent(start, count);
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public void removeView(View view) {
        super.removeView(view);
    }

    @Override // android.view.ViewGroup
    public void removeViewAt(int index) {
        super.removeViewAt(index);
    }

    @Override // android.view.ViewGroup
    public void removeAllViews() {
        super.removeAllViews();
    }

    @Override // android.view.ViewGroup
    public void removeAllViewsInLayout() {
        super.removeAllViewsInLayout();
    }

    @Override // android.view.ViewGroup
    protected void removeDetachedView(View child, boolean animate) {
        super.removeDetachedView(child, animate);
    }

    @Override // android.view.ViewGroup
    public void removeViewInLayout(View view) {
        super.removeViewInLayout(view);
    }

    @Override // android.view.ViewGroup
    public void removeViews(int start, int count) {
        super.removeViews(start, count);
    }

    @Override // android.view.ViewGroup
    public void removeViewsInLayout(int start, int count) {
        super.removeViewsInLayout(start, count);
    }

    protected void fxDetach() {
        View v = getTheView();
        if (v != null) {
            int id = getItemInfoId(v);
            Logger.d(TAG, "[ROSIE_DEBUG] LegacyLayout. fxDetach(" + id + ") - enter");
            sPendingViews.remove(this);
            if (this.mFxScreen != -1) {
                ItemInfo itemInfo = getItemInfo(v);
                if (itemInfo != null) {
                    detachInner(itemInfo);
                }
                this.mFxSceneControl = null;
                this.mFxScreen = -1;
            }
            removeTheView();
            Logger.d(TAG, "[ROSIE_DEBUG] LegacyLayout. fxDetach(" + id + ") - exit");
        }
    }

    private void detachInner(ItemInfo itemInfo) {
        FxScreen fxScreen;
        if (itemInfo instanceof FolderInfo) {
            FxScreen fxScreen2 = getFxScreen(itemInfo.screen);
            if (fxScreen2 != null) {
                fxScreen2.removeFolder();
            }
            if (SettingUtil.isSupportLandscape() && (fxScreen = getAnotherFxScreen(itemInfo.screen)) != null) {
                fxScreen.removeFolder();
                return;
            }
            return;
        }
        try {
            getFxWorkspace().removeItemFromScreen(itemInfo.screen, (int) itemInfo.id);
        } catch (FxScreen.ItemNotFoundException infe) {
            Logger.e(TAG, "[ROSIE_DEBUG] " + infe.getMessage());
        }
    }

    private Workspace getWorkspace() {
        return this.mWorkspace;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public FxWorkspace getFxWorkspace() {
        if (getWorkspace() == null) {
            Logger.d(TAG, "[ROSIE_DEBUG] LegacyLayout. LegacyLayout.getFxWorkspace() mWorkspace.getLauncher() mWorkspace = null");
            return null;
        }
        if (this.mWorkspace.getLauncher() != null) {
            return this.mWorkspace.getLauncher().getFxWorkspace();
        }
        Logger.d(TAG, "[ROSIE_DEBUG] LegacyLayout. LegacyLayout.getFxWorkspace() mWorkspace.getLauncher() = null");
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public FxScreen getFxScreen(int screen) {
        return getFxWorkspace().getCurrentWorkspace().getScreen(screen);
    }

    private FxScreen getAnotherFxScreen(int screen) {
        if (SettingUtil.isSupportLandscape()) {
            return getFxWorkspace().getAnotherWorkspace().getScreen(screen);
        }
        return null;
    }

    private FxSceneLoader getM10ByWH(int w, int h, boolean portrait) {
        Workspace workspace = getWorkspace();
        if (workspace == null) {
            Logger.d(TAG, "[ROSIE_DEBUG] LegacyLayout. LegacyLayout.getM10ByWH() mWorkspace = null");
            return null;
        }
        if (workspace.getLauncher() == null) {
            Logger.d(TAG, "[ROSIE_DEBUG] LegacyLayout. LegacyLayout.getM10ByWH() getLauncher() = null");
            return null;
        }
        String[] m10s = workspace.getLauncher().getResources().getStringArray(R.array.legacy_widget_containers);
        String path = (portrait ? "port/scenes/" : "land/scenes/") + m10s[((w - 1) * 4) + (h - 1)];
        Logger.d(TAG, "[ROSIE_DEBUG] LegacyLayout. getM10ByWH(" + w + "," + h + ") path(" + path + ")");
        return FxSceneLoader.create(path);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public ViewParent invalidateChildInParent(int[] location, Rect dirty) {
        ViewParent vp = super.invalidateChildInParent(location, dirty);
        this.mNeedsDraw++;
        this.mDirtyRgn.union(dirty);
        return vp;
    }

    @Override // android.view.View
    public void invalidate() {
        super.invalidate();
        this.mNeedsDraw++;
    }

    @Override // android.view.View
    public void invalidate(int l, int t, int r, int b) {
        super.invalidate(l, t, r, b);
        this.mNeedsDraw++;
    }

    @Override // android.view.View
    public void invalidate(Rect dirty) {
        super.invalidate(dirty);
        this.mNeedsDraw++;
    }

    public void release() {
        View v = getTheView();
        if (v != null) {
            v.setPressed(false);
        }
    }

    private void schedulePendingDraw() {
        sPendingViews.add(this);
        if (!sH.hasMessages(MSG_RETRY)) {
            sH.sendEmptyMessageDelayed(MSG_RETRY, 15L);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void flushPendingDraw() {
        sFlushCount++;
        Logger.d(TAG, "[ROSIE_DEBUG] pending#" + sFlushCount);
        for (LegacyLayout v : sPendingViews) {
            Logger.d(TAG, "[ROSIE_DEBUG] pending view:" + v);
            v.invalidate();
        }
        sPendingViews.clear();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void dispatchDraw(Canvas canvas) {
        View v = getTheView();
        if (this.mFxSceneControl != null && v != null) {
            if (this.mPressed || this.mNeedsDraw > 0) {
                this.mPressed = false;
                if (v.isPressed()) {
                    this.mPressed = true;
                }
                int id = getItemInfoId(v);
                Future<Bitmap> buffer = getBuffer();
                if (buffer == null) {
                    Logger.w(TAG, "[ROSIE_DEBUG] LegacyLayout. dispatchDraw(" + id + ") - backBuffer() Bitmap = null");
                    schedulePendingDraw();
                    return;
                }
                Bitmap b = null;
                try {
                    if (buffer.isDone()) {
                        b = buffer.get(500L, TimeUnit.MILLISECONDS);
                    }
                } catch (ClassCastException e) {
                    Logger.e(TAG, "[ROSIE_DEBUG] LegacyLayout. dispatchDraw(" + id + ") - " + e.getMessage());
                    b = null;
                } catch (InterruptedException e2) {
                    e2.printStackTrace();
                } catch (ExecutionException e3) {
                    e3.printStackTrace();
                } catch (TimeoutException e4) {
                    Logger.e(TAG, "[ROSIE_DEBUG] LegacyLayout. dispatchDraw(" + id + ") - BackBuffer.get() Bitmap error(" + e4.getMessage() + ")");
                    return;
                }
                if (b == null) {
                    Logger.w(TAG, "[ROSIE_DEBUG] LegacyLayout. dispatchDraw(" + id + ") - bitmap = null. Try again! Handler=" + sH);
                    schedulePendingDraw();
                    return;
                }
                Canvas c = new Canvas(b);
                c.drawColor(0, PorterDuff.Mode.CLEAR);
                super.dispatchDraw(c);
                FxStreamingTexture.flushCanvas(c);
                this.mFxSceneControl.swap(buffer);
                Logger.d(TAG, "[ROSIE_DEBUG] LegacyLayout. dispatchDraw(" + id + ") - done");
                this.mNeedsDraw--;
                return;
            }
            Logger.d(TAG, hashCode() + " ignore dispatchDraw mNeedDraw:" + this.mNeedsDraw);
        }
    }

    private void drawBorder(Canvas canvas) {
        View v = getTheView();
        if (v != null) {
            this.mOutlinePaint.setStrokeWidth(3.0f);
            this.mOutlinePaint.setTextSize(20.0f);
            this.mOutlinePaint.setStyle(Paint.Style.STROKE);
            if (this.mCount % 2 == 0) {
                this.mOutlinePaint.setColor(-65536);
            } else {
                this.mOutlinePaint.setColor(-256);
            }
            v.getHitRect(this.mFrame);
            canvas.drawRect(this.mFrame, this.mOutlinePaint);
            this.mOutlinePaint.setStrokeWidth(2.0f);
            canvas.drawText(this.mCount + LoggingEvents.EXTRA_CALLING_APP_NAME, 10.0f, 20.0f, this.mOutlinePaint);
            this.mCount++;
        }
    }

    private int getItemInfoId(View view) {
        Object tag;
        if (view != null && (tag = view.getTag()) != null && (tag instanceof ItemInfo)) {
            return (int) ((ItemInfo) tag).id;
        }
        return -1;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public ItemInfo getItemInfo(View view) {
        Object tag;
        if (view != null && (tag = view.getTag()) != null && (tag instanceof ItemInfo)) {
            return (ItemInfo) tag;
        }
        return null;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public void onLayout(boolean changed, int l, int t, int r, int b) {
        View v = getTheView();
        try {
            super.onLayout(changed, l, t, r, b);
            if (this.mFxSceneControl != null && v != null) {
                int id = getItemInfoId(v);
                ItemInfo itemInfo = getItemInfo(v);
                if (v != null) {
                    Logger.d(TAG, "[ROSIE_DEBUG] LegacyLayout. onLayout(" + id + ") (" + changed + "," + l + "," + t + "," + r + "," + b + ") View(" + v.getMeasuredWidth() + ", " + v.getMeasuredHeight() + ")");
                } else {
                    Logger.d(TAG, "[ROSIE_DEBUG] LegacyLayout. onLayout(" + id + ") (" + changed + "," + l + "," + t + "," + r + "," + b + ") View = null!");
                }
                if (itemInfo == null) {
                    Logger.e(TAG, "[ROSIE_DEBUG] LegacyLayout. onLayout() ItemInfo = null - exit");
                    return;
                }
                Logger.d(TAG, "[ROSIE_DEBUG] LegacyLayout. onLayout(" + id + ") (" + changed + "," + l + "," + t + "," + r + "," + b + ") ItemType:" + itemInfo.itemType + ", " + v.getMeasuredWidth() + ", " + v.getMeasuredHeight());
                this.mFxSceneControl.attachToScreen();
                this.mNeedsDraw++;
                this.mWorkspace.invalidate();
            }
        } catch (RuntimeException ex) {
            Logger.e(TAG, "[ROSIE_DEBUG] LegancyLayout layout fail. " + v.getTag());
            ex.printStackTrace();
        }
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        Logger.d(TAG, "[ROSIE_DEBUG] LegacyLayout. onDraw()");
        super.onDraw(canvas);
    }

    void changeView(View view) {
        removeTheView();
        addView(view);
        this.mNeedsDraw = 1L;
    }

    View getTheView() {
        return getChildAt(0);
    }

    void removeTheView() {
        final View v = getChildAt(0);
        if (v != null) {
            v.post(new Runnable() { // from class: com.htc.launcher.LegacyLayout.2
                @Override // java.lang.Runnable
                public void run() {
                    LegacyLayout.this.removeView(v);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean isFolder() {
        View v = getTheView();
        return v != null && (v instanceof Folder);
    }
}
