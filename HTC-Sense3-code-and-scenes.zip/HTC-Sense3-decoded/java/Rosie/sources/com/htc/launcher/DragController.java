package com.htc.launcher;

import com.htc.launcher.DragSource;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public interface DragController {
    public static final int DRAG_ACTION_COPY = 1;
    public static final int DRAG_ACTION_MOVE = 0;

    public interface DragListener {
        void onDragEnd();

        void onPostDragStart(Draggee draggee, DragSource dragSource, Object obj, int i);

        void onPreDragStart(Draggee draggee, DragSource dragSource, Object obj, int i);
    }

    DragSource.DragCompletedAction getDragCompleteAction();

    void prepareDrag(Draggee draggee, DragSource dragSource, Object obj, int i);

    void removeDragListener(DragListener dragListener);

    void setDragCompleteAction(DragSource.DragCompletedAction dragCompletedAction);

    void setDragListener(DragListener dragListener);

    void startDrag(Draggee draggee, DragSource dragSource, Object obj, int i);
}
