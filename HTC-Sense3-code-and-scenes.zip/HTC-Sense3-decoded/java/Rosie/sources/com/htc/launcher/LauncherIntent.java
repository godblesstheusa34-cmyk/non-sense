package com.htc.launcher;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class LauncherIntent {
    public static final String ACTION_COPY_SCENE = "com.htc.launcher.ThemeChooser.action.theme_copy";
    public static final String ACTION_CUSTOMIZE_SHORTCUT = "android.intent.action.CUSTOMIZE_SHORTCUT";
    public static final String ACTION_DELETE_SCENE = "com.htc.launcher.ThemeChooser.action.theme_delete";
    public static final String ACTION_MODE_CHANGE = "com.htc.launcher.action.mode_change";
    public static final String ACTION_MODE_CHANGE_SET_PROPERTY = "com.htc.launcher.action.mode_change.set_property";
    public static final String ACTION_NEW_SCENE = "com.htc.launcher.ThemeChooser.action.theme_new";
    public static final String ACTION_RENAME_SCENE = "com.htc.launcher.ThemeChooser.action.theme_rename";
    public static final String ACTION_RESTRICT_THEME_CHANGE = "com.htc.launcher.ThemeChooser.action.restrict_theme_change";
    public static final String ACTION_SQA_INFO = "com.htc.launcher.SQA.info";
    public static final String ACTION_STATUS_BAR_DISABLE = "com.android.StatusBarService.disable";
    public static final String ACTION_THEME_CHANGE = "com.htc.launcher.ThemeChooser.action.theme_change";
    public static final String EXTRA_BACKLIGHT_EFFECT = "backlight_effect";
    public static final String EXTRA_DISPLAY_NAME = "display_name";
    public static final String EXTRA_KIDZONE_MODE = "kidzone_mode";
    public static final String EXTRA_NEW_WORKSPACE_ID = "new_workspace_id";
    public static final String EXTRA_SCREEN_ID = "screen_id";
    public static final String EXTRA_SKIN_WILL_CHANGE = "skin_will_change";
    public static final String EXTRA_WORKSPACE_ID = "workspace_id";
    public static final String SEARCHBAR_FOCUS_IN = "android.launcher.searchbar_focus_in";
    public static final String SEARCHBAR_FOCUS_OUT = "android.launcher.searchbar_focus_out";
    public static final String SET_KIDZONE_MODE_PASSKEY = "SetKidZoneFlag";
    public static final String SOFTWARE_KEYBOARD_DISABLE = "android.launcher.keyboard_disable";
    public static final String SOFTWARE_KEYBOARD_ENABLE = "android.launcher.keyboard_enable";
}
