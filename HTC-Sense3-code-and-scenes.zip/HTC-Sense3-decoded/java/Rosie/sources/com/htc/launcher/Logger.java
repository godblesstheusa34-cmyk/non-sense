package com.htc.launcher;

import android.content.Context;
import android.content.Intent;
import android.util.Slog;
import com.android.common.speech.LoggingEvents;
import com.htc.launcher.settings.SettingUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class Logger {
    public static final boolean LOGV = SettingUtil.localLOGD;

    public static void i(String tag, String msg) {
        if (LOGV) {
            Slog.i(tag, msg);
        }
    }

    public static void d(String tag, String msg) {
        if (LOGV) {
            Slog.d(tag, msg);
        }
    }

    public static void w(String tag, String msg) {
        if (LOGV) {
            Slog.w(tag, msg);
        }
    }

    public static void w(String tag, String msg, Throwable tr) {
        if (LOGV) {
            Slog.w(tag, msg, tr);
        }
    }

    public static void v(String tag, String msg) {
        if (LOGV) {
            Slog.v(tag, msg);
        }
    }

    public static void e(String tag, String msg) {
        Slog.e(tag, msg);
    }

    public static void e(String tag, String msg, Throwable tr) {
        Slog.e(tag, msg, tr);
    }

    public static String showStack(int level, String tag) {
        int deep;
        StackTraceElement[] ste = new Throwable().getStackTrace();
        if (ste != null && (deep = ste.length) >= 2) {
            if (deep >= level) {
                deep = level;
            }
            for (int i = 2; i < deep; i++) {
                d(tag, "    [" + tag + "] " + ste[i].getFileName() + ", " + ste[i].getMethodName() + "(), Line:" + ste[i].getLineNumber());
            }
        }
        return LoggingEvents.EXTRA_CALLING_APP_NAME;
    }

    public static void showMeWidget(Context context, String tag) {
        Intent intent = new Intent();
        intent.setAction("com.htc.showme.LOG");
        intent.putExtra("callingApp", "com.htc.launcher");
        if (tag == null) {
            tag = "tag is null wrong usage";
        }
        intent.putExtra("actionCoverage", tag);
        if (context != null) {
            context.sendBroadcast(intent);
            d("Rosie", "showMeWidget: " + tag);
        } else {
            e("Rosie", "showMeWidget: error context is null ");
        }
    }
}
