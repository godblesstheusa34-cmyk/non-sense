package com.htc.launcher;

import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Parcelable;
import android.os.Process;
import android.util.Log;
import android.widget.BaseAdapter;
import com.android.common.speech.LoggingEvents;
import com.htc.launcher.LauncherSettings;
import com.htc.launcher.model.FilterableAndSortableApplicationInfoList;
import com.htc.launcher.settings.SettingUtil;
import com.htc.widget.CarouselInternalActivity;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class UpdateShortcutReceiver extends BroadcastReceiver {
    static final String LOG_TAG = "Rosie";
    private static final boolean localLOGD = SettingUtil.localLOGD;
    private static BaseAdapter observer = null;

    @Override // android.content.BroadcastReceiver
    public void onReceive(final Context context, final Intent data) {
        if (data != null) {
            Logger.d(LoggingEvents.EXTRA_CALLING_APP_NAME, "UPDATE - UpdateShortcutReceiver.onReceive(" + data.getAction() + ")");
            Thread thread = new Thread() { // from class: com.htc.launcher.UpdateShortcutReceiver.1
                @Override // java.lang.Thread, java.lang.Runnable
                public void run() {
                    Process.setThreadPriority(19);
                    long itemId = data.getLongExtra("favorite_item_id", -1L);
                    Parcelable iconParcel = data.getParcelableExtra("favorite_icon");
                    Parcelable intent = data.getParcelableExtra("favorite_intent");
                    String title = data.getStringExtra("favorite_title");
                    String pkgName = data.getStringExtra("packagename");
                    String select = data.getStringExtra("select");
                    String[] selectArgs = data.getStringArrayExtra("selectArgs");
                    TFC.d(UpdateShortcutReceiver.LOG_TAG, "UpdateShortcutReceiver: itemId=" + itemId + " pkgName=" + pkgName + " title=" + title + " intent=" + intent + " iconParcel=" + iconParcel);
                    if (itemId == -1) {
                        UpdateShortcutReceiver.this.keepIcon4AllApps(pkgName, (Bitmap) iconParcel, title, select, selectArgs);
                    } else {
                        UpdateShortcutReceiver.this.updateShortcut(context, itemId, iconParcel, intent, title);
                    }
                }
            };
            thread.start();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateShortcut(Context context, long itemId, Parcelable icon, Parcelable parceIntent, String title) {
        Logger.d(LoggingEvents.EXTRA_CALLING_APP_NAME, "UPDATE - UpdateShortcutReceiver.updateShortcut(" + title + ") itemId(" + itemId + ")");
        ContentResolver contentResolver = context.getContentResolver();
        Cursor c = contentResolver.query(LauncherSettings.Favorites.CONTENT_URI_NO_NOTIFICATION, null, "_id=?", new String[]{LoggingEvents.EXTRA_CALLING_APP_NAME + itemId}, null);
        if (c != null && c.moveToNext()) {
            int itemTypeIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ITEM_TYPE);
            int itemType = c.getInt(itemTypeIndex);
            if (itemType == 0 || itemType == 1) {
                Bitmap bmp = null;
                byte[] compressedBitmap = null;
                Intent intent = null;
                if (icon != null && (icon instanceof Bitmap)) {
                    bmp = (Bitmap) icon;
                    compressedBitmap = compressBitmap(bmp);
                }
                if (parceIntent != null && (parceIntent instanceof Intent)) {
                    intent = (Intent) parceIntent;
                }
                if (compressedBitmap != null || intent != null || title != null) {
                    Logger.d(LoggingEvents.EXTRA_CALLING_APP_NAME, "UPDATE - UpdateShortcutReceiver.updateShortcut(" + title + ") itemId(" + itemId + ")");
                    ContentValues values = new ContentValues();
                    if (compressedBitmap != null) {
                        values.put(LauncherSettings.Favorites.ICON_TYPE, (Integer) 1);
                        values.put(LauncherSettings.Favorites.ICON, compressedBitmap);
                    } else {
                        Log.e(UpdateShortcutReceiver.class.getSimpleName(), "updateShortcut(), The compressedBitmap is null, icon = " + icon);
                    }
                    if (intent != null) {
                        values.put("intent", intent.toUri(0));
                    }
                    if (title != null) {
                        values.put("title", title);
                    }
                    contentResolver.update(LauncherSettings.Favorites.CONTENT_URI_NO_NOTIFICATION, values, "_id=?", new String[]{LoggingEvents.EXTRA_CALLING_APP_NAME + itemId});
                    Launcher.updateItem(itemId, bmp, intent, title);
                } else {
                    Log.w(LOG_TAG, "Fail to compress icon : " + itemId);
                }
            } else if (localLOGD) {
                Log.d(LOG_TAG, "Incorrect item type, ignore : " + itemType);
            }
        } else if (localLOGD) {
            Log.d(LOG_TAG, "Not be processed ...");
        }
        if (c != null) {
            c.close();
        }
    }

    static byte[] compressBitmap(Bitmap inBitmap) {
        if (inBitmap != null) {
            Bitmap bitmap = inBitmap.copy(Bitmap.Config.ARGB_8888, false);
            int size = bitmap.getWidth() * bitmap.getHeight() * 4;
            ByteArrayOutputStream out = new ByteArrayOutputStream(size);
            try {
                boolean success = bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                out.flush();
                out.close();
                if (success) {
                    if (localLOGD) {
                        Log.d(LOG_TAG, "Bitmap compressed." + bitmap);
                    }
                    return out.toByteArray();
                }
                if (localLOGD) {
                    Log.d(LOG_TAG, "Bitmap doesn't compressed." + bitmap);
                }
                return null;
            } catch (IOException e) {
                Log.w(LOG_TAG, "Could not write icon");
            }
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void keepIcon4AllApps(String pkgName, Bitmap icon, String title, String select, String[] selectArgs) {
        if (pkgName != null && pkgName.length() != 0) {
            try {
                FilterableAndSortableApplicationInfoList appList = Launcher.getModel().getApplications();
                for (int i = 0; i < appList.originalSize(); i++) {
                    ApplicationInfo info = appList.originalGet(i);
                    if (pkgName.equals(info.packageName) && (selectArgs == null || 1 > selectArgs.length || selectArgs[0] == null || matchComponentName(info, selectArgs[0]))) {
                        TFC.d(LOG_TAG, "keepIcon4AllApps: update icon=" + icon);
                        CarouselInternalActivity carouselInternalActivity = (Launcher) Launcher.sRefLauncher.get();
                        Resources res = carouselInternalActivity.getResources();
                        synchronized (info) {
                            if (icon != null) {
                                info.icon = new BitmapDrawable(res, icon);
                            }
                            if (title != null) {
                                info.title = title;
                            }
                        }
                        if (observer != null) {
                            carouselInternalActivity.runOnUiThread(new Runnable() { // from class: com.htc.launcher.UpdateShortcutReceiver.2
                                @Override // java.lang.Runnable
                                public void run() {
                                    try {
                                        UpdateShortcutReceiver.observer.notifyDataSetChanged();
                                    } catch (Exception e) {
                                        Log.e(UpdateShortcutReceiver.LOG_TAG, "notifyDataSetChanged: e=" + e);
                                        e.printStackTrace();
                                    }
                                }
                            });
                            return;
                        }
                        return;
                    }
                }
            } catch (Exception e) {
                Log.e(LOG_TAG, "keepIcon4AllApps: e=" + e);
                e.printStackTrace();
            }
        }
    }

    private boolean matchComponentName(ApplicationInfo info, String string) {
        int start = 0;
        int end = string.length();
        if (string.startsWith("%")) {
            start = 0 + 1;
        }
        if (string.endsWith("%")) {
            end--;
        }
        if (start >= string.length() || end <= 0) {
            return false;
        }
        try {
            return info.intent.getComponent().flattenToShortString().contains(string.substring(start, end));
        } catch (Exception e) {
            return false;
        }
    }

    public static void registerObserver(BaseAdapter observer2) {
        observer = observer2;
        if (localLOGD) {
            Log.d(LOG_TAG, "registerObserver: observer=" + observer2);
        }
    }

    public static void unregisterObserver() {
        observer = null;
        if (localLOGD) {
            Log.d(LOG_TAG, "unregisterObserver: ");
        }
    }
}
