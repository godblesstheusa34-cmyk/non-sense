package com.htc.launcher;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import junit.framework.Assert;

@Deprecated
/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class HandleView extends ImageView {
    private static final int ORIENTATION_HORIZONTAL = 1;
    private Launcher mLauncher;
    private int mOrientation;

    public HandleView(Context context) {
        super(context);
        this.mOrientation = 1;
        Assert.fail();
    }

    public HandleView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
        Assert.fail();
    }

    public HandleView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mOrientation = 1;
        Assert.fail();
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.HandleView, defStyle, 0);
        this.mOrientation = a.getInt(0, 1);
        a.recycle();
    }

    @Override // android.view.View
    public View focusSearch(int direction) {
        View newFocus = super.focusSearch(direction);
        if (newFocus != null || !this.mLauncher.isDrawerDown()) {
            return newFocus;
        }
        Workspace workspace = this.mLauncher.getWorkspace();
        workspace.dispatchUnhandledMove(null, direction);
        return (this.mOrientation == 1 && direction == 130) ? this : workspace;
    }

    @Override // android.view.View, android.view.KeyEvent.Callback
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        boolean handled = super.onKeyDown(keyCode, event);
        return (handled || this.mLauncher.isDrawerDown() || isDirectionKey(keyCode)) ? handled : this.mLauncher.getApplicationsGrid().onKeyDown(keyCode, event);
    }

    @Override // android.view.View, android.view.KeyEvent.Callback
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        boolean handled = super.onKeyUp(keyCode, event);
        return (handled || this.mLauncher.isDrawerDown() || isDirectionKey(keyCode)) ? handled : this.mLauncher.getApplicationsGrid().onKeyUp(keyCode, event);
    }

    private static boolean isDirectionKey(int keyCode) {
        return keyCode == 20 || keyCode == 21 || keyCode == 22 || keyCode == 19;
    }

    void setLauncher(Launcher launcher) {
        this.mLauncher = launcher;
    }
}
