package com.htc.launcher;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public interface DragSource {

    public enum DragCompletedAction {
        NONE,
        REMOVE,
        SETTING,
        DROP_ON_BUTTONBAR,
        FOLDERICON
    }

    void onDropCompleted(DropTarget dropTarget, boolean z);

    void setDragger(DragController dragController);
}
