package com.htc.launcher;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.util.Log;
import android.view.Menu;
import java.util.List;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class AppSharing {
    private static final String APP_SHARING_ICON = "launcher_share";
    private static final String APP_SHARING_PACKAGE = "com.htc.appsharing";
    private static final String APP_SHARING_TEXT = "launcher_share";
    private static final String LOG_TAG = "Rosie_AppSharing";
    public static boolean localLOGV = false;

    public static void addIfExists(Context context, Menu menu, int groupId, int itemId, int order) {
        try {
            Intent intent = new Intent("com.htc.appsharing.action.GET_SELECTION");
            List<ResolveInfo> infos = context.getPackageManager().queryIntentActivities(intent, 65536);
            if (infos.size() > 0) {
                PackageManager pm = context.getPackageManager();
                Resources resources = pm.getResourcesForApplication(APP_SHARING_PACKAGE);
                int textResId = resources.getIdentifier("launcher_share", "string", APP_SHARING_PACKAGE);
                String text = resources.getString(textResId);
                if (localLOGV) {
                    Log.d(LOG_TAG, "text : " + text);
                }
                menu.add(groupId, itemId, order, text).setIcon(34079543);
            }
        } catch (PackageManager.NameNotFoundException e) {
            if (localLOGV) {
                Log.d(LOG_TAG, "app sharing not found : com.htc.appsharing");
            }
        } catch (Resources.NotFoundException ex) {
            Log.e(LOG_TAG, "resource not found : ", ex);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static void onItemSelected(Launcher launcher) {
        try {
            Intent intent = new Intent("com.htc.appsharing.action.SHARE");
            launcher.startActivity(intent);
        } catch (Exception ex) {
            Log.e(LOG_TAG, ex.getMessage(), ex);
        }
    }
}
