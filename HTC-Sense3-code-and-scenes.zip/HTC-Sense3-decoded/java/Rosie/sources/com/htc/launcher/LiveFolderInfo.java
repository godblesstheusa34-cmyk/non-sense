package com.htc.launcher;

import android.content.ContentValues;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.ViewGroup;
import com.htc.launcher.LauncherSettings;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
class LiveFolderInfo extends FolderInfo {
    Intent baseIntent;
    int displayMode;
    boolean filtered;
    Drawable icon;
    Intent.ShortcutIconResource iconResource;
    Uri uri;

    LiveFolderInfo() {
        this.itemType = 3;
    }

    @Override // com.htc.launcher.FxShortcutInfo, com.htc.launcher.ItemInfo
    void onAddToDatabase(ContentValues values) {
        super.onAddToDatabase(values);
        if (((FolderInfo) this).title != null) {
            values.put("title", ((FolderInfo) this).title.toString());
        }
        if (this.uri != null) {
            values.put("uri", this.uri.toString());
        }
        if (this.baseIntent != null) {
            values.put("intent", this.baseIntent.toUri(0));
        }
        values.put(LauncherSettings.Favorites.ICON_TYPE, (Integer) 0);
        values.put(LauncherSettings.Favorites.DISPLAY_MODE, Integer.valueOf(this.displayMode));
        if (this.iconResource != null) {
            values.put(LauncherSettings.Favorites.ICON_PACKAGE, this.iconResource.packageName);
            values.put(LauncherSettings.Favorites.ICON_RESOURCE, this.iconResource.resourceName);
        }
    }

    @Override // com.htc.launcher.FxShortcutInfo, com.htc.launcher.ItemInfo
    public Draggee createItem(Launcher launcher, ViewGroup container) {
        return LiveFolderIcon.fromXml(R.layout.live_folder_icon, launcher, container, this);
    }

    @Override // com.htc.launcher.FxShortcutInfo, com.htc.launcher.ItemInfo
    public long getId() {
        return this.id;
    }
}
