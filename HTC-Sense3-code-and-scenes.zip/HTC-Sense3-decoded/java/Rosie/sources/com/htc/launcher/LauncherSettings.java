package com.htc.launcher;

import android.net.Uri;
import android.provider.BaseColumns;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class LauncherSettings {

    public static final class WidgetItemTypes implements BaseColumns {
        public static final String SELECT_BY_UNIQUE_NAME = "package_name=? AND widget_name=? ";
        public static final Uri CONTENT_URI = Uri.parse("content://com.htc.launcher.settings/widget_item_types?notify=true");
        public static final String PACKAGE_NAME = "package_name";
        public static final String WIDGET_NAME = "widget_name";
        public static final String PLUGIN_CLASSNAME = "plugin_classname";
        public static final String ITEM_CATEGORY = "item_category";
        public static final String PARENT_ID = "parent_id";
        public static final String TEXT_RESOURCE = "text_resource";
        public static final String ICON_RESOURCE = "icon_resource";
        public static final String SPAN_X = "span_x";
        public static final String SPAN_Y = "span_y";
        public static final String LAYOUT_RESOURCE = "layout_resource";
        public static final String EXTRA_PROPERTIES = "extra_properties";
        static final String[] COLUMN_NAMES = {Favorites.ID, PACKAGE_NAME, WIDGET_NAME, PLUGIN_CLASSNAME, ITEM_CATEGORY, PARENT_ID, TEXT_RESOURCE, ICON_RESOURCE, SPAN_X, SPAN_Y, LAYOUT_RESOURCE, EXTRA_PROPERTIES};
    }

    static Uri getSpecialAction(String action) {
        return Uri.parse("content://com.htc.launcher.settings/" + action);
    }

    public static final class Favorites implements BaseColumns {
        public static final String APPWIDGET_ID = "appWidgetId";
        public static final int CELLY_BUTTONBAR_ITEM = 10;
        public static final String CONTAINER = "container";
        public static final int CONTAINER_DESKTOP = -100;
        public static final String FXWIDGET_ID = "appWidgetId";
        public static final String FXWIDGET_PROVIDER = "intent";
        public static final String FXWIDGET_STYLE = "uri";
        public static final String FXWIDGET_TYPE_ID = "title";
        public static final int ICON_TYPE_BITMAP = 1;
        public static final int ICON_TYPE_RESOURCE = 0;
        public static final String INTENT = "intent";
        public static final int ITEM_TYPE_APPLICATION = 0;
        public static final int ITEM_TYPE_APPWIDGET = 4;
        public static final int ITEM_TYPE_FXWIDGET = 5;
        public static final int ITEM_TYPE_LIVE_FOLDER = 3;
        public static final int ITEM_TYPE_SHORTCUT = 1;
        public static final int ITEM_TYPE_USER_FOLDER = 2;
        public static final int ITEM_TYPE_WIDGET_CLOCK = 1000;
        public static final int ITEM_TYPE_WIDGET_PHOTO_FRAME = 1002;
        public static final int ITEM_TYPE_WIDGET_SEARCH = 1001;
        public static final String TITLE = "title";
        public static final String URI = "uri";
        public static final String WORKSPACE_ID = "workspace_id";
        public static final Uri CONTENT_URI = Uri.parse("content://com.htc.launcher.settings/favorites?notify=true");
        public static final Uri CONTENT_URI_NO_NOTIFICATION = Uri.parse("content://com.htc.launcher.settings/favorites?notify=false");
        public static final String ID = "_id";
        public static final String SCREEN = "screen";
        public static final String CELLX = "cellX";
        public static final String CELLY = "cellY";
        public static final String SPANX = "spanX";
        public static final String SPANY = "spanY";
        public static final String ITEM_TYPE = "itemType";
        public static final String IS_SHORTCUT = "isShortcut";
        public static final String ICON_TYPE = "iconType";
        public static final String ICON_PACKAGE = "iconPackage";
        public static final String ICON_RESOURCE = "iconResource";
        public static final String ICON = "icon";
        public static final String PROPS = "props";
        public static final String ORIG_ID = "orig_id";
        public static final String DISPLAY_MODE = "displayMode";
        public static final String[] COLUMN_NAMES = {ID, "title", "intent", "container", SCREEN, CELLX, CELLY, SPANX, SPANY, ITEM_TYPE, "appWidgetId", IS_SHORTCUT, ICON_TYPE, ICON_PACKAGE, ICON_RESOURCE, ICON, PROPS, "workspace_id", ORIG_ID, "uri", DISPLAY_MODE};

        public static Uri getContentUri(long id, boolean notify) {
            return Uri.parse("content://com.htc.launcher.settings/favorites/" + id + "?notify=" + notify);
        }
    }

    public static final class WidgetWorkspace implements BaseColumns {
        public static final String DISPLAY_NAME = "display_name";
        public static final Uri CONTENT_URI = Uri.parse("content://com.htc.launcher.settings/widget_workspaces?notify=true");
        public static final String CREATED = "created";
        public static final String STATUS = "status";
        public static final String ANCESTOR_ID = "ancestor_id";
        public static final String TRANSLATE_ID = "translate_id";
        public static final String LOCKSCREEN_WALLPAPER_NAME = "lockscreen_wallpaper";
        public static final String WALLPAPER_COMPONENT = "wallpaper_component";
        static final String[] COLUMN_NAMES = {Favorites.ID, "display_name", CREATED, STATUS, ANCESTOR_ID, TRANSLATE_ID, LOCKSCREEN_WALLPAPER_NAME, WALLPAPER_COMPONENT};

        public static Uri getContentUri(long id, boolean notify) {
            return Uri.parse("content://com.htc.launcher.settings/widget_workspaces/" + id + "?notify=" + notify);
        }
    }
}
