package com.htc.launcher;

import android.content.res.Resources;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.view.ViewGroup;
import com.android.common.speech.LoggingEvents;
import com.htc.android.rosie.home.fxcontrol.DropEventListener;
import com.htc.android.rosie.home.fxcontrol.DropZone;
import com.htc.android.rosie.home.fxcontrol.FxDropTarget;
import com.htc.android.rosie.home.fxcontrol.FxShortcutButton;
import com.htc.fusion.fx.FxDraggable;
import com.htc.fusion.fx.controls.FxDragControl;
import com.htc.fusion.fx.controls.FxDropControl;
import com.htc.launcher.DragSource;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class FolderIcon extends FxShortcutButton {
    private static final String DRAGDROP_SCOPE = "empty";
    private static final String LOG_TAG = "FolderIcon";
    public static long SCOPE_KEY_COUNT = 0;
    private Drawable mCloseIcon;
    private Drawable mCurrentIcon;
    private DropZone mDropZone;
    private DropZone mDropZoneLand;
    private UserFolderInfo mInfo;
    private boolean mIsAppDragOver;
    private Launcher mLauncher;
    private Drawable mOpenIcon;

    public FolderIcon(ItemInfo info, int orientation) {
        super(info, orientation);
        this.mIsAppDragOver = true;
        this.mCurrentIcon = null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    static Draggee fromXml(int resId, Launcher launcher, ViewGroup group, UserFolderInfo folderInfo) {
        FolderIcon folderIcon = new FolderIcon(folderInfo, launcher.getOrientation());
        Resources resources = launcher.getResources();
        folderIcon.mCloseIcon = Utilities.createIconThumbnail(resources.getDrawable(34079058), launcher);
        folderIcon.mOpenIcon = resources.getDrawable(34079059);
        folderIcon.setContents(folderIcon.mCloseIcon, folderInfo.title);
        folderIcon.setOnClickListener(launcher.getDesktopItemController().mOnClickFolderListener);
        folderIcon.mInfo = folderInfo;
        folderIcon.mLauncher = launcher;
        Rect rect = new Rect(0, 0, 0, 0);
        int overlayColor = launcher.getResources().getColor(R.color.delete_color_filter);
        FxDropTarget dropTarget = folderIcon.createDropTarget(rect, DragSource.DragCompletedAction.FOLDERICON, "FolderIcon[" + SCOPE_KEY_COUNT + "]");
        if (folderIcon.getFxDropControl() != null) {
            FolderIconZone folderIconZone = folderIcon.createFolderIconZone("empty", folderIcon.getFxDropControl(), dropTarget, overlayColor);
            folderIcon.mDropZone = folderIconZone;
            folderIcon.bindDropEventListener(folderIconZone);
        }
        if (folderIcon.getFxDropControlLand() != null) {
            FolderIconZone folderIconZoneLand = folderIcon.createFolderIconZone("empty", folderIcon.getFxDropControlLand(), dropTarget, overlayColor);
            folderIcon.mDropZoneLand = folderIconZoneLand;
            folderIcon.bindDropEventListener(folderIconZoneLand);
        }
        SCOPE_KEY_COUNT++;
        folderInfo.setDropTarget(dropTarget);
        launcher.addDropTarget(dropTarget);
        Logger.d(LoggingEvents.EXTRA_CALLING_APP_NAME, "[EDIT_DEBUG] addDropTarget() FolderIcon.fromXml() - " + dropTarget);
        return folderIcon;
    }

    private FolderIconZone createFolderIconZone(String scope, FxDropControl drop, FxDropTarget target, int overlayColor) {
        return new FolderIconZone(scope, drop, target, overlayColor);
    }

    private FxDropTarget createDropTarget(Rect rect, DragSource.DragCompletedAction action, String name) {
        return new MyDropTarget(rect, DragSource.DragCompletedAction.FOLDERICON, name);
    }

    void bindDropEventListener(DropZone dropZone) {
        if (this.mLauncher != null && dropZone != null) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] FolderIcon.bindDropEventListener()");
            DropEventListener dropEventListener = new MyDropEventListener(this.mLauncher.getFxWorkspace().getCurrentWorkspace().getDropBar().getDropHandler(), dropZone);
            dropZone.bindListener(dropEventListener);
        }
    }

    final class FolderIconZone extends DropZone {
        public FolderIconZone(String scope, FxDropControl drop, FxDropTarget target, int overlayColor) {
            super(scope, drop, target, overlayColor);
        }

        @Override // com.htc.android.rosie.home.fxcontrol.DropZone
        public void updateBounds() {
            int left = FolderIcon.this.mLauncher.getResources().getDimensionPixelSize(R.dimen.remove_btn_left);
            int top = FolderIcon.this.mLauncher.getResources().getDimensionPixelSize(R.dimen.remove_btn_top);
            int right = FolderIcon.this.mLauncher.getResources().getDimensionPixelSize(R.dimen.remove_btn_right);
            int bottom = FolderIcon.this.mLauncher.getResources().getDimensionPixelSize(R.dimen.remove_btn_bottom);
            Rect removeRect = new Rect(left, top, right, bottom);
            getTarget().bounds = removeRect;
        }
    }

    private class MyDropTarget extends FxDropTarget {
        private String mName;

        public MyDropTarget(Rect rect, DragSource.DragCompletedAction action, String name) {
            super(rect, action);
            this.mName = null;
            this.mName = name;
        }

        @Override // com.htc.android.rosie.home.fxcontrol.FxDropTarget, com.htc.launcher.DropTarget
        public void onDragEnter(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
            Logger.d(FolderIcon.LOG_TAG, "[EDIT_DEBUG] FolderIcon onDragEnter() " + FolderIcon.this);
            super.onDragEnter(source, x, y, xOffset, yOffset, dragItem);
            if (!(dragItem.getItemInfo() instanceof ApplicationInfo)) {
                FolderIcon.this.mIsAppDragOver = false;
            } else {
                FolderIcon.this.mIsAppDragOver = true;
                FolderIcon.this.changeIcon(FolderIcon.this.mOpenIcon);
            }
        }

        @Override // com.htc.android.rosie.home.fxcontrol.FxDropTarget, com.htc.launcher.DropTarget
        public void onDragOver(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
            super.onDragOver(source, x, y, xOffset, yOffset, dragItem);
            if (!(dragItem.getItemInfo() instanceof ApplicationInfo)) {
                FolderIcon.this.mIsAppDragOver = false;
            } else {
                FolderIcon.this.mIsAppDragOver = true;
            }
        }

        @Override // com.htc.android.rosie.home.fxcontrol.FxDropTarget, com.htc.launcher.DropTarget
        public void onDragExit(DragSource source, DropTarget target, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
            Logger.d(FolderIcon.LOG_TAG, "[EDIT_DEBUG] FolderIcon onDragExit() " + FolderIcon.this);
            super.onDragExit(source, target, x, y, xOffset, yOffset, dragItem);
            if (dragItem.getItemInfo() instanceof ApplicationInfo) {
                FolderIcon.this.mIsAppDragOver = true;
                FolderIcon.this.changeIcon(FolderIcon.this.mCloseIcon);
            }
        }

        @Override // com.htc.android.rosie.home.fxcontrol.FxDropTarget, com.htc.launcher.DropTarget
        public boolean acceptDrop(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
            Logger.d(FolderIcon.LOG_TAG, "[EDIT_DEBUG] FolderIcon acceptDrop() " + FolderIcon.this);
            if (dragItem.getItemInfo() instanceof ApplicationInfo) {
                return super.acceptDrop(source, x, y, xOffset, yOffset, dragItem);
            }
            return false;
        }

        @Override // com.htc.android.rosie.home.fxcontrol.FxDropTarget, com.htc.launcher.DropTarget
        public void onDrop(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
            Logger.d(FolderIcon.LOG_TAG, "[EDIT_DEBUG] FolderIcon onDrop() " + FolderIcon.this);
            super.onDrop(source, x, y, xOffset, yOffset, dragItem);
            FolderIcon.this.mIsAppDragOver = true;
        }

        @Override // com.htc.android.rosie.home.fxcontrol.FxDropTarget, com.htc.launcher.DropTarget
        public boolean claimDrop(int x, int y, int[] coordinates) {
            if (!super.claimDrop(x, y, coordinates)) {
                return false;
            }
            Logger.d(FolderIcon.LOG_TAG, "[EDIT_DEBUG] FolderIcon.claimDrop() - " + FolderIcon.this.mIsAppDragOver + ":" + FolderIcon.this);
            return FolderIcon.this.mIsAppDragOver;
        }

        public String toString() {
            return "FxDragTarget." + this.mName;
        }
    }

    private class MyDropEventListener extends DropEventListener {
        MyDropEventListener(Handler handler, DropZone zone) {
            super(handler, zone);
        }

        @Override // com.htc.android.rosie.home.fxcontrol.DropEventListener
        public void handleEvent(FxDraggable drag, DropZone drop, FxDropTarget.State state) {
            if (state == FxDropTarget.State.DROP) {
                Logger.d(FolderIcon.LOG_TAG, "[EDIT_DEBUG] FolderIcon Drop");
                drop.getTarget().mDragOver = false;
                FolderIcon.this.mIsAppDragOver = true;
                FxDragControl dg = (FxDragControl) drag;
                dg.setHighlight(0);
                FolderIcon.this.doDropAction();
                return;
            }
            if (state == FxDropTarget.State.DRAG_OVER) {
                drop.getTarget().mDragOver = true;
                Logger.d(FolderIcon.LOG_TAG, "[EDIT_DEBUG] FolderIcon DragOver!!!!!!!!!!!!!!!!!!!!!!!!!!!! - " + FolderIcon.this.mIsAppDragOver);
            } else if (state == FxDropTarget.State.DRAG_EXIT) {
                Logger.d(FolderIcon.LOG_TAG, "[EDIT_DEBUG] FolderIcon DragExit");
                drop.getTarget().mDragOver = false;
                FolderIcon.this.mIsAppDragOver = true;
                FxDragControl dg2 = (FxDragControl) drag;
                dg2.setHighlight(0);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void changeIcon(Drawable icon) {
        if (this.mCurrentIcon != icon) {
            this.mCurrentIcon = icon;
            setIcon(this.mCurrentIcon);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void doDropAction() {
        Logger.d(LOG_TAG, "[EDIT_DEBUG][tengi] FolderIcon.doDropAction()");
        if (this.mDropZone != null) {
            FxDropTarget target = this.mDropZone.getTarget();
            if (target.item instanceof ApplicationInfo) {
                this.mLauncher.getDesktopItemController().removeDraggedAppIconAddedIntoFolderIcon();
                ApplicationInfo item = (ApplicationInfo) target.item;
                Logger.d(LOG_TAG, "[EDIT_DEBUG][tengi] FolderIcon.doDropAction() item(" + item + ")");
                item.id = -1L;
                this.mInfo.add(item);
                item.container = -1L;
                LauncherModel.addOrMoveItemInDatabase(this.mLauncher, item, this.mInfo.id, 0, 0, 0);
            }
        }
    }

    @Override // com.htc.android.rosie.home.fxcontrol.FxShortcutButton, com.htc.launcher.FxItem, com.htc.launcher.Draggee
    public void onDrop(DropTarget target, int cellX, int cellY) {
        super.onDrop(target, cellX, cellY);
        Logger.d(LOG_TAG, "[EDIT_DEBUG] FolderIcon.onDrop()");
        enableDrop(true);
    }

    @Override // com.htc.android.rosie.home.fxcontrol.FxShortcutButton, com.htc.launcher.FxItem, com.htc.launcher.Draggee
    public void onDrag() {
        super.onDrag();
        Logger.d(LOG_TAG, "[EDIT_DEBUG] FolderIcon.onDrag()");
        enableDrop(false);
    }

    @Override // com.htc.android.rosie.home.fxcontrol.FxShortcutButton, com.htc.launcher.FxItem, com.htc.launcher.Draggee
    public void onDropAbort(DragSource source) {
        super.onDropAbort(source);
        Logger.d(LOG_TAG, "[EDIT_DEBUG] FolderIcon.onDropAbort()");
        enableDrop(true);
    }

    public void onStartDrag() {
        enableDrop(false);
    }

    public void onEndDrag() {
        enableDrop(true);
    }

    private void enableDrop(boolean enable) {
        if (this.mDropZone != null) {
            this.mDropZone.setEnabled(enable);
            FxDropControl drop = getFxDropControl();
            if (drop != null) {
                drop.setVisibility(enable);
            }
        }
    }
}
