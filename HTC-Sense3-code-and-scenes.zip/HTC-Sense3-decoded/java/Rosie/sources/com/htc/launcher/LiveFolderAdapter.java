package com.htc.launcher;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.htc.launcher.LauncherSettings;
import java.lang.ref.SoftReference;
import java.net.URISyntaxException;
import java.util.HashMap;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
class LiveFolderAdapter extends CursorAdapter {
    private final HashMap<Long, SoftReference<Drawable>> mCustomIcons;
    private final HashMap<String, Drawable> mIcons;
    private LayoutInflater mInflater;
    private boolean mIsList;
    private final Launcher mLauncher;

    /* JADX WARN: Multi-variable type inference failed */
    LiveFolderAdapter(Launcher launcher, LiveFolderInfo info, Cursor cursor) {
        super((Context) launcher, cursor, true);
        this.mIcons = new HashMap<>();
        this.mCustomIcons = new HashMap<>();
        this.mIsList = info.displayMode == 2;
        this.mInflater = LayoutInflater.from(launcher);
        this.mLauncher = launcher;
        this.mLauncher.startManagingCursor(getCursor());
    }

    static Cursor query(Context context, LiveFolderInfo info) {
        return context.getContentResolver().query(info.uri, null, null, null, "name ASC");
    }

    @Override // android.widget.CursorAdapter
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        View view;
        ViewHolder holder = new ViewHolder();
        if (!this.mIsList) {
            view = this.mInflater.inflate(R.layout.application_boxed, parent, false);
        } else {
            view = this.mInflater.inflate(R.layout.rosie_application_list, parent, false);
            holder.description = (TextView) view.findViewById(R.id.description);
            holder.icon = (ImageView) view.findViewById(R.id.icon);
        }
        holder.name = (TextView) view.findViewById(R.id.name);
        holder.idIndex = cursor.getColumnIndexOrThrow(LauncherSettings.Favorites.ID);
        holder.nameIndex = cursor.getColumnIndexOrThrow("name");
        holder.descriptionIndex = cursor.getColumnIndex("description");
        holder.intentIndex = cursor.getColumnIndex("intent");
        holder.iconBitmapIndex = cursor.getColumnIndex("icon_bitmap");
        holder.iconResourceIndex = cursor.getColumnIndex(LauncherSettings.WidgetItemTypes.ICON_RESOURCE);
        holder.iconPackageIndex = cursor.getColumnIndex("icon_package");
        view.setTag(holder);
        return view;
    }

    @Override // android.widget.CursorAdapter
    public void bindView(View view, Context context, Cursor cursor) {
        ViewHolder holder = (ViewHolder) view.getTag();
        holder.id = cursor.getLong(holder.idIndex);
        Drawable icon = loadIcon(context, cursor, holder);
        holder.name.setText(cursor.getString(holder.nameIndex));
        if (!this.mIsList) {
            holder.name.setCompoundDrawablesWithIntrinsicBounds((Drawable) null, icon, (Drawable) null, (Drawable) null);
        } else {
            boolean hasIcon = icon != null;
            holder.icon.setVisibility(hasIcon ? 0 : 8);
            if (hasIcon) {
                holder.icon.setImageDrawable(icon);
            }
            if (holder.descriptionIndex != -1) {
                String description = cursor.getString(holder.descriptionIndex);
                if (description != null) {
                    holder.description.setText(description);
                    holder.description.setVisibility(0);
                } else {
                    holder.description.setVisibility(8);
                }
            } else {
                holder.description.setVisibility(8);
            }
        }
        if (holder.intentIndex != -1) {
            try {
                holder.intent = Intent.parseUri(cursor.getString(holder.intentIndex), 0);
            } catch (URISyntaxException e) {
            }
        } else {
            holder.useBaseIntent = true;
        }
    }

    private Drawable loadIcon(Context context, Cursor cursor, ViewHolder holder) {
        Drawable icon = null;
        byte[] data = null;
        if (holder.iconBitmapIndex != -1) {
            data = cursor.getBlob(holder.iconBitmapIndex);
        }
        if (data != null) {
            SoftReference<Drawable> reference = this.mCustomIcons.get(Long.valueOf(holder.id));
            if (reference != null) {
                Drawable icon2 = reference.get();
                icon = icon2;
            }
            if (icon == null) {
                Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
                Drawable icon3 = new FastBitmapDrawable(Utilities.createBitmapThumbnail(bitmap, ((CursorAdapter) this).mContext));
                this.mCustomIcons.put(Long.valueOf(holder.id), new SoftReference<>(icon3));
                return icon3;
            }
            return icon;
        }
        if (holder.iconResourceIndex == -1 || holder.iconPackageIndex == -1) {
            return null;
        }
        String resource = cursor.getString(holder.iconResourceIndex);
        Drawable icon4 = this.mIcons.get(resource);
        Drawable icon5 = icon4;
        if (icon5 == null) {
            try {
                PackageManager packageManager = context.getPackageManager();
                Resources resources = packageManager.getResourcesForApplication(cursor.getString(holder.iconPackageIndex));
                int id = resources.getIdentifier(resource, null, null);
                icon5 = Utilities.createIconThumbnail(resources.getDrawable(id), ((CursorAdapter) this).mContext);
                this.mIcons.put(resource, icon5);
                return icon5;
            } catch (Exception e) {
                return icon5;
            }
        }
        return icon5;
    }

    void cleanup() {
        for (Drawable icon : this.mIcons.values()) {
            icon.setCallback(null);
        }
        this.mIcons.clear();
        for (SoftReference<Drawable> icon2 : this.mCustomIcons.values()) {
            Drawable drawable = icon2.get();
            if (drawable != null) {
                drawable.setCallback(null);
            }
        }
        this.mCustomIcons.clear();
        Cursor cursor = getCursor();
        if (cursor != null) {
            try {
                cursor.close();
            } finally {
                this.mLauncher.stopManagingCursor(cursor);
            }
        }
    }

    static class ViewHolder {
        TextView description;
        ImageView icon;
        long id;
        int idIndex;
        Intent intent;
        TextView name;
        int nameIndex;
        boolean useBaseIntent;
        int descriptionIndex = -1;
        int intentIndex = -1;
        int iconBitmapIndex = -1;
        int iconResourceIndex = -1;
        int iconPackageIndex = -1;

        ViewHolder() {
        }
    }
}
