package com.htc.launcher.widget;

import android.text.TextUtils;
import com.htc.widget.HtcListItemSeparable;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class HtcSimpleSeparable implements HtcListItemSeparable {
    protected boolean mDrawOnThis;
    protected String mSeparateID;

    public HtcSimpleSeparable(String id) {
        this.mSeparateID = id;
        this.mDrawOnThis = true;
    }

    public HtcSimpleSeparable(String id, boolean drawOnThis) {
        this.mSeparateID = id;
        this.mDrawOnThis = drawOnThis;
    }

    public final String getSeparateID() {
        return this.mSeparateID;
    }

    public void setSeparateID(String id) {
        this.mSeparateID = id;
    }

    public final boolean getShouldDrawOnThis() {
        return this.mDrawOnThis;
    }

    public void setSeparateID(boolean drawOnThis) {
        this.mDrawOnThis = drawOnThis;
    }

    public boolean shouldDrawOnThis() {
        return this.mDrawOnThis;
    }

    public boolean shouldSeparate(Object listitem) {
        if (listitem != null && (listitem instanceof HtcSimpleSeparable)) {
            HtcSimpleSeparable nextTag = (HtcSimpleSeparable) listitem;
            String nextID = nextTag.getSeparateID();
            if (this.mSeparateID == null && nextID == null) {
                return false;
            }
            if ((this.mSeparateID == null && nextID != null) || (this.mSeparateID != null && nextID == null)) {
                return true;
            }
            if (TextUtils.isEmpty(this.mSeparateID) && TextUtils.isEmpty(nextID)) {
                return false;
            }
            if ((!TextUtils.isEmpty(this.mSeparateID) || TextUtils.isEmpty(nextID)) && (TextUtils.isEmpty(this.mSeparateID) || !TextUtils.isEmpty(nextID))) {
                return !this.mSeparateID.equals(nextID);
            }
            return true;
        }
        return true;
    }
}
