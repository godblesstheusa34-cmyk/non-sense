package com.htc.launcher;

import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.ComponentInfo;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.SQLException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Process;
import android.util.Log;
import com.android.common.speech.LoggingEvents;
import com.android.internal.os.HtcAppUsageStats;
import com.htc.android.rosie.widget.WidgetProvider;
import com.htc.app.HtcUsageStats;
import com.htc.launcher.LauncherSettings;
import com.htc.launcher.config.FavoriteData;
import com.htc.launcher.fusion.WidgetProviderInfoCollector;
import com.htc.launcher.model.FilterableAndSortableApplicationInfoList;
import com.htc.utils.ulog.ReusableULogData;
import com.htc.utils.ulog.ULog;
import com.htc.widget.CarouselInternalActivity;
import java.io.File;
import java.lang.ref.WeakReference;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class LauncherModel {
    private static final long APPLICATION_NOT_RESPONDING_TIMEOUT = 5000;
    private static final boolean DEBUG = false;
    static final boolean DEBUG_LOADERS = true;
    private static final int DEFAULT_APPLICATIONS_NUMBER = 42;
    private static final int INITIAL_ICON_CACHE_CAPACITY = 50;
    static final String LOG_TAG = "HomeLoaders";
    public static final int SORT_BY_LAUNCH_COUNT_DESC = 103;
    public static final int SORT_BY_NAME = 100;
    public static final int SORT_BY_OPERATOR_TAB = 104;
    public static final int SORT_BY_TIME_NEW_TO_OLD = 101;
    public static final int SORT_BY_TIME_OLD_TO_NEW = 102;
    private static final int UI_NOTIFICATION_RATE = 4;
    private static Configuration sUsConfiguration = new Configuration();
    private static HashMap<String, Integer> sUsageMap;
    private static HtcUsageStats sUsageStatsService;
    FilterableAndSortableApplicationInfoList mApplications;
    private ApplicationsAdapter mApplicationsAdapter;
    private boolean mApplicationsLoaded;
    private ApplicationsLoader mApplicationsLoader;
    private Thread mApplicationsLoaderThread;
    private ArrayList<ItemInfo> mButtonBarItems;
    private ArrayList<LauncherAppWidgetInfo> mDesktopAppWidgets;
    private ArrayList<ItemInfo> mDesktopItems;
    private boolean mDesktopItemsLoaded;
    private DesktopItemsLoader mDesktopItemsLoader;
    private Thread mDesktopLoaderThread;
    private HashMap<Long, FolderInfo> mFolders;
    private boolean skipOutputAllDeskItems = false;
    private final HashMap<ComponentName, ApplicationInfo> mAppInfoCache = new HashMap<>(INITIAL_ICON_CACHE_CAPACITY);

    synchronized void abortLoaders() {
        if (this.mApplicationsLoader != null && this.mApplicationsLoader.isRunning()) {
            this.mApplicationsLoader.stop();
            this.mApplicationsLoaded = false;
        }
        if (this.mDesktopItemsLoader != null && this.mDesktopItemsLoader.isRunning()) {
            this.mDesktopItemsLoader.stop();
            this.mDesktopItemsLoaded = false;
        }
    }

    synchronized void dropApplicationCache() {
        this.mAppInfoCache.clear();
    }

    /* JADX WARN: Multi-variable type inference failed */
    synchronized boolean loadApplications(boolean isLaunching, Launcher launcher, boolean localeChanged) {
        boolean z;
        refreshUsageStatCache(launcher);
        if (isLaunching && this.mApplicationsLoaded && !localeChanged) {
            this.mApplicationsAdapter = new ApplicationsAdapter((Context) launcher, this.mApplications);
            this.mApplicationsAdapter.getList().sort(FilterableAndSortableApplicationInfoList.ALPHABET);
            Log.d(LOG_TAG, "  --> applications loaded, return");
            z = false;
        } else {
            stopAndWaitForApplicationsLoader();
            if (localeChanged) {
                dropApplicationCache();
            }
            if (this.mApplicationsAdapter == null || isLaunching || localeChanged) {
                this.mApplications = new FilterableAndSortableApplicationInfoList();
                this.mApplicationsAdapter = new ApplicationsAdapter((Context) launcher, this.mApplications);
                this.mApplicationsAdapter.getList().sort(FilterableAndSortableApplicationInfoList.ALPHABET);
            }
            this.mApplicationsLoaded = false;
            if (!isLaunching) {
                startApplicationsLoader(launcher);
                z = false;
            } else {
                z = true;
            }
        }
        return z;
    }

    private synchronized void stopAndWaitForApplicationsLoader() {
        if (this.mApplicationsLoader != null && this.mApplicationsLoader.isRunning()) {
            Log.d(LOG_TAG, "  --> wait for applications loader");
            this.mApplicationsLoader.stop();
            try {
                this.mApplicationsLoaderThread.join(APPLICATION_NOT_RESPONDING_TIMEOUT);
            } catch (InterruptedException e) {
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void startApplicationsLoader(Launcher launcher) {
        Log.d(LOG_TAG, "  --> starting applications loader");
        stopAndWaitForApplicationsLoader();
        this.mApplicationsLoader = new ApplicationsLoader(launcher);
        this.mApplicationsLoaderThread = new Thread(this.mApplicationsLoader, "Applications Loader");
        this.mApplicationsLoaderThread.start();
    }

    synchronized void addPackage(final Launcher launcher, final String packageName) {
        if (this.mApplicationsLoader != null && this.mApplicationsLoader.isRunning()) {
            startApplicationsLoader(launcher);
        } else if (packageName != null && packageName.length() > 0) {
            Thread thread = new Thread("addPackage") { // from class: com.htc.launcher.LauncherModel.1
                @Override // java.lang.Thread, java.lang.Runnable
                public void run() {
                    PackageManager packageManager = launcher.getPackageManager();
                    List<ResolveInfo> matches = LauncherModel.findActivitiesForPackage(packageManager, packageName);
                    if (matches.size() > 0) {
                        final ApplicationsAdapter adapter = LauncherModel.this.mApplicationsAdapter;
                        HashMap<ComponentName, ApplicationInfo> cache = LauncherModel.this.mAppInfoCache;
                        ArrayList<ApplicationInfo> toAdd = new ArrayList<>();
                        for (ResolveInfo info : matches) {
                            toAdd.add(LauncherModel.makeAndCacheApplicationInfo(packageManager, cache, info));
                        }
                        FilterableAndSortableApplicationInfoList list = LauncherModel.this.getApplications();
                        list.addAll(toAdd);
                        launcher.runOnUiThread(new Runnable() { // from class: com.htc.launcher.LauncherModel.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                adapter.notifyDataSetChanged();
                            }
                        });
                    }
                }
            };
            thread.start();
        }
    }

    synchronized void removePackage(Launcher launcher, String packageName) {
        if (this.mApplicationsLoader != null && this.mApplicationsLoader.isRunning()) {
            dropApplicationCache();
            startApplicationsLoader(launcher);
        } else if (packageName != null && packageName.length() > 0) {
            ApplicationsAdapter adapter = this.mApplicationsAdapter;
            List<ApplicationInfo> toRemove = new ArrayList<>();
            int count = adapter.getCount();
            for (int i = 0; i < count; i++) {
                ApplicationInfo applicationInfo = adapter.getItem(i);
                Intent intent = applicationInfo.intent;
                ComponentName component = intent.getComponent();
                if (packageName.equals(component.getPackageName())) {
                    toRemove.add(applicationInfo);
                }
            }
            HashMap<ComponentName, ApplicationInfo> cache = this.mAppInfoCache;
            FilterableAndSortableApplicationInfoList list = getApplications();
            for (ApplicationInfo info : toRemove) {
                list.remove(info);
                cache.remove(info.intent.getComponent());
            }
            if (toRemove.size() > 0) {
                adapter.notifyDataSetChanged();
            }
        }
    }

    synchronized void updatePackage(final Launcher launcher, final String packageName) {
        if (this.mApplicationsLoader != null && this.mApplicationsLoader.isRunning()) {
            startApplicationsLoader(launcher);
        } else if (packageName != null && packageName.length() > 0) {
            Thread thread = new Thread("updatePackage") { // from class: com.htc.launcher.LauncherModel.2
                @Override // java.lang.Thread, java.lang.Runnable
                public void run() {
                    PackageManager packageManager = launcher.getPackageManager();
                    final ApplicationsAdapter adapter = LauncherModel.this.mApplicationsAdapter;
                    List<ResolveInfo> matches = LauncherModel.findActivitiesForPackage(packageManager, packageName);
                    int count = matches.size();
                    boolean changed = false;
                    ArrayList<ApplicationInfo> toAdd = new ArrayList<>();
                    for (int i = 0; i < count; i++) {
                        ResolveInfo info = matches.get(i);
                        ApplicationInfo applicationInfo = LauncherModel.findIntent(LauncherModel.this.getApplications(), ((PackageItemInfo) ((ComponentInfo) info.activityInfo).applicationInfo).packageName, ((PackageItemInfo) info.activityInfo).name);
                        if (applicationInfo != null) {
                            LauncherModel.this.updateAndCacheApplicationInfo(packageManager, info, applicationInfo);
                        } else {
                            ArrayList<ApplicationInfo> applicationInfos = LauncherModel.findApplicationInfoByPackageName(adapter, ((PackageItemInfo) ((ComponentInfo) info.activityInfo).applicationInfo).packageName);
                            if (applicationInfos != null) {
                                Iterator i$ = applicationInfos.iterator();
                                while (i$.hasNext()) {
                                    ApplicationInfo replacedInfo = i$.next();
                                    LauncherModel.this.getApplications().remove(replacedInfo);
                                }
                            }
                            toAdd.add(LauncherModel.makeAndCacheApplicationInfo(packageManager, LauncherModel.this.mAppInfoCache, info));
                        }
                        changed = true;
                    }
                    LauncherModel.this.getApplications().addAll(toAdd);
                    if (changed) {
                        launcher.runOnUiThread(new Runnable() { // from class: com.htc.launcher.LauncherModel.2.1
                            @Override // java.lang.Runnable
                            public void run() {
                                adapter.notifyDataSetChanged();
                                launcher.mWorkspace.updateShortcutsForPackage(packageName);
                            }
                        });
                    }
                }
            };
            thread.start();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateAndCacheApplicationInfo(PackageManager packageManager, ResolveInfo info, ApplicationInfo applicationInfo) {
        updateApplicationInfoTitleAndIcon(packageManager, info, applicationInfo);
        ComponentName componentName = new ComponentName(((PackageItemInfo) ((ComponentInfo) info.activityInfo).applicationInfo).packageName, ((PackageItemInfo) info.activityInfo).name);
        this.mAppInfoCache.put(componentName, applicationInfo);
    }

    /* JADX WARN: Multi-variable type inference failed */
    synchronized boolean syncPackage(Launcher launcher, String packageName) {
        boolean z;
        boolean ret = false;
        if (this.mApplicationsLoader != null && this.mApplicationsLoader.isRunning()) {
            startApplicationsLoader(launcher);
            z = false;
        } else if (this.mApplicationsAdapter == null) {
            z = false;
        } else {
            if (packageName != null && packageName.length() > 0) {
                PackageManager packageManager = launcher.getPackageManager();
                List<ResolveInfo> matches = findActivitiesForPackage(packageManager, packageName);
                final ApplicationsAdapter adapter = this.mApplicationsAdapter;
                boolean removed = removeDisabledActivities(packageName, matches, adapter);
                ret = removed;
                boolean added = addEnabledAndUpdateActivities(matches, adapter, launcher);
                if (added || removed) {
                    launcher.runOnUiThread(new Runnable() { // from class: com.htc.launcher.LauncherModel.3
                        @Override // java.lang.Runnable
                        public void run() {
                            adapter.notifyDataSetChanged();
                        }
                    });
                }
            }
            z = ret;
        }
        return z;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static List<ResolveInfo> findActivitiesForPackage(PackageManager packageManager, String packageName) {
        Intent mainIntent = new Intent("android.intent.action.MAIN", (Uri) null);
        mainIntent.addCategory("android.intent.category.LAUNCHER");
        List<ResolveInfo> apps = packageManager.queryIntentActivities(mainIntent, 0);
        List<ResolveInfo> matches = new ArrayList<>();
        if (apps != null) {
            int count = apps.size();
            for (int i = 0; i < count; i++) {
                ResolveInfo info = apps.get(i);
                ActivityInfo activityInfo = info.activityInfo;
                if (packageName.equals(((PackageItemInfo) activityInfo).packageName)) {
                    matches.add(info);
                }
            }
        }
        return matches;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private boolean addEnabledAndUpdateActivities(List<ResolveInfo> matches, ApplicationsAdapter adapter, Launcher launcher) {
        List<ApplicationInfo> toAdd = new ArrayList<>();
        int count = matches.size();
        boolean changed = false;
        for (int i = 0; i < count; i++) {
            ResolveInfo info = matches.get(i);
            ApplicationInfo applicationInfo = findIntent(getApplications(), ((PackageItemInfo) ((ComponentInfo) info.activityInfo).applicationInfo).packageName, ((PackageItemInfo) info.activityInfo).name);
            if (applicationInfo == null) {
                toAdd.add(makeAndCacheApplicationInfo(launcher.getPackageManager(), this.mAppInfoCache, info));
            } else {
                updateAndCacheApplicationInfo(launcher.getPackageManager(), info, applicationInfo);
            }
            changed = true;
        }
        getApplications().addAll(toAdd);
        return changed;
    }

    private boolean removeDisabledActivities(String packageName, List<ResolveInfo> matches, ApplicationsAdapter adapter) {
        List<ApplicationInfo> toRemove = new ArrayList<>();
        int count = adapter.getCount();
        boolean changed = false;
        for (int i = 0; i < count; i++) {
            ApplicationInfo applicationInfo = adapter.getItem(i);
            Intent intent = applicationInfo.intent;
            ComponentName component = intent.getComponent();
            if (packageName.equals(component.getPackageName())) {
                toRemove.add(applicationInfo);
                if (!findIntent(matches, component)) {
                    changed = true;
                }
            }
        }
        HashMap<ComponentName, ApplicationInfo> cache = this.mAppInfoCache;
        for (ApplicationInfo info : toRemove) {
            getApplications().remove(info);
            cache.remove(info.intent.getComponent());
        }
        return changed;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static ApplicationInfo findIntent(FilterableAndSortableApplicationInfoList list, String packageName, String name) {
        int count = list.originalSize();
        for (int i = 0; i < count; i++) {
            ApplicationInfo applicationInfo = list.originalGet(i);
            Intent intent = applicationInfo.intent;
            ComponentName component = intent.getComponent();
            if (packageName.equals(component.getPackageName()) && name.equals(component.getClassName())) {
                return applicationInfo;
            }
        }
        return null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static ArrayList<ApplicationInfo> findApplicationInfoByPackageName(ApplicationsAdapter adapter, String packageName) {
        ArrayList<ApplicationInfo> list = null;
        int count = adapter.getCount();
        for (int i = 0; i < count; i++) {
            ApplicationInfo applicationInfo = adapter.getItem(i);
            Intent intent = applicationInfo.intent;
            ComponentName component = intent.getComponent();
            if (packageName.equals(component.getPackageName())) {
                if (list == null) {
                    list = new ArrayList<>();
                }
                list.add(applicationInfo);
            }
        }
        return list;
    }

    private static boolean findIntent(List<ResolveInfo> apps, ComponentName component) {
        String className = component.getClassName();
        for (ResolveInfo info : apps) {
            ActivityInfo activityInfo = info.activityInfo;
            if (((PackageItemInfo) activityInfo).name.equals(className)) {
                return true;
            }
        }
        return false;
    }

    Drawable getApplicationInfoIcon(PackageManager manager, ApplicationInfo info) {
        ResolveInfo resolveInfo = manager.resolveActivity(info.intent, 0);
        if (resolveInfo == null) {
            return null;
        }
        ComponentName componentName = new ComponentName(((PackageItemInfo) ((ComponentInfo) resolveInfo.activityInfo).applicationInfo).packageName, ((PackageItemInfo) resolveInfo.activityInfo).name);
        ApplicationInfo application = this.mAppInfoCache.get(componentName);
        if (application == null) {
            return ResourceUtil.getApplicationIcon(manager, resolveInfo.activityInfo);
        }
        return application.icon;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static ApplicationInfo makeAndCacheApplicationInfo(PackageManager manager, HashMap<ComponentName, ApplicationInfo> appInfoCache, ResolveInfo info) {
        ComponentName componentName = new ComponentName(((PackageItemInfo) ((ComponentInfo) info.activityInfo).applicationInfo).packageName, ((PackageItemInfo) info.activityInfo).name);
        ApplicationInfo application = appInfoCache.get(componentName);
        if (application == null) {
            application = new ApplicationInfo();
            application.container = -1L;
            updateApplicationInfoTitleAndIcon(manager, info, application);
            application.setActivity(componentName, 270532608);
            String activityScrouceDir = ((ComponentInfo) info.activityInfo).applicationInfo.publicSourceDir;
            File applicationSource = new File(activityScrouceDir);
            if (applicationSource.exists() && !activityScrouceDir.startsWith("/system/app/")) {
                application.lastModifiedTime = applicationSource.lastModified();
            } else {
                application.lastModifiedTime = 0L;
            }
            application.isDownloaded = isDownloadedApp(info);
            application.packageName = new String(((PackageItemInfo) ((ComponentInfo) info.activityInfo).applicationInfo).packageName);
            application.customizeAppId = getCustomAppId(info, manager);
            application.launchCount = getLaunchCount(application.packageName, application.customizeAppId);
            TFC.d("VivoWCTGBS_246", "LauncherModel.makeAndCacheApplicationInfo: title=" + ((Object) application.title) + " pkg=" + ((PackageItemInfo) ((ComponentInfo) info.activityInfo).applicationInfo).packageName + " priority=" + application.priority + " modified=" + application.lastModifiedTime);
            appInfoCache.put(componentName, application);
        }
        return application;
    }

    private static void updateApplicationInfoTitleAndIcon(PackageManager manager, ResolveInfo info, ApplicationInfo application) {
        application.title = info.loadLabel(manager);
        if (application.title == null) {
            application.title = ((PackageItemInfo) info.activityInfo).name;
        }
        try {
            application.icon = ResourceUtil.getApplicationIcon(manager, info.activityInfo);
        } catch (Resources.NotFoundException e) {
            Log.w(LOG_TAG, "LauncherModel.updateApplicationInfoTitleAndIcon() - icon not found.");
        }
        application.filtered = false;
        application.isDownloaded = isDownloadedApp(info);
        application.packageName = new String(((PackageItemInfo) ((ComponentInfo) info.activityInfo).applicationInfo).packageName);
        application.customizeAppId = getCustomAppId(info, manager);
        application.launchCount = getLaunchCount(application.packageName, application.customizeAppId);
    }

    private class ApplicationsLoader implements Runnable {
        private final WeakReference<Launcher> mLauncher;
        private volatile boolean mRunning;
        private volatile boolean mStopped;

        ApplicationsLoader(Launcher launcher) {
            this.mLauncher = new WeakReference<>(launcher);
        }

        void stop() {
            this.mStopped = true;
        }

        boolean isRunning() {
            return this.mRunning;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.mRunning = true;
            Process.setThreadPriority(10);
            Intent mainIntent = new Intent("android.intent.action.MAIN", (Uri) null);
            mainIntent.addCategory("android.intent.category.LAUNCHER");
            CarouselInternalActivity carouselInternalActivity = (Launcher) this.mLauncher.get();
            PackageManager manager = carouselInternalActivity.getPackageManager();
            List<ResolveInfo> apps = manager.queryIntentActivities(mainIntent, 0);
            carouselInternalActivity.getResources().getStringArray(R.array.original_need_changed_names);
            carouselInternalActivity.getResources().getStringArray(R.array.original_change_to_names);
            ApplicationManager am = ApplicationManager.instance(carouselInternalActivity);
            if (apps != null && !this.mStopped) {
                int count = apps.size();
                ApplicationsAdapter applicationList = LauncherModel.this.mApplicationsAdapter;
                ChangeNotifier action = new ChangeNotifier(applicationList, true);
                HashMap<ComponentName, ApplicationInfo> appInfoCache = LauncherModel.this.mAppInfoCache;
                for (int i = 0; i < count && !this.mStopped; i++) {
                    ResolveInfo info = apps.get(i);
                    if (!am.inHideCustomizationList(((PackageItemInfo) ((ComponentInfo) info.activityInfo).applicationInfo).packageName, ((PackageItemInfo) info.activityInfo).name, 1)) {
                        ApplicationInfo application = LauncherModel.makeAndCacheApplicationInfo(manager, appInfoCache, info);
                        application.title = AllAppsGridView.translateAppTitle((String) application.title, carouselInternalActivity);
                        application.priority = am.getCustomizationListPriority(((PackageItemInfo) ((ComponentInfo) info.activityInfo).applicationInfo).packageName, ((PackageItemInfo) info.activityInfo).name, 1);
                        TFC.d("VivoWCTGBS_246", "LauncherModel.ApplicationsLoader: title=" + ((Object) application.title) + " pkg=" + ((PackageItemInfo) ((ComponentInfo) info.activityInfo).applicationInfo).packageName + " priority=" + application.priority + " modified=" + application.lastModifiedTime);
                        if (action.add(application) && !this.mStopped) {
                            carouselInternalActivity.runOnUiThread(action);
                            action = new ChangeNotifier(applicationList, false);
                        }
                    }
                }
                carouselInternalActivity.runOnUiThread(action);
            }
            if (!this.mStopped) {
                LauncherModel.this.mApplicationsLoaded = true;
            }
            this.mRunning = false;
        }
    }

    private static boolean isDownloadedApp(ResolveInfo rInfo) {
        android.content.pm.ApplicationInfo appInfo = ((ComponentInfo) rInfo.activityInfo).applicationInfo;
        return (appInfo.flags & 1) == 0 || (appInfo.flags & 128) != 0;
    }

    private static class ChangeNotifier implements Runnable {
        private final ApplicationsAdapter mApplicationList;
        private final ArrayList<ApplicationInfo> mBuffer = new ArrayList<>(4);
        private boolean mFirst;

        ChangeNotifier(ApplicationsAdapter applicationList, boolean first) {
            this.mFirst = true;
            this.mApplicationList = applicationList;
            this.mFirst = first;
        }

        @Override // java.lang.Runnable
        public void run() {
            ApplicationsAdapter applicationList = this.mApplicationList;
            if (applicationList != null) {
                if (this.mFirst) {
                    applicationList.getList().clear();
                    this.mFirst = false;
                }
                applicationList.getList().addAll(this.mBuffer);
                this.mBuffer.clear();
                applicationList.notifyDataSetChanged();
            }
        }

        boolean add(ApplicationInfo application) {
            ArrayList<ApplicationInfo> buffer = this.mBuffer;
            buffer.add(application);
            return buffer.size() >= 4;
        }
    }

    boolean isDesktopLoaded() {
        return this.mDesktopItems != null && this.mDesktopItemsLoaded;
    }

    static ApplicationInfo getShortcut(FavoriteData favdata, Context launcher) {
        if (favdata.packageName == null || favdata.className == null) {
            return null;
        }
        ApplicationInfo info = new ApplicationInfo();
        info.workspaceId = favdata.workspaceId;
        info.cellX = favdata.x;
        info.cellY = favdata.y;
        info.screen = favdata.screen;
        info.title = favdata.title;
        info.container = 1L;
        info.removable = favdata.removable != 0;
        Intent intent = new Intent();
        intent.setAction(LauncherIntent.ACTION_CUSTOMIZE_SHORTCUT);
        intent.setClassName(favdata.packageName, favdata.className);
        if (favdata.url != null) {
            Uri uri = Uri.parse(favdata.url);
            intent.setData(uri);
            intent.setAction("android.intent.action.VIEW");
        }
        info.intent = intent;
        if (favdata.icon == null) {
            ApplicationInfo tempinfo = getApplicationInfo(launcher.getPackageManager(), intent);
            if (tempinfo != null) {
                info.icon = tempinfo.icon;
            } else {
                info.icon = getNonScaledBitmapDrawable(launcher.getResources(), WidgetPackageManager.manipulateResourcePath("ic_def_app_icon.png"));
            }
            info.iconname = null;
        } else {
            info.icon = getNonScaledBitmapDrawable(launcher.getResources(), WidgetPackageManager.manipulateResourcePath(favdata.icon));
            info.iconname = WidgetPackageManager.manipulateResourcePath(favdata.icon);
        }
        return info;
    }

    static BitmapDrawable getNonScaledBitmapDrawable(Resources res, String filename) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inScaled = false;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap bitmap = BitmapFactory.decodeFile(filename, options);
        return new BitmapDrawable(res, bitmap);
    }

    public static ApplicationInfo getApplication(FavoriteData favdata, Context context) {
        if (favdata.packageName == null || favdata.className == null) {
            return null;
        }
        ComponentName component = new ComponentName(favdata.packageName, favdata.className);
        PackageManager packageManager = context.getPackageManager();
        ActivityInfo activityInfo = null;
        try {
            activityInfo = packageManager.getActivityInfo(component, 0);
        } catch (PackageManager.NameNotFoundException e) {
            Log.w(LOG_TAG, "Couldn't find ActivityInfo for selected application : " + component);
        }
        if (activityInfo == null) {
            return null;
        }
        ApplicationInfo itemInfo = new ApplicationInfo();
        itemInfo.title = activityInfo.loadLabel(packageManager);
        if (itemInfo.title == null) {
            itemInfo.title = ((PackageItemInfo) activityInfo).name;
        }
        itemInfo.setActivity(component, 270532608);
        itemInfo.icon = ResourceUtil.getApplicationIcon(packageManager, activityInfo);
        itemInfo.container = -1L;
        itemInfo.cellX = favdata.x;
        itemInfo.cellY = favdata.y;
        itemInfo.screen = favdata.screen;
        itemInfo.workspaceId = favdata.workspaceId;
        return itemInfo;
    }

    void loadUserItems(boolean isLaunching, Launcher launcher, boolean localeChanged, boolean loadApplications) {
        Log.d(LOG_TAG, "loading user items");
        if (isLaunching && isDesktopLoaded()) {
            Log.d(LOG_TAG, "  --> items loaded, return");
            if (loadApplications) {
                startApplicationsLoader(launcher);
            }
            launcher.onDesktopItemsLoaded();
            return;
        }
        if (this.mDesktopItemsLoader != null && this.mDesktopItemsLoader.isRunning()) {
            Log.d(LOG_TAG, "  --> stopping workspace loader");
            this.mDesktopItemsLoader.stop();
            try {
                this.mDesktopLoaderThread.join(APPLICATION_NOT_RESPONDING_TIMEOUT);
            } catch (InterruptedException e) {
            }
            loadApplications = this.mDesktopItemsLoader.mLoadApplications;
        }
        Log.d(LOG_TAG, "  --> starting workspace loader");
        this.mDesktopItemsLoaded = false;
        this.mDesktopItemsLoader = new DesktopItemsLoader(launcher, localeChanged, loadApplications);
        this.mDesktopLoaderThread = new Thread(this.mDesktopItemsLoader, "Desktop Items Loader");
        this.mDesktopLoaderThread.start();
    }

    static void updateShortcutLabels(ContentResolver resolver, PackageManager manager) {
        resolver.update(LauncherSettings.getSpecialAction("_update_shortcut_labels"), null, null, null);
    }

    static String getLabel(PackageManager manager, ActivityInfo activityInfo) {
        String label = activityInfo.loadLabel(manager).toString();
        if (label == null) {
            String label2 = manager.getApplicationLabel(((ComponentInfo) activityInfo).applicationInfo).toString();
            if (label2 == null) {
                return ((PackageItemInfo) activityInfo).name;
            }
            return label2;
        }
        return label;
    }

    private class DesktopItemsLoader implements Runnable {
        private final WeakReference<Launcher> mLauncher;
        private final boolean mLoadApplications;
        private final boolean mLocaleChanged;
        private volatile boolean mRunning;
        private volatile boolean mStopped;

        DesktopItemsLoader(Launcher launcher, boolean localeChanged, boolean loadApplications) {
            this.mLoadApplications = loadApplications;
            this.mLauncher = new WeakReference<>(launcher);
            this.mLocaleChanged = localeChanged;
        }

        void stop() {
            this.mStopped = true;
        }

        boolean isRunning() {
            return this.mRunning;
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r14v1, types: [android.content.Context, com.htc.launcher.Launcher] */
        @Override // java.lang.Runnable
        public void run() {
            this.mRunning = true;
            final Launcher launcher = this.mLauncher.get();
            ContentResolver contentResolver = launcher.getContentResolver();
            PackageManager manager = launcher.getPackageManager();
            if (Launcher.sWidgetPackageManager == null) {
                Launcher.sWidgetPackageManager = WidgetPackageManager.instance(launcher);
                Launcher.sWidgetPackageManager.initFavorites(launcher, LauncherModel.this);
                launcher.mWidgetsManager.setWidgetPackageManager(Launcher.sWidgetPackageManager);
            }
            Log.d(LauncherModel.LOG_TAG, "Remove temporary ItemInfo : screen < 0 OR cellX < 0 OR cellY < 0 ");
            contentResolver.delete(LauncherSettings.Favorites.CONTENT_URI, "screen < 0 OR cellX < 0 OR cellY < 0 ", null);
            SharedPreferences preferences = launcher.getSharedPreferences(Launcher.PERSONALIZE_PREFERENCES, 0);
            launcher.setLiveWallpaperName(preferences.getString(Launcher.ACTION_SUMMARY_CHANGES[1], null));
            if (this.mLocaleChanged) {
                Log.d(LauncherModel.LOG_TAG, "Locale changed, rename scenes according to new Locale settings.");
                WidgetWorkspaceManager instance = WidgetWorkspaceManager.instance(launcher);
                instance.translateDisplayName(launcher);
                try {
                    LauncherModel.updateShortcutLabels(contentResolver, manager);
                } catch (Exception e) {
                }
                WidgetWorkspace[] FindUnSaveWorkspaces = instance.listWorkspace();
                if (FindUnSaveWorkspaces[0].status == 1) {
                    instance.setDisplayName(FindUnSaveWorkspaces[0].id, launcher.getResources().getString(R.string.scene_current_unsaved));
                }
            }
            LauncherModel.this.mDesktopItems = new ArrayList();
            LauncherModel.this.mDesktopAppWidgets = new ArrayList();
            LauncherModel.this.mFolders = new HashMap();
            LauncherModel.this.mButtonBarItems = new ArrayList();
            ArrayList<ItemInfo> desktopItems = LauncherModel.this.mDesktopItems;
            ArrayList<LauncherAppWidgetInfo> desktopAppWidgets = LauncherModel.this.mDesktopAppWidgets;
            ArrayList<ItemInfo> buttonBarItems = LauncherModel.this.mButtonBarItems;
            Cursor c = contentResolver.query(LauncherSettings.Favorites.CONTENT_URI, null, "workspace_id=0", null, null);
            Logger.d(LauncherModel.LOG_TAG, "There are " + c.getCount() + " items in current Scene");
            try {
                int idIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ID);
                int intentIndex = c.getColumnIndexOrThrow("intent");
                int titleIndex = c.getColumnIndexOrThrow("title");
                int iconTypeIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ICON_TYPE);
                int iconIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ICON);
                int iconPackageIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ICON_PACKAGE);
                int iconResourceIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ICON_RESOURCE);
                int containerIndex = c.getColumnIndexOrThrow("container");
                int itemTypeIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ITEM_TYPE);
                int appWidgetIdIndex = c.getColumnIndexOrThrow("appWidgetId");
                int screenIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.SCREEN);
                int cellXIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.CELLX);
                int cellYIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.CELLY);
                int propsIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.PROPS);
                int spanXIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.SPANX);
                int spanYIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.SPANY);
                int uriIndex = c.getColumnIndexOrThrow("uri");
                int displayModeIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.DISPLAY_MODE);
                int fxProviderIndex = c.getColumnIndexOrThrow("intent");
                int fxStyleIndex = c.getColumnIndexOrThrow("uri");
                int fxWidgetIdIndex = c.getColumnIndexOrThrow("appWidgetId");
                int fxWidgetTypeIdIndex = c.getColumnIndexOrThrow("title");
                HashMap<Long, FolderInfo> folders = LauncherModel.this.mFolders;
                while (!this.mStopped && c.moveToNext()) {
                    try {
                        int itemType = c.getInt(itemTypeIndex);
                        c.getInt(cellYIndex);
                        switch (itemType) {
                            case 0:
                            case 1:
                                try {
                                    Intent intent = Intent.parseUri(c.getString(intentIndex), 0);
                                    ApplicationInfo info = itemType == 0 ? LauncherModel.getApplicationInfo(manager, intent, c, launcher, iconTypeIndex, iconIndex) : LauncherModel.this.getApplicationInfoShortcut(c, launcher, iconTypeIndex, iconPackageIndex, iconResourceIndex, iconIndex);
                                    if (info == null) {
                                        info = new ApplicationInfo();
                                        info.itemType = itemType;
                                        info.icon = manager.getDefaultActivityIcon();
                                    }
                                    if (info != null) {
                                        info.title = c.getString(titleIndex);
                                        info.intent = intent;
                                        info.id = c.getLong(idIndex);
                                        int container = c.getInt(containerIndex);
                                        info.container = container;
                                        info.screen = c.getInt(screenIndex);
                                        info.cellX = c.getInt(cellXIndex);
                                        info.cellY = c.getInt(cellYIndex);
                                        if (info.cellY == 10) {
                                            String packageName = c.getString(iconPackageIndex);
                                            info.packageName = packageName;
                                            buttonBarItems.add(info);
                                            break;
                                        } else {
                                            switch (container) {
                                                case LauncherSettings.Favorites.CONTAINER_DESKTOP /* -100 */:
                                                    desktopItems.add(info);
                                                    break;
                                                default:
                                                    LauncherModel.this.findOrMakeUserFolder(folders, container).add(info);
                                                    break;
                                            }
                                        }
                                    } else {
                                        continue;
                                    }
                                } catch (URISyntaxException e2) {
                                    break;
                                }
                            case 2:
                                long id = c.getLong(idIndex);
                                UserFolderInfo folderInfo = LauncherModel.this.findOrMakeUserFolder(folders, id);
                                folderInfo.title = c.getString(titleIndex);
                                folderInfo.id = id;
                                int container2 = c.getInt(containerIndex);
                                folderInfo.container = container2;
                                folderInfo.screen = c.getInt(screenIndex);
                                folderInfo.cellX = c.getInt(cellXIndex);
                                folderInfo.cellY = c.getInt(cellYIndex);
                                switch (container2) {
                                    case LauncherSettings.Favorites.CONTAINER_DESKTOP /* -100 */:
                                        desktopItems.add(folderInfo);
                                        continue;
                                }
                            case 3:
                                long id2 = c.getLong(idIndex);
                                LiveFolderInfo liveFolderInfo = LauncherModel.this.findOrMakeLiveFolder(folders, id2);
                                String intentDescription = c.getString(intentIndex);
                                Intent intent2 = null;
                                if (intentDescription != null) {
                                    try {
                                        intent2 = Intent.parseUri(intentDescription, 0);
                                    } catch (URISyntaxException e3) {
                                    }
                                }
                                liveFolderInfo.title = c.getString(titleIndex);
                                liveFolderInfo.id = id2;
                                int container3 = c.getInt(containerIndex);
                                liveFolderInfo.container = container3;
                                liveFolderInfo.screen = c.getInt(screenIndex);
                                liveFolderInfo.cellX = c.getInt(cellXIndex);
                                liveFolderInfo.cellY = c.getInt(cellYIndex);
                                liveFolderInfo.uri = Uri.parse(c.getString(uriIndex));
                                liveFolderInfo.baseIntent = intent2;
                                liveFolderInfo.displayMode = c.getInt(displayModeIndex);
                                LauncherModel.loadLiveFolderIcon(launcher, c, iconTypeIndex, iconPackageIndex, iconResourceIndex, liveFolderInfo);
                                switch (container3) {
                                    case LauncherSettings.Favorites.CONTAINER_DESKTOP /* -100 */:
                                        desktopItems.add(liveFolderInfo);
                                        continue;
                                }
                            case 4:
                                int appWidgetId = c.getInt(appWidgetIdIndex);
                                LauncherAppWidgetInfo appWidgetInfo = new LauncherAppWidgetInfo(appWidgetId);
                                appWidgetInfo.id = c.getLong(idIndex);
                                appWidgetInfo.screen = c.getInt(screenIndex);
                                appWidgetInfo.cellX = c.getInt(cellXIndex);
                                appWidgetInfo.cellY = c.getInt(cellYIndex);
                                appWidgetInfo.spanX = c.getInt(spanXIndex);
                                appWidgetInfo.spanY = c.getInt(spanYIndex);
                                appWidgetInfo.appWidgetComponent = ComponentName.unflattenFromString(c.getString(intentIndex));
                                if (c.getInt(containerIndex) != -100) {
                                    Log.w("Rosie", "Widget found where container != CONTAINER_DESKTOP -- ignoring!");
                                    break;
                                } else {
                                    appWidgetInfo.container = c.getInt(containerIndex);
                                    desktopAppWidgets.add(appWidgetInfo);
                                    continue;
                                }
                            case 5:
                                ComponentName provider = ComponentName.unflattenFromString(c.getString(fxProviderIndex));
                                WidgetProvider.Info.Style style = WidgetProviderInfoCollector.getStyleByComponent(launcher, ComponentName.unflattenFromString(c.getString(fxStyleIndex)), c.getString(fxWidgetTypeIdIndex));
                                if (style == null) {
                                    Logger.w(LauncherModel.LOG_TAG, "[ROSIE_DEBUG] Warning!! Style not found for FXWIDGET: itemType(" + itemType + ") Provider(" + c.getString(fxProviderIndex) + ") Style(" + c.getString(fxStyleIndex) + ") WidgetTypeId(" + c.getString(fxWidgetTypeIdIndex) + ")");
                                    break;
                                } else {
                                    FxItemInfo fxInfo = new FxItemInfo(provider, style.component);
                                    fxInfo.data = c.getBlob(propsIndex);
                                    fxInfo.container = c.getInt(containerIndex);
                                    fxInfo.id = c.getLong(idIndex);
                                    fxInfo.widgetId = (int) c.getLong(fxWidgetIdIndex);
                                    fxInfo.spanX = c.getInt(spanXIndex);
                                    fxInfo.spanY = c.getInt(spanYIndex);
                                    fxInfo.screen = c.getInt(screenIndex);
                                    fxInfo.cellX = c.getInt(cellXIndex);
                                    fxInfo.cellY = c.getInt(cellYIndex);
                                    fxInfo.workspaceId = WidgetWorkspaceManager.instance().getCurrentWorkspaceId();
                                    int container4 = c.getInt(containerIndex);
                                    if (container4 != -100) {
                                        Log.w("Rosie", "Widget found where container != CONTAINER_DESKTOP -- ignoring!");
                                        break;
                                    } else {
                                        fxInfo.container = container4;
                                        desktopItems.add(fxInfo);
                                        continue;
                                    }
                                }
                            case LauncherSettings.Favorites.ITEM_TYPE_WIDGET_SEARCH /* 1001 */:
                                Widget widgetInfo = Widget.makeSearch();
                                int container5 = c.getInt(containerIndex);
                                if (container5 != -100) {
                                    Log.e("Rosie", "Widget found where container != CONTAINER_DESKTOP  ignoring!");
                                    break;
                                } else {
                                    widgetInfo.id = c.getLong(idIndex);
                                    widgetInfo.screen = c.getInt(screenIndex);
                                    widgetInfo.container = container5;
                                    widgetInfo.cellX = c.getInt(cellXIndex);
                                    widgetInfo.cellY = c.getInt(cellYIndex);
                                    desktopItems.add(widgetInfo);
                                    continue;
                                }
                            default:
                                Log.d(LauncherModel.LOG_TAG, "DB iterate : item type - " + itemType);
                                try {
                                    Widget widgetInfo2 = Launcher.sWidgetPackageManager.newWidget(itemType, launcher, c.getLong(idIndex));
                                    if (widgetInfo2 != null) {
                                        c.getBlob(iconIndex);
                                        widgetInfo2.props = c.getBlob(propsIndex);
                                        int container6 = c.getInt(containerIndex);
                                        if (container6 != -100) {
                                            Log.w(LauncherModel.LOG_TAG, "Widget found where container != CONTAINER_DESKTOP -- ignoring!");
                                            break;
                                        } else {
                                            widgetInfo2.id = c.getLong(idIndex);
                                            widgetInfo2.screen = c.getInt(screenIndex);
                                            widgetInfo2.container = container6;
                                            widgetInfo2.cellX = c.getInt(cellXIndex);
                                            widgetInfo2.cellY = c.getInt(cellYIndex);
                                            desktopItems.add(widgetInfo2);
                                            break;
                                        }
                                    } else {
                                        continue;
                                    }
                                } catch (Throwable th) {
                                    Log.w(LauncherModel.LOG_TAG, "a widget not loaded  : " + itemType);
                                    break;
                                }
                        }
                    } catch (Exception e4) {
                        Log.w("Rosie", "Desktop items loading interrupted:", e4);
                    }
                    Log.w("Rosie", "Desktop items loading interrupted:", e4);
                }
            } catch (Exception e5) {
                e5.printStackTrace();
                Log.w("Rosie", "Desktop items loading interrupted:", e5);
            } finally {
                c.close();
            }
            int size = desktopAppWidgets.size();
            if (size > 0 && launcher != 0) {
                ArrayList<Integer> bindSources = new ArrayList<>();
                ArrayList<ComponentName> bindTargets = new ArrayList<>();
                Iterator i$ = desktopAppWidgets.iterator();
                while (i$.hasNext()) {
                    LauncherAppWidgetInfo info2 = i$.next();
                    if (info2.isTWM_Widget()) {
                        if (info2.appWidgetId != -1) {
                            Launcher.sDefaultAppWidgetHost.deleteAppWidgetId(info2.appWidgetId);
                        }
                        int appWidgetId2 = Launcher.sDefaultAppWidgetHost.allocateAppWidgetId();
                        info2.appWidgetId = appWidgetId2;
                        LauncherModel.updateItemInDatabase(launcher, info2);
                        bindSources.add(Integer.valueOf(info2.appWidgetId));
                        bindTargets.add(info2.appWidgetComponent);
                    }
                }
                if (bindSources.size() > 0) {
                    int[] sources = new int[bindSources.size()];
                    for (int i = 0; i < bindSources.size(); i++) {
                        sources[i] = bindSources.get(i).intValue();
                    }
                    if (launcher != 0) {
                        launchAppWidgetBinder(launcher, sources, bindTargets);
                    }
                }
            }
            if (!this.mStopped) {
                launcher.runOnUiThread(new Runnable() { // from class: com.htc.launcher.LauncherModel.DesktopItemsLoader.1
                    @Override // java.lang.Runnable
                    public void run() {
                        launcher.onDesktopItemsLoaded();
                    }
                });
                if (this.mLoadApplications) {
                    LauncherModel.this.startApplicationsLoader(launcher);
                }
            }
            if (!this.mStopped) {
                LauncherModel.this.mDesktopItemsLoaded = true;
            }
            this.mRunning = false;
        }

        private void launchAppWidgetBinder(Context context, int[] bindSources, ArrayList<ComponentName> bindTargets) {
            Intent intent = new Intent();
            intent.setComponent(new ComponentName("com.htc.AddProgramWidget", "com.htc.AddProgramWidget.LauncherAppWidgetBinder"));
            intent.setFlags(268435456);
            Bundle extras = new Bundle();
            extras.putIntArray("com.android.launcher.settings.bindsources", bindSources);
            extras.putParcelableArrayList("com.android.launcher.settings.bindtargets", bindTargets);
            intent.putExtras(extras);
            context.startActivity(intent);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public static void loadLiveFolderIcon(Launcher launcher, Cursor c, int iconTypeIndex, int iconPackageIndex, int iconResourceIndex, LiveFolderInfo liveFolderInfo) {
        int iconType = c.getInt(iconTypeIndex);
        switch (iconType) {
            case 0:
                String packageName = c.getString(iconPackageIndex);
                String resourceName = c.getString(iconResourceIndex);
                PackageManager packageManager = launcher.getPackageManager();
                try {
                    Resources resources = packageManager.getResourcesForApplication(packageName);
                    int id = resources.getIdentifier(resourceName, null, null);
                    liveFolderInfo.icon = ResourceUtil.getDrawable(resources, id);
                } catch (Exception e) {
                    liveFolderInfo.icon = launcher.getResources().getDrawable(34079058);
                }
                liveFolderInfo.iconResource = new Intent.ShortcutIconResource();
                liveFolderInfo.iconResource.packageName = packageName;
                liveFolderInfo.iconResource.resourceName = resourceName;
                break;
            default:
                liveFolderInfo.icon = launcher.getResources().getDrawable(34079058);
                break;
        }
    }

    FolderInfo findFolderById(long id) {
        return this.mFolders.get(Long.valueOf(id));
    }

    void addFolder(FolderInfo info) {
        this.mFolders.put(Long.valueOf(info.id), info);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public UserFolderInfo findOrMakeUserFolder(HashMap<Long, FolderInfo> folders, long id) {
        FolderInfo folderInfo = folders.get(Long.valueOf(id));
        if (folderInfo == null || !(folderInfo instanceof UserFolderInfo)) {
            folderInfo = new UserFolderInfo();
            folders.put(Long.valueOf(id), folderInfo);
        }
        return (UserFolderInfo) folderInfo;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public LiveFolderInfo findOrMakeLiveFolder(HashMap<Long, FolderInfo> folders, long id) {
        FolderInfo folderInfo = folders.get(Long.valueOf(id));
        if (folderInfo == null || !(folderInfo instanceof LiveFolderInfo)) {
            folderInfo = new LiveFolderInfo();
            folders.put(Long.valueOf(id), folderInfo);
        }
        return (LiveFolderInfo) folderInfo;
    }

    void unbind() {
        stopAndWaitForApplicationsLoader();
        this.mApplicationsAdapter = null;
        unbindAppDrawables(this.mApplications);
        unbindDrawables(this.mDesktopItems);
        unbindAppWidgetHostViews(this.mDesktopAppWidgets);
        unbindCachedIconDrawables();
    }

    private void unbindDrawables(ArrayList<ItemInfo> desktopItems) {
        if (desktopItems != null) {
            int count = desktopItems.size();
            for (int i = 0; i < count; i++) {
                ItemInfo item = desktopItems.get(i);
                switch (item.itemType) {
                    case 0:
                    case 1:
                        Drawable icon = ((ApplicationInfo) item).icon;
                        if (icon != null) {
                            icon.setCallback(null);
                            break;
                        } else {
                            break;
                        }
                }
            }
        }
    }

    private void unbindAppDrawables(FilterableAndSortableApplicationInfoList applications) {
        if (applications != null) {
            int count = applications.originalSize();
            for (int i = 0; i < count; i++) {
                ApplicationInfo item = applications.originalGet(i);
                if (item != null && item.icon != null) {
                    item.icon.setCallback(null);
                }
            }
        }
    }

    private void unbindAppWidgetHostViews(ArrayList<LauncherAppWidgetInfo> appWidgets) {
        if (appWidgets != null) {
            int count = appWidgets.size();
            for (int i = 0; i < count; i++) {
                LauncherAppWidgetInfo launcherInfo = appWidgets.get(i);
                launcherInfo.hostView = null;
            }
        }
    }

    private void unbindCachedIconDrawables() {
        for (ApplicationInfo appInfo : this.mAppInfoCache.values()) {
            if (appInfo.icon != null) {
                appInfo.icon.setCallback(null);
            }
        }
    }

    public FilterableAndSortableApplicationInfoList getApplications() {
        return this.mApplications;
    }

    ApplicationsAdapter getApplicationsAdapter() {
        return this.mApplicationsAdapter;
    }

    ArrayList<ItemInfo> getDesktopItems() {
        return this.mDesktopItems;
    }

    ArrayList<LauncherAppWidgetInfo> getDesktopAppWidgets() {
        return this.mDesktopAppWidgets;
    }

    public ArrayList<ItemInfo> getButtonBarItems() {
        return this.mButtonBarItems;
    }

    public boolean[] getButtonBarOccupied() {
        boolean[] buttonBarOccupied = new boolean[3];
        for (int j = 0; j < buttonBarOccupied.length; j++) {
            buttonBarOccupied[j] = false;
        }
        ArrayList<ItemInfo> buttonBarItems = getButtonBarItems();
        for (int i = 0; i < buttonBarItems.size(); i++) {
            ApplicationInfo app = (ApplicationInfo) buttonBarItems.get(i);
            switch (app.cellX) {
                case 0:
                    buttonBarOccupied[0] = true;
                    break;
                case 1:
                    buttonBarOccupied[1] = true;
                    break;
                case 2:
                    buttonBarOccupied[2] = true;
                    break;
            }
        }
        return buttonBarOccupied;
    }

    void addDesktopItem(ItemInfo info) {
        Logger.d(LoggingEvents.EXTRA_CALLING_APP_NAME, "ITEM - ADD Info[" + this.mDesktopItems.size() + "]" + info);
        this.mDesktopItems.add(info);
        outputAllDeskItems();
    }

    void removeDesktopItem(ItemInfo info) {
        this.skipOutputAllDeskItems = true;
        if (!this.mDesktopItems.remove(info)) {
            Iterator i$ = this.mDesktopItems.iterator();
            while (true) {
                if (!i$.hasNext()) {
                    break;
                }
                ItemInfo item = i$.next();
                if (info.screen == item.screen && info.cellX == item.cellX && info.cellY == item.cellY && info.spanX == item.spanX && info.spanY == item.spanY) {
                    this.mDesktopItems.remove(item);
                    break;
                }
            }
        }
        outputAllDeskItems();
    }

    void removeButtonItem(ItemInfo info) {
        this.mButtonBarItems.remove(info);
        outputAllDeskItems();
    }

    void addDesktopAppWidget(LauncherAppWidgetInfo info) {
        this.mDesktopAppWidgets.add(info);
        outputAllDeskItems();
    }

    void removeDesktopAppWidget(LauncherAppWidgetInfo info) {
        this.mDesktopAppWidgets.remove(info);
        if (!this.mDesktopAppWidgets.remove(info)) {
            Iterator i$ = this.mDesktopAppWidgets.iterator();
            while (i$.hasNext()) {
                LauncherAppWidgetInfo item = i$.next();
                if (info.screen == item.screen && info.cellX == item.cellX && info.cellY == item.cellY && info.spanX == item.spanX && info.spanY == item.spanY) {
                    this.mDesktopAppWidgets.remove(item);
                    return;
                }
            }
        }
    }

    public void addButtonBarItem(ItemInfo info) {
        this.mButtonBarItems.add(info);
    }

    void removeButtonBarItem(ItemInfo info) {
        this.mButtonBarItems.remove(info);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public static ApplicationInfo getApplicationInfo(PackageManager manager, Intent intent, Cursor c, Launcher launcher, int iconTypeIndex, int iconIndex) {
        ResolveInfo resolveInfo = manager.resolveActivity(intent, 0);
        if (resolveInfo == null) {
            return null;
        }
        ApplicationInfo info = new ApplicationInfo();
        ActivityInfo activityInfo = resolveInfo.activityInfo;
        int iconType = c.getInt(iconTypeIndex);
        if (iconType == 1) {
            byte[] data = c.getBlob(iconIndex);
            Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
            info.icon = new FastBitmapDrawable(Utilities.createBitmapThumbnail(bitmap, launcher));
            info.filtered = true;
            info.customIcon = true;
        } else {
            info.icon = ResourceUtil.getApplicationIcon(manager, activityInfo);
        }
        if (info.title == null || info.title.length() == 0) {
            info.title = activityInfo.loadLabel(manager);
        }
        if (info.title == null) {
            info.title = LoggingEvents.EXTRA_CALLING_APP_NAME;
        }
        info.itemType = 0;
        return info;
    }

    private static ApplicationInfo getApplicationInfo(PackageManager manager, Intent intent) {
        ResolveInfo resolveInfo = manager.resolveActivity(intent, 0);
        if (resolveInfo == null) {
            return null;
        }
        ApplicationInfo info = new ApplicationInfo();
        ActivityInfo activityInfo = resolveInfo.activityInfo;
        info.icon = ResourceUtil.getApplicationIcon(manager, activityInfo);
        if (info.title == null || info.title.length() == 0) {
            info.title = activityInfo.loadLabel(manager);
        }
        if (info.title == null) {
            info.title = LoggingEvents.EXTRA_CALLING_APP_NAME;
        }
        info.itemType = 0;
        return info;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    public ApplicationInfo getApplicationInfoShortcut(Cursor c, Launcher launcher, int iconTypeIndex, int iconPackageIndex, int iconResourceIndex, int iconIndex) {
        ApplicationInfo info = new ApplicationInfo();
        info.itemType = 1;
        int iconType = c.getInt(iconTypeIndex);
        switch (iconType) {
            case 0:
                String packageName = c.getString(iconPackageIndex);
                String resourceName = c.getString(iconResourceIndex);
                PackageManager packageManager = launcher.getPackageManager();
                try {
                    Resources resources = packageManager.getResourcesForApplication(packageName);
                    int id = resources.getIdentifier(resourceName, null, null);
                    info.icon = resources.getDrawable(id);
                } catch (Exception e) {
                    if (resourceName != null) {
                        info.icon = getNonScaledBitmapDrawable(launcher.getResources(), resourceName);
                    } else {
                        try {
                            info.icon = packageManager.getApplicationIcon(packageName);
                        } catch (Exception e2) {
                            info.icon = packageManager.getDefaultActivityIcon();
                        }
                    }
                }
                info.iconResource = new Intent.ShortcutIconResource();
                info.iconResource.packageName = packageName;
                info.iconResource.resourceName = resourceName;
                info.customIcon = false;
                return info;
            case 1:
                byte[] data = c.getBlob(iconIndex);
                Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
                info.icon = new FastBitmapDrawable(Utilities.createBitmapThumbnail(bitmap, launcher));
                info.filtered = true;
                info.customIcon = true;
                return info;
            default:
                info.icon = launcher.getPackageManager().getDefaultActivityIcon();
                info.customIcon = false;
                return info;
        }
    }

    void removeUserFolderItem(UserFolderInfo folder, ItemInfo info) {
        folder.contents.remove(info);
    }

    void removeUserFolder(UserFolderInfo userFolderInfo) {
        this.mFolders.remove(Long.valueOf(userFolderInfo.id));
    }

    private static String getUsageMapId(String packageName, String customizeAppId) {
        return customizeAppId + "@" + packageName;
    }

    private static String getUsageMapId(HtcAppUsageStats usageStats) {
        return getUsageMapId(usageStats.packageName, usageStats.appName);
    }

    private static void refreshUsageStatCache(Context context) {
        try {
            if (sUsageStatsService == null) {
                sUsageStatsService = new HtcUsageStats(context);
            }
            HtcAppUsageStats[] stats = sUsageStatsService.getAllAppUsageStats();
            sUsageMap = new HashMap<>();
            for (HtcAppUsageStats s : stats) {
                String mapId = getUsageMapId(s);
                sUsageMap.put(mapId, Integer.valueOf(s.launchCount));
            }
        } catch (Exception e) {
            Log.e(LOG_TAG, "UsageStatsService.getAllPkgUsageStats failed");
            e.printStackTrace();
        }
    }

    private static int getLaunchCount(String packageName, String customizeAppId) {
        Integer launchCount = sUsageMap.get(getUsageMapId(packageName, customizeAppId));
        if (launchCount != null) {
            return launchCount.intValue();
        }
        return 0;
    }

    synchronized void refreshUsageStats(Context context, boolean refreshCache) {
        if (this.mApplicationsLoader != null && this.mApplicationsLoader.isRunning()) {
            Log.w(LOG_TAG, "refreshUsageStats when ApplicationsLoader running");
        } else {
            if (refreshCache || sUsageMap == null) {
                refreshUsageStatCache(context);
            }
            if (this.mApplications != null) {
                synchronized (this.mAppInfoCache) {
                    for (ApplicationInfo app : this.mAppInfoCache.values()) {
                        app.launchCount = getLaunchCount(app.packageName, app.customizeAppId);
                    }
                }
            }
        }
    }

    static {
        sUsConfiguration.setToDefaults();
        sUsConfiguration.locale = Locale.US;
    }

    public static String getCustomAppId(ResolveInfo info, PackageManager pm) {
        String id = null;
        try {
            int labelRes = ((PackageItemInfo) info.activityInfo).labelRes;
            if (labelRes == 0) {
                labelRes = ((PackageItemInfo) ((ComponentInfo) info.activityInfo).applicationInfo).labelRes;
            }
            if (labelRes != 0) {
                Resources res = pm.getResourcesForApplication(((ComponentInfo) info.activityInfo).applicationInfo);
                Configuration origConf = new Configuration(res.getConfiguration());
                res.updateConfiguration(sUsConfiguration, null);
                CharSequence label = res.getText(labelRes);
                if (label != null) {
                    id = label.toString();
                }
                res.updateConfiguration(origConf, null);
            }
        } catch (Exception e) {
            Log.w(LOG_TAG, "load label failed");
            e.printStackTrace();
        }
        if (id == null) {
            return ((PackageItemInfo) ((ComponentInfo) info.activityInfo).applicationInfo).nonLocalizedLabel != null ? ((PackageItemInfo) ((ComponentInfo) info.activityInfo).applicationInfo).nonLocalizedLabel.toString() : ((PackageItemInfo) info.activityInfo).packageName;
        }
        return id;
    }

    private static class addOrMoveItemInDatabaseRunner implements Runnable {
        private int mCellX;
        private int mCellY;
        private long mContainer;
        private Context mContext;
        private ItemInfo mItem;
        private int mScreen;

        addOrMoveItemInDatabaseRunner(Context context, ItemInfo item, long container, int screen, int cellX, int cellY) {
            this.mContext = context;
            this.mItem = item;
            this.mContainer = container;
            this.mScreen = screen;
            this.mCellX = cellX;
            this.mCellY = cellY;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (this.mItem.container == -1) {
                LauncherModel.addItemToDatabase(this.mContext, this.mItem, this.mContainer, this.mScreen, this.mCellX, this.mCellY, false);
            } else {
                LauncherModel.moveItemInDatabase(this.mContext, this.mItem, this.mContainer, this.mScreen, this.mCellX, this.mCellY);
            }
        }
    }

    static void addOrMoveItemInDatabase(Context context, ItemInfo item, long container, int screen, int cellX, int cellY) {
        addOrMoveItemInDatabaseRunner work = new addOrMoveItemInDatabaseRunner(context, item, container, screen, cellX, cellY);
        work.run();
    }

    static void moveItemInDatabase(Context context, ItemInfo item, long container, int screen, int cellX, int cellY) {
        if (item != null && context != null) {
            item.container = container;
            item.screen = screen;
            item.cellX = cellX;
            item.cellY = cellY;
            Logger.d("LauncherModel", "[EDIT_DEBUG] LauncherModel.moveItemInDatabase() - item:" + item);
            try {
                ContentValues values = new ContentValues();
                ContentResolver cr = context.getContentResolver();
                if (values != null && cr != null) {
                    Logger.d("LauncherModel", "[EDIT_DEBUG] LauncherModel.moveItemInDatabase() Container(" + item.container + ") - ok");
                    values.put("container", Long.valueOf(item.container));
                    values.put(LauncherSettings.Favorites.CELLX, Integer.valueOf(item.cellX));
                    values.put(LauncherSettings.Favorites.CELLY, Integer.valueOf(item.cellY));
                    values.put(LauncherSettings.Favorites.SCREEN, Integer.valueOf(item.screen));
                    cr.update(LauncherSettings.Favorites.getContentUri(item.id, false), values, null, null);
                    WidgetWorkspaceManager.instance(context).onSceneModified();
                }
            } catch (SQLException e) {
                Log.e(LOG_TAG, "moveItemInDatabase failed, disk full?", e);
            }
            Logger.d("LauncherModel", "[EDIT_DEBUG] LauncherModel.moveItemInDatabase() - exit");
        }
    }

    static boolean shortcutExists(Context context, String title, Intent intent) {
        ContentResolver cr = context.getContentResolver();
        Cursor c = cr.query(LauncherSettings.Favorites.CONTENT_URI, new String[]{"title", "intent"}, "title=? and intent=?", new String[]{title, intent.toUri(0)}, null);
        try {
            boolean result = c.moveToFirst();
            return result;
        } finally {
            c.close();
        }
    }

    FolderInfo getFolderById(Context context, long id) {
        ContentResolver cr = context.getContentResolver();
        Cursor c = cr.query(LauncherSettings.Favorites.CONTENT_URI, null, "_id=? and (itemType=? or itemType=?)", new String[]{String.valueOf(id), String.valueOf(2), String.valueOf(3)}, null);
        try {
            if (c.moveToFirst()) {
                int itemTypeIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ITEM_TYPE);
                int titleIndex = c.getColumnIndexOrThrow("title");
                int containerIndex = c.getColumnIndexOrThrow("container");
                int screenIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.SCREEN);
                int cellXIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.CELLX);
                int cellYIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.CELLY);
                FolderInfo folderInfo = null;
                switch (c.getInt(itemTypeIndex)) {
                    case 2:
                        folderInfo = findOrMakeUserFolder(this.mFolders, id);
                        break;
                    case 3:
                        folderInfo = findOrMakeLiveFolder(this.mFolders, id);
                        break;
                }
                folderInfo.title = c.getString(titleIndex);
                folderInfo.id = id;
                folderInfo.container = c.getInt(containerIndex);
                folderInfo.screen = c.getInt(screenIndex);
                folderInfo.cellX = c.getInt(cellXIndex);
                folderInfo.cellY = c.getInt(cellYIndex);
                c.close();
                return folderInfo;
            }
            c.close();
            return null;
        } catch (Throwable th) {
            c.close();
            throw th;
        }
    }

    public static void addItemToDatabase(Context context, ItemInfo item, long container, int screen, int cellX, int cellY, boolean notify) {
        if (item != null) {
            item.container = container;
            item.screen = screen;
            item.cellX = cellX;
            item.cellY = cellY;
            Logger.d("LauncherModel", "[EDIT_DEBUG] LauncherModel.addItemToDatabase() item:" + item);
            ContentValues values = new ContentValues();
            ContentResolver cr = context.getContentResolver();
            item.onAddToDatabase(values);
            if (cellX >= 0 && cellY >= 0) {
                WidgetWorkspaceManager.instance(context).onSceneModified();
            }
            Uri result = cr.insert(notify ? LauncherSettings.Favorites.CONTENT_URI : LauncherSettings.Favorites.CONTENT_URI_NO_NOTIFICATION, values);
            if (result != null) {
                item.id = Integer.parseInt(result.getPathSegments().get(1));
                Logger.d("LauncherModel", "[EDIT_DEBUG][tengi] LauncherModel.addItemToDatabase() item:" + item.id);
                sendItemAdded(context, item);
                return;
            }
            Logger.d("LauncherModel", "[EDIT_DEBUG][tengi] LauncherModel.addItemToDatabase() failed............... item:" + item.id);
            return;
        }
        Logger.e("LauncherModel", "addItemToDatabase() item is null");
    }

    public static void initAddItemToDatabase(Context context, ItemInfo item, long container, int screen, int cellX, int cellY, boolean notify) {
        item.container = container;
        item.screen = screen;
        item.cellX = cellX;
        item.cellY = cellY;
        ContentValues values = new ContentValues();
        ContentResolver cr = context.getContentResolver();
        item.onAddToDatabase(values);
        cr.insert(notify ? LauncherSettings.Favorites.CONTENT_URI : LauncherSettings.Favorites.CONTENT_URI_NO_NOTIFICATION, values);
    }

    static void updateItemInDatabase(Context context, ItemInfo item) {
        ContentValues values = new ContentValues();
        ContentResolver cr = context.getContentResolver();
        item.onAddToDatabase(values);
        cr.update(LauncherSettings.Favorites.getContentUri(item.id, false), values, null, null);
    }

    static void deleteItemFromDatabase(Context context, ItemInfo item) {
        ContentResolver cr = context.getContentResolver();
        if (item != null) {
            Log.w(LOG_TAG, "deleteItemFromDatabase item=" + item.id);
            cr.delete(LauncherSettings.Favorites.getContentUri(item.id, false), null, null);
            sendItemRemoved(context, item);
        }
    }

    static void deleteUserFolderContentsFromDatabase(Context context, UserFolderInfo info) {
        ContentResolver cr = context.getContentResolver();
        Log.w(LOG_TAG, "deleteUserFolderContentsFromDatabase folder=" + info.id);
        cr.delete(LauncherSettings.Favorites.getContentUri(info.id, false), null, null);
        cr.delete(LauncherSettings.Favorites.CONTENT_URI_NO_NOTIFICATION, "container=" + info.id, null);
        Iterator i$ = info.contents.iterator();
        while (i$.hasNext()) {
            ApplicationInfo item = i$.next();
            sendItemRemoved(context, item);
        }
    }

    static void sendItemAdded(Context context, ItemInfo item) {
        if (item instanceof ApplicationInfo) {
            Intent intent = new Intent("com.htc.launcher.action.ACTION_ITEM_ADDED");
            intent.putExtra("favorite_item_id", item.id);
            if (((ApplicationInfo) item).intent != null) {
                intent.putExtra("favorite_intent", ((ApplicationInfo) item).intent.toUri(0));
            }
            context.sendBroadcast(intent);
        }
    }

    static void sendItemRemoved(Context context, ItemInfo item) {
        if (item instanceof ApplicationInfo) {
            Intent intent = new Intent("com.htc.launcher.action.ACTION_ITEM_REMOVED");
            intent.putExtra("favorite_item_id", item.id);
            if (((ApplicationInfo) item).intent != null) {
                intent.putExtra("favorite_intent", ((ApplicationInfo) item).intent.toUri(0));
            }
            context.sendBroadcast(intent);
        }
    }

    static void deleteAllItemsFromDatabase(Context context, int workspaceId) {
        ContentResolver cr = context.getContentResolver();
        Log.w(LOG_TAG, "deleteAllItemsFromDatabase ws=" + workspaceId);
        cr.delete(LauncherSettings.Favorites.CONTENT_URI_NO_NOTIFICATION, "workspace_id=" + workspaceId, null);
    }

    static void deleteAllItemsFromDatabase(Context context) {
        ContentResolver cr = context.getContentResolver();
        Log.w(LOG_TAG, "deleteAllItemsFromDatabase");
        cr.delete(LauncherSettings.Favorites.CONTENT_URI_NO_NOTIFICATION, null, null);
    }

    static void adjustItemOrigId(Context context, int workspaceId) {
        ContentValues values = new ContentValues();
        values.put("workspace_id", Integer.valueOf(workspaceId));
        context.getContentResolver().update(LauncherSettings.getSpecialAction("_adjust_insaved_item_orig_id"), values, null, null);
    }

    static void duplicateAllItems(Context context, int fromWorkspaceId, int toWorkspaceId) {
        ContentResolver contentResolver = context.getContentResolver();
        Log.w(LOG_TAG, "deleteAllItems for duplicationAllItems ws=" + toWorkspaceId);
        contentResolver.delete(LauncherSettings.Favorites.CONTENT_URI_NO_NOTIFICATION, "workspace_id=" + toWorkspaceId, null);
        Cursor c = contentResolver.query(LauncherSettings.Favorites.CONTENT_URI_NO_NOTIFICATION, null, "workspace_id=" + fromWorkspaceId, null, null);
        int idIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ID);
        int intentIndex = c.getColumnIndexOrThrow("intent");
        int titleIndex = c.getColumnIndexOrThrow("title");
        int iconTypeIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ICON_TYPE);
        int iconIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ICON);
        int iconPackageIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ICON_PACKAGE);
        int iconResourceIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ICON_RESOURCE);
        int containerIndex = c.getColumnIndexOrThrow("container");
        int itemTypeIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ITEM_TYPE);
        int appWidgetIdIndex = c.getColumnIndexOrThrow("appWidgetId");
        int screenIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.SCREEN);
        int cellXIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.CELLX);
        int cellYIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.CELLY);
        int propsIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.PROPS);
        int spanXIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.SPANX);
        int spanYIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.SPANY);
        int uriIndex = c.getColumnIndexOrThrow("uri");
        int displayModeIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.DISPLAY_MODE);
        int isShortcutIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.IS_SHORTCUT);
        ArrayList<ContentValues> list = new ArrayList<>();
        while (c.moveToNext()) {
            ContentValues values = new ContentValues();
            list.add(values);
            values.put(LauncherSettings.Favorites.ORIG_ID, c.getString(idIndex));
            values.put("title", c.getString(titleIndex));
            values.put("intent", c.getString(intentIndex));
            values.put("container", c.getString(containerIndex));
            values.put(LauncherSettings.Favorites.SCREEN, c.getString(screenIndex));
            values.put(LauncherSettings.Favorites.CELLX, c.getString(cellXIndex));
            values.put(LauncherSettings.Favorites.DISPLAY_MODE, c.getString(displayModeIndex));
            values.put(LauncherSettings.Favorites.CELLY, c.getString(cellYIndex));
            values.put(LauncherSettings.Favorites.SPANX, c.getString(spanXIndex));
            values.put(LauncherSettings.Favorites.SPANY, c.getString(spanYIndex));
            values.put(LauncherSettings.Favorites.ITEM_TYPE, c.getString(itemTypeIndex));
            values.put("appWidgetId", c.getString(appWidgetIdIndex));
            values.put(LauncherSettings.Favorites.IS_SHORTCUT, c.getString(isShortcutIndex));
            values.put(LauncherSettings.Favorites.ICON_TYPE, c.getString(iconTypeIndex));
            values.put(LauncherSettings.Favorites.ICON_PACKAGE, c.getString(iconPackageIndex));
            values.put(LauncherSettings.Favorites.ICON_RESOURCE, c.getString(iconResourceIndex));
            values.put(LauncherSettings.Favorites.ICON, c.getBlob(iconIndex));
            values.put(LauncherSettings.Favorites.PROPS, c.getBlob(propsIndex));
            values.put("uri", c.getString(uriIndex));
            values.put(LauncherSettings.Favorites.DISPLAY_MODE, c.getString(displayModeIndex));
            values.put("workspace_id", Integer.valueOf(toWorkspaceId));
        }
        c.close();
        contentResolver.bulkInsert(LauncherSettings.Favorites.CONTENT_URI_NO_NOTIFICATION, (ContentValues[]) list.toArray(new ContentValues[0]));
    }

    static void restoreNonDefaultFavorites(Context context) {
        ContentResolver contentResolver = context.getContentResolver();
        Uri CONTENT_URI = Uri.parse("content://com.htc.launcher.settings/favorites_backup");
        Cursor c = contentResolver.query(CONTENT_URI, null, null, null, null);
        int idIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ID);
        int intentIndex = c.getColumnIndexOrThrow("intent");
        int titleIndex = c.getColumnIndexOrThrow("title");
        int iconTypeIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ICON_TYPE);
        int iconIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ICON);
        int iconPackageIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ICON_PACKAGE);
        int iconResourceIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ICON_RESOURCE);
        int containerIndex = c.getColumnIndexOrThrow("container");
        int itemTypeIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ITEM_TYPE);
        int appWidgetIdIndex = c.getColumnIndexOrThrow("appWidgetId");
        int screenIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.SCREEN);
        int cellXIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.CELLX);
        int cellYIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.CELLY);
        int propsIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.PROPS);
        int spanXIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.SPANX);
        int spanYIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.SPANY);
        int uriIndex = c.getColumnIndexOrThrow("uri");
        int workspaceId = c.getColumnIndexOrThrow("workspace_id");
        int displayModeIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.DISPLAY_MODE);
        int isShortcutIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.IS_SHORTCUT);
        ArrayList<ContentValues> list = new ArrayList<>();
        boolean hasRosieSearchWidget = false;
        ArrayList<ComponentName> bindTargets = new ArrayList<>();
        ArrayList<Integer> bindSources = new ArrayList<>();
        int htcSearchWidgetId = getHtcSearchWidgetId(context);
        while (c.moveToNext()) {
            ContentValues values = new ContentValues();
            list.add(values);
            String itemType = c.getString(itemTypeIndex);
            if (itemType.equals("1001") || itemType.equals(LoggingEvents.EXTRA_CALLING_APP_NAME + htcSearchWidgetId)) {
                int appWidgetId = Launcher.sDefaultAppWidgetHost.allocateAppWidgetId();
                values.put(LauncherSettings.Favorites.ITEM_TYPE, "4");
                values.put("appWidgetId", appWidgetId + LoggingEvents.EXTRA_CALLING_APP_NAME);
                values.put(LauncherSettings.Favorites.ORIG_ID, c.getString(idIndex));
                values.put(LauncherSettings.Favorites.SPANX, (Integer) 4);
                values.put(LauncherSettings.Favorites.SPANY, (Integer) 1);
                bindTargets.add(new ComponentName("com.google.android.googlequicksearchbox", "com.google.android.googlequicksearchbox.SearchWidgetProvider"));
                bindSources.add(Integer.valueOf(appWidgetId));
                hasRosieSearchWidget = true;
            } else {
                values.put(LauncherSettings.Favorites.ITEM_TYPE, itemType);
                values.put("appWidgetId", c.getString(appWidgetIdIndex));
                values.put(LauncherSettings.Favorites.ORIG_ID, c.getString(idIndex));
                values.put(LauncherSettings.Favorites.SPANX, c.getString(spanXIndex));
                values.put(LauncherSettings.Favorites.SPANY, c.getString(spanYIndex));
            }
            values.put("title", c.getString(titleIndex));
            String iconPackage = c.getString(iconPackageIndex);
            if (iconPackage != null && iconPackage.equals("com.sprint.zone")) {
                values.put("intent", "#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;launchFlags=0x10200000;component=com.sprint.dsa/.PageMain;end");
                values.put(LauncherSettings.Favorites.ICON_PACKAGE, "com.sprint.dsa");
            } else {
                values.put("intent", c.getString(intentIndex));
                values.put(LauncherSettings.Favorites.ICON_PACKAGE, c.getString(iconPackageIndex));
            }
            values.put("container", c.getString(containerIndex));
            values.put(LauncherSettings.Favorites.SCREEN, c.getString(screenIndex));
            values.put(LauncherSettings.Favorites.CELLX, c.getString(cellXIndex));
            values.put(LauncherSettings.Favorites.DISPLAY_MODE, c.getString(displayModeIndex));
            values.put(LauncherSettings.Favorites.CELLY, c.getString(cellYIndex));
            values.put(LauncherSettings.Favorites.IS_SHORTCUT, c.getString(isShortcutIndex));
            values.put(LauncherSettings.Favorites.ICON_TYPE, c.getString(iconTypeIndex));
            values.put(LauncherSettings.Favorites.ICON_RESOURCE, c.getString(iconResourceIndex));
            values.put(LauncherSettings.Favorites.ICON, c.getBlob(iconIndex));
            values.put(LauncherSettings.Favorites.PROPS, c.getBlob(propsIndex));
            values.put("uri", c.getString(uriIndex));
            values.put(LauncherSettings.Favorites.DISPLAY_MODE, c.getString(displayModeIndex));
            values.put("workspace_id", Integer.valueOf(c.getInt(workspaceId)));
        }
        c.close();
        contentResolver.bulkInsert(LauncherSettings.Favorites.CONTENT_URI_NO_NOTIFICATION, (ContentValues[]) list.toArray(new ContentValues[0]));
        contentResolver.update(LauncherSettings.getSpecialAction("_restore_widget_workspaces"), null, null, null);
        if (hasRosieSearchWidget) {
            int size = bindSources.size();
            int[] bindSourcesArray = new int[size];
            for (int i = 0; i < size; i++) {
                bindSourcesArray[i] = bindSources.get(i).intValue();
            }
            WidgetPackageManager.launchAppWidgetBinder(context, bindSourcesArray, bindTargets);
        }
    }

    static void backupAllItems(Context context) {
        context.getContentResolver().update(LauncherSettings.getSpecialAction("_backup_all_items"), null, null, null);
    }

    static int getAppWidgetCount(Context context, int appWidgetId) {
        int i;
        ContentResolver contentResolver = context.getContentResolver();
        Cursor c = null;
        try {
            c = contentResolver.query(LauncherSettings.Favorites.CONTENT_URI_NO_NOTIFICATION, null, "appWidgetId=" + appWidgetId, null, null);
            if (c != null) {
                i = c.getCount();
            } else {
                i = 0;
                if (c != null) {
                    c.close();
                }
            }
            return i;
        } finally {
            if (c != null) {
                c.close();
            }
        }
    }

    static void updateScreenId(Context context, int workspace_id, int[] mappingTable) {
        try {
            ContentValues values = new ContentValues();
            ContentResolver cr = context.getContentResolver();
            if (values != null && cr != null) {
                values.put("workspace_id", Integer.valueOf(workspace_id));
                byte[] data = new byte[mappingTable.length];
                for (int i = 0; i < mappingTable.length; i++) {
                    data[mappingTable[i]] = (byte) i;
                }
                values.put(LauncherSettings.Favorites.SCREEN, data);
                cr.update(LauncherSettings.getSpecialAction("_update_screen_id"), values, null, null);
                WidgetWorkspaceManager.instance(context).onSceneModified();
            }
        } catch (SQLException e) {
            Log.e(LOG_TAG, "updateScreenId failed, disk full?", e);
        }
    }

    private static int getHtcSearchWidgetId(Context context) {
        ContentResolver cr = context.getContentResolver();
        Uri CONTENT_URI = Uri.parse("content://com.htc.launcher.settings/widget_item_types");
        Cursor c = cr.query(CONTENT_URI, new String[]{LauncherSettings.WidgetItemTypes.WIDGET_NAME, LauncherSettings.Favorites.ID}, "widget_name='htcsearchwidgets.MyWidgetItem'", null, null);
        if (c.getCount() > 0) {
            c.moveToFirst();
            int htcSearchWidgetId = c.getInt(c.getColumnIndex(LauncherSettings.Favorites.ID));
            c.close();
            return htcSearchWidgetId;
        }
        c.close();
        return ApplicationManager.ALL_PROGRAM_LIST_HIGHEST_PRIORITY;
    }

    void outputAllDeskItems() {
        if (this.skipOutputAllDeskItems) {
            this.skipOutputAllDeskItems = false;
        } else {
            Thread thread = new Thread() { // from class: com.htc.launcher.LauncherModel.4
                @Override // java.lang.Thread, java.lang.Runnable
                public void run() {
                    try {
                        Thread.sleep(1000L);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    String output = LoggingEvents.EXTRA_CALLING_APP_NAME;
                    int seqNo = 0;
                    ReusableULogData uLogData = ReusableULogData.obtain();
                    uLogData.setAppId("com.htc.launcher").setCategory("layout");
                    Iterator i$ = LauncherModel.this.mDesktopItems.iterator();
                    while (i$.hasNext()) {
                        ItemInfo item = (ItemInfo) i$.next();
                        if (item != null && !item.getUlog().isEmpty()) {
                            seqNo++;
                            output = output + "widget_info" + Integer.toString(seqNo) + "=" + item.getUlog() + " ";
                        }
                    }
                    Iterator i$2 = LauncherModel.this.mDesktopAppWidgets.iterator();
                    while (i$2.hasNext()) {
                        ItemInfo item2 = (LauncherAppWidgetInfo) i$2.next();
                        if (item2 != null && !item2.getUlog().isEmpty()) {
                            seqNo++;
                            output = output + "widget_info" + Integer.toString(seqNo) + "=" + item2.getUlog() + " ";
                        }
                    }
                    uLogData.addData("widget_info", output);
                    ULog.log(uLogData);
                    Log.d(LauncherModel.LOG_TAG, "HTC user profiling" + output);
                    uLogData.recycle();
                }
            };
            thread.start();
        }
    }

    public static int getNextHostWidgetManagerId(Context context) {
        int result = 16777216;
        try {
            ContentResolver cr = context.getContentResolver();
            Cursor c = cr.query(LauncherSettings.Favorites.CONTENT_URI, new String[]{"appWidgetId"}, null, null, "appWidgetId DESC LIMIT 1");
            try {
                if (c.moveToFirst()) {
                    result = c.getInt(0);
                    result++;
                }
            } finally {
                c.close();
            }
        } catch (SQLException e) {
            Log.e(LOG_TAG, "getNextHostWidgetManagerId:", e);
        }
        return result;
    }
}
