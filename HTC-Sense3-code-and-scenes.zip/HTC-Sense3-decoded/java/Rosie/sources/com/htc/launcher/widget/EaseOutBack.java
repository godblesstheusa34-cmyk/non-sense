package com.htc.launcher.widget;

import com.htc.launcher.settings.SettingUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class EaseOutBack implements EasingFunction {
    @Override // com.htc.launcher.widget.EasingFunction
    public float currentResult(float v0, float t, float b, float c, float d) {
        float t2 = t / d;
        float ts = t2 * t2;
        float tc = ts * t2;
        return (((SettingUtil.sEaseOutBackCoefficients[4] * tc * ts) + (SettingUtil.sEaseOutBackCoefficients[3] * ts * ts) + (SettingUtil.sEaseOutBackCoefficients[2] * tc) + (SettingUtil.sEaseOutBackCoefficients[1] * ts) + (SettingUtil.sEaseOutBackCoefficients[0] * t2)) * c) + b;
    }
}
