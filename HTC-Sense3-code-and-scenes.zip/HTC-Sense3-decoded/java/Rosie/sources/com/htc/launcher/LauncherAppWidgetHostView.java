package com.htc.launcher;

import android.appwidget.AppWidgetHostView;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.RemoteViews;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class LauncherAppWidgetHostView extends AppWidgetHostView {
    private boolean mHasPerformedLongPress;
    private LayoutInflater mInflater;
    private CheckForLongPress mPendingCheckForLongPress;

    public LauncherAppWidgetHostView(Context context) {
        super(context);
        this.mInflater = (LayoutInflater) context.getSystemService("layout_inflater");
    }

    @Override // android.appwidget.AppWidgetHostView
    protected View getErrorView() {
        return this.mInflater.inflate(R.layout.appwidget_error, (ViewGroup) this, false);
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        if (this.mHasPerformedLongPress) {
            this.mHasPerformedLongPress = false;
            return true;
        }
        switch (ev.getAction()) {
            case 0:
                postCheckForLongClick();
                break;
            case 1:
            case 3:
                this.mHasPerformedLongPress = false;
                if (this.mPendingCheckForLongPress != null) {
                    removeCallbacks(this.mPendingCheckForLongPress);
                    break;
                }
                break;
        }
        return false;
    }

    class CheckForLongPress implements Runnable {
        private int mOriginalWindowAttachCount;

        CheckForLongPress() {
        }

        @Override // java.lang.Runnable
        public void run() {
            if (((View) LauncherAppWidgetHostView.this).mParent != null && LauncherAppWidgetHostView.this.hasWindowFocus() && this.mOriginalWindowAttachCount == LauncherAppWidgetHostView.this.getWindowAttachCount() && !LauncherAppWidgetHostView.this.mHasPerformedLongPress && LauncherAppWidgetHostView.this.performLongClick()) {
                LauncherAppWidgetHostView.this.mHasPerformedLongPress = true;
            }
        }

        public void rememberWindowAttachCount() {
            this.mOriginalWindowAttachCount = LauncherAppWidgetHostView.this.getWindowAttachCount();
        }
    }

    private void postCheckForLongClick() {
        this.mHasPerformedLongPress = false;
        if (this.mPendingCheckForLongPress == null) {
            this.mPendingCheckForLongPress = new CheckForLongPress();
        }
        this.mPendingCheckForLongPress.rememberWindowAttachCount();
        postDelayed(this.mPendingCheckForLongPress, ViewConfiguration.getLongPressTimeout());
    }

    @Override // android.view.View
    public void cancelLongPress() {
        super.cancelLongPress();
        this.mHasPerformedLongPress = false;
        if (this.mPendingCheckForLongPress != null) {
            removeCallbacks(this.mPendingCheckForLongPress);
        }
    }

    @Override // android.appwidget.AppWidgetHostView
    public void updateAppWidget(RemoteViews remoteViews) {
        if (Launcher.sDefaultAppWidgetHost.mListening) {
            super.updateAppWidget(remoteViews);
        }
    }
}
