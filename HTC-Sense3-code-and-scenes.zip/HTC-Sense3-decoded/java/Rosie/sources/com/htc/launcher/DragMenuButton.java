package com.htc.launcher;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.widget.RelativeLayout;
import android.widget.TextView;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class DragMenuButton extends RelativeLayout {
    private static final int ORIENTATION_HORIZONTAL = 1;
    private DisplayMetrics mMetrics;
    private int mOrientation;
    private TextView text;

    public DragMenuButton(Context context) {
        super(context);
    }

    public DragMenuButton(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public DragMenuButton(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.DragMenuBar, defStyle, 0);
        this.mOrientation = a.getInt(0, 1);
        a.recycle();
        this.mMetrics = getResources().getDisplayMetrics();
    }

    @Override // android.view.View
    protected void onFinishInflate() {
        this.text = (TextView) findViewById(R.id.drag_content);
    }

    public void setCompoundDrawablesWithIntrinsicBounds(int left, int top, int right, int bottom) {
        this.text.setCompoundDrawablesWithIntrinsicBounds(left, top, right, bottom);
    }

    public void setTextColor(int color) {
        this.text.setTextColor(color);
    }

    public void setTextPadding(int left, int top, int right, int bottom) {
        this.text.setPadding(left, top, right, bottom);
    }

    public void setText(int resid) {
        this.text.setText(resid);
    }

    public RelativeLayout.LayoutParams getTextLayoutParams() {
        return (RelativeLayout.LayoutParams) this.text.getLayoutParams();
    }
}
