package com.htc.launcher;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import com.htc.launcher.DragSource;
import com.htc.launcher.UserFolderInfo;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class UserFolder extends Folder implements DropTarget, UserFolderInfo.Observer {
    static final String LOG_TAG = "Rosie";

    public UserFolder(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    static UserFolder fromXml(Context context) {
        return (UserFolder) LayoutInflater.from(context).inflate(R.layout.user_folder, (ViewGroup) null);
    }

    @Override // com.htc.launcher.DropTarget
    public boolean acceptDrop(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        ItemInfo info = dragItem.getItemInfo();
        int itemType = info.itemType;
        return (itemType == 0 || itemType == 1) && info.container != this.mInfo.id;
    }

    @Override // com.htc.launcher.DropTarget
    public Rect estimateDropLocation(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem, Rect recycle) {
        return null;
    }

    @Override // com.htc.launcher.DropTarget
    public void onDrop(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        ItemInfo info = dragItem.getItemInfo();
        ListAdapter adapter = (ListAdapter) this.mContent.getAdapter();
        if (adapter instanceof ApplicationsAdapter) {
            ((ApplicationsAdapter) adapter).getList().add((ApplicationInfo) info);
            ((ApplicationsAdapter) adapter).notifyDataSetChanged();
        } else {
            TFC.assertTrue("strange adapter, not instanceof ApplicationsAdapter. adapter=" + adapter, false);
        }
        LauncherModel.addOrMoveItemInDatabase(this.mLauncher, info, this.mInfo.id, 0, 0, 0);
    }

    @Override // com.htc.launcher.DropTarget
    public void onDragEnter(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
    }

    @Override // com.htc.launcher.DropTarget
    public void onDragOver(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
    }

    @Override // com.htc.launcher.DropTarget
    public void onDragExit(DragSource source, DropTarget target, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
    }

    @Override // com.htc.launcher.DropTarget
    public DragSource.DragCompletedAction getDragCompletedAction() {
        return DragSource.DragCompletedAction.REMOVE;
    }

    @Override // com.htc.launcher.Folder, com.htc.launcher.DragSource
    public void onDropCompleted(DropTarget target, boolean success) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG][FOLDER] UserFolder.onDropCompleted() success:" + success);
        if (success) {
            ApplicationsAdapter adapter = (ApplicationsAdapter) this.mContent.getAdapter();
            adapter.getList().remove(this.mDragItem);
        }
        if (this.mLauncher != null && this.mDragItem != null) {
            this.mLauncher.getDesktopItemController().poofFxItem();
        }
    }

    @Override // com.htc.launcher.Folder
    void bind(FolderInfo info) {
        super.bind(info);
        ApplicationsAdapter mAdapter = new ApplicationsAdapter(((View) this).mContext, ((UserFolderInfo) info).contents);
        setContentAdapter(mAdapter);
        if (info instanceof UserFolderInfo) {
            ((UserFolderInfo) info).setObserver(this);
        }
    }

    @Override // com.htc.launcher.Folder
    void onOpen() {
        super.onOpen();
        requestFocus();
    }

    @Override // com.htc.launcher.UserFolderInfo.Observer
    public void onDataChanged() {
        if (this.mContent.getAdapter() != null) {
            PendingUIUpdate.instance().postPending(-100, new Runnable() { // from class: com.htc.launcher.UserFolder.1
                @Override // java.lang.Runnable
                public void run() {
                    ((ApplicationsAdapter) UserFolder.this.mContent.getAdapter()).notifyDataSetChanged();
                }
            });
        }
    }

    public void AddIntoFolder(Context context, Intent data) {
        ComponentName component = data.getComponent();
        PackageManager packageManager = context.getPackageManager();
        ActivityInfo activityInfo = null;
        try {
            activityInfo = packageManager.getActivityInfo(component, 0);
        } catch (PackageManager.NameNotFoundException e) {
            Log.e(LOG_TAG, "Couldn't find ActivityInfo for selected application", e);
        }
        if (activityInfo != null) {
            ApplicationInfo itemInfo = new ApplicationInfo();
            itemInfo.title = activityInfo.loadLabel(packageManager);
            if (itemInfo.title == null) {
                itemInfo.title = ((PackageItemInfo) activityInfo).name;
            }
            itemInfo.setActivity(component, 270532608);
            itemInfo.icon = ResourceUtil.getApplicationIcon(packageManager, activityInfo);
            itemInfo.container = -1L;
            ListAdapter adapter = (ListAdapter) this.mContent.getAdapter();
            if (adapter instanceof ApplicationsAdapter) {
                ((ApplicationsAdapter) adapter).getList().add(itemInfo);
                ((ApplicationsAdapter) adapter).notifyDataSetChanged();
            } else {
                TFC.assertTrue("adapter not instanceof ApplicationsAdapter. adapter=" + adapter, false);
            }
            LauncherModel.addOrMoveItemInDatabase(this.mLauncher, itemInfo, this.mInfo.id, 0, 0, 0);
        }
    }

    public void notifyDataSetChanged() {
        if (this.mContent.getAdapter() instanceof ApplicationsAdapter) {
            ((ApplicationsAdapter) this.mContent.getAdapter()).notifyDataSetChanged();
        }
    }

    @Override // com.htc.launcher.DropTarget
    public boolean claimDrop(int x, int y, int[] dropCoordinates) {
        return false;
    }

    public boolean addIntoFolder(ApplicationInfo itemInfo) {
        if (itemInfo != null && (itemInfo instanceof ApplicationInfo)) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG][FOLDER] UserFolder.addIntoFolder() FolderId(" + getId() + ") ItemInfo:" + itemInfo);
            itemInfo.container = -1L;
            ListAdapter adapter = (ListAdapter) this.mContent.getAdapter();
            if (adapter instanceof ApplicationsAdapter) {
                ((ApplicationsAdapter) adapter).getList().add(itemInfo);
                ((ApplicationsAdapter) adapter).notifyDataSetChanged();
            } else {
                TFC.assertTrue("UserFolder.addIntoFolder: adapter=" + adapter, false);
            }
            ((DragLayer) this.mLauncher.getDragController()).invalidate();
            LauncherModel.addOrMoveItemInDatabase(this.mLauncher, itemInfo, this.mInfo.id, 0, 0, 0);
            return true;
        }
        return false;
    }

    public void froceUpdateRemote(Canvas canvas) {
    }
}
