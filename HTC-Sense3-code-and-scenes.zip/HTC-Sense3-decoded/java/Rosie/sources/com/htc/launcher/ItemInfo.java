package com.htc.launcher;

import android.content.ContentValues;
import android.graphics.Bitmap;
import android.util.Log;
import android.view.ViewGroup;
import com.android.common.speech.LoggingEvents;
import com.htc.launcher.LauncherSettings;
import com.htc.launcher.settings.SettingUtil;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public abstract class ItemInfo {
    public static final int NO_ID = -1;
    public static final int max_screen = SettingUtil.sWorkspaceScreenCount;
    public int cellX;
    public int cellY;
    public long container;
    String iconname;
    public long id;
    public int itemType;
    public boolean removable;
    public int screen;
    public int spanX;
    public int spanY;
    public int workspaceId;

    public abstract Draggee createItem(Launcher launcher, ViewGroup viewGroup);

    public abstract long getId();

    ItemInfo() {
        this.id = -1L;
        this.container = -1L;
        this.screen = -1;
        this.cellX = -1;
        this.cellY = -1;
        this.spanX = 1;
        this.spanY = 1;
        this.removable = true;
        this.iconname = null;
        this.workspaceId = 0;
    }

    ItemInfo(ItemInfo info) {
        this.id = -1L;
        this.container = -1L;
        this.screen = -1;
        this.cellX = -1;
        this.cellY = -1;
        this.spanX = 1;
        this.spanY = 1;
        this.removable = true;
        this.iconname = null;
        this.workspaceId = 0;
        this.id = info.id;
        this.cellX = info.cellX;
        this.cellY = info.cellY;
        this.spanX = info.spanX;
        this.spanY = info.spanY;
        this.screen = info.screen;
        this.itemType = info.itemType;
        this.container = info.container;
        this.removable = info.removable;
        this.iconname = info.iconname;
    }

    void onAddToDatabase(ContentValues values) {
        values.put(LauncherSettings.Favorites.ITEM_TYPE, Integer.valueOf(this.itemType));
        values.put("container", Long.valueOf(this.container));
        values.put(LauncherSettings.Favorites.SCREEN, Integer.valueOf(this.screen));
        values.put(LauncherSettings.Favorites.CELLX, Integer.valueOf(this.cellX));
        values.put(LauncherSettings.Favorites.CELLY, Integer.valueOf(this.cellY));
        values.put(LauncherSettings.Favorites.SPANX, Integer.valueOf(this.spanX));
        values.put(LauncherSettings.Favorites.SPANY, Integer.valueOf(this.spanY));
        values.put("workspace_id", Integer.valueOf(this.workspaceId));
    }

    static void writeBitmap(ContentValues values, Bitmap bitmap) {
        if (bitmap != null) {
            int size = bitmap.getWidth() * bitmap.getHeight() * 4;
            ByteArrayOutputStream out = new ByteArrayOutputStream(size);
            try {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                out.flush();
                out.close();
                values.put(LauncherSettings.Favorites.ICON, out.toByteArray());
            } catch (IOException e) {
                Log.w("Favorite", "Could not write icon");
            }
        }
    }

    public String toString() {
        return "id(" + this.id + ")cellX(" + this.cellX + ")cellY(" + this.cellY + ")spanX(" + this.spanX + ")spanY(" + this.spanY + ")screen(" + this.screen + ")itemType(" + this.itemType + ")container(" + this.container + ")removable(" + this.removable + ")iconname(" + this.iconname + ")";
    }

    public String getUlog() {
        return LoggingEvents.EXTRA_CALLING_APP_NAME;
    }

    public boolean isItemEditable() {
        return false;
    }

    public void editItem() {
    }
}
