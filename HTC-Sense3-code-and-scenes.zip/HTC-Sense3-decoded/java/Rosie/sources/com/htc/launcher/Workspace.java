package com.htc.launcher;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.android.common.speech.LoggingEvents;
import com.htc.android.rosie.home.fxcontrol.FxScreen;
import com.htc.home.HtcSearch;
import com.htc.launcher.CellInfo;
import com.htc.launcher.CellLayout;
import com.htc.launcher.DragController;
import com.htc.launcher.DragSource;
import com.htc.launcher.Draggee;
import com.htc.launcher.LauncherSettings;
import com.htc.launcher.LeapController;
import com.htc.launcher.custom.CustomResourceUtil;
import com.htc.launcher.settings.SettingUtil;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class Workspace extends ViewGroup implements DropTarget, DragSource, DragScroller, DragController.DragListener, LeapController.LeapLayer, LeapController.LeapAnimationPlayer {
    static final /* synthetic */ boolean $assertionsDisabled;
    static final int ALL_SCREENS = Integer.MIN_VALUE;
    static final int ALL_SCREENS_BUT_CURRENT = -2147483647;
    private static final long APP_WIDGET_RESUME_DELAY = 2000;
    public static final boolean AUTO_REARRANGE_MODE;
    private static final boolean CACHE_ALWAYS_ON = true;
    private static final boolean CACHE_PAGE = false;
    static final int CURRENT_SCREEN = -2147483646;
    private static final boolean DEBUG_TOUCH;
    private static final float HVGA_WIDTH = 320.0f;
    static final int INVALID_SCREEN = -1;
    private static final String LOG_TAG = "Workspace";
    public static final int MINIMUM_DURATION = 500;
    private static final int MINIMUM_VELOCITY = 1000;
    private static final int RECOVERY_DURATION = 1000;
    private static final int SCROLL_COMPENSATION_MAX_VELOCITY = 1000;
    private static final int TOUCH_STATE_REST = 0;
    private static final int TOUCH_STATE_SCROLLING = 1;
    private static boolean hasCache;
    private static final boolean localLOGD;
    static float sScrollSpeedScale;
    private boolean isNeedRecovery;
    private boolean isRestoreCurrentPage;
    private boolean isScrolling;
    private boolean isShowVacantRect;
    private SavedState localSavedState;
    private boolean mAllowLongPress;
    private int mBounceScreen;
    private boolean mCanScroll;
    final Rect mClipBounds;
    private int mCurrentScreen;
    private int mCurrentTouchScreen;
    private boolean mDidScroll;
    private boolean mDidfling;
    private long mDownTime;
    private CellInfo mDragInfo;
    private int mDragOverX;
    private int mDragOverY;
    Draggee mDraggeeItem;
    private ItemInfo mDraggeeItemInfo;
    private DragController mDragger;
    final Rect mDrawerBounds;
    int mDrawerContentHeight;
    int mDrawerContentWidth;
    private boolean mEditing;
    private int mFakeCellPadding;
    boolean mFirstLayout;
    private FocusState mFocus;
    private boolean mIsNeedDropBack;
    private boolean mIsNeedtoDrawAllScreens;
    private float mLastMotionX;
    private float mLastMotionY;
    private long mLastTouchEventTime;
    private Launcher mLauncher;
    private LeapController mLeapController;
    private boolean mLocked;
    private View.OnLongClickListener mLongClickListener;
    private boolean mMoved;
    private int mNextScreen;
    private Runnable mNotifyScrollEnded;
    private OnHomeScreenListener mOnHomeScreenListener;
    private boolean mOnSnapToScreen;
    private Paint mPaint;
    private int mPreviousWidth;
    private ArrayList<Draggee> mRearrangedDraggee;
    private float mRecoveryDistance;
    private Runnable mResumeAppWidgets;
    private ScrollMonitor mScrollMonitor;
    private long mScrollStartTime;
    private ArrayList<OnScrollStateChangedListener> mScrollStateChangedListeners;
    private SlideController mSlideController;
    private float mStartX;
    private boolean mTouchDownRedirected;
    private View.OnTouchListener mTouchRedirect;
    private int mTouchState;
    Handler mUpdateVacantHandler;
    HandlerThread mUpdateVacantThread;
    private VelocityTracker mVelocityTracker;
    private final WallpaperManager mWallpaperManager;

    public interface OnHomeScreenListener {
        void onEnterHomeScreen();

        void onHomeScreenLayoutChanged();
    }

    public interface OnScrollStateChangedListener {
        void onBeginFling();

        void onBeginScroll(boolean z, int i, int i2);

        void onEndScroll();

        void updateSnapInfo(int i, int i2);
    }

    public interface OnSlideListener {
        void onFling(int i, int i2, int i3);

        void onScrollTo(float f, float f2, int i, int i2);

        void onTouch(MotionEvent motionEvent, int i);
    }

    public interface Screen {
        boolean acceptChildDrop(int i, int i2, int i3, int i4, Draggee draggee);

        void addItem(Draggee draggee, int i);

        ViewGroup asViewGroup();

        void cellToPoint(int i, int i2, int[] iArr);

        void cellToRect(int i, int i2, int i3, int i4, RectF rectF);

        void cellToWidgetRect(int i, int i2, int i3, int i4, RectF rectF);

        void clearVacant();

        CellInfo findAllVacantCells(boolean[] zArr);

        CellInfo.VacantCell findNearestVacantCellsForSpan(CellInfo cellInfo, int i, int i2);

        void findVacantCellsForSpan(List<CellInfo.VacantCell> list, int i, int i2);

        Folder getOpenFolder();

        ArrayList<Draggee> getRearrangeItems();

        boolean hasRearrangedVacant();

        boolean hasVacant();

        void hideVacant();

        boolean isVacantVisible();

        boolean isValidCellInfo(float f, float f2, CellInfo cellInfo);

        void onDragChild(Draggee draggee);

        void onDragExit(int i, int i2, boolean z);

        void onDragOverChild(View view, int i, int i2);

        void onDropChild(Draggee draggee, int i, int i2, int i3, int i4);

        void onDropChildByCell(Draggee draggee, int i, int i2, int i3, int i4);

        void onEndDrag();

        void pointToDropCell(int i, int i2, int i3, int i4, int[] iArr);

        boolean removeItem(Draggee draggee);

        boolean tryRearrangeForSpan(Draggee draggee, int i, int i2, int i3, int i4);

        void updateVacant(int i, int i2, int i3, int i4);
    }

    static {
        $assertionsDisabled = !Workspace.class.desiredAssertionStatus();
        AUTO_REARRANGE_MODE = "3.0".equals("2.1");
        localLOGD = SettingUtil.localLOGD;
        DEBUG_TOUCH = false;
        hasCache = false;
        sScrollSpeedScale = 1.0f;
    }

    public Workspace(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public Workspace(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mFirstLayout = true;
        this.mPreviousWidth = -1;
        this.mCurrentScreen = 4;
        this.mNextScreen = -1;
        this.mBounceScreen = -1;
        this.mFakeCellPadding = 0;
        this.mTouchState = 0;
        this.mOnSnapToScreen = false;
        this.mDrawerBounds = new Rect();
        this.mClipBounds = new Rect();
        this.mDidScroll = false;
        this.mDidfling = false;
        this.isRestoreCurrentPage = true;
        this.mIsNeedtoDrawAllScreens = false;
        this.mCanScroll = true;
        this.isNeedRecovery = false;
        this.mMoved = false;
        this.mResumeAppWidgets = new Runnable() { // from class: com.htc.launcher.Workspace.1
            @Override // java.lang.Runnable
            public void run() {
                Launcher.sDefaultAppWidgetHost.startListening();
            }
        };
        this.mNotifyScrollEnded = new Runnable() { // from class: com.htc.launcher.Workspace.2
            @Override // java.lang.Runnable
            public void run() {
                Workspace.this.clearChildrenCache();
                Workspace.this.mLauncher.raisePriority(false);
            }
        };
        this.isScrolling = false;
        this.mFocus = null;
        this.mRearrangedDraggee = new ArrayList<>();
        this.mUpdateVacantThread = null;
        this.mUpdateVacantHandler = null;
        this.isShowVacantRect = true;
        this.mTouchRedirect = null;
        this.mTouchDownRedirected = false;
        this.mDraggeeItemInfo = null;
        this.mDraggeeItem = null;
        this.mIsNeedDropBack = false;
        this.mWallpaperManager = WallpaperManager.getInstance(context);
        initWorkspace();
    }

    private void initWorkspace() {
        this.mCurrentScreen = getDefaultScreenIndex();
        sendCurrentScreenIndexInfo();
        Launcher.setScreen(this.mCurrentScreen);
        this.mPaint = new Paint();
        this.mPaint.setDither(false);
    }

    void loadWallpaper(Bitmap bitmap) {
        this.mWallpaperManager.setStaticWallpaper(bitmap);
        requestLayout();
        invalidate();
    }

    @Override // android.view.ViewGroup
    public void addView(View child, int index, ViewGroup.LayoutParams params) {
        if (!(child instanceof CellLayout)) {
            throw new IllegalArgumentException("A Workspace can only have CellLayout children.");
        }
        super.addView(child, index, params);
    }

    @Override // android.view.ViewGroup
    public void addView(View child) {
        if (!(child instanceof CellLayout)) {
            throw new IllegalArgumentException("A Workspace can only have CellLayout children.");
        }
        super.addView(child);
    }

    @Override // android.view.ViewGroup
    public void addView(View child, int index) {
        if (!(child instanceof CellLayout)) {
            throw new IllegalArgumentException("A Workspace can only have CellLayout children.");
        }
        super.addView(child, index);
    }

    @Override // android.view.ViewGroup
    public void addView(View child, int width, int height) {
        if (!(child instanceof CellLayout)) {
            throw new IllegalArgumentException("A Workspace can only have CellLayout children.");
        }
        super.addView(child, width, height);
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public void addView(View child, ViewGroup.LayoutParams params) {
        if (!(child instanceof CellLayout)) {
            throw new IllegalArgumentException("A Workspace can only have CellLayout children.");
        }
        super.addView(child, params);
    }

    Folder getOpenFolder() {
        Screen screen = getCurrentScreen();
        if (screen == null) {
            return null;
        }
        return screen.getOpenFolder();
    }

    ArrayList<Folder> getOpenFolders() {
        Folder found;
        int N = SettingUtil.getScreenCount();
        ArrayList<Folder> folders = new ArrayList<>(N);
        for (int screen = 0; screen < N; screen++) {
            Screen current = getScreenAt(screen);
            if (current != null && (found = current.getOpenFolder()) != null) {
                folders.add(found);
            }
        }
        return folders;
    }

    public void closeAllOpenLiveFolder() {
        ArrayList<Folder> folders = getOpenFolders();
        Iterator i$ = folders.iterator();
        while (i$.hasNext()) {
            Folder folder = i$.next();
            if (folder instanceof LiveFolder) {
                this.mLauncher.getDesktopItemController().closeFolder(folder);
            }
        }
    }

    public void closeAllOpenFolder() {
        ArrayList<Folder> folders = getOpenFolders();
        Iterator i$ = folders.iterator();
        while (i$.hasNext()) {
            Folder folder = i$.next();
            this.mLauncher.getDesktopItemController().closeFolder(folder);
        }
    }

    boolean isDefaultScreenShowing() {
        return this.mCurrentScreen == getDefaultScreenIndex();
    }

    void sendCurrentScreenIndexInfo() {
        Intent intent = new Intent();
        intent.setAction(LauncherIntent.ACTION_SQA_INFO);
        intent.putExtra(LauncherIntent.EXTRA_SCREEN_ID, this.mCurrentScreen);
        Launcher.sRefLauncher.get().sendBroadcast(intent);
    }

    public int getCurrentScreenIndex() {
        return this.mCurrentScreen;
    }

    int getCurrentScreenIndexByScrollX() {
        return this.mSlideController.getCurrentScreenIndexByScrollX();
    }

    public void setCurrentScreen(int currentScreen) {
        int previousScreen = getCurrentScreenIndex();
        this.mCurrentScreen = Math.max(0, Math.min(currentScreen, getChildCount() - 1));
        sendCurrentScreenIndexInfo();
        this.mSlideController.scrollTo(this.mCurrentScreen * getWidth(), 0.0f);
        this.mOnSnapToScreen = false;
        if (previousScreen != getDefaultScreenIndex() && isCurrentScreenHomeScreen() && this.mOnHomeScreenListener != null) {
            this.mOnHomeScreenListener.onEnterHomeScreen();
        }
        scrollTo(this.mCurrentScreen * getWidth(), 0);
    }

    boolean isCurrentScreenHomeScreen() {
        return this.mCurrentScreen == getDefaultScreenIndex();
    }

    void showDefaultScreen() {
        setCurrentScreen(getDefaultScreenIndex());
    }

    @Deprecated
    private void addInCurrentScreen(View child, int x, int y, int spanX, int spanY) {
        addInScreen(child, this.mCurrentScreen, x, y, spanX, spanY, false);
    }

    @Deprecated
    private void addInCurrentScreen(View child, int x, int y, int spanX, int spanY, boolean insert) {
        addInScreen(child, this.mCurrentScreen, x, y, spanX, spanY, insert);
    }

    @Deprecated
    private void addInScreen(View child, int screen, int x, int y, int spanX, int spanY) {
        addInScreen(child, screen, x, y, spanX, spanY, false);
    }

    void addInScreen(View child, int screen, int cellX, int cellY, int spanX, int spanY, boolean insert) {
        if (screen < 0 || screen >= getChildCount()) {
            throw new IllegalStateException("The screen must be >= 0 and < " + getChildCount());
        }
        CellLayout group = (CellLayout) getChildAt(screen);
        ViewGroup.LayoutParams lp = child.getLayoutParams();
        if (lp == null || !(lp instanceof CellLayout.LayoutParams)) {
            lp = new CellLayout.LayoutParams(cellX, cellY, spanX, spanY);
            child.setLayoutParams(lp);
        }
        CellLayout.LayoutParams clp = (CellLayout.LayoutParams) lp;
        clp.cellX = cellX;
        clp.cellY = cellY;
        clp.cellHSpan = spanX;
        clp.cellVSpan = spanY;
        group.addView(child, insert ? -1 : 0, lp);
    }

    LegacyLayout wrapLegacyView(View view) {
        if (view.getLayoutParams() == null) {
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, -1);
            view.setPadding(this.mFakeCellPadding, 0, this.mFakeCellPadding, 0);
            view.setLayoutParams(layoutParams);
        }
        view.setOnLongClickListener(this.mLongClickListener);
        return new LegacyLayout(this, view, view.getLayoutParams());
    }

    private void log(String msg) {
        Log.d(LOG_TAG, msg);
    }

    CellInfo findAllVacantCells(boolean[] occupied) {
        Screen screen = getScreenAt(this.mCurrentScreen);
        if (screen != null) {
            return screen.findAllVacantCells(occupied);
        }
        return null;
    }

    void getWidthHeightForSpan(int spanX, int spanY, int[] wh) {
        Screen screen = getScreenAt(0);
        RectF rect = new RectF();
        screen.cellToRect(0, 0, spanX, spanY, rect);
        wh[0] = (int) rect.width();
        wh[1] = (int) rect.height();
    }

    boolean hasRoomForSpan(int spanX, int spanY) {
        boolean has = false;
        int N = SettingUtil.getScreenCount();
        for (int i = 0; i < N; i++) {
            Screen screen = getScreenAt(i);
            screen.updateVacant(-1, -1, spanX, spanY);
            if (screen.hasVacant()) {
                has = true;
            }
        }
        return has;
    }

    boolean hasRoomInCurrentScreen(int spanX, int spanY, boolean forShortcut) {
        ArrayList<CellInfo.VacantCell> cells = new ArrayList<>();
        Screen screen = getCurrentScreen();
        screen.findVacantCellsForSpan(cells, spanX, spanY);
        return cells.size() > 0;
    }

    boolean hasRoomForSpan_ForceUpdate(int spanX, int spanY) {
        boolean has = false;
        int N = SettingUtil.getScreenCount();
        for (int i = 0; i < N; i++) {
            Screen screen = getScreenAt(i);
            screen.clearVacant();
            screen.updateVacant(-1, -1, spanX, spanY);
            if (screen.hasVacant()) {
                has = true;
            }
        }
        return has;
    }

    void invalidateVacant() {
        SettingUtil.getScreenCount();
        for (int i = 0; i < getChildCount(); i++) {
            Screen screen = getScreenAt(i);
            if (screen != null) {
                if (screen.isVacantVisible()) {
                    screen.hideVacant();
                }
                screen.clearVacant();
            }
        }
    }

    public static class OnLongClickReference implements View.OnLongClickListener {
        private WeakReference<View.OnLongClickListener> refListener;

        private OnLongClickReference(View.OnLongClickListener l) {
            this.refListener = null;
            this.refListener = new WeakReference<>(l);
        }

        @Override // android.view.View.OnLongClickListener
        public boolean onLongClick(View v) {
            View.OnLongClickListener l = this.refListener.get();
            if (l != null) {
                return l.onLongClick(v);
            }
            return false;
        }
    }

    @Override // android.view.View
    public void setOnLongClickListener(View.OnLongClickListener l) {
        this.mLongClickListener = new OnLongClickReference(l);
        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            getChildAt(i).setOnLongClickListener(this.mLongClickListener);
        }
    }

    public View.OnLongClickListener getOnLongClickListener() {
        return this.mLongClickListener;
    }

    void addDirtyView(View view) {
        ViewParent screen = view.getParent();
        for (int i = 0; i < getChildCount(); i++) {
            if (getChildAt(i) == screen) {
                drawScreens(i);
            }
        }
    }

    @Deprecated
    void drawScreens(int screen) {
        long now = SystemClock.elapsedRealtime();
        int childCount = getChildCount();
        switch (screen) {
            case Integer.MIN_VALUE:
                for (int i = 0; i < childCount; i++) {
                    View childView = getChildAt(i);
                    if (childView instanceof CellLayout) {
                        ((CellLayout) childView).updateCellLayoutCache();
                        ((CellLayout) childView).stopAutoUpdateCellLayoutCache();
                    }
                }
                break;
            case ALL_SCREENS_BUT_CURRENT /* -2147483647 */:
                for (int i2 = 0; i2 < childCount; i2++) {
                    if (i2 != this.mCurrentScreen) {
                        View childView2 = getChildAt(i2);
                        if (childView2 instanceof CellLayout) {
                            ((CellLayout) childView2).updateCellLayoutCache();
                            ((CellLayout) childView2).stopAutoUpdateCellLayoutCache();
                        }
                    }
                }
                break;
            default:
                int which = screen == CURRENT_SCREEN ? getCurrentScreenIndexByScrollX() : screen;
                if (localLOGD) {
                    Log.d(LOG_TAG, "drawScreens(" + which + ")");
                }
                View childView3 = getChildAt(which);
                if (childView3 instanceof CellLayout) {
                    ((CellLayout) childView3).updateCellLayoutCache();
                    ((CellLayout) childView3).stopAutoUpdateCellLayoutCache();
                    break;
                } else {
                    Log.e(LOG_TAG, "drawScreens(" + which + ") but childView is " + childView3);
                    break;
                }
        }
        if (localLOGD) {
            long now2 = SystemClock.elapsedRealtime() - now;
            if (screen == Integer.MIN_VALUE) {
                if (!localLOGD) {
                    if (localLOGD) {
                        Log.d("[ScrollKPI]", "draw screen#" + screen + " takes " + now2 + "ms");
                        return;
                    }
                    return;
                }
                Log.d("[ScrollKPI]", "draw all screens takes " + now2 + "ms");
            }
        }
    }

    public void updateWallpaperOffset() {
        if (this.mLeapController.isLeapMode()) {
            updateWallpaperOffset(getChildCount() * (this.mRight - this.mLeft), this.mScrollX + (this.mRight - this.mLeft));
        } else if (SettingUtil.isTabletDevice()) {
            updateWallpaperOffset(getChildCount() * (this.mRight - this.mLeft), this.mScrollX);
        } else {
            updateWallpaperOffset((getChildCount() + 1) * (this.mRight - this.mLeft), this.mScrollX + (this.mRight - this.mLeft));
        }
    }

    private void updateWallpaperOffset(int scrollRange, int scrollX) {
        IBinder win = getWindowToken();
        if (win == null) {
            Log.w(LOG_TAG, "view is not attached to window so wallpaper offset will not be updated.");
            return;
        }
        if (this.mLeapController.isLeapMode()) {
            this.mWallpaperManager.setWallpaperOffsets(win, ((this.mLeapController.getVirtualScrollX() + this.mRight) - this.mLeft) / scrollRange, 0.0f);
            return;
        }
        if (scrollX > scrollRange) {
            scrollX %= scrollRange;
        } else if (scrollX < 0) {
            scrollX = scrollRange - (Math.abs(scrollX) % scrollRange);
        }
        this.mWallpaperManager.setWallpaperOffsetSteps(1.0f / (getChildCount() + 1), 0.0f);
        this.mWallpaperManager.setWallpaperOffsets(win, scrollX / scrollRange, 0.0f);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void dispatchDraw(Canvas canvas) {
        if (this.mLauncher.mStartOrientation > 0) {
            Launcher.sOrientationMonitor.beginDispatchDraw();
        }
        if (isDoingScroll()) {
            this.mScrollMonitor.startDrawWorkspace();
        }
        boolean restore = false;
        if (this.mLauncher.isDrawerUp()) {
            Rect clipBounds = this.mClipBounds;
            canvas.getClipBounds(clipBounds);
            clipBounds.offset(-this.mScrollX, -this.mScrollY);
            this.mDrawerBounds.contains(clipBounds);
            return;
        }
        if (this.mLauncher.isDrawerMoving()) {
            restore = true;
            canvas.save(2);
            View view = this.mLauncher.getDrawerHandle();
            int top = view.getTop() + view.getHeight();
            canvas.clipRect(this.mScrollX, top, this.mScrollX + this.mDrawerContentWidth, this.mDrawerContentHeight + top, Region.Op.DIFFERENCE);
        }
        this.mWallpaperManager.drawWallpaper(canvas, getWidth(), this.mScrollX, this.mTop, this.mBottom, this.mPaint);
        long drawingTime = getDrawingTime();
        if (this.mScrollX < 0) {
            drawChild(canvas, getChildAt(0), drawingTime);
        } else if (this.mScrollX > getWidth() * (getChildCount() - 1)) {
            drawChild(canvas, getChildAt(getChildCount() - 1), drawingTime);
        } else if (this.mIsNeedtoDrawAllScreens) {
            int count = canvas.save();
            canvas.clipRect(0.0f, 0.0f, canvas.getWidth(), canvas.getHeight(), Region.Op.REPLACE);
            for (int i = 0; i < getChildCount(); i++) {
                View childView = getChildAt(i);
                ((CellLayout) childView).dispatchDraw(canvas);
                drawChild(canvas, childView, drawingTime);
            }
            canvas.restoreToCount(count);
            this.mIsNeedtoDrawAllScreens = false;
            this.mLauncher.getFxWorkspace().pulseFreezeAllScreens();
        } else {
            int currentScreen = this.mScrollX / getWidth();
            int neighborScreen = currentScreen + 1;
            if (currentScreen != this.mBounceScreen) {
                drawChild(canvas, getChildAt(currentScreen), drawingTime);
            }
            if (currentScreen < getChildCount() - 1 && getChildAt(neighborScreen).getLeft() - this.mScrollX < getWidth() && neighborScreen != this.mBounceScreen) {
                drawChild(canvas, getChildAt(neighborScreen), drawingTime);
            }
        }
        if (restore) {
            canvas.restore();
        }
        if (isDoingScroll()) {
            this.mScrollMonitor.endDrawWorkspace(this.mScrollX, getCurrentScreenIndexByScrollX());
        }
        if (this.mLauncher.mStartOrientation > 0) {
            if (localLOGD) {
                Log.d(LOG_TAG, "Time spent on Orientation - " + (System.currentTimeMillis() - this.mLauncher.mStartOrientation));
            }
            this.mLauncher.mStartOrientation = -1L;
            Launcher.sOrientationMonitor.endDispatchDraw();
        }
    }

    @Override // android.view.ViewGroup
    @Deprecated
    protected boolean drawChild(Canvas canvas, View child, long drawingTime) {
        if (isDrawCellCache(child)) {
            return true;
        }
        super.drawChild(canvas, child, drawingTime);
        return true;
    }

    @Deprecated
    boolean isDrawCellCache(View child) {
        return (isDoingScroll() || this.mLauncher.isDrawerMoving()) && (child instanceof CellLayout) && ((CellLayout) child).isCacheReady();
    }

    @Override // android.view.View
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        Launcher.sOrientationMonitor.beginWorkspaceOnMeasure();
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int width = View.MeasureSpec.getSize(widthMeasureSpec);
        int widthMode = View.MeasureSpec.getMode(widthMeasureSpec);
        if (widthMode != 1073741824) {
            throw new IllegalStateException("Workspace can only be used in EXACTLY mode.");
        }
        int heightMode = View.MeasureSpec.getMode(heightMeasureSpec);
        if (heightMode != 1073741824) {
            throw new IllegalStateException("Workspace can only be used in EXACTLY mode.");
        }
        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            getChildAt(i).measure(widthMeasureSpec, heightMeasureSpec);
        }
        this.mWallpaperManager.onMeasure(getContext(), width, 0, widthMeasureSpec, heightMeasureSpec);
        if (this.mFirstLayout && this.mPreviousWidth != width) {
            scrollTo(this.mCurrentScreen * width, 0);
            updateWallpaperOffset((getChildCount() + 1) * width, this.mScrollX + width);
            this.mFirstLayout = false;
            this.mPreviousWidth = width;
        }
        Launcher.sOrientationMonitor.endWorkspaceOnMeasure();
        sScrollSpeedScale = HVGA_WIDTH / width;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        int childLeft = 0;
        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            View child = getChildAt(i);
            if (child.getVisibility() != 8) {
                int childWidth = child.getMeasuredWidth();
                child.layout(childLeft, 0, childLeft + childWidth, child.getMeasuredHeight());
                childLeft += childWidth;
            }
        }
    }

    @Override // android.view.View
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        sScrollSpeedScale = HVGA_WIDTH / w;
        if (localLOGD) {
            Log.d("Workspace.onSizeChanged", "w=" + w + " h=" + h + " ow=" + oldw + " oh=" + oldh + ", child:" + getChildCount());
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean requestChildRectangleOnScreen(View child, Rect rectangle, boolean immediate) {
        int screen = indexOfChild(child);
        if (screen == this.mCurrentScreen && this.mSlideController.isSlideFinish()) {
            return false;
        }
        if (!this.mLauncher.isWorkspaceLocked() && !this.mLeapController.isLeapMode()) {
            this.mSlideController.snapToScreen(screen);
        }
        return true;
    }

    @Override // android.view.ViewGroup
    protected boolean onRequestFocusInDescendants(int direction, Rect previouslyFocusedRect) {
        int focusableScreen;
        if (this.mLauncher.isDrawerDown()) {
            Folder openFolder = getOpenFolder();
            if (openFolder != null) {
                return openFolder.requestFocus(direction, previouslyFocusedRect);
            }
            if (this.mNextScreen != -1) {
                focusableScreen = this.mNextScreen;
            } else {
                focusableScreen = this.mCurrentScreen;
            }
            getChildAt(focusableScreen).requestFocus(direction, previouslyFocusedRect);
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchUnhandledMove(View focused, int direction) {
        if (this.mLeapController.isLeapMode()) {
            return true;
        }
        if (direction == 17) {
            if (getCurrentScreenIndex() > 0) {
                drawScreens(getCurrentScreenIndex());
                this.mSlideController.snapToScreen(getCurrentScreenIndex() - 1);
                return true;
            }
        } else if (direction == 66 && getCurrentScreenIndex() < getChildCount() - 1) {
            drawScreens(getCurrentScreenIndex());
            this.mSlideController.snapToScreen(getCurrentScreenIndex() + 1);
            return true;
        }
        return super.dispatchUnhandledMove(focused, direction);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void addFocusables(ArrayList<View> views, int direction, int focusableMode) {
        if (this.mLauncher.isDrawerDown() && !this.mLeapController.isLeapMode() && !this.mEditing) {
            Folder openFolder = getOpenFolder();
            if (openFolder == null) {
                getChildAt(this.mCurrentScreen).addFocusables(views, direction);
                if (direction == 17) {
                    if (this.mCurrentScreen > 0) {
                        getChildAt(this.mCurrentScreen - 1).addFocusables(views, direction);
                        return;
                    }
                    return;
                } else {
                    if (direction == 66 && this.mCurrentScreen < getChildCount() - 1) {
                        getChildAt(this.mCurrentScreen + 1).addFocusables(views, direction);
                        return;
                    }
                    return;
                }
            }
            openFolder.addFocusables(views, direction);
        }
    }

    void enableScroll(boolean enable) {
        this.mCanScroll = enable;
        if (!enable) {
            clearChildrenCache();
        }
    }

    public boolean isValidCellInfo(CellInfo cellInfo) {
        return getScreenAt(0).isValidCellInfo(this.mLastMotionX, this.mLastMotionY, cellInfo);
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        if (this.mLocked || !this.mLauncher.isDrawerDown() || this.mLauncher.isOnOrientationChange() || this.mLauncher.isOnConfigurationChanged()) {
            return true;
        }
        if (DEBUG_TOUCH) {
            Log.v(LOG_TAG, "intercept touch:" + ev);
        }
        if (localLOGD) {
            Profiler.stop(true, "First Input: ");
        }
        if (this.mLeapController.isHandleMotionEvent(ev)) {
            return true;
        }
        int action = ev.getAction();
        if (action == 2 && this.mTouchState != 0) {
            return true;
        }
        float x = ev.getX();
        float y = ev.getY();
        switch (action) {
            case 0:
                if (this.mLauncher != null) {
                    this.mLauncher.stop3DAnimation(true);
                }
                this.mStartX = x;
                this.mLastMotionX = x;
                this.mLastMotionY = y;
                if (!isDoingScroll()) {
                    setAllowLongPress(true);
                }
                this.mCurrentTouchScreen = getCurrentScreenIndexByScrollX();
                this.mTouchState = this.mSlideController.isSlideFinish() ? 0 : 1;
                if (this.mTouchState == 0) {
                    try {
                        drawScreens(this.mCurrentScreen);
                    } catch (NullPointerException e) {
                        if (localLOGD) {
                            Log.v(LOG_TAG, "onInterceptTouchEvent(), nullpnter");
                        }
                    }
                }
                this.mLastTouchEventTime = AnimationUtils.currentAnimationTimeMillis();
                this.mScrollMonitor.onInterceptTouchEvent(action, this.mCurrentTouchScreen);
                this.mDownTime = System.currentTimeMillis();
                if (this.mVelocityTracker == null) {
                    this.mVelocityTracker = VelocityTracker.obtain();
                }
                this.mVelocityTracker.addMovement(ev);
                this.mMoved = false;
                break;
            case 1:
            case 3:
                this.mScrollMonitor.onInterceptTouchEvent(action, 0);
                if (this.mTouchState != 1) {
                    CellLayout currentScreen = (CellLayout) getChildAt(this.mCurrentScreen);
                    if (!currentScreen.lastDownOnOccupiedCell()) {
                        this.mWallpaperManager.sendWallpaperCommand(getWindowToken(), "android.wallpaper.tap", (int) ev.getX(), (int) ev.getY(), 0, null);
                    }
                }
                this.mTouchState = 0;
                this.mAllowLongPress = false;
                if (this.mVelocityTracker != null) {
                    this.mVelocityTracker.recycle();
                    this.mVelocityTracker = null;
                }
                if (action == 1 && System.currentTimeMillis() - this.mDownTime <= ViewConfiguration.getLongPressTimeout() && !this.mMoved) {
                    onTap(ev);
                }
                this.mMoved = false;
                break;
            case 2:
                if (this.mVelocityTracker == null) {
                    this.mVelocityTracker = VelocityTracker.obtain();
                }
                this.mVelocityTracker.addMovement(ev);
                int xDiff = (int) Math.abs(x - this.mLastMotionX);
                int yDiff = (int) Math.abs(y - this.mLastMotionY);
                int touchSlop = SettingUtil.sTouchSlop;
                boolean xMoved = xDiff >= touchSlop;
                boolean yMoved = yDiff >= touchSlop;
                if (xMoved || yMoved) {
                    this.mMoved = true;
                    if (xMoved && yDiff * SettingUtil.sWorkspaceScrollDegree < xDiff && this.mCanScroll) {
                        this.mTouchState = 1;
                        if (DEBUG_TOUCH) {
                            Log.v(LOG_TAG, "intercept touch:begin scroll");
                        }
                        beginScroll(false, this.mCurrentScreen);
                    }
                    if (this.mAllowLongPress) {
                        setAllowLongPress(false);
                        getChildAt(this.mCurrentScreen).cancelLongPress();
                    }
                } else {
                    this.mScrollMonitor.onInterceptTouchEvent(action, xDiff);
                }
                this.mLastTouchEventTime = AnimationUtils.currentAnimationTimeMillis();
                break;
        }
        return this.mTouchState != 0;
    }

    void onTap(MotionEvent ev) {
        if (!isPortrait()) {
            int leftPadding = this.mLauncher.getResources().getDimensionPixelSize(R.dimen.workspace_screen_cl_long_axis_start_padding);
            int rightPadding = this.mLauncher.getResources().getDimensionPixelSize(R.dimen.workspace_screen_cl_long_axis_end_padding);
            int bottomPadding = this.mLauncher.getResources().getDimensionPixelSize(R.dimen.launcher_control_height);
            if (ev.getY() < getHeight() - bottomPadding) {
                if (ev.getX() < leftPadding) {
                    scrollLeft();
                    return;
                }
                if (ev.getX() > getWidth() - rightPadding) {
                    scrollRight();
                    return;
                }
                FxScreen screen = this.mLauncher.getFxWorkspace().getScreen(this.mCurrentScreen);
                if (screen != null) {
                    if (screen.isEmpty()) {
                        this.mLauncher.onClickAddtoHome(null);
                        return;
                    }
                    return;
                }
                Log.e(LOG_TAG, "screen not found: " + this.mCurrentScreen);
            }
        }
    }

    void beginFling() {
        if (!isDoingFling()) {
            setDoingFling(true);
            Iterator i$ = this.mScrollStateChangedListeners.iterator();
            while (i$.hasNext()) {
                OnScrollStateChangedListener l = i$.next();
                l.onBeginFling();
            }
        }
    }

    private void endFling() {
        if (isDoingFling()) {
            setDoingFling(false);
            setDoingScroll(false);
            Iterator i$ = this.mScrollStateChangedListeners.iterator();
            while (i$.hasNext()) {
                OnScrollStateChangedListener l = i$.next();
                l.onEndScroll();
            }
        }
    }

    void beginScroll(boolean isSnap, int dest) {
        if (!isDoingScroll()) {
            if (localLOGD) {
                Log.d("Scroll", "BEGIN");
            }
            this.mLauncher.setBackgroundTrafficLight(false);
            this.mScrollMonitor.startOfBeginScroll();
            setDoingScroll(true);
            PendingUIUpdate.instance().beginScroll();
            removeCallbacks(this.mResumeAppWidgets);
            Launcher.sDefaultAppWidgetHost.stopListening();
            removeCallbacks(this.mNotifyScrollEnded);
            this.mLauncher.mWidgetsManager.fireVisible(-1);
            this.mLauncher.raisePriority(true);
            Iterator i$ = this.mScrollStateChangedListeners.iterator();
            while (i$.hasNext()) {
                OnScrollStateChangedListener l = i$.next();
                l.onBeginScroll(isSnap, this.mCurrentScreen, dest);
            }
            this.mLeapController.setTouchEventHolder(1);
            this.mScrollMonitor.endOfBeginScroll(this.mScrollX);
            View focusedChild = getFocusedChild();
            if (focusedChild != null && focusedChild == getChildAt(this.mCurrentScreen)) {
                focusedChild.clearFocus();
            }
        }
    }

    public void updateSnapInfo(int endScreen, int snapOffset) {
        Iterator i$ = this.mScrollStateChangedListeners.iterator();
        while (i$.hasNext()) {
            OnScrollStateChangedListener l = i$.next();
            l.updateSnapInfo(endScreen, snapOffset);
        }
    }

    void endScroll() {
        if (isDoingScroll()) {
            this.mScrollMonitor.end();
            PendingUIUpdate.instance().endScroll();
            removeCallbacks(this.mResumeAppWidgets);
            postDelayed(this.mResumeAppWidgets, APP_WIDGET_RESUME_DELAY);
            setDoingFling(false);
            setDoingScroll(false);
            this.isScrolling = false;
            removeCallbacks(this.mNotifyScrollEnded);
            postDelayed(this.mNotifyScrollEnded, 1000L);
            if (this.mTouchState == 0 && !this.mEditing) {
                this.mLauncher.mWidgetsManager.fireVisible(this.mCurrentScreen);
            }
            this.mLeapController.setTouchEventHolder(0);
            if (this.mScrollStateChangedListeners != null) {
                Iterator i$ = this.mScrollStateChangedListeners.iterator();
                while (i$.hasNext()) {
                    OnScrollStateChangedListener listener = i$.next();
                    listener.onEndScroll();
                }
            }
            if (this.mEditing) {
                showDragHint(true);
                CellLayout currentScreen = (CellLayout) getChildAt(getCurrentScreenIndexByScrollX());
                if (currentScreen != null && this.mDragInfo != null) {
                    currentScreen.rearrange(this.mDraggeeItem, this.mDragOverX, this.mDragOverY, this.mDragInfo.spanX, this.mDragInfo.spanY);
                }
            }
            if (localLOGD) {
                Log.d("Scroll", "END");
            }
            if (this.mIsNeedDropBack && this.mDragInfo != null) {
                CellLayout cellLayout = (CellLayout) getChildAt(this.mDragInfo.screen);
                cellLayout.onDropAborted(this.mDragInfo.item);
                if (localLOGD) {
                    Logger.d(LOG_TAG, "[EDIT_DEBUG] Workspace.endScroll() - dropBack");
                }
                dropBack();
            }
            invalidate();
        }
    }

    void enableChildrenCache() {
        if (!hasCache) {
            hasCache = true;
            if (localLOGD) {
                Log.d("Children Cache", "enable");
            }
            getChildCount();
        }
    }

    void clearChildrenCache() {
        if (hasCache) {
            hasCache = false;
            if (localLOGD) {
                Log.d("Children Cache", "clear");
            }
        }
    }

    void buildChildrenCache() {
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00fd  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public boolean onTouchEvent(MotionEvent ev) {
        if (this.mLocked || !this.mLauncher.isDrawerDown()) {
            return true;
        }
        if (this.mLeapController.isHandleMotionEvent(ev)) {
            return true;
        }
        if (DEBUG_TOUCH) {
            Log.d(LOG_TAG, "scrolling: " + (this.mTouchState != 0) + ", touch:" + ev);
        }
        if (this.mTouchState == 0) {
            return false;
        }
        this.mLauncher.checkButtonBar();
        if (this.mVelocityTracker == null) {
            this.mVelocityTracker = VelocityTracker.obtain();
        }
        this.mVelocityTracker.addMovement(ev);
        int action = ev.getAction();
        float x = ev.getX();
        switch (action) {
            case 0:
                if (!this.mSlideController.isSlideFinish()) {
                    this.mSlideController.stopSlide();
                    this.mSlideController.actionDown(ev);
                }
                this.mStartX = x;
                this.mLastMotionX = x;
                this.mLastTouchEventTime = AnimationUtils.currentAnimationTimeMillis();
                this.mCurrentScreen = getCurrentScreenIndexByScrollX();
                sendCurrentScreenIndexInfo();
                break;
            case 1:
                if (this.mTouchState == 1) {
                    VelocityTracker velocityTracker = this.mVelocityTracker;
                    velocityTracker.computeCurrentVelocity(LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK);
                    int velocityX = (int) velocityTracker.getXVelocity();
                    float deltaX = x - this.mStartX;
                    if (Math.abs(deltaX) > SettingUtil.sTouchSlop * 2 && Math.abs(velocityX) > SettingUtil.sDragSensitive) {
                        if (velocityX >= 1000 || velocityX <= 0) {
                            if (velocityX <= -1000 || velocityX >= 0) {
                                this.mSlideController.snapScreen(this.mCurrentTouchScreen, velocityX);
                            } else if (deltaX < 0.0f || velocityX < -600) {
                                if (SettingUtil.sFixedScrollVelocity) {
                                    this.mSlideController.snapScreen(this.mCurrentTouchScreen, velocityX);
                                } else {
                                    this.mSlideController.snapScreen(this.mCurrentTouchScreen, (int) ((-1000.0f) / sScrollSpeedScale));
                                }
                            } else {
                                this.mSlideController.snapToDestination();
                            }
                        } else if (deltaX > 0.0f || velocityX > 600) {
                            if (SettingUtil.sFixedScrollVelocity) {
                                this.mSlideController.snapScreen(this.mCurrentTouchScreen, velocityX);
                            } else {
                                this.mSlideController.snapScreen(this.mCurrentTouchScreen, (int) (1000.0f / sScrollSpeedScale));
                            }
                        } else {
                            this.mSlideController.snapToDestination();
                        }
                    } else {
                        this.mSlideController.snapToDestination();
                    }
                    this.mScrollMonitor.onTouchEvent(1, velocityX, (int) deltaX);
                    if (this.mVelocityTracker != null) {
                        this.mVelocityTracker.recycle();
                        this.mVelocityTracker = null;
                    }
                }
                this.mTouchState = 0;
                break;
            case 2:
                if (this.mTouchState == 1) {
                    if (!this.isScrolling) {
                        if (x > this.mLastMotionX) {
                            this.mLastMotionX = Math.min(x, this.mLastMotionX + SettingUtil.sTouchSlop);
                        } else if (x < this.mLastMotionX) {
                            this.mLastMotionX = Math.max(x, this.mLastMotionX - SettingUtil.sTouchSlop);
                        }
                        this.isScrolling = true;
                    }
                    float deltaX2 = this.mLastMotionX - x;
                    this.mLastMotionX -= deltaX2;
                    this.mSlideController.slideBy(deltaX2, this.mScrollX, isPortrait());
                    this.mScrollMonitor.onTouchEvent(2, (int) ((this.mScrollX + deltaX2) - this.mStartX), 0);
                    updateWallpaperOffset();
                    this.mLastTouchEventTime = AnimationUtils.currentAnimationTimeMillis();
                    break;
                }
                break;
            case 3:
                this.mScrollMonitor.onTouchEvent(3, 0, 0);
                if (this.mTouchState == 1) {
                }
                this.mTouchState = 0;
                break;
        }
        return true;
    }

    public void setDraggeeItemInfo(ItemInfo itemInfo, Draggee item) {
        this.mDraggeeItemInfo = itemInfo;
        this.mDraggeeItem = item;
    }

    void startDrag(CellInfo cellInfo) {
        Draggee cell = cellInfo.item;
        this.mDraggeeItem = cellInfo.item;
        if (cell != null) {
            this.mDraggeeItemInfo = cell.getItemInfo();
            this.mDragInfo = cellInfo;
            this.mDragInfo.screen = this.mCurrentScreen;
            Object cellItem = cell.getItem();
            if (localLOGD) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG] Workspace.startDrag() " + cell.getItemInfo());
            }
            RectF bounds = new RectF();
            if (cellItem instanceof FxItem) {
                FxItem fxItem = (FxItem) cellItem;
                ItemInfo info = cell.getItemInfo();
                if (localLOGD) {
                    Logger.d(LOG_TAG, "[EDIT_DEBUG] Workspace.startDrag() cellItem is FxItem:" + fxItem);
                }
                Screen current = getCurrentScreen();
                current.onDragChild(cell);
                current.cellToWidgetRect(info.cellX, info.cellY, info.spanX, info.spanY, bounds);
                fxItem.onBeforeDrag();
                this.mLauncher.getDesktopItemController().pauseRenderring();
                this.mLauncher.getFxWorkspace().removeItemSceneFromScreen(fxItem, info.screen);
                this.mLauncher.getDesktopItemController().startDragFxWidget(this, (FxItem) cellItem, bounds);
                return;
            }
            if (cellItem instanceof LegacyLayout) {
                if (localLOGD) {
                    Logger.d(LOG_TAG, "[EDIT_DEBUG] Workspace.startDrag() cellItem is LegacyLayout");
                }
                CellLayout group = (CellLayout) getChildAt(cell.getItemInfo().screen);
                if (group != null) {
                    if (localLOGD) {
                        Logger.d(LOG_TAG, "[EDIT_DEBUG] Workspace.startDrag() LegacyLayout()");
                    }
                    LegacyLayout legacyLayout = (LegacyLayout) cellItem;
                    FxScreen.IsOnFloating = true;
                    ItemInfo info2 = cell.getItemInfo();
                    group.cellToWidgetRect(info2.cellX, info2.cellY, info2.spanX, info2.spanY, bounds);
                    group.onDragChild(cell);
                    this.mLauncher.getDesktopItemController().pauseRenderring();
                    this.mLauncher.getFxWorkspace().removeItemSceneFromScreen(cell, cell.getItemInfo().screen);
                    this.mLauncher.getDesktopItemController().startDragAppWidget(this, legacyLayout, cell.getItemInfo(), bounds);
                }
            }
        }
    }

    @Override // android.view.View
    protected Parcelable onSaveInstanceState() {
        SavedState state = new SavedState(super.onSaveInstanceState());
        state.mPreviousLocal = getResources().getConfiguration().locale.toString().hashCode();
        if (CustomResourceUtil.getAppliedSkinPackageName() != null) {
            state.mPreviousSkin = CustomResourceUtil.getAppliedSkinPackageName().hashCode();
        }
        if (this.mSlideController.isSlideFinish()) {
            state.currentScreen = this.mCurrentScreen;
        }
        View focused = findFocus();
        if (focused != null) {
            CellLayout screen = (CellLayout) getChildAt(this.mCurrentScreen);
            int[] xy = new int[2];
            if (screen.findCellByView(xy, focused)) {
                state.focus.cellX = xy[0];
                state.focus.cellY = xy[1];
                state.focus.id = focused.getId();
            }
            focused.clearFocus();
        }
        this.localSavedState = state;
        return state;
    }

    protected void onRestoreInstanceState() {
        if (this.localSavedState != null) {
            onRestoreInstanceState(this.localSavedState);
        }
    }

    public void doNotRestoreCurrentScreen() {
        this.isRestoreCurrentPage = false;
    }

    @Override // android.view.View
    protected void onRestoreInstanceState(Parcelable state) {
        if (!(state instanceof SavedState)) {
            super.onRestoreInstanceState(state);
            return;
        }
        SavedState savedState = (SavedState) state;
        super.onRestoreInstanceState(savedState.getSuperState());
        int screen = this.mCurrentScreen;
        if (savedState.mPreviousLocal != -1 && savedState.mPreviousLocal != getResources().getConfiguration().locale.toString().hashCode()) {
            this.isRestoreCurrentPage = false;
            this.mCurrentScreen = getDefaultScreenIndex();
        } else if (savedState.mPreviousSkin != -1 && savedState.mPreviousSkin != CustomResourceUtil.getAppliedSkinPackageName().hashCode()) {
            this.isRestoreCurrentPage = false;
            this.mCurrentScreen = getDefaultScreenIndex();
        }
        if (savedState.currentScreen != -1) {
            if (this.isRestoreCurrentPage) {
                this.mCurrentScreen = savedState.currentScreen;
            } else {
                this.isRestoreCurrentPage = true;
            }
            if (screen != this.mCurrentScreen && !this.mLeapController.isLeapMode()) {
                setCurrentScreen(this.mCurrentScreen);
                updateWallpaperOffset();
            }
            Launcher.setScreen(this.mCurrentScreen);
            savedState.currentScreen = -1;
        }
        this.mFocus = savedState.focus;
    }

    boolean restoreFocus() {
        CellLayout screen;
        if (this.mFocus != null && (screen = (CellLayout) getChildAt(this.mCurrentScreen)) != null && screen.restoreFocus(this.mFocus.cellX, this.mFocus.cellY, this.mFocus.id)) {
            this.mFocus = null;
            return true;
        }
        return false;
    }

    void addApplicationShortcut(ApplicationInfo info, CellInfo cellInfo) {
        addApplicationShortcut(info, cellInfo, false);
    }

    void addApplicationShortcut(ApplicationInfo info, CellInfo cellInfo, boolean insertAtFirst) {
        Screen screen = getScreenAt(cellInfo.screen);
        int[] result = new int[2];
        screen.cellToPoint(cellInfo.cellX, cellInfo.cellY, result);
        onDropExternal(result[0], result[1], info, screen, insertAtFirst);
    }

    void addApplicationShortcutByCellXY(ApplicationInfo info, CellInfo cellInfo, boolean insertAtFirst) {
        Screen screen = getScreenAt(cellInfo.screen);
        onDropExternal(cellInfo.cellX, cellInfo.cellY, info, screen, insertAtFirst);
    }

    @Override // com.htc.launcher.DropTarget
    public void onDrop(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] Worksapce.onDrop()");
        }
        if (dragItem != null && checkAndaddIntoFolder(dragItem.getItemInfo())) {
            if (localLOGD) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG] Worksapce.onDrop() - checkAndaddIntoFolder() success!");
                return;
            }
            return;
        }
        int dropScreen = getCurrentScreenIndexByScrollX();
        Screen screen = getScreenAt(dropScreen);
        if (source != this) {
            if (localLOGD) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG]# Worksapce.onDrop() source != this, onDropExternal()");
            }
            onDropExternal(x - xOffset, y - yOffset, dragItem.getItemInfo(), screen);
        } else {
            if (localLOGD) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG]# Worksapce.onDrop() source = this, dropMove()");
            }
            if (this.mDragInfo != null && this.mDragInfo.item != null) {
                ItemInfo info = this.mDragInfo.item.getItemInfo();
                int[] dropXY = new int[2];
                screen.pointToDropCell(x - xOffset, y - yOffset, info.spanX, info.spanY, dropXY);
                dropMove(dropScreen, x - xOffset, y - yOffset, dropXY[0], dropXY[1]);
            } else {
                return;
            }
        }
        writeRearrengeItemsToDataBase(dropScreen, x - xOffset, y - yOffset);
        for (int i = 0; i < getChildCount(); i++) {
            Screen tmpScreen = getScreenAt(i);
            tmpScreen.onEndDrag();
        }
    }

    private boolean checkAndaddIntoFolder(ItemInfo info) {
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG]# Worksapce.onDrop() addIntoFolder() ItemInfo:" + info);
        }
        int itemType = info.itemType;
        if (itemType != 0 && itemType != 1) {
            if (localLOGD) {
                Logger.i(LOG_TAG, "onDrop() addIntoFolder() item type not matched");
            }
            return false;
        }
        int screenIndex = getCurrentScreenIndexByScrollX();
        Screen screen = getScreenAt(screenIndex);
        if (screen == null) {
            Logger.e(LOG_TAG, "onDrop() screen is empty");
            return false;
        }
        Folder folder = screen.getOpenFolder();
        if (folder == null || !(folder instanceof UserFolder)) {
            if (localLOGD) {
                Logger.d(LOG_TAG, "onDrop() folder is " + folder);
            }
            return false;
        }
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG]# Workspace.checkAndaddIntoFolder() poofLegacyItem()");
        }
        if (info instanceof ApplicationInfo) {
            this.mLauncher.getDesktopItemController().poofFxItem();
        } else {
            this.mLauncher.getDesktopItemController().poofLegacyItem();
            if (this.mDraggeeItem != null) {
                LegacyLayout legacyLayout = (LegacyLayout) this.mDraggeeItem.getItem();
                View widgetView = legacyLayout.getTheView();
                legacyLayout.removeAllViews();
                this.mLauncher.getDesktopItemController().removeLegacyWidget(widgetView, this.mDraggeeItem.getItemInfo());
                legacyLayout.fxDetach();
                CellLayout group = (CellLayout) getChildAt(this.mDraggeeItem.getItemInfo().screen);
                if (group != null) {
                    group.removeView(legacyLayout);
                }
            }
        }
        UserFolder userFolder = (UserFolder) folder;
        userFolder.addIntoFolder((ApplicationInfo) info);
        resetDragInfo();
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG]# Worksapce.onDrop() addIntoFolder() - done!");
        }
        return true;
    }

    private void writeRearrengeItemsToDataBase(int toScreen, int x, int y) {
        Screen targetScreen = getScreenAt(toScreen);
        int dropScreen = getCurrentScreenIndexByScrollX();
        this.mRearrangedDraggee.clear();
        ArrayList<Draggee> listDraggee = targetScreen.getRearrangeItems();
        Iterator i$ = listDraggee.iterator();
        while (i$.hasNext()) {
            Draggee drag = i$.next();
            drag.getItemInfo();
            Point p = drag.getCellXY();
            this.mLauncher.getDesktopItemController().moveRearrangedItem(drag, dropScreen, p.x, p.y, false);
            this.mRearrangedDraggee.add(drag);
        }
        postDelayed(new WriteRearrangedItemToDatabase(dropScreen), 100L);
    }

    class WriteRearrangedItemToDatabase implements Runnable {
        private int mDropScreen;

        WriteRearrangedItemToDatabase(int dropScreen) {
            this.mDropScreen = dropScreen;
        }

        @Override // java.lang.Runnable
        public void run() {
            Screen targetScreen = Workspace.this.getScreenAt(this.mDropScreen);
            int size = Workspace.this.mRearrangedDraggee.size();
            Draggee[] draggees = new Draggee[size];
            int[] cellXs = new int[size];
            int[] cellYs = new int[size];
            for (int i = 0; i < size; i++) {
                Draggee drag = (Draggee) Workspace.this.mRearrangedDraggee.get(i);
                ItemInfo info = drag.getItemInfo();
                Point p = drag.getCellXY();
                draggees[i] = drag;
                cellXs[i] = p.x;
                cellYs[i] = p.y;
                targetScreen.onDropChildByCell(drag, p.x, p.y, info.spanX, info.spanY);
                LauncherModel.moveItemInDatabase(Workspace.this.mLauncher, drag.getItemInfo(), -100L, this.mDropScreen, p.x, p.y);
            }
        }
    }

    private void moveItem(Draggee item, int fromScreen, int toScreen, int x, int y) {
        Screen source = getScreenAt(fromScreen);
        Screen target = getScreenAt(toScreen);
        ItemInfo info = item.getItemInfo();
        int[] dropXY = new int[2];
        source.pointToDropCell(x, y, info.spanX, info.spanY, dropXY);
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG]# Worksapce.moveItem() from:" + fromScreen + " to:" + toScreen + " cellX:" + dropXY[0] + " cellY:" + dropXY[1] + " - enter");
        }
        this.mLauncher.mFxWorkspace.resumeItemInScreen(item, fromScreen, toScreen, dropXY[0], dropXY[1]);
        if (toScreen != fromScreen && (((item instanceof FxItem) || (item instanceof Draggee.LegacyDraggee)) && (item.getItem() instanceof View))) {
            moveLegacyItem(item, fromScreen, toScreen);
        }
        target.onDropChild(item, x, y, this.mDragInfo.spanX, this.mDragInfo.spanY);
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG]# Worksapce.moveItem() - done");
        }
    }

    public void moveLegacyItem(Draggee item, int from, int to) {
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG]# Worksapce.moveLegacyItem() from:" + from + " to:" + to);
        }
        CellLayout source = (CellLayout) getChildAt(from);
        CellLayout target = (CellLayout) getChildAt(to);
        source.removeView((View) item.getItem());
        target.addView((View) item.getItem());
    }

    void showDragHint(boolean show) {
        if (!show) {
            ((DragLayer) this.mParent).showDragHint(show);
            return;
        }
        Screen screen = getScreenAt(getCurrentScreenIndexByScrollX());
        if (screen.hasRearrangedVacant()) {
            ((DragLayer) this.mParent).setDragHintMessage(R.string.drag_hint_with_setting_mode);
        } else {
            ((DragLayer) this.mParent).setDragHintMessage(R.string.drag_hint_without_space);
        }
        if (SettingUtil.isTabletDevice()) {
            boolean haveVacantCell = false;
            int i = 0;
            while (true) {
                if (i >= SettingUtil.getScreenCount()) {
                    break;
                }
                Screen screen2 = getScreenAt(i);
                if (screen2 == null || !screen2.hasRearrangedVacant()) {
                    i++;
                } else {
                    haveVacantCell = true;
                    break;
                }
            }
            ((DragLayer) this.mParent).setLeftArrowEnable(haveVacantCell);
            ((DragLayer) this.mParent).setRightArrowEnable(haveVacantCell);
        } else {
            ((DragLayer) this.mParent).setLeftArrowEnable(false);
            ((DragLayer) this.mParent).setRightArrowEnable(false);
            int i2 = 0;
            while (true) {
                if (i2 >= this.mCurrentScreen) {
                    break;
                }
                Screen screen3 = getScreenAt(i2);
                if (screen3 == null || !screen3.hasVacant()) {
                    i2++;
                } else {
                    ((DragLayer) this.mParent).setLeftArrowEnable(true);
                    break;
                }
            }
            int i3 = this.mCurrentScreen + 1;
            while (true) {
                if (i3 >= getChildCount()) {
                    break;
                }
                View temp = getChildAt(i3);
                if (temp instanceof CellLayout) {
                    Screen screen4 = (CellLayout) temp;
                    if (screen4.hasVacant()) {
                        ((DragLayer) this.mParent).setRightArrowEnable(true);
                        break;
                    }
                }
                i3++;
            }
        }
        ((DragLayer) this.mParent).showDragHint(show);
    }

    public void enterEditMode(Object dragInfo, DragSource source) {
        int spanX;
        int spanY;
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] Workspace.enterEditMode()");
        }
        if (!this.mEditing) {
            this.mEditing = true;
            post(new Runnable() { // from class: com.htc.launcher.Workspace.3
                @Override // java.lang.Runnable
                public void run() {
                    Workspace.this.setDescendantFocusability(393216);
                }
            });
            CellLayout screen = (CellLayout) getChildAt(getCurrentScreenIndexByScrollX());
            this.mLauncher.mWidgetsManager.fireVisible(-1);
            if (!isAlwaysDrawnWithCacheEnabled()) {
                setAlwaysDrawnWithCacheEnabled(true);
            }
            if (!screen.isVacantVisible()) {
                int cellX = -1;
                int cellY = -1;
                if (this.mDragInfo == null) {
                    ItemInfo info = (ItemInfo) dragInfo;
                    if (info.container == -100) {
                        cellX = info.cellX;
                    }
                    cellY = info.cellY;
                    spanX = info.spanX;
                    spanY = info.spanY;
                } else {
                    spanX = this.mDragInfo.spanX;
                    spanY = this.mDragInfo.spanY;
                }
                if (this.mUpdateVacantThread == null) {
                    this.mUpdateVacantThread = new HandlerThread("UpdateVacantThread", 10);
                    this.mUpdateVacantThread.start();
                    this.mUpdateVacantHandler = new Handler(this.mUpdateVacantThread.getLooper());
                }
                int currentScreen = getCurrentScreenIndexByScrollX();
                long start = System.currentTimeMillis();
                for (int i = 0; i < getChildCount(); i++) {
                    View temp = getChildAt(i);
                    if (temp instanceof CellLayout) {
                        CellLayout screen2 = (CellLayout) temp;
                        screen2.setDragInfo(dragInfo);
                        if (i == currentScreen) {
                            if (this.mDragInfo != null && this.mDragInfo.screen == i) {
                                screen2.clearVacant();
                                screen2.updateVacant(this.mDragInfo.cellX, this.mDragInfo.cellY, spanX, spanY);
                            } else {
                                screen2.clearVacant();
                                screen2.updateVacant(cellX, cellY, spanX, spanY);
                            }
                        } else {
                            UpdateVacantRunnable r = new UpdateVacantRunnable(i, (ItemInfo) dragInfo);
                            this.mUpdateVacantHandler.post(r);
                        }
                    }
                }
                long diff = System.currentTimeMillis() - start;
                if (localLOGD) {
                    Logger.d("UpdateVacant", String.format("updateVacant cost %d", Long.valueOf(diff)));
                }
                drawScreens(this.mCurrentScreen);
                if (localLOGD) {
                    Log.v(LOG_TAG, "enterEditMode(), showDragHint(true)");
                }
                showDragHint(true);
                showStatusBar(false);
            }
        }
    }

    class UpdateVacantRunnable implements Runnable {
        ItemInfo mInfo;
        int mScreen;

        UpdateVacantRunnable(int screen, ItemInfo info) {
            this.mScreen = screen;
            this.mInfo = info;
        }

        @Override // java.lang.Runnable
        public void run() {
            Logger.d(Workspace.LOG_TAG, "updateVacant cost UpdateVacantRunnable() - enter");
            int cellX = -1;
            int cellY = -1;
            int spanX = 0;
            int spanY = 0;
            boolean isFromDrag = false;
            if (Workspace.this.mDragInfo != null) {
                synchronized (Workspace.this.mDragInfo) {
                    isFromDrag = true;
                    spanX = Workspace.this.mDragInfo.spanX;
                    spanY = Workspace.this.mDragInfo.spanY;
                    if (Workspace.this.mDragInfo.screen == this.mScreen) {
                        cellX = Workspace.this.mDragInfo.cellX;
                        cellY = Workspace.this.mDragInfo.cellY;
                    }
                }
            }
            if (!isFromDrag) {
                if (this.mInfo.container == -100) {
                    cellX = this.mInfo.cellX;
                }
                cellY = this.mInfo.cellY;
                spanX = this.mInfo.spanX;
                spanY = this.mInfo.spanY;
            }
            CellLayout screen = (CellLayout) Workspace.this.getChildAt(this.mScreen);
            screen.setDragInfo(this.mInfo);
            screen.clearVacant();
            screen.updateVacant(cellX, cellY, spanX, spanY);
            Logger.v(Workspace.LOG_TAG, "updateVacant cost UpdateVacantRunnable() - exit");
        }
    }

    public void leaveEditMode() {
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] Workspace.leaveEditMode() mEditing:" + this.mEditing);
        }
        FxScreen.IsOnFloating = false;
        if (this.mEditing) {
            this.mEditing = false;
            showDragHint(false);
            this.mLauncher.mWidgetsManager.fireVisible(this.mCurrentScreen);
            setDescendantFocusability(131072);
            if (isAlwaysDrawnWithCacheEnabled()) {
                setAlwaysDrawnWithCacheEnabled(false);
            }
            for (int i = 0; i < getChildCount(); i++) {
                View temp = getChildAt(i);
                if (temp instanceof CellLayout) {
                    CellLayout screen = (CellLayout) getChildAt(i);
                    screen.setDragInfo(null);
                    screen.onEndDrag();
                }
            }
            this.mLauncher.mWidgetsManager.fireVisible(this.mCurrentScreen);
            this.mUpdateVacantThread.quit();
            this.mUpdateVacantThread = null;
            showStatusBar(true);
            invalidateVacant();
            post(new Runnable() { // from class: com.htc.launcher.Workspace.4
                @Override // java.lang.Runnable
                public void run() {
                    Workspace.this.drawScreens(Integer.MIN_VALUE);
                }
            });
        }
    }

    private void showStatusBar(boolean show) {
        Window w = this.mLauncher.getWindow();
        WindowManager.LayoutParams wlp = w.getAttributes();
        if (show) {
            wlp.flags &= -1025;
        } else {
            wlp.flags |= 1024;
        }
        w.setAttributes(wlp);
    }

    @Override // com.htc.launcher.DropTarget
    public void onDragEnter(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        onDragOver(source, x, y, xOffset, yOffset, dragItem);
    }

    @Override // com.htc.launcher.DropTarget
    public void onDragOver(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        CellLayout currentScreen = (CellLayout) getChildAt(getCurrentScreenIndexByScrollX());
        if (currentScreen != null && currentScreen.getOpenFolder() == null) {
            ItemInfo info = dragItem.getItemInfo();
            CellInfo cellInfo = this.mDragInfo;
            int cellHSpan = 1;
            int cellVSpan = 1;
            if (cellInfo != null) {
                cellHSpan = cellInfo.spanX;
                cellVSpan = cellInfo.spanY;
            } else if (info != null) {
                cellHSpan = info.spanX;
                cellVSpan = info.spanY;
            }
            if (currentScreen != null && !this.mOnSnapToScreen) {
                currentScreen.rearrange(dragItem, x - xOffset, y - yOffset, cellHSpan, cellVSpan);
            }
            this.mDragOverX = x - xOffset;
            this.mDragOverY = y - yOffset;
        }
    }

    @Override // com.htc.launcher.DropTarget
    public void onDragExit(DragSource source, DropTarget target, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] Workspace.onDragExit() mEditing:" + this.mEditing);
        }
        if (this.mEditing) {
            CellLayout currentScreen = (CellLayout) getChildAt(getCurrentScreenIndexByScrollX());
            currentScreen.findNearestVacantCell(-1, -1, 1, 1, false);
            currentScreen.onDragExit(x - xOffset, y - yOffset, target == this);
        } else if (!$assertionsDisabled) {
            throw new AssertionError();
        }
    }

    private void onDropExternal(int x, int y, Object dragInfo, Screen screen) {
        onDropExternal(x, y, dragInfo, screen, false);
    }

    private void onDropExternal(int x, int y, Object dragInfo, Screen screen, boolean insertAtFirst) {
        ItemInfo info;
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] Workspace.onDropExternal() - enter ###########");
        }
        ItemInfo info2 = (ItemInfo) dragInfo;
        LauncherModel model = Launcher.getModel();
        if (info2.cellY == 10) {
            model.removeButtonItem(info2);
            if (SettingUtil.isDoubleShot()) {
                this.mLauncher.getFxWorkspace().getCurrentWorkspace().showMiddleBackgroundImageControls(model.getButtonBarOccupied());
            }
        }
        int dropScreen = getCurrentScreenIndexByScrollX();
        Screen target = getScreenAt(dropScreen);
        int[] cellXY = new int[2];
        if (info2 instanceof FxItemInfo) {
            if (localLOGD) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG] Workspace.onDropExternal() - drop a new FxItem");
            }
            target.pointToDropCell(x, y, info2.spanX, info2.spanY, cellXY);
            this.mLauncher.getDesktopItemController().landFxItem(dropScreen, cellXY[0], cellXY[1]);
            info = info2;
        } else {
            if (info2 instanceof FxShortcutInfo) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG] Workspace.onDropExternal() - drop a new ApplicationInfo info:" + info2);
                target.pointToDropCell(x, y, info2.spanX, info2.spanY, cellXY);
                info2.cellX = cellXY[0];
                info2.cellY = cellXY[1];
                ApplicationInfo newAppInfo = new ApplicationInfo((ApplicationInfo) info2);
                model.addDesktopItem(newAppInfo);
                LauncherModel.addOrMoveItemInDatabase(this.mLauncher, newAppInfo, -100L, dropScreen, cellXY[0], cellXY[1]);
                Logger.d(LOG_TAG, "[EDIT_DEBUG] Workspace.onDropExternal() - landFxItem info:" + info2);
                this.mLauncher.getDesktopItemController().bindFxShortcut(newAppInfo);
                return;
            }
            if (localLOGD) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG] Workspace.onDropExternal() - drop a new LegacyItem");
            }
            info = addLegacyItem(info2, target, x, y, insertAtFirst, cellXY);
        }
        model.addDesktopItem(info);
        LauncherModel.addOrMoveItemInDatabase(this.mLauncher, info, -100L, dropScreen, cellXY[0], cellXY[1]);
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] Workspace.onDropExternal() - done ###########");
        }
    }

    private ItemInfo addLegacyItem(ItemInfo info, Screen target, int x, int y, boolean insertAtFirst, int[] cellXY) {
        View view;
        switch (info.itemType) {
            case 0:
            case 1:
                if (info.container == -1) {
                    info = new ApplicationInfo((ApplicationInfo) info);
                }
                Draggee draggee = info.createItem(this.mLauncher, target.asViewGroup());
                view = (View) draggee.getItem();
                break;
            case 2:
            case 3:
                Draggee draggee2 = info.createItem(this.mLauncher, target.asViewGroup());
                view = (View) draggee2.getItem();
                break;
            default:
                if (info instanceof WidgetProxy) {
                    ((WidgetProxy) info).fireOnResume();
                }
                view = (View) this.mLauncher.getDesktopItemController().getFloatingDragge().getItem();
                if (view instanceof LegacyLayout) {
                    LegacyLayout legacyLayout = (LegacyLayout) view;
                    view = legacyLayout.getTheView();
                    legacyLayout.removeAllViews();
                    if (localLOGD) {
                        Logger.d(LOG_TAG, "[EDIT_DEBUG] Workspace.addLegacyItem() view is a LegacyLayout");
                    }
                } else if (localLOGD) {
                    Logger.d(LOG_TAG, "[EDIT_DEBUG] Workspace.addLegacyItem() view is not a LegacyLayout");
                }
                if (view != null) {
                    view.setLayoutParams(new CellLayout.LayoutParams(info.cellX, info.cellY, info.spanX, info.spanY));
                    break;
                } else {
                    throw new IllegalStateException("Unknown item type: " + info.itemType);
                }
        }
        view.setOnLongClickListener(this.mLongClickListener);
        View view2 = new LegacyLayout(this, view, view.getLayoutParams());
        Draggee item = Draggee.LegacyDraggee.wrap(view2);
        this.mLauncher.getDesktopItemController().IS_EXTERNAL_APP_ADDING = true;
        target.addItem(item, insertAtFirst ? 0 : -1);
        target.onDropChild(item, x, y, info.spanX, info.spanY);
        CellLayout.LayoutParams lp = (CellLayout.LayoutParams) view2.getLayoutParams();
        cellXY[0] = lp.cellX;
        cellXY[1] = lp.cellY;
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] Workspace.addLegacyItem() done!");
        }
        return info;
    }

    @Override // com.htc.launcher.DropTarget
    public boolean acceptDrop(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        ItemInfo info = dragItem.getItemInfo();
        CellInfo cellInfo = this.mDragInfo;
        int cellHSpan = 1;
        int cellVSpan = 1;
        if (cellInfo != null) {
            cellHSpan = cellInfo.spanX;
            cellVSpan = cellInfo.spanY;
        } else if (info != null) {
            cellHSpan = info.spanX;
            cellVSpan = info.spanY;
        }
        int screenIndex = getCurrentScreenIndexByScrollX();
        Screen screen = getScreenAt(screenIndex);
        if (acceptDropByFolder(source, x, y, xOffset, yOffset, dragItem)) {
            return true;
        }
        if (screen != null && !this.mOnSnapToScreen && screen.tryRearrangeForSpan(dragItem, x - xOffset, y - yOffset, cellHSpan, cellVSpan)) {
            return true;
        }
        return false;
    }

    @Override // com.htc.launcher.DropTarget
    public Rect estimateDropLocation(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem, Rect recycle) {
        return null;
    }

    Screen getCurrentScreen() {
        int i = getCurrentScreenIndexByScrollX();
        return getScreenAt(i);
    }

    Screen getScreenAt(int index) {
        return (Screen) getChildAt(index);
    }

    void setLauncher(Launcher launcher) {
        this.mLauncher = launcher;
    }

    public Launcher getLauncher() {
        return this.mLauncher;
    }

    @Override // com.htc.launcher.DragSource
    public void setDragger(DragController dragger) {
        this.mDragger = dragger;
    }

    @Override // com.htc.launcher.DropTarget
    public DragSource.DragCompletedAction getDragCompletedAction() {
        return DragSource.DragCompletedAction.NONE;
    }

    @Override // com.htc.launcher.DragSource
    public void onDropCompleted(DropTarget target, boolean success) {
        onDropCompleted(target, success, success ? target.getDragCompletedAction() : DragSource.DragCompletedAction.NONE);
    }

    public void onDropCompleted(DropTarget target, boolean success, DragSource.DragCompletedAction action) {
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] Workspace.onDropCompleted() success:" + success + ", action:" + action);
        }
        if (success) {
            if (target != this && this.mDragInfo != null) {
                if (action == DragSource.DragCompletedAction.SETTING) {
                    dropBack();
                } else if (action == DragSource.DragCompletedAction.REMOVE || action == DragSource.DragCompletedAction.FOLDERICON) {
                    Draggee item = this.mDragInfo.item;
                    this.mLauncher.mFxWorkspace.removeItemFromScreen(item, this.mDragInfo.screen);
                    CellLayout cellLayout = (CellLayout) getChildAt(this.mDragInfo.screen);
                    cellLayout.removeItem(item);
                    ItemInfo itemInfo = item.getItemInfo();
                    if (itemInfo != null) {
                        Launcher.getModel().removeDesktopItem(itemInfo);
                        if (action == DragSource.DragCompletedAction.REMOVE) {
                            LauncherModel.deleteItemFromDatabase(this.mLauncher, itemInfo);
                        }
                    }
                } else if (action == DragSource.DragCompletedAction.DROP_ON_BUTTONBAR) {
                    int dropIndex = this.mLauncher.mFxWorkspace.mButtonBarHandler.getButtonBarLongClickX(target.getLeft(), target.getTop());
                    if (this.mLauncher.mFxWorkspace.getIsButtonBarNull(dropIndex)) {
                        Draggee item2 = this.mDragInfo.item;
                        this.mLauncher.mFxWorkspace.removeItemFromScreen(item2, this.mDragInfo.screen);
                        CellLayout cellLayout2 = (CellLayout) getChildAt(this.mDragInfo.screen);
                        cellLayout2.removeItem(item2);
                        Launcher.getModel().removeDesktopItem(item2.getItemInfo());
                    }
                } else if (localLOGD) {
                    Logger.i(LOG_TAG, String.format("onDropCompleted with action %s", action.toString()));
                }
            }
            Launcher.getModel().outputAllDeskItems();
        } else {
            if (this.mLauncher.mFxWorkspace.mButtonBarHandler != null) {
                this.mLauncher.mFxWorkspace.mButtonBarHandler.setTargetCantDrop();
            }
            if (this.mDragInfo != null) {
                CellLayout cellLayout3 = (CellLayout) getChildAt(this.mDragInfo.screen);
                if (!scrollForDropBack()) {
                    cellLayout3.onDropAborted(this.mDragInfo.item);
                } else {
                    return;
                }
            }
        }
        if (action != DragSource.DragCompletedAction.NONE) {
            if ((this.mDraggeeItemInfo instanceof FxItemInfo) || (this.mDraggeeItemInfo instanceof FxShortcutInfo)) {
                this.mLauncher.getDesktopItemController().poofFxItem();
            } else {
                this.mLauncher.getDesktopItemController().poofLegacyItem();
            }
            resetDragInfo();
        }
    }

    public void removeDraggedAppIconAddedIntoFolderIcon() {
        if (this.mDraggeeItemInfo != null && this.mDraggeeItem != null) {
            if ((this.mDraggeeItemInfo instanceof FxItemInfo) || (this.mDraggeeItemInfo instanceof FxShortcutInfo)) {
                this.mLauncher.getDesktopItemController().poofFxItem();
                this.mLauncher.getDesktopItemController().removeItem(this, this.mDraggeeItemInfo);
            } else {
                this.mLauncher.getDesktopItemController().poofLegacyItem();
            }
            if (this.mDraggeeItem != null && (this.mDraggeeItem.getItem() instanceof LegacyLayout)) {
                LegacyLayout legacyLayout = (LegacyLayout) this.mDraggeeItem.getItem();
                View widgetView = legacyLayout.getTheView();
                legacyLayout.fxDetach();
                this.mLauncher.getDesktopItemController().removeLegacyWidget(widgetView, this.mDraggeeItem.getItemInfo());
                CellLayout group = (CellLayout) getChildAt(this.mDraggeeItem.getItemInfo().screen);
                if (group != null) {
                    group.removeView(legacyLayout);
                }
                resetDragInfo();
            }
        }
    }

    @Override // com.htc.launcher.DragScroller
    public void scrollLeft() {
        if (this.mSlideController.scrollLeft()) {
            getCurrentScreen().onDragExit(0, 0, false);
            this.mOnSnapToScreen = true;
        }
    }

    @Override // com.htc.launcher.DragScroller
    public void scrollRight() {
        if (this.mSlideController.scrollRight()) {
            getCurrentScreen().onDragExit(0, 0, false);
            this.mOnSnapToScreen = true;
        }
    }

    public int getScreenForView(View v) {
        if (v != null) {
            ViewParent vp = v.getParent();
            int count = getChildCount();
            for (int i = 0; i < count; i++) {
                if (vp == getChildAt(i)) {
                    return i;
                }
            }
        }
        return -1;
    }

    private HtcSearch findHtcSearchWidget(CellLayout screen) {
        int count = screen.getChildCount();
        for (int i = 0; i < count; i++) {
            HtcSearch childAt = screen.getChildAt(i);
            if (childAt instanceof HtcSearch) {
                return childAt;
            }
        }
        return null;
    }

    private boolean focusOnHtcSearch(int screen) {
        View temp = getChildAt(screen);
        if (!(temp instanceof CellLayout)) {
            return false;
        }
        CellLayout currentScreen = (CellLayout) temp;
        HtcSearch searchWidget = findHtcSearchWidget(currentScreen);
        if (searchWidget == null) {
            return false;
        }
        if (isInTouchMode()) {
            searchWidget.requestFocusFromTouch();
        } else {
            searchWidget.requestFocus();
        }
        searchWidget.clearQuery();
        return true;
    }

    public boolean snapToSearch() {
        int current = this.mCurrentScreen;
        int first = current;
        int last = current;
        boolean next = false;
        int count = getChildCount();
        while (!focusOnHtcSearch(current)) {
            boolean hitLast = last == count - 1;
            boolean hitFirst = first == 0;
            if (hitLast && hitFirst) {
                return false;
            }
            if (hitFirst || (next && !hitLast)) {
                last++;
                current = last;
                next = false;
            } else {
                first--;
                current = first;
                next = true;
            }
        }
        return true;
    }

    public Folder getFolderForTag(Object tag) {
        int screenCount = getChildCount();
        for (int screen = 0; screen < screenCount; screen++) {
            View temp = getChildAt(screen);
            if (temp instanceof CellLayout) {
                CellLayout currentScreen = (CellLayout) temp;
                int count = currentScreen.getChildCount();
                for (int i = 0; i < count; i++) {
                    View child = currentScreen.getChildAt(i);
                    CellLayout.LayoutParams lp = (CellLayout.LayoutParams) child.getLayoutParams();
                    if (lp.cellHSpan == 4 && lp.cellVSpan == 4 && (child instanceof Folder)) {
                        Folder f = (Folder) child;
                        if (f.getInfo() == tag) {
                            return f;
                        }
                    }
                }
            }
        }
        return null;
    }

    public View getViewForTag(Object tag) {
        int screenCount = getChildCount();
        for (int screen = 0; screen < screenCount; screen++) {
            View temp = getChildAt(screen);
            if (temp instanceof CellLayout) {
                CellLayout currentScreen = (CellLayout) temp;
                int count = currentScreen.getChildCount();
                for (int i = 0; i < count; i++) {
                    View child = currentScreen.getChildAt(i);
                    if (child.getTag() == tag) {
                        return child;
                    }
                }
            }
        }
        return null;
    }

    public void unlock() {
        this.mLocked = false;
    }

    public void lock() {
        this.mLocked = true;
    }

    public boolean allowLongPress() {
        return this.mAllowLongPress;
    }

    void setAllowLongPress(boolean allowLongPress) {
        this.mAllowLongPress = allowLongPress;
    }

    void removeShortcutsForPackage(String packageName) {
        ArrayList<View> childrenToRemove = new ArrayList<>();
        LauncherModel model = Launcher.getModel();
        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            View temp = getChildAt(i);
            if (temp instanceof CellLayout) {
                CellLayout layout = (CellLayout) temp;
                int childCount = layout.getChildCount();
                childrenToRemove.clear();
                for (int j = 0; j < childCount; j++) {
                    View view = layout.getChildAt(j);
                    Object tag = view.getTag();
                    if (tag instanceof LauncherAppWidgetInfo) {
                        LauncherAppWidgetInfo info = (LauncherAppWidgetInfo) tag;
                        String appWidgeName = info.appWidgetComponent.getPackageName();
                        if (appWidgeName != null && packageName.equals(appWidgeName)) {
                            this.mLauncher.getFxWorkspace().removeItemFromScreen(info.screen, (int) info.id);
                            model.removeDesktopItem(info);
                            LauncherModel.deleteItemFromDatabase(this.mLauncher, info);
                            childrenToRemove.add(view);
                        }
                    } else if (tag instanceof ApplicationInfo) {
                        ApplicationInfo info2 = (ApplicationInfo) tag;
                        Intent intent = info2.intent;
                        ComponentName name = intent.getComponent();
                        if (name != null && packageName.equals(name.getPackageName())) {
                            this.mLauncher.getFxWorkspace().removeItemFromScreen(info2.screen, (int) info2.id);
                            model.removeDesktopItem(info2);
                            LauncherModel.deleteItemFromDatabase(this.mLauncher, info2);
                            childrenToRemove.add(view);
                        }
                    }
                }
                int childCount2 = childrenToRemove.size();
                for (int j2 = 0; j2 < childCount2; j2++) {
                    layout.removeViewInLayout(childrenToRemove.get(j2));
                }
                if (childCount2 > 0) {
                    layout.requestLayout();
                    layout.invalidate();
                }
            }
        }
        this.mLauncher.getDesktopItemController().removeShortcutsForPackage(packageName);
        ArrayList<ApplicationInfo> appInfo = this.mLauncher.getFxWorkspace().removeButtonBarShortcut(packageName);
        if (appInfo != null) {
            for (int index = 0; index < appInfo.size(); index++) {
                model.removeButtonItem(appInfo.get(index));
                LauncherModel.deleteItemFromDatabase(this.mLauncher, appInfo.get(index));
            }
            if (SettingUtil.isDoubleShot()) {
                this.mLauncher.getFxWorkspace().getCurrentWorkspace().showMiddleBackgroundImageControls(model.getButtonBarOccupied());
            }
        }
    }

    void updateApplicationIconForPackage(String packageName) {
        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            View temp = getChildAt(i);
            if (temp instanceof CellLayout) {
                CellLayout layout = (CellLayout) temp;
                int childCount = layout.getChildCount();
                for (int j = 0; j < childCount; j++) {
                    final View view = layout.getChildAt(j);
                    Object tag = view.getTag();
                    if (tag instanceof ApplicationInfo) {
                        ApplicationInfo info = (ApplicationInfo) tag;
                        updateApplicationInfo(packageName, view, info);
                    } else if (tag instanceof UserFolderInfo) {
                        Iterator i$ = ((UserFolderInfo) tag).contents.iterator();
                        while (i$.hasNext()) {
                            ApplicationInfo app = i$.next();
                            updateApplicationInfo(packageName, null, app);
                        }
                    } else if ((view instanceof UserFolder) && this.mLauncher != null) {
                        this.mLauncher.runOnUiThread(new Runnable() { // from class: com.htc.launcher.Workspace.5
                            @Override // java.lang.Runnable
                            public void run() {
                                ((UserFolder) view).notifyDataSetChanged();
                            }
                        });
                    }
                }
            }
        }
        this.mLauncher.getDesktopItemController().updateShortcutsForPackage(packageName);
    }

    private void updateApplicationInfo(String packageName, View view, ApplicationInfo info) {
        Intent intent = info.intent;
        ComponentName name = intent.getComponent();
        if ((info.itemType == 0 || info.itemType == 1) && "android.intent.action.MAIN".equals(intent.getAction()) && name != null && packageName.equals(name.getPackageName())) {
            Drawable icon = Launcher.getModel().getApplicationInfoIcon(this.mLauncher.getPackageManager(), info);
            if (icon == null) {
                icon = this.mLauncher.getPackageManager().getDefaultActivityIcon();
            }
            if (icon != null && icon != info.icon) {
                if (info.icon != null) {
                    info.icon.setCallback(null);
                }
                info.icon = Utilities.createIconThumbnail(icon, this.mContext);
                info.filtered = true;
                if (view != null) {
                    if (view instanceof ViewGroup) {
                        int viewCount = ((ViewGroup) view).getChildCount();
                        for (int k = 0; k < viewCount; k++) {
                            View childView = ((ViewGroup) view).getChildAt(k);
                            if (childView instanceof TextView) {
                                ((TextView) childView).setCompoundDrawablesWithIntrinsicBounds((Drawable) null, info.icon, (Drawable) null, (Drawable) null);
                            }
                        }
                        return;
                    }
                    if (view instanceof TextView) {
                        ((TextView) view).setCompoundDrawablesWithIntrinsicBounds((Drawable) null, info.icon, (Drawable) null, (Drawable) null);
                    }
                }
            }
        }
    }

    void updateShortcutsForPackage(String packageName) {
        Drawable icon;
        Logger.d(LoggingEvents.EXTRA_CALLING_APP_NAME, "updateShortcutsForPackage(" + packageName + ")");
        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            View temp = getChildAt(i);
            if (temp instanceof CellLayout) {
                CellLayout layout = (CellLayout) temp;
                int childCount = layout.getChildCount();
                for (int j = 0; j < childCount; j++) {
                    View view = layout.getChildAt(j);
                    Object tag = view.getTag();
                    if (tag instanceof ApplicationInfo) {
                        ApplicationInfo info = (ApplicationInfo) tag;
                        Intent intent = info.intent;
                        ComponentName name = intent.getComponent();
                        if (info.itemType == 0 && "android.intent.action.MAIN".equals(intent.getAction()) && name != null && packageName.equals(name.getPackageName()) && (icon = Launcher.getModel().getApplicationInfoIcon(this.mLauncher.getPackageManager(), info)) != null && icon != info.icon) {
                            info.icon = Utilities.createIconThumbnail(icon, this.mContext);
                            if (info.icon != null) {
                                info.icon.setCallback(null);
                            }
                            info.filtered = true;
                            if (view instanceof ViewGroup) {
                                int viewCount = ((ViewGroup) view).getChildCount();
                                for (int k = 0; k < viewCount; k++) {
                                    View childView = ((ViewGroup) view).getChildAt(k);
                                    if (childView instanceof TextView) {
                                        ((TextView) childView).setCompoundDrawablesWithIntrinsicBounds((Drawable) null, info.icon, (Drawable) null, (Drawable) null);
                                    }
                                }
                            } else if (view instanceof TextView) {
                                ((TextView) view).setCompoundDrawablesWithIntrinsicBounds((Drawable) null, info.icon, (Drawable) null, (Drawable) null);
                            }
                        }
                    }
                }
            }
        }
        this.mLauncher.getDesktopItemController().updateShortcutsForPackage(packageName);
    }

    int moveToDefaultScreen() {
        int duration = this.mSlideController.snapToDefaultScreen(getDefaultScreenIndex());
        getChildAt(getDefaultScreenIndex()).requestFocus();
        return duration;
    }

    private static class FocusState {
        int cellX;
        int cellY;
        int id;

        private FocusState() {
            this.cellX = -1;
            this.cellY = -1;
            this.id = -1;
        }
    }

    public static class SavedState extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>() { // from class: com.htc.launcher.Workspace.SavedState.1
            /* JADX WARN: Can't rename method to resolve collision */
            @Override // android.os.Parcelable.Creator
            public SavedState createFromParcel(Parcel in) {
                return new SavedState(in);
            }

            /* JADX WARN: Can't rename method to resolve collision */
            @Override // android.os.Parcelable.Creator
            public SavedState[] newArray(int size) {
                return new SavedState[size];
            }
        };
        int currentScreen;
        FocusState focus;
        int mPreviousLocal;
        int mPreviousSkin;

        SavedState(Parcelable superState) {
            super(superState);
            this.currentScreen = -1;
            this.mPreviousLocal = -1;
            this.mPreviousSkin = -1;
            this.focus = new FocusState();
        }

        private SavedState(Parcel in) {
            super(in);
            this.currentScreen = -1;
            this.mPreviousLocal = -1;
            this.mPreviousSkin = -1;
            this.focus = new FocusState();
            this.currentScreen = in.readInt();
            this.mPreviousLocal = in.readInt();
            this.mPreviousSkin = in.readInt();
            this.focus.cellX = in.readInt();
            this.focus.cellY = in.readInt();
            this.focus.id = in.readInt();
        }

        @Override // android.view.View.BaseSavedState, android.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel out, int flags) {
            super.writeToParcel(out, flags);
            out.writeInt(this.currentScreen);
            out.writeInt(this.mPreviousLocal);
            out.writeInt(this.mPreviousSkin);
            out.writeInt(this.focus.cellX);
            out.writeInt(this.focus.cellY);
            out.writeInt(this.focus.id);
        }
    }

    int getScrollRange() {
        return getWidth() * (getChildCount() - 1);
    }

    public void onDestroy() {
        removeCallbacks(this.mNotifyScrollEnded);
        clearChildrenCache();
    }

    public void enableShowVacantRect(boolean enable) {
        this.isShowVacantRect = enable;
    }

    public void setScrollMonitor(ScrollMonitor scrollMonitor) {
        this.mScrollMonitor = scrollMonitor;
        for (int i = 0; i < getChildCount(); i++) {
            View childView = getChildAt(i);
            if (childView instanceof CellLayout) {
                ((CellLayout) childView).setScrollMonitor(this.mScrollMonitor);
            }
        }
        this.mSlideController.setScrollMonitor(this.mScrollMonitor);
    }

    public boolean isEditing() {
        return this.mEditing;
    }

    @Override // com.htc.launcher.DragController.DragListener
    public void onDragEnd() {
        Screen currentScreen = getScreenAt(getCurrentScreenIndexByScrollX());
        currentScreen.onDragExit(0, 0, false);
        leaveEditMode();
    }

    @Override // com.htc.launcher.DragController.DragListener
    public void onPreDragStart(Draggee cell, DragSource source, Object info, int dragAction) {
        enterEditMode(info, source);
    }

    @Override // com.htc.launcher.DragController.DragListener
    public void onPostDragStart(Draggee cell, DragSource source, Object info, int dragAction) {
    }

    protected CellInfo scrollToAvailableScreenForSpan(int spanX, int spanY) {
        return scrollToAvailableScreenForShortcutOrSpan(spanX, spanY, false);
    }

    protected CellInfo scrollToAvailableScreenForShortcut() {
        return scrollToAvailableScreenForShortcutOrSpan(1, 1, true);
    }

    private ArrayList<Integer> getVisitScreenForVancantList() {
        ArrayList<Integer> pageList = new ArrayList<>();
        int[] offsets = {0, -1, 1, -2, 2, -3, 3, -4, 4};
        for (int i = 0; i < SettingUtil.getScreenCount(); i++) {
            int value = this.mCurrentScreen + offsets[i];
            if (value < 0) {
                value += SettingUtil.getScreenCount();
            } else if (value >= SettingUtil.getScreenCount()) {
                value -= SettingUtil.getScreenCount();
            }
            pageList.add(Integer.valueOf(value));
        }
        return pageList;
    }

    private CellInfo scrollToAvailableScreenForShortcutOrSpan(int spanX, int spanY, boolean forShortcut) {
        int availablePage = -1;
        CellInfo.VacantCell vCell = null;
        ArrayList<Integer> visitScreenForVancantList = getVisitScreenForVancantList();
        ArrayList<CellInfo.VacantCell> cells = new ArrayList<>();
        int i = 0;
        while (true) {
            if (i >= SettingUtil.getScreenCount()) {
                break;
            }
            int screenIndex = visitScreenForVancantList.get(i).intValue();
            View temp = getChildAt(screenIndex);
            if (temp instanceof CellLayout) {
                CellLayout screen = (CellLayout) temp;
                cells.clear();
                screen.findVacantCellsForSpan(cells, spanX, spanY);
                if (cells.size() > 0) {
                    CellInfo.VacantCell vCell2 = cells.get(0);
                    vCell = vCell2;
                    availablePage = screenIndex;
                    break;
                }
            }
            i++;
        }
        final int snapPage = availablePage;
        if (availablePage >= 0) {
            postDelayed(new Runnable() { // from class: com.htc.launcher.Workspace.6
                @Override // java.lang.Runnable
                public void run() {
                    Workspace.this.mSlideController.snapToScreen(snapPage);
                }
            }, 300L);
        }
        if (vCell == null) {
            return null;
        }
        CellInfo info = new CellInfo();
        info.cellX = vCell.cellX;
        info.cellY = vCell.cellY;
        info.spanX = vCell.spanX;
        info.spanY = vCell.spanY;
        info.screen = availablePage;
        return info;
    }

    private void cancelScrollingAndFling() {
        endFling();
        MotionEvent event = MotionEvent.obtain(0L, this.mLastTouchEventTime, 3, this.mLastMotionX, this.mLastMotionY, 0);
        onTouchEvent(event);
    }

    public void updateOrientation(boolean portrait) {
        cancelScrollingAndFling();
        if (this.mLeapController.isLeapMode()) {
            this.mLeapController.leaveLeapMode();
        }
        FrameLayout.LayoutParams WorkspaceParams = (FrameLayout.LayoutParams) getLayoutParams();
        WorkspaceParams.height = -1;
        WorkspaceParams.width = -1;
        this.mFakeCellPadding = 0;
        setDoingFling(false);
        int currentChildCount = getChildCount();
        for (int i = 0; i < currentChildCount; i++) {
            View temp = getChildAt(i);
            if (temp instanceof CellLayout) {
                CellLayout currentScreen = (CellLayout) temp;
                currentScreen.updateOrientation(portrait);
            }
        }
    }

    public int getFakeCellPadding() {
        return this.mFakeCellPadding;
    }

    public void updateBubbleText(int Ori, int screen, boolean screenOnly) {
        int currentChildCount = getChildCount();
        for (int i = 0; i < currentChildCount; i++) {
            if ((!screenOnly || i == screen) && (screenOnly || i != screen)) {
                CellLayout currentScreen = (CellLayout) getChildAt(i);
                int count = currentScreen.getChildCount();
                for (int j = 0; j < count; j++) {
                    View child = currentScreen.getChildAt(j);
                    if ((child instanceof LegacyLayout) && (((LegacyLayout) child).getTheView() instanceof BubbleTextView)) {
                        BubbleTextView BTView = (BubbleTextView) ((LegacyLayout) child).getTheView();
                        BTView.OnDeskTopOrientationChanged(Ori);
                    }
                }
            }
        }
    }

    public void tempRemoveChildren() {
        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            View temp = getChildAt(i);
            if (temp instanceof CellLayout) {
                CellLayout cell = (CellLayout) temp;
                cell.tempRemoveChildren();
            }
        }
    }

    public void restoreRemovedChildren(int screen, boolean screenOnly) {
        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            if ((!screenOnly || i == screen) && (screenOnly || i != screen)) {
                View temp = getChildAt(i);
                if (temp instanceof CellLayout) {
                    CellLayout cell = (CellLayout) temp;
                    cell.restoreRemovedChildren();
                }
            }
        }
    }

    public void clearTempRemovedChildren() {
        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            View temp = getChildAt(i);
            if (temp instanceof CellLayout) {
                CellLayout cell = (CellLayout) temp;
                cell.clearTempRemovedChildren();
            }
        }
    }

    public boolean canEnableThumbnailMode() {
        return (this.mLeapController.isLeapMode() || isDoingScroll()) ? false : true;
    }

    public void removeAllViewsRecursively() {
        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            View view = getChildAt(i);
            if (view instanceof ViewGroup) {
                ((ViewGroup) view).removeAllViews();
            }
        }
        removeAllViews();
    }

    public boolean isPortrait() {
        return this.mLauncher.isPortrait();
    }

    public void onUpdateCellLayoutCache(CellLayout cellLayout) {
        if (cellLayout != null && cellLayout.equals(getChildAt(getDefaultScreenIndex())) && this.mOnHomeScreenListener != null) {
            this.mOnHomeScreenListener.onHomeScreenLayoutChanged();
        }
    }

    public void onPause() {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View temp = getChildAt(i);
            if (temp instanceof CellLayout) {
                ((CellLayout) temp).onPause();
            }
        }
    }

    public void onResume() {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View temp = getChildAt(i);
            if (temp instanceof CellLayout) {
                ((CellLayout) temp).onResume();
            }
        }
    }

    public void setOnHomeScreenListener(OnHomeScreenListener listener) {
        this.mOnHomeScreenListener = listener;
    }

    private static void setDefaultScreen(int screen) {
        SettingUtil.setDefaultScreenIndex(screen);
    }

    public static int getDefaultScreenIndex() {
        return SettingUtil.sWorkspaceDefaultScreen;
    }

    void redirectTouchTo(View.OnTouchListener receiver) {
        this.mTouchRedirect = receiver;
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchTouchEvent(MotionEvent event) {
        int action = event.getAction();
        int stateBeforeDispatch = this.mTouchState;
        boolean handled = super.dispatchTouchEvent(event);
        boolean downRedirected = this.mTouchDownRedirected;
        if (action == 1 || action == 3) {
            this.mTouchDownRedirected = false;
        }
        if (this.mTouchRedirect == null) {
            return handled;
        }
        boolean inLeap = this.mLeapController.isLeapMode();
        if (inLeap) {
            return this.mTouchRedirect.onTouch(this, event);
        }
        boolean scrolling = this.mTouchState != 0;
        if (scrolling) {
            if (stateBeforeDispatch == 0 && scrolling) {
                MotionEvent cancel = MotionEvent.obtain(event);
                cancel.setAction(3);
                this.mTouchRedirect.onTouch(this, cancel);
                if (localLOGD) {
                    Log.d(LOG_TAG, "cancel by begin scroll:" + cancel);
                }
            }
            return handled;
        }
        if (action == 3) {
            return handled;
        }
        boolean hit = false;
        View temp = getChildAt(this.mCurrentScreen);
        if (temp instanceof CellLayout) {
            CellLayout cell = (CellLayout) temp;
            hit = cell.isChildHit();
        }
        if (DEBUG_TOUCH) {
            Log.v(LOG_TAG, "handled:" + handled + ", hit:" + hit + " dispatch touch:" + event);
        }
        if (!hit) {
            handled = this.mTouchRedirect.onTouch(this, event);
            if (action == 0) {
                this.mTouchDownRedirected = true;
            }
        } else if (downRedirected && action == 1) {
            handled = this.mTouchRedirect.onTouch(this, event);
        }
        return handled;
    }

    public void setLeapController(LeapController leapController) {
        this.mLeapController = leapController;
    }

    public void setSlideController(SlideController slideController) {
        this.mSlideController = slideController;
    }

    @Override // com.htc.launcher.LeapController.LeapLayer
    public boolean canEnterLeapMode() {
        return this.mLauncher.canEnableLeapMode();
    }

    @Override // com.htc.launcher.LeapController.LeapLayer
    public int getCurrentPage() {
        return getCurrentScreenIndexByScrollX();
    }

    @Override // com.htc.launcher.LeapController.LeapLayer
    public void setCurrentPage(int currentSPage) {
        setCurrentScreen(currentSPage);
    }

    @Override // com.htc.launcher.LeapController.LeapLayer
    public int findPage(float x, float y) {
        return this.mLauncher.findPanelFromFxWorkspace(x, y);
    }

    @Override // com.htc.launcher.LeapController.LeapAnimationPlayer
    public void setZoomInAnimationProgress(int selectPage, int action, float ratio, int virtualScrollX) {
        this.mScrollX = virtualScrollX;
        updateWallpaperOffset();
    }

    @Override // com.htc.launcher.LeapController.LeapAnimationPlayer
    public void setZoomOutAnimationProgress(int selectPage, int action, float ratio, int virtualScrollX) {
    }

    public void drawAllScreens() {
        this.mIsNeedtoDrawAllScreens = true;
        invalidate();
    }

    public void registerScrollStateChangedListener(OnScrollStateChangedListener listener) {
        if (this.mScrollStateChangedListeners == null) {
            this.mScrollStateChangedListeners = new ArrayList<>();
        }
        this.mScrollStateChangedListeners.add(listener);
    }

    public void unRegisterScrollStateChangedListener(OnScrollStateChangedListener listener) {
        if (this.mScrollStateChangedListeners != null) {
            this.mScrollStateChangedListeners.remove(listener);
        }
    }

    public void setBounceScreen(int bounceScreen) {
        this.mBounceScreen = bounceScreen;
    }

    public void setNextScreen(int nextScreen) {
        this.mNextScreen = nextScreen;
    }

    public int getNextScreen() {
        return this.mNextScreen;
    }

    @Override // com.htc.launcher.DropTarget
    public boolean claimDrop(int x, int y, int[] dropCoordinates) {
        return false;
    }

    private boolean scrollToScreen(final int screen) {
        if (screen < 0) {
            return false;
        }
        postDelayed(new Runnable() { // from class: com.htc.launcher.Workspace.7
            @Override // java.lang.Runnable
            public void run() {
                Workspace.this.mSlideController.snapToScreen(screen);
            }
        }, 300L);
        return true;
    }

    public boolean scrollForDropBack() {
        boolean isSuccess;
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] Workspace.scrollForFxItemLand()");
        }
        if (this.mDraggeeItemInfo == null) {
            if (localLOGD) {
                Logger.d(LOG_TAG, "[EDIT_MODE] Workspace.scrollForFxItemLand() mDraggeeItemInfo = null, return");
            }
            return false;
        }
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG]### Workspace.scrollForFxItemLand() " + getCurrentPage() + "," + this.mDraggeeItemInfo.screen);
        }
        if (getCurrentPage() == this.mDraggeeItemInfo.screen) {
            isSuccess = dropBack();
        } else {
            this.mIsNeedDropBack = true;
            Screen currentScreen = getScreenAt(getCurrentScreenIndexByScrollX());
            currentScreen.onDragExit(0, 0, false);
            isSuccess = scrollToScreen(this.mDraggeeItemInfo.screen);
            if (!isSuccess) {
                this.mIsNeedDropBack = false;
            }
        }
        return isSuccess;
    }

    public boolean dropBack() {
        if (this.mDraggeeItemInfo == null) {
            if (localLOGD) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG]# Workspace.dropBack() - mDraggeeItemInfo = null, return!");
            }
            return false;
        }
        if ((this.mDraggeeItemInfo instanceof FxItemInfo) || (this.mDraggeeItemInfo instanceof FxShortcutInfo)) {
            this.mLauncher.getDesktopItemController().poofFxItem();
        } else {
            this.mLauncher.getDesktopItemController().poofLegacyItem();
        }
        this.mLauncher.getFxWorkspace().resumeItemInScreen(this.mDraggeeItem, this.mDraggeeItemInfo.screen, this.mDraggeeItemInfo.screen, this.mDraggeeItemInfo.cellX, this.mDraggeeItemInfo.cellY);
        this.mIsNeedDropBack = false;
        for (int i = 0; i < getChildCount(); i++) {
            Screen tmpScreen = getScreenAt(i);
            tmpScreen.onEndDrag();
        }
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG]# Workspace.dropBack() - done !!!!!!!!!!!!!!!!!!!!!!!!!");
        }
        showDrag();
        resetDragInfo();
        return true;
    }

    public void dropMove(int dropScreen, int dropX, int dropY, int cellX, int cellY) {
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG]# Workspace.dropMove(" + dropScreen + ", " + dropX + ", " + dropY + ", " + cellX + ", " + cellY + ") - enter !!!!!!");
        }
        if (this.mDraggeeItem == null) {
            if (localLOGD) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG]# dropMove(" + cellX + "," + cellY + ") mDraggee = null, return!");
                return;
            }
            return;
        }
        if (this.mDraggeeItem.getItem() == null) {
            if (localLOGD) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG]# dropMove(" + cellX + "," + cellY + ") mDraggee.getItem() = null, return!");
                return;
            }
            return;
        }
        if (this.mDraggeeItemInfo.screen == dropScreen && cellX == this.mDraggeeItemInfo.cellX && cellY == this.mDraggeeItemInfo.cellY && localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG]# dropMove(" + cellX + "," + cellY + ") same position!!");
        }
        if ((this.mDraggeeItemInfo instanceof FxItemInfo) || (this.mDraggeeItemInfo instanceof FxShortcutInfo)) {
            if (localLOGD) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG]# Workspace.dropMove() poofFxItem()");
            }
            this.mLauncher.getDesktopItemController().poofFxItem();
        } else {
            if (localLOGD) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG]# Workspace.dropMove() poofLegacyItem()");
            }
            this.mLauncher.getDesktopItemController().poofLegacyItem();
        }
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG]# Workspace.dropMove() - Before SpanX:" + this.mDraggeeItemInfo.spanX + " SpanY:" + this.mDraggeeItemInfo.spanY);
        }
        this.mLauncher.getDesktopItemController().moveFxItem(this.mDraggeeItem, dropScreen, cellX, cellY, true);
        showDrag();
        resetDragInfo();
    }

    public void showDrag() {
        if (this.mDraggeeItemInfo != null) {
            if (localLOGD) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG]# Workspace.showDrag()");
            }
            this.mLauncher.getFxWorkspace().showDrag(this.mDraggeeItemInfo);
        }
    }

    private void resetDragInfo() {
        if (!this.mIsNeedDropBack) {
            this.mDragInfo = null;
            this.mDraggeeItemInfo = null;
            this.mDraggeeItem = null;
        }
    }

    public void updateScrollValue(int x, int y) {
        this.mScrollX = x;
        this.mScrollY = y;
    }

    public void froceUpdateRemote(Canvas canvas) {
    }

    public void onLeapRearrangeComplete(int[] screenMap) {
        int childCount = getChildCount();
        View[] temp = new View[childCount];
        for (int i = 0; i < childCount; i++) {
            if (localLOGD) {
                Logger.d(LOG_TAG, "[LEAP] Leap[" + i + "]:" + screenMap[i]);
            }
            temp[i] = getChildAt(screenMap[i]);
        }
        removeAllViews();
        for (int i2 = 0; i2 < childCount; i2++) {
            addView(temp[i2]);
            temp[i2] = null;
        }
        for (int i3 = 0; i3 < childCount; i3++) {
            View childView = getChildAt(i3);
            if (childView instanceof CellLayout) {
                ((CellLayout) childView).changeScreenIndex(i3);
            }
        }
        LauncherModel.updateScreenId(this.mContext, 0, screenMap);
        if (localLOGD) {
            Logger.showMeWidget(this.mContext, "topic_tag-home_screen-rearrange_home_screens");
        }
    }

    private boolean acceptDropByFolder(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        Folder folder;
        int screenIndex = getCurrentScreenIndexByScrollX();
        Screen screen = getScreenAt(screenIndex);
        if (screen != null && (folder = screen.getOpenFolder()) != null && (folder instanceof UserFolder) && ((UserFolder) folder).acceptDrop(source, x, y, xOffset, yOffset, dragItem)) {
            return true;
        }
        return false;
    }

    private void setDoingScroll(boolean mDidScroll) {
        this.mDidScroll = mDidScroll;
    }

    boolean isDoingScroll() {
        return this.mDidScroll;
    }

    private void setDoingFling(boolean mDidfling) {
        this.mDidfling = mDidfling;
    }

    private boolean isDoingFling() {
        return this.mDidfling;
    }

    void clear() {
        clearTempRemovedChildren();
        int N = getChildCount();
        for (int i = 0; i < N; i++) {
            View child = getChildAt(i);
            if (child instanceof CellLayout) {
                ((CellLayout) child).clear();
                child.invalidate();
            } else if (localLOGD) {
                Log.w("Launcher", "removeWidgetsAndLoadUserItems: i=" + i + " child=" + child + " child.class=" + child.getClass());
            }
        }
    }
}
