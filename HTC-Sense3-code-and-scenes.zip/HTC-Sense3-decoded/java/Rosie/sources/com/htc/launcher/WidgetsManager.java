package com.htc.launcher;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import com.htc.home.AbstractWidgetView;
import com.htc.home.LegacyOrientation;
import com.htc.launcher.AddAdapter;
import com.htc.launcher.settings.SettingUtil;
import java.util.ArrayList;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class WidgetsManager {
    private static final String TAG = "Widget";
    private static final boolean localLOGV = SettingUtil.localLOGD;
    private AddAdapter mAddAdapter;
    private WidgetPackageManager mWidgetPackageManager;
    private ArrayList<WidgetProxy> mWidgets = WidgetPackageManager.instanceNoScan().mWidgets;
    private boolean mAreWidgetsPaused = false;

    public void onDestory() {
    }

    public void setWidgetPackageManager(WidgetPackageManager widgetPackageManager) {
        this.mWidgetPackageManager = widgetPackageManager;
    }

    public void setAddAdapter(AddAdapter addAdapter) {
        this.mAddAdapter = addAdapter;
    }

    public AddAdapter.ListItem[] listListItems(int categoryId) {
        ArrayList<AddAdapter.ListItem> actions = new ArrayList<>();
        ArrayList<WidgetItem> items = this.mWidgetPackageManager.getWidgetItemList(categoryId);
        WidgetItem[] arr$ = (WidgetItem[]) items.toArray(new WidgetItem[0]);
        for (WidgetItem item : arr$) {
            Integer count = Integer.valueOf(this.mWidgetPackageManager.getWidgetCountOnWorkspace(item));
            int maxInstance = item.getMaxInstances();
            if (item.isVisible() && (maxInstance < 0 || count.intValue() < maxInstance)) {
                try {
                    actions.add(item.getListItem(this.mAddAdapter));
                } catch (Exception ex) {
                    Log.e("Widget", "Fail to add list item - " + item.mPluginClassname);
                    Log.e("Widget", ex.getMessage(), ex);
                }
            }
        }
        if (localLOGV) {
            Log.d("Widget", "actions size - " + actions.size());
        }
        return (AddAdapter.ListItem[]) actions.toArray(new AddAdapter.ListItem[0]);
    }

    public void addWidgetsOnWorkspace(WidgetProxy wProxy) {
        Launcher.sWidgetPackageManager.addWidgetsOnWorkspace(wProxy);
    }

    public void removeWidgetsOnWorkspace(WidgetProxy wProxy) {
        Launcher.sWidgetPackageManager.removeWidgetsOnWorkspace(wProxy);
    }

    public void fireVisible(int currentScreen) {
        if (!this.mAreWidgetsPaused) {
            notifyWidgets(currentScreen, -1);
        }
    }

    public void fireAllVisible() {
        if (!this.mAreWidgetsPaused) {
            notifyAllWidgets();
        }
    }

    private void notifyWidgets(int screen1, int screen2) {
        WidgetProxy[] widgets = (WidgetProxy[]) this.mWidgets.toArray(new WidgetProxy[0]);
        for (WidgetProxy widget : widgets) {
            if (widget != null && widget.mVisibilityObserver != null && widget.isAddedConfirmed && widget.mVisibilityObserver.getNotifyType() != 40) {
                if (widget.getScreen() == screen1 || widget.getScreen() == screen2) {
                    widget.mVisibilityObserver.fireOnResume(20);
                } else {
                    widget.mVisibilityObserver.fireOnPause(20);
                }
            }
        }
    }

    private void notifyAllWidgets() {
        WidgetProxy[] widgets = (WidgetProxy[]) this.mWidgets.toArray(new WidgetProxy[0]);
        for (WidgetProxy widget : widgets) {
            if (widget != null && widget.mVisibilityObserver != null && widget.isAddedConfirmed && widget.mVisibilityObserver.getNotifyType() != 40) {
                widget.mVisibilityObserver.fireOnResume(20);
            }
        }
    }

    public void onActivityResume(Launcher launcher, int notifyCause) {
        Workspace workspace;
        this.mAreWidgetsPaused = false;
        if (launcher != null && (workspace = launcher.getWorkspace()) != null) {
            int currentScreen = workspace.getCurrentScreenIndexByScrollX();
            if (localLOGV) {
                Log.d("Widget", "onActivityResume currentScreen : " + currentScreen);
            }
            WidgetProxy[] widgets = (WidgetProxy[]) this.mWidgets.toArray(new WidgetProxy[0]);
            for (WidgetProxy widget : widgets) {
                if (widget.mVisibilityObserver != null && widget.isAddedConfirmed) {
                    if (notifyCause == 50) {
                        if (widget.getScreen() == currentScreen && widget.mVisibilityObserver.getNotifyType() == 50) {
                            widget.mVisibilityObserver.fireOnResume(notifyCause);
                        }
                    } else if (widget.getScreen() == currentScreen || widget.mVisibilityObserver.getNotifyType() == 40) {
                        widget.mVisibilityObserver.fireOnResume(notifyCause);
                    }
                }
            }
        }
    }

    public void onActivityResume(Launcher launcher) {
        onActivityResume(launcher, 30);
    }

    public void onActivityPause(Launcher launcher, int notifyCause) {
        this.mAreWidgetsPaused = true;
        Workspace workspace = launcher.getWorkspace();
        if (workspace != null) {
            int currentScreen = workspace.getCurrentScreenIndex();
            if (localLOGV) {
                Log.d("Widget", "onActivityPause currentScreen : " + currentScreen);
            }
            WidgetProxy[] widgets = (WidgetProxy[]) this.mWidgets.toArray(new WidgetProxy[0]);
            for (WidgetProxy widget : widgets) {
                if (widget.mVisibilityObserver != null) {
                    if (notifyCause == 50) {
                        if (widget.getScreen() == currentScreen && widget.mVisibilityObserver.getNotifyType() == 50) {
                            widget.mVisibilityObserver.fireOnPause(notifyCause);
                        }
                    } else if (widget.getScreen() == currentScreen || widget.mVisibilityObserver.getNotifyType() == 40 || widget.mVisibilityObserver.getNotifyType() == 50) {
                        widget.mVisibilityObserver.fireOnPause(notifyCause);
                    }
                }
            }
        }
    }

    public void onActivityPause(Launcher launcher) {
        onActivityPause(launcher, 30);
    }

    public void onActivityNewIntent(Launcher launcher) {
        WidgetProxy[] widgets = (WidgetProxy[]) this.mWidgets.toArray(new WidgetProxy[0]);
        for (WidgetProxy widget : widgets) {
            if (widget.mVisibilityObserver != null && widget.mVisibilityObserver.getNotifyType() == 50) {
                widget.mVisibilityObserver.fireOnNewIntent(60);
            }
        }
    }

    public void onActivityDestroy() {
        WidgetProxy[] widgets = (WidgetProxy[]) this.mWidgets.toArray(new WidgetProxy[0]);
        for (int i = 0; i < widgets.length; i++) {
            long begin = System.currentTimeMillis();
            try {
                try {
                    widgets[i].onActivityDestroy();
                    long end = System.currentTimeMillis();
                    long diff = end - begin;
                    if (localLOGV) {
                        Log.d("Widget", "onActivityDestroy() for " + widgets[i].getWidgetView() + ", diff = " + diff);
                    }
                } catch (Throwable th) {
                    Log.e("Widget", "onActivityDestroy Error !", th);
                    long end2 = System.currentTimeMillis();
                    long diff2 = end2 - begin;
                    if (localLOGV) {
                        Log.d("Widget", "onActivityDestroy() for " + widgets[i].getWidgetView() + ", diff = " + diff2);
                    }
                }
            } catch (Throwable th2) {
                long end3 = System.currentTimeMillis();
                long diff3 = end3 - begin;
                if (localLOGV) {
                    Log.d("Widget", "onActivityDestroy() for " + widgets[i].getWidgetView() + ", diff = " + diff3);
                }
                throw th2;
            }
        }
    }

    public void refreshContents() {
        WidgetProxy[] widgets = (WidgetProxy[]) this.mWidgets.toArray(new WidgetProxy[0]);
        for (int i = 0; i < widgets.length; i++) {
            long begin = System.currentTimeMillis();
            try {
                try {
                    widgets[i].getWidgetView().refreshContents();
                    long end = System.currentTimeMillis();
                    long diff = end - begin;
                    if (localLOGV) {
                        Log.d("Widget", "refreshContents() for " + widgets[i].getWidgetView() + ", diff = " + diff);
                    }
                } catch (Throwable th) {
                    Log.e("Widget", "onActivityDestroy Error !", th);
                    long end2 = System.currentTimeMillis();
                    long diff2 = end2 - begin;
                    if (localLOGV) {
                        Log.d("Widget", "refreshContents() for " + widgets[i].getWidgetView() + ", diff = " + diff2);
                    }
                }
            } catch (Throwable th2) {
                long end3 = System.currentTimeMillis();
                long diff3 = end3 - begin;
                if (localLOGV) {
                    Log.d("Widget", "refreshContents() for " + widgets[i].getWidgetView() + ", diff = " + diff3);
                }
                throw th2;
            }
        }
    }

    private void onOrientationChangedFast(WidgetProxy widget, int orientation) {
        AbstractWidgetView widgetView = widget.getWidgetView();
        if (widgetView instanceof AbstractWidgetView) {
            widgetView.onOrientationChanged(orientation);
        }
    }

    private void onOrientationChangedLegacy(WidgetProxy widget, Launcher launcher, Workspace workspace) {
        Log.w("Widget", "run in legacy orientation - " + widget.getWidgetView());
        try {
            widget.onActivityDestroy();
        } catch (Throwable th) {
            Log.e("Widget", "onOrientationChanged Error ! - " + widget.getWidgetView(), th);
        }
        View childView = widget.mView;
        ViewGroup parentView = (ViewGroup) childView.getParent();
        if (parentView != null) {
            parentView.removeView(childView);
        }
        View view2 = widget.inflate(launcher, (ViewGroup) workspace.getChildAt(widget.screen), false);
        view2.setTag(widget);
        launcher.getDesktopItemController().addLegacyItemToDesktop(view2, widget, widget.screen, widget.cellX, widget.cellY, widget.spanX, widget.spanY, false);
    }

    public void onOrientationChanged(Launcher launcher, Workspace workspace, int orientation, int screen, boolean screenOnly) {
        WidgetProxy[] widgets = (WidgetProxy[]) this.mWidgets.toArray(new WidgetProxy[0]);
        for (int i = 0; i < widgets.length; i++) {
            if ((!screenOnly || widgets[i].screen == screen) && (screenOnly || widgets[i].screen != screen)) {
                long begin = System.currentTimeMillis();
                try {
                    try {
                        if (widgets[i].getWidgetView() instanceof LegacyOrientation) {
                            onOrientationChangedLegacy(widgets[i], launcher, workspace);
                        } else {
                            onOrientationChangedFast(widgets[i], orientation);
                        }
                        long end = System.currentTimeMillis();
                        long diff = end - begin;
                        Launcher.sOrientationMonitor.addOnConfigurationChanged(widgets[i].getWidgetView(), diff);
                        if (localLOGV) {
                            Log.d("Widget", "onOrientationChanged() for " + widgets[i].getWidgetView() + ", diff = " + diff);
                        }
                    } catch (Throwable th) {
                        Log.e("Widget", "onOrientationChanged Error !", th);
                        long end2 = System.currentTimeMillis();
                        long diff2 = end2 - begin;
                        Launcher.sOrientationMonitor.addOnConfigurationChanged(widgets[i].getWidgetView(), diff2);
                        if (localLOGV) {
                            Log.d("Widget", "onOrientationChanged() for " + widgets[i].getWidgetView() + ", diff = " + diff2);
                        }
                    }
                } catch (Throwable th2) {
                    long end3 = System.currentTimeMillis();
                    long diff3 = end3 - begin;
                    Launcher.sOrientationMonitor.addOnConfigurationChanged(widgets[i].getWidgetView(), diff3);
                    if (localLOGV) {
                        Log.d("Widget", "onOrientationChanged() for " + widgets[i].getWidgetView() + ", diff = " + diff3);
                    }
                    throw th2;
                }
            }
        }
    }
}
