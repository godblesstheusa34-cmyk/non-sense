package com.htc.launcher;

import android.content.pm.ActivityInfo;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.DisplayMetrics;
import com.htc.launcher.settings.SettingUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class ResourceUtil {
    static Drawable getDrawable(Resources resources, int id) {
        Drawable drawable = null;
        try {
            if (SettingUtil.sOverrideDpi == 160) {
                drawable = resources.getDrawable(id);
            } else {
                Configuration cfg = resources.getConfiguration();
                DisplayMetrics dm = resources.getDisplayMetrics();
                float fOriginalDensity = dm.density;
                int fOriginalDpi = dm.densityDpi;
                dm.density = SettingUtil.sOverrideDensity;
                dm.densityDpi = SettingUtil.sOverrideDpi;
                resources.updateConfiguration(cfg, dm);
                drawable = resources.getDrawable(id);
                dm.density = fOriginalDensity;
                dm.densityDpi = fOriginalDpi;
                resources.updateConfiguration(cfg, dm);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return drawable;
    }

    static Drawable getApplicationIcon(PackageManager manager, ActivityInfo info) {
        Drawable icon = null;
        try {
            if (SettingUtil.sOverrideDpi == 160) {
                icon = info.loadIcon(manager);
            } else {
                Resources resources = manager.getResourcesForApplication(((PackageItemInfo) info).packageName);
                Configuration cfg = resources.getConfiguration();
                DisplayMetrics dm = resources.getDisplayMetrics();
                float fOriginalDensity = dm.density;
                int fOriginalDpi = dm.densityDpi;
                dm.density = SettingUtil.sOverrideDensity;
                dm.densityDpi = SettingUtil.sOverrideDpi;
                resources.updateConfiguration(cfg, dm);
                icon = info.loadIcon(manager);
                dm.density = fOriginalDensity;
                dm.densityDpi = fOriginalDpi;
                resources.updateConfiguration(cfg, dm);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return icon;
    }
}
