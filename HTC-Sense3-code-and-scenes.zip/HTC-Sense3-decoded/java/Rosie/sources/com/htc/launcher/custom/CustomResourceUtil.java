package com.htc.launcher.custom;

import android.content.Context;
import com.htc.util.skin.HtcSkinUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class CustomResourceUtil {
    public static int getColorResIdentifier(Context context, String resName, int defRes) {
        return HtcSkinUtil.getColorResIdentifier(context, resName, defRes);
    }

    public static int getDrawableResIdentifier(Context context, String resName, int defRes) {
        return HtcSkinUtil.getDrawableResIdentifier(context, resName, defRes);
    }

    public static int getIntegerResIdentifier(Context context, String resName, int defRes) {
        return HtcSkinUtil.getIntegerResIdentifier(context, resName, defRes);
    }

    public static String getSkinName(Context context, String packageName) {
        return HtcSkinUtil.getSkinName(context, packageName);
    }

    public static String getAppliedSkinPackageName() {
        return HtcSkinUtil.getAppliedSkinPackageName();
    }
}
