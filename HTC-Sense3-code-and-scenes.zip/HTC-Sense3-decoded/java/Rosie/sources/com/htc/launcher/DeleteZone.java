package com.htc.launcher;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.TransitionDrawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.htc.launcher.DragController;
import com.htc.launcher.DragSource;
import com.htc.launcher.custom.CustomResourceUtil;
import com.htc.launcher.settings.SettingUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class DeleteZone extends RelativeLayout implements DropTarget, DragController.DragListener {
    private static final int ANIMATION_DURATION = 200;
    private static final int ORIENTATION_HORIZONTAL = 1;
    private static final int TRANSITION_DURATION = 250;
    private TextView mDeleteText;
    private DragLayer mDragLayer;
    private View mHandle;
    private Animation mHandleInAnimation;
    private Animation mHandleOutAnimation;
    private AnimationSet mInAnimation;
    private Launcher mLauncher;
    private final int[] mLocation;
    private int mOrientation;
    private AnimationSet mOutAnimation;
    private final RectF mRegion;
    private TransitionDrawable mTransition;
    private boolean mTrashMode;

    public DeleteZone(Context context) {
        super(context);
        this.mLocation = new int[2];
        this.mRegion = new RectF();
    }

    public DeleteZone(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public DeleteZone(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mLocation = new int[2];
        this.mRegion = new RectF();
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.DeleteZone, defStyle, 0);
        this.mOrientation = a.getInt(0, 1);
        a.recycle();
    }

    @Override // android.view.View
    protected void onFinishInflate() {
        super.onFinishInflate();
        View handle = findViewById(R.id.delete_handle);
        this.mTransition = (TransitionDrawable) handle.getBackground();
        try {
            this.mDeleteText = (TextView) findViewById(R.id.delete_content);
            this.mDeleteText.setCompoundDrawablesWithIntrinsicBounds(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "edit_delet_icon", R.drawable.edit_delet_icon), 0, 0, 0);
            setBackgroundDrawable(getResources().getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "navbar", 34079090)));
        } catch (ClassCastException ex) {
            Log.e("DeleteZone", "mDeleteText : " + findViewById(R.id.delete_content));
            throw ex;
        }
    }

    @Override // com.htc.launcher.DropTarget
    public boolean acceptDrop(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        return true;
    }

    @Override // com.htc.launcher.DropTarget
    public Rect estimateDropLocation(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem, Rect recycle) {
        return null;
    }

    @Override // com.htc.launcher.DropTarget
    public void onDrop(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        this.mLauncher.getDesktopItemController().removeItem(source, dragItem.getItemInfo());
    }

    @Override // com.htc.launcher.DropTarget
    public void onDragEnter(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        this.mTransition.resetTransition();
        this.mTransition.reverseTransition(TRANSITION_DURATION);
        this.mDeleteText.setCompoundDrawablesWithIntrinsicBounds(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "con_trash_on", R.drawable.con_trash_on), 0, 0, 0);
        this.mDragLayer.setDragColor(R.color.delete_color_filter);
    }

    @Override // com.htc.launcher.DropTarget
    public void onDragOver(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
    }

    @Override // com.htc.launcher.DropTarget
    public void onDragExit(DragSource source, DropTarget target, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        this.mTransition.reverseTransition(TRANSITION_DURATION);
        this.mDeleteText.setCompoundDrawablesWithIntrinsicBounds(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "con_trash_rest", R.drawable.con_trash_rest), 0, 0, 0);
    }

    @Override // com.htc.launcher.DragController.DragListener
    public void onPreDragStart(Draggee cell, DragSource source, Object info, int dragAction) {
    }

    @Override // com.htc.launcher.DragController.DragListener
    public void onPostDragStart(Draggee cell, DragSource source, Object info, int dragAction) {
        if (SettingUtil.htc_sense < 2.0f) {
            if (Launcher.localLOGD) {
                Log.d("Rosie", "[ATS][com.htc.launcher][press_hold_widget][movable]");
            }
            ItemInfo item = (ItemInfo) info;
            if (item != null) {
                this.mTrashMode = true;
                createAnimations();
                int[] location = this.mLocation;
                getLocationOnScreen(location);
                this.mRegion.set(location[0], location[1], (location[0] + ((View) this).mRight) - ((View) this).mLeft, (location[1] + ((View) this).mBottom) - ((View) this).mTop);
                this.mDragLayer.setDeleteRegion(this.mRegion);
                this.mTransition.resetTransition();
            }
        }
    }

    @Override // com.htc.launcher.DragController.DragListener
    public void onDragEnd() {
        if (this.mTrashMode) {
            this.mTrashMode = false;
            this.mDragLayer.setDeleteRegion(null);
        }
    }

    @Override // com.htc.launcher.DropTarget
    public DragSource.DragCompletedAction getDragCompletedAction() {
        return DragSource.DragCompletedAction.REMOVE;
    }

    private void createAnimations() {
        if (this.mInAnimation == null) {
            this.mInAnimation = new FastAnimationSet();
            AnimationSet animationSet = this.mInAnimation;
            animationSet.setInterpolator(new AccelerateInterpolator());
            animationSet.addAnimation(new AlphaAnimation(0.0f, 1.0f));
            if (this.mOrientation == 1) {
                animationSet.addAnimation(new TranslateAnimation(0, 0.0f, 0, 0.0f, 1, 1.0f, 1, 0.0f));
            } else {
                animationSet.addAnimation(new TranslateAnimation(1, 1.0f, 1, 0.0f, 0, 0.0f, 0, 0.0f));
            }
            animationSet.setDuration(200L);
        }
        if (this.mHandleInAnimation == null) {
            if (this.mOrientation == 1) {
                this.mHandleInAnimation = new TranslateAnimation(0, 0.0f, 0, 0.0f, 1, 1.0f, 1, 0.0f);
            } else {
                this.mHandleInAnimation = new TranslateAnimation(1, 1.0f, 1, 0.0f, 0, 0.0f, 0, 0.0f);
            }
            this.mHandleInAnimation.setDuration(200L);
        }
        if (this.mOutAnimation == null) {
            this.mOutAnimation = new FastAnimationSet();
            AnimationSet animationSet2 = this.mOutAnimation;
            animationSet2.setInterpolator(new AccelerateInterpolator());
            animationSet2.addAnimation(new AlphaAnimation(1.0f, 0.0f));
            if (this.mOrientation == 1) {
                animationSet2.addAnimation(new FastTranslateAnimation(0, 0.0f, 0, 0.0f, 1, 0.0f, 1, 1.0f));
            } else {
                animationSet2.addAnimation(new FastTranslateAnimation(1, 0.0f, 1, 1.0f, 0, 0.0f, 0, 0.0f));
            }
            animationSet2.setDuration(200L);
        }
        if (this.mHandleOutAnimation == null) {
            if (this.mOrientation == 1) {
                this.mHandleOutAnimation = new FastTranslateAnimation(0, 0.0f, 0, 0.0f, 1, 0.0f, 1, 1.0f);
            } else {
                this.mHandleOutAnimation = new FastTranslateAnimation(1, 0.0f, 1, 1.0f, 0, 0.0f, 0, 0.0f);
            }
            this.mHandleOutAnimation.setFillAfter(true);
            this.mHandleOutAnimation.setDuration(200L);
        }
    }

    void setLauncher(Launcher launcher) {
        this.mLauncher = launcher;
    }

    void setDragController(DragLayer dragLayer) {
        this.mDragLayer = dragLayer;
    }

    void setHandle(View view) {
        this.mHandle = view;
    }

    private static class FastTranslateAnimation extends TranslateAnimation {
        public FastTranslateAnimation(int fromXType, float fromXValue, int toXType, float toXValue, int fromYType, float fromYValue, int toYType, float toYValue) {
            super(fromXType, fromXValue, toXType, toXValue, fromYType, fromYValue, toYType, toYValue);
        }

        @Override // android.view.animation.Animation
        public boolean willChangeTransformationMatrix() {
            return true;
        }

        @Override // android.view.animation.Animation
        public boolean willChangeBounds() {
            return false;
        }
    }

    private static class FastAnimationSet extends AnimationSet {
        FastAnimationSet() {
            super(false);
        }

        @Override // android.view.animation.AnimationSet, android.view.animation.Animation
        public boolean willChangeTransformationMatrix() {
            return true;
        }

        @Override // android.view.animation.AnimationSet, android.view.animation.Animation
        public boolean willChangeBounds() {
            return false;
        }
    }

    public void updateOrientation(boolean portrait) {
        Resources res = getResources();
        FrameLayout.LayoutParams DeletelParams = (FrameLayout.LayoutParams) getLayoutParams();
        if (portrait) {
            ((ViewGroup.LayoutParams) DeletelParams).width = -2;
            ((ViewGroup.LayoutParams) DeletelParams).height = res.getDimensionPixelSize(R.dimen.button_bar_height);
            DeletelParams.gravity = 81;
            this.mOrientation = 1;
            setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "navbar", 34079090)));
        } else {
            ((ViewGroup.LayoutParams) DeletelParams).width = res.getDimensionPixelSize(R.dimen.button_bar_height);
            ((ViewGroup.LayoutParams) DeletelParams).height = -2;
            DeletelParams.gravity = 21;
            this.mOrientation = 0;
            setBackgroundDrawable(res.getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "navbar", 34079090)));
        }
        View deleteHandle = findViewById(R.id.delete_handle);
        deleteHandle.setBackgroundDrawable(res.getDrawable(R.drawable.rosie_delete_zone_selector));
        RelativeLayout.LayoutParams deleteHandleParams = (RelativeLayout.LayoutParams) deleteHandle.getLayoutParams();
        ((ViewGroup.LayoutParams) deleteHandleParams).width = -2;
        ((ViewGroup.LayoutParams) deleteHandleParams).height = -2;
        deleteHandleParams.addRule(15, 0);
        deleteHandleParams.addRule(11, 0);
        deleteHandleParams.addRule(14, 0);
        deleteHandleParams.addRule(12, 0);
        deleteHandleParams.setMargins(0, 0, 0, 0);
        if (portrait) {
            deleteHandleParams.addRule(14);
            deleteHandleParams.addRule(12);
        } else {
            deleteHandleParams.addRule(15);
            deleteHandleParams.addRule(11);
            deleteHandleParams.setMargins(0, 0, res.getDimensionPixelOffset(R.dimen.button_bar_left_margin_right), 0);
        }
        TextView deleteContent = (TextView) findViewById(R.id.delete_content);
        RelativeLayout.LayoutParams deleteContentParams = (RelativeLayout.LayoutParams) deleteContent.getLayoutParams();
        ((ViewGroup.LayoutParams) deleteContentParams).width = -2;
        ((ViewGroup.LayoutParams) deleteContentParams).height = -2;
        deleteContentParams.addRule(15, 0);
        deleteContentParams.addRule(7, 0);
        deleteContentParams.addRule(14, 0);
        deleteContentParams.addRule(12, 0);
        deleteContentParams.setMargins(0, 0, 0, 0);
        if (portrait) {
            deleteContentParams.addRule(14);
            deleteContentParams.addRule(12);
            deleteContent.setText(R.string.delete);
        } else {
            deleteContentParams.addRule(15);
            deleteContentParams.setMargins(0, 0, res.getDimensionPixelOffset(R.dimen.deletezone_icon_marginright), 0);
            deleteContentParams.addRule(7, R.id.delete_handle);
            deleteContent.setText(R.string.delete_landscape);
        }
    }

    @Override // com.htc.launcher.DropTarget
    public boolean claimDrop(int x, int y, int[] dropCoordinates) {
        return false;
    }

    public void froceUpdateRemote(Canvas canvas) {
    }
}
