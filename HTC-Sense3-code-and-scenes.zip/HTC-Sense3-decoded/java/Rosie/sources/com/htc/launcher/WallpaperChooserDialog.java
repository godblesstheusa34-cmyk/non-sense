package com.htc.launcher;

import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageItemInfo;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import com.htc.app.HtcAlertActivity;
import com.htc.app.HtcAlertController;
import com.htc.launcher.settings.SettingUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class WallpaperChooserDialog extends HtcAlertActivity implements DialogInterface.OnClickListener {
    private static final int WALLPAPER_ALBUMS = 1;
    private static final int WALLPAPER_GALLERY = 0;
    private static final int WALLPAPER_LIVEWALLPAPER = 2;
    private static final int WALLPAPER_OTHER = 3;
    AddWallpaperAdapter mItemAdapter;
    boolean mIsPickLockScreenWallpaper = false;
    boolean mIsLiveWallPaper = false;

    /* JADX WARN: Multi-variable type inference failed */
    protected void onCreate(Bundle savedInstanceState) {
        Intent intent = getIntent();
        this.mIsPickLockScreenWallpaper = intent.getBooleanExtra("IS_SELECT_LOCKSCREEN", false);
        this.mIsLiveWallPaper = intent.getBooleanExtra("IS_LIVE_WALLPAPER", false);
        super.onCreate(savedInstanceState);
        initialDialog();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void initialDialog() {
        HtcAlertController.AlertParams p = ((HtcAlertActivity) this).mAlertParams;
        p.mTitle = getText(R.string.chooser_wallpaper);
        this.mItemAdapter = new AddWallpaperAdapter(this, this.mIsPickLockScreenWallpaper);
        p.mAdapter = this.mItemAdapter;
        p.mIsSingleChoice = true;
        p.mOnClickListener = this;
        setupAlert();
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialog, int which) {
        int which2;
        ResolveInfo matchApp = this.mItemAdapter.GetMatchResolveInfo(which);
        String filename = ((PackageItemInfo) matchApp.activityInfo).packageName;
        String activityname = ((PackageItemInfo) matchApp.activityInfo).name;
        if (filename.equals("com.htc.AddProgramWidget")) {
            which2 = 0;
        } else if (filename.equals("com.htc.album")) {
            which2 = 1;
        } else if (filename.equals("com.android.wallpaper.livepicker")) {
            which2 = 2;
        } else {
            which2 = 3;
        }
        switch (which2) {
            case 0:
                Intent pickWallpaper = new Intent("android.intent.action.SET_WALLPAPER");
                pickWallpaper.setComponent(new ComponentName(filename, activityname));
                if (this.mIsPickLockScreenWallpaper) {
                    pickWallpaper.putExtra("IS_SELECT_LOCKSCREEN", true);
                }
                if (SettingUtil.localLOGD) {
                    Log.d("Rosie", "[ATS][com.htc.launcher][press_gallery][successful]");
                }
                startActivity(pickWallpaper);
                break;
            case 1:
                if (!this.mIsPickLockScreenWallpaper) {
                    Intent pickIntent = new Intent("android.intent.action.SET_WALLPAPER");
                    pickIntent.putExtra("CAN_RESET_DEFAULT", false);
                    pickIntent.setComponent(new ComponentName("com.htc.album", "com.htc.album.PickWallpaper"));
                    startActivity(pickIntent);
                    break;
                } else {
                    Intent pickIntent2 = new Intent("android.intent.action.SET_LOCKSCREEN");
                    pickIntent2.putExtra("CAN_RESET_DEFAULT", false);
                    startActivity(pickIntent2);
                    break;
                }
            case 2:
                Intent pickWallpaper2 = new Intent("android.intent.action.SET_WALLPAPER");
                pickWallpaper2.setComponent(new ComponentName("com.android.wallpaper.livepicker", "com.android.wallpaper.livepicker.LiveWallpaperListActivity"));
                startActivity(pickWallpaper2);
                break;
            case 3:
                Intent pickWallpaper3 = new Intent("android.intent.action.SET_WALLPAPER");
                pickWallpaper3.setComponent(new ComponentName(filename, activityname));
                startActivity(pickWallpaper3);
                break;
        }
        finish();
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void closeRosieDrawer() {
        Intent intent = new Intent(Launcher.ACTION_SILDER_STATE);
        intent.putExtra(Launcher.EXTRA_SILDER_STATE, false);
        sendBroadcast(intent);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == 1) {
            switch (event.getKeyCode()) {
                case 4:
                    finish();
                    return true;
            }
        }
        return super/*android.app.Activity*/.dispatchKeyEvent(event);
    }
}
