package com.htc.launcher;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.content.res.ColorStateList;
import android.content.res.CompatibilityInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Movie;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import com.android.common.speech.LoggingEvents;
import com.htc.launcher.OperatorTabCore;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class OperatorTabManager {
    public static final String TAG = "OperatorTabManager";
    private static OperatorTabManager instance = null;
    private Context ctx = null;
    private final Map<Integer, OperatorTab> operatorTabMap = new HashMap();
    private final List<OperatorTab> sortedOperatorTabList = new ArrayList();
    private final OperatorTabResources res = new OperatorTabResources();

    private OperatorTabManager() {
    }

    public static synchronized OperatorTabManager getInstance() {
        OperatorTabManager operatorTabManager;
        synchronized (OperatorTabManager.class) {
            if (instance == null) {
                instance = new OperatorTabManager();
            }
            operatorTabManager = instance;
        }
        return operatorTabManager;
    }

    public void setContext(Context ctx) {
        if (this.ctx != ctx) {
            TFC.d(TAG, "setContext: ctx=" + ctx + " this.ctx=" + this.ctx);
            this.ctx = ctx;
        }
    }

    public OperatorTab getOperatorTabByIndex(int i) {
        return this.sortedOperatorTabList.get(i);
    }

    public OperatorTab getOperatorTabByMinorNb(int minorNb) {
        return this.operatorTabMap.get(Integer.valueOf(minorNb));
    }

    public int getOperatorTabCount() {
        return this.operatorTabMap.size();
    }

    private void addOperatorTab(OperatorTab opTab) {
        this.operatorTabMap.put(Integer.valueOf(opTab.getMinorNb()), opTab);
        int i = 0;
        while (i < this.sortedOperatorTabList.size() && opTab.getInitOrder() >= this.sortedOperatorTabList.get(i).getInitOrder()) {
            i++;
        }
        this.sortedOperatorTabList.add(i, opTab);
    }

    public OperatorTabResources getResources() {
        return this.res;
    }

    void reload() {
        this.operatorTabMap.clear();
        this.sortedOperatorTabList.clear();
        loadCustomizationForm();
    }

    private void loadTestData() {
        File restIcon = new File("/data/data/com.htc.launcher/files/rest_icon.png");
        File onIcon = new File("/data/data/com.htc.launcher/files/on_icon.png");
        File overlayIcon = new File("/data/data/com.htc.launcher/files/overlay_icon.png");
        HashMap<Locale, String> labelMap = new HashMap<>();
        labelMap.put(null, "HTC");
        ArrayList<OperatorTabCore.Application> appList = new ArrayList<>();
        appList.add(new OperatorTabCore.Application("com.futuredial", "com.futuredial.ui.DMIUI", 9));
        appList.add(new OperatorTabCore.Application("com.twitter.android", "com.twitter.android.LoginActivity", 8));
        appList.add(new OperatorTabCore.Application("com.htc.album", "com.htc.album.TabPluginDevice.ActivityAllVideos", 7));
        OperatorTab opTab = new OperatorTab(0, "test operator tab", 3, 99, restIcon, onIcon, overlayIcon, labelMap, appList);
        addOperatorTab(opTab);
    }

    private void loadCustomizationForm() {
        Bundle form = this.ctx == null ? null : WidgetPackageManager.getModuleBundle(this.ctx);
        if (this.ctx != null && form != null) {
            int i = 0;
            while (true) {
                Bundle opTabBundle = form.getBundle("operator_tab_" + i);
                if (opTabBundle != null) {
                    OperatorTab opTab = parseOpTabFunction(i, opTabBundle);
                    TFC.d(TAG, "loadCustomizationForm: opTab=" + opTab);
                    if (opTab != null) {
                        addOperatorTab(opTab);
                    }
                    i++;
                } else {
                    return;
                }
            }
        }
    }

    private OperatorTab parseOpTabFunction(int i, Bundle opTabBundle) {
        HashMap<Locale, String> labelMap = new HashMap<>();
        ArrayList<OperatorTabCore.Application> appList = new ArrayList<>();
        OperatorTab ret = null;
        for (String key : opTabBundle.keySet()) {
            Bundle set = opTabBundle.getBundle(key);
            String type = set.getString(LoggingEvents.VoiceIme.EXTRA_TEXT_MODIFIED_TYPE);
            if ("label".equals(type)) {
                parseLabelSet(set, labelMap);
            } else if ("app".equals(type)) {
                parseAppSet(set, appList);
            } else if ("tab".equals(type)) {
                ret = parseTabSet(set, labelMap, appList, i);
            }
        }
        return ret;
    }

    private OperatorTab parseTabSet(Bundle set, HashMap<Locale, String> labelMap, ArrayList<OperatorTabCore.Application> appList, int minorNb) {
        String id = set.getString("id");
        int initOrder = 3;
        try {
            initOrder = Integer.parseInt(set.getString("init_order"));
        } catch (NumberFormatException e) {
            TFC.e(TAG, "parseTabSet: INIT_ORDER=" + set.getString("init_order"), e);
        }
        if (initOrder < 0) {
            TFC.w(TAG, "parseTabSet: invalid tab initOrder=" + initOrder);
            initOrder = 3;
        }
        String initPlaceString = set.getString("init_place");
        int initPlace = 99;
        if ("TAB".equals(initPlaceString)) {
            initPlace = 99;
        } else if ("POOL".equals(initPlaceString)) {
            initPlace = 100;
        } else if ("PERMANENT".equals(initPlaceString)) {
            initPlace = 101;
        }
        File restIcon = new File(set.getString("rest_icon"));
        File onIcon = new File(set.getString("on_icon"));
        File overlayIcon = new File(set.getString("overlay_icon"));
        OperatorTab opTab = new OperatorTab(minorNb, id, initOrder, initPlace, restIcon, onIcon, overlayIcon, labelMap, appList);
        return opTab;
    }

    private void parseAppSet(Bundle set, ArrayList<OperatorTabCore.Application> appList) {
        String packageName = set.getString("package");
        String className = set.getString("class");
        int priority = Integer.parseInt(set.getString("priority"));
        OperatorTabCore.Application app = new OperatorTabCore.Application(packageName, className, priority);
        appList.add(app);
    }

    private void parseLabelSet(Bundle set, HashMap<Locale, String> labelMap) {
        Locale locale;
        for (String key : set.keySet()) {
            String value = set.getString(key);
            if ("default".equals(key)) {
                labelMap.put(null, value);
            } else {
                if (-1 == key.indexOf("_")) {
                    locale = new Locale(key);
                } else {
                    String language = key.substring(0, key.indexOf("_"));
                    String country = key.substring(key.indexOf("_") + 1);
                    locale = new Locale(language, country);
                }
                labelMap.put(locale, value);
            }
        }
    }

    public class OperatorTabResources extends Resources {
        static final String ENTRY_NAME_ON_ICON = "on_icon_";
        static final String ENTRY_NAME_OVERLAY_ICON = "overlay_icon_";
        static final String ENTRY_NAME_REST_ICON = "rest_icon_";
        static final String ENTRY_NAME_TITLE = "title_";
        private static final int ID_ON_ICON = -102;
        private static final int ID_OVERLAY_ICON = -103;
        private static final int ID_REST_ICON = -101;
        private static final int ID_TITLE = -100;
        private static final int MAJOR_NB = -497;
        private static final int MAJOR_SCALE = 1000000;
        private static final int MINOR_SCALE = 1000;
        static final String TYPE_DRAWABLE = "drawable";
        static final String TYPE_STRING = "string";

        private OperatorTabResources() {
            super(new AssetManager(), new DisplayMetrics(), null);
        }

        @Override // android.content.res.Resources
        public InputStream openRawResource(int id) throws Resources.NotFoundException {
            File path = null;
            int minorNb = -1;
            if (id / MAJOR_SCALE == MAJOR_NB) {
                minorNb = (id % MAJOR_SCALE) / 1000;
                OperatorTabCore operatorTab = (OperatorTabCore) OperatorTabManager.this.operatorTabMap.get(Integer.valueOf(minorNb));
                if (operatorTab != null) {
                    switch (id % 1000) {
                        case ID_OVERLAY_ICON /* -103 */:
                            path = operatorTab.getOverlayIconPath();
                            break;
                        case ID_ON_ICON /* -102 */:
                            path = operatorTab.getOnIconPath();
                            break;
                        case ID_REST_ICON /* -101 */:
                            path = operatorTab.getRestIconPath();
                            break;
                    }
                }
                if (path == null) {
                    TFC.w(OperatorTabManager.TAG, "openRawResource: return null. id=" + id);
                    return null;
                }
            }
            TFC.d(OperatorTabManager.TAG, "OperatorTabResources.openRawResource: id=" + id + " path(abs)=" + (path == null ? null : path.getAbsolutePath()) + " minorNb=" + minorNb);
            if (path == null) {
                if (OperatorTabManager.this.ctx != null) {
                    return OperatorTabManager.this.ctx.getResources().openRawResource(id);
                }
                return super.openRawResource(id);
            }
            try {
                InputStream ret = new FileInputStream(path.getAbsolutePath());
                return ret;
            } catch (FileNotFoundException e) {
                throw new Resources.NotFoundException(e.toString());
            }
        }

        @Override // android.content.res.Resources
        public Drawable getDrawable(int id) throws Resources.NotFoundException {
            File path = null;
            int minorNb = -1;
            if (id / MAJOR_SCALE == MAJOR_NB) {
                minorNb = (id % MAJOR_SCALE) / 1000;
                OperatorTabCore operatorTab = (OperatorTabCore) OperatorTabManager.this.operatorTabMap.get(Integer.valueOf(minorNb));
                if (operatorTab != null) {
                    switch (id % 1000) {
                        case ID_OVERLAY_ICON /* -103 */:
                            path = operatorTab.getOverlayIconPath();
                            break;
                        case ID_ON_ICON /* -102 */:
                            path = operatorTab.getOnIconPath();
                            break;
                        case ID_REST_ICON /* -101 */:
                            path = operatorTab.getRestIconPath();
                            break;
                    }
                }
                if (path == null) {
                    TFC.w(OperatorTabManager.TAG, "getDrawable: return null. id=" + id);
                    return null;
                }
            }
            TFC.d(OperatorTabManager.TAG, "OperatorTabResources.getDrawable: id=" + id + " path(abs)=" + (path == null ? null : path.getAbsolutePath()) + " minorNb=" + minorNb);
            if (path != null) {
                if (OperatorTabManager.this.ctx != null) {
                    BitmapDrawable ret = new BitmapDrawable(OperatorTabManager.this.ctx.getResources(), path.getAbsolutePath());
                    ret.setTargetDensity(OperatorTabManager.this.res.getDisplayMetrics());
                    return ret;
                }
                return new BitmapDrawable(path.getAbsolutePath());
            }
            if (OperatorTabManager.this.ctx != null) {
                return OperatorTabManager.this.ctx.getResources().getDrawable(id);
            }
            return super.getDrawable(id);
        }

        @Override // android.content.res.Resources
        public String getString(int id) throws Resources.NotFoundException {
            String ret = doGetString(id);
            if (ret != null) {
                return ret;
            }
            if (OperatorTabManager.this.ctx != null) {
                return OperatorTabManager.this.ctx.getResources().getString(id);
            }
            return super.getString(id);
        }

        @Override // android.content.res.Resources
        public CharSequence getText(int id) throws Resources.NotFoundException {
            String ret = doGetString(id);
            if (ret != null) {
                return ret;
            }
            if (OperatorTabManager.this.ctx != null) {
                return OperatorTabManager.this.ctx.getResources().getText(id);
            }
            return super.getText(id);
        }

        private String doGetString(int id) {
            String ret = null;
            int minorNb = -1;
            if (id / MAJOR_SCALE == MAJOR_NB && id % 1000 == -100) {
                minorNb = (id % MAJOR_SCALE) / 1000;
                OperatorTabCore operatorTab = (OperatorTabCore) OperatorTabManager.this.operatorTabMap.get(Integer.valueOf(minorNb));
                if (operatorTab != null) {
                    Locale locale = null;
                    if (OperatorTabManager.this.ctx != null) {
                        locale = OperatorTabManager.this.ctx.getResources().getConfiguration().locale;
                    }
                    ret = operatorTab.getLabel(locale);
                    if (ret == null) {
                        ret = operatorTab.getLabel(null);
                    }
                }
                if (ret == null) {
                    TFC.w(OperatorTabManager.TAG, "doGetString: return empty string. id=" + id);
                    return LoggingEvents.EXTRA_CALLING_APP_NAME;
                }
            }
            TFC.d(OperatorTabManager.TAG, "OperatorTabResources.doGetString: id=" + id + " ret=" + ret + " minorNb=" + minorNb);
            return ret;
        }

        @Override // android.content.res.Resources
        public String getResourceName(int resid) throws Resources.NotFoundException {
            String ret = null;
            int minorNb = -1;
            if (resid / MAJOR_SCALE == MAJOR_NB) {
                minorNb = (resid % MAJOR_SCALE) / 1000;
                ret = getResourcePackageName(resid) + ":" + getResourceTypeName(resid) + "/" + getResourceEntryName(resid);
            }
            TFC.d(OperatorTabManager.TAG, "OperatorTabResources.getResourceName: resid=" + resid + " ret=" + ret + " minorNb=" + minorNb);
            if (ret != null) {
                return ret;
            }
            if (OperatorTabManager.this.ctx != null) {
                return OperatorTabManager.this.ctx.getResources().getResourceName(resid);
            }
            return super.getResourceName(resid);
        }

        @Override // android.content.res.Resources
        public int getIdentifier(String name, String type, String packageName) {
            String tmp = null;
            int i = name.indexOf("/");
            if (-1 != i) {
                tmp = name.substring(0, i);
                name = name.substring(i + 1);
            }
            if (tmp != null) {
                int i2 = tmp.indexOf(":");
                if (-1 != i2) {
                    packageName = tmp.substring(0, i2);
                    type = tmp.substring(i2 + 1);
                } else {
                    TFC.w(OperatorTabManager.TAG, "OperatorTabResources.getIdentifier: invalid parameters. name=" + name + " type=" + type + " packageName=" + packageName);
                }
            }
            int ret = 0;
            int minorNb = -1;
            if (OperatorTabManager.this.ctx.getPackageName().equals(packageName) && name != null) {
                if (name.startsWith(ENTRY_NAME_TITLE) && TYPE_STRING.equals(type)) {
                    minorNb = Integer.parseInt(name.substring(ENTRY_NAME_TITLE.length()));
                    ret = ((minorNb * 1000) - 497000000) - 100;
                } else if (name.startsWith(ENTRY_NAME_REST_ICON) && TYPE_DRAWABLE.equals(type)) {
                    minorNb = Integer.parseInt(name.substring(ENTRY_NAME_REST_ICON.length()));
                    ret = ((minorNb * 1000) - 497000000) + ID_REST_ICON;
                } else if (name.startsWith(ENTRY_NAME_ON_ICON) && TYPE_DRAWABLE.equals(type)) {
                    minorNb = Integer.parseInt(name.substring(ENTRY_NAME_ON_ICON.length()));
                    ret = ((minorNb * 1000) - 497000000) + ID_ON_ICON;
                } else if (name.startsWith(ENTRY_NAME_OVERLAY_ICON) && TYPE_DRAWABLE.equals(type)) {
                    minorNb = Integer.parseInt(name.substring(ENTRY_NAME_OVERLAY_ICON.length()));
                    ret = ((minorNb * 1000) - 497000000) + ID_OVERLAY_ICON;
                }
            }
            TFC.d(OperatorTabManager.TAG, "OperatorTabResources.getIdentifier: name=" + name + " type=" + type + " pkg=" + packageName + " ret=" + ret + " minorNb=" + minorNb);
            if (ret != 0) {
                return ret;
            }
            if (OperatorTabManager.this.ctx != null) {
                return OperatorTabManager.this.ctx.getResources().getIdentifier(name, type, packageName);
            }
            return super.getIdentifier(name, type, packageName);
        }

        @Override // android.content.res.Resources
        public String getResourceEntryName(int resid) throws Resources.NotFoundException {
            String ret = null;
            int minorNb = -1;
            if (resid / MAJOR_SCALE == MAJOR_NB) {
                minorNb = (resid % MAJOR_SCALE) / 1000;
                switch (resid % 1000) {
                    case ID_OVERLAY_ICON /* -103 */:
                        ret = encodeResourceEntryName(ENTRY_NAME_OVERLAY_ICON, minorNb);
                        break;
                    case ID_ON_ICON /* -102 */:
                        ret = encodeResourceEntryName(ENTRY_NAME_ON_ICON, minorNb);
                        break;
                    case ID_REST_ICON /* -101 */:
                        ret = encodeResourceEntryName(ENTRY_NAME_REST_ICON, minorNb);
                        break;
                    case -100:
                        ret = encodeResourceEntryName(ENTRY_NAME_TITLE, minorNb);
                        break;
                }
            }
            TFC.d(OperatorTabManager.TAG, "OperatorTabResources.getResourceEntryName: resid=" + resid + " ret=" + ret + " minorNb=" + minorNb);
            if (ret != null) {
                return ret;
            }
            if (OperatorTabManager.this.ctx != null) {
                return OperatorTabManager.this.ctx.getResources().getResourceEntryName(resid);
            }
            return super.getResourceEntryName(resid);
        }

        @Override // android.content.res.Resources
        public String getResourcePackageName(int resid) throws Resources.NotFoundException {
            String ret = null;
            int minorNb = -1;
            if (resid / MAJOR_SCALE == MAJOR_NB) {
                minorNb = (resid % MAJOR_SCALE) / 1000;
                ret = OperatorTabManager.this.ctx.getPackageName();
            }
            TFC.d(OperatorTabManager.TAG, "OperatorTabResources.getResourcePackageName: resid=" + resid + " ret=" + ret + " minorNb=" + minorNb);
            if (ret != null) {
                return ret;
            }
            if (OperatorTabManager.this.ctx != null) {
                return OperatorTabManager.this.ctx.getResources().getResourcePackageName(resid);
            }
            return super.getResourcePackageName(resid);
        }

        @Override // android.content.res.Resources
        public String getResourceTypeName(int resid) throws Resources.NotFoundException {
            String ret = null;
            int minorNb = -1;
            if (resid / MAJOR_SCALE == MAJOR_NB) {
                minorNb = (resid % MAJOR_SCALE) / 1000;
                switch (resid % 1000) {
                    case ID_OVERLAY_ICON /* -103 */:
                        ret = TYPE_DRAWABLE;
                        break;
                    case ID_ON_ICON /* -102 */:
                        ret = TYPE_DRAWABLE;
                        break;
                    case ID_REST_ICON /* -101 */:
                        ret = TYPE_DRAWABLE;
                        break;
                    case -100:
                        ret = TYPE_STRING;
                        break;
                }
            }
            TFC.d(OperatorTabManager.TAG, "OperatorTabResources.getResourceTypeName: resid=" + resid + " ret=" + ret + " minorNb=" + minorNb);
            if (ret != null) {
                return ret;
            }
            if (OperatorTabManager.this.ctx != null) {
                return OperatorTabManager.this.ctx.getResources().getResourceTypeName(resid);
            }
            return super.getResourceTypeName(resid);
        }

        @Override // android.content.res.Resources
        public void updateConfiguration(Configuration arg0, DisplayMetrics arg1) {
            TFC.d(OperatorTabManager.TAG, "OperatorTabResources.updateConfiguration: ctx=" + OperatorTabManager.this.ctx);
            if (OperatorTabManager.this.ctx == null) {
                TFC.w(OperatorTabManager.TAG, "OperatorTabResources.updateConfiguration: arg0(conf)=" + arg0 + " arg1(dispMetrics)=" + arg1);
            }
            if (OperatorTabManager.this.ctx != null) {
                OperatorTabManager.this.ctx.getResources().updateConfiguration(arg0, arg1);
            }
            super.updateConfiguration(arg0, arg1);
        }

        public int getLabelResId(OperatorTab tab) {
            return getIdentifier(encodeResourceEntryName(ENTRY_NAME_TITLE, tab.getMinorNb()), TYPE_STRING, OperatorTabManager.this.ctx.getPackageName());
        }

        public int getRestIconResId(OperatorTab tab) {
            return getIdentifier(encodeResourceEntryName(ENTRY_NAME_REST_ICON, tab.getMinorNb()), TYPE_DRAWABLE, OperatorTabManager.this.ctx.getPackageName());
        }

        public int getOnIconResId(OperatorTab tab) {
            return getIdentifier(encodeResourceEntryName(ENTRY_NAME_ON_ICON, tab.getMinorNb()), TYPE_DRAWABLE, OperatorTabManager.this.ctx.getPackageName());
        }

        public int getOverlayIconResId(OperatorTab tab) {
            return getIdentifier(encodeResourceEntryName(ENTRY_NAME_OVERLAY_ICON, tab.getMinorNb()), TYPE_DRAWABLE, OperatorTabManager.this.ctx.getPackageName());
        }

        private String encodeResourceEntryName(String name, int minorNb) {
            return name + minorNb;
        }

        @Override // android.content.res.Resources
        public XmlResourceParser getAnimation(int id) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!z");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getAnimation(id) : super.getAnimation(id);
        }

        @Override // android.content.res.Resources
        public boolean getBoolean(int arg0) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!y");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getBoolean(arg0) : super.getBoolean(arg0);
        }

        @Override // android.content.res.Resources
        public int getColor(int arg0) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!x");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getColor(arg0) : super.getColor(arg0);
        }

        @Override // android.content.res.Resources
        public ColorStateList getColorStateList(int arg0) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!w");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getColorStateList(arg0) : super.getColorStateList(arg0);
        }

        public CompatibilityInfo getCompatibilityInfo() {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!v");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getCompatibilityInfo() : super.getCompatibilityInfo();
        }

        @Override // android.content.res.Resources
        public Configuration getConfiguration() {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!u");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getConfiguration() : super.getConfiguration();
        }

        public Display getDefaultDisplay(Display defaultDisplay) {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!t");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getDefaultDisplay(defaultDisplay) : super.getDefaultDisplay(defaultDisplay);
        }

        @Override // android.content.res.Resources
        public float getDimension(int arg0) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!s");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getDimension(arg0) : super.getDimension(arg0);
        }

        @Override // android.content.res.Resources
        public int getDimensionPixelOffset(int arg0) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!r");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getDimensionPixelOffset(arg0) : super.getDimensionPixelOffset(arg0);
        }

        @Override // android.content.res.Resources
        public int getDimensionPixelSize(int arg0) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!q");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getDimensionPixelSize(arg0) : super.getDimensionPixelSize(arg0);
        }

        @Override // android.content.res.Resources
        public DisplayMetrics getDisplayMetrics() {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!p");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getDisplayMetrics() : super.getDisplayMetrics();
        }

        @Override // android.content.res.Resources
        public float getFraction(int arg0, int arg1, int arg2) {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!o");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getFraction(arg0, arg1, arg2) : super.getFraction(arg0, arg1, arg2);
        }

        @Override // android.content.res.Resources
        public int[] getIntArray(int id) throws Resources.NotFoundException {
            Log.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!n");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getIntArray(id) : super.getIntArray(id);
        }

        @Override // android.content.res.Resources
        public int getInteger(int arg0) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!m");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getInteger(arg0) : super.getInteger(arg0);
        }

        @Override // android.content.res.Resources
        public XmlResourceParser getLayout(int id) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!l");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getLayout(id) : super.getLayout(id);
        }

        @Override // android.content.res.Resources
        public Movie getMovie(int arg0) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!k");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getMovie(arg0) : super.getMovie(arg0);
        }

        @Override // android.content.res.Resources
        public String getQuantityString(int id, int quantity, Object... formatArgs) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!j");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getQuantityString(id, quantity, formatArgs) : super.getQuantityString(id, quantity, formatArgs);
        }

        @Override // android.content.res.Resources
        public String getQuantityString(int id, int quantity) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!i");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getQuantityString(id, quantity) : super.getQuantityString(id, quantity);
        }

        @Override // android.content.res.Resources
        public CharSequence getQuantityText(int id, int quantity) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!h");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getQuantityText(id, quantity) : super.getQuantityText(id, quantity);
        }

        @Override // android.content.res.Resources
        public String getString(int id, Object... formatArgs) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!g");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getString(id, formatArgs) : super.getString(id, formatArgs);
        }

        @Override // android.content.res.Resources
        public String[] getStringArray(int id) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!f");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getStringArray(id) : super.getStringArray(id);
        }

        @Override // android.content.res.Resources
        public CharSequence getText(int id, CharSequence def) {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!e");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getText(id, def) : super.getText(id, def);
        }

        @Override // android.content.res.Resources
        public CharSequence[] getTextArray(int id) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!d");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getTextArray(id) : super.getTextArray(id);
        }

        @Override // android.content.res.Resources
        public void getValue(int id, TypedValue outValue, boolean resolveRefs) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!c");
            if (OperatorTabManager.this.ctx != null) {
                OperatorTabManager.this.ctx.getResources().getValue(id, outValue, resolveRefs);
            } else {
                super.getValue(id, outValue, resolveRefs);
            }
        }

        @Override // android.content.res.Resources
        public void getValue(String name, TypedValue outValue, boolean resolveRefs) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!b");
            if (OperatorTabManager.this.ctx != null) {
                OperatorTabManager.this.ctx.getResources().getValue(name, outValue, resolveRefs);
            } else {
                super.getValue(name, outValue, resolveRefs);
            }
        }

        @Override // android.content.res.Resources
        public XmlResourceParser getXml(int id) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!a");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().getXml(id) : super.getXml(id);
        }

        public boolean isPreloading() {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!0");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().isPreloading() : super.isPreloading();
        }

        @Override // android.content.res.Resources
        public TypedArray obtainAttributes(AttributeSet set, int[] attrs) {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!9");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().obtainAttributes(set, attrs) : super.obtainAttributes(set, attrs);
        }

        @Override // android.content.res.Resources
        public TypedArray obtainTypedArray(int id) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!8");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().obtainTypedArray(id) : super.obtainTypedArray(id);
        }

        @Override // android.content.res.Resources
        public InputStream openRawResource(int arg0, TypedValue arg1) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!7");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().openRawResource(arg0, arg1) : super.openRawResource(arg0, arg1);
        }

        @Override // android.content.res.Resources
        public AssetFileDescriptor openRawResourceFd(int arg0) throws Resources.NotFoundException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!5");
            return OperatorTabManager.this.ctx != null ? OperatorTabManager.this.ctx.getResources().openRawResourceFd(arg0) : super.openRawResourceFd(arg0);
        }

        @Override // android.content.res.Resources
        public void parseBundleExtra(String arg0, AttributeSet arg1, Bundle arg2) throws XmlPullParserException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!4");
            if (OperatorTabManager.this.ctx != null) {
                OperatorTabManager.this.ctx.getResources().parseBundleExtra(arg0, arg1, arg2);
            } else {
                super.parseBundleExtra(arg0, arg1, arg2);
            }
        }

        @Override // android.content.res.Resources
        public void parseBundleExtras(XmlResourceParser arg0, Bundle arg1) throws XmlPullParserException, IOException {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!3");
            if (OperatorTabManager.this.ctx != null) {
                OperatorTabManager.this.ctx.getResources().parseBundleExtras(arg0, arg1);
            } else {
                super.parseBundleExtras(arg0, arg1);
            }
        }

        public void setCompatibilityInfo(CompatibilityInfo ci) {
            TFC.e(OperatorTabManager.TAG, "OperatorTabResources.XXX: ERROR!2");
            if (OperatorTabManager.this.ctx != null) {
                OperatorTabManager.this.ctx.getResources().setCompatibilityInfo(ci);
            } else {
                super.setCompatibilityInfo(ci);
            }
        }
    }
}
