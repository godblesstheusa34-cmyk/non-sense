package com.htc.launcher;

import android.graphics.Point;
import android.graphics.Rect;
import android.util.Log;
import android.view.View;
import com.htc.launcher.CellLayout;
import com.htc.launcher.settings.SettingUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public interface Draggee {
    public static final String LOG_TAG = Draggee.class.getSimpleName();

    Point getCellXY();

    Object getItem();

    ItemInfo getItemInfo();

    Rect getRectInPixels();

    void onDrag();

    void onDrop(DropTarget dropTarget, int i, int i2);

    void onDropAbort(DragSource dragSource);

    public static final class LegacyDraggee implements Draggee {
        private Rect mBounds;
        private View mView;

        public static Draggee wrap(Object item) {
            return new LegacyDraggee((View) item);
        }

        private LegacyDraggee(View view) {
            this.mView = view;
        }

        @Override // com.htc.launcher.Draggee
        public Object getItem() {
            return this.mView;
        }

        @Override // com.htc.launcher.Draggee
        public ItemInfo getItemInfo() {
            if (this.mView == null) {
                return null;
            }
            return (ItemInfo) this.mView.getTag();
        }

        @Override // com.htc.launcher.Draggee
        public Point getCellXY() {
            if (this.mView == null) {
                return null;
            }
            CellLayout.LayoutParams lp = (CellLayout.LayoutParams) this.mView.getLayoutParams();
            return new Point(lp.cellX, lp.cellY);
        }

        @Override // com.htc.launcher.Draggee
        public Rect getRectInPixels() {
            if (this.mView == null) {
                return null;
            }
            if (this.mBounds == null) {
                this.mBounds = new Rect();
            }
            this.mBounds.set(this.mView.getLeft(), this.mView.getTop(), this.mView.getRight(), this.mView.getBottom());
            return this.mBounds;
        }

        @Override // com.htc.launcher.Draggee
        public void onDrop(DropTarget target, int cellX, int cellY) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] LegacyDraggee.onDrop(1)");
            if (this.mView == null) {
                Log.e(LOG_TAG, "Tring to move null item");
                return;
            }
            if (target == null) {
                if (SettingUtil.localLOGD) {
                    Log.d(LOG_TAG, "Drop on null target");
                    return;
                }
                return;
            }
            if (this.mView.getLayoutParams() instanceof CellLayout.LayoutParams) {
                CellLayout.LayoutParams lp = (CellLayout.LayoutParams) this.mView.getLayoutParams();
                lp.cellX = cellX;
                lp.cellY = cellY;
                lp.isDragging = false;
                lp.dropped = true;
            }
            this.mView.requestLayout();
        }

        @Override // com.htc.launcher.Draggee
        public void onDropAbort(DragSource source) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] LegacyDraggee.onDropAbort()");
            if (this.mView != null && (this.mView.getLayoutParams() instanceof CellLayout.LayoutParams)) {
                ((CellLayout.LayoutParams) this.mView.getLayoutParams()).isDragging = false;
            }
        }

        @Override // com.htc.launcher.Draggee
        public void onDrag() {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] LegacyDraggee.onDrag()");
            if (this.mView.getLayoutParams() instanceof CellLayout.LayoutParams) {
                CellLayout.LayoutParams lp = (CellLayout.LayoutParams) this.mView.getLayoutParams();
                lp.isDragging = true;
            }
        }
    }
}
