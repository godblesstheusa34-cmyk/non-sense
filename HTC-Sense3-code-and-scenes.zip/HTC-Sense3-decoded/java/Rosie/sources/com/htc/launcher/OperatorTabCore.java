package com.htc.launcher;

import android.content.ComponentName;
import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public abstract class OperatorTabCore {
    private final List<Application> appList;
    private final String id;
    private final int initOrder;
    private final int initPlace;
    private final HashMap<Locale, String> labelMap;
    private final int minorNb;
    private final File onIconPath;
    private final File overlayIconPath;
    private final File restIconPath;

    public static class Application {
        public final String className;
        private ComponentName component;
        public final String packageName;
        public final int priority;

        public Application(String packageName, String className, int priority) {
            this.packageName = packageName;
            this.className = className;
            this.priority = priority;
        }

        public synchronized ComponentName getComponent() {
            if (this.component == null) {
                this.component = new ComponentName(this.packageName, this.className);
            }
            return this.component;
        }
    }

    protected OperatorTabCore(int minorNb, String id, int initOrder, int initPlace, File restIconPath, File onIconPath, File overlayIconPath, HashMap<Locale, String> labelMap, List<Application> appList) {
        this.minorNb = minorNb;
        this.id = id;
        this.initOrder = initOrder;
        this.initPlace = initPlace;
        this.restIconPath = restIconPath;
        this.onIconPath = onIconPath;
        this.overlayIconPath = overlayIconPath;
        this.labelMap = labelMap;
        this.appList = appList;
    }

    public int getMinorNb() {
        return this.minorNb;
    }

    public String getId() {
        return this.id;
    }

    public int getInitOrder() {
        return this.initOrder;
    }

    public int getInitPlace() {
        return this.initPlace;
    }

    public File getRestIconPath() {
        return this.restIconPath;
    }

    public File getOnIconPath() {
        return this.onIconPath;
    }

    public File getOverlayIconPath() {
        return this.overlayIconPath;
    }

    public String getLabel(Locale locale) {
        return this.labelMap.get(locale);
    }

    public List<Application> getAppList() {
        return this.appList;
    }
}
