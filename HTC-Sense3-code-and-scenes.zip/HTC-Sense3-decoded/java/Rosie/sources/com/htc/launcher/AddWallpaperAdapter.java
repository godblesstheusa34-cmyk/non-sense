package com.htc.launcher;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.htc.launcher.config.DeviceFlag;
import com.htc.launcher.custom.CustomResourceUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class AddWallpaperAdapter extends BaseAdapter {
    private final Context mContext;
    private int mIconHeight;
    private int mIconWidth;
    private final LayoutInflater mInflater;
    boolean mIsPickLockScreenWallpaper;
    PackageManager mPkgMgr;
    private ArrayList<String> mItemName = new ArrayList<>();
    private ArrayList<Drawable> mIconRes = new ArrayList<>();
    protected ArrayList<ResolveInfo> MatchApps = new ArrayList<>();

    public AddWallpaperAdapter(Context context, boolean IsPickLockScreenWallpaper) {
        this.mIsPickLockScreenWallpaper = false;
        this.mContext = context;
        this.mIsPickLockScreenWallpaper = IsPickLockScreenWallpaper;
        this.mInflater = (LayoutInflater) this.mContext.getSystemService("layout_inflater");
        LoadListeItemResource();
        this.mIconWidth = this.mContext.getResources().getDimensionPixelSize(R.dimen.add_to_home_icon_width);
        this.mIconHeight = this.mContext.getResources().getDimensionPixelSize(R.dimen.add_to_home_icon_height);
    }

    private void LoadListeItemResource() {
        this.mPkgMgr = this.mContext.getPackageManager();
        Intent pickWallpaper = new Intent("android.intent.action.SET_WALLPAPER");
        List<ResolveInfo> apps = this.mPkgMgr.queryIntentActivities(pickWallpaper, 0);
        Collections.sort(apps, new Comparator<ResolveInfo>() { // from class: com.htc.launcher.AddWallpaperAdapter.1
            @Override // java.util.Comparator
            public int compare(ResolveInfo item1, ResolveInfo item2) {
                return Utilities.sCollator.compare(((PackageItemInfo) item1.activityInfo).packageName, ((PackageItemInfo) item2.activityInfo).packageName);
            }
        });
        boolean sense20 = Float.parseFloat("3.0") >= 2.0f;
        for (int i = 0; i < apps.size(); i++) {
            String filename = ((PackageItemInfo) apps.get(i).activityInfo).packageName;
            Log.i("AddWallpaperAdapter", "sense=" + sense20 + " ,filename=" + filename);
            if ((!sense20 || !filename.equals("com.android.wallpaper.livepicker")) && (!DeviceFlag.isTabletDevice() || !filename.equals("com.android.launcher"))) {
                if (this.mIsPickLockScreenWallpaper) {
                    if (filename.equals("com.htc.AddProgramWidget") || filename.equals("com.htc.album")) {
                        this.mIconRes.add(apps.get(i).loadIcon(this.mPkgMgr));
                        this.mItemName.add(apps.get(i).loadLabel(this.mPkgMgr).toString());
                        this.MatchApps.add(apps.get(i));
                    }
                } else {
                    this.mIconRes.add(apps.get(i).loadIcon(this.mPkgMgr));
                    this.mItemName.add(apps.get(i).loadLabel(this.mPkgMgr).toString());
                    this.MatchApps.add(apps.get(i));
                }
            }
        }
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.mItemName.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int position) {
        return this.mItemName.get(position);
    }

    @Override // android.widget.Adapter
    public long getItemId(int position) {
        return position;
    }

    @Override // android.widget.Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = this.mInflater.inflate(34144263, parent, false);
            int listSelectorID = CustomResourceUtil.getDrawableResIdentifier(this.mContext, "rosie_list_selector", 0);
            if (listSelectorID != 0) {
                ((ListView) parent).setSelector(listSelectorID);
            }
        }
        TextView textView = (TextView) convertView;
        textView.setText(this.mItemName.get(position));
        Drawable tmpIcon = this.mIconRes.get(position);
        if (tmpIcon != null) {
            tmpIcon.setBounds(0, 0, this.mIconWidth, this.mIconHeight);
            textView.setCompoundDrawables(tmpIcon, null, null, null);
        }
        textView.setCompoundDrawablePadding(15);
        return convertView;
    }

    public ResolveInfo GetMatchResolveInfo(int position) {
        return this.MatchApps.get(position);
    }
}
