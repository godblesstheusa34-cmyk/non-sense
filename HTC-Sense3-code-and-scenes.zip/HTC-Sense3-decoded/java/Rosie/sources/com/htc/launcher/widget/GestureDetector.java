package com.htc.launcher.widget;

import android.content.Context;
import android.os.Handler;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import com.htc.launcher.settings.SettingUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class GestureDetector {
    private android.view.GestureDetector mGestureDetector;
    private final OnMultiTouchListener mListener;
    private ScaleGestureDetector mScaleGestureDetector;
    public static boolean localLOGV = false;
    private static final String TAG = GestureDetector.class.getSimpleName();
    private boolean mIsMultiTouchMode = false;
    private float mScaleFactor = 1.0f;
    private GestureDetector.OnGestureListener mOnGestureListener = new GestureDetector.OnGestureListener() { // from class: com.htc.launcher.widget.GestureDetector.1
        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onDown(MotionEvent e) {
            if (SettingUtil.localLOGD && e != null) {
                Log.d(GestureDetector.TAG, "onDown(), (" + e.getX() + ", " + e.getY() + "), action = " + e.getAction());
                return false;
            }
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onFling(MotionEvent e0, MotionEvent e1, float arg2, float arg3) {
            if (GestureDetector.this.mIsMultiTouchMode) {
                return false;
            }
            if (SettingUtil.localLOGD && e0 != null && e1 != null) {
                Log.d(GestureDetector.TAG, "onFling(" + arg2 + ", " + arg3 + "), (" + e0.getX() + ", " + e0.getY() + "), action = " + e0.getAction() + "(" + e1.getX() + ", " + e0.getY() + "), action = " + e1.getAction());
            }
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onLongPress(MotionEvent ev) {
            if (!GestureDetector.this.mIsMultiTouchMode) {
                if (SettingUtil.localLOGD && ev != null) {
                    Log.d(GestureDetector.TAG, "onLongPress(" + ev.getX() + ", " + ev.getY() + "), action = " + ev.getAction());
                }
                GestureDetector.this.mListener.onLongPress(ev);
            }
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
            if (GestureDetector.this.mIsMultiTouchMode) {
                return false;
            }
            if (SettingUtil.localLOGD && e1 != null && e2 != null) {
                Log.d(GestureDetector.TAG, "onScroll(" + distanceX + ", " + distanceY + "), (" + e1.getX() + ", " + e1.getY() + "), action = " + e1.getAction() + "(" + e2.getX() + ", " + e2.getY() + "), action = " + e2.getAction());
            }
            GestureDetector.this.mListener.onScroll(e1, e2, distanceX, distanceY);
            return false;
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public void onShowPress(MotionEvent ev) {
            if (SettingUtil.localLOGD && ev != null) {
                Log.d(GestureDetector.TAG, "onShowPress(" + ev.getX() + ", " + ev.getY() + "), action = " + ev.getAction());
            }
            GestureDetector.this.mListener.onShowPress(ev);
        }

        @Override // android.view.GestureDetector.OnGestureListener
        public boolean onSingleTapUp(MotionEvent ev) {
            GestureDetector.this.mListener.onSingleTapUp(ev);
            if (SettingUtil.localLOGD && ev != null) {
                Log.d(GestureDetector.TAG, "onSingleTapUp((" + ev.getX() + ", " + ev.getY() + "), action = " + ev.getAction());
                return false;
            }
            return false;
        }
    };
    private ScaleGestureDetector.OnScaleGestureListener mOnScaleGestureListener = new ScaleGestureDetector.OnScaleGestureListener() { // from class: com.htc.launcher.widget.GestureDetector.2
        @Override // android.view.ScaleGestureDetector.OnScaleGestureListener
        public boolean onScale(ScaleGestureDetector arg0) {
            GestureDetector.access$332(GestureDetector.this, arg0.getScaleFactor());
            GestureDetector.this.mListener.onScale(GestureDetector.this.mScaleFactor);
            return true;
        }

        @Override // android.view.ScaleGestureDetector.OnScaleGestureListener
        public boolean onScaleBegin(ScaleGestureDetector ev) {
            if (!GestureDetector.this.mIsMultiTouchMode) {
                GestureDetector.this.mListener.onMultiTouch((ev.getX(0) + ev.getX(1)) / 2.0f, (ev.getY(0) + ev.getY(1)) / 2.0f);
                if (SettingUtil.localLOGD) {
                    Log.d(GestureDetector.TAG, "onScaleBegin()");
                }
            }
            GestureDetector.this.mIsMultiTouchMode = true;
            GestureDetector.access$332(GestureDetector.this, ev.getScaleFactor());
            return true;
        }

        @Override // android.view.ScaleGestureDetector.OnScaleGestureListener
        public void onScaleEnd(ScaleGestureDetector arg0) {
        }
    };

    public interface OnMultiTouchListener {
        boolean onActionCancel(MotionEvent motionEvent);

        boolean onActionUp(MotionEvent motionEvent);

        boolean onLongPress(MotionEvent motionEvent);

        boolean onMultiTouch(float f, float f2);

        boolean onScale(float f);

        boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent2, float f, float f2);

        void onShowPress(MotionEvent motionEvent);

        boolean onSingleTapUp(MotionEvent motionEvent);
    }

    static /* synthetic */ float access$332(GestureDetector x0, float x1) {
        float f = x0.mScaleFactor * x1;
        x0.mScaleFactor = f;
        return f;
    }

    public GestureDetector(Context context, OnMultiTouchListener listener, Handler handler) {
        if (SettingUtil.localLOGD) {
            Log.d("MultiTouchDetector", "MultiTouchDetectorv v0.36");
        }
        this.mListener = listener;
        init(context);
    }

    public GestureDetector(Context context, OnMultiTouchListener listener) {
        if (SettingUtil.localLOGD) {
            Log.d("MultiTouchDetector", "MultiTouchDetector v0.36");
        }
        this.mListener = listener;
        init(context);
    }

    public GestureDetector(Context context, OnMultiTouchListener listener, boolean bAccelerate) {
        if (SettingUtil.localLOGD) {
            Log.d("MultiTouchDetector", "MultiTouchDetector v0.36,bAccelerate=" + bAccelerate);
        }
        this.mListener = listener;
        init(context);
    }

    private void init(Context context) {
        this.mGestureDetector = new android.view.GestureDetector(context, this.mOnGestureListener);
        this.mScaleGestureDetector = new ScaleGestureDetector(context, this.mOnScaleGestureListener);
        if (this.mListener == null) {
            throw new NullPointerException("OnMultiTouchListener must not be null");
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:3:0x0013, code lost:
    
        return false;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public boolean onTouchEvent(MotionEvent ev) {
        int action = ev.getAction();
        this.mScaleGestureDetector.onTouchEvent(ev);
        this.mGestureDetector.onTouchEvent(ev);
        switch (action) {
            case 0:
                this.mIsMultiTouchMode = false;
                break;
            case 1:
                if (SettingUtil.localLOGD) {
                    Log.d(TAG, "ACTION_UP");
                }
                this.mIsMultiTouchMode = false;
                this.mListener.onActionUp(ev);
                this.mScaleFactor = 1.0f;
                break;
            case 3:
                if (SettingUtil.localLOGD) {
                    Log.d(TAG, "ACTION_CANCEL");
                }
                this.mIsMultiTouchMode = false;
                this.mListener.onActionCancel(ev);
                break;
        }
    }

    public void cancelGesture() {
        this.mScaleGestureDetector.onTouchEvent(MotionEvent.obtain(System.currentTimeMillis(), System.currentTimeMillis(), 3, 0.0f, 0.0f, 0));
    }
}
