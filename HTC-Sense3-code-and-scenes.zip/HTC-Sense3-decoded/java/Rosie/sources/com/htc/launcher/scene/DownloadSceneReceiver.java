package com.htc.launcher.scene;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.FileUtils;
import com.htc.launcher.WidgetWorkspaceManager;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class DownloadSceneReceiver extends BroadcastReceiver {
    private static final String ACTION_DOWNLOAD_COMPLETE = "com.htc.launcher.scene.ACTION_DOWNLOAD_COMPLETE";
    public static final String ACTION_DOWNLOAD_SCENE_SAVED = "com.htc.launcher.scene.ACTION_DOWNLOAD_SCENE_SAVED";
    public static final String ACTION_UPDATE_SCENE = "com.htc.launcher.scene.ACTION_UPDATE_SCENE";
    public static final String EXTRA_DOWNLOAD_SCENE_ID = "com.htc.launcher.scene.EXTRA_SCENE_ID";
    private static final String EXTRA_LOCALIZED_NAME = "com.htc.launcher.scene.LOCALIZED_SCENE_NAME";
    public static final String EXTRA_ONLINE_SCENE_ID = "com.htc.launcher.scene.ONLINE_SCENE_ID";
    private static final String EXTRA_PREVIEW_LAND_PATH = "com.htc.launcher.scene.PREVIEW_LAND_PATH";
    private static final String EXTRA_PREVIEW_PATH = "com.htc.launcher.scene.PREVIEW_PATH";
    private static final String EXTRA_SCENE_PATH = "com.htc.launcher.scene.SCENE_PATH";
    private static final String EXTRA_THUMBNAIL_LAND_PATH = "com.htc.launcher.scene.THUMBNAIL_LAND_PATH";
    private static final String EXTRA_THUMBNAIL_PATH = "com.htc.launcher.scene.THUMBNAIL_PATH";
    private static final String TAG = "DownloadSceneReceiver";
    private static final boolean localLOG = false;

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        SaveSceneThread saveSceneThread = new SaveSceneThread(context, intent);
        saveSceneThread.start();
    }

    private class SaveSceneThread extends Thread {
        private Context mContext;
        private Intent mIntent;

        public SaveSceneThread(Context context, Intent intent) {
            this.mContext = context;
            this.mIntent = intent;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            super.run();
            DownloadSceneReceiver.this.saveSceneData(this.mContext, this.mIntent);
            this.mContext = null;
            this.mIntent = null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void saveSceneData(Context context, Intent intent) {
        System.currentTimeMillis();
        int sceneId = -1;
        String onlineSceneId = null;
        try {
            try {
                String filePath = intent.getStringExtra(EXTRA_SCENE_PATH);
                String previewPath = intent.getStringExtra(EXTRA_PREVIEW_PATH);
                String thumbnailPath = intent.getStringExtra(EXTRA_THUMBNAIL_PATH);
                String previewLandPath = intent.getStringExtra(EXTRA_PREVIEW_LAND_PATH);
                intent.getStringExtra(EXTRA_THUMBNAIL_LAND_PATH);
                onlineSceneId = intent.getStringExtra(EXTRA_ONLINE_SCENE_ID);
                String localizedName = intent.getStringExtra(EXTRA_LOCALIZED_NAME);
                if (filePath != null) {
                    if (filePath.endsWith("zip")) {
                        ZipFile zipFile = new ZipFile(filePath);
                        Enumeration<? extends ZipEntry> entries = zipFile.entries();
                        InputStream xmlInputStream = null;
                        InputStream wallpaperStream = null;
                        while (entries.hasMoreElements()) {
                            ZipEntry entry = entries.nextElement();
                            String entryName = entry.getName();
                            if (entryName.endsWith(".xml")) {
                                xmlInputStream = zipFile.getInputStream(entry);
                            } else {
                                wallpaperStream = zipFile.getInputStream(entry);
                            }
                        }
                        InputStreamReader reader = new InputStreamReader(xmlInputStream);
                        sceneId = XmlUtils.startParsing(context, reader, previewPath, thumbnailPath, localizedName);
                        FileUtils.copyToFile(wallpaperStream, new File("/data/data/com.htc.launcher/files/home_wallpaper_" + sceneId));
                        wallpaperStream.close();
                        xmlInputStream.close();
                    } else {
                        FileReader reader2 = new FileReader(filePath);
                        sceneId = XmlUtils.startParsing(context, reader2, previewPath, thumbnailPath, localizedName);
                    }
                    if (previewPath != null) {
                        File src = new File(previewPath);
                        File dest = new File(ScenePickerAdapter.PREVIEW_PATH + sceneId + ".png");
                        if (src.exists()) {
                            FileUtils.copyFile(src, dest);
                        }
                    }
                    if (previewLandPath != null) {
                        File src2 = new File(previewLandPath);
                        File dest2 = new File(ScenePickerAdapter.PREVIEW_PATH_LAND + sceneId + ".png");
                        if (src2.exists()) {
                            FileUtils.copyFile(src2, dest2);
                        }
                    }
                    WidgetWorkspaceManager widgetWorkspaceManager = WidgetWorkspaceManager.instance(context);
                    widgetWorkspaceManager.reset(context);
                }
                Intent saveCompleteIntent = new Intent(ACTION_DOWNLOAD_SCENE_SAVED);
                saveCompleteIntent.putExtra(EXTRA_DOWNLOAD_SCENE_ID, sceneId);
                saveCompleteIntent.putExtra(EXTRA_ONLINE_SCENE_ID, onlineSceneId);
                context.sendBroadcast(saveCompleteIntent);
            } catch (IOException e) {
                e.printStackTrace();
                Intent saveCompleteIntent2 = new Intent(ACTION_DOWNLOAD_SCENE_SAVED);
                saveCompleteIntent2.putExtra(EXTRA_DOWNLOAD_SCENE_ID, sceneId);
                saveCompleteIntent2.putExtra(EXTRA_ONLINE_SCENE_ID, onlineSceneId);
                context.sendBroadcast(saveCompleteIntent2);
            } catch (XmlPullParserException e2) {
                e2.printStackTrace();
                Intent saveCompleteIntent3 = new Intent(ACTION_DOWNLOAD_SCENE_SAVED);
                saveCompleteIntent3.putExtra(EXTRA_DOWNLOAD_SCENE_ID, sceneId);
                saveCompleteIntent3.putExtra(EXTRA_ONLINE_SCENE_ID, onlineSceneId);
                context.sendBroadcast(saveCompleteIntent3);
            }
        } catch (Throwable th) {
            Intent saveCompleteIntent4 = new Intent(ACTION_DOWNLOAD_SCENE_SAVED);
            saveCompleteIntent4.putExtra(EXTRA_DOWNLOAD_SCENE_ID, sceneId);
            saveCompleteIntent4.putExtra(EXTRA_ONLINE_SCENE_ID, onlineSceneId);
            context.sendBroadcast(saveCompleteIntent4);
            throw th;
        }
    }
}
