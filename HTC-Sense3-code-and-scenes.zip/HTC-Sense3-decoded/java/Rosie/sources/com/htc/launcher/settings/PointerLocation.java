package com.htc.launcher.settings;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import java.util.ArrayList;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class PointerLocation {
    private boolean mCurDown;
    private int mCurNumPointers;
    private int mHeight;
    private int mMaxNumPointers;
    private Paint mPathPaint;
    private Paint mTargetPaint;
    private int mWidth;
    private ArrayList<PointerState> mPointers = new ArrayList<>();
    private Paint mPaint = new Paint();

    public PointerLocation(int width, int height) {
        this.mWidth = width;
        this.mHeight = height;
        this.mPaint.setAntiAlias(true);
        this.mPaint.setARGB(255, 255, 255, 255);
        this.mPaint.setStyle(Paint.Style.STROKE);
        this.mPaint.setStrokeWidth(2.0f);
        this.mTargetPaint = new Paint();
        this.mTargetPaint.setAntiAlias(false);
        this.mTargetPaint.setARGB(255, 0, 0, 192);
        this.mPathPaint = new Paint();
        this.mPathPaint.setAntiAlias(false);
        this.mPathPaint.setARGB(255, 0, 96, 255);
        this.mPaint.setStyle(Paint.Style.STROKE);
        this.mPaint.setStrokeWidth(1.0f);
        this.mPaint.setTextSize(30.0f);
        PointerState ps = new PointerState();
        ps.mVelocity = VelocityTracker.obtain();
        this.mPointers.add(ps);
    }

    public void DrawPointerLocation(Canvas canvas) {
        int NP = this.mPointers.size();
        for (int p = 0; p < NP; p++) {
            PointerState ps = this.mPointers.get(p);
            if (this.mCurDown && ps.mCurDown) {
                canvas.drawLine(0.0f, ps.mCurY, getWidth(), ps.mCurY, this.mTargetPaint);
                canvas.drawLine(ps.mCurX, 0.0f, ps.mCurX, getHeight(), this.mTargetPaint);
                int pressureLevel = (int) (ps.mCurPressure * 255.0f);
                this.mPaint.setARGB(255, pressureLevel, 128, 255 - pressureLevel);
                canvas.drawPoint(ps.mCurX, ps.mCurY, this.mPaint);
                canvas.drawCircle(ps.mCurX, ps.mCurY, ps.mCurWidth, this.mPaint);
            }
        }
        for (int p2 = 0; p2 < NP; p2++) {
            PointerState ps2 = this.mPointers.get(p2);
            int N = ps2.mXs.size();
            float lastX = 0.0f;
            float lastY = 0.0f;
            boolean haveLast = false;
            boolean drawn = false;
            this.mPaint.setARGB(255, 128, 255, 255);
            for (int i = 0; i < N; i++) {
                float x = ((Float) ps2.mXs.get(i)).floatValue();
                float y = ((Float) ps2.mYs.get(i)).floatValue();
                if (Float.isNaN(x)) {
                    haveLast = false;
                } else {
                    if (haveLast) {
                        canvas.drawLine(lastX, lastY, x, y, this.mPathPaint);
                        canvas.drawPoint(lastX, lastY, this.mPaint);
                        drawn = true;
                    }
                    lastX = x;
                    lastY = y;
                    haveLast = true;
                }
            }
            if (drawn) {
                if (ps2.mVelocity != null) {
                    this.mPaint.setARGB(255, 255, 64, 128);
                    float xVel = ps2.mVelocity.getXVelocity() * 16.0f;
                    float yVel = ps2.mVelocity.getYVelocity() * 16.0f;
                    canvas.drawLine(lastX, lastY, lastX + xVel, lastY + yVel, this.mPaint);
                    canvas.drawText(Integer.toString((int) (ps2.mVelocity.getXVelocity() * 1000.0f)), canvas.getWidth() / 2, canvas.getHeight() / 2, this.mPaint);
                } else {
                    canvas.drawPoint(lastX, lastY, this.mPaint);
                }
            }
        }
    }

    int getWidth() {
        return this.mWidth;
    }

    int getHeight() {
        return this.mHeight;
    }

    public boolean PointerLocationTouchEvent(MotionEvent event) {
        int action = event.getAction();
        int NP = this.mPointers.size();
        if (action == 0) {
            for (int p = 0; p < NP; p++) {
                PointerState ps = this.mPointers.get(p);
                ps.mXs.clear();
                ps.mYs.clear();
                ps.mVelocity = VelocityTracker.obtain();
                ps.mCurDown = false;
            }
            this.mPointers.get(0).mCurDown = true;
            this.mMaxNumPointers = 0;
        }
        if ((action & 255) == 5) {
            int id = (65280 & action) >> 8;
            while (NP <= id) {
                PointerState ps2 = new PointerState();
                ps2.mVelocity = VelocityTracker.obtain();
                this.mPointers.add(ps2);
                NP++;
            }
            PointerState ps3 = this.mPointers.get(id);
            ps3.mVelocity = VelocityTracker.obtain();
            ps3.mCurDown = true;
        }
        int NI = event.getPointerCount();
        this.mCurDown = (action == 1 || action == 3) ? false : true;
        this.mCurNumPointers = this.mCurDown ? NI : 0;
        if (this.mMaxNumPointers < this.mCurNumPointers) {
            this.mMaxNumPointers = this.mCurNumPointers;
        }
        for (int i = 0; i < NI; i++) {
            PointerState ps4 = this.mPointers.get(event.getPointerId(i));
            ps4.mVelocity.addMovement(event);
            ps4.mVelocity.computeCurrentVelocity(1);
            int N = event.getHistorySize();
            for (int j = 0; j < N; j++) {
                ps4.mXs.add(Float.valueOf(event.getHistoricalX(i, j)));
                ps4.mYs.add(Float.valueOf(event.getHistoricalY(i, j)));
            }
            ps4.mXs.add(Float.valueOf(event.getX(i)));
            ps4.mYs.add(Float.valueOf(event.getY(i)));
            ps4.mCurX = (int) event.getX(i);
            ps4.mCurY = (int) event.getY(i);
            ps4.mCurPressure = event.getPressure(i);
            ps4.mCurSize = event.getSize(i);
            ps4.mCurWidth = (int) (ps4.mCurSize * (getWidth() / 3));
        }
        if ((action & 255) == 6) {
            PointerState ps5 = this.mPointers.get((65280 & action) >> 8);
            ps5.mXs.add(Float.valueOf(Float.NaN));
            ps5.mYs.add(Float.valueOf(Float.NaN));
            ps5.mCurDown = false;
        }
        if (action == 1) {
            for (int i2 = 0; i2 < NI; i2++) {
                PointerState ps6 = this.mPointers.get(event.getPointerId(i2));
                if (ps6.mCurDown) {
                    ps6.mCurDown = false;
                }
            }
            return true;
        }
        return true;
    }

    public static class PointerState {
        private boolean mCurDown;
        private float mCurPressure;
        private float mCurSize;
        private int mCurWidth;
        private int mCurX;
        private int mCurY;
        private VelocityTracker mVelocity;
        private final ArrayList<Float> mXs = new ArrayList<>();
        private final ArrayList<Float> mYs = new ArrayList<>();
    }
}
