package com.htc.launcher;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.text.Layout;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.htc.launcher.FxShortcutInfo;
import com.htc.launcher.custom.CustomResourceUtil;
import java.lang.ref.WeakReference;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class BubbleTextView extends TextView implements FxShortcutInfo.Observer {
    private static final float CORNER_RADIUS = 10.0f;
    private static final float PADDING_H = 5.0f;
    private static final float PADDING_V = 1.0f;
    private Drawable mBackground;
    private boolean mBackgroundSizeChanged;
    private float mCornerRadius;
    private float mPaddingH;
    private float mPaddingV;
    private Paint mPaint;
    private final RectF mRect;
    private Drawable mTextBubble;

    public BubbleTextView(Context context) {
        super(context);
        this.mRect = new RectF();
        init();
    }

    public BubbleTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mRect = new RectF();
        init();
    }

    public BubbleTextView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mRect = new RectF();
        init();
    }

    private void init() {
        float scale = getContext().getResources().getDisplayMetrics().density;
        setGravity(1);
        setFocusable(true);
        this.mBackground = getContext().getResources().getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "rosie_shortcut_selector", R.drawable.shortcut_selector));
        setBackgroundDrawable(null);
        this.mBackground.setCallback(this);
        this.mPaint = new Paint(1);
        this.mPaint.setColor(getContext().getResources().getColor(CustomResourceUtil.getColorResIdentifier(((View) this).mContext, "rosie_bubble_dark_background", R.color.bubble_dark_background)));
        this.mTextBubble = getContext().getResources().getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "common_label", 34078791));
        this.mCornerRadius = CORNER_RADIUS * scale;
        this.mPaddingH = PADDING_H * scale;
        this.mPaddingV = PADDING_V * scale;
        if (this.mPaddingV >= PADDING_V) {
            this.mPaddingV = PADDING_V;
        } else if (this.mPaddingV < PADDING_V) {
            this.mPaddingV = 0.0f;
        }
        if (CustomResourceUtil.getIntegerResIdentifier(((View) this).mContext, "rosie_bubbletextview_shadowRadius", 0) != 0) {
            setShadowLayer(getResources().getInteger(CustomResourceUtil.getIntegerResIdentifier(((View) this).mContext, "rosie_bubbletextview_shadowRadius", 1)), getResources().getInteger(CustomResourceUtil.getIntegerResIdentifier(((View) this).mContext, "rosie_bubbletextview_shadowDx", 0)), getResources().getInteger(CustomResourceUtil.getIntegerResIdentifier(((View) this).mContext, "rosie_bubbletextview_shadowDy", 0)), getResources().getColor(R.color.bubble_text_shadowColor));
        }
    }

    @Override // android.widget.TextView
    protected boolean setFrame(int left, int top, int right, int bottom) {
        if (((View) this).mLeft != left || ((View) this).mRight != right || ((View) this).mTop != top || ((View) this).mBottom != bottom) {
            this.mBackgroundSizeChanged = true;
        }
        return super.setFrame(left, top, right, bottom);
    }

    @Override // android.widget.TextView, android.view.View
    protected boolean verifyDrawable(Drawable who) {
        return who == this.mBackground || super.verifyDrawable(who);
    }

    @Override // android.widget.TextView, android.view.View
    protected void drawableStateChanged() {
        Drawable d = this.mBackground;
        if (d != null && d.isStateful()) {
            d.setState(getDrawableState());
        }
        super.drawableStateChanged();
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        try {
            Drawable background = this.mBackground;
            if (background != null) {
                int scrollX = ((View) this).mScrollX;
                int scrollY = ((View) this).mScrollY;
                if (this.mBackgroundSizeChanged) {
                    background.setBounds(0, 0, ((View) this).mRight - ((View) this).mLeft, ((View) this).mBottom - ((View) this).mTop);
                    this.mBackgroundSizeChanged = false;
                }
                if ((scrollX | scrollY) == 0) {
                    background.draw(canvas);
                } else {
                    canvas.translate(scrollX, scrollY);
                    background.draw(canvas);
                    canvas.translate(-scrollX, -scrollY);
                }
            }
            Layout layout = getLayout();
            RectF rect = this.mRect;
            int left = getCompoundPaddingLeft();
            if (layout == null) {
                int top = getCompoundPaddingTop();
                rect.set((left + 0) - this.mPaddingH, top - this.mPaddingV, Math.min(left + this.mPaddingH, (((View) this).mScrollX + ((View) this).mRight) - ((View) this).mLeft), top + this.mPaddingV);
            } else {
                int top2 = getExtendedPaddingTop();
                rect.set((left + layout.getLineLeft(0)) - this.mPaddingH, (layout.getLineTop(0) + top2) - this.mPaddingV, Math.min(left + layout.getLineRight(0) + this.mPaddingH, (((View) this).mScrollX + ((View) this).mRight) - ((View) this).mLeft), layout.getLineBottom(0) + top2 + this.mPaddingV);
            }
            if (this.mTextBubble != null) {
                this.mTextBubble.draw(canvas);
            }
            super.draw(canvas);
        } catch (NullPointerException e) {
            Log.w("Rosie", "BubbleTextView mLayout null");
            e.printStackTrace();
        }
    }

    public void OnDeskTopOrientationChanged(int Ori) {
        Resources res = getResources();
        ViewGroup parent = (ViewGroup) getParent();
        if (parent != null && (parent instanceof LegacyLayout)) {
            ViewGroup.MarginLayoutParams BTParams = (ViewGroup.MarginLayoutParams) parent.getLayoutParams();
            BTParams.leftMargin = res.getDimensionPixelSize(R.dimen.application_shortcut_margin_left);
            BTParams.rightMargin = res.getDimensionPixelSize(R.dimen.application_shortcut_margin_right);
            BTParams.topMargin = res.getDimensionPixelSize(R.dimen.application_shortcut_margin_top);
            BTParams.bottomMargin = res.getDimensionPixelSize(R.dimen.application_shortcut_margin_bottom);
        }
        setBackgroundDrawable(getContext().getResources().getDrawable(CustomResourceUtil.getDrawableResIdentifier(((View) this).mContext, "rosie_shortcut_selector", R.drawable.shortcut_selector)));
        setCompoundDrawablePadding(res.getDimensionPixelSize(R.dimen.desktop_drawable_padding));
        getLayoutParams().height = -1;
        getLayoutParams().width = -1;
        ((View) this).mPaddingTop = res.getDimensionPixelSize(R.dimen.desktop_bubble_padding_top);
        ((View) this).mPaddingLeft = res.getDimensionPixelSize(R.dimen.desktop_bubble_padding_left);
        ((View) this).mPaddingRight = res.getDimensionPixelSize(R.dimen.desktop_bubble_padding_right);
        setGravity(1);
    }

    @Override // android.view.View
    public void setTag(Object tag) {
        super.setTag(tag);
        if (tag instanceof ApplicationInfo) {
            ((ApplicationInfo) tag).setObserver(this);
        }
    }

    @Override // com.htc.launcher.FxShortcutInfo.Observer
    public void onIconUpdate(int id, Drawable icon, CharSequence title) {
        PendingUIUpdate.instance().postPending(id, new IconUpdateRunnable(this, title, icon));
    }

    private static class IconUpdateRunnable implements Runnable {
        private WeakReference<Drawable> mRefIcon;
        private WeakReference<BubbleTextView> mRefView;
        private CharSequence mTitle;

        public IconUpdateRunnable(BubbleTextView view, CharSequence title, Drawable icon) {
            this.mRefView = new WeakReference<>(view);
            this.mTitle = title;
            this.mRefIcon = new WeakReference<>(icon);
        }

        @Override // java.lang.Runnable
        public void run() {
            BubbleTextView view = this.mRefView.get();
            if (view != null) {
                if (this.mRefIcon.get() != null) {
                    view.setCompoundDrawablesWithIntrinsicBounds((Drawable) null, this.mRefIcon.get(), (Drawable) null, (Drawable) null);
                } else {
                    Log.e(BubbleTextView.class.getSimpleName(), "The shortcut icon(" + ((Object) this.mTitle) + ") is GC.");
                }
                if (this.mTitle != null) {
                    view.setText(this.mTitle);
                }
            }
        }
    }
}
