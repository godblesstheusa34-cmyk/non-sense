package com.htc.launcher.scene;

import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.FileUtils;
import android.util.Log;
import com.htc.android.rosie.home.HostWidgetManager;
import com.htc.launcher.ApplicationInfo;
import com.htc.launcher.FxItemInfo;
import com.htc.launcher.Launcher;
import com.htc.launcher.LauncherModel;
import com.htc.launcher.LauncherSettings;
import com.htc.launcher.Widget;
import com.htc.launcher.WidgetItem;
import com.htc.launcher.WidgetPackageManager;
import com.htc.launcher.config.FavoriteData;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class XmlUtils {
    private static final String CELL_X = "cell_x";
    private static final String CELL_Y = "cell_y";
    private static final String CLASS_NAME = "className";
    private static final String COMPONENT = "component";
    private static final String DISPLAY_NAME = "display_name";
    private static final String FILENAME = "filename";
    private static final String GUID = "guid";
    private static final String ID = "_id";
    private static final String ITEM = "item";
    private static final String ITEM_TYPE = "itemType";
    private static final String LOCKSCREEN = "lockscreen";
    private static final String NAME = "name";
    private static final String PACKAGE_NAME = "packageName";
    private static final String PREFIX_PROPERTY = "property.";
    private static final String PROVIDER_NAME = "providerName";
    private static final String SCENE = "scene";
    private static final String SCREEN = "screen";
    private static final String SKIN = "skin";
    private static final String SPAN_X = "span_x";
    private static final String SPAN_Y = "span_y";
    private static final String WALLPAPER = "wallpaper";
    private static final String WIDGET_NAME = "widgetName";
    private static final String XML_TAG = "XmlUtils";
    private static final boolean localLOG = false;
    private static XmlUtils sInstances;
    private static final Uri SCENE_CONTENT_URI = Uri.parse("content://com.htc.launcher.settings/widget_workspaces?notify=true");
    private static final Uri FAVORITE_CONTENT_URI = Uri.parse("content://com.htc.launcher.settings/favorites?notify=false");
    private static HostWidgetManager mFxWidgetManager = null;

    private XmlUtils() {
    }

    public static XmlUtils instance() {
        if (sInstances == null) {
            sInstances = new XmlUtils();
        }
        return sInstances;
    }

    public void setFxWidgetManager(HostWidgetManager manager) {
        mFxWidgetManager = manager;
    }

    public static int startParsing(Context context, Reader input, String prievewPath, String thumbnailPath, String localizedName) throws XmlPullParserException, IOException {
        XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
        XmlPullParser xpp = factory.newPullParser();
        xpp.setInput(input);
        return startParsing(context, xpp, localizedName);
    }

    public static int startParsing(Context context, int resId, String prievewPath, String thumbnailPath) throws XmlPullParserException, IOException {
        XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
        factory.newPullParser();
        XmlPullParser xpp = context.getResources().getXml(resId);
        return startParsing(context, xpp, null);
    }

    private static synchronized int startParsing(Context context, XmlPullParser xpp, String localizedName) throws XmlPullParserException, IOException {
        int saveWorkspace;
        synchronized (XmlUtils.class) {
            Entry entry = new Entry();
            int eventType = xpp.getEventType();
            while (eventType != 1) {
                if (eventType == 2) {
                    entry = getEntry(xpp, entry);
                }
                xpp.next();
                eventType = xpp.getEventType();
            }
            saveWorkspace = saveWorkspace(context, entry, localizedName);
        }
        return saveWorkspace;
    }

    private static Entry getEntry(XmlPullParser xpp, Entry entry) throws XmlPullParserException, IOException {
        entry.setTag(xpp.getName());
        int attributeCount = xpp.getAttributeCount();
        for (int i = 0; i < attributeCount; i++) {
            entry.addInfo(xpp.getAttributeName(i), xpp.getAttributeValue(i));
        }
        xpp.next();
        int eventType = xpp.getEventType();
        while (eventType != 3) {
            if (eventType == 2) {
                entry.addEntry(getEntry(xpp, new Entry()));
            }
            xpp.next();
            eventType = xpp.getEventType();
        }
        return entry;
    }

    private static int saveWorkspace(Context context, Entry e, String localizedName) {
        ContentResolver cr = context.getContentResolver();
        int sceneId = requestSceneId(cr);
        saveSceneInfo(cr, e, sceneId, localizedName);
        saveSceneWallpaper(context, e, sceneId);
        saveSceneWidgets(context, cr, e, sceneId);
        return sceneId;
    }

    private static void saveSceneWallpaper(Context context, Entry e, int sceneId) {
        Bundle itemInfo;
        ArrayList<Entry> entries = e.getEntries();
        if (entries != null) {
            Iterator i$ = entries.iterator();
            while (i$.hasNext()) {
                Entry entry = i$.next();
                if (WALLPAPER.equals(entry.getTag()) && (itemInfo = entry.getInfo()) != null) {
                    String fileName = itemInfo.getString(FILENAME);
                    String guid = itemInfo.getString(GUID);
                    String component = itemInfo.getString(COMPONENT);
                    if (fileName != null) {
                        String guid2 = WidgetPackageManager.manipulateResourcePath(fileName);
                        File src = new File(guid2);
                        if (src.exists()) {
                            FileUtils.copyFile(src, new File("/data/data/com.htc.launcher/files/home_wallpaper_" + sceneId));
                        } else {
                            Log.w(XML_TAG, "cannot find build in wallpaper(" + fileName + "), we use default wallpaper");
                            FileUtils.copyFile(new File(WidgetPackageManager.manipulateResourcePath("htc_wallpaper_06.jpg")), new File("/data/data/com.htc.launcher/files/home_wallpaper_" + sceneId));
                        }
                    } else if (guid != null) {
                        FileUtils.copyFile(new File(WidgetPackageManager.manipulateResourcePath("htc_wallpaper_06.jpg")), new File("/data/data/com.htc.launcher/files/home_wallpaper_" + sceneId));
                    } else if (component != null) {
                        ContentResolver contentResolver = context.getContentResolver();
                        ContentValues values = new ContentValues();
                        values.put(LauncherSettings.WidgetWorkspace.WALLPAPER_COMPONENT, component);
                        contentResolver.update(LauncherSettings.WidgetWorkspace.getContentUri(sceneId, false), values, null, null);
                    }
                }
            }
        }
    }

    private static void saveSceneWidgets(Context context, ContentResolver cr, Entry e, int sceneId) {
        ContentValues v;
        ArrayList<Entry> entries = e.getEntries();
        ArrayList<ContentValues> items = new ArrayList<>();
        ArrayList<ComponentName> bindTarget = new ArrayList<>();
        ArrayList<Integer> bindSource = new ArrayList<>();
        Iterator i$ = entries.iterator();
        while (i$.hasNext()) {
            Entry entry = i$.next();
            if (ITEM.equals(entry.getTag())) {
                Bundle itemInfo = entry.getInfo();
                String itemType = itemInfo.getString("itemType");
                if ("application".equals(itemType)) {
                    createApplicationValues(context, itemInfo, sceneId);
                } else if ("htc_widget".equals(itemType)) {
                    createHtcWidgetValues(context, itemInfo, sceneId);
                } else if ("htc_fx_widget".equals(itemType)) {
                    createHtcFxWidgetValues(context, itemInfo, sceneId);
                } else if ("app_widget".equals(itemType) && (v = createAppwidgetValues(itemInfo, sceneId, bindSource, bindTarget, context)) != null) {
                    items.add(v);
                }
            }
        }
        Iterator i$2 = items.iterator();
        while (i$2.hasNext()) {
            ContentValues values = i$2.next();
            cr.insert(FAVORITE_CONTENT_URI, values);
        }
        int[] sourceArray = new int[bindSource.size()];
        for (int i = 0; i < bindSource.size(); i++) {
            sourceArray[i] = bindSource.get(i).intValue();
        }
        int i2 = sourceArray.length;
        if (i2 > 0) {
            WidgetPackageManager.launchAppWidgetBinder(context, sourceArray, bindTarget);
        }
    }

    private static void createApplicationValues(Context context, Bundle info, int workspaceId) {
        String packageName = info.getString(PACKAGE_NAME);
        String className = info.getString(CLASS_NAME);
        String screen = info.getString("screen");
        String cell_x = info.getString(CELL_X);
        String cell_y = info.getString(CELL_Y);
        FavoriteData favdata = new FavoriteData();
        favdata.packageName = packageName;
        favdata.className = className;
        favdata.workspaceId = workspaceId;
        favdata.itemtype = 0;
        int workspaceId2 = Integer.parseInt(screen);
        favdata.screen = workspaceId2;
        favdata.x = Integer.parseInt(cell_x);
        favdata.y = Integer.parseInt(cell_y);
        ApplicationInfo app = LauncherModel.getApplication(favdata, context);
        if (app != null) {
            LauncherModel.initAddItemToDatabase(context, app, -100L, app.screen, app.cellX, app.cellY, false);
        } else {
            Log.d(XML_TAG, "Application: getApplication fail");
        }
    }

    private static void createHtcWidgetValues(Context context, Bundle info, int workspaceId) {
        String packageName = info.getString(PACKAGE_NAME);
        String widgetName = info.getString(WIDGET_NAME);
        String screen = info.getString("screen");
        String cell_x = info.getString(CELL_X);
        String cell_y = info.getString(CELL_Y);
        WidgetPackageManager widgetPackageManager = WidgetPackageManager.instance(context);
        WidgetItem item = widgetPackageManager.getWidgetItem(packageName, widgetName);
        if (item == null) {
            Log.w(XML_TAG, "package/widget not found : " + packageName + "/" + widgetName);
            return;
        }
        try {
            int intScreen = Integer.parseInt(screen);
            int intCellX = Integer.parseInt(cell_x);
            int intCellY = Integer.parseInt(cell_y);
            Widget widget = item.newWidget();
            widget.setWorkspaceId(workspaceId);
            Set<String> ketSet = info.keySet();
            Properties props = null;
            for (String key : ketSet) {
                if (key != null && key.startsWith(PREFIX_PROPERTY)) {
                    if (props == null) {
                        props = new Properties();
                    }
                    String realKey = key.substring(PREFIX_PROPERTY.length());
                    props.setProperty(realKey, info.getString(key));
                }
                props = props;
            }
            if (props != null) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                ObjectOutputStream out2 = new ObjectOutputStream(out);
                out2.writeObject(props);
                widget.props = out.toByteArray();
            }
            LauncherModel.initAddItemToDatabase(context, widget, -100L, intScreen, intCellX, intCellY, false);
        } catch (Exception e) {
            Log.w(XML_TAG, "package/widget fail to added : " + packageName + "/" + widgetName);
        }
    }

    private static void createHtcFxWidgetValues(Context context, Bundle info, int workspaceId) {
        String packageName = info.getString(PACKAGE_NAME);
        String providerName = packageName + "/" + info.getString(PROVIDER_NAME);
        String widgetName = packageName + "/" + info.getString(WIDGET_NAME);
        String screen = info.getString("screen");
        String cell_x = info.getString(CELL_X);
        String cell_y = info.getString(CELL_Y);
        String span_x = info.getString("span_x");
        String span_y = info.getString("span_y");
        try {
            FxItemInfo fxInfo = new FxItemInfo(providerName, widgetName);
            fxInfo.widgetId = mFxWidgetManager.allocWidgetId();
            fxInfo.data = null;
            fxInfo.screen = Integer.parseInt(screen);
            fxInfo.cellX = Integer.parseInt(cell_x);
            fxInfo.cellY = Integer.parseInt(cell_y);
            fxInfo.spanX = Integer.parseInt(span_x);
            fxInfo.spanY = Integer.parseInt(span_y);
            fxInfo.workspaceId = workspaceId;
            Set<String> ketSet = info.keySet();
            Properties props = null;
            for (String key : ketSet) {
                if (key != null && key.startsWith(PREFIX_PROPERTY)) {
                    if (props == null) {
                        props = new Properties();
                    }
                    String realKey = key.substring(PREFIX_PROPERTY.length());
                    props.setProperty(realKey, info.getString(key));
                }
                props = props;
            }
            if (props != null) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                ObjectOutputStream out2 = new ObjectOutputStream(out);
                out2.writeObject(props);
                fxInfo.data = out.toByteArray();
            }
            LauncherModel.initAddItemToDatabase(context, fxInfo, -100L, fxInfo.screen, fxInfo.cellX, fxInfo.cellY, false);
        } catch (Exception ex) {
            Log.w(XML_TAG, "package/widget fail to added : " + widgetName + "," + ex.toString());
        }
    }

    private static ContentValues createAppwidgetValues(Bundle info, int workspaceId, ArrayList<Integer> bindSource, ArrayList<ComponentName> bindTargets, Context ctx) {
        String packageName = info.getString(PACKAGE_NAME);
        String className = info.getString(CLASS_NAME);
        String screen = info.getString("screen");
        String cell_x = info.getString(CELL_X);
        String cell_y = info.getString(CELL_Y);
        String span_x = info.getString("span_x");
        String span_y = info.getString("span_y");
        int appwidgetId = Launcher.getDefaultAppWidgetHostInstance(ctx).allocateAppWidgetId();
        ContentValues values = new ContentValues();
        values.put("container", (Integer) (-100));
        values.put("screen", Integer.valueOf(screen));
        values.put(LauncherSettings.Favorites.CELLX, Integer.valueOf(cell_x));
        values.put(LauncherSettings.Favorites.CELLY, Integer.valueOf(cell_y));
        values.put(LauncherSettings.Favorites.SPANX, Integer.valueOf(span_x));
        values.put(LauncherSettings.Favorites.SPANY, Integer.valueOf(span_y));
        values.put("itemType", (Integer) 4);
        values.put("appWidgetId", Integer.valueOf(appwidgetId));
        values.put("workspace_id", Integer.valueOf(workspaceId));
        values.put("intent", new ComponentName(packageName, className).flattenToString());
        bindTargets.add(new ComponentName(packageName, className));
        bindSource.add(Integer.valueOf(appwidgetId));
        return values;
    }

    private static void saveSceneInfo(ContentResolver cr, Entry e, int sceneId, String localizedName) {
        if (SCENE.equals(e.getTag())) {
            Bundle infoBundle = e.getInfo();
            String name = requestSceneName(cr, infoBundle.getString(NAME));
            if (localizedName != null) {
                name = localizedName;
            }
            infoBundle.getString(SKIN);
            String lockscreen = infoBundle.getString(LOCKSCREEN);
            ContentValues values = new ContentValues();
            values.put("_id", Integer.valueOf(sceneId));
            values.put("display_name", name);
            values.put(LauncherSettings.WidgetWorkspace.CREATED, Long.valueOf(System.currentTimeMillis()));
            values.put(LauncherSettings.WidgetWorkspace.STATUS, (Integer) 5);
            values.put(LauncherSettings.WidgetWorkspace.ANCESTOR_ID, (Integer) (-1));
            values.put(LauncherSettings.WidgetWorkspace.TRANSLATE_ID, (Integer) (-1));
            if (lockscreen != null) {
                values.put(LauncherSettings.WidgetWorkspace.LOCKSCREEN_WALLPAPER_NAME, lockscreen);
            }
            cr.insert(SCENE_CONTENT_URI, values);
        }
    }

    private static int requestSceneId(ContentResolver cr) {
        Cursor cursor = null;
        int maxId = -1;
        try {
            try {
                cursor = cr.query(SCENE_CONTENT_URI, new String[]{"_id"}, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    do {
                        int id = cursor.getInt(0);
                        if (id > maxId) {
                            maxId = id;
                        }
                    } while (cursor.moveToNext());
                }
            } catch (RuntimeException ex) {
                ex.printStackTrace();
                if (cursor != null) {
                    cursor.close();
                }
            }
            if (maxId == -1) {
                return 1;
            }
            return maxId + 1;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    private static String requestSceneName(ContentResolver cr, String name) {
        Cursor cursor = null;
        ArrayList<String> sceneName = new ArrayList<>();
        String newSceneName = null;
        try {
            try {
                cursor = cr.query(SCENE_CONTENT_URI, new String[]{"display_name"}, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    do {
                        sceneName.add(cursor.getString(0));
                    } while (cursor.moveToNext());
                }
                if (!isContainString(name, sceneName)) {
                    newSceneName = name;
                } else {
                    int i = 0;
                    do {
                        i++;
                        newSceneName = name + " " + i;
                    } while (isContainString(newSceneName, sceneName));
                }
            } catch (RuntimeException ex) {
                ex.printStackTrace();
                if (cursor != null) {
                    cursor.close();
                }
            }
            return newSceneName;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    private static boolean isContainString(String s, ArrayList<String> list) {
        Iterator i$ = list.iterator();
        while (i$.hasNext()) {
            String name = i$.next();
            if (name.equals(s)) {
                return true;
            }
        }
        return false;
    }

    private void printEntry(Entry e) {
        e.getInfo();
        if (!SCENE.equals(e.getTag()) && ITEM.equals(e.getTag())) {
        }
        ArrayList<Entry> entries = e.getEntries();
        if (entries != null) {
            Iterator i$ = entries.iterator();
            while (i$.hasNext()) {
                Entry entry = i$.next();
                if (entry != null) {
                    printEntry(entry);
                }
            }
        }
    }
}
