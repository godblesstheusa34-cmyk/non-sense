package com.htc.launcher;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class FastBitmapDrawable extends Drawable {
    private Bitmap mBitmap;
    private Rect mDstRect;
    private boolean mFillParent;
    private Rect mSrcRect;

    FastBitmapDrawable(Bitmap b) {
        this.mFillParent = false;
        this.mSrcRect = new Rect();
        this.mDstRect = new Rect();
        this.mBitmap = b;
    }

    FastBitmapDrawable(Bitmap b, boolean fillParent) {
        this.mFillParent = false;
        this.mSrcRect = new Rect();
        this.mDstRect = new Rect();
        this.mBitmap = b;
        this.mFillParent = fillParent;
        if (this.mFillParent) {
            this.mSrcRect.set(0, 0, this.mBitmap.getWidth(), this.mBitmap.getHeight());
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        if (this.mFillParent) {
            this.mDstRect.set(0, 0, canvas.getWidth(), canvas.getHeight());
            canvas.drawBitmap(this.mBitmap, this.mSrcRect, this.mDstRect, (Paint) null);
        } else {
            canvas.drawBitmap(this.mBitmap, 0.0f, 0.0f, (Paint) null);
        }
    }

    public Rect getDstRect() {
        if (this.mFillParent) {
            return this.mDstRect;
        }
        return null;
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        return -3;
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int alpha) {
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter cf) {
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicWidth() {
        return this.mBitmap.getWidth();
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicHeight() {
        return this.mBitmap.getHeight();
    }

    @Override // android.graphics.drawable.Drawable
    public int getMinimumWidth() {
        return this.mBitmap.getWidth();
    }

    @Override // android.graphics.drawable.Drawable
    public int getMinimumHeight() {
        return this.mBitmap.getHeight();
    }

    public Bitmap getBitmap() {
        return this.mBitmap;
    }
}
