package com.htc.launcher;

import android.content.ContentValues;
import android.view.ViewGroup;
import com.htc.launcher.LauncherSettings;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class Widget extends ItemInfo {
    int layoutResource;
    public byte[] props;

    static Widget makeSearch() {
        Widget w = new Widget();
        w.itemType = LauncherSettings.Favorites.ITEM_TYPE_WIDGET_SEARCH;
        w.spanX = 4;
        w.spanY = 1;
        w.layoutResource = R.layout.widget_search;
        return w;
    }

    @Override // com.htc.launcher.ItemInfo
    void onAddToDatabase(ContentValues values) {
        super.onAddToDatabase(values);
        values.put(LauncherSettings.Favorites.PROPS, this.props);
    }

    public void setWorkspaceId(int id) {
        this.workspaceId = id;
    }

    @Override // com.htc.launcher.ItemInfo
    public Draggee createItem(Launcher launcher, ViewGroup container) {
        return null;
    }

    @Override // com.htc.launcher.ItemInfo
    public long getId() {
        return this.id;
    }
}
