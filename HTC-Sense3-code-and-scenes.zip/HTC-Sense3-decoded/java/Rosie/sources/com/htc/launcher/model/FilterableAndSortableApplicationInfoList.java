package com.htc.launcher.model;

import com.htc.launcher.ApplicationInfo;
import com.htc.launcher.TFC;
import com.htc.launcher.Utilities;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class FilterableAndSortableApplicationInfoList {
    private static final int DEFAULT_CAPACITY = 96;
    private final ArrayList<ApplicationInfo> classifiedSortedData;
    private Classifier classifier;
    private boolean classifierChanged;
    private Comparator<? super ApplicationInfo> comparator;
    private boolean comparatorChanged;
    private final ArrayList<ApplicationInfo> data;
    private boolean dataChanged;
    private String keywords;
    private boolean keywordsChanged;
    private final ArrayList<ApplicationInfo> searchResult;
    private final ArrayList<ApplicationInfo> sortedData;
    public static final Comparator<ApplicationInfo> NEWEST_FIRST = new BasicAppInfoComparator() { // from class: com.htc.launcher.model.FilterableAndSortableApplicationInfoList.1
        @Override // com.htc.launcher.model.FilterableAndSortableApplicationInfoList.BasicAppInfoComparator
        protected int doCompare(ApplicationInfo l, ApplicationInfo r) {
            long ret = r.lastModifiedTime - l.lastModifiedTime;
            if (0 == ret) {
                return 0;
            }
            return ret > 0 ? 1 : -1;
        }
    };
    public static final Comparator<ApplicationInfo> OLDEST_FIRST = new BasicAppInfoComparator() { // from class: com.htc.launcher.model.FilterableAndSortableApplicationInfoList.2
        @Override // com.htc.launcher.model.FilterableAndSortableApplicationInfoList.BasicAppInfoComparator
        protected int doCompare(ApplicationInfo l, ApplicationInfo r) {
            long ret = l.lastModifiedTime - r.lastModifiedTime;
            if (0 == ret) {
                return 0;
            }
            return ret > 0 ? 1 : -1;
        }
    };
    public static final Comparator<ApplicationInfo> FREQUENTLY_USED_FIRST = new BasicAppInfoComparator() { // from class: com.htc.launcher.model.FilterableAndSortableApplicationInfoList.3
        @Override // com.htc.launcher.model.FilterableAndSortableApplicationInfoList.BasicAppInfoComparator
        protected int doCompare(ApplicationInfo l, ApplicationInfo r) {
            return r.launchCount - l.launchCount;
        }
    };
    public static final Comparator<ApplicationInfo> ALPHABET = new BasicAppInfoComparator() { // from class: com.htc.launcher.model.FilterableAndSortableApplicationInfoList.4
        @Override // com.htc.launcher.model.FilterableAndSortableApplicationInfoList.BasicAppInfoComparator
        protected int doCompare(ApplicationInfo l, ApplicationInfo r) {
            return 0;
        }
    };
    public static final Comparator<ApplicationInfo> ORIGINAL_ORDER = null;
    public static final Classifier ALL_APPS = null;
    public static final Classifier DOWNLOADED = new Classifier() { // from class: com.htc.launcher.model.FilterableAndSortableApplicationInfoList.5
        @Override // com.htc.launcher.model.FilterableAndSortableApplicationInfoList.Classifier
        public void reset() {
        }

        @Override // com.htc.launcher.model.FilterableAndSortableApplicationInfoList.Classifier
        public boolean classified(ApplicationInfo app) {
            return app.isDownloaded;
        }
    };
    public static final Classifier ONE_PAGE_EVER_USED = new Classifier() { // from class: com.htc.launcher.model.FilterableAndSortableApplicationInfoList.6
        public int COUNT_PER_PAGE = 20;
        private int classifiedNb = 0;

        @Override // com.htc.launcher.model.FilterableAndSortableApplicationInfoList.Classifier
        public void reset() {
            this.classifiedNb = 0;
        }

        @Override // com.htc.launcher.model.FilterableAndSortableApplicationInfoList.Classifier
        public boolean classified(ApplicationInfo app) {
            if (app.launchCount == 0) {
                return false;
            }
            this.classifiedNb++;
            return this.classifiedNb <= this.COUNT_PER_PAGE;
        }
    };

    public interface Classifier {
        boolean classified(ApplicationInfo applicationInfo);

        void reset();
    }

    public FilterableAndSortableApplicationInfoList() {
        this.sortedData = new ArrayList<>(DEFAULT_CAPACITY);
        this.classifiedSortedData = new ArrayList<>(DEFAULT_CAPACITY);
        this.searchResult = new ArrayList<>(DEFAULT_CAPACITY);
        this.comparator = ORIGINAL_ORDER;
        this.classifier = ALL_APPS;
        this.keywords = null;
        this.dataChanged = false;
        this.comparatorChanged = false;
        this.classifierChanged = false;
        this.keywordsChanged = false;
        this.data = new ArrayList<>(DEFAULT_CAPACITY);
    }

    public FilterableAndSortableApplicationInfoList(ArrayList<ApplicationInfo> data) {
        this.sortedData = new ArrayList<>(DEFAULT_CAPACITY);
        this.classifiedSortedData = new ArrayList<>(DEFAULT_CAPACITY);
        this.searchResult = new ArrayList<>(DEFAULT_CAPACITY);
        this.comparator = ORIGINAL_ORDER;
        this.classifier = ALL_APPS;
        this.keywords = null;
        this.dataChanged = false;
        this.comparatorChanged = false;
        this.classifierChanged = false;
        this.keywordsChanged = false;
        TFC.assertTrue("data should not be null", data != null);
        this.data = data;
        this.dataChanged = true;
        notifyDataSetChanged();
    }

    public boolean add(ApplicationInfo app) {
        add(this.data.size(), app);
        return true;
    }

    public void add(int index, ApplicationInfo app) {
        this.data.add(index, app);
        this.dataChanged = true;
        notifyDataSetChanged();
    }

    public boolean addAll(Collection<? extends ApplicationInfo> collect) {
        return addAll(this.data.size(), collect);
    }

    public boolean addAll(int index, Collection<? extends ApplicationInfo> collect) {
        boolean modified = this.data.addAll(index, collect);
        if (modified) {
            this.dataChanged = true;
            notifyDataSetChanged();
        }
        return modified;
    }

    public void clear() {
        if (!this.data.isEmpty()) {
            this.data.clear();
            this.dataChanged = true;
            notifyDataSetChanged();
        }
    }

    public ApplicationInfo remove(int index) {
        ApplicationInfo app = this.data.remove(index);
        this.dataChanged = true;
        notifyDataSetChanged();
        return app;
    }

    public boolean remove(ApplicationInfo app) {
        boolean modified = this.data.remove(app);
        if (modified) {
            this.dataChanged = true;
            notifyDataSetChanged();
        }
        return modified;
    }

    public ApplicationInfo set(int index, ApplicationInfo app) {
        TFC.assertTrue("app should not be null", app != null);
        ApplicationInfo ret = this.data.set(index, app);
        this.dataChanged = true;
        notifyDataSetChanged();
        return ret;
    }

    private ArrayList<ApplicationInfo> getFinalList() {
        return this.keywords != null ? this.searchResult : this.classifiedSortedData;
    }

    public boolean contains(ApplicationInfo app) {
        return getFinalList().contains(app);
    }

    public ApplicationInfo get(int index) {
        return getFinalList().get(index);
    }

    public int indexOf(ApplicationInfo app) {
        return getFinalList().indexOf(app);
    }

    public int lastIndexOf(ApplicationInfo app) {
        return getFinalList().lastIndexOf(app);
    }

    public int size() {
        return getFinalList().size();
    }

    public int originalSize() {
        return this.data.size();
    }

    public ApplicationInfo originalGet(int index) {
        return this.data.get(index);
    }

    private void notifyDataSetChanged() {
        if (this.dataChanged) {
            this.sortedData.clear();
            this.sortedData.addAll(this.data);
        }
        if (this.dataChanged || this.comparatorChanged) {
            if (ORIGINAL_ORDER == this.comparator) {
                if (this.dataChanged) {
                    TFC.d("VivoWCTGBS_246", "FASAIL.notifyDataSetChanged: original order. (do nothing)");
                } else {
                    this.sortedData.clear();
                    this.sortedData.addAll(this.data);
                    TFC.d("VivoWCTGBS_246", "FASAIL.notifyDataSetChanged: original order. (reset data)");
                }
            } else {
                Collections.sort(this.sortedData, this.comparator);
                String comparatorName = "Unknown";
                if (NEWEST_FIRST == this.comparator) {
                    comparatorName = "NEWEST_FIRST";
                } else if (OLDEST_FIRST == this.comparator) {
                    comparatorName = "OLDEST_FIRST";
                } else if (ALPHABET == this.comparator) {
                    comparatorName = "ALPHABET";
                } else if (ORIGINAL_ORDER == this.comparator) {
                    comparatorName = "ORIGINAL_ORDER";
                } else if (FREQUENTLY_USED_FIRST == this.comparator) {
                    comparatorName = "FREQUENTLY_USED_FIRST";
                }
                TFC.d("VivoWCTGBS_246", "FASAIL.notifyDataSetChanged: sort by " + comparatorName);
            }
        }
        if (this.dataChanged || this.comparatorChanged || this.classifierChanged) {
            this.classifiedSortedData.clear();
            if (ALL_APPS == this.classifier) {
                this.classifiedSortedData.addAll(this.sortedData);
            } else {
                this.classifier.reset();
                Iterator i$ = this.sortedData.iterator();
                while (i$.hasNext()) {
                    ApplicationInfo app = i$.next();
                    if (this.classifier.classified(app)) {
                        this.classifiedSortedData.add(app);
                    }
                }
            }
        }
        if ((this.dataChanged || this.comparatorChanged || this.classifierChanged || this.keywordsChanged) && this.keywords != null) {
            this.searchResult.clear();
            Iterator i$2 = this.classifiedSortedData.iterator();
            while (i$2.hasNext()) {
                ApplicationInfo app2 = i$2.next();
                if (match(app2, this.keywords)) {
                    this.searchResult.add(app2);
                }
            }
        }
        this.dataChanged = false;
        this.comparatorChanged = false;
        this.classifierChanged = false;
        this.keywordsChanged = false;
    }

    private boolean match(ApplicationInfo app, String keywords) {
        String string = app.title.toString().toLowerCase();
        return -1 != string.indexOf(keywords.toLowerCase());
    }

    public void sort(Comparator<? super ApplicationInfo> comparator) {
        if (this.comparator != comparator) {
            this.comparator = comparator;
            this.comparatorChanged = true;
            notifyDataSetChanged();
        }
    }

    public Comparator<? super ApplicationInfo> getComparator() {
        return this.comparator;
    }

    public void classify(Classifier classifier) {
        if (this.classifier != classifier) {
            this.classifier = classifier;
            this.classifierChanged = true;
            notifyDataSetChanged();
        }
    }

    public Classifier getClassifier() {
        return this.classifier;
    }

    public void search(String keywords) {
        if (keywords.isEmpty()) {
            keywords = null;
        }
        if (this.keywords != keywords) {
            if (keywords == null || !keywords.equals(this.keywords)) {
                this.keywords = keywords;
                this.keywordsChanged = true;
                notifyDataSetChanged();
            }
        }
    }

    public String getKeywords() {
        return this.keywords;
    }

    private static abstract class BasicAppInfoComparator implements Comparator<ApplicationInfo> {
        protected abstract int doCompare(ApplicationInfo applicationInfo, ApplicationInfo applicationInfo2);

        private BasicAppInfoComparator() {
        }

        @Override // java.util.Comparator
        public int compare(ApplicationInfo l, ApplicationInfo r) {
            if (l.priority != r.priority) {
                return l.priority - r.priority;
            }
            int ret = doCompare(l, r);
            if (ret == 0) {
                ret = Utilities.sCollator.compare(l.title, r.title);
            }
            return ret;
        }
    }
}
