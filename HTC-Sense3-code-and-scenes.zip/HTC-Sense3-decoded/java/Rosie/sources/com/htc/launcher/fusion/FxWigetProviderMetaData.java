package com.htc.launcher.fusion;

import android.net.Uri;
import android.provider.BaseColumns;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class FxWigetProviderMetaData {
    public static final String AUTHORITY = "com.htc.AddProgramWidget.fusionwidget.FxWidgetProvider";
    public static final String DATABASE_NAME = "fxwidget.db";
    public static final String DATABASE_TABLE_NAME = "fxwidgets";
    public static final int DATABASE_VERSION = 1;

    private FxWigetProviderMetaData() {
    }

    public static final class FxWidgetTableMedata implements BaseColumns {
        public static final String CONTENT_ITEM = "vnd.android.cursor.item/vnd.htc.fxrosiewidget";
        public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.htc.fxrosiewidget";
        public static final Uri CONTENT_URI = Uri.parse("content://com.htc.AddProgramWidget.fusionwidget.FxWidgetProvider/fxwidgets");
        public static final String DEFAULT_SORT_ORDER = "modified DESC";
        public static final String TABLE_NAME = "fxwidgets";

        private FxWidgetTableMedata() {
        }
    }
}
