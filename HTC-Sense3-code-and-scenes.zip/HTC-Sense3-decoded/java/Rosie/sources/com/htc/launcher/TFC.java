package com.htc.launcher;

import android.util.Log;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class TFC {
    public static final boolean DEBUG = false;
    private static final String TAG = "TFC";

    public static void e(String tag, String mesg, Throwable e) {
        Log.e(tag, mesg, e);
        e.printStackTrace();
    }

    public static void e(String tag, String mesg) {
        Log.e(tag, mesg);
    }

    public static void d(String tag, String mesg) {
    }

    public static void w(String tag, String mesg) {
        Log.w(tag, mesg);
    }

    public static void assertTrue(String mesg, boolean condition) {
        if (!condition) {
            Log.e(TAG, "assertTrue:" + mesg);
            Thread.dumpStack();
        }
    }
}
