package com.htc.launcher;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.htc.android.rosie.home.HostWidgetManager;
import com.htc.fusion.fx.FxScene;
import com.htc.fusion.fx.FxSceneLoader;
import com.htc.fusion.fx.FxViewObject;
import com.htc.launcher.settings.SettingUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class HostActivityBridge implements HostWidgetManager.Owner {
    private static final String LOG_TAG = HostActivityBridge.class.getSimpleName();
    static final long NO_STORE_ID = -1;
    private final Activity mActivity;
    private final FxViewObject mFxView;

    public HostActivityBridge(Activity activity, FxViewObject fxView) {
        this.mActivity = activity;
        this.mFxView = fxView;
    }

    @Override // com.htc.android.rosie.home.HostWidgetManager.Owner
    public Context getContext() {
        return this.mActivity;
    }

    @Override // com.htc.android.rosie.home.HostWidgetManager.Owner
    public void addResourcePath(String path) {
        this.mFxView.setPackageResourcePath(path);
    }

    @Override // com.htc.android.rosie.home.HostWidgetManager.Owner
    public void startActivityForResult(Intent intent, int requestCode) {
        this.mActivity.startActivityForResult(intent, requestCode);
    }

    @Override // com.htc.android.rosie.home.HostWidgetManager.Owner
    public FxScene createScene(String path, boolean visible) {
        FxSceneLoader loader = FxSceneLoader.create(path);
        if (SettingUtil.localLOGD) {
            Log.d(LOG_TAG, "will create scene:" + path);
        }
        try {
            FxScene scene = FxScene.create(loader, visible);
            if (SettingUtil.localLOGD) {
                Log.d(LOG_TAG, "did create scene:" + scene);
            }
            return scene;
        } catch (Exception e) {
            Log.e("LOG_TAG", "FxScene.create fail: " + path);
            return null;
        }
    }

    @Override // com.htc.android.rosie.home.HostWidgetManager.Owner
    public void destroyScene(FxScene scene) {
        scene.clearHandle();
    }

    @Override // com.htc.android.rosie.home.HostWidgetManager.Owner
    public long getInvalidId() {
        return NO_STORE_ID;
    }

    @Override // com.htc.android.rosie.home.HostWidgetManager.Owner
    public boolean storeWidgetInfo(HostWidgetManager.WidgetInfo widgetInfo) {
        if (widgetInfo == null) {
            return false;
        }
        FxItemInfo item = new FxItemInfo(widgetInfo);
        LauncherModel.addItemToDatabase(this.mActivity, item, -100L, item.screen, item.cellX, item.cellY, false);
        widgetInfo.setStoreId(item.id);
        if (SettingUtil.localLOGD) {
            Log.d(LOG_TAG, "saving:" + widgetInfo);
        }
        return true;
    }

    @Override // com.htc.android.rosie.home.HostWidgetManager.Owner
    public boolean updateWidgetInfo(HostWidgetManager.WidgetInfo widgetInfo) {
        if (widgetInfo == null) {
            return false;
        }
        FxItemInfo item = new FxItemInfo(widgetInfo);
        LauncherModel.updateItemInDatabase(this.mActivity, item);
        return item.id != NO_STORE_ID;
    }

    @Override // com.htc.android.rosie.home.HostWidgetManager.Owner
    public boolean deleteWidgetInfo(HostWidgetManager.WidgetInfo widgetInfo) {
        FxItemInfo item = new FxItemInfo(widgetInfo);
        LauncherModel.deleteItemFromDatabase(this.mActivity, item);
        return true;
    }

    @Override // com.htc.android.rosie.home.HostWidgetManager.Owner
    public void surpressSlide(boolean surpress) {
        if (this.mActivity instanceof Launcher) {
            Launcher l = (Launcher) this.mActivity;
            l.getWorkspace().enableScroll(!surpress);
        }
    }

    @Override // com.htc.android.rosie.home.HostWidgetManager.Owner
    public void surpressLongClick(boolean surpress) {
        if (this.mActivity instanceof Launcher) {
            Launcher l = (Launcher) this.mActivity;
            l.getWorkspace().setAllowLongPress(!surpress);
        }
    }
}
