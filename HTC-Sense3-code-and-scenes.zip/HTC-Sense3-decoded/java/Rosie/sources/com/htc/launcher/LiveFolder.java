package com.htc.launcher;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import com.htc.launcher.LiveFolderAdapter;
import java.lang.ref.WeakReference;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class LiveFolder extends Folder {
    private AsyncTask<LiveFolderInfo, Void, Cursor> mLoadingTask;

    public LiveFolder(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    static LiveFolder fromXml(Context context, FolderInfo folderInfo) {
        int layout = isDisplayModeList(folderInfo) ? 2130903065 : 2130903063;
        return (LiveFolder) LayoutInflater.from(context).inflate(layout, (ViewGroup) null);
    }

    private static boolean isDisplayModeList(FolderInfo folderInfo) {
        return ((LiveFolderInfo) folderInfo).displayMode == 2;
    }

    @Override // com.htc.launcher.Folder, android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView parent, View v, int position, long id) {
        LiveFolderAdapter.ViewHolder holder = (LiveFolderAdapter.ViewHolder) v.getTag();
        if (holder.useBaseIntent) {
            Intent baseIntent = ((LiveFolderInfo) this.mInfo).baseIntent;
            if (baseIntent != null) {
                Intent intent = new Intent(baseIntent);
                Uri uri = baseIntent.getData();
                intent.setData(uri.buildUpon().appendPath(Long.toString(holder.id)).build());
                this.mLauncher.launchAppType = "RS_folder";
                this.mLauncher.startActivitySafely(intent);
                return;
            }
            return;
        }
        if (holder.intent != null) {
            this.mLauncher.startActivitySafely(holder.intent);
        }
    }

    @Override // com.htc.launcher.Folder, android.widget.AdapterView.OnItemLongClickListener
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        return false;
    }

    @Override // com.htc.launcher.Folder
    void bind(FolderInfo info) {
        super.bind(info);
        if (this.mLoadingTask != null && this.mLoadingTask.getStatus() == AsyncTask.Status.RUNNING) {
            this.mLoadingTask.cancel(true);
        }
        this.mLoadingTask = new FolderLoadingTask(this);
        this.mLoadingTask.execute((LiveFolderInfo) info);
    }

    @Override // com.htc.launcher.Folder
    void onOpen() {
        super.onOpen();
        requestFocus();
    }

    @Override // com.htc.launcher.Folder
    void onClose() {
        super.onClose();
        if (this.mLoadingTask != null && this.mLoadingTask.getStatus() == AsyncTask.Status.RUNNING) {
            this.mLoadingTask.cancel(true);
        }
        LiveFolderAdapter adapter = (LiveFolderAdapter) this.mContent.getAdapter();
        if (adapter != null) {
            adapter.cleanup();
        }
    }

    private class FolderLoadingTask extends AsyncTask<LiveFolderInfo, Void, Cursor> {
        private final WeakReference<LiveFolder> mFolder;
        private LiveFolderInfo mInfo;

        FolderLoadingTask(LiveFolder folder) {
            this.mFolder = new WeakReference<>(folder);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Cursor doInBackground(LiveFolderInfo... params) {
            LiveFolder folder = this.mFolder.get();
            if (folder == null) {
                return null;
            }
            this.mInfo = params[0];
            return LiveFolderAdapter.query(folder.mLauncher, this.mInfo);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Cursor cursor) {
            LiveFolder folder;
            if (!isCancelled()) {
                if (cursor != null && (folder = this.mFolder.get()) != null) {
                    Launcher launcher = folder.mLauncher;
                    folder.setContentAdapter(new LiveFolderAdapter(launcher, this.mInfo, cursor));
                    return;
                }
                return;
            }
            if (cursor != null) {
                cursor.close();
            }
        }
    }
}
