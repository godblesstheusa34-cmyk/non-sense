package com.htc.launcher;

import android.appwidget.AppWidgetHost;
import android.content.ComponentName;
import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.UriMatcher;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDiskIOException;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import com.android.common.speech.LoggingEvents;
import com.htc.launcher.LauncherSettings;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class LauncherProvider extends ContentProvider {
    static final String AUTHORITY = "com.htc.launcher.settings";
    static final String BACKUP_DATABASE_NAME = "backup_launcher.db";
    private static final int CODE_BACKUP_NONDEFAULT_FAVORITES = 8;
    private static final int CODE_RESTORE_WORKSPACES = 9;
    private static final int CODE_SPECIAL_ADJUST_UNSAVED_ITEM_ORIG_ID = 2;
    private static final int CODE_SPECIAL_BACKUP_ALL_ITEMS = 3;
    private static final int CODE_SPECIAL_INCREASE_PAGE = 1;
    private static final int CODE_SPECIAL_INIT_WORKSPACES = 7;
    private static final int CODE_SPECIAL_SCENE_NAME_LOCALE_CHANGE = 6;
    private static final int CODE_SPECIAL_UPDATE_REARRANGE_SCREEN_ID = 5;
    private static final int CODE_SPECIAL_UPDATE_SHORTCUT_LABELS = 4;
    static final Uri CONTENT_APPWIDGET_RESET_URI;
    static final String DATABASE_NAME = "launcher.db";
    private static final int DATABASE_VERSION = 4;
    static final String EXTRA_BIND_SOURCES = "com.android.launcher.settings.bindsources";
    static final String EXTRA_BIND_TARGETS = "com.android.launcher.settings.bindtargets";
    private static final boolean LOGD = false;
    private static final String LOG_TAG = "LauncherProvider";
    static final String PARAMETER_NOTIFY = "notify";
    static final String SPECIAL_ADJUST_UNSAVED_ITEM_ORIG_ID = "_adjust_insaved_item_orig_id";
    static final String SPECIAL_BACKUP_ALL_ITEMS = "_backup_all_items";
    static final String SPECIAL_INCREASE_PAGE = "_increase_page";
    static final String SPECIAL_INIT_WORKSPACES = "_init_workspaces";
    static final String SPECIAL_SCENE_NAME_LOCALE_CHANGE = "_scene_name_locale_change";
    static final String SPECIAL_UPDATE_REARRANGE_SCREEN_ID = "_update_screen_id";
    static final String SPECIAL_UPDATE_SHORTCUT_LABELS = "_update_shortcut_labels";
    static final String SPECILA_BACKUP_NONDEFAULT_FAVORITES = "_backup_nondefault_favorites";
    static final String SPECILA_RESTORE_WORKSPACES = "_restore_widget_workspaces";
    static final String TABLE_FAVORITES = "favorites";
    static final String TABLE_FAVORITES_BACKUP = "favorites_backup";
    static final String TABLE_WIDGET_ITEM_TYPES = "widget_item_types";
    static final String TABLE_WIDGET_WORKSPACE = "widget_workspaces";
    static final String TABLE_WORKSPACE_BACKUP = "widget_workspaces_backup";
    private static final UriMatcher sURIMatcher = new UriMatcher(-1);
    private SQLiteOpenHelper mOpenHelper;

    static {
        sURIMatcher.addURI(AUTHORITY, SPECIAL_INCREASE_PAGE, 1);
        sURIMatcher.addURI(AUTHORITY, SPECIAL_ADJUST_UNSAVED_ITEM_ORIG_ID, 2);
        sURIMatcher.addURI(AUTHORITY, SPECIAL_BACKUP_ALL_ITEMS, 3);
        sURIMatcher.addURI(AUTHORITY, SPECIAL_UPDATE_SHORTCUT_LABELS, 4);
        sURIMatcher.addURI(AUTHORITY, SPECIAL_UPDATE_REARRANGE_SCREEN_ID, 5);
        sURIMatcher.addURI(AUTHORITY, SPECIAL_SCENE_NAME_LOCALE_CHANGE, 6);
        sURIMatcher.addURI(AUTHORITY, SPECIAL_INIT_WORKSPACES, 7);
        sURIMatcher.addURI(AUTHORITY, SPECILA_BACKUP_NONDEFAULT_FAVORITES, 8);
        sURIMatcher.addURI(AUTHORITY, SPECILA_RESTORE_WORKSPACES, 9);
        CONTENT_APPWIDGET_RESET_URI = Uri.parse("content://com.htc.launcher.settings/appWidgetReset");
    }

    @Override // android.content.ContentProvider
    public boolean onCreate() {
        this.mOpenHelper = new DatabaseHelper(getContext());
        return true;
    }

    @Override // android.content.ContentProvider
    public String getType(Uri uri) {
        SqlArguments args = new SqlArguments(uri, null, null);
        return TextUtils.isEmpty(args.where) ? "vnd.android.cursor.dir/" + args.table : "vnd.android.cursor.item/" + args.table;
    }

    @Override // android.content.ContentProvider
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        try {
            SqlArguments args = new SqlArguments(uri, selection, selectionArgs);
            SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
            qb.setTables(args.table);
            SQLiteDatabase db = this.mOpenHelper.getReadableDatabase();
            Cursor result = qb.query(db, projection, args.where, args.args, null, null, sortOrder);
            result.setNotificationUri(getContext().getContentResolver(), uri);
            return result;
        } catch (SQLiteDiskIOException e) {
            return null;
        } catch (SQLiteException e2) {
            Log.e(LOG_TAG, "unable to open database file");
            return null;
        }
    }

    @Override // android.content.ContentProvider
    public Uri insert(Uri uri, ContentValues initialValues) {
        SqlArguments args = new SqlArguments(uri);
        try {
            SQLiteDatabase db = this.mOpenHelper.getWritableDatabase();
            long rowId = db.insert(args.table, null, initialValues);
            if (rowId <= 0) {
                return null;
            }
            Uri uri2 = ContentUris.withAppendedId(uri, rowId);
            sendNotify(uri2);
            return uri2;
        } catch (SQLiteException e) {
            Log.e(LOG_TAG, "unable to open database file");
            return null;
        }
    }

    @Override // android.content.ContentProvider
    public int bulkInsert(Uri uri, ContentValues[] values) {
        return LauncherSettings.Favorites.CONTENT_URI_NO_NOTIFICATION.equals(uri) ? bulkInsertAdjustContainer(uri, values) : bulkInsertOrig(uri, values);
    }

    public int bulkInsertAdjustContainer(Uri uri, ContentValues[] values) {
        SqlArguments args = new SqlArguments(uri);
        HashMap<String, String> origId2IdMap = new HashMap<>();
        Arrays.sort(values, new Comparator<ContentValues>() { // from class: com.htc.launcher.LauncherProvider.1
            @Override // java.util.Comparator
            public int compare(ContentValues arg0, ContentValues arg1) {
                int container0 = arg0.getAsInteger("container").intValue();
                int container1 = arg1.getAsInteger("container").intValue();
                return container0 - container1;
            }
        });
        SQLiteDatabase db = null;
        try {
            db = this.mOpenHelper.getWritableDatabase();
            db.beginTransaction();
            int numValues = values.length;
            for (int i = 0; i < numValues; i++) {
                String container = values[i].getAsString("container");
                String newContainer = origId2IdMap.get(container);
                if (newContainer != null && newContainer.length() > 0) {
                    values[i].put("container", newContainer);
                }
                long newRowId = db.insert(args.table, null, values[i]);
                origId2IdMap.put(values[i].getAsString(LauncherSettings.Favorites.ORIG_ID), Long.toString(newRowId));
                if (newRowId < 0) {
                    return 0;
                }
            }
            db.setTransactionSuccessful();
            db.endTransaction();
            sendNotify(uri);
            return values.length;
        } catch (SQLiteException e) {
            Log.e(LOG_TAG, "unable to open database file");
            return 0;
        } finally {
            db.endTransaction();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:16:0x002b, code lost:
    
        r1.setTransactionSuccessful();
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x002e, code lost:
    
        r1.endTransaction();
        sendNotify(r11);
        r5 = r12.length;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public int bulkInsertOrig(Uri uri, ContentValues[] values) {
        int i;
        SqlArguments args = new SqlArguments(uri);
        SQLiteDatabase db = null;
        try {
            try {
                db = this.mOpenHelper.getWritableDatabase();
                db.beginTransaction();
                int numValues = values.length;
                int i2 = 0;
                while (true) {
                    if (i2 >= numValues) {
                        break;
                    }
                    if (db.insert(args.table, null, values[i2]) >= 0) {
                        i2++;
                    } else {
                        db.endTransaction();
                        i = 0;
                        break;
                    }
                }
            } catch (SQLiteException e) {
                Log.e(LOG_TAG, "unable to open database file");
                db.endTransaction();
                i = 0;
            }
            return i;
        } catch (Throwable th) {
            db.endTransaction();
            throw th;
        }
    }

    @Override // android.content.ContentProvider
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        int code = sURIMatcher.match(uri);
        if (code != -1) {
            return specialAction(code, uri, null, selection, selectionArgs);
        }
        SqlArguments args = new SqlArguments(uri, selection, selectionArgs);
        try {
            SQLiteDatabase db = this.mOpenHelper.getWritableDatabase();
            int count = db.delete(args.table, args.where, args.args);
            if (count > 0) {
                sendNotify(uri);
            }
            return count;
        } catch (SQLException e) {
            Log.e(LOG_TAG, "Error deleting : " + uri, e);
            return -1;
        }
    }

    @Override // android.content.ContentProvider
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        int code = sURIMatcher.match(uri);
        if (code != -1) {
            return specialAction(code, uri, values, selection, selectionArgs);
        }
        SqlArguments args = new SqlArguments(uri, selection, selectionArgs);
        try {
            SQLiteDatabase db = this.mOpenHelper.getWritableDatabase();
            int count = db.update(args.table, values, args.where, args.args);
            if (count > 0) {
                sendNotify(uri);
            }
            return count;
        } catch (SQLException e) {
            Log.e(LOG_TAG, "Error deleting : " + uri, e);
            return -1;
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    private int specialAction(int code, Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        String intentUri;
        ComponentName name;
        int count = 0;
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            try {
            } catch (SQLiteException e) {
                Log.e(LOG_TAG, "unable to open database file");
            } finally {
            }
        } catch (SQLiteException e2) {
            Log.e(LOG_TAG, "unable to open database file");
        } finally {
        }
        switch (code) {
            case 1:
                try {
                    db = this.mOpenHelper.getWritableDatabase();
                    db.beginTransaction();
                    db.execSQL("update favorites set screen=screen+1");
                    db.setTransactionSuccessful();
                } catch (SQLiteException e3) {
                    Log.e(LOG_TAG, "unable to open database file");
                } finally {
                }
                return count;
            case 2:
                Integer workspaceId = values.getAsInteger("workspace_id");
                if (workspaceId == null) {
                    Log.e(LOG_TAG, "no workspace_id found in SPECIAL_ADJUST_UNSAVED_ITEM_ORIG_ID");
                } else {
                    try {
                        try {
                            db = this.mOpenHelper.getWritableDatabase();
                            db.beginTransaction();
                            cursor = db.rawQuery("select b._id, a._id from favorites a, favorites b where a.workspace_id=? AND a.orig_id=b._id", new String[]{workspaceId.toString()});
                            while (cursor.moveToNext()) {
                                int id = cursor.getInt(0);
                                int newOrigId = cursor.getInt(1);
                                ContentValues updateValues = new ContentValues();
                                updateValues.put(LauncherSettings.Favorites.ORIG_ID, Integer.valueOf(newOrigId));
                                db.update(TABLE_FAVORITES, updateValues, "_id=?", new String[]{LoggingEvents.EXTRA_CALLING_APP_NAME + id});
                                count++;
                            }
                            db.setTransactionSuccessful();
                            if (cursor != null) {
                                cursor.close();
                            }
                        } catch (SQLiteException e4) {
                            Log.e(LOG_TAG, "unable to open database file");
                            if (cursor != null) {
                                cursor.close();
                            }
                        }
                    } catch (Throwable th) {
                        if (cursor != null) {
                            cursor.close();
                        }
                        throw th;
                    }
                }
                return count;
            case 3:
                try {
                    try {
                        db = this.mOpenHelper.getWritableDatabase();
                        db.beginTransaction();
                        cursor = db.query(TABLE_FAVORITES, null, "workspace_id = 0", null, null, null, null);
                        int origIdIndex = cursor.getColumnIndexOrThrow(LauncherSettings.Favorites.ORIG_ID);
                        int intentIndex = cursor.getColumnIndexOrThrow("intent");
                        int titleIndex = cursor.getColumnIndexOrThrow("title");
                        int iconTypeIndex = cursor.getColumnIndexOrThrow(LauncherSettings.Favorites.ICON_TYPE);
                        int iconIndex = cursor.getColumnIndexOrThrow(LauncherSettings.Favorites.ICON);
                        int iconPackageIndex = cursor.getColumnIndexOrThrow(LauncherSettings.Favorites.ICON_PACKAGE);
                        int iconResourceIndex = cursor.getColumnIndexOrThrow(LauncherSettings.Favorites.ICON_RESOURCE);
                        int propsIndex = cursor.getColumnIndexOrThrow(LauncherSettings.Favorites.PROPS);
                        int uriIndex = cursor.getColumnIndexOrThrow("uri");
                        int displayModeIndex = cursor.getColumnIndexOrThrow(LauncherSettings.Favorites.DISPLAY_MODE);
                        while (cursor.moveToNext()) {
                            ContentValues updateValues2 = new ContentValues();
                            updateValues2.put("title", cursor.getString(titleIndex));
                            updateValues2.put("intent", cursor.getString(intentIndex));
                            updateValues2.put(LauncherSettings.Favorites.ICON_TYPE, cursor.getString(iconTypeIndex));
                            updateValues2.put(LauncherSettings.Favorites.ICON_PACKAGE, cursor.getString(iconPackageIndex));
                            updateValues2.put(LauncherSettings.Favorites.ICON_RESOURCE, cursor.getString(iconResourceIndex));
                            updateValues2.put(LauncherSettings.Favorites.ICON, cursor.getBlob(iconIndex));
                            updateValues2.put(LauncherSettings.Favorites.PROPS, cursor.getBlob(propsIndex));
                            updateValues2.put("uri", cursor.getString(uriIndex));
                            updateValues2.put(LauncherSettings.Favorites.DISPLAY_MODE, cursor.getString(displayModeIndex));
                            String origId = cursor.getString(origIdIndex);
                            if (origId != null && origId.length() > 0) {
                                db.update(TABLE_FAVORITES, updateValues2, "_id=?", new String[]{origId});
                            }
                            count++;
                        }
                        db.setTransactionSuccessful();
                        if (cursor != null) {
                            cursor.close();
                        }
                    } catch (SQLiteException e5) {
                        Log.e(LOG_TAG, "unable to open database file");
                        if (cursor != null) {
                            cursor.close();
                        }
                    }
                    return count;
                } catch (Throwable th2) {
                    if (cursor != null) {
                        cursor.close();
                    }
                    throw th2;
                }
            case 4:
                try {
                    try {
                        db = this.mOpenHelper.getWritableDatabase();
                        db.beginTransaction();
                        PackageManager manager = getContext().getPackageManager();
                        cursor = db.query(TABLE_FAVORITES, new String[]{LauncherSettings.Favorites.ID, "title", "intent", LauncherSettings.Favorites.ITEM_TYPE}, null, null, null, null, null);
                        int idIndex = cursor.getColumnIndexOrThrow(LauncherSettings.Favorites.ID);
                        int intentIndex2 = cursor.getColumnIndexOrThrow("intent");
                        int itemTypeIndex = cursor.getColumnIndexOrThrow(LauncherSettings.Favorites.ITEM_TYPE);
                        int titleIndex2 = cursor.getColumnIndexOrThrow("title");
                        while (cursor.moveToNext()) {
                            try {
                                if (cursor.getInt(itemTypeIndex) == 0 && (intentUri = cursor.getString(intentIndex2)) != null) {
                                    Intent shortcut = Intent.parseUri(intentUri, 0);
                                    if ("android.intent.action.MAIN".equals(shortcut.getAction()) && (name = shortcut.getComponent()) != null) {
                                        ActivityInfo activityInfo = manager.getActivityInfo(name, 0);
                                        String title = cursor.getString(titleIndex2);
                                        String label = AllAppsGridView.translateAppTitle(LauncherModel.getLabel(manager, activityInfo), getContext());
                                        if (title == null || !title.equals(label)) {
                                            ContentValues updateValues3 = new ContentValues();
                                            updateValues3.put("title", label);
                                            db.update(TABLE_FAVORITES, updateValues3, "_id=?", new String[]{String.valueOf(cursor.getLong(idIndex))});
                                            count++;
                                        }
                                    }
                                }
                            } catch (PackageManager.NameNotFoundException e6) {
                            } catch (URISyntaxException e7) {
                            }
                        }
                        db.setTransactionSuccessful();
                        if (cursor != null) {
                            cursor.close();
                        }
                    } catch (SQLiteException e8) {
                        Log.e(LOG_TAG, "unable to open database file");
                        if (cursor != null) {
                            cursor.close();
                        }
                    }
                    return count;
                } catch (Throwable th3) {
                    if (cursor != null) {
                        cursor.close();
                    }
                    throw th3;
                }
            case 5:
                db = this.mOpenHelper.getWritableDatabase();
                db.beginTransaction();
                int w_id = values.getAsInteger("workspace_id").intValue();
                byte[] mapping = values.getAsByteArray(LauncherSettings.Favorites.SCREEN);
                for (int i = 0; i < mapping.length; i++) {
                    db.execSQL("update favorites set screen = " + (-mapping[i]) + " where screen = " + i + " and workspace_id = " + w_id);
                }
                db.execSQL("update favorites set screen = -screen where screen < 0");
                db.setTransactionSuccessful();
                return count;
            case 6:
                try {
                    db = this.mOpenHelper.getWritableDatabase();
                    db.beginTransaction();
                    Set<Map.Entry<String, Object>> entries = values.valueSet();
                    for (Map.Entry<String, Object> entry : entries) {
                        ContentValues updateValues4 = new ContentValues();
                        String displayName = entry.getValue() == null ? LoggingEvents.EXTRA_CALLING_APP_NAME : entry.getValue().toString();
                        updateValues4.put("display_name", displayName);
                        db.update(TABLE_WIDGET_WORKSPACE, updateValues4, "_id=?", new String[]{entry.getKey()});
                    }
                    db.setTransactionSuccessful();
                } catch (SQLiteException e9) {
                    Log.e(LOG_TAG, "unable to open database file");
                } finally {
                }
                return count;
            case 7:
                try {
                    db = this.mOpenHelper.getWritableDatabase();
                    db.beginTransaction();
                    db.execSQL("delete from widget_workspaces");
                    initWorkspaces(db, getContext());
                    db.setTransactionSuccessful();
                } catch (SQLiteException e10) {
                    Log.e(LOG_TAG, "unable to open database file");
                } finally {
                }
                return count;
            case 8:
                db = this.mOpenHelper.getWritableDatabase();
                db.beginTransaction();
                db.execSQL("drop table if exists favorites_backup");
                db.execSQL("create table favorites_backup as select * from favorites where workspace_id = 0 or workspace_id in (select _id from widget_workspaces where status<>2)");
                db.execSQL("drop table if exists widget_workspaces_backup");
                db.execSQL("create table widget_workspaces_backup as select * from widget_workspaces where status <> 2");
                db.setTransactionSuccessful();
                return count;
            case 9:
                try {
                    db = this.mOpenHelper.getWritableDatabase();
                    db.beginTransaction();
                    db.execSQL("delete from widget_workspaces where status<>2");
                    db.execSQL("insert into widget_workspaces select * from widget_workspaces_backup");
                    db.setTransactionSuccessful();
                } catch (SQLiteException e11) {
                    Log.e(LOG_TAG, "unable to open database file");
                } finally {
                }
                return count;
            default:
                return count;
        }
    }

    private void sendNotify(Uri uri) {
        String notify = uri.getQueryParameter(PARAMETER_NOTIFY);
        if (notify == null || "true".equals(notify)) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
    }

    private static class DatabaseHelper extends SQLiteOpenHelper {
        private static final String TAG_CLOCK = "clock";
        private static final String TAG_FAVORITE = "favorite";
        private static final String TAG_FAVORITES = "favorites";
        private static final String TAG_SEARCH = "search";
        private final AppWidgetHost mAppWidgetHost;
        private final Context mContext;

        DatabaseHelper(Context context) {
            super(context, LauncherProvider.DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 4);
            this.mContext = context;
            this.mAppWidgetHost = new AppWidgetHost(context, 9999);
        }

        private void sendAppWidgetResetNotify() {
            ContentResolver resolver = this.mContext.getContentResolver();
            resolver.notifyChange(LauncherProvider.CONTENT_APPWIDGET_RESET_URI, null);
        }

        @Override // android.database.sqlite.SQLiteOpenHelper
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE favorites (_id INTEGER PRIMARY KEY,title TEXT,intent TEXT,container INTEGER,screen INTEGER,cellX INTEGER,cellY INTEGER,spanX INTEGER,spanY INTEGER,itemType INTEGER,appWidgetId INTEGER NOT NULL DEFAULT -1,isShortcut INTEGER,iconType INTEGER,iconPackage TEXT,iconResource TEXT,icon BLOB,props BLOB,workspace_id INTEGER,orig_id INTEGER,uri TEXT,displayMode INTEGER);");
            db.execSQL("CREATE INDEX IDX_workspace_id on favorites (workspace_id)");
            if (this.mAppWidgetHost != null) {
                this.mAppWidgetHost.deleteHost();
                sendAppWidgetResetNotify();
            }
            db.execSQL("CREATE TABLE widget_item_types (_id INTEGER PRIMARY KEY,package_name TEXT,widget_name TEXT,plugin_classname TEXT,item_category INTEGER,parent_id INTEGER,text_resource INTEGER,icon_resource INTEGER,span_x INTEGER,span_y INTEGER,layout_resource INTEGER,extra_properties BLOB,CONSTRAINT uc_widget_naming UNIQUE (package_name,widget_name));");
            db.execSQL("CREATE INDEX IDX_ITEM_TYPE_PARENT_ID on widget_item_types (parent_id)");
            db.execSQL("CREATE TABLE widget_workspaces (_id INTEGER PRIMARY KEY, display_name TEXT, created LONG, status TEXT, ancestor_id INTEGER, translate_id INTEGER, lockscreen_wallpaper TEXT, wallpaper_component TEXT );");
            LauncherProvider.initWorkspaces(db, this.mContext);
            convertDatabase(db);
        }

        private boolean convertDatabase(SQLiteDatabase db) {
            boolean converted = false;
            Uri uri = Uri.parse("content://settings/old_favorites?notify=true");
            ContentResolver resolver = this.mContext.getContentResolver();
            Cursor cursor = null;
            try {
                cursor = resolver.query(uri, null, null, null, null);
            } catch (Exception e) {
            }
            if (cursor != null && cursor.getCount() > 0) {
                try {
                    converted = copyFromCursor(db, cursor) > 0;
                    if (converted) {
                        resolver.delete(uri, null, null);
                    }
                } finally {
                    cursor.close();
                }
            }
            if (converted) {
                convertWidgets(db);
            }
            return converted;
        }

        private int copyFromCursor(SQLiteDatabase db, Cursor c) {
            int idIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ID);
            int intentIndex = c.getColumnIndexOrThrow("intent");
            int titleIndex = c.getColumnIndexOrThrow("title");
            int iconTypeIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ICON_TYPE);
            int iconIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ICON);
            int iconPackageIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ICON_PACKAGE);
            int iconResourceIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ICON_RESOURCE);
            int containerIndex = c.getColumnIndexOrThrow("container");
            int itemTypeIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.ITEM_TYPE);
            int screenIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.SCREEN);
            int cellXIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.CELLX);
            int cellYIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.CELLY);
            int uriIndex = c.getColumnIndexOrThrow("uri");
            int displayModeIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.DISPLAY_MODE);
            ContentValues[] rows = new ContentValues[c.getCount()];
            int i = 0;
            while (c.moveToNext()) {
                ContentValues values = new ContentValues(c.getColumnCount());
                values.put(LauncherSettings.Favorites.ID, Long.valueOf(c.getLong(idIndex)));
                values.put("intent", c.getString(intentIndex));
                values.put("title", c.getString(titleIndex));
                values.put(LauncherSettings.Favorites.ICON_TYPE, Integer.valueOf(c.getInt(iconTypeIndex)));
                values.put(LauncherSettings.Favorites.ICON, c.getBlob(iconIndex));
                values.put(LauncherSettings.Favorites.ICON_PACKAGE, c.getString(iconPackageIndex));
                values.put(LauncherSettings.Favorites.ICON_RESOURCE, c.getString(iconResourceIndex));
                values.put("container", Integer.valueOf(c.getInt(containerIndex)));
                values.put(LauncherSettings.Favorites.ITEM_TYPE, Integer.valueOf(c.getInt(itemTypeIndex)));
                values.put("appWidgetId", (Integer) (-1));
                values.put(LauncherSettings.Favorites.SCREEN, Integer.valueOf(c.getInt(screenIndex)));
                values.put(LauncherSettings.Favorites.CELLX, Integer.valueOf(c.getInt(cellXIndex)));
                values.put(LauncherSettings.Favorites.CELLY, Integer.valueOf(c.getInt(cellYIndex)));
                values.put("uri", c.getString(uriIndex));
                values.put(LauncherSettings.Favorites.DISPLAY_MODE, Integer.valueOf(c.getInt(displayModeIndex)));
                rows[i] = values;
                i++;
            }
            db.beginTransaction();
            int total = 0;
            try {
                for (ContentValues contentValues : rows) {
                    if (db.insert(TAG_FAVORITES, null, contentValues) >= 0) {
                        total++;
                    } else {
                        return 0;
                    }
                }
                db.setTransactionSuccessful();
                db.endTransaction();
                return total;
            } finally {
                db.endTransaction();
            }
        }

        @Override // android.database.sqlite.SQLiteOpenHelper
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            int version = oldVersion;
            if (version < 3) {
                db.beginTransaction();
                try {
                    db.execSQL("ALTER TABLE favorites ADD COLUMN appWidgetId INTEGER NOT NULL DEFAULT -1;");
                    db.setTransactionSuccessful();
                    version = 3;
                } catch (SQLException ex) {
                    Log.e(LauncherProvider.LOG_TAG, ex.getMessage(), ex);
                } finally {
                }
                if (version == 3) {
                    convertWidgets(db);
                }
            }
            if (version < 4) {
                db.beginTransaction();
                try {
                    db.execSQL("ALTER TABLE widget_workspaces ADD COLUMN wallpaper_component TEXT;");
                    db.setTransactionSuccessful();
                } catch (SQLException ex2) {
                    Log.e(LauncherProvider.LOG_TAG, ex2.getMessage(), ex2);
                } finally {
                }
            }
        }

        private void convertWidgets(SQLiteDatabase db) {
            int[] bindSources = {LauncherSettings.Favorites.ITEM_TYPE_WIDGET_CLOCK, LauncherSettings.Favorites.ITEM_TYPE_WIDGET_PHOTO_FRAME};
            ArrayList<ComponentName> bindTargets = new ArrayList<>();
            bindTargets.add(new ComponentName("com.android.alarmclock", "com.android.alarmclock.AnalogAppWidgetProvider"));
            bindTargets.add(new ComponentName("com.android.camera", "com.android.camera.PhotoAppWidgetProvider"));
            String selectWhere = LauncherProvider.buildOrWhereString(LauncherSettings.Favorites.ITEM_TYPE, bindSources);
            Cursor c = null;
            boolean allocatedAppWidgets = false;
            db.beginTransaction();
            try {
                try {
                    c = db.query(TAG_FAVORITES, new String[]{LauncherSettings.Favorites.ID}, selectWhere, null, null, null, null);
                    ContentValues values = new ContentValues();
                    while (c != null && c.moveToNext()) {
                        long favoriteId = c.getLong(0);
                        try {
                            int appWidgetId = this.mAppWidgetHost.allocateAppWidgetId();
                            values.clear();
                            values.put("appWidgetId", Integer.valueOf(appWidgetId));
                            values.put(LauncherSettings.Favorites.SPANX, (Integer) 2);
                            values.put(LauncherSettings.Favorites.SPANY, (Integer) 2);
                            String updateWhere = "_id=" + favoriteId;
                            db.update(TAG_FAVORITES, values, updateWhere, null);
                            allocatedAppWidgets = true;
                        } catch (RuntimeException ex) {
                            Log.e(LauncherProvider.LOG_TAG, "Problem allocating appWidgetId", ex);
                        }
                    }
                    db.setTransactionSuccessful();
                    db.endTransaction();
                    if (c != null) {
                        c.close();
                    }
                } catch (SQLException ex2) {
                    Log.w(LauncherProvider.LOG_TAG, "Problem while allocating appWidgetIds for existing widgets", ex2);
                    db.endTransaction();
                    if (c != null) {
                        c.close();
                    }
                }
                if (allocatedAppWidgets) {
                    launchAppWidgetBinder(bindSources, bindTargets);
                }
            } catch (Throwable th) {
                db.endTransaction();
                if (c != null) {
                    c.close();
                }
                throw th;
            }
        }

        private void launchAppWidgetBinder(int[] bindSources, ArrayList<ComponentName> bindTargets) {
            Intent intent = new Intent();
            intent.setComponent(new ComponentName("com.android.settings", "com.android.settings.LauncherAppWidgetBinder"));
            intent.setFlags(268435456);
            Bundle extras = new Bundle();
            extras.putIntArray(LauncherProvider.EXTRA_BIND_SOURCES, bindSources);
            extras.putParcelableArrayList(LauncherProvider.EXTRA_BIND_TARGETS, bindTargets);
            intent.putExtras(extras);
            this.mContext.startActivity(intent);
        }
    }

    static String buildOrWhereString(String column, int[] values) {
        StringBuilder selectWhere = new StringBuilder();
        for (int i = values.length - 1; i >= 0; i--) {
            selectWhere.append(column).append("=").append(values[i]);
            if (i > 0) {
                selectWhere.append(" OR ");
            }
        }
        return selectWhere.toString();
    }

    static class SqlArguments {
        public final String[] args;
        public final String table;
        public final String where;

        SqlArguments(Uri url, String where, String[] args) {
            if (url.getPathSegments().size() == 1) {
                this.table = url.getPathSegments().get(0);
                this.where = where;
                this.args = args;
            } else {
                if (url.getPathSegments().size() != 2) {
                    throw new IllegalArgumentException("Invalid URI: " + url);
                }
                if (!TextUtils.isEmpty(where)) {
                    throw new UnsupportedOperationException("WHERE clause not supported: " + url);
                }
                this.table = url.getPathSegments().get(0);
                this.where = "_id=" + ContentUris.parseId(url);
                this.args = null;
            }
        }

        SqlArguments(Uri url) {
            if (url.getPathSegments().size() == 1) {
                this.table = url.getPathSegments().get(0);
                this.where = null;
                this.args = null;
                return;
            }
            throw new IllegalArgumentException("Invalid URI: " + url);
        }
    }

    static void initWorkspaces(SQLiteDatabase db, Context context) {
        long current = System.currentTimeMillis();
        String[] names = context.getResources().getStringArray(R.array.default_workspace_names);
        for (int i = names.length; i > 0; i--) {
            int translateId = i - 1;
            if (i == 1) {
                translateId = -1;
            }
            db.execSQL("INSERT INTO widget_workspaces VALUES (" + i + ", '" + names[i - 1] + "', " + current + ", 2, " + i + ", " + translateId + ", 'htc_wallpaper_0" + i + "_lockscreen.jpg','');");
            current++;
        }
    }
}
