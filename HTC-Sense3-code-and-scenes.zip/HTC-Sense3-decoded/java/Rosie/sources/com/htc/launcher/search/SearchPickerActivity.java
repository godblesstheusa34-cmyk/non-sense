package com.htc.launcher.search;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import com.htc.app.HtcAlertActivity;
import com.htc.app.HtcAlertController;
import com.htc.launcher.R;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class SearchPickerActivity extends HtcAlertActivity implements DialogInterface.OnClickListener, HtcAlertController.AlertParams.OnPrepareListViewListener, AdapterView.OnItemSelectedListener {
    private static final int GOOGLE_ITEM = 1;
    public static final String PREFERENCES = "launcher";
    private static final int RESULT_OK = -1;
    private static final int SEARCHANYWHERE_ITEM = 0;
    private static final String TAG = "SearchPicker";
    private String choose_search = default_Search_Engine;
    public static String SEARCH_ENGINE = "SearchEngine";
    public static String GOOGLE_INTENT = "android.search.action.GLOBAL_SEARCH";
    public static String SEARCHANYWHERE_INTENT = "com.htc.searchanywhere.START";
    public static String default_Search_Engine = SEARCHANYWHERE_INTENT;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initialDialog();
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface arg0, int which) {
        SharedPreferences preferences = getSharedPreferences("launcher", 0);
        SharedPreferences.Editor editor = preferences.edit();
        switch (which) {
            case -1:
                Log.v(TAG, "user choose " + this.choose_search);
                editor.putString(SEARCH_ENGINE, this.choose_search);
                try {
                    editor.apply();
                    if (this.choose_search != null) {
                        Settings.System.putString(getContentResolver(), SEARCH_ENGINE, this.choose_search);
                        break;
                    }
                } catch (Exception e) {
                    Log.v(TAG, "save value fail");
                    return;
                }
                break;
            case 0:
                this.choose_search = SEARCHANYWHERE_INTENT;
                break;
            case 1:
                this.choose_search = GOOGLE_INTENT;
                break;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void initialDialog() {
        HtcAlertController.AlertParams p = ((HtcAlertActivity) this).mAlertParams;
        p.mTitle = getText(R.string.search_picker_title);
        p.mItems = getResources().getStringArray(R.array.search_choices);
        p.mIsSingleChoice = true;
        p.mOnClickListener = this;
        p.mPositiveButtonText = getString(android.R.string.ok);
        p.mPositiveButtonListener = this;
        p.mNegativeButtonText = getString(android.R.string.cancel);
        p.mPositiveButtonListener = this;
        p.mOnPrepareListViewListener = this;
        setupAlert();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void onPrepareListView(ListView listview) {
        SharedPreferences preferences = getSharedPreferences("launcher", 0);
        String default_search = preferences.getString(SEARCH_ENGINE, "default");
        if (default_search.equals(GOOGLE_INTENT)) {
            ((HtcAlertActivity) this).mAlertParams.mCheckedItem = 1;
        } else if (default_search.equals(SEARCHANYWHERE_INTENT)) {
            ((HtcAlertActivity) this).mAlertParams.mCheckedItem = 0;
        } else {
            ((HtcAlertActivity) this).mAlertParams.mCheckedItem = 0;
        }
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onItemSelected(AdapterView<?> adapterview, View view, int position, long id) {
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onNothingSelected(AdapterView<?> arg0) {
    }
}
