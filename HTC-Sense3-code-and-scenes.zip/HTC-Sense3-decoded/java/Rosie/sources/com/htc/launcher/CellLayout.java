package com.htc.launcher;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.CornerPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.MessageQueue;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewDebug;
import android.view.ViewGroup;
import android.view.ViewParent;
import com.htc.android.rosie.home.fxcontrol.FxScreen;
import com.htc.launcher.CellInfo;
import com.htc.launcher.Draggee;
import com.htc.launcher.Workspace;
import com.htc.launcher.custom.CustomResourceUtil;
import com.htc.launcher.settings.SettingUtil;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class CellLayout extends ViewGroup implements Workspace.Screen {
    static final /* synthetic */ boolean $assertionsDisabled;
    private static final boolean CHECK_CHILDREN_DRAWING_CACHE = false;
    private static final boolean DEBUG_DRAW = false;
    private static final boolean DEBUG_TOUCH;
    static final String LOG_TAG = "CellLayout";
    private static final int NOTIFY_DIRTY = 25;
    private static final int NOTIFY_DIRTY_DELAY = 1500;
    private static final int NOTIFY_REARRANGE = 26;
    private static final int NOTIFY_REARRANGE_DELAY = 500;
    public static final boolean localLOGD;
    private static int sAvailableBoundaryColor;
    private static int sCornerRadius;
    private static int sDropCellColor;
    private static int sLineWidth;
    private static int sOccupiedAreaColor;
    private static Paint sScreenPaint;
    private boolean isShowVacantRect;
    View[] mBackupChildren;
    private int mButtonBarHeight;
    private int mCellHeight;
    private CellInfo mCellInfo;
    private int mCellWidth;
    int[] mCellXY;
    private Rect mChildFrame;
    private boolean mChildHit;
    private Object mCurrentDragInfo;
    private Rect mDirty;
    private boolean mDirtyTag;
    private CellInfo mDragCellInfo;
    private CellInfo mDragOverInfo;
    private RectF mDragRect;
    boolean[][] mDraggingOccupied;
    private int mHeightGap;
    boolean mIsDragging;
    private boolean mIsPause;
    private boolean mIsScrolling;
    private boolean mIsVacantValid;
    private OccupiedDelegation mLandOccupiedDelegation;
    private boolean mLastDownOnOccupiedCell;
    private int mLastDragCellX;
    private int mLastDragCellY;
    private int mLongAxisCells;
    private int mLongAxisEndPadding;
    private int mLongAxisStartPadding;
    private CellInfo.VacantCell mNearestVacant;
    private RectF mNearestVacantBounds;
    private Handler mNotifyHandler;
    boolean[][] mOccupied;
    private boolean[][] mOccupiedDelegationCopy;
    private Paint mPaint;
    private OccupiedDelegation mPortOccupiedDelegation;
    private boolean mPortrait;
    ArrayList<RearrangeInfo> mRearrangeCells;
    private final Rect mRect;
    private Bitmap mScreenBitmap;
    private Canvas mScreensCanvas;
    private ScrollMonitor mScrollMonitor;
    private int mShortAxisCells;
    private int mShortAxisEndPadding;
    private int mShortAxisStartPadding;
    private boolean mShowVacant;
    private MessageQueue mUIMessageQueue;
    private UpdateCellLayoutCacheHandler mUpdateCellLayoutCacheHandler;
    private List<CellInfo.VacantCell> mVacantCells;
    private Rect mVacantInvalidRect;
    private Paint mVacantPaint;
    private Path mVacantPath;
    private final WallpaperManager mWallpaperManager;
    private int mWidthGap;
    private boolean mhasRearrangedVacant;

    public interface OccupiedDelegation {
        void findCoveredCells(CellInfo cellInfo, List<CellInfo> list);

        boolean[][] getDraggingOccupiedCells();

        boolean[][] getOccupiedCells();

        ArrayList<Draggee> getRearrangeItems();

        boolean isTouchOnItem(int i, int i2);

        void moveOccupiedCells(CellInfo cellInfo, CellInfo cellInfo2, FxScreen fxScreen, boolean z);

        void performRearrange(boolean z, ArrayList<RearrangeInfo> arrayList);

        void setOccupiedCells(boolean[] zArr);
    }

    static {
        $assertionsDisabled = !CellLayout.class.desiredAssertionStatus();
        localLOGD = SettingUtil.localLOGD;
        DEBUG_TOUCH = false;
        sCornerRadius = -1;
        sAvailableBoundaryColor = -1;
        sOccupiedAreaColor = -1;
        sDropCellColor = -1;
        sLineWidth = -1;
    }

    public CellLayout(Context context) {
        this(context, null);
    }

    public CellLayout(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public CellLayout(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mIsPause = false;
        this.mPortrait = true;
        this.mRect = new Rect();
        this.mCellInfo = new CellInfo();
        this.mCellXY = new int[2];
        this.mIsDragging = false;
        this.mDragRect = new RectF();
        this.mLastDownOnOccupiedCell = false;
        this.mDirty = new Rect();
        this.isShowVacantRect = false;
        this.mChildFrame = new Rect();
        this.mBackupChildren = null;
        this.mIsScrolling = false;
        this.mDragOverInfo = new CellInfo();
        this.mDragCellInfo = new CellInfo();
        this.mLastDragCellX = -1;
        this.mLastDragCellY = -1;
        this.mRearrangeCells = new ArrayList<>();
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.CellLayout, defStyle, 0);
        this.mCellWidth = a.getDimensionPixelSize(0, 10);
        this.mCellHeight = a.getDimensionPixelSize(1, 10);
        this.mLongAxisStartPadding = a.getDimensionPixelSize(2, 10);
        this.mLongAxisEndPadding = a.getDimensionPixelSize(3, 10);
        this.mShortAxisStartPadding = a.getDimensionPixelSize(4, 10);
        this.mShortAxisEndPadding = a.getDimensionPixelSize(5, 10);
        this.mShortAxisCells = a.getInt(6, 4);
        this.mLongAxisCells = a.getInt(7, 4);
        a.recycle();
        this.mButtonBarHeight = context.getResources().getDimensionPixelSize(R.dimen.launcher_control_height);
        setAlwaysDrawnWithCacheEnabled(false);
        this.mPaint = new Paint();
        this.mPaint.setDither(false);
        this.mPaint.setFilterBitmap(true);
        this.mWallpaperManager = WallpaperManager.getInstance(getContext());
        this.mUIMessageQueue = Looper.myQueue();
        this.mUpdateCellLayoutCacheHandler = new UpdateCellLayoutCacheHandler();
        this.mNotifyHandler = new NotifyDirtyHandler();
    }

    @Override // android.view.View
    public void cancelLongPress() {
        super.cancelLongPress();
        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            View child = getChildAt(i);
            cancelLongPress(child);
        }
    }

    private void cancelLongPress(View targetView) {
        if (targetView instanceof ViewGroup) {
            ViewGroup parentView = (ViewGroup) targetView;
            int childCount = parentView.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View child = parentView.getChildAt(i);
                cancelLongPress(child);
            }
            parentView.cancelLongPress();
            return;
        }
        targetView.cancelLongPress();
    }

    int getCountX() {
        return this.mPortrait ? this.mShortAxisCells : this.mLongAxisCells;
    }

    int getCountY() {
        return this.mPortrait ? this.mLongAxisCells : this.mShortAxisCells;
    }

    @Override // com.htc.launcher.Workspace.Screen
    @Deprecated
    public boolean isVacantVisible() {
        return this.mShowVacant;
    }

    @Override // com.htc.launcher.Workspace.Screen
    @Deprecated
    public boolean hasVacant() {
        return (this.mIsVacantValid && this.mVacantCells.isEmpty()) ? false : true;
    }

    @Override // com.htc.launcher.Workspace.Screen
    @Deprecated
    public void updateVacant(int cellX, int cellY, int spanX, int spanY) {
        if (!this.mIsVacantValid) {
            if (this.mVacantCells == null) {
                this.mVacantCells = new ArrayList();
            }
            boolean[][] occupied = getOccupied(null, true);
            if (cellX >= 0 && cellY >= 0) {
                for (int i = cellX; i < cellX + spanX; i++) {
                    if (i >= occupied.length) {
                        Log.e(LOG_TAG, "Draggee out of bound: cx=" + cellX + ", sx=" + spanX + ", bound=" + occupied.length);
                    } else {
                        for (int j = cellY; j < cellY + spanY; j++) {
                            if (j >= occupied[i].length) {
                                Log.e(LOG_TAG, "Draggee out of bound: cy=" + cellY + ", sy=" + spanY + ", bound=" + occupied[i].length);
                            } else {
                                occupied[i][j] = false;
                            }
                        }
                    }
                }
            }
            if (cellX >= 0 && cellY >= 0) {
                this.mhasRearrangedVacant = true;
            } else {
                CellInfo.VacantCell vCell = findRearrangeCandiatesForSpan(spanX, spanY);
                this.mhasRearrangedVacant = vCell != null;
            }
            findVacantCellsForSpan(this.mVacantCells, spanX, spanY);
            this.mIsVacantValid = true;
        }
    }

    @Override // com.htc.launcher.Workspace.Screen
    public boolean hasRearrangedVacant() {
        return this.mhasRearrangedVacant;
    }

    private void allVacants(List<CellInfo.VacantCell> cells) {
        int x = getCountX();
        int y = getCountY();
        for (int i = 0; i <= x; i++) {
            for (int j = 0; j <= y; j++) {
                CellInfo.VacantCell cell = new CellInfo.VacantCell();
                cell.cellX = i;
                cell.cellY = j;
                cell.spanX = 1;
                cell.spanY = 1;
                cells.add(cell);
            }
        }
    }

    @Override // com.htc.launcher.Workspace.Screen
    public Folder getOpenFolder() {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View child = getChildAt(i);
            LayoutParams lp = (LayoutParams) child.getLayoutParams();
            if (lp.cellHSpan == -1 && lp.cellVSpan == -1 && child.getVisibility() != 8) {
                if (child instanceof Folder) {
                    return (Folder) child;
                }
                if (child instanceof LegacyLayout) {
                    View view = ((LegacyLayout) child).getTheView();
                    if (view instanceof Folder) {
                        return (Folder) view;
                    }
                } else {
                    continue;
                }
            }
        }
        return null;
    }

    void showVacant() {
        if (!this.mShowVacant && this.mIsVacantValid) {
            this.mShowVacant = true;
            if (this.mVacantPath == null) {
                this.mVacantPath = new Path();
                this.mVacantPaint = new Paint();
                this.mNearestVacantBounds = new RectF();
                this.mVacantInvalidRect = new Rect();
            }
            if (sCornerRadius < 0) {
                Resources r = ((View) this).mContext.getResources();
                sCornerRadius = r.getInteger(R.integer.cell_layout_corner_radius);
                sAvailableBoundaryColor = r.getColor(R.color.cell_layout_available_boundary_color);
                sOccupiedAreaColor = r.getColor(R.color.cell_layout_occupied_area_color);
                sDropCellColor = r.getColor(CustomResourceUtil.getColorResIdentifier(((View) this).mContext, "app_selection_highlight", R.color.cell_layout_drop_cell_color));
                sLineWidth = r.getInteger(R.integer.cell_layout_line_width);
            }
            getCellsBoundaryPath(this.mVacantCells, this.mVacantPath);
            this.mNearestVacant = null;
            this.mNearestVacantBounds.setEmpty();
            invalidate();
        }
    }

    @Override // com.htc.launcher.Workspace.Screen
    @Deprecated
    public void clearVacant() {
        if (this.mIsVacantValid) {
            this.mVacantCells.clear();
            this.mIsVacantValid = false;
        }
    }

    @Override // com.htc.launcher.Workspace.Screen
    @Deprecated
    public void hideVacant() {
        this.mShowVacant = false;
        this.mVacantPaint.reset();
        this.mVacantPath.rewind();
        this.mNearestVacant = null;
        this.mNearestVacantBounds.setEmpty();
        invalidate();
    }

    boolean findNearestVacantCell(int x, int y, int spanX, int spanY, boolean showVacant) {
        if (this.mNearestVacantBounds == null) {
            return false;
        }
        int[] cellXY = this.mCellXY;
        pointToDropCell(x, y, spanX, spanY, cellXY);
        if (this.mNearestVacant != null && cellXY[0] == this.mNearestVacant.cellX && cellXY[1] == this.mNearestVacant.cellY && this.isShowVacantRect == showVacant) {
            return true;
        }
        this.isShowVacantRect = showVacant;
        if (!this.mNearestVacantBounds.isEmpty()) {
            this.mVacantInvalidRect.set((int) this.mNearestVacantBounds.left, (int) this.mNearestVacantBounds.top, (int) this.mNearestVacantBounds.right, (int) this.mNearestVacantBounds.bottom);
            this.mVacantInvalidRect.inset(-sLineWidth, -sLineWidth);
            invalidate(this.mVacantInvalidRect);
        }
        if (showVacant) {
            for (CellInfo.VacantCell c : this.mVacantCells) {
                if (c != this.mNearestVacant && cellXY[0] == c.cellX && cellXY[1] == c.cellY) {
                    cellToOutlineRect(c.cellX, c.cellY, c.spanX, c.spanY, this.mNearestVacantBounds);
                    this.mNearestVacant = c;
                    this.mVacantInvalidRect.set((int) this.mNearestVacantBounds.left, (int) this.mNearestVacantBounds.top, (int) this.mNearestVacantBounds.right, (int) this.mNearestVacantBounds.bottom);
                    this.mVacantInvalidRect.inset(-sLineWidth, -sLineWidth);
                    invalidate(this.mVacantInvalidRect);
                    return true;
                }
            }
        }
        this.mNearestVacant = null;
        this.mNearestVacantBounds.setEmpty();
        return false;
    }

    private ArrayList<Integer> getVisitCellForVancant(int upperBound, int index) {
        ArrayList<Integer> indexList = new ArrayList<>();
        int[] offsets = {0, -1, 1, -2, 2, -3, 3, -4, 4};
        for (int i : offsets) {
            int newIndex = index + i;
            if (newIndex >= 0 && newIndex <= upperBound) {
                indexList.add(Integer.valueOf(newIndex));
            }
        }
        return indexList;
    }

    @Override // com.htc.launcher.Workspace.Screen
    public CellInfo.VacantCell findNearestVacantCellsForSpan(CellInfo addCellInfo, int spanX, int spanY) {
        int x = getCountX() - spanX;
        int y = getCountY() - spanY;
        int targetX = (addCellInfo == null || addCellInfo.cellX < 0) ? 0 : addCellInfo.cellX;
        int targetY = (addCellInfo == null || addCellInfo.cellY < 0) ? 0 : addCellInfo.cellY;
        ArrayList<Integer> xIndexArray = getVisitCellForVancant(x, targetX);
        ArrayList<Integer> yIndexArray = getVisitCellForVancant(y, targetY);
        boolean[][] occupied = getOccupied(null, false);
        for (int a = 0; a <= x; a++) {
            int i = xIndexArray.get(a).intValue();
            if (i >= occupied.length) {
                Log.e(LOG_TAG, "Draggee out of bound: i=" + i + ", x=" + x + " bound=" + occupied.length);
            } else {
                for (int b = 0; b <= y; b++) {
                    int j = yIndexArray.get(b).intValue();
                    if (j >= occupied[i].length) {
                        Log.e(LOG_TAG, "Draggee out of bound: j=" + j + ", y=" + y + " bound=" + occupied[i].length);
                    } else if (!occupied[i][j] && !isAreaOccupied(occupied, i, j, i + spanX, j + spanY)) {
                        CellInfo.VacantCell cell = new CellInfo.VacantCell();
                        cell.cellX = i;
                        cell.cellY = j;
                        cell.spanX = spanX;
                        cell.spanY = spanY;
                        return cell;
                    }
                }
            }
        }
        return null;
    }

    @Override // com.htc.launcher.Workspace.Screen
    public void findVacantCellsForSpan(List<CellInfo.VacantCell> cells, int spanX, int spanY) {
        int x = getCountX() - spanX;
        int y = getCountY() - spanY;
        boolean[][] occupied = getOccupied(null, false);
        for (int i = 0; i <= x; i++) {
            if (i >= occupied.length) {
                Log.e(LOG_TAG, "Draggee out of bound: i=" + i + ", x=" + x + " bound=" + occupied.length);
            } else {
                for (int j = 0; j <= y; j++) {
                    if (j >= occupied[i].length) {
                        Log.e(LOG_TAG, "Draggee out of bound: j=" + j + ", y=" + y + " bound=" + occupied[i].length);
                    } else if (!occupied[i][j] && !isAreaOccupied(occupied, i, j, i + spanX, j + spanY)) {
                        CellInfo.VacantCell cell = new CellInfo.VacantCell();
                        cell.cellX = i;
                        cell.cellY = j;
                        cell.spanX = spanX;
                        cell.spanY = spanY;
                        cells.add(cell);
                    }
                }
            }
        }
    }

    @Override // com.htc.launcher.Workspace.Screen
    public boolean tryRearrangeForSpan(Draggee dragItem, int posX, int posY, int spanX, int spanY) {
        this.mNotifyHandler.removeMessages(NOTIFY_REARRANGE);
        List<CellInfo> coveredCells = new ArrayList<>();
        CellInfo currentCell = new CellInfo();
        int[] cellXY = this.mCellXY;
        pointToDropCell(posX, posY, spanX, spanY, cellXY);
        int cellX = cellXY[0];
        int cellY = cellXY[1];
        currentCell.cellX = cellX;
        currentCell.cellY = cellY;
        currentCell.spanX = spanX;
        currentCell.spanY = spanY;
        currentCell.item = dragItem;
        Logger.d("Rearrange", "tryRearrangeForSpan:" + currentCell.toString());
        findCoveredCells(currentCell, coveredCells);
        if (!calculateRearrangeCells(currentCell, coveredCells, this.mRearrangeCells)) {
            return false;
        }
        Logger.d("Rearrange", "tryRearrangeForSpan performRearrange");
        performRearrange(true);
        CellInfo.VacantCell cell = new CellInfo.VacantCell();
        cell.cellX = cellX;
        cell.cellY = cellY;
        cell.spanX = spanX;
        cell.spanY = spanY;
        this.mVacantCells.add(cell);
        return true;
    }

    private CellInfo.VacantCell findRearrangeCandiatesFor1x1(boolean[][] occupied) {
        for (int x = 0; x < getCountX(); x++) {
            for (int y = 0; y < getCountY(); y++) {
                if (!occupied[x][y]) {
                    CellInfo.VacantCell cell = new CellInfo.VacantCell();
                    cell.cellX = 0;
                    cell.cellY = 0;
                    cell.spanX = 1;
                    cell.spanY = 1;
                    this.mVacantCells.add(cell);
                    return cell;
                }
            }
        }
        return null;
    }

    private CellInfo.VacantCell findRearrangeCandiatesFor4x4(boolean[][] occupied) {
        for (int x = 0; x < getCountX(); x++) {
            for (int y = 0; y < getCountY(); y++) {
                if (occupied[x][y]) {
                    return null;
                }
            }
        }
        CellInfo.VacantCell cell = new CellInfo.VacantCell();
        cell.cellX = 0;
        cell.cellY = 0;
        cell.spanX = 1;
        cell.spanY = 1;
        this.mVacantCells.add(cell);
        return cell;
    }

    private boolean hasRoomForSpan(int spanX, int spanY, boolean[][] occupied) {
        int needRoom = spanX * spanY;
        int count = 0;
        for (int x = 0; x < getCountX(); x++) {
            for (int y = 0; y < getCountY(); y++) {
                if (!occupied[x][y]) {
                    count++;
                }
            }
        }
        return count >= needRoom;
    }

    public CellInfo.VacantCell findRearrangeCandiatesForSpan(int spanX, int spanY) {
        if (getCurrentOccupiedDelegation() == null) {
            return null;
        }
        boolean[][] occupied = getCurrentOccupiedDelegation().getOccupiedCells();
        if (1 == spanX && 1 == spanY) {
            return findRearrangeCandiatesFor1x1(occupied);
        }
        if (4 == spanX && 4 == spanY) {
            return findRearrangeCandiatesFor1x1(occupied);
        }
        if (!hasRoomForSpan(spanX, spanY, occupied)) {
            return null;
        }
        for (int y = 0; y < (getCountY() - spanY) + 1; y++) {
            for (int x = 0; x < (getCountX() - spanX) + 1; x++) {
                List<CellInfo> coveredCells = new ArrayList<>();
                CellInfo currentCell = new CellInfo();
                currentCell.cellX = x;
                currentCell.cellY = y;
                currentCell.spanX = spanX;
                currentCell.spanY = spanY;
                findCoveredCells(currentCell, coveredCells);
                if (calculateRearrangeCells(currentCell, coveredCells, this.mRearrangeCells)) {
                    CellInfo.VacantCell cell = new CellInfo.VacantCell();
                    cell.cellX = x;
                    cell.cellY = y;
                    cell.spanX = spanX;
                    cell.spanY = spanY;
                    this.mVacantCells.add(cell);
                    return cell;
                }
            }
        }
        return null;
    }

    private static final boolean isAreaOccupied(boolean[][] occupied, int left, int top, int right, int bottom) {
        for (int i = left; i < right; i++) {
            for (int j = top; j < bottom; j++) {
                try {
                    if (occupied[i][j]) {
                        Logger.d("Rearragne", String.format("isAreaOccupied occupied[%d][%d]=true", Integer.valueOf(i), Integer.valueOf(j)));
                        return true;
                    }
                } catch (Exception e) {
                    Logger.d("Rearragne", String.format("OUT OF BOUND left:%d, top:%d, exception:%s", Integer.valueOf(left), Integer.valueOf(top), e.toString()));
                    return true;
                }
            }
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void cellToOutlineRect(int cellX, int cellY, int spanX, int spanY, RectF rect) {
        cellToRect(cellX, cellY, spanX, spanY, rect);
        int w = this.mWidthGap / 2;
        int h = this.mHeightGap / 2;
        if (w * 2 < this.mWidthGap) {
            w++;
        }
        if (h * 2 < this.mHeightGap) {
            h++;
        }
        rect.inset(-w, -h);
        if (rect.bottom >= getHeight() - this.mButtonBarHeight) {
            rect.bottom = getHeight() - this.mButtonBarHeight;
        }
        if (rect.top <= 0.0f) {
            rect.top = 0.0f;
        }
    }

    private Path getCellBoundaryPath(CellInfo.VacantCell cell) {
        Path path = new Path();
        RectF rect = new RectF();
        cellToOutlineRect(cell.cellX, cell.cellY, cell.spanX, cell.spanY, rect);
        rect.inset(sLineWidth / 2, sLineWidth / 2);
        path.addRoundRect(rect, sCornerRadius, sCornerRadius, Path.Direction.CW);
        return path;
    }

    private void getCellsBoundaryPath(List<CellInfo.VacantCell> cells, Path path) {
        RectF rect = new RectF();
        Rect r = new Rect();
        Region rgn = new Region();
        for (CellInfo.VacantCell c : cells) {
            cellToOutlineRect(c.cellX, c.cellY, c.spanX, c.spanY, rect);
            r.set((int) rect.left, (int) rect.top, (int) rect.right, (int) rect.bottom);
            rgn.union(r);
        }
        path.reset();
        if (!rgn.isEmpty()) {
            Path bnd = new Path();
            rgn.getBoundaryPath(bnd);
            Paint paint = new Paint();
            paint.setStyle(Paint.Style.STROKE);
            paint.setPathEffect(new CornerPathEffect(sCornerRadius));
            paint.getFillPath(bnd, path);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void dispatchDraw(Canvas canvas) {
        Logger.d(LOG_TAG, hashCode() + " dispatchDraw");
        super.dispatchDraw(canvas);
    }

    boolean findCellByView(int[] cell, View view) {
        int count = getChildCount();
        int id = view.getId();
        for (int i = 0; i < count; i++) {
            View child = getChildAt(i);
            View v = child.findViewById(id);
            if (view == v) {
                int id2 = child.getId();
                cell[0] = (id2 >> 8) & 255;
                cell[1] = id2 & 255;
                return true;
            }
        }
        return false;
    }

    boolean restoreFocus(int cellX, int cellY, int id) {
        View v = findViewByCellAndId(cellX, cellY, id);
        if (v == null) {
            return false;
        }
        v.requestFocus();
        return true;
    }

    private View findViewByCellAndId(int cellX, int cellY, int id) {
        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            View child = getChildAt(i);
            View view = child.findViewById(id);
            if (view != null) {
                LayoutParams lp = (LayoutParams) child.getLayoutParams();
                if (lp.cellX == cellX && lp.cellY == cellY) {
                    return view;
                }
            }
        }
        return null;
    }

    @Override // android.view.ViewGroup
    public void addView(View child, int index, ViewGroup.LayoutParams params) {
        LayoutParams cellParams = (LayoutParams) params;
        child.setId(((getId() & 255) << 16) | ((cellParams.cellX & 255) << 8) | (cellParams.cellY & 255));
        super.addView(child, index, params);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestChildFocus(View child, View focused) {
        super.requestChildFocus(child, focused);
        if (child != null) {
            Rect r = new Rect();
            child.getDrawingRect(r);
            requestRectangleOnScreen(r);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.mCellInfo.screen = ((ViewGroup) getParent()).indexOfChild(this);
    }

    void buildChildrenCache() {
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            if (child.isDrawingCacheEnabled()) {
                try {
                    child.getDrawingCache();
                } catch (RuntimeException re) {
                    if (child.getTag() instanceof WidgetProxy) {
                        WidgetProxy proxy = (WidgetProxy) child.getTag();
                        Log.e(WidgetHostHandle.TAG, "widget view : " + proxy.getWidgetView());
                    }
                    throw re;
                }
            }
        }
    }

    public boolean isChildHit() {
        return this.mChildHit;
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchTouchEvent(MotionEvent ev) {
        this.mChildHit = false;
        int N = getChildCount();
        for (int i = 0; i < N; i++) {
            View child = getChildAt(i);
            child.getHitRect(this.mChildFrame);
            if (this.mChildFrame.contains((int) ev.getX(), (int) ev.getY())) {
                if (DEBUG_TOUCH) {
                    Log.d("CellLayout#" + ((getId() - R.id.cell1) + 1), "true touch:" + ev);
                }
                this.mChildHit = true;
            }
        }
        boolean ret = super.dispatchTouchEvent(ev);
        if (DEBUG_TOUCH) {
            Log.d("CellLayout#" + ((getId() - R.id.cell1) + 1), ret + " dispatch touch:" + ev);
        }
        return ret;
    }

    public boolean touchInScreen(int x, int y) {
        int hStartPadding = this.mPortrait ? this.mShortAxisStartPadding : this.mLongAxisStartPadding;
        int hEndPadding = this.mPortrait ? this.mShortAxisEndPadding : this.mLongAxisEndPadding;
        if (x < hStartPadding || x > getWidth() - hEndPadding) {
            setTag(null);
            return false;
        }
        return true;
    }

    @Override // com.htc.launcher.Workspace.Screen
    public boolean isValidCellInfo(float x, float y, CellInfo cellInfo) {
        if ((cellInfo.spanX != 1 || cellInfo.spanY != 1) && !SettingUtil.isTabletDevice()) {
            return true;
        }
        int hStartPadding = this.mPortrait ? this.mShortAxisStartPadding : this.mLongAxisStartPadding;
        int vStartPadding = this.mPortrait ? this.mLongAxisStartPadding : this.mShortAxisStartPadding;
        int XTOUCH_THRESHOLD = (int) (this.mCellWidth * 0.01f * cellInfo.spanX);
        int YTOUCH_THRESHOLD = (int) (this.mCellHeight * 0.01f * cellInfo.spanY);
        int cellBeginX = (cellInfo.cellX * (this.mCellWidth + this.mWidthGap)) + hStartPadding + XTOUCH_THRESHOLD;
        int cellEndX = ((((cellInfo.cellX + cellInfo.spanX) * (this.mCellWidth + this.mWidthGap)) + hStartPadding) - this.mWidthGap) - XTOUCH_THRESHOLD;
        if (x < cellBeginX || x > cellEndX) {
            return false;
        }
        int cellBeginY = (cellInfo.cellY * (this.mCellHeight + this.mHeightGap)) + vStartPadding + YTOUCH_THRESHOLD;
        int cellEndY = ((((cellInfo.cellY + cellInfo.spanY) * (this.mCellHeight + this.mHeightGap)) + vStartPadding) - this.mHeightGap) - YTOUCH_THRESHOLD;
        if (y < cellBeginY || y > cellEndY) {
            return false;
        }
        return true;
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        int action = ev.getAction();
        CellInfo cellInfo = this.mCellInfo;
        if (action == 0) {
            Rect frame = this.mRect;
            int x = ((int) ev.getX()) + ((View) this).mScrollX;
            int y = ((int) ev.getY()) + ((View) this).mScrollY;
            int count = getChildCount();
            if (!touchInScreen(x, y)) {
                setTag(null);
                return false;
            }
            boolean found = false;
            if (localLOGD) {
                Log.d("CellLayout#" + ((getId() - R.id.cell1) + 1), "false , childCount = " + count);
            }
            int i = count - 1;
            while (true) {
                if (i < 0) {
                    break;
                }
                View child = getChildAt(i);
                if (child.getVisibility() == 0 || child.getAnimation() != null) {
                    child.getHitRect(frame);
                    if (frame.contains(x, y)) {
                        LayoutParams lp = (LayoutParams) child.getLayoutParams();
                        cellInfo.item = Draggee.LegacyDraggee.wrap(child);
                        cellInfo.cellX = lp.cellX;
                        cellInfo.cellY = lp.cellY;
                        cellInfo.spanX = lp.cellHSpan;
                        cellInfo.spanY = lp.cellVSpan;
                        cellInfo.valid = true;
                        found = true;
                        this.mDirtyTag = false;
                        break;
                    }
                    if (localLOGD) {
                        Log.d("CellLayout#" + ((getId() - R.id.cell1) + 1), "false#chile(" + i + ") is hit?:false");
                    }
                }
                i--;
            }
            boolean portrait = this.mPortrait;
            int hStartPadding = portrait ? this.mShortAxisStartPadding : this.mLongAxisStartPadding;
            int vStartPadding = portrait ? this.mLongAxisStartPadding : this.mShortAxisStartPadding;
            int tx = ((int) ev.getX()) - hStartPadding;
            int ty = ((int) ev.getY()) - vStartPadding;
            if (getCurrentOccupiedDelegation() != null && getCurrentOccupiedDelegation().isTouchOnItem(tx, ty)) {
                this.mLastDownOnOccupiedCell = true;
            } else {
                this.mLastDownOnOccupiedCell = found;
            }
            setTag(cellInfo);
            if (!found) {
                int[] cellXY = this.mCellXY;
                pointToCellExact(x, y, cellXY);
                int xCount = portrait ? this.mShortAxisCells : this.mLongAxisCells;
                int yCount = portrait ? this.mLongAxisCells : this.mShortAxisCells;
                boolean[][] occupied = getOccupied(null, true);
                cellInfo.item = null;
                cellInfo.cellX = cellXY[0];
                cellInfo.cellY = cellXY[1];
                cellInfo.spanX = 1;
                cellInfo.spanY = 1;
                cellInfo.valid = cellXY[0] >= 0 && cellXY[1] >= 0 && cellXY[0] < xCount && cellXY[1] < yCount && !occupied[cellXY[0]][cellXY[1]];
                this.mDirtyTag = true;
            }
            setTag(cellInfo);
        } else if (action == 1) {
            cellInfo.item = null;
            cellInfo.cellX = -1;
            cellInfo.cellY = -1;
            cellInfo.spanX = 0;
            cellInfo.spanY = 0;
            cellInfo.valid = false;
            this.mDirtyTag = false;
            setTag(cellInfo);
        }
        if (DEBUG_TOUCH) {
            Log.d("CellLayout#" + ((getId() - R.id.cell1) + 1), "false intercept touch:" + ev);
        }
        return false;
    }

    @Override // android.view.View
    public CellInfo getTag() {
        CellInfo info = (CellInfo) super.getTag();
        if (this.mDirtyTag && info != null && info.valid) {
            boolean portrait = this.mPortrait;
            int xCount = portrait ? this.mShortAxisCells : this.mLongAxisCells;
            int yCount = portrait ? this.mLongAxisCells : this.mShortAxisCells;
            boolean[][] occupied = getOccupied(null, true);
            CellInfo.findIntersectingVacantCells(info, info.cellX, info.cellY, xCount, yCount, occupied);
            this.mDirtyTag = false;
        }
        return info;
    }

    @Override // com.htc.launcher.Workspace.Screen
    public CellInfo findAllVacantCells(boolean[] occupiedCells) {
        boolean portrait = this.mPortrait;
        int xCount = portrait ? this.mShortAxisCells : this.mLongAxisCells;
        int yCount = portrait ? this.mLongAxisCells : this.mShortAxisCells;
        boolean[][] occupied = getOccupied(occupiedCells, true);
        CellInfo cellInfo = new CellInfo();
        cellInfo.cellX = -1;
        cellInfo.cellY = -1;
        cellInfo.spanY = 0;
        cellInfo.spanX = 0;
        cellInfo.maxVacantSpanX = ApplicationManager.ALL_PROGRAM_LIST_HIGHEST_PRIORITY;
        cellInfo.maxVacantSpanXSpanY = ApplicationManager.ALL_PROGRAM_LIST_HIGHEST_PRIORITY;
        cellInfo.maxVacantSpanY = ApplicationManager.ALL_PROGRAM_LIST_HIGHEST_PRIORITY;
        cellInfo.maxVacantSpanYSpanX = ApplicationManager.ALL_PROGRAM_LIST_HIGHEST_PRIORITY;
        cellInfo.screen = this.mCellInfo.screen;
        Rect current = cellInfo.current;
        for (int x = 0; x < xCount; x++) {
            for (int y = 0; y < yCount; y++) {
                if (!occupied[x][y]) {
                    current.set(x, y, x, y);
                    CellInfo.findVacantCell(current, xCount, yCount, occupied, cellInfo);
                    occupied[x][y] = true;
                }
            }
        }
        cellInfo.valid = cellInfo.vacantCells.size() > 0;
        return cellInfo;
    }

    void pointToCellExact(int x, int y, int[] result) {
        boolean portrait = this.mPortrait;
        int hStartPadding = portrait ? this.mShortAxisStartPadding : this.mLongAxisStartPadding;
        int vStartPadding = portrait ? this.mLongAxisStartPadding : this.mShortAxisStartPadding;
        result[0] = (x - hStartPadding) / (this.mCellWidth + this.mWidthGap);
        result[1] = (y - vStartPadding) / (this.mCellHeight + this.mHeightGap);
        int xAxis = portrait ? this.mShortAxisCells : this.mLongAxisCells;
        int yAxis = portrait ? this.mLongAxisCells : this.mShortAxisCells;
        if (result[0] < 0) {
            result[0] = 0;
        }
        if (result[0] >= xAxis) {
            result[0] = xAxis - 1;
        }
        if (result[1] < 0) {
            result[1] = 0;
        }
        if (result[1] >= yAxis) {
            result[1] = yAxis - 1;
        }
    }

    @Override // com.htc.launcher.Workspace.Screen
    public void pointToDropCell(int x, int y, int spanX, int spanY, int[] result) {
        pointToCellRounded(x, y, result);
        boolean portrait = this.mPortrait;
        int xAxis = portrait ? this.mShortAxisCells : this.mLongAxisCells;
        int yAxis = portrait ? this.mLongAxisCells : this.mShortAxisCells;
        if (result[0] + spanX > xAxis) {
            result[0] = xAxis - spanX;
        }
        if (result[1] + spanY > yAxis) {
            result[1] = yAxis - spanY;
        }
    }

    void pointToCellRounded(int x, int y, int[] result) {
        pointToCellExact((this.mCellWidth / 2) + x, (this.mCellHeight / 2) + y, result);
    }

    @Override // com.htc.launcher.Workspace.Screen
    public void cellToPoint(int cellX, int cellY, int[] result) {
        boolean portrait = this.mPortrait;
        int hStartPadding = portrait ? this.mShortAxisStartPadding : this.mLongAxisStartPadding;
        int vStartPadding = portrait ? this.mLongAxisStartPadding : this.mShortAxisStartPadding;
        result[0] = ((this.mCellWidth + this.mWidthGap) * cellX) + hStartPadding;
        result[1] = ((this.mCellHeight + this.mHeightGap) * cellY) + vStartPadding;
    }

    private void measureGapSize() {
        int heightSpecSize = getMeasuredHeight();
        int widthSpecSize = getMeasuredWidth();
        int cellWidth = this.mCellWidth;
        int cellHeight = this.mCellHeight;
        int shortAxisCells = this.mShortAxisCells;
        int longAxisCells = this.mLongAxisCells;
        int longAxisStartPadding = this.mLongAxisStartPadding;
        int longAxisEndPadding = this.mLongAxisEndPadding;
        int shortAxisStartPadding = this.mShortAxisStartPadding;
        int shortAxisEndPadding = this.mShortAxisEndPadding;
        this.mPortrait = heightSpecSize > widthSpecSize;
        int numShortGaps = shortAxisCells - 1;
        int numLongGaps = longAxisCells - 1;
        if (this.mPortrait) {
            int vSpaceLeft = ((heightSpecSize - longAxisStartPadding) - longAxisEndPadding) - (cellHeight * longAxisCells);
            this.mHeightGap = vSpaceLeft / numLongGaps;
            int hSpaceLeft = ((widthSpecSize - shortAxisStartPadding) - shortAxisEndPadding) - (cellWidth * shortAxisCells);
            if (numShortGaps > 0) {
                this.mWidthGap = hSpaceLeft / numShortGaps;
                return;
            } else {
                this.mWidthGap = 0;
                return;
            }
        }
        int hSpaceLeft2 = ((widthSpecSize - longAxisStartPadding) - longAxisEndPadding) - (cellWidth * longAxisCells);
        this.mWidthGap = hSpaceLeft2 / numLongGaps;
        int vSpaceLeft2 = ((heightSpecSize - shortAxisStartPadding) - shortAxisEndPadding) - (cellHeight * shortAxisCells);
        if (numShortGaps > 0) {
            this.mHeightGap = vSpaceLeft2 / numShortGaps;
        } else {
            this.mHeightGap = 0;
        }
    }

    @Override // android.view.View
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int widthSpecMode = View.MeasureSpec.getMode(widthMeasureSpec);
        int widthSpecSize = View.MeasureSpec.getSize(widthMeasureSpec);
        int heightSpecMode = View.MeasureSpec.getMode(heightMeasureSpec);
        int heightSpecSize = View.MeasureSpec.getSize(heightMeasureSpec);
        if (widthSpecMode == 0 || heightSpecMode == 0) {
            throw new RuntimeException("CellLayout cannot have UNSPECIFIED dimensions");
        }
        setMeasuredDimension(widthSpecSize, heightSpecSize);
        int cellWidth = this.mCellWidth;
        int cellHeight = this.mCellHeight;
        int longAxisStartPadding = this.mLongAxisStartPadding;
        int shortAxisStartPadding = this.mShortAxisStartPadding;
        measureGapSize();
        if (this.mOccupied == null) {
            if (this.mPortrait) {
                this.mOccupied = (boolean[][]) Array.newInstance((Class<?>) Boolean.TYPE, this.mShortAxisCells, this.mLongAxisCells);
            } else {
                this.mOccupied = (boolean[][]) Array.newInstance((Class<?>) Boolean.TYPE, this.mLongAxisCells, this.mShortAxisCells);
            }
        }
        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            View child = getChildAt(i);
            LayoutParams lp = (LayoutParams) child.getLayoutParams();
            if (this.mPortrait) {
                lp.setup(cellWidth, cellHeight, this.mWidthGap, this.mHeightGap, shortAxisStartPadding, longAxisStartPadding, this.mShortAxisCells, this.mLongAxisCells);
            } else {
                lp.setup(cellWidth, cellHeight, this.mWidthGap, this.mHeightGap, longAxisStartPadding, shortAxisStartPadding, this.mLongAxisCells, this.mShortAxisCells);
            }
            int childWidthMeasureSpec = View.MeasureSpec.makeMeasureSpec(((ViewGroup.LayoutParams) lp).width, 1073741824);
            int childheightMeasureSpec = View.MeasureSpec.makeMeasureSpec(((ViewGroup.LayoutParams) lp).height, 1073741824);
            child.measure(childWidthMeasureSpec, childheightMeasureSpec);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            View child = getChildAt(i);
            if (child.getVisibility() != 8) {
                LayoutParams lp = (LayoutParams) child.getLayoutParams();
                int childLeft = lp.x;
                int childTop = lp.y;
                child.layout(childLeft, childTop, ((ViewGroup.LayoutParams) lp).width + childLeft, ((ViewGroup.LayoutParams) lp).height + childTop);
                if (lp.dropped) {
                    lp.dropped = false;
                    this.mWallpaperManager.sendWallpaperCommand(getWindowToken(), "android.home.drop", (((ViewGroup.LayoutParams) lp).width / 2) + childLeft, (((ViewGroup.LayoutParams) lp).height / 2) + childTop, 0, null);
                }
            }
        }
    }

    @Override // android.view.ViewGroup
    protected void setChildrenDrawingCacheEnabled(boolean enabled) {
        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            View view = getChildAt(i);
            view.setDrawingCacheEnabled(enabled);
            if (!enabled) {
                view.destroyDrawingCache();
            }
        }
    }

    @Override // android.view.ViewGroup
    protected void setChildrenDrawnWithCacheEnabled(boolean enabled) {
        super.setChildrenDrawnWithCacheEnabled(enabled);
    }

    @Override // com.htc.launcher.Workspace.Screen
    public boolean acceptChildDrop(int x, int y, int cellHSpan, int cellVSpan, Draggee cell) {
        int[] cellXY = this.mCellXY;
        pointToDropCell(x, y, cellHSpan, cellVSpan, cellXY);
        int cellX = cellXY[0];
        int cellY = cellXY[1];
        revertRearrangedCells(cellX, cellY, cellHSpan, cellVSpan);
        return findCell(cellX, cellY, cellHSpan, cellVSpan, cell) == null;
    }

    View findCell(int cellX, int cellY, int cellHSpan, int cellVSpan, Draggee ignoreCell) {
        if (cellX >= 0) {
            if (cellX + cellHSpan <= (this.mPortrait ? this.mShortAxisCells : this.mLongAxisCells) && cellY >= 0) {
                if (cellY + cellVSpan <= (this.mPortrait ? this.mLongAxisCells : this.mShortAxisCells)) {
                    boolean[][] occupied = getOccupied(null, true);
                    if (ignoreCell != null) {
                        ItemInfo info = ignoreCell.getItemInfo();
                        int right = info.cellX + info.spanX;
                        int bottom = info.cellY + info.spanY;
                        for (int x = info.cellX; x < right; x++) {
                            for (int y = info.cellY; y < bottom; y++) {
                                occupied[x][y] = false;
                            }
                        }
                    }
                    int right2 = cellX + cellHSpan;
                    int bottom2 = cellY + cellVSpan;
                    for (int x2 = cellX; x2 < right2; x2++) {
                        for (int y2 = cellY; y2 < bottom2; y2++) {
                            if (occupied[x2][y2]) {
                                return this;
                            }
                        }
                    }
                    return null;
                }
            }
        }
        return this;
    }

    @Override // com.htc.launcher.Workspace.Screen
    public void addItem(Draggee item, int index) {
        addView((View) item.getItem(), index);
    }

    @Override // com.htc.launcher.Workspace.Screen
    public boolean removeItem(Draggee item) {
        if (item.getItem() instanceof FxItem) {
            return false;
        }
        View view = (View) item.getItem();
        if (view instanceof LegacyLayout) {
            LegacyLayout ll = (LegacyLayout) view;
            ll.fxDetach();
        }
        removeView(view);
        return view.getParent() == null;
    }

    @Override // com.htc.launcher.Workspace.Screen
    public void onDropChild(Draggee cell, int x, int y, int spanX, int spanY) {
        int[] cellXY = this.mCellXY;
        pointToDropCell(x, y, spanX, spanY, cellXY);
        onDropChildByCell(cell, cellXY[0], cellXY[1], spanX, spanY);
    }

    @Override // com.htc.launcher.Workspace.Screen
    public void onDropChildByCell(Draggee cell, int cellX, int cellY, int spanX, int spanY) {
        cell.onDrop((DropTarget) getParent(), cellX, cellY);
        invalidate();
        this.mDragRect.setEmpty();
    }

    void onDropAborted(Draggee cell) {
        if (cell != null) {
            cell.onDropAbort((DragSource) getParent());
            invalidate();
        }
        this.mDragRect.setEmpty();
    }

    @Override // com.htc.launcher.Workspace.Screen
    public void onDragChild(Draggee cell) {
        this.mDragRect.setEmpty();
        ItemInfo info = cell.getItemInfo();
        this.mDragCellInfo.cellX = info.cellX;
        this.mDragCellInfo.cellY = info.cellY;
        this.mDragCellInfo.spanX = info.spanX;
        this.mDragCellInfo.spanY = info.spanY;
        this.mDragCellInfo.valid = true;
        Logger.d(LOG_TAG, "mDragCellInfo:" + this.mDragCellInfo.toString());
        this.mIsDragging = true;
    }

    @Override // com.htc.launcher.Workspace.Screen
    public void onDragOverChild(View child, int cellX, int cellY) {
        int[] cellXY = this.mCellXY;
        LayoutParams lp = (LayoutParams) child.getLayoutParams();
        pointToDropCell(cellX, cellY, lp.cellHSpan, lp.cellVSpan, cellXY);
        cellToRect(cellXY[0], cellXY[1], lp.cellHSpan, lp.cellVSpan, this.mDragRect);
        invalidate();
    }

    @Override // com.htc.launcher.Workspace.Screen
    public void onDragExit(int x, int y, boolean bDropOnMe) {
        if (!bDropOnMe) {
            hideDropArea();
            resetRearrangeLastDragInfo();
            revertRearrangedCells(-1, -1, 0, 0);
        }
    }

    @Override // com.htc.launcher.Workspace.Screen
    public void cellToRect(int cellX, int cellY, int cellHSpan, int cellVSpan, RectF dragRect) {
        boolean portrait = this.mPortrait;
        int cellWidth = this.mCellWidth;
        int cellHeight = this.mCellHeight;
        int widthGap = this.mWidthGap;
        int heightGap = this.mHeightGap;
        int hStartPadding = portrait ? this.mShortAxisStartPadding : this.mLongAxisStartPadding;
        int vStartPadding = portrait ? this.mLongAxisStartPadding : this.mShortAxisStartPadding;
        int width = (cellHSpan * cellWidth) + ((cellHSpan - 1) * widthGap);
        int height = (cellVSpan * cellHeight) + ((cellVSpan - 1) * heightGap);
        int x = hStartPadding + ((cellWidth + widthGap) * cellX);
        int y = vStartPadding + ((cellHeight + heightGap) * cellY);
        dragRect.set(x, y, x + width, y + height);
    }

    @Override // com.htc.launcher.Workspace.Screen
    public void cellToWidgetRect(int cellX, int cellY, int cellHSpan, int cellVSpan, RectF dragRect) {
        boolean portrait = this.mPortrait;
        int cellWidth = this.mCellWidth;
        int cellHeight = this.mCellHeight;
        int widthGap = this.mWidthGap;
        int heightGap = this.mHeightGap;
        int hStartPadding = portrait ? this.mShortAxisStartPadding : this.mLongAxisStartPadding;
        int vStartPadding = portrait ? this.mLongAxisStartPadding : this.mShortAxisStartPadding;
        int width = (cellHSpan * cellWidth) + ((cellHSpan - 1) * widthGap);
        int height = (cellVSpan * cellHeight) + ((cellVSpan - 1) * heightGap);
        int x = hStartPadding + ((cellWidth + widthGap) * cellX);
        int y = vStartPadding + ((cellHeight + heightGap) * cellY);
        dragRect.set(x, y, x + width, y + height);
    }

    public int[] rectToCell(int width, int height) {
        Resources resources = getResources();
        int actualWidth = resources.getDimensionPixelSize(R.dimen.cell_width);
        int actualHeight = resources.getDimensionPixelSize(R.dimen.cell_height);
        int smallerSize = Math.min(actualWidth, actualHeight);
        int spanX = (width + smallerSize) / smallerSize;
        int spanY = (height + smallerSize) / smallerSize;
        return new int[]{spanX, spanY};
    }

    boolean[] getOccupiedCells() {
        boolean portrait = this.mPortrait;
        int xCount = portrait ? this.mShortAxisCells : this.mLongAxisCells;
        int yCount = portrait ? this.mLongAxisCells : this.mShortAxisCells;
        boolean[][] occupied = getOccupied(null, true);
        boolean[] flat = new boolean[xCount * yCount];
        for (int y = 0; y < yCount; y++) {
            for (int x = 0; x < xCount; x++) {
                flat[(y * xCount) + x] = occupied[x][y];
            }
        }
        return flat;
    }

    private void findOccupiedCells(int xCount, int yCount, boolean[][] occupied) {
        for (int x = 0; x < xCount; x++) {
            for (int y = 0; y < yCount; y++) {
                occupied[x][y] = false;
            }
        }
        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            View child = getChildAt(i);
            if (!(child instanceof Folder)) {
                LayoutParams lp = (LayoutParams) child.getLayoutParams();
                for (int x2 = lp.cellX; x2 < lp.cellX + lp.cellHSpan && x2 < xCount; x2++) {
                    for (int y2 = lp.cellY; y2 < lp.cellY + lp.cellVSpan && y2 < yCount; y2++) {
                        try {
                            occupied[x2][y2] = true;
                        } catch (ArrayIndexOutOfBoundsException e) {
                        }
                    }
                }
            }
        }
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attrs) {
        return new LayoutParams(getContext(), attrs);
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams p) {
        return p instanceof LayoutParams;
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams p) {
        return new LayoutParams(p);
    }

    int[] getMeasureSpec() {
        int[] specs = new int[2];
        if (getMeasuredWidth() <= 0) {
            int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
            specs[1] = makeMeasureSpec;
            specs[0] = makeMeasureSpec;
        } else {
            specs[0] = View.MeasureSpec.makeMeasureSpec(ApplicationManager.ALL_PROGRAM_LIST_HIGHEST_PRIORITY, this.mCellWidth);
            specs[1] = View.MeasureSpec.makeMeasureSpec(ApplicationManager.ALL_PROGRAM_LIST_HIGHEST_PRIORITY, this.mCellHeight);
        }
        return specs;
    }

    public static class LayoutParams extends ViewGroup.MarginLayoutParams {

        @ViewDebug.ExportedProperty
        public int cellHSpan;

        @ViewDebug.ExportedProperty
        public int cellVSpan;

        @ViewDebug.ExportedProperty
        public int cellX;

        @ViewDebug.ExportedProperty
        public int cellY;
        boolean dropped;
        public boolean isDragging;

        @ViewDebug.ExportedProperty
        int x;

        @ViewDebug.ExportedProperty
        int y;

        public LayoutParams(Context c, AttributeSet attrs) {
            super(c, attrs);
            this.cellHSpan = 1;
            this.cellVSpan = 1;
        }

        public LayoutParams(ViewGroup.LayoutParams source) {
            super(source);
            this.cellHSpan = 1;
            this.cellVSpan = 1;
        }

        public LayoutParams(int cellX, int cellY, int cellHSpan, int cellVSpan) {
            super(-1, -1);
            this.cellX = cellX;
            this.cellY = cellY;
            this.cellHSpan = cellHSpan;
            this.cellVSpan = cellVSpan;
        }

        public void setup(int cellWidth, int cellHeight, int widthGap, int heightGap, int hStartPadding, int vStartPadding, int numHorizontalCell, int numVerticalCell) {
            int myCellHSpan = this.cellHSpan == -1 ? numHorizontalCell : this.cellHSpan;
            int myCellVSpan = this.cellVSpan == -1 ? numVerticalCell : this.cellVSpan;
            int myCellX = this.cellX;
            int myCellY = this.cellY;
            ((ViewGroup.LayoutParams) this).width = (myCellHSpan * cellWidth) + ((myCellHSpan - 1) * widthGap);
            ((ViewGroup.LayoutParams) this).height = (myCellVSpan * cellHeight) + ((myCellVSpan - 1) * heightGap);
            this.x = ((cellWidth + widthGap) * myCellX) + hStartPadding;
            this.y = ((cellHeight + heightGap) * myCellY) + vStartPadding;
        }
    }

    public boolean lastDownOnOccupiedCell() {
        return this.mLastDownOnOccupiedCell;
    }

    public void setDragInfo(Object dragInfo) {
        this.mCurrentDragInfo = dragInfo;
    }

    @Override // android.view.ViewGroup
    public void removeAllViewsInLayout() {
        super.removeAllViewsInLayout();
        if (localLOGD) {
            Thread.dumpStack();
        }
        setTag(null);
        this.mCellInfo = new CellInfo();
    }

    @Override // android.view.ViewGroup
    public void removeAllViews() {
        if (localLOGD) {
            Thread.dumpStack();
        }
        super.removeAllViews();
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public void removeView(View view) {
        if (localLOGD) {
            Thread.dumpStack();
        }
        super.removeView(view);
    }

    @Override // android.view.ViewGroup
    public void removeViewAt(int index) {
        if (localLOGD) {
            Thread.dumpStack();
        }
        super.removeViewAt(index);
    }

    @Override // android.view.ViewGroup
    public void removeViewInLayout(View view) {
        if (localLOGD) {
            Thread.dumpStack();
        }
        super.removeViewInLayout(view);
    }

    @Override // android.view.ViewGroup
    public void removeViews(int start, int count) {
        if (localLOGD) {
            Thread.dumpStack();
        }
        super.removeViews(start, count);
    }

    @Override // android.view.ViewGroup
    public void removeViewsInLayout(int start, int count) {
        if (localLOGD) {
            Thread.dumpStack();
        }
        super.removeViewsInLayout(start, count);
    }

    void clear() {
        int N = getChildCount();
        for (int i = 0; i < N; i++) {
            View v = getChildAt(i);
            if (v instanceof LegacyLayout) {
                ((LegacyLayout) v).removeTheView();
            }
        }
        removeAllViewsInLayout();
    }

    @Override // android.view.ViewGroup
    protected boolean drawChild(Canvas canvas, View child, long drawingTime) {
        try {
            return super.drawChild(canvas, child, drawingTime);
        } catch (RuntimeException rex) {
            Log.e(WidgetHostHandle.TAG, "CellLayout exception: " + child);
            Log.e(WidgetHostHandle.TAG, "CellLayout exception, tag: " + child.getTag());
            if (child.getTag() instanceof WidgetProxy) {
                WidgetProxy proxy = (WidgetProxy) child.getTag();
                Log.e(WidgetHostHandle.TAG, "widget view : " + proxy.getWidgetView());
            }
            throw rex;
        } catch (StackOverflowError ex) {
            if (child.getTag() instanceof WidgetProxy) {
                WidgetProxy proxy2 = (WidgetProxy) child.getTag();
                Log.e(WidgetHostHandle.TAG, "widget view : " + proxy2.getWidgetView());
            }
            throw ex;
        }
    }

    @Deprecated
    public void updateCellLayoutCache() {
    }

    public boolean isCacheReady() {
        return (this.mScreenBitmap == null || this.mScreenBitmap.isRecycled()) ? false : true;
    }

    @Deprecated
    public void drawScreenCache(Canvas canvas) {
        int restoreTo = canvas.save();
        canvas.translate(((View) this).mLeft, ((View) this).mTop);
        if (this.mScreenBitmap == null) {
            updateCellLayoutCache();
        }
        if (sScreenPaint == null) {
            sScreenPaint = new Paint();
            sScreenPaint.setDither(false);
            if (Launcher.sUseWallpaperService) {
                sScreenPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC));
            }
        }
        canvas.drawBitmap(this.mScreenBitmap, 0.0f, 0.0f, sScreenPaint);
        canvas.restoreToCount(restoreTo);
    }

    public void updateOrientation(boolean portrait) {
        this.mScreenBitmap = null;
        this.mScreensCanvas = null;
        Resources resources = getResources();
        ViewGroup.LayoutParams CellParams = getLayoutParams();
        CellParams.height = -1;
        CellParams.width = -1;
        this.mShortAxisCells = resources.getInteger(R.integer.workspace_screen_cl_short_axis_cells);
        this.mLongAxisCells = resources.getInteger(R.integer.workspace_screen_cl_long_axis_cells);
        this.mLongAxisStartPadding = resources.getDimensionPixelSize(R.dimen.workspace_screen_cl_long_axis_start_padding);
        this.mLongAxisEndPadding = resources.getDimensionPixelSize(R.dimen.workspace_screen_cl_long_axis_end_padding);
        this.mShortAxisStartPadding = resources.getDimensionPixelSize(R.dimen.workspace_screen_cl_short_axis_start_padding);
        this.mShortAxisEndPadding = resources.getDimensionPixelSize(R.dimen.workspace_screen_cl_short_axis_end_padding);
        this.mCellWidth = resources.getDimensionPixelSize(R.dimen.workspace_screen_cl_cell_width);
        this.mCellHeight = resources.getDimensionPixelSize(R.dimen.workspace_screen_cl_cell_height);
        if (portrait) {
            this.mButtonBarHeight = getContext().getResources().getDimensionPixelSize(R.dimen.launcher_control_height);
        } else {
            this.mButtonBarHeight = 0;
        }
        measureGapSize();
    }

    public void tempRemoveChildren() {
        int count = getChildCount();
        this.mBackupChildren = new View[count];
        for (int i = 0; i < count; i++) {
            View child = getChildAt(i);
            this.mBackupChildren[i] = child;
        }
        removeAllViews();
    }

    public void restoreRemovedChildren() {
        if (this.mBackupChildren != null) {
            for (int i = 0; i < this.mBackupChildren.length; i++) {
                addView(this.mBackupChildren[i]);
            }
            this.mBackupChildren = null;
        }
    }

    public void clearTempRemovedChildren() {
        this.mBackupChildren = null;
    }

    @Deprecated
    public void updateScreenIndex(int currentIndex) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childView = getChildAt(i);
            Object tag = childView.getTag();
            if (tag instanceof ItemInfo) {
                ((ItemInfo) tag).screen = currentIndex;
            }
        }
    }

    public void setScrollMonitor(ScrollMonitor scrollMonitor) {
        this.mScrollMonitor = scrollMonitor;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public ViewParent invalidateChildInParent(int[] location, Rect dirty) {
        ViewParent vp = super.invalidateChildInParent(location, dirty);
        this.mDirty.union(dirty);
        return vp;
    }

    @Override // android.view.View
    public void invalidate() {
        if (this.mDirty == null) {
            this.mDirty = new Rect();
        }
        this.mDirty.union(0, 0, ((View) this).mRight - ((View) this).mLeft, ((View) this).mBottom - ((View) this).mTop);
        super.invalidate();
    }

    @Override // android.view.View
    public void invalidate(int l, int t, int r, int b) {
        if (this.mDirty == null) {
            this.mDirty = new Rect();
        }
        int scrollX = ((View) this).mScrollX;
        int scrollY = ((View) this).mScrollY;
        this.mDirty.union(l - scrollX, t - scrollY, r - scrollX, b - scrollY);
        super.invalidate(l, t, r, b);
    }

    @Override // android.view.View
    public void invalidate(Rect dirty) {
        if (this.mDirty == null) {
            this.mDirty = new Rect();
        }
        int scrollX = ((View) this).mScrollX;
        int scrollY = ((View) this).mScrollY;
        this.mDirty.union(dirty.left - scrollX, dirty.top - scrollY, dirty.right - scrollX, dirty.bottom - scrollY);
        super.invalidate(dirty);
    }

    private void notifyDirty() {
        if (!this.mIsScrolling) {
            if (this.mNotifyHandler == null) {
                this.mNotifyHandler = new NotifyDirtyHandler();
            }
            this.mNotifyHandler.removeMessages(NOTIFY_DIRTY);
            Message msg = this.mNotifyHandler.obtainMessage(NOTIFY_DIRTY);
            if (!this.mNotifyHandler.sendMessageDelayed(msg, 1500L)) {
                Log.e(LOG_TAG, "sendMessage error.");
            }
        }
    }

    public void stopAutoUpdateCellLayoutCache() {
        if (this.mNotifyHandler == null) {
            this.mNotifyHandler = new NotifyDirtyHandler();
        }
        this.mNotifyHandler.removeMessages(NOTIFY_DIRTY);
    }

    private class NotifyDirtyHandler extends Handler {
        private NotifyDirtyHandler() {
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case CellLayout.NOTIFY_DIRTY /* 25 */:
                    if (!CellLayout.this.mIsScrolling && !CellLayout.this.mIsPause) {
                        if (CellLayout.localLOGD) {
                            Log.d("DEBUG", "add UpdateCellLayoutCacheHandler into Idle Handler");
                        }
                        CellLayout.this.mUIMessageQueue.addIdleHandler(CellLayout.this.mUpdateCellLayoutCacheHandler);
                        break;
                    }
                    break;
                case CellLayout.NOTIFY_REARRANGE /* 26 */:
                    if (CellLayout.this.mDragOverInfo != null) {
                        int X0 = CellLayout.this.mDragOverInfo.cellX;
                        int Y0 = CellLayout.this.mDragOverInfo.cellY;
                        int spanX = CellLayout.this.mDragOverInfo.spanX;
                        int spanY = CellLayout.this.mDragOverInfo.spanY;
                        CellLayout.this.mNearestVacant = new CellInfo.VacantCell();
                        CellLayout.this.mNearestVacant.cellX = X0;
                        CellLayout.this.mNearestVacant.cellY = Y0;
                        CellLayout.this.mNearestVacant.spanX = spanX;
                        CellLayout.this.mNearestVacant.spanY = spanY;
                        if (CellLayout.this.mNearestVacantBounds != null) {
                            CellLayout.this.cellToOutlineRect(X0, Y0, spanX, spanY, CellLayout.this.mNearestVacantBounds);
                        }
                        Logger.d("Rearrange", "handleMessage performRearrange");
                        CellLayout.this.performRearrange(true);
                        break;
                    } else {
                        Log.w(CellLayout.LOG_TAG, "NOTIFY_REARRANGE but mDragOverInfo is null");
                        break;
                    }
                default:
                    super.handleMessage(msg);
                    break;
            }
        }
    }

    private class UpdateCellLayoutCacheHandler extends Handler implements MessageQueue.IdleHandler {
        private UpdateCellLayoutCacheHandler() {
        }

        @Override // android.os.MessageQueue.IdleHandler
        public boolean queueIdle() {
            if (!CellLayout.this.mIsScrolling && !CellLayout.this.mIsPause) {
                CellLayout.this.updateCellLayoutCache();
                return false;
            }
            return false;
        }
    }

    @Deprecated
    public void beginScroll() {
        this.mIsScrolling = true;
    }

    @Deprecated
    public void endScroll() {
        this.mIsScrolling = false;
    }

    public final Bitmap getScreenBitmap() {
        return this.mScreenBitmap;
    }

    public void onPause() {
        this.mIsPause = true;
    }

    public void onResume() {
        this.mIsPause = false;
    }

    public void setOccupiedDelegation(OccupiedDelegation delegation, boolean bPortrait) {
        if (bPortrait) {
            this.mPortOccupiedDelegation = delegation;
        } else {
            this.mLandOccupiedDelegation = delegation;
        }
    }

    private boolean[][] getOccupied(boolean[] occupiedCells, boolean update) {
        boolean portrait = this.mPortrait;
        int xCount = portrait ? this.mShortAxisCells : this.mLongAxisCells;
        int yCount = portrait ? this.mLongAxisCells : this.mShortAxisCells;
        if (getCurrentOccupiedDelegation() != null) {
            if (occupiedCells != null) {
                getCurrentOccupiedDelegation().setOccupiedCells(occupiedCells);
            }
            boolean[][] occupied = getCurrentOccupiedDelegation().getOccupiedCells();
            if (!$assertionsDisabled && occupied == null) {
                throw new AssertionError();
            }
            if (!$assertionsDisabled && occupied.length != xCount) {
                throw new AssertionError();
            }
            if (!$assertionsDisabled && (occupied[0] == null || occupied[0].length != yCount)) {
                throw new AssertionError();
            }
            if (this.mOccupiedDelegationCopy == null) {
                this.mOccupiedDelegationCopy = (boolean[][]) Array.newInstance((Class<?>) Boolean.TYPE, xCount, yCount);
            }
            boolean[][] copy = this.mOccupiedDelegationCopy;
            for (int y = 0; y < yCount; y++) {
                for (int x = 0; x < xCount; x++) {
                    copy[x][y] = occupied[x][y];
                }
            }
            if (localLOGD) {
                for (int i = 0; i < xCount; i++) {
                    Log.d("Delegation", "column#" + i + columnString(copy[i]));
                }
            }
            return copy;
        }
        if (this.mOccupied == null) {
            if (this.mPortrait) {
                this.mOccupied = (boolean[][]) Array.newInstance((Class<?>) Boolean.TYPE, this.mShortAxisCells, this.mLongAxisCells);
            } else {
                this.mOccupied = (boolean[][]) Array.newInstance((Class<?>) Boolean.TYPE, this.mLongAxisCells, this.mShortAxisCells);
            }
        }
        boolean[][] occupied2 = this.mOccupied;
        if (update) {
            if (occupiedCells != null) {
                for (int y2 = 0; y2 < yCount; y2++) {
                    for (int x2 = 0; x2 < xCount; x2++) {
                        occupied2[x2][y2] = occupiedCells[(y2 * xCount) + x2];
                    }
                }
            } else {
                findOccupiedCells(xCount, yCount, occupied2);
            }
            if (localLOGD) {
                for (int i2 = 0; i2 < xCount; i2++) {
                    Log.d("Original", "column#" + i2 + columnString(this.mOccupied[i2]));
                }
            }
        }
        return this.mOccupied;
    }

    private String columnString(boolean[] column) {
        StringBuilder sb = new StringBuilder();
        for (boolean z : column) {
            sb.append(z ? "*" : " ");
        }
        return sb.toString();
    }

    private OccupiedDelegation getCurrentOccupiedDelegation() {
        return this.mPortrait ? this.mPortOccupiedDelegation : this.mLandOccupiedDelegation;
    }

    private OccupiedDelegation getAnotherOccupiedDelegation() {
        return this.mPortrait ? this.mLandOccupiedDelegation : this.mPortOccupiedDelegation;
    }

    @Override // com.htc.launcher.Workspace.Screen
    public ViewGroup asViewGroup() {
        return this;
    }

    public class RearrangeInfo {
        public CellInfo from;
        public CellInfo to;

        public RearrangeInfo() {
        }
    }

    private boolean cellPositionChanged(int cellX, int cellY) {
        if (cellX == this.mLastDragCellX && cellY == this.mLastDragCellY) {
            return false;
        }
        this.mLastDragCellX = cellX;
        this.mLastDragCellY = cellY;
        return true;
    }

    private void resetRearrangeLastDragInfo() {
        this.mLastDragCellX = -1;
        this.mLastDragCellY = -1;
    }

    public void rearrange(Draggee dragItem, int posX, int posY, int spanX, int spanY) {
        int[] cellXY = new int[2];
        pointToDropCell(posX, posY, spanX, spanY, cellXY);
        int X0 = cellXY[0];
        int Y0 = cellXY[1];
        if (cellPositionChanged(X0, Y0)) {
            if (this.mNotifyHandler == null) {
                this.mNotifyHandler = new NotifyDirtyHandler();
            }
            this.mNotifyHandler.removeMessages(NOTIFY_REARRANGE);
            CellInfo info = new CellInfo();
            info.cellX = X0;
            info.cellY = Y0;
            info.spanX = spanX;
            info.spanY = spanY;
            info.item = dragItem;
            info.valid = true;
            List<CellInfo> coveredCells = new ArrayList<>();
            findCoveredCells(info, coveredCells);
            this.mDragOverInfo.cellX = X0;
            this.mDragOverInfo.cellY = Y0;
            this.mDragOverInfo.spanX = spanX;
            this.mDragOverInfo.spanY = spanY;
            this.mRearrangeCells.clear();
            if (!calculateRearrangeCells(info, coveredCells, this.mRearrangeCells)) {
                showDropArea(X0, Y0, spanX, spanY, false);
                return;
            }
            this.mNotifyHandler.sendMessageDelayed(this.mNotifyHandler.obtainMessage(NOTIFY_REARRANGE), 500L);
            if (!info.valid) {
                hideDropArea();
            } else {
                showDropArea(X0, Y0, spanX, spanY, true);
            }
        }
    }

    public void revertRearrangedCells() {
        revertRearrangedCells(-1, -1, 0, 0);
    }

    public void revertRearrangedCells(int cellX, int cellY, int spanX, int spanY) {
        if (this.mNotifyHandler != null) {
            Logger.d("Rearrange", "revertRearrangedCells");
            this.mNotifyHandler.removeMessages(NOTIFY_REARRANGE);
            this.mRearrangeCells.clear();
            performRearrange(true);
        }
    }

    private void showDropArea(int cellX, int cellY, int spanX, int spanY, boolean valid) {
        FxScreen screen = (FxScreen) getCurrentOccupiedDelegation();
        screen.showDropArea(cellX, cellY, spanX, spanY, valid);
    }

    public void hideDropArea() {
        FxScreen screen = (FxScreen) getCurrentOccupiedDelegation();
        screen.hideDropArea();
    }

    class CellComparator implements Comparator<CellInfo> {
        private CellInfo mDragInfo;

        CellComparator(CellInfo dragInfo) {
            this.mDragInfo = dragInfo;
        }

        @Override // java.util.Comparator
        public int compare(CellInfo arg0, CellInfo arg1) {
            int area0 = arg0.spanX * arg0.spanY;
            int area1 = arg1.spanX * arg1.spanY;
            return area0 != area1 ? area1 - area0 : (Math.abs(this.mDragInfo.cellX - arg1.cellX) * Math.abs(this.mDragInfo.cellY - arg1.cellY)) - (Math.abs(this.mDragInfo.cellX - arg0.cellX) * Math.abs(this.mDragInfo.cellY - arg0.cellY));
        }
    }

    private void findCoveredCells(CellInfo dragInfo, List<CellInfo> cells) {
        if (cells != null) {
            cells.clear();
            getCurrentOccupiedDelegation().findCoveredCells(dragInfo, cells);
            if (this.mDragCellInfo.valid) {
                Iterator i$ = cells.iterator();
                while (true) {
                    if (!i$.hasNext()) {
                        break;
                    }
                    CellInfo info = i$.next();
                    if (info.cellX == this.mDragCellInfo.cellX && info.cellY == this.mDragCellInfo.cellY && info.spanX == this.mDragCellInfo.spanX && info.spanY == this.mDragCellInfo.spanY) {
                        cells.remove(info);
                        break;
                    }
                }
            }
            int count = cells.size();
            if (count > 0) {
                Collections.sort(cells, new CellComparator(dragInfo));
                if (localLOGD) {
                    Log.v(LOG_TAG, "findCoveredCells List cells for freeing space on (" + dragInfo.cellX + "," + dragInfo.cellY + ") [" + dragInfo.spanX + "x" + dragInfo.spanY + "]");
                    for (int i = 0; i < count; i++) {
                        CellInfo cell = cells.get(i);
                        Log.v(LOG_TAG, "findCoveredCells cell " + i + " (" + cell.cellX + "," + cell.cellY + ") [" + cell.spanX + "x" + cell.spanY + "]");
                    }
                }
            }
        }
    }

    private CellInfo checkCanSwitchCell(CellInfo dragCell, CellInfo c, boolean[][] occupied) {
        int distance;
        if (!this.mDragCellInfo.valid || !dragCell.contains(c)) {
            return null;
        }
        Logger.d(LOG_TAG, "item " + c.toString() + " covered by " + dragCell.toString());
        int offsetX = c.cellX - dragCell.cellX;
        int offsetY = c.cellY - dragCell.cellY;
        CellInfo toCell = new CellInfo();
        toCell.item = c.item;
        toCell.cellX = this.mDragCellInfo.cellX + offsetX;
        toCell.cellY = this.mDragCellInfo.cellY + offsetY;
        toCell.spanX = c.spanX;
        toCell.spanY = c.spanY;
        toCell.valid = true;
        int xAxis = this.mPortrait ? this.mShortAxisCells : this.mLongAxisCells;
        int yAxis = this.mPortrait ? this.mLongAxisCells : this.mShortAxisCells;
        if (toCell.cellX + toCell.spanX > xAxis || toCell.cellY + toCell.spanY > yAxis) {
            Logger.e(LOG_TAG, "OUT OF BOUND! switch item from" + c.toString() + " to " + toCell.toString());
            return null;
        }
        if (!isAreaOccupied(occupied, toCell.cellX, toCell.cellY, toCell.cellX + toCell.spanX, toCell.cellY + toCell.spanY)) {
            Logger.d(LOG_TAG, "switch item " + c.toString() + " to " + toCell.toString());
            return toCell;
        }
        int maxX = Math.min((xAxis - c.spanX) + 1, this.mDragCellInfo.cellX + this.mDragCellInfo.spanX);
        int maxY = Math.min((yAxis - c.spanY) + 1, this.mDragCellInfo.cellY + this.mDragCellInfo.spanY);
        toCell.valid = false;
        int shortestDistance = Integer.MAX_VALUE;
        for (int j = this.mDragCellInfo.cellY; j < maxY; j++) {
            if (j >= occupied.length) {
                Log.e("Rearrange", "checkCanSwitchCell out of bound: j=" + j + ", y=" + maxY + " bound=" + occupied.length);
            } else {
                for (int i = this.mDragCellInfo.cellX; i < maxX; i++) {
                    if (i >= occupied[j].length) {
                        Log.e("Rearrange", "checkCanSwitchCell out of bound: i=" + i + ", x=" + maxX + " bound=" + occupied[j].length);
                    } else if (!occupied[i][j]) {
                        if (!isAreaOccupied(occupied, i, j, c.spanX + i, c.spanY + j) && shortestDistance > (distance = ((i - c.cellX) * (i - c.cellX)) + ((j - c.cellY) * (j - c.cellY)))) {
                            toCell.cellX = i;
                            toCell.cellY = j;
                            toCell.valid = true;
                            shortestDistance = distance;
                        }
                    }
                }
            }
        }
        if (toCell.valid) {
            return toCell;
        }
        return null;
    }

    private CellInfo findNearestVacantCellForCell(CellInfo c, boolean[][] occupied) {
        int distance;
        CellInfo switchToCell;
        int countX = getCountX();
        int countY = getCountY();
        int x = countX - c.spanX;
        int y = countY - c.spanY;
        int shortestDistance = (countX * countX) + (countY * countY);
        CellInfo targetCell = new CellInfo();
        targetCell.valid = false;
        if (this.mIsDragging && (switchToCell = checkCanSwitchCell(this.mDragOverInfo, c, occupied)) != null) {
            return switchToCell;
        }
        for (int j = 0; j <= y; j++) {
            if (j >= occupied.length) {
                Log.e("Rearrange", "Cell out of bound: j=" + j + ", y=" + y + " bound=" + occupied.length);
            } else {
                for (int i = 0; i <= x; i++) {
                    if (i >= occupied[j].length) {
                        Log.e("Rearrange", "Cell out of bound: i=" + i + ", x=" + x + " bound=" + occupied[j].length);
                    } else if (!occupied[i][j] && !isAreaOccupied(occupied, i, j, c.spanX + i, c.spanY + j) && shortestDistance > (distance = ((i - c.cellX) * (i - c.cellX)) + ((j - c.cellY) * (j - c.cellY)))) {
                        targetCell.item = c.item;
                        targetCell.cellX = i;
                        targetCell.cellY = j;
                        targetCell.spanX = c.spanX;
                        targetCell.spanY = c.spanY;
                        targetCell.valid = true;
                        shortestDistance = distance;
                    }
                }
            }
        }
        if (targetCell.valid) {
            return targetCell;
        }
        return null;
    }

    private void dumpOccupiedCell(boolean[][] occupied) {
        String[] dummy = new String[4];
        for (int i = 0; i < 4; i++) {
            Object[] objArr = new Object[4];
            objArr[0] = Character.valueOf(occupied[0][i] ? 'x' : 'o');
            objArr[1] = Character.valueOf(occupied[1][i] ? 'x' : 'o');
            objArr[2] = Character.valueOf(occupied[2][i] ? 'x' : 'o');
            objArr[3] = Character.valueOf(occupied[3][i] ? 'x' : 'o');
            dummy[i] = String.format("%c%c%c%c", objArr);
        }
        Logger.d("Rearrange", String.format("%s, %s, %s, %s", dummy[0], dummy[1], dummy[2], dummy[3]));
    }

    boolean calculateRearrangeCells(CellInfo dragCell, List<CellInfo> cells, List<RearrangeInfo> rearrangeCells) {
        if (cells == null) {
            return true;
        }
        Logger.d("Rearrange", String.format("calculateRearrangeCells dragCell:%s", dragCell.toString()));
        this.mDraggingOccupied = getCurrentOccupiedDelegation().getDraggingOccupiedCells();
        dumpOccupiedCell(this.mDraggingOccupied);
        if (dragCell.item != null && dragCell.spanX == 1 && dragCell.spanY == 1) {
            Iterator i$ = cells.iterator();
            while (i$.hasNext()) {
                if (i$.next().item.getItemInfo().itemType == 2 && (dragCell.item.getItemInfo().itemType == 0 || dragCell.item.getItemInfo().itemType == 1)) {
                    rearrangeCells.clear();
                    dragCell.valid = false;
                    return false;
                }
            }
        }
        rearrangeCells.clear();
        for (CellInfo c : cells) {
            for (int oy = c.cellY; oy < c.cellY + c.spanY; oy++) {
                for (int ox = c.cellX; ox < c.cellX + c.spanX; ox++) {
                    this.mDraggingOccupied[ox][oy] = false;
                }
            }
        }
        for (int ox2 = dragCell.cellX; ox2 < dragCell.cellX + dragCell.spanX; ox2++) {
            for (int oy2 = dragCell.cellY; oy2 < dragCell.cellY + dragCell.spanY; oy2++) {
                this.mDraggingOccupied[ox2][oy2] = true;
            }
        }
        dumpOccupiedCell(this.mDraggingOccupied);
        for (CellInfo c2 : cells) {
            Logger.d("Rearrange", String.format("calculateRearrangeCells calculate %s", c2.toString()));
            CellInfo targetCell = findNearestVacantCellForCell(c2, this.mDraggingOccupied);
            if (targetCell == null) {
                if (localLOGD) {
                    Log.d("Rearrange", "can't find cell to auto rearrange for " + c2.toString());
                }
                return false;
            }
            if (localLOGD) {
                Log.w("Rearrange", "Move " + c2.toString() + " to " + targetCell.toString());
            }
            for (int y = targetCell.cellY; y < targetCell.cellY + targetCell.spanY; y++) {
                for (int x = targetCell.cellX; x < targetCell.cellX + targetCell.spanX; x++) {
                    this.mDraggingOccupied[x][y] = true;
                }
            }
            RearrangeInfo moveInfo = new RearrangeInfo();
            moveInfo.to = targetCell;
            moveInfo.from = c2;
            rearrangeCells.add(moveInfo);
        }
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void performRearrange(boolean bAnimation) {
        Logger.d("Rearrange", String.format("CellLayout performRearrange " + bAnimation + ", size:%d", Integer.valueOf(this.mRearrangeCells.size())));
        if (SettingUtil.isSupportLandscape()) {
            getAnotherOccupiedDelegation().performRearrange(false, this.mRearrangeCells);
        }
        getCurrentOccupiedDelegation().performRearrange(bAnimation, this.mRearrangeCells);
    }

    @Override // com.htc.launcher.Workspace.Screen
    public ArrayList<Draggee> getRearrangeItems() {
        if (SettingUtil.isSupportLandscape()) {
            getAnotherOccupiedDelegation().getRearrangeItems();
        }
        return getCurrentOccupiedDelegation().getRearrangeItems();
    }

    @Override // com.htc.launcher.Workspace.Screen
    public void onEndDrag() {
        this.mIsDragging = false;
        this.mDragCellInfo.valid = false;
        this.mRearrangeCells.clear();
        resetRearrangeLastDragInfo();
        hideDropArea();
    }

    public void changeScreenIndex(int index) {
        if (this.mCellInfo != null) {
            this.mCellInfo.screen = index;
        }
    }
}
