package com.htc.launcher.scene;

import android.graphics.Bitmap;
import java.lang.ref.SoftReference;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class ScenePickerItem {
    private Bitmap icon;
    int id;
    private boolean marked;
    String name;
    private SoftReference<Bitmap> preview;
    private int translateId;

    public ScenePickerItem(String name, int id, Bitmap preview, Bitmap icon, int translateId) {
        setName(name);
        setId(id);
        setPreview(preview);
        setMarked(false);
        setTranslateId(translateId);
        setIcon(icon);
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return this.id;
    }

    public void setPreview(Bitmap preview) {
        this.preview = new SoftReference<>(preview);
    }

    public Bitmap getPreview() {
        if (this.preview == null) {
            return null;
        }
        return this.preview.get();
    }

    public void setIcon(Bitmap icon) {
        this.icon = icon;
    }

    public Bitmap getIcon() {
        return this.icon;
    }

    public void setMarked(boolean marked) {
        this.marked = marked;
    }

    public boolean isMarked() {
        return this.marked;
    }

    public void setTranslateId(int translateId) {
        this.translateId = translateId;
    }

    public int getTranslateId() {
        return this.translateId;
    }
}
