package com.htc.launcher;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class WidgetLayoutInfalter extends LayoutInflater {
    private static final String[] sClassPrefixList = {"android.widget.", "android.webkit."};

    protected WidgetLayoutInfalter(Context context) {
        super(context);
    }

    @Override // android.view.LayoutInflater
    protected View onCreateView(String name, AttributeSet attrs) throws ClassNotFoundException {
        View view;
        String[] arr$ = sClassPrefixList;
        for (String prefix : arr$) {
            try {
                view = createView(name, prefix, attrs);
            } catch (ClassNotFoundException e) {
            }
            if (view != null) {
                return view;
            }
        }
        return super.onCreateView(name, attrs);
    }

    @Override // android.view.LayoutInflater
    public LayoutInflater cloneInContext(Context context) {
        return new WidgetLayoutInfalter(context);
    }
}
