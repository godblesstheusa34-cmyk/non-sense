package com.htc.launcher.settings;

import android.content.Context;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import com.htc.cscore.util.CSUtil;
import com.htc.launcher.AddAdapter;
import com.htc.launcher.R;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class SettingUtil {
    public static final String PERFORMANCE_TAG = "PREF";
    public static final float SENSE_1_5 = 1.5f;
    public static final float SENSE_2_0 = 2.0f;
    private static final String TAG = "SettingUtil";
    public static final int VIBRATE_DURATION = 35;
    public static float htc_sense;
    private static String mSceneRoot;
    private static int mScreenLongAxisLength;
    private static int mScreenShortAxisLength;
    public static float sEaseInBackDuration;
    public static float sEaseOutBackDuration;
    public static float sEaseOutDuration;
    public static int scrollThreshold;
    public static boolean localLOGD = false;
    public static int sWorkspaceScreenCount = 8;
    public static int sWorkspaceDefaultScreen = 0;
    public static int sWallpaperScreensSpan = 2;
    private static int sCustomizeButtonCount = 0;
    public static boolean sIsEnableLoopLog = false;
    public static boolean sIsCSPackageInstalled = true;
    public static boolean sIsEnablePointerLocation = false;
    public static int sDragSensitive = 100;
    public static int sTouchSlop = 25;
    public static boolean sIsRingSlide = true;
    private static boolean sShouldFreezeWallpaper = true;
    public static boolean sFixedScrollVelocity = false;
    public static int sFixedScrollDurationPort = 650;
    public static int sFixedScrollDurationLand = 650;
    public static int sFullRoundScrollVelocityLand = 8000;
    public static int sSinglePageScrollVelocityLand = 3000;
    public static int sFullRoundScrollVelocityPort = 6000;
    public static int sSinglePageScrollVelocityPort = 2000;
    public static int sMaxScrollOffset = sWorkspaceScreenCount * 2;
    public static int sMediumScrollOffset = sWorkspaceScreenCount * 1;
    public static int sMaxScrollRoundDurationLand = 2000;
    public static int sMediumScrollRoundDurationLand = 1200;
    public static int sMaxScrollRoundDurationPort = 2200;
    public static int sMediumScrollRoundDurationPort = 1500;
    public static boolean sMultiPageScrollOnPortrait = false;
    public static float[] sEaseOutCoefficientsLong = new float[5];
    public static float[] sEaseOutCoefficientsShort = new float[5];
    public static float[] sEaseOutBackCoefficients = new float[5];
    public static float[] sEaseInBackCoefficients = new float[5];
    private static final float DEFAULT_SCROLL_DEGREE = 1.0f;
    public static float sWorkspaceScrollDegree = DEFAULT_SCROLL_DEGREE;
    public static boolean sEnableThumbnailMode = true;
    public static boolean sIsHomeToThumbnail = true;
    public static boolean sIsRealTimeThumbnailMode = false;
    public static boolean sIsEnableRearrange = true;
    public static boolean sIsEnableRearrangeAnimation = false;
    public static float sOverrideDensity = 0.0f;
    public static int sOverrideDpi = 160;
    public static boolean ENABLE_THUMBNAIL_MODE = true;
    public static boolean sGLScroll = true;
    public static boolean sSpringboardMode = false;
    public static boolean ENABLE_G_SENEOR = false;
    public static boolean isAllProgramTitle = true;
    public static boolean isAllProgramButtonBar = true;
    public static boolean isShowButtonBar = true;

    static {
        if ("3.0".equals("2.0")) {
            htc_sense = 2.0f;
            if (localLOGD) {
                Log.d(TAG, "HTC Sense 2.0");
                return;
            }
            return;
        }
        htc_sense = 1.5f;
        if (localLOGD) {
            Log.d(TAG, "HTC Sense 1.5 or 1.6");
        }
    }

    public static void loadSettings(Context context) {
        sWorkspaceScreenCount = context.getResources().getInteger(R.integer.default_screen_count);
        sWorkspaceDefaultScreen = context.getResources().getInteger(R.integer.default_screen);
        sIsCSPackageInstalled = CSUtil.isCSPackageInstalled(context);
        Display display = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
        int screenWidth = display.getWidth();
        int screenHeight = display.getHeight();
        if (screenWidth > screenHeight) {
            mScreenLongAxisLength = screenWidth;
            mScreenShortAxisLength = screenHeight;
        } else {
            mScreenLongAxisLength = screenHeight;
            mScreenShortAxisLength = screenWidth;
        }
        if (localLOGD) {
            Log.d(TAG, "Screen resolution (" + mScreenShortAxisLength + ", " + mScreenLongAxisLength + ")");
        }
        sEaseOutBackCoefficients[0] = 4.5f;
        sEaseOutBackCoefficients[1] = -7.0f;
        sEaseOutBackCoefficients[2] = 5.0f;
        sEaseOutBackCoefficients[3] = -2.0f;
        sEaseOutBackCoefficients[4] = 0.5f;
        if (usesRingSlide()) {
            sEaseOutCoefficientsShort[0] = 5.5f;
            sEaseOutCoefficientsShort[1] = -13.0f;
            sEaseOutCoefficientsShort[2] = 16.0f;
            sEaseOutCoefficientsShort[3] = -10.0f;
            sEaseOutCoefficientsShort[4] = 2.5f;
            sEaseOutCoefficientsLong[0] = 1.85f;
            sEaseOutCoefficientsLong[1] = -0.1f;
            sEaseOutCoefficientsLong[2] = -0.8f;
            sEaseOutCoefficientsLong[3] = -0.5025f;
            sEaseOutCoefficientsLong[4] = 0.5525f;
            sFixedScrollVelocity = true;
            sFixedScrollDurationPort = AddAdapter.EXCUTE_SHORTCUT;
            sFixedScrollDurationLand = AddAdapter.EXCUTE_SHORTCUT;
            sFullRoundScrollVelocityLand = 5000;
            sSinglePageScrollVelocityLand = 2000;
            if (isTabletDevice()) {
                sFullRoundScrollVelocityPort = 4500;
                sSinglePageScrollVelocityPort = 3000;
                sMaxScrollRoundDurationPort = 2500;
                sMediumScrollRoundDurationPort = 1200;
                sMaxScrollRoundDurationLand = 2200;
                sMediumScrollRoundDurationLand = 1200;
            } else {
                sFullRoundScrollVelocityPort = 3750;
                sSinglePageScrollVelocityPort = 3750;
            }
            sFixedScrollVelocity = true;
            sOverrideDensity = 1.5f;
            sOverrideDpi = 240;
            sMaxScrollOffset = sWorkspaceScreenCount * 2;
            sMediumScrollOffset = sWorkspaceScreenCount * 1;
            sTouchSlop = 25;
            sDragSensitive = 5;
            sMultiPageScrollOnPortrait = true;
            sWallpaperScreensSpan = 1;
        } else {
            sEaseOutCoefficientsShort[0] = 5.0f;
            sEaseOutCoefficientsShort[1] = -10.0f;
            sEaseOutCoefficientsShort[2] = 10.0f;
            sEaseOutCoefficientsShort[3] = -5.0f;
            sEaseOutCoefficientsShort[4] = 1.0f;
            sEaseOutCoefficientsLong[0] = 5.0f;
            sEaseOutCoefficientsLong[1] = -10.0f;
            sEaseOutCoefficientsLong[2] = 10.0f;
            sEaseOutCoefficientsLong[3] = -5.0f;
            sEaseOutCoefficientsLong[4] = 1.0f;
            sFixedScrollVelocity = false;
        }
        sEaseInBackCoefficients[0] = -1.5f;
        sEaseInBackCoefficients[1] = 11.0f;
        sEaseInBackCoefficients[2] = -17.0f;
        sEaseInBackCoefficients[3] = 11.5f;
        sEaseInBackCoefficients[4] = -3.0f;
        sEaseInBackDuration = 3.0f;
        sEaseOutBackDuration = 2.0f;
        sEaseOutDuration = 4.0f;
        sWorkspaceScrollDegree = DEFAULT_SCROLL_DEGREE;
        if (!isTabletDevice()) {
            sShouldFreezeWallpaper = false;
        }
    }

    public static int getScreenShortAxisLength() {
        return mScreenShortAxisLength;
    }

    public static int getScreenLongAxisLength() {
        return mScreenLongAxisLength;
    }

    public static boolean isLiveWallaperSupported() {
        return true;
    }

    public static boolean forceRGB32Window() {
        return false;
    }

    public static boolean isUAKSupported() {
        return false;
    }

    public static void setSceneRoot(boolean isPortrait) {
        if (isSupportLandscape() && !isPortrait) {
            mSceneRoot = "land/";
        } else {
            mSceneRoot = "port/";
        }
    }

    public static String getSceneRoot() {
        return mSceneRoot;
    }

    public static boolean isSupportLandscape() {
        return isTabletDevice();
    }

    public static boolean isTabletDevice() {
        if (isDoubleShot()) {
            return true;
        }
        return false;
    }

    public static boolean isDoubleShot() {
        return false;
    }

    public static int getScreenCount() {
        return sWorkspaceScreenCount;
    }

    public static void setScreenCount(int count) {
        sWorkspaceScreenCount = count;
    }

    public static int getDefaultScreenIndex() {
        return sWorkspaceDefaultScreen;
    }

    public static void setDefaultScreenIndex(int index) {
        sWorkspaceDefaultScreen = index;
    }

    public static int getCustomizeButtonCount() {
        if (isTabletDevice()) {
            sCustomizeButtonCount = 3;
        }
        return sCustomizeButtonCount;
    }

    public static boolean usesRingSlide() {
        return isTabletDevice() || sIsRingSlide;
    }

    public static boolean shouldFreezeWallpaper() {
        return sShouldFreezeWallpaper;
    }
}
