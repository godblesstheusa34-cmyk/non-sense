package com.htc.launcher;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.SystemProperties;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class GeneralPurposeReceiver extends BroadcastReceiver {
    public static final String PREF_BUILD_NO = "build_no";
    public static final String PREF_SCAN_DONE = "scan_htc_widget_done";
    public static final Object syncScanDone = new Object();

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        if ("com.htc.rosie.ACTION_SCAN_HTC_WIDGET_DONE".equals(intent.getAction())) {
            synchronized (syncScanDone) {
                SharedPreferences preferences = context.getSharedPreferences(WidgetPackageManager.REFERENCES, 0);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putBoolean(PREF_SCAN_DONE, true);
                editor.putString(PREF_BUILD_NO, SystemProperties.get("ro.build.description"));
                editor.apply();
                syncScanDone.notifyAll();
            }
        }
    }
}
