package com.htc.launcher;

import android.graphics.Rect;
import android.view.ContextMenu;
import com.htc.launcher.CellLayout;
import java.lang.reflect.Array;
import java.util.ArrayList;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public final class CellInfo implements ContextMenu.ContextMenuInfo {
    public int cellX;
    public int cellY;
    public Draggee item;
    int maxVacantSpanX;
    int maxVacantSpanXSpanY;
    int maxVacantSpanY;
    int maxVacantSpanYSpanX;
    int screen;
    public int spanX;
    public int spanY;
    boolean valid;
    final ArrayList<VacantCell> vacantCells = new ArrayList<>(100);
    final Rect current = new Rect();

    static final class VacantCell {
        private static final int POOL_LIMIT = 100;
        private static VacantCell sRoot;
        int cellX;
        int cellY;
        private VacantCell next;
        int spanX;
        int spanY;
        private static final Object sLock = new Object();
        private static int sAcquiredCount = 0;

        VacantCell() {
        }

        static VacantCell acquire() {
            synchronized (sLock) {
                if (sRoot == null) {
                    return new VacantCell();
                }
                VacantCell info = sRoot;
                sRoot = info.next;
                sAcquiredCount--;
                return info;
            }
        }

        void release() {
            synchronized (sLock) {
                if (sAcquiredCount < 100) {
                    sAcquiredCount++;
                    this.next = sRoot;
                    sRoot = this;
                }
            }
        }

        public String toString() {
            return "VacantCell[x=" + this.cellX + ", y=" + this.cellY + ", spanX=" + this.spanX + ", spanY=" + this.spanY + "]";
        }
    }

    public CellLayout.LayoutParams getLayoutParams() {
        return new CellLayout.LayoutParams(this.cellX, this.cellY, this.spanX, this.spanY);
    }

    private void clearVacantCells() {
        ArrayList<VacantCell> list = this.vacantCells;
        int count = list.size();
        for (int i = 0; i < count; i++) {
            list.get(i).release();
        }
        list.clear();
    }

    void findVacantCellsFromOccupied(boolean[] occupied, int xCount, int yCount) {
        if (this.cellX < 0 || this.cellY < 0) {
            this.maxVacantSpanXSpanY = ApplicationManager.ALL_PROGRAM_LIST_HIGHEST_PRIORITY;
            this.maxVacantSpanX = ApplicationManager.ALL_PROGRAM_LIST_HIGHEST_PRIORITY;
            this.maxVacantSpanYSpanX = ApplicationManager.ALL_PROGRAM_LIST_HIGHEST_PRIORITY;
            this.maxVacantSpanY = ApplicationManager.ALL_PROGRAM_LIST_HIGHEST_PRIORITY;
            clearVacantCells();
            return;
        }
        boolean[][] unflattened = (boolean[][]) Array.newInstance((Class<?>) Boolean.TYPE, xCount, yCount);
        for (int y = 0; y < yCount; y++) {
            for (int x = 0; x < xCount; x++) {
                unflattened[x][y] = occupied[(y * xCount) + x];
            }
        }
        findIntersectingVacantCells(this, this.cellX, this.cellY, xCount, yCount, unflattened);
    }

    boolean findCellForSpan(int[] cellXY, int spanX, int spanY) {
        ArrayList<VacantCell> list = this.vacantCells;
        int count = list.size();
        boolean found = false;
        if (this.spanX >= spanX && this.spanY >= spanY) {
            cellXY[0] = this.cellX;
            cellXY[1] = this.cellY;
            found = true;
        }
        int i = 0;
        while (true) {
            if (i >= count) {
                break;
            }
            VacantCell cell = list.get(i);
            if (cell.spanX != spanX || cell.spanY != spanY) {
                i++;
            } else {
                cellXY[0] = cell.cellX;
                cellXY[1] = cell.cellY;
                found = true;
                break;
            }
        }
        int i2 = 0;
        while (true) {
            if (i2 >= count) {
                break;
            }
            VacantCell cell2 = list.get(i2);
            if (cell2.spanX < spanX || cell2.spanY < spanY) {
                i2++;
            } else {
                cellXY[0] = cell2.cellX;
                cellXY[1] = cell2.cellY;
                found = true;
                break;
            }
        }
        clearVacantCells();
        return found;
    }

    public String toString() {
        return "Draggee[view=" + (this.item == null ? "null" : this.item.toString()) + ", x=" + this.cellX + ", y=" + this.cellY + "], span=[" + this.spanX + ", " + this.spanY + "]]";
    }

    static boolean findVacantCell(int[] vacant, int spanX, int spanY, int xCount, int yCount, boolean[][] occupied) {
        for (int x = 0; x < xCount; x++) {
            for (int y = 0; y < yCount; y++) {
                boolean available = !occupied[x][y];
                for (int i = x; i < (x + spanX) - 1 && x < xCount; i++) {
                    for (int j = y; j < (y + spanY) - 1 && y < yCount; j++) {
                        available = available && !occupied[i][j];
                        if (!available) {
                            break;
                        }
                    }
                }
                if (available) {
                    vacant[0] = x;
                    vacant[1] = y;
                    return true;
                }
            }
        }
        return false;
    }

    static void findIntersectingVacantCells(CellInfo cellInfo, int x, int y, int xCount, int yCount, boolean[][] occupied) {
        cellInfo.maxVacantSpanX = ApplicationManager.ALL_PROGRAM_LIST_HIGHEST_PRIORITY;
        cellInfo.maxVacantSpanXSpanY = ApplicationManager.ALL_PROGRAM_LIST_HIGHEST_PRIORITY;
        cellInfo.maxVacantSpanY = ApplicationManager.ALL_PROGRAM_LIST_HIGHEST_PRIORITY;
        cellInfo.maxVacantSpanYSpanX = ApplicationManager.ALL_PROGRAM_LIST_HIGHEST_PRIORITY;
        cellInfo.clearVacantCells();
        if (!occupied[x][y]) {
            cellInfo.current.set(x, y, x, y);
            findVacantCell(cellInfo.current, xCount, yCount, occupied, cellInfo);
        }
    }

    static void findVacantCell(Rect current, int xCount, int yCount, boolean[][] occupied, CellInfo cellInfo) {
        addVacantCell(current, cellInfo);
        if (current.left > 0 && isColumnEmpty(current.left - 1, current.top, current.bottom, occupied)) {
            current.left--;
            findVacantCell(current, xCount, yCount, occupied, cellInfo);
            current.left++;
        }
        if (current.right < xCount - 1 && isColumnEmpty(current.right + 1, current.top, current.bottom, occupied)) {
            current.right++;
            findVacantCell(current, xCount, yCount, occupied, cellInfo);
            current.right--;
        }
        if (current.top > 0 && isRowEmpty(current.top - 1, current.left, current.right, occupied)) {
            current.top--;
            findVacantCell(current, xCount, yCount, occupied, cellInfo);
            current.top++;
        }
        if (current.bottom < yCount - 1 && isRowEmpty(current.bottom + 1, current.left, current.right, occupied)) {
            current.bottom++;
            findVacantCell(current, xCount, yCount, occupied, cellInfo);
            current.bottom--;
        }
    }

    private static void addVacantCell(Rect current, CellInfo cellInfo) {
        VacantCell cell = VacantCell.acquire();
        cell.cellX = current.left;
        cell.cellY = current.top;
        cell.spanX = (current.right - current.left) + 1;
        cell.spanY = (current.bottom - current.top) + 1;
        if (cell.spanX > cellInfo.maxVacantSpanX) {
            cellInfo.maxVacantSpanX = cell.spanX;
            cellInfo.maxVacantSpanXSpanY = cell.spanY;
        }
        if (cell.spanY > cellInfo.maxVacantSpanY) {
            cellInfo.maxVacantSpanY = cell.spanY;
            cellInfo.maxVacantSpanYSpanX = cell.spanX;
        }
        cellInfo.vacantCells.add(cell);
    }

    private static boolean isColumnEmpty(int x, int top, int bottom, boolean[][] occupied) {
        for (int y = top; y <= bottom; y++) {
            if (occupied[x][y]) {
                return false;
            }
        }
        return true;
    }

    private static boolean isRowEmpty(int y, int left, int right, boolean[][] occupied) {
        for (int x = left; x <= right; x++) {
            if (occupied[x][y]) {
                return false;
            }
        }
        return true;
    }

    public boolean contains(CellInfo info) {
        if (info.screen != this.screen) {
            return false;
        }
        return info.cellX >= this.cellX && info.cellX + info.spanX <= this.cellX + this.spanX && info.cellY >= this.cellY && info.cellY + info.spanY <= this.cellY + this.spanY;
    }
}
