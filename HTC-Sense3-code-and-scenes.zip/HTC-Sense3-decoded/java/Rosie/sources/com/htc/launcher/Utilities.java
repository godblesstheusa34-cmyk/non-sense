package com.htc.launcher;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PaintFlagsDrawFilter;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.PaintDrawable;
import android.os.Bundle;
import android.os.Parcel;
import android.util.Log;
import com.htc.launcher.settings.SettingUtil;
import java.text.Collator;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public final class Utilities {
    private static int sIconWidth = -1;
    private static int sIconHeight = -1;
    private static final Paint sPaint = new Paint();
    private static final Rect sBounds = new Rect();
    private static final Rect sOldBounds = new Rect();
    private static Canvas sCanvas = new Canvas();
    private static int sOrientation = -1;
    public static Collator sCollator = Collator.getInstance();

    static {
        sCanvas.setDrawFilter(new PaintFlagsDrawFilter(4, 2));
    }

    static Bitmap centerToFit(Bitmap bitmap, int width, int height, Context context) {
        int bitmapWidth = bitmap.getWidth();
        int bitmapHeight = bitmap.getHeight();
        if (bitmapWidth < width || bitmapHeight < height) {
            int color = context.getResources().getColor(R.color.window_background);
            Bitmap centered = Bitmap.createBitmap(bitmapWidth < width ? width : bitmapWidth, bitmapHeight < height ? height : bitmapHeight, Bitmap.Config.RGB_565);
            Canvas canvas = new Canvas(centered);
            canvas.drawColor(color);
            canvas.drawBitmap(bitmap, (width - bitmapWidth) / 2.0f, (height - bitmapHeight) / 2.0f, (Paint) null);
            return centered;
        }
        return bitmap;
    }

    public static Drawable createIconThumbnail(Drawable icon, Context context) {
        BitmapDrawable bitmapDrawable;
        Bitmap bitmap;
        int iconHeight;
        int width;
        if (icon == null) {
            return null;
        }
        getIconWidthHeight(context);
        int width2 = sIconWidth;
        int height = sIconHeight;
        if (icon instanceof PaintDrawable) {
            PaintDrawable painter = (PaintDrawable) icon;
            painter.setIntrinsicWidth(width2);
            painter.setIntrinsicHeight(height);
        } else if ((icon instanceof BitmapDrawable) && (bitmap = (bitmapDrawable = (BitmapDrawable) icon).getBitmap()) != null && bitmap.getDensity() == 0) {
            bitmapDrawable.setTargetDensity(context.getResources().getDisplayMetrics());
        }
        int iconWidth = icon.getIntrinsicWidth();
        int iconHeight2 = icon.getIntrinsicHeight();
        Log.d("Utilities", "createIconThumbnail # iconWidth: " + iconWidth + ",iconHeight: " + iconHeight2 + ",width: " + width2 + ",height: " + height);
        if (width2 > 0 && height > 0) {
            if (width2 < iconWidth || height < iconHeight2 || 1.0f != 1.0f) {
                float scale = iconHeight2;
                float ratio = iconWidth / scale;
                if (iconWidth > iconHeight2) {
                    iconHeight = (int) (width2 / ratio);
                    width = width2;
                } else if (iconHeight2 > iconWidth) {
                    iconHeight = height;
                    width = (int) (ratio * height);
                } else {
                    iconHeight = height;
                    width = width2;
                }
                Bitmap.Config c = icon.getOpacity() != -1 ? Bitmap.Config.ARGB_8888 : Bitmap.Config.RGB_565;
                Bitmap thumb = Bitmap.createBitmap(sIconWidth, sIconHeight, c);
                Canvas canvas = sCanvas;
                canvas.setBitmap(thumb);
                sOldBounds.set(icon.getBounds());
                int x = (sIconWidth - width) / 2;
                int y = (sIconHeight - iconHeight) / 2;
                icon.setBounds(x, y, x + width, y + iconHeight);
                icon.draw(canvas);
                icon.setBounds(sOldBounds);
                return new FastBitmapDrawable(thumb);
            }
            if (iconWidth < width2 && iconHeight2 < height) {
                Bitmap.Config c2 = Bitmap.Config.ARGB_8888;
                Bitmap thumb2 = Bitmap.createBitmap(sIconWidth, sIconHeight, c2);
                Canvas canvas2 = sCanvas;
                canvas2.setBitmap(thumb2);
                sOldBounds.set(icon.getBounds());
                if (SettingUtil.isTabletDevice()) {
                    icon.setBounds(0, 0, width2, height);
                } else {
                    int x2 = (width2 - iconWidth) / 2;
                    int y2 = (height - iconHeight2) / 2;
                    icon.setBounds(x2, y2, iconWidth + x2, iconHeight2 + y2);
                }
                icon.draw(canvas2);
                icon.setBounds(sOldBounds);
                return new FastBitmapDrawable(thumb2);
            }
        }
        return icon;
    }

    public static Drawable createIconThumbnail(Drawable icon, Context context, int width, int height) {
        BitmapDrawable bitmapDrawable;
        Bitmap bitmap;
        if (icon == null) {
            return null;
        }
        getIconWidthHeight(context);
        if (icon instanceof PaintDrawable) {
            PaintDrawable painter = (PaintDrawable) icon;
            painter.setIntrinsicWidth(width);
            painter.setIntrinsicHeight(height);
        } else if ((icon instanceof BitmapDrawable) && (bitmap = (bitmapDrawable = (BitmapDrawable) icon).getBitmap()) != null && bitmap.getDensity() == 0) {
            bitmapDrawable.setTargetDensity(context.getResources().getDisplayMetrics());
        }
        int iconWidth = icon.getIntrinsicWidth();
        int iconHeight = icon.getIntrinsicHeight();
        Log.d("Utilities", "createIconThumbnail # iconWidth: " + iconWidth + ",iconHeight: " + iconHeight + ",width: " + width + ",height: " + height);
        if (width > 0 && height > 0) {
            if (width < iconWidth || height < iconHeight || 1.0f != 1.0f) {
                float scale = iconHeight;
                float ratio = iconWidth / scale;
                if (iconWidth > iconHeight) {
                    height = (int) (width / ratio);
                } else if (iconHeight > iconWidth) {
                    width = (int) (ratio * height);
                }
                Bitmap.Config c = icon.getOpacity() != -1 ? Bitmap.Config.ARGB_8888 : Bitmap.Config.RGB_565;
                Bitmap thumb = Bitmap.createBitmap(iconWidth, iconHeight, c);
                Canvas canvas = sCanvas;
                canvas.setBitmap(thumb);
                sOldBounds.set(icon.getBounds());
                icon.setBounds(0, 0, iconWidth, iconHeight);
                icon.draw(canvas);
                icon.setBounds(sOldBounds);
                Bitmap scaleIcon = Bitmap.createScaledBitmap(thumb, width, height, true);
                return new FastBitmapDrawable(scaleIcon);
            }
            if (iconWidth < width && iconHeight < height) {
                Bitmap.Config c2 = Bitmap.Config.ARGB_8888;
                Bitmap thumb2 = Bitmap.createBitmap(iconWidth, iconHeight, c2);
                Canvas canvas2 = sCanvas;
                canvas2.setBitmap(thumb2);
                sOldBounds.set(icon.getBounds());
                if (SettingUtil.isTabletDevice()) {
                    icon.setBounds(0, 0, width, height);
                } else {
                    int x = (width - iconWidth) / 2;
                    int y = (height - iconHeight) / 2;
                    icon.setBounds(x, y, iconWidth + x, iconHeight + y);
                }
                icon.draw(canvas2);
                icon.setBounds(sOldBounds);
                Bitmap scaleIcon2 = Bitmap.createScaledBitmap(thumb2, width, height, true);
                return new FastBitmapDrawable(scaleIcon2);
            }
            return icon;
        }
        return icon;
    }

    static Bitmap createBitmapThumbnail(Bitmap bitmap, Context context) {
        getIconWidthHeight(context);
        int width = sIconWidth;
        int height = sIconHeight;
        int bitmapWidth = bitmap.getWidth();
        int bitmapHeight = bitmap.getHeight();
        if (width <= 0 || height <= 0 || (width >= bitmapWidth && height >= bitmapHeight)) {
            return bitmap;
        }
        float ratio = bitmapWidth / bitmapHeight;
        if (bitmapWidth > bitmapHeight) {
            height = (int) (width / ratio);
        } else if (bitmapHeight > bitmapWidth) {
            width = (int) (height * ratio);
        }
        Bitmap.Config c = (width == sIconWidth && height == sIconHeight) ? bitmap.getConfig() : Bitmap.Config.ARGB_8888;
        Bitmap thumb = Bitmap.createBitmap(sIconWidth, sIconHeight, c);
        Canvas canvas = sCanvas;
        Paint paint = sPaint;
        canvas.setBitmap(thumb);
        paint.setDither(false);
        paint.setFilterBitmap(true);
        sBounds.set((sIconWidth - width) / 2, (sIconHeight - height) / 2, width, height);
        sOldBounds.set(0, 0, bitmapWidth, bitmapHeight);
        canvas.drawBitmap(bitmap, sOldBounds, sBounds, paint);
        return thumb;
    }

    private static void getIconWidthHeight(Context context) {
        Resources resources = context.getResources();
        if (SettingUtil.isTabletDevice()) {
            if (sOrientation != resources.getConfiguration().orientation) {
                sIconWidth = -1;
                sOrientation = resources.getConfiguration().orientation;
            }
            if (sIconWidth == -1) {
                int dimensionPixelSize = resources.getDimensionPixelSize(R.dimen.workspace_icon_size);
                sIconHeight = dimensionPixelSize;
                sIconWidth = dimensionPixelSize;
                return;
            }
            return;
        }
        if (sIconWidth == -1) {
            int dimension = (int) resources.getDimension(android.R.dimen.app_icon_size);
            sIconHeight = dimension;
            sIconWidth = dimension;
        }
    }

    public static int getIconWidthHeight() {
        return sIconWidth;
    }

    static Bundle byteArrayToBundle(byte[] data) {
        Parcel parcel = Parcel.obtain();
        parcel.unmarshall(data, 0, data.length);
        parcel.setDataPosition(0);
        Bundle bundle = new Bundle();
        bundle.readFromParcel(parcel);
        return bundle;
    }
}
