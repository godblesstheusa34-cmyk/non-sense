package com.htc.launcher;

import android.app.Activity;
import android.util.Log;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class CarouselDummyActivity extends Activity {
    public static final String EXTRA_TAB = "extra_tab";
    private static final String LOG_TAG = "CarouselDummyActivity";

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        String tag = getIntent().getStringExtra(EXTRA_TAB);
        Log.d(LOG_TAG, "CarouselDummyActivity.onResume: " + tag);
        Launcher launcher = (Launcher) getParent();
        if (launcher.mDrawer.isOpened() && launcher.mIsLauncherAllProgram && !launcher.mIsOpenPersonalizeBySetting) {
            try {
                launcher.updateAllAppsStatus(tag);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
