package com.htc.launcher;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.htc.launcher.custom.CustomResourceUtil;
import java.util.ArrayList;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class AddWallpaperDialogAdapter extends BaseAdapter {
    private final Context mContext;
    private int mIconHeight;
    private int mIconWidth;
    private final LayoutInflater mInflater;
    private ArrayList<String> mItemName = new ArrayList<>();
    private ArrayList<Drawable> mIconRes = new ArrayList<>();

    public AddWallpaperDialogAdapter(Context context) {
        this.mContext = context;
        this.mInflater = (LayoutInflater) this.mContext.getSystemService("layout_inflater");
        LoadListeItemResource();
        this.mIconWidth = this.mContext.getResources().getDimensionPixelSize(R.dimen.add_to_home_icon_width);
        this.mIconHeight = this.mContext.getResources().getDimensionPixelSize(R.dimen.add_to_home_icon_height);
    }

    private void LoadListeItemResource() {
        String[] str = this.mContext.getResources().getStringArray(R.array.select_apply_wallpaper_dialog_items);
        for (int i = 0; i < str.length; i++) {
            this.mItemName.add(str[i]);
            if (i == 0) {
                this.mIconRes.add(this.mContext.getResources().getDrawable(R.drawable.touch_flo));
            } else if (i == 1) {
                this.mIconRes.add(this.mContext.getResources().getDrawable(R.drawable.lockscreen));
            }
        }
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.mItemName.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int position) {
        return this.mItemName.get(position);
    }

    @Override // android.widget.Adapter
    public long getItemId(int position) {
        return position;
    }

    @Override // android.widget.Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = this.mInflater.inflate(34144263, parent, false);
            int listSelectorID = CustomResourceUtil.getDrawableResIdentifier(this.mContext, "rosie_list_selector", 0);
            if (listSelectorID != 0) {
                ((ListView) parent).setSelector(listSelectorID);
            }
        }
        TextView textView = (TextView) convertView;
        textView.setText(this.mItemName.get(position));
        Drawable tmpIcon = this.mIconRes.get(position);
        if (tmpIcon != null) {
            tmpIcon.setBounds(0, 0, this.mIconWidth, this.mIconHeight);
            textView.setCompoundDrawables(tmpIcon, null, null, null);
        }
        textView.setCompoundDrawablePadding(15);
        return convertView;
    }
}
