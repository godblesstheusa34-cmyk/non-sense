package com.htc.launcher;

import android.content.Context;
import android.os.Bundle;
import com.htc.launcher.LauncherSettings;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class ApplicationManager {
    public static final int ALL_PROGRAM_LIST_DEFAULT_PRIORITY = 200;
    public static final int ALL_PROGRAM_LIST_HIGHEST_PRIORITY = Integer.MIN_VALUE;
    public static final int LIST_TYPE_APPLICATION = 1;
    public static final int LIST_TYPE_APP_WIDGET = 2;
    public static final int LIST_TYPE_HTC_FXWIDGET = 5;
    public static final int LIST_TYPE_HTC_WIDGET = 4;
    public static final int LIST_TYPE_SHORTCUT = 3;
    private static final String NULL = "null";
    private static final String TAG = "ApplicationManager";
    private static final boolean localLOGV = false;
    private static boolean initialized = false;
    private static ApplicationManager sInstance = new ApplicationManager();
    private CustomizeAppInfo[] mShowApplicationList = new CustomizeAppInfo[0];
    private CustomizeAppInfo[] mHideApplicationList = new CustomizeAppInfo[0];
    private CustomizeAppInfo[] mShowAppWidgetList = new CustomizeAppInfo[0];
    private CustomizeAppInfo[] mHideAppWidgetList = new CustomizeAppInfo[0];
    private CustomizeAppInfo[] mHideHtcWidgetList = new CustomizeAppInfo[0];
    private CustomizeAppInfo[] mHideHtcFusionWidgetList = new CustomizeAppInfo[0];
    private CustomizeAppInfo[] mShowHtcWidgetList = new CustomizeAppInfo[0];
    private CustomizeAppInfo[] mShowHtcFusionWidgetList = new CustomizeAppInfo[0];
    private CustomizeAppInfo[] mShowShortCutList = new CustomizeAppInfo[0];
    private CustomizeAppInfo[] mHideShortCutList = new CustomizeAppInfo[0];

    public static class CustomizeAppInfo {
        String className;
        String packageName;
        int priority;
        String widgetName;
    }

    public static synchronized ApplicationManager instance(Context context) {
        ApplicationManager applicationManager;
        synchronized (ApplicationManager.class) {
            if (!initialized) {
                sInstance.init(context);
                initialized = true;
            }
            applicationManager = sInstance;
        }
        return applicationManager;
    }

    public boolean inHideCustomizationList(String packageName, String classNameOrWidgetName, int listType) {
        CustomizeAppInfo[] customizeList = new CustomizeAppInfo[0];
        switch (listType) {
            case 1:
                customizeList = this.mHideApplicationList;
                break;
            case 2:
                customizeList = this.mHideAppWidgetList;
                break;
            case 3:
                customizeList = this.mHideShortCutList;
                break;
            case 4:
                customizeList = this.mHideHtcWidgetList;
                break;
            case 5:
                customizeList = this.mHideHtcFusionWidgetList;
                break;
        }
        switch (listType) {
            case 4:
                CustomizeAppInfo[] arr$ = customizeList;
                for (CustomizeAppInfo appInfo : arr$) {
                    if (appInfo.packageName != null && appInfo.packageName.equals(packageName) && (appInfo.widgetName == null || appInfo.widgetName.equals(NULL) || appInfo.widgetName.equals(classNameOrWidgetName))) {
                        return true;
                    }
                }
                break;
            default:
                CustomizeAppInfo[] arr$2 = customizeList;
                for (CustomizeAppInfo appInfo2 : arr$2) {
                    if (appInfo2.packageName != null && appInfo2.packageName.equals(packageName) && (appInfo2.className == null || appInfo2.className.equals(NULL) || appInfo2.className.equals(classNameOrWidgetName))) {
                        return true;
                    }
                }
                break;
        }
        return false;
    }

    public int getCustomizationListPriority(String packageName, String className, int listType) {
        CustomizeAppInfo[] customizeList = new CustomizeAppInfo[0];
        switch (listType) {
            case 1:
                customizeList = this.mShowApplicationList;
                break;
            case 2:
                customizeList = this.mShowAppWidgetList;
                break;
            case 3:
                customizeList = this.mShowShortCutList;
                break;
            case 4:
                CustomizeAppInfo[] customizeList2 = this.mShowHtcWidgetList;
            case 5:
                customizeList = this.mShowHtcFusionWidgetList;
                break;
        }
        switch (listType) {
            case 4:
                CustomizeAppInfo[] arr$ = customizeList;
                for (CustomizeAppInfo appInfo : arr$) {
                    if (appInfo.packageName != null && appInfo.packageName.equals(packageName) && (appInfo.widgetName == null || appInfo.widgetName.equals(NULL) || appInfo.widgetName.equals(className))) {
                        return appInfo.priority;
                    }
                }
                return 200;
            default:
                CustomizeAppInfo[] arr$2 = customizeList;
                for (CustomizeAppInfo appInfo2 : arr$2) {
                    if (appInfo2.packageName != null && appInfo2.packageName.equals(packageName) && (appInfo2.className == null || appInfo2.className.equals(NULL) || appInfo2.className.equals(className))) {
                        return appInfo2.priority;
                    }
                }
                return 200;
        }
    }

    private void init(Context context) {
        Bundle moduleBundle = WidgetPackageManager.getModuleBundle(context);
        initShowHideCustomizationList(moduleBundle);
    }

    private void initShowHideCustomizationList(Bundle moduleBundle) {
        Bundle showBundle = moduleBundle.getBundle("applications_show");
        this.mShowApplicationList = initList(showBundle);
        Bundle hideBundle = moduleBundle.getBundle("applications_hide");
        this.mHideApplicationList = initList(hideBundle);
        Bundle appWidgetshowBundle = moduleBundle.getBundle("app_widgets_show");
        this.mShowAppWidgetList = initList(appWidgetshowBundle);
        Bundle appWidgetHideBundle = moduleBundle.getBundle("app_widgets_hide");
        this.mHideAppWidgetList = initList(appWidgetHideBundle);
        Bundle htcWidgetshowBundle = moduleBundle.getBundle("htc_widgets_show");
        this.mShowHtcWidgetList = initList(htcWidgetshowBundle);
        Bundle htcFusionWidgetshowBundle = moduleBundle.getBundle("htc_fusion_widgets_show");
        this.mShowHtcFusionWidgetList = initList(htcFusionWidgetshowBundle);
        Bundle htcWidgetHideBundle = moduleBundle.getBundle("htc_widgets_hide");
        this.mHideHtcWidgetList = initList(htcWidgetHideBundle);
        Bundle htcFusionWidgetHideBundle = moduleBundle.getBundle("htc_fusion_widgets_hide");
        this.mHideHtcFusionWidgetList = initList(htcFusionWidgetHideBundle);
        Bundle shortCutHideBundle = moduleBundle.getBundle("shortcut_hide");
        this.mHideShortCutList = initList(shortCutHideBundle);
        Bundle shortcutShowBundle = moduleBundle.getBundle("shortcut_show");
        this.mShowShortCutList = initList(shortcutShowBundle);
    }

    private CustomizeAppInfo[] initList(Bundle inputBundle) {
        if (inputBundle == null) {
            return new CustomizeAppInfo[0];
        }
        int size = inputBundle.size();
        CustomizeAppInfo[] tempShowList = new CustomizeAppInfo[size];
        for (int i = 0; i < size; i++) {
            String key = "plenty_set" + (i + 1);
            Bundle childBundle = inputBundle.getBundle(key);
            tempShowList[i] = new CustomizeAppInfo();
            tempShowList[i].packageName = childBundle.getString("package");
            tempShowList[i].className = childBundle.getString("class");
            tempShowList[i].widgetName = childBundle.getString(LauncherSettings.WidgetItemTypes.WIDGET_NAME);
            String priority = childBundle.getString("priority");
            if (priority == null) {
                tempShowList[i].priority = 200;
            } else {
                tempShowList[i].priority = Integer.parseInt(priority);
            }
        }
        return tempShowList;
    }
}
