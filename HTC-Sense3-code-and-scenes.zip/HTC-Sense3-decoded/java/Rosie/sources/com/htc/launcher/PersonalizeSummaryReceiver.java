package com.htc.launcher;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class PersonalizeSummaryReceiver extends BroadcastReceiver {
    private static final String TAG = "PersonalizeSummaryReceiver";
    private static final boolean localLOGV = false;

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        SharedPreferences preferences = context.getSharedPreferences(Launcher.PERSONALIZE_PREFERENCES, 0);
        String action = intent.getAction();
        for (int i = 0; i < Launcher.ACTION_SUMMARY_CHANGES.length; i++) {
            if (Launcher.ACTION_SUMMARY_CHANGES[i].equals(action)) {
                String summary = intent.getStringExtra("com.htc.intent.EXTRA_SUMMARY");
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString(Launcher.ACTION_SUMMARY_CHANGES[i], summary);
                try {
                    editor.apply();
                } catch (Exception e) {
                }
            }
        }
    }
}
