package com.htc.android.rosie.home;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.ContentObserver;
import android.hardware.Sensor;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.htc.android.rosie.home.fxcontrol.FxShortcutButton;
import com.htc.android.rosie.widget.Widget;
import com.htc.android.rosie.widget.WidgetManager;
import com.htc.android.rosie.widget.WidgetProvider;
import com.htc.fusion.fx.FxScene;
import com.htc.launcher.FxItem;
import com.htc.launcher.LauncherModel;
import com.htc.launcher.Logger;
import com.htc.launcher.settings.SettingUtil;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class HostWidgetManager implements WidgetManager.Host {
    private static final String NEXT_ID_FILE_NAME = "widget-manager-data";
    private Worker mBkgWorker;
    private final Owner mOwner;
    private SensorManager mSensorManager;
    private static final String LOG_TAG = HostWidgetManager.class.getSimpleName();
    private static final boolean localLOGD = SettingUtil.localLOGD;
    private static int sNextWidgetId = 16777216;
    private List<WidgetInfo> mWidgets = new LinkedList();
    private Runnable mIdSaver = new Runnable() { // from class: com.htc.android.rosie.home.HostWidgetManager.1
        @Override // java.lang.Runnable
        public void run() {
            try {
                if (HostWidgetManager.localLOGD) {
                    Log.d(HostWidgetManager.LOG_TAG, "Saving widget ID:" + HostWidgetManager.sNextWidgetId);
                }
                DataOutputStream out = new DataOutputStream(HostWidgetManager.this.mOwner.getContext().openFileOutput(HostWidgetManager.NEXT_ID_FILE_NAME, 0));
                out.writeInt(HostWidgetManager.sNextWidgetId);
                out.flush();
            } catch (IOException e) {
                Log.e(HostWidgetManager.LOG_TAG, "cannot record widget ID: " + e.getMessage());
            }
        }
    };
    private WorkerFactory mBkgWorkerFactory = new WorkerFactory("background works", 10);
    private Map<SensorEventListener, List<Sensor>> mSensorListeners = new HashMap();
    private int mResultReceiverId = -1;
    List<FxItem> mFxShortcutItems = new ArrayList();
    private final WidgetManager mManager = WidgetManager.getInstance();

    public interface Owner {
        void addResourcePath(String str);

        FxScene createScene(String str, boolean z);

        boolean deleteWidgetInfo(WidgetInfo widgetInfo);

        void destroyScene(FxScene fxScene);

        Context getContext();

        long getInvalidId();

        void startActivityForResult(Intent intent, int i);

        boolean storeWidgetInfo(WidgetInfo widgetInfo);

        void surpressLongClick(boolean z);

        void surpressSlide(boolean z);

        boolean updateWidgetInfo(WidgetInfo widgetInfo);
    }

    public HostWidgetManager(Owner owner) {
        this.mOwner = owner;
        Context ctx = this.mOwner.getContext();
        long start = System.currentTimeMillis();
        sNextWidgetId = LauncherModel.getNextHostWidgetManagerId(ctx);
        if (localLOGD) {
            Logger.d(LOG_TAG, "HostWidgetManager sNextWidgetId:" + sNextWidgetId + " costs:" + (System.currentTimeMillis() - start));
        }
    }

    public int allocWidgetId() {
        int id;
        synchronized (this.mWidgets) {
            if (sNextWidgetId == -1) {
                Log.e(LOG_TAG, "out of widget id!");
                sNextWidgetId++;
            }
            id = sNextWidgetId;
            sNextWidgetId = id + 1;
        }
        return id;
    }

    public Owner getOwner() {
        return this.mOwner;
    }

    public Context getContext() {
        return this.mOwner.getContext();
    }

    public synchronized WidgetInfo addWidget(ComponentName provider, WidgetProvider.Info.Style style, int containerId, int cellX, int cellY, Intent intent) {
        WidgetInfo widgetInfo;
        boolean ok;
        WidgetProvider p = this.mManager.registerProvider(this, provider);
        this.mOwner.addResourcePath(p.getPackageContext().getPackageResourcePath());
        int id = allocWidgetId();
        intent.setComponent(style.component);
        try {
            ok = this.mManager.bindWidgetId(id, p, intent, this, (Properties) null);
        } catch (Widget.WidgetRuntimeException wre) {
            Log.e(LOG_TAG, "fail to bind widget: " + wre.getMessage());
            widgetInfo = null;
        } catch (ClassNotFoundException cnfe) {
            Log.e(LOG_TAG, "fail to bind widget: " + cnfe.getMessage());
            widgetInfo = null;
        } catch (RuntimeException re) {
            Log.e(LOG_TAG, "fail to bind widget: " + re.getMessage());
            widgetInfo = null;
        }
        if (ok) {
            WidgetInfo wi = new WidgetInfo(provider, style.component, style.view.sx, style.view.sy, id);
            wi.setStoreId(this.mOwner.getInvalidId());
            FxScene scene = this.mManager.getWidgetScene(this, id);
            if (scene != null) {
                wi.addToContainer(containerId, cellX, cellY);
                synchronized (this.mWidgets) {
                    this.mWidgets.add(wi);
                }
                this.mManager.startWidget(this, id);
                this.mManager.restoreWidgetState(this, id);
                this.mManager.callWidgetOnPostCreate(this, id);
                widgetInfo = wi;
            } else {
                this.mManager.unbindWidgetId(this, id);
            }
        }
        widgetInfo = null;
        return widgetInfo;
    }

    public boolean addWidget(WidgetInfo widgetInfo) {
        WidgetProvider p = this.mManager.registerProvider(this, widgetInfo.getProvider());
        this.mOwner.addResourcePath(p.getPackageContext().getPackageResourcePath());
        Intent intent = new Intent();
        intent.setComponent(widgetInfo.getName());
        try {
            if (localLOGD) {
                Log.d(LOG_TAG, "bind with data:" + widgetInfo.mData);
            }
            boolean ok = this.mManager.bindWidgetId(widgetInfo.mId, p, intent, this, widgetInfo.mData);
            FxScene scene = null;
            if (ok) {
                scene = this.mManager.getWidgetScene(this, widgetInfo.mId);
                if (scene != null) {
                    synchronized (this.mWidgets) {
                        this.mWidgets.add(widgetInfo);
                    }
                    this.mManager.startWidget(this, widgetInfo.mId);
                    this.mManager.restoreWidgetState(this, widgetInfo.mId);
                    this.mManager.callWidgetOnPostCreate(this, widgetInfo.mId);
                } else {
                    this.mManager.unbindWidgetId(this, widgetInfo.mId);
                }
            }
            return scene != null;
        } catch (Throwable e) {
            Log.e(LOG_TAG, "fail to bind widget: " + e.getMessage());
            return false;
        }
    }

    public void removeWidget(int containerId, int cellX, int cellY) {
        WidgetInfo info = findWidgetInfo(containerId, cellX, cellY);
        if (info != null) {
            removeWidget(info);
        }
    }

    public void removeWidget(int id) {
        WidgetInfo info = findWidgetInfo(id);
        if (info != null) {
            removeWidget(info);
        }
    }

    private void removeWidget(WidgetInfo info) {
        if (info == null) {
            return;
        }
        try {
            this.mManager.pauseWidget(this, info.mId, false);
            this.mManager.stopWidget(this, info.mId);
            this.mManager.destroyWidget(this, info.mId);
            synchronized (this.mWidgets) {
                this.mWidgets.remove(info);
            }
            this.mManager.unbindWidgetId(this, info.mId);
        } catch (RuntimeException ex) {
            Log.e(LOG_TAG, "remove widget(" + info.mName + ") fail");
            ex.printStackTrace();
            if (SettingUtil.localLOGD) {
                throw ex;
            }
        }
    }

    public void updateWidgetContainerId(int widgetId, int newContainerId) {
        WidgetInfo info = findWidgetInfo(widgetId);
        if (info != null) {
            Logger.d("HostWidgetManager", "[EDIT_DEBUG] HostWidgetManager.updateWidgetContainerId(" + widgetId + "  " + info.mContainerId + "->" + newContainerId + ")");
            info.mContainerId = newContainerId;
        }
    }

    public synchronized boolean storeWidgetToDatabase(WidgetInfo info) {
        return this.mOwner.storeWidgetInfo(info);
    }

    public synchronized boolean updateWidgetInDatabase(WidgetInfo info) {
        return this.mOwner.updateWidgetInfo(info);
    }

    public synchronized boolean deleteWidgetFromDatabase(WidgetInfo info) {
        return this.mOwner.deleteWidgetInfo(info);
    }

    public void pauseAllWidgets(boolean saveState) {
        synchronized (this.mWidgets) {
            for (WidgetInfo wi : this.mWidgets) {
                try {
                    long start = System.currentTimeMillis();
                    this.mManager.pauseWidget(this, wi.mId, saveState);
                    Logger.d(SettingUtil.PERFORMANCE_TAG, "Pausing widget " + wi.mName + " costs " + (System.currentTimeMillis() - start));
                } catch (RuntimeException ex) {
                    Log.e(LOG_TAG, "pause widget(" + wi.mName + ") fail");
                    ex.printStackTrace();
                    if (SettingUtil.localLOGD) {
                        throw ex;
                    }
                }
            }
        }
    }

    public void notifyAllWidgetsConfigurationChanged(Configuration newConfiguration) {
        synchronized (this.mWidgets) {
            for (WidgetInfo wi : this.mWidgets) {
                long start = System.currentTimeMillis();
                this.mManager.callWidgetOnConfigurationChanged(this, wi.mId, newConfiguration);
                if (localLOGD) {
                    Log.d(SettingUtil.PERFORMANCE_TAG, "callWidgetOnConfigurationChanged " + wi.getName() + " : " + (System.currentTimeMillis() - start));
                }
            }
        }
        updateFxShortcutOrientation(newConfiguration.orientation);
    }

    public void onOrientationChangeComplete(int containerId) {
        Message msg = Message.obtain();
        msg.what = 3;
        synchronized (this.mWidgets) {
            for (WidgetInfo wi : this.mWidgets) {
                if (containerId == wi.mContainerId) {
                    long start = System.currentTimeMillis();
                    this.mManager.callWidgetOnHostMessage(this, wi.mId, msg);
                    if (localLOGD) {
                        Log.d(SettingUtil.PERFORMANCE_TAG, "onOrientationChangeComplete " + wi.getName() + " : " + (System.currentTimeMillis() - start));
                    }
                }
            }
        }
    }

    public void onResumeInKeyguard(int containerId) {
        Message msg = Message.obtain();
        msg.what = 4;
        synchronized (this.mWidgets) {
            for (WidgetInfo wi : this.mWidgets) {
                msg.arg1 = 0;
                msg.arg1 |= containerId == wi.mContainerId ? 1 : 0;
                msg.arg2 = 0;
                msg.arg2 |= (wi.mCellX + wi.mCellY) << 3;
                this.mManager.callWidgetOnHostMessage(this, wi.mId, msg);
            }
        }
    }

    public void onUserPresent(int containerId, boolean onWorkspace) {
        startWidgetsService(containerId, onWorkspace, 5);
    }

    public void sendEmptyHostMessage(int what) {
        Message msg = Message.obtain();
        msg.what = what;
        synchronized (this.mWidgets) {
            for (WidgetInfo wi : this.mWidgets) {
                long start = System.currentTimeMillis();
                this.mManager.callWidgetOnHostMessage(this, wi.mId, msg);
                Logger.d(SettingUtil.PERFORMANCE_TAG, "sendEmptyHostMessage " + wi.mName + " costs " + (System.currentTimeMillis() - start));
            }
        }
    }

    public void startWidgetsIn(int containerId) {
        synchronized (this.mWidgets) {
            for (WidgetInfo wi : this.mWidgets) {
                if (wi.mContainerId == containerId) {
                    try {
                        long start = System.currentTimeMillis();
                        this.mManager.startWidget(this, wi.mId);
                        Logger.d(SettingUtil.PERFORMANCE_TAG, "startWidget " + wi.mName + " costs " + (System.currentTimeMillis() - start));
                    } catch (RuntimeException ex) {
                        Log.e(LOG_TAG, "start widget(" + wi.mName + ") fail");
                        ex.printStackTrace();
                        if (SettingUtil.localLOGD) {
                            throw ex;
                        }
                    }
                }
            }
        }
    }

    public void stopWidgets(int containerId) {
        synchronized (this.mWidgets) {
            for (WidgetInfo wi : this.mWidgets) {
                try {
                    if (wi.mContainerId == containerId) {
                        this.mManager.stopWidget(this, wi.mId);
                    }
                } catch (RuntimeException ex) {
                    Log.e(LOG_TAG, "stop widget(" + wi.mName + ") fail");
                    ex.printStackTrace();
                    if (SettingUtil.localLOGD) {
                        throw ex;
                    }
                }
            }
        }
    }

    public void resumeWidgets(int containerId) {
        synchronized (this.mWidgets) {
            for (WidgetInfo wi : this.mWidgets) {
                try {
                    if (wi.mContainerId == containerId) {
                        this.mManager.resumeWidget(this, wi.mId);
                    }
                } catch (RuntimeException ex) {
                    Log.e(LOG_TAG, "resume widget(" + wi.mName + ") fail");
                    ex.printStackTrace();
                    if (SettingUtil.localLOGD) {
                        throw ex;
                    }
                }
            }
        }
    }

    public void pauseWidgets(int containerId, boolean saveState) {
        synchronized (this.mWidgets) {
            for (WidgetInfo wi : this.mWidgets) {
                try {
                    if (wi.mContainerId == containerId) {
                        this.mManager.pauseWidget(this, wi.mId, saveState);
                    }
                } catch (RuntimeException ex) {
                    Log.e(LOG_TAG, "pause widget(" + wi.mName + ") fail");
                    ex.printStackTrace();
                    if (SettingUtil.localLOGD) {
                        throw ex;
                    }
                }
            }
        }
    }

    public void setWidgetVisibility(int containerId, boolean visible) {
        synchronized (this.mWidgets) {
            for (WidgetInfo wi : this.mWidgets) {
                if (wi.mContainerId == containerId) {
                    this.mManager.setWidgetVisibility(this, wi.mId, visible);
                }
            }
        }
    }

    public void tiltWidgets(int containerId, float tilt) {
        synchronized (this.mWidgets) {
            for (WidgetInfo wi : this.mWidgets) {
                if (wi.mContainerId == containerId) {
                    long start = System.currentTimeMillis();
                    this.mManager.setWidgetTilt(this, wi.mId, tilt);
                    long diff = System.currentTimeMillis() - start;
                    if (diff > 10 && localLOGD) {
                        Log.d(SettingUtil.PERFORMANCE_TAG, "setWidgetTilt " + wi.getName().getShortClassName() + " : " + diff);
                    }
                }
            }
        }
    }

    public void startWidgetsService(int containerId, boolean onWorkspace, int msgType) {
        synchronized (this.mWidgets) {
            if (localLOGD) {
                Log.d("LOG_TAG", "StartWidgetsServicecurrent workspace:" + Integer.toString(containerId));
            }
            List<WidgetInfo> currentPageWidgets = new LinkedList<>();
            for (WidgetInfo wi : this.mWidgets) {
                if (currentPageWidgets.isEmpty()) {
                    currentPageWidgets.add(wi);
                } else {
                    int idx = 0;
                    while (true) {
                        if (idx >= currentPageWidgets.size()) {
                            break;
                        }
                        int localPriority = (currentPageWidgets.get((currentPageWidgets.size() - idx) - 1).mContainerId * 100) + (currentPageWidgets.get((currentPageWidgets.size() - idx) - 1).mCellY * 10) + currentPageWidgets.get((currentPageWidgets.size() - idx) - 1).mCellX;
                        int iteratorPriority = (wi.mContainerId * 100) + (wi.mCellY * 10) + wi.mCellX;
                        if (localPriority < iteratorPriority) {
                            currentPageWidgets.add(currentPageWidgets.size() - idx, wi);
                            break;
                        }
                        if (localPriority > iteratorPriority) {
                            if (idx == currentPageWidgets.size() - 1) {
                                currentPageWidgets.add(0, wi);
                            }
                        } else {
                            Log.e("LOG_TAG", "StartWidgetsServiceerror: widget overlay issue");
                        }
                        idx++;
                    }
                }
            }
            if (localLOGD) {
                Log.d("LOG_TAG", "StartWidgetsService currentPageWidgets:" + currentPageWidgets);
            }
            Message msg = Message.obtain();
            msg.what = msgType;
            for (WidgetInfo wi2 : currentPageWidgets) {
                msg.arg1 = 0;
                if (onWorkspace) {
                    msg.arg1 |= containerId == wi2.mContainerId ? 1 : 0;
                }
                msg.arg2 = 0;
                this.mManager.callWidgetOnHostMessage(this, wi2.mId, msg);
            }
        }
    }

    public void stopWidgetsService(int containerId) {
        synchronized (this.mWidgets) {
            for (WidgetInfo wi : this.mWidgets) {
                Message msg = Message.obtain();
                msg.what = 2;
                msg.arg1 = wi.mCellX;
                msg.arg2 = wi.mCellY;
                this.mManager.callWidgetOnHostMessage(this, wi.mId, msg);
            }
        }
    }

    public void moveWidgetAt(int fromContainerId, int fromX, int fromY, int toContainerId, int toX, int toY) {
        synchronized (this.mWidgets) {
            for (WidgetInfo wi : this.mWidgets) {
                if (wi.mContainerId == fromContainerId && wi.mCellX == fromX && wi.mCellY == fromY) {
                    this.mWidgets.remove(wi);
                    this.mWidgets.add(wi);
                    wi.mContainerId = toContainerId;
                    wi.mCellX = toX;
                    wi.mCellY = toY;
                    return;
                }
            }
            Logger.w(LOG_TAG, String.format("can't find widget %d %d %d", Integer.valueOf(fromContainerId), Integer.valueOf(fromX), Integer.valueOf(fromY)));
        }
    }

    public void startWidgetAt(int containerId, int x, int y) {
        WidgetInfo found = findWidgetInfo(containerId, x, y);
        if (found == null) {
            return;
        }
        try {
            this.mManager.startWidget(this, found.mId);
        } catch (RuntimeException ex) {
            Log.e(LOG_TAG, "start widget(" + found.mName + ") fail");
            ex.printStackTrace();
            if (SettingUtil.localLOGD) {
                throw ex;
            }
        }
    }

    public void stopWidgetAt(int conatinerId, int x, int y) {
        WidgetInfo found = findWidgetInfo(conatinerId, x, y);
        if (found == null) {
            return;
        }
        try {
            this.mManager.stopWidget(this, found.mId);
        } catch (RuntimeException ex) {
            Log.e(LOG_TAG, "stop widget(" + found.mName + ") fail");
            ex.printStackTrace();
            if (SettingUtil.localLOGD) {
                throw ex;
            }
        }
    }

    public void resumeWidgetAt(int conatinerId, int x, int y) {
        WidgetInfo found = findWidgetInfo(conatinerId, x, y);
        if (found == null) {
            return;
        }
        try {
            this.mManager.resumeWidget(this, found.mId);
        } catch (RuntimeException ex) {
            Log.e(LOG_TAG, "resume widget(" + found.mName + ") fail");
            ex.printStackTrace();
            if (SettingUtil.localLOGD) {
                throw ex;
            }
        }
    }

    public void pauseWidgetAt(int conatinerId, int x, int y) {
        WidgetInfo found = findWidgetInfo(conatinerId, x, y);
        if (found == null) {
            return;
        }
        try {
            this.mManager.pauseWidget(this, found.mId, true);
        } catch (RuntimeException ex) {
            Log.e(LOG_TAG, "pause widget(" + found.mName + ") fail");
            ex.printStackTrace();
            if (SettingUtil.localLOGD) {
                throw ex;
            }
        }
    }

    public boolean isEditable(int containerId, int x, int y) {
        if (localLOGD) {
            Log.d("HostWidgetManager", "isEditable(" + containerId + ":" + x + "," + y + ")");
        }
        WidgetInfo found = findWidgetInfo(containerId, x, y);
        if (found != null) {
            return this.mManager.isEditable(this, found.mId);
        }
        return false;
    }

    public void editWidget(int containerId, int x, int y) {
        WidgetInfo found = findWidgetInfo(containerId, x, y);
        if (found == null) {
            return;
        }
        this.mManager.editWidget(this, found.mId);
    }

    public FxScene getWidgetScene(WidgetInfo info) {
        return this.mManager.getWidgetScene(this, info.mId);
    }

    public FxScene getWidgetScene(int id) {
        return this.mManager.getWidgetScene(this, id);
    }

    public void finish() {
        removeAllWidgets();
        this.mBkgWorkerFactory.close();
        this.mBkgWorkerFactory = null;
    }

    private void saveWidgetId() {
        if (this.mIdSaver != null) {
            this.mIdSaver.run();
        }
    }

    private WidgetInfo findWidgetInfo(int containerId, int cx, int cy) {
        synchronized (this.mWidgets) {
            for (WidgetInfo wi : this.mWidgets) {
                if (wi.mContainerId == containerId && wi.mCellX == cx && wi.mCellY == cy) {
                    return wi;
                }
            }
            Logger.d(LOG_TAG, String.format("can't find widget %d %d %d", Integer.valueOf(containerId), Integer.valueOf(cx), Integer.valueOf(cy)));
            return null;
        }
    }

    public void removeAllWidgets() {
        synchronized (this.mWidgets) {
            for (WidgetInfo wi : this.mWidgets) {
                try {
                    this.mManager.pauseWidget(this, wi.mId, false);
                    this.mManager.stopWidget(this, wi.mId);
                    this.mManager.destroyWidget(this, wi.mId);
                    this.mManager.unbindWidgetId(this, wi.mId);
                } catch (RuntimeException ex) {
                    Log.e(LOG_TAG, "remove widget(" + wi.mName + ") fail");
                    ex.printStackTrace();
                    if (SettingUtil.localLOGD) {
                        throw ex;
                    }
                }
            }
            this.mWidgets.clear();
        }
    }

    public Widget.Host.Worker getWorker() {
        return this.mBkgWorkerFactory.getWorker(null);
    }

    public Widget.Host.Worker getWorker(Handler.Callback callback) {
        return this.mBkgWorkerFactory.getWorker(callback);
    }

    private boolean openSensorManager() {
        if (this.mSensorManager == null) {
            this.mSensorManager = (SensorManager) getContext().getSystemService("sensor");
            Logger.d(LOG_TAG, "new a SensorManager in HostWidgetManager");
            Logger.showStack(10, LOG_TAG);
        }
        return this.mSensorManager != null;
    }

    void stopListenToSensors() {
        if (this.mSensorManager != null) {
            Set<SensorEventListener> listeners = this.mSensorListeners.keySet();
            for (SensorEventListener l : listeners) {
                this.mSensorManager.unregisterListener(l);
            }
            this.mSensorListeners.clear();
            this.mSensorManager = null;
        }
    }

    public Sensor registerSensorListener(SensorEventListener listener, int type, int rate) {
        if (!openSensorManager()) {
            return null;
        }
        List<Sensor> s = this.mSensorManager.getSensorList(type);
        if (s == null || s.size() <= 0) {
            return null;
        }
        Sensor sensor = s.get(0);
        if (!this.mSensorManager.registerListener(listener, sensor, rate)) {
            return null;
        }
        List<Sensor> l = this.mSensorListeners.get(listener);
        if (l == null) {
            l = new ArrayList<>();
            this.mSensorListeners.put(listener, l);
        }
        l.add(sensor);
        if (localLOGD) {
            Log.d(LOG_TAG, "register " + listener + " for sensor:" + sensor);
        }
        return sensor;
    }

    public void unregisterSensorListener(SensorEventListener listener, Sensor sensor) {
        if (listener != null) {
            List<Sensor> l = this.mSensorListeners.remove(listener);
            if (sensor == null) {
                this.mSensorManager.unregisterListener(listener);
                if (l != null) {
                    l.clear();
                }
            } else if (l != null) {
                l.remove(sensor);
            }
            if (localLOGD) {
                Log.d(LOG_TAG, "unregister " + listener + " for sensor:" + sensor);
            }
        }
    }

    public FxScene createScene(String path, boolean visible) {
        return this.mOwner.createScene(path, visible);
    }

    public void destroyScene(FxScene scene) {
        this.mOwner.destroyScene(scene);
    }

    public void surpressSlide(boolean surpress) {
        this.mOwner.surpressSlide(surpress);
    }

    public void surpressLongClick(boolean surpress) {
        this.mOwner.surpressLongClick(surpress);
    }

    public synchronized void storeInstanceData(int id, Properties data) {
        WidgetInfo wi = findWidgetInfo(id);
        if (wi != null) {
            if (localLOGD) {
                Log.d(LOG_TAG, "widget#" + wi.mId + " save data:" + data);
            }
            boolean inDatabase = wi.mStoreId != this.mOwner.getInvalidId();
            wi.saveData(data);
            if (inDatabase) {
                this.mOwner.updateWidgetInfo(wi);
            }
        }
    }

    public synchronized Properties loadInstanceData(int id) {
        WidgetInfo wi;
        wi = findWidgetInfo(id);
        return wi != null ? wi.getData() : null;
    }

    private WidgetInfo findWidgetInfo(int id) {
        synchronized (this.mWidgets) {
            for (WidgetInfo wi : this.mWidgets) {
                if (wi.mId == id) {
                    return wi;
                }
            }
            return null;
        }
    }

    public void startActivity(Intent intent) {
        this.mOwner.startActivityForResult(intent, -1);
    }

    public void startActivityForResult(int id, Intent intent, int requestCode) {
        Logger.d(LOG_TAG, "startActivityForResult id:" + id + " requestCode:" + requestCode);
        this.mResultReceiverId = id;
        this.mOwner.startActivityForResult(intent, requestCode);
    }

    public boolean dispatchActivityResult(int requestCode, int resultCode, Intent data) {
        Logger.d(LOG_TAG, "dispatchActivityResult requestCode:" + requestCode + " resultCode:" + resultCode);
        if (this.mResultReceiverId == -1) {
            return false;
        }
        this.mManager.dispatchActivityResult(this, this.mResultReceiverId, requestCode, resultCode, data);
        this.mResultReceiverId = -1;
        return true;
    }

    public int[] getWidgetPosition(int id) {
        WidgetInfo wi = findWidgetInfo(id);
        if (wi == null) {
            return null;
        }
        int[] pos = {wi.mCellX, wi.mCellY};
        return pos;
    }

    public static final class WidgetInfo {
        private int mCellX;
        private int mCellY;
        private int mContainerId;
        private Properties mData;
        private final int mId;
        private final ComponentName mName;
        private final ComponentName mProvider;
        private final int mSpanX;
        private final int mSpanY;
        private long mStoreId;

        private WidgetInfo(ComponentName provider, ComponentName name, int sx, int sy, int id) {
            this.mContainerId = -1;
            this.mCellX = -1;
            this.mCellY = -1;
            this.mId = id;
            this.mProvider = provider;
            this.mName = name;
            this.mSpanX = sx;
            this.mSpanY = sy;
        }

        public WidgetInfo(ComponentName provider, ComponentName name, int sx, int sy, int id, int containerId, int cx, int cy) {
            this(provider, name, sx, sy, id);
            this.mContainerId = containerId;
            this.mCellX = cx;
            this.mCellY = cy;
        }

        public ComponentName getProvider() {
            return this.mProvider;
        }

        public ComponentName getName() {
            return this.mName;
        }

        public int getSpanX() {
            return this.mSpanX;
        }

        public int getSpanY() {
            return this.mSpanY;
        }

        public int getId() {
            return this.mId;
        }

        public void addToContainer(int container, int x, int y) {
            this.mContainerId = container;
            if (container != -1) {
                this.mCellX = x;
                this.mCellY = y;
            }
        }

        public int getContainerId() {
            return this.mContainerId;
        }

        public int getX() {
            return this.mCellX;
        }

        public int getY() {
            return this.mCellY;
        }

        public void saveData(Properties data) {
            this.mData = data;
        }

        public Properties getData() {
            return this.mData;
        }

        public synchronized void setStoreId(long id) {
            this.mStoreId = id;
        }

        public synchronized long getStoreId() {
            return this.mStoreId;
        }

        public String toString() {
            return "WidgetInfo: provider=" + this.mProvider + ", name=" + this.mName + ", spanX=" + this.mSpanX + ", spanY=" + this.mSpanY + ", ID=" + this.mId + ", store=" + this.mStoreId + ", container=" + this.mContainerId + ", x=" + this.mCellX + ", y=" + this.mCellY + ", data=" + this.mData;
        }
    }

    static class WorkerFactory {
        private boolean mClosed;
        private final String mName;
        private final int mPriority;
        private HandlerThread mThread;

        private WorkerFactory(String name, int priority) {
            this.mName = name;
            this.mPriority = priority;
        }

        private synchronized void open() {
            if (this.mThread == null) {
                this.mThread = new HandlerThread(this.mName, this.mPriority);
                this.mThread.start();
                this.mClosed = false;
            }
        }

        synchronized void close() {
            if (this.mThread != null) {
                this.mThread.getLooper().quit();
                this.mThread = null;
                this.mClosed = true;
            }
        }

        Widget.Host.Worker getWorker(Handler.Callback callback) {
            if (this.mClosed) {
                return null;
            }
            open();
            return new Worker(this.mThread.getLooper(), callback);
        }
    }

    static final class Worker implements Widget.Host.Worker {
        private Handler mHandler;

        private Worker(Looper looper, Handler.Callback callback) {
            if (callback != null) {
                this.mHandler = new Handler(looper, callback);
            } else {
                this.mHandler = new Handler(looper);
            }
        }

        public void post(Runnable r) {
            this.mHandler.post(r);
        }

        public void postDelayed(Runnable r, long delayMillis) {
            this.mHandler.postDelayed(r, delayMillis);
        }

        public void postAtTime(Runnable r, long uptimeMillis) {
            this.mHandler.postAtTime(r, uptimeMillis);
        }

        public void cancel(Runnable r) {
            if (r != null) {
                this.mHandler.removeCallbacks(r);
            }
        }

        public void send(int what) {
            this.mHandler.sendEmptyMessage(what);
        }

        public void sendDelayed(int what, long delayMillis) {
            this.mHandler.sendEmptyMessageDelayed(what, delayMillis);
        }

        public Message obtainMessage() {
            return this.mHandler.obtainMessage();
        }

        public void send(Message msg) {
            this.mHandler.sendMessage(msg);
        }

        public void sendDelayed(Message msg, long delayMillis) {
            this.mHandler.sendMessageDelayed(msg, delayMillis);
        }

        public void sendAtTime(int what, long uptimeMillis) {
            this.mHandler.sendEmptyMessageAtTime(what, uptimeMillis);
        }

        public void sendAtTime(Message msg, long uptimeMillis) {
            this.mHandler.sendMessageAtTime(msg, uptimeMillis);
        }

        public boolean hasMessage(int what) {
            return this.mHandler.hasMessages(what);
        }

        public boolean hasMessage(int what, Object object) {
            return this.mHandler.hasMessages(what, object);
        }

        public void recall(int what) {
            this.mHandler.removeMessages(what);
        }

        public void recall(int what, Object obj) {
            this.mHandler.removeMessages(what, obj);
        }

        public void cancelAll() {
            this.mHandler.removeCallbacksAndMessages(null);
        }

        public ContentObserver getContentObserver(Widget.Host.Worker.ContentChangeCallback callback) {
            return new HostContentObserver(this.mHandler, callback);
        }

        static final class HostContentObserver extends ContentObserver {
            Widget.Host.Worker.ContentChangeCallback mCallback;

            private HostContentObserver(Handler handler, Widget.Host.Worker.ContentChangeCallback callback) {
                super(handler);
                this.mCallback = callback;
            }

            @Override // android.database.ContentObserver
            public void onChange(boolean selfChange) {
                if (this.mCallback == null) {
                    super.onChange(selfChange);
                } else {
                    this.mCallback.onChanged(selfChange);
                }
            }

            @Override // android.database.ContentObserver
            public boolean deliverSelfNotifications() {
                return this.mCallback == null ? super.deliverSelfNotifications() : this.mCallback.deliverSelfNotifications();
            }
        }
    }

    public boolean addFxShortcutItem(FxItem fxItem) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.addFxShortcutItem()");
        if (this.mFxShortcutItems == null) {
            return false;
        }
        for (FxItem item : this.mFxShortcutItems) {
            long id = item.getInfo().getId();
            if (id == fxItem.getInfo().getId()) {
                return false;
            }
        }
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.addFxShortcutItem() done!");
        this.mFxShortcutItems.add(fxItem);
        return true;
    }

    public boolean removeFxShortcutItem(long id) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.removeFxShortcutItem(" + id + ")");
        if (this.mFxShortcutItems == null) {
            return false;
        }
        for (FxItem item : this.mFxShortcutItems) {
            if (id == item.getInfo().getId()) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.removeFxShortcutItem(" + id + ") remove!");
                return this.mFxShortcutItems.remove(item);
            }
        }
        return false;
    }

    public FxItem getFxShortcutItem(long id) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.getFxShortcutItem(" + id + ")");
        if (this.mFxShortcutItems == null) {
            return null;
        }
        for (FxItem item : this.mFxShortcutItems) {
            if (id == item.getInfo().getId()) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.getFxShortcutItem(" + id + ") got!");
                return item;
            }
        }
        return null;
    }

    public FxScene getFxShortcutScene(long id, boolean isPort) {
        FxItem fxItem = getFxShortcutItem(id);
        if (fxItem == null) {
            return null;
        }
        return fxItem.getScene();
    }

    private void updateFxShortcutOrientation(int orientation) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] DesktopItemController.updateFxShortcutOrientation(orientation:" + orientation + ")");
        if (this.mFxShortcutItems != null) {
            synchronized (this.mFxShortcutItems) {
                for (FxItem item : this.mFxShortcutItems) {
                    ((FxShortcutButton) item).updateOrientation(orientation);
                }
            }
        }
    }

    public List<FxItem> getFxShortcutItems() {
        return this.mFxShortcutItems;
    }
}
