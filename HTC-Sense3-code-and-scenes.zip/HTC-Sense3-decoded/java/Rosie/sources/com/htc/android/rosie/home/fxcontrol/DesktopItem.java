package com.htc.android.rosie.home.fxcontrol;

import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.SystemClock;
import com.htc.fusion.fx.FxScene;
import com.htc.fusion.fx.FxView;
import com.htc.fusion.fx.controls.FxCellSceneContainer;
import com.htc.launcher.Draggee;
import com.htc.launcher.FxItem;
import com.htc.launcher.Logger;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class DesktopItem {
    protected FxScene mAttachedScene;
    protected RectF mBounds;
    protected FxItem mFxItem;
    public ItemContainer mItemContainer;
    private final String LOG_TAG = getClass().getSimpleName();
    public boolean isDragging = false;
    protected FxView mFxViewParent = null;
    protected FxCellSceneContainer mFxCellSceneContainer = null;

    public DesktopItem(FxItem fxItem, ItemContainer itemContainer) {
        this.mFxItem = fxItem;
        this.mItemContainer = itemContainer;
        FxScene scene = fxItem.getScene();
        if (scene != null) {
            PointF size = fxItem.getScene().getSize();
            this.mBounds = new RectF(0.0f, 0.0f, size.x, size.y);
        }
    }

    public void attachTo(FxView viewParent) {
        if (this.mItemContainer == null) {
            Logger.d(this.LOG_TAG, "attachTo when mItemContainer == null");
            return;
        }
        FxScene scene = this.mItemContainer.getScene();
        if (scene == null) {
            Logger.d(this.LOG_TAG, "attachTo when mItemContainer.getScene() == null");
            return;
        }
        if (this.mFxViewParent != null || this.mFxCellSceneContainer != null) {
            detach();
        }
        this.mFxViewParent = viewParent;
        this.mFxViewParent.addScene(scene);
        this.mAttachedScene = scene;
        Logger.d(this.LOG_TAG, String.format("attach %d to FxView %d", Integer.valueOf(scene.hashCode()), Integer.valueOf(this.mFxViewParent.hashCode())));
    }

    public boolean attachTo(FxCellSceneContainer cellSceneContainer, Rect r) {
        if (this.mItemContainer == null) {
            Logger.d(this.LOG_TAG, "attachTo when mItemContainer == null");
            return false;
        }
        FxScene scene = this.mItemContainer.getScene();
        if (scene == null) {
            Logger.d(this.LOG_TAG, "attachTo when mItemContainer.getScene() == null");
            return false;
        }
        if (this.mFxViewParent != null || this.mFxCellSceneContainer != null) {
            detach();
        }
        this.mFxCellSceneContainer = cellSceneContainer;
        boolean ok = this.mFxCellSceneContainer.addScene(scene, r);
        if (ok) {
            this.mAttachedScene = scene;
        }
        Logger.d(this.LOG_TAG, String.format("attach %d to cellSceneContainer %d, ok:" + ok, Integer.valueOf(scene.hashCode()), Integer.valueOf(this.mFxCellSceneContainer.hashCode())));
        return ok;
    }

    public boolean detach() {
        if (this.mItemContainer == null) {
            Logger.d(this.LOG_TAG, "detach when mItemContainer == null");
            return false;
        }
        if (this.mAttachedScene == null) {
            Logger.d(this.LOG_TAG, "detach when mItemContainer.getScene() == null");
            return false;
        }
        if (this.mFxViewParent != null) {
            long start = SystemClock.uptimeMillis();
            this.mFxViewParent.removeScene(this.mAttachedScene);
            long diff = SystemClock.uptimeMillis() - start;
            Logger.d(this.LOG_TAG, "detach " + this.mAttachedScene.hashCode() + " from mFxViewParent:" + diff);
            this.mFxViewParent = null;
            return true;
        }
        if (this.mFxCellSceneContainer != null) {
            long start2 = SystemClock.uptimeMillis();
            boolean ok = this.mFxCellSceneContainer.removeScene(this.mAttachedScene);
            long diff2 = SystemClock.uptimeMillis() - start2;
            Logger.d(this.LOG_TAG, "detach " + this.mAttachedScene.hashCode() + " from mFxCellSceneContainer " + this.mFxCellSceneContainer.hashCode() + "," + ok + ",diff:" + diff2);
            this.mFxCellSceneContainer = null;
            return true;
        }
        Logger.d(this.LOG_TAG, "detach but no parent");
        return true;
    }

    public void setVisibility(boolean visible) {
        setItemVisibility(visible);
    }

    public void setItemVisibility(boolean visible) {
        this.mItemContainer.getScene().setVisibility(visible);
    }

    public Draggee getDraggee() {
        return this.mFxItem.getDraggee();
    }

    RectF getRect() {
        return this.mBounds;
    }

    void pick() {
        if (!this.isDragging) {
            if (this.mItemContainer == null) {
                Logger.d("DesktopItem", "[EDIT_DEBUG] DesktopItem.pick() mItemContainer = null, return!");
            } else {
                this.mItemContainer.pick();
                this.isDragging = true;
            }
        }
    }

    void drop() {
        if (this.isDragging) {
            if (this.mItemContainer == null) {
                Logger.d("DesktopItem", "[EDIT_DEBUG] DesktopItem.drop() mItemContainer = null, return!");
            } else {
                this.mItemContainer.drop();
                this.isDragging = false;
            }
        }
    }

    void setFxScene(FxScene scene) {
        if (scene == null) {
            Logger.d("DesktopItem", "[EDIT_DEBUG] DesktopItem.setFxScene() scene = null, return!");
            return;
        }
        this.mFxItem.setScene(scene);
        if (this.mBounds == null) {
            PointF size = scene.getSize();
            this.mBounds = new RectF(0.0f, 0.0f, size.x, size.y);
        }
    }
}
