package com.htc.android.rosie.home.fxcontrol;

import com.htc.fusion.fx.FxDraggable;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.MessageListener;
import com.htc.fusion.fx.controls.FxDropControl;
import com.htc.launcher.Logger;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class FxLeapRearrangeDrop {
    private static final String LOG_TAG = "LeapRearrangeDrop";
    private FxDropControl mFxDrop = null;
    private int mScreen = -1;
    private IFxLeapRearrangeController mFxLeapRearrangeController = null;
    private FxTimelineControl mTimelinePosition = null;
    private MessageListener<FxDraggable> mOnDropActivateListener = new MessageListener<FxDraggable>() { // from class: com.htc.android.rosie.home.fxcontrol.FxLeapRearrangeDrop.1
        public void onMessageReceived(FxDraggable drag) {
            Logger.d(FxLeapRearrangeDrop.LOG_TAG, "[ROSIE_DEBUG] LeapDrop[" + FxLeapRearrangeDrop.this.mScreen + "].onDropEvent() - Activate");
        }
    };
    private MessageListener<FxDraggable> mOnDropDeActivateListener = new MessageListener<FxDraggable>() { // from class: com.htc.android.rosie.home.fxcontrol.FxLeapRearrangeDrop.2
        public void onMessageReceived(FxDraggable drag) {
            Logger.d(FxLeapRearrangeDrop.LOG_TAG, "[ROSIE_DEBUG] LeapDrop[" + FxLeapRearrangeDrop.this.mScreen + "].onDropEvent() - DeActivate");
            if (FxLeapRearrangeDrop.this.mFxLeapRearrangeController != null) {
                FxLeapRearrangeDrop.this.mFxLeapRearrangeController.stopMoveAnimation();
                FxLeapRearrangeDrop.this.mFxLeapRearrangeController.hideIndicator();
            }
        }
    };
    private MessageListener<FxDraggable> mOnDropListener = new MessageListener<FxDraggable>() { // from class: com.htc.android.rosie.home.fxcontrol.FxLeapRearrangeDrop.3
        public void onMessageReceived(FxDraggable drag) {
            Logger.d(FxLeapRearrangeDrop.LOG_TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] LeapDrop[" + FxLeapRearrangeDrop.this.mScreen + "].onDropEvent() - Drop");
            if (FxLeapRearrangeDrop.this.mFxLeapRearrangeController != null) {
                if (FxLeapRearrangeDrop.this.mFxLeapRearrangeController != null) {
                    FxLeapRearrangeDrop.this.mFxLeapRearrangeController.stopMoveAnimation();
                    FxLeapRearrangeDrop.this.mFxLeapRearrangeController.hideIndicator();
                }
                if (FxLeapRearrangeDrop.this.mFxLeapRearrangeController.getDragSource() == null) {
                    Logger.e(FxLeapRearrangeDrop.LOG_TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] LeapDrop[" + FxLeapRearrangeDrop.this.mScreen + "].onDropEvent() - No DragSource, return!");
                } else if (FxLeapRearrangeDrop.this.mFxLeapRearrangeController.getDragSource().getOriginalScreen() == FxLeapRearrangeDrop.this.mScreen) {
                    Logger.d(FxLeapRearrangeDrop.LOG_TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] LeapDrop[" + FxLeapRearrangeDrop.this.mScreen + "].onDropEvent() - Drag=Drop, return!");
                } else if (FxLeapRearrangeDrop.this.mFxLeapRearrangeController.getFxLeapRearrangeListener() != null) {
                    FxLeapRearrangeDrop.this.mFxLeapRearrangeController.getFxLeapRearrangeListener().onLeapRearrangeDrop(FxLeapRearrangeDrop.this.mScreen);
                }
            }
        }
    };
    private MessageListener<FxDraggable> mOnDropOverListener = new MessageListener<FxDraggable>() { // from class: com.htc.android.rosie.home.fxcontrol.FxLeapRearrangeDrop.4
        public void onMessageReceived(FxDraggable drag) {
            Logger.d(FxLeapRearrangeDrop.LOG_TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] LeapDrop[" + FxLeapRearrangeDrop.this.mScreen + "].onDropEvent() - Enter");
            if (FxLeapRearrangeDrop.this.mFxLeapRearrangeController != null) {
                if (FxLeapRearrangeDrop.this.mFxLeapRearrangeController.getDragSource() == null) {
                    Logger.e(FxLeapRearrangeDrop.LOG_TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] LeapDrop[" + FxLeapRearrangeDrop.this.mScreen + "].onDropEvent() - No DragSource, return!");
                    return;
                }
                FxLeapRearrangeDrop.this.mFxLeapRearrangeController.setMoveTo(FxLeapRearrangeDrop.this.mScreen);
                FxLeapRearrangeDrop.this.mFxLeapRearrangeController.setDropTarget(FxLeapRearrangeDrop.this);
                FxLeapRearrangeDrop.this.mFxLeapRearrangeController.showIndicator(FxLeapRearrangeDrop.this.mScreen);
                FxLeapRearrangeDrop.this.mFxLeapRearrangeController.getDragSource().setScreen(FxLeapRearrangeDrop.this.mScreen);
                FxLeapRearrangeDrop.this.mFxLeapRearrangeController.startMoveAnimation();
            }
        }
    };
    private MessageListener<FxDraggable> mOnDropOutListener = new MessageListener<FxDraggable>() { // from class: com.htc.android.rosie.home.fxcontrol.FxLeapRearrangeDrop.5
        public void onMessageReceived(FxDraggable drag) {
            Logger.d(FxLeapRearrangeDrop.LOG_TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] LeapDrop[" + FxLeapRearrangeDrop.this.mScreen + "].onDropEvent() - Exit");
            if (FxLeapRearrangeDrop.this.mFxLeapRearrangeController != null) {
                FxLeapRearrangeDrop.this.mFxLeapRearrangeController.stopMoveAnimation();
                FxLeapRearrangeDrop.this.mFxLeapRearrangeController.hideIndicator();
            }
        }
    };

    public FxLeapRearrangeDrop(int screen, FxDropControl fxDrag) {
        setScreen(screen);
        setFxDrop(fxDrag);
    }

    public void setScreen(int screen) {
        this.mScreen = screen;
    }

    public int getScreen() {
        return this.mScreen;
    }

    private void setFxDrop(FxDropControl fxDrop) {
        this.mFxDrop = fxDrop;
        this.mFxDrop.getDropActivateSource().bind(this.mOnDropActivateListener);
        this.mFxDrop.getDropDeactivateSource().bind(this.mOnDropDeActivateListener);
        this.mFxDrop.getDropSource().bind(this.mOnDropListener);
        this.mFxDrop.getDropOverSource().bind(this.mOnDropOverListener);
        this.mFxDrop.getDropOutSource().bind(this.mOnDropOutListener);
    }

    public FxDropControl getFxDrag() {
        return this.mFxDrop;
    }

    public void setFxLeapRearrangeController(IFxLeapRearrangeController leapRearrangeController) {
        this.mFxLeapRearrangeController = leapRearrangeController;
    }

    public void setPositionTimeline(FxTimelineControl timelinePosition) {
        this.mTimelinePosition = timelinePosition;
    }

    public String toString() {
        return "mScreen(" + this.mScreen + ") " + this.mFxDrop;
    }
}
