package com.htc.android.rosie.home.fxcontrol;

import android.util.Log;
import com.htc.android.rosie.home.fxcontrol.FxScreen;
import com.htc.launcher.settings.SettingUtil;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class FxScreenItemManager {
    private static final String LOG_TAG = FxScreenItemManager.class.getSimpleName();
    private static final boolean localLOGD = SettingUtil.localLOGD;
    private Map<Long, FxScreen.Item> mItems = new HashMap();

    FxScreenItemManager() {
    }

    public int getCount() {
        int size;
        synchronized (this.mItems) {
            size = this.mItems.size();
        }
        return size;
    }

    public final Map<Long, FxScreen.Item> getAll() {
        return this.mItems;
    }

    public FxScreen.Item get(long id) {
        FxScreen.Item i;
        synchronized (this.mItems) {
            i = this.mItems.get(Long.valueOf(id));
        }
        if (i == null && localLOGD) {
            Log.d(LOG_TAG, "Item not found: " + id);
        }
        return i;
    }

    public void add(long id, FxScreen.Item item) {
        synchronized (this.mItems) {
            this.mItems.put(Long.valueOf(id), item);
        }
    }

    public void remove(Long id) {
        synchronized (this.mItems) {
            if (this.mItems.remove(id) == null && localLOGD) {
                Log.d(LOG_TAG, "Item not removed: " + id);
            }
        }
    }

    public Set<Long> keySet() {
        return this.mItems.keySet();
    }
}
