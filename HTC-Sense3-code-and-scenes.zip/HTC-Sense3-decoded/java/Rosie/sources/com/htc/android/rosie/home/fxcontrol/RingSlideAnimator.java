package com.htc.android.rosie.home.fxcontrol;

import android.util.Log;
import com.htc.android.rosie.home.fxcontrol.FxWorkspace;
import com.htc.android.rosie.home.fxcontrol.PageSlideControl;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.Marker;
import com.htc.launcher.settings.SettingUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class RingSlideAnimator extends SlideAnimator {
    private static final String LOG_TAG = "RingSlideAnimator";
    private Marker[] mLeftTranslationMarkers;
    private Marker[] mRightTranslationMarkers;
    private Marker[] mSinkLeftTranslationMarkers;
    private Marker[] mSinkRightTranslationMarkers;

    public RingSlideAnimator(FxWorkspace fxWorkspace, FxTimelineControl slideControl, int screenCount) {
        super(fxWorkspace, slideControl, screenCount);
    }

    @Override // com.htc.android.rosie.home.fxcontrol.SlideAnimator
    protected void initMarkers(int screenCount) {
        this.mLeftTranslationMarkers = new Marker[screenCount + 1];
        this.mRightTranslationMarkers = new Marker[screenCount + 1];
        this.mSinkLeftTranslationMarkers = new Marker[screenCount + 1];
        this.mSinkRightTranslationMarkers = new Marker[screenCount + 1];
        this.mLeftTranslationMarkers[0] = this.mSlideControl.getMarker("6to0");
        this.mLeftTranslationMarkers[1] = this.mSlideControl.getMarker("0to1");
        this.mLeftTranslationMarkers[2] = this.mSlideControl.getMarker("1to2");
        this.mLeftTranslationMarkers[3] = this.mSlideControl.getMarker("2to3");
        this.mLeftTranslationMarkers[4] = this.mSlideControl.getMarker("3to4");
        this.mLeftTranslationMarkers[5] = this.mSlideControl.getMarker("4to5");
        this.mLeftTranslationMarkers[6] = this.mSlideControl.getMarker("5to6");
        this.mLeftTranslationMarkers[7] = this.mSlideControl.getMarker("6to0");
        this.mRightTranslationMarkers[0] = this.mSlideControl.getMarker("0to6");
        this.mRightTranslationMarkers[1] = this.mSlideControl.getMarker("1to0");
        this.mRightTranslationMarkers[2] = this.mSlideControl.getMarker("2to1");
        this.mRightTranslationMarkers[3] = this.mSlideControl.getMarker("3to2");
        this.mRightTranslationMarkers[4] = this.mSlideControl.getMarker("4to3");
        this.mRightTranslationMarkers[5] = this.mSlideControl.getMarker("5to4");
        this.mRightTranslationMarkers[6] = this.mSlideControl.getMarker("6to5");
        this.mRightTranslationMarkers[7] = this.mSlideControl.getMarker("0to6");
        this.mSinkLeftTranslationMarkers[0] = this.mSlideControl.getMarker("s_6to0");
        this.mSinkLeftTranslationMarkers[1] = this.mSlideControl.getMarker("s_0to1");
        this.mSinkLeftTranslationMarkers[2] = this.mSlideControl.getMarker("s_1to2");
        this.mSinkLeftTranslationMarkers[3] = this.mSlideControl.getMarker("s_2to3");
        this.mSinkLeftTranslationMarkers[4] = this.mSlideControl.getMarker("s_3to4");
        this.mSinkLeftTranslationMarkers[5] = this.mSlideControl.getMarker("s_4to5");
        this.mSinkLeftTranslationMarkers[6] = this.mSlideControl.getMarker("s_5to6");
        this.mSinkLeftTranslationMarkers[7] = this.mSlideControl.getMarker("s_6to0");
        this.mSinkRightTranslationMarkers[0] = this.mSlideControl.getMarker("s_0to6");
        this.mSinkRightTranslationMarkers[1] = this.mSlideControl.getMarker("s_1to0");
        this.mSinkRightTranslationMarkers[2] = this.mSlideControl.getMarker("s_2to1");
        this.mSinkRightTranslationMarkers[3] = this.mSlideControl.getMarker("s_3to2");
        this.mSinkRightTranslationMarkers[4] = this.mSlideControl.getMarker("s_4to3");
        this.mSinkRightTranslationMarkers[5] = this.mSlideControl.getMarker("s_5to4");
        this.mSinkRightTranslationMarkers[6] = this.mSlideControl.getMarker("s_6to5");
        this.mSinkRightTranslationMarkers[7] = this.mSlideControl.getMarker("s_0to6");
    }

    @Override // com.htc.android.rosie.home.fxcontrol.SlideAnimator
    public float scrollXToFrame(float scrollX, int screenWidth, PageSlideControl.Direction direction, FxWorkspace.SnapInfo snapInfo) {
        Marker marker;
        Marker marker2;
        if (screenWidth == 0) {
            Log.w(LOG_TAG, "invalid screenWidth");
            return 0.0f;
        }
        int currentScreen = ((int) Math.floor(scrollX / screenWidth)) + 1;
        float shiftX = scrollX;
        while (shiftX >= screenWidth) {
            shiftX -= screenWidth;
        }
        if (currentScreen >= this.mLeftTranslationMarkers.length) {
            currentScreen %= this.mLeftTranslationMarkers.length;
        } else if (currentScreen < 0) {
            currentScreen = 0;
        }
        if (direction == PageSlideControl.Direction.LEFT) {
            if (snapInfo.snapOffset >= SettingUtil.getScreenCount() && !snapInfo.isSnap && snapInfo.end != -1) {
                marker2 = this.mSinkLeftTranslationMarkers[currentScreen];
            } else {
                marker2 = this.mLeftTranslationMarkers[currentScreen];
            }
            return ((((marker2.EndFrame - marker2.StartFrame) + 1) * shiftX) / screenWidth) + marker2.StartFrame;
        }
        if (snapInfo.snapOffset >= SettingUtil.getScreenCount() && !snapInfo.isSnap && snapInfo.end != -1) {
            marker = this.mSinkRightTranslationMarkers[currentScreen];
        } else {
            marker = this.mRightTranslationMarkers[currentScreen];
        }
        return (((screenWidth - shiftX) * ((marker.EndFrame - marker.StartFrame) + 1)) / screenWidth) + marker.StartFrame;
    }

    @Override // com.htc.android.rosie.home.fxcontrol.SlideAnimator
    public float getInitialFrame(int defaultScreenIndex) {
        return this.mLeftTranslationMarkers[defaultScreenIndex].EndFrame + 1;
    }
}
