package com.htc.android.rosie.home.fxcontrol;

import android.os.Vibrator;
import android.util.Log;
import com.htc.fusion.fx.FxScene;
import com.htc.fusion.fx.controls.FxSceneContainer;
import com.htc.launcher.Logger;
import com.htc.launcher.settings.SettingUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class LeapRearrangeController implements IFxLeapRearrangeListener {
    private static final String LOG_TAG = "LeapRearrangeController";
    private FxLeapRearrangeController mFxLeapRearrangeController;
    private FxWorkspace mFxWorkspace;
    private final Vibrator mVibrator = new Vibrator();
    private boolean mHasDropJobNotDone = false;
    private boolean mHasLeapChanged = false;

    public LeapRearrangeController(FxWorkspace fxWorkspace, FxScene scene) {
        this.mFxWorkspace = null;
        this.mFxLeapRearrangeController = null;
        this.mFxWorkspace = fxWorkspace;
        this.mFxLeapRearrangeController = new FxLeapRearrangeController(scene, this.mFxWorkspace.getScreenCount());
        this.mFxLeapRearrangeController.setFxLeapRearrangeListener(this);
    }

    FxSceneContainer getLeapRearrangeContainer(int screen) {
        return this.mFxLeapRearrangeController.getLeapRearrangeContainer(screen);
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeListener
    public void onLeapRearrangeDrag(int from) {
        if (SettingUtil.localLOGD) {
            Log.d(LOG_TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] LeapRearrangeController.onLeapRearrangeDrag(" + from + ")");
        }
        this.mHasLeapChanged = false;
        this.mVibrator.vibrate(35L);
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeListener
    public void onLeapRearrangeDragDrop() {
        if (SettingUtil.localLOGD) {
            Log.d(LOG_TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] LeapRearrangeController.onLeapRearrangeDragDrop() HasLeapChanged:" + this.mHasLeapChanged);
        }
        onDrop();
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeListener
    public void onLeapRearrangeDragDropCancel() {
        Logger.d(LOG_TAG, "[LEAP_REARRANGE_DEBUG] onLeapRearrangeDragCancel()");
        if (this.mFxWorkspace != null && this.mFxLeapRearrangeController != null && this.mFxLeapRearrangeController.getDragSource() != null) {
            this.mFxLeapRearrangeController.getDragSource().reset();
            this.mFxLeapRearrangeController.resetAllDrags();
        }
    }

    private void onDrop() {
        if (this.mFxWorkspace != null && this.mFxLeapRearrangeController != null && this.mFxLeapRearrangeController.getDragSource() != null) {
            if (this.mFxLeapRearrangeController.getDropTarget() == null) {
                if (SettingUtil.localLOGD) {
                    Log.d(LOG_TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] LeapRearrangeController.onLeapRearrangeDragDrop() is moving, return");
                    return;
                }
                return;
            }
            if (!this.mHasLeapChanged) {
                if (SettingUtil.localLOGD) {
                    Log.d(LOG_TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] LeapRearrangeController.onLeapRearrangeDragDrop() no Leap changed, return!!");
                }
                this.mFxLeapRearrangeController.getDragSource().reset();
                return;
            }
            this.mHasDropJobNotDone = false;
            if (this.mFxLeapRearrangeController.isMoving()) {
                this.mHasDropJobNotDone = true;
                if (SettingUtil.localLOGD) {
                    Log.d(LOG_TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] LeapRearrangeController.onLeapRearrangeDragDrop() is moving, return");
                    return;
                }
                return;
            }
            int numOfScreen = this.mFxWorkspace.getScreens().size();
            int[] orginalScreenIndices = new int[numOfScreen];
            for (int i = 0; i < numOfScreen; i++) {
                int originalScreen = this.mFxLeapRearrangeController.getLeapDragOriginalScreen(i);
                orginalScreenIndices[i] = originalScreen;
            }
            this.mFxWorkspace.updateScreenIndices(orginalScreenIndices);
            this.mFxLeapRearrangeController.resetAllDrags();
            this.mFxWorkspace.switchMode(2, 0);
            this.mFxWorkspace.showAllScreens();
            this.mHasLeapChanged = false;
        }
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeListener
    public void onLeapRearrangeDragEnd() {
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeListener
    public void onLeapRearrangeDrop(int to) {
    }

    public void clean() {
        if (this.mFxLeapRearrangeController != null) {
            this.mFxLeapRearrangeController.clean();
        }
    }

    public void setDragEenable(boolean enable) {
        if (this.mFxLeapRearrangeController != null) {
            this.mFxLeapRearrangeController.setDragEnable(enable);
        }
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeListener
    public void onMoveAnimationEnd() {
        if (SettingUtil.localLOGD) {
            Log.d(LOG_TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] LeapRearrangeController.onLeapRearrangeDragDrop() mHasDropJobNotDone:" + this.mHasDropJobNotDone);
        }
        this.mHasLeapChanged = true;
        if (this.mHasDropJobNotDone) {
            onDrop();
        }
    }

    public void showPosition() {
        if (this.mFxLeapRearrangeController != null) {
            this.mFxLeapRearrangeController.showPosition();
        }
    }
}
