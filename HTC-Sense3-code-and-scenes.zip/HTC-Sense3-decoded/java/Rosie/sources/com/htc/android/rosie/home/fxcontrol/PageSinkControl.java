package com.htc.android.rosie.home.fxcontrol;

import android.util.Log;
import android.view.animation.AccelerateInterpolator;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.Marker;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class PageSinkControl implements IPageSinkControl {
    private static final String LOG_TAG = PageSinkControl.class.getSimpleName();
    private static final String MARKER_Z_MOVE = "z_move";
    private int mEndFrame;
    private int mFrameCount;
    private int mStartFrame;
    private FxTimelineControl mTimeline;
    private float mSinkExtent = 0.0f;
    private boolean mToSink = true;
    private float mProgress = 0.0f;
    private float mCurrentSink = 0.0f;
    private float mCurrentFrame = 0.0f;
    private float mStartPi = 0.0f;
    private float mCurrentPi = 0.0f;
    private AccelerateInterpolator mAccelerator = new AccelerateInterpolator();

    PageSinkControl(FxTimelineControl timeline) {
        this.mTimeline = timeline;
        if (this.mTimeline == null) {
            Log.e(LOG_TAG, "timeline not found");
            return;
        }
        Marker m = this.mTimeline.getMarker(MARKER_Z_MOVE);
        if (m == null) {
            Log.e(LOG_TAG, "marker not found");
            return;
        }
        this.mStartFrame = m.StartFrame;
        this.mEndFrame = m.EndFrame;
        this.mFrameCount = this.mEndFrame - this.mStartFrame;
        Log.d(LOG_TAG, "Sink Marker: " + m.Name + "(" + this.mStartFrame + " - " + this.mEndFrame + ")");
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IPageSinkControl
    public void startSink(float extent) {
        if (extent > 1.0f) {
            extent = 1.0f;
        }
        this.mSinkExtent = extent;
        this.mToSink = true;
        this.mStartPi = this.mCurrentPi;
        if (this.mStartPi == 3.141592653589793d) {
            this.mStartPi = 0.0f;
        } else if (this.mStartPi > 1.5707963267948966d) {
            this.mStartPi = (float) (3.141592653589793d - this.mStartPi);
        }
        Log.d(LOG_TAG, "startSink: " + extent + " from " + this.mStartPi);
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IPageSinkControl
    public void startRise() {
        this.mToSink = false;
        this.mStartPi = this.mCurrentPi;
        Log.d(LOG_TAG, "startRise from " + this.mStartPi);
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IPageSinkControl
    public void setScrollProgress(float progress) {
        this.mProgress = progress;
        float newSink = getSink(this.mProgress);
        if (this.mCurrentSink != newSink) {
            this.mCurrentSink = newSink;
            updateSinkFrame();
        }
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IPageSinkControl
    public void reset() {
        Log.d(LOG_TAG, "reset");
        this.mCurrentSink = 0.0f;
        updateSinkFrame();
        this.mSinkExtent = 0.0f;
        this.mCurrentFrame = 0.0f;
        this.mProgress = 0.0f;
        this.mToSink = true;
        this.mStartPi = 0.0f;
        this.mCurrentPi = 0.0f;
    }

    private float getSink(float progress) {
        if (progress == 1.0f) {
            return 0.0f;
        }
        this.mCurrentPi = (float) (this.mStartPi + (progress * (3.141592653589793d - this.mStartPi)));
        return (float) Math.sin(this.mCurrentPi);
    }

    private void updateSinkFrame() {
        if (this.mTimeline != null) {
            float frame = this.mStartFrame + (this.mFrameCount * this.mCurrentSink * this.mSinkExtent);
            if (frame != this.mCurrentFrame) {
                this.mTimeline.setFrame(frame);
            }
            this.mCurrentFrame = frame;
        }
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IPageSinkControl
    public void playSink(float speed) {
        this.mCurrentSink = 1.0f;
        Log.d(LOG_TAG, "playSink");
        if (this.mTimeline != null) {
            this.mTimeline.playFrames(this.mStartFrame, this.mEndFrame, 0, speed, false);
        }
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IPageSinkControl
    public boolean isSinking() {
        return this.mToSink;
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IPageSinkControl
    public float getSink() {
        return this.mCurrentSink;
    }
}
