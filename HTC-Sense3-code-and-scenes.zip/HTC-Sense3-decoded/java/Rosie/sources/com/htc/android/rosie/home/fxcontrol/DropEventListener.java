package com.htc.android.rosie.home.fxcontrol;

import android.os.Handler;
import android.util.Log;
import com.htc.android.rosie.home.fxcontrol.FxDropTarget;
import com.htc.fusion.fx.FxDraggable;
import com.htc.fusion.fx.IMessageSource;
import com.htc.fusion.fx.MessageListener;
import com.htc.fusion.fx.controls.FxDragControl;
import com.htc.launcher.Logger;
import com.htc.launcher.settings.SettingUtil;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class DropEventListener {
    private static final String LOG_TAG = "DropEventListener";
    private Map<IMessageSource<FxDraggable>, MessageListener<FxDraggable>> mBindings = new HashMap();
    protected Handler mHandler;

    public DropEventListener(Handler handler, DropZone zone) {
        this.mHandler = handler;
    }

    void bindEvent(IMessageSource<FxDraggable> source, MessageListener<FxDraggable> handler) {
        this.mBindings.put(source, handler);
        source.bind(handler);
    }

    public void handleEvent(FxDraggable drag, DropZone drop, FxDropTarget.State state) {
        Logger.d("DropBar", "[EDIT_DEBUG] DropEventListener.handleEvent() state:" + state);
        if (state == FxDropTarget.State.DROP) {
            drop.getTarget().mDragOver = false;
            Runnable action = drop.getAction();
            FxDragControl dg = (FxDragControl) drag;
            dg.setHighlight(0);
            if (action != null && this.mHandler != null) {
                this.mHandler.post(action);
                return;
            }
            return;
        }
        if (state == FxDropTarget.State.DRAG_OVER) {
            if (SettingUtil.localLOGD) {
                Log.d(LOG_TAG, drop + " claim");
            }
            drop.getTarget().mDragOver = true;
            FxDragControl dg2 = (FxDragControl) drag;
            dg2.setHighlight(drop.mOverlayColor);
            return;
        }
        if (state == FxDropTarget.State.DRAG_EXIT) {
            if (SettingUtil.localLOGD) {
                Log.d(LOG_TAG, drop + " give up");
            }
            drop.getTarget().mDragOver = false;
            FxDragControl dg3 = (FxDragControl) drag;
            dg3.setHighlight(0);
        }
    }

    private void unbindAll() {
        synchronized (this.mBindings) {
            if (!this.mBindings.isEmpty()) {
                Collection<IMessageSource<FxDraggable>> sources = this.mBindings.keySet();
                for (IMessageSource<FxDraggable> s : sources) {
                    MessageListener<FxDraggable> l = this.mBindings.get(s);
                    s.unbind(l);
                }
            }
            this.mBindings.clear();
        }
    }

    void destroy() {
        unbindAll();
        this.mHandler = null;
    }
}
