package com.htc.android.rosie.home.fxcontrol;

import com.htc.android.rosie.home.fxcontrol.FxWorkspace;
import com.htc.launcher.Workspace;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class UnlockAnimationListener implements FxWorkspace.IUnlockAnimationListener {
    private FxWorkspace mFxWorkspace;
    private Workspace mWorkspace;

    public UnlockAnimationListener(Workspace workspace, FxWorkspace fxWorkspace) {
        this.mWorkspace = null;
        this.mFxWorkspace = null;
        this.mWorkspace = workspace;
        this.mFxWorkspace = fxWorkspace;
    }

    @Override // com.htc.android.rosie.home.fxcontrol.FxWorkspace.IUnlockAnimationListener
    public void onAnimationStart() {
        if (this.mWorkspace != null) {
            this.mWorkspace.lock();
        }
    }

    @Override // com.htc.android.rosie.home.fxcontrol.FxWorkspace.IUnlockAnimationListener
    public void onAnimationEnd() {
        if (this.mWorkspace != null) {
            this.mWorkspace.post(new Runnable() { // from class: com.htc.android.rosie.home.fxcontrol.UnlockAnimationListener.1
                @Override // java.lang.Runnable
                public void run() {
                    UnlockAnimationListener.this.mWorkspace.unlock();
                    UnlockAnimationListener.this.mWorkspace.setCurrentScreen(UnlockAnimationListener.this.mWorkspace.getCurrentScreenIndex());
                }
            });
        }
    }
}
