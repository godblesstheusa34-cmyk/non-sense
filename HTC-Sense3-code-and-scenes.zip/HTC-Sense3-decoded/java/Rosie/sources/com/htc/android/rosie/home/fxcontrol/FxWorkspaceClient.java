package com.htc.android.rosie.home.fxcontrol;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.text.SpannableString;
import android.text.style.ImageSpan;
import android.util.Log;
import com.htc.android.rosie.home.fxcontrol.FxScreen;
import com.htc.android.rosie.home.fxcontrol.FxWorkspace;
import com.htc.android.rosie.home.fxcontrol.TimelineAnimation;
import com.htc.fusion.Point3F;
import com.htc.fusion.fx.FxNodeControl;
import com.htc.fusion.fx.FxObject;
import com.htc.fusion.fx.FxScene;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.IMessageListener;
import com.htc.fusion.fx.IMessageSource;
import com.htc.fusion.fx.Marker;
import com.htc.fusion.fx.MessageListener;
import com.htc.fusion.fx.controls.FxButton;
import com.htc.fusion.fx.controls.FxDragControl;
import com.htc.fusion.fx.controls.FxDropControl;
import com.htc.fusion.fx.controls.FxDynamicImage;
import com.htc.fusion.fx.controls.FxHitbox;
import com.htc.fusion.fx.controls.FxSceneContainer;
import com.htc.fusion.fx.controls.FxTextLabel;
import com.htc.launcher.ApplicationInfo;
import com.htc.launcher.DragSource;
import com.htc.launcher.Draggee;
import com.htc.launcher.FastBitmapDrawable;
import com.htc.launcher.FxItem;
import com.htc.launcher.ItemInfo;
import com.htc.launcher.Launcher;
import com.htc.launcher.Logger;
import com.htc.launcher.R;
import com.htc.launcher.settings.SettingUtil;
import com.htc.util.skin.HtcSkinUtil;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class FxWorkspaceClient {
    private static final String BUTTON_BAR = "timeline.NavBar_rearrange";
    private static final String DROP_EDIT_FX_NAME = "drop.navBtn_side_anim-Left";
    private static final String DROP_EDIT_LABEL = "edit";
    private static final String DROP_MIDDLE_CENTER_FX_NAME = "drop.navbar_middle_center";
    private static final String DROP_MIDDLE_LEFT_FX_NAME = "drop.navbar_middle_left";
    private static final String DROP_MIDDLE_RIGHT_FX_NAME = "drop.navbar_middle_right";
    private static final String DROP_REMOVE_FX_NAME = "drop.navBtn_side_anim-Right";
    private static final String DROP_REMOVE_LABEL = "Remove";
    private static final String FUNCTION_BAR = "timeline.NavBar_preComp";
    static final int ID_FXOBJ_BTN_BACKGROUND_IMAGE_CENTER = 22;
    static final int ID_FXOBJ_BTN_BACKGROUND_IMAGE_LEFT = 21;
    static final int ID_FXOBJ_BTN_BACKGROUND_IMAGE_RIGHT = 23;
    static final int ID_FXOBJ_BTN_DRAG_CENTER = 16;
    static final int ID_FXOBJ_BTN_DRAG_LEFT = 15;
    static final int ID_FXOBJ_BTN_DRAG_RIGHT = 17;
    static final int ID_FXOBJ_BTN_IMAGE_CENTER = 13;
    static final int ID_FXOBJ_BTN_IMAGE_LEFT = 12;
    static final int ID_FXOBJ_BTN_IMAGE_RIGHT = 14;
    static final int ID_FXOBJ_BTN_LABEL_CENTER = 19;
    static final int ID_FXOBJ_BTN_LABEL_LEFT = 18;
    static final int ID_FXOBJ_BTN_LABEL_RIGHT = 20;
    static final int ID_FXOBJ_BTN_NAVBTN_MIDDLE_CENTER = 10;
    static final int ID_FXOBJ_BTN_NAVBTN_MIDDLE_LEFT = 9;
    static final int ID_FXOBJ_BTN_NAVBTN_MIDDLE_RIGHT = 11;
    static final int ID_FXOBJ_BTN_NAV_BTN_SIDE_ANIM_CENTER = 9;
    static final int ID_FXOBJ_BTN_NAV_BTN_SIDE_ANIM_LEFT = 7;
    static final int ID_FXOBJ_BTN_NAV_BTN_SIDE_ANIM_RIGHT = 8;
    static final int ID_FXOBJ_BUTTON_ALLAPPS = 5;
    static final int ID_FXOBJ_BUTTON_PERSONALIZE = 6;
    static final int ID_FXOBJ_FUNCTION_BAR = 3;
    static final int ID_FXOBJ_IN_COMING_CALL_CONTROL = 10;
    static final int ID_FXOBJ_NAVIGATION_BAR = 2;
    static final int ID_FXOBJ_PAGESLIDE = 0;
    static final int ID_FXOBJ_PAGESLIDEZ = 4;
    static final int ID_FXOBJ_SCROLL_BAR = 1;
    private static final int IN_EDITZONE = -960;
    public static final int IN_MIDDLE_CENTER = 1;
    public static final int IN_MIDDLE_LEFT = 0;
    public static final int IN_MIDDLE_RIGHT = 2;
    private static final int IN_REMOVEZONE = -961;
    private static final int IN_WORKSPACE = -962;
    private static final String LEAP_FX_PREFIX = "scenecontainer.container_main_0";
    private static final String LEAP_M10 = "Rosie_leap.m10";
    private static final String LEAP_REARRANGE_M10 = "Rosie_leap_rearrange.m10";
    static final int MODE_LEAP = 1;
    static final int MODE_LEAP_REARRANGE = 2;
    static final int MODE_SCROLL = 0;
    private static final String NAME_BUTTON_ALLAPPS = "timeline.icon_all_apps_rest";
    private static final String NAME_BUTTON_BACKGROUND_IMAGE_CENTER = "timeline.slots_rounded2";
    private static final String NAME_BUTTON_BACKGROUND_IMAGE_LEFT = "timeline.slots_rounded3";
    private static final String NAME_BUTTON_BACKGROUND_IMAGE_RIGHT = "timeline.slots_rounded1";
    private static final String NAME_BUTTON_DRAG_CENTER = "drag.navbar_appicon_center";
    private static final String NAME_BUTTON_DRAG_LEFT = "drag.navbar_appicon_left";
    private static final String NAME_BUTTON_DRAG_RIGHT = "drag.navbar_appicon_right";
    private static final String NAME_BUTTON_IMAGE_CENTER = "di.navbar_appicon_center";
    private static final String NAME_BUTTON_IMAGE_LEFT = "di.navbar_appicon_left";
    private static final String NAME_BUTTON_IMAGE_RIGHT = "di.navbar_appicon_right";
    private static final String NAME_BUTTON_LABEL_CENTER = "text.navbar_app_center";
    private static final String NAME_BUTTON_LABEL_LEFT = "text.navbar_app_left";
    private static final String NAME_BUTTON_LABEL_RIGHT = "text.navbar_app_right";
    private static final String NAME_BUTTON_PERSONALIZE = "timeline.icon_personalize_rest";
    private static final String NAME_BUTTON_PHONE = "timeline.icon_phone_rest";
    private static final String NAVIGATION_BAR = "t.Rosie_Workspace";
    static final int OP_ALL = 0;
    static final int OP_CURRENT_BESIDE = 2;
    static final int OP_CURRENT_ONLY = 1;
    private static final String PAGE_SLIDE_Z;
    private static final String SCROLL_BAR = "timeline.mainnav_scroller";
    private static final String SCROLL_CONTAINER_FX_NAME = "scenecontainer.Page_template";
    private static final String WORKSPACE_LEAP_FX_PREFIX = "timeline.leap_view";
    private static final String WORKSPACE_M10 = "Rosie_workspace.m10";
    private static final String WORKSPACE_SCREEN_FX_PREFIX = "timeline.Container_Main_0";
    private FxTimelineControl mButtonAllApps;
    private IButtonListener mButtonListener;
    private FxTimelineControl mButtonPersonalize;
    private Buttons mButtons;
    private Context mContext;
    private CustomizeShortcut mCustomizeShortcuts;
    private DropBar mDropBar;
    FxWorkspace.IEditModeListener mEditModeListener;
    private FxObject[] mFxObjects;
    private FxWorkspace mFxWorkspace;
    private InComingCallControl mInComingCallControl;
    boolean mIsEnteringEditMode;
    boolean mIsLeavingEditMode;
    private boolean mIsPortrait;
    private List<FxSceneContainer> mLeapContainers;
    private List<FxNodeControl> mLeapPanels;
    private FxScene mLeapRearrangeScene;
    private FxScene mLeapScene;
    private FxWorkspace.NavigationBar mNavigationBar;
    private FxWorkspace.PageLeapControl mPageLeapControl;
    private IPageSinkControl mPageSinkControl;
    private PageSlideControl mPageSlideControl;
    private PageSlideZControl mPageSlideZControl;
    private List<FxWorkspace.ScreenHolder> mScreens;
    private List<FxSceneContainer> mScrollContainers;
    private FxScene mSlideScene;
    private FxDropControl mfxDropEdit;
    private FxDropControl mfxDropRemove;
    private static final String LOG_TAG = FxWorkspace.class.getSimpleName();
    private static final boolean localLOGD = SettingUtil.localLOGD;
    private FxWorkspace mFxParent = null;
    private FxScene mAttachedScene = null;
    private int mMode = 0;
    private LeapRearrangeController mLeapRearrangeController = null;
    boolean mDontFreezeWhenLeap = false;
    private boolean mIsFirstDraw = true;
    private boolean mQuickScrolling = false;
    TimelineAnimation.OnCompleteListener mFadeOutListener = new TimelineAnimation.OnCompleteListener() { // from class: com.htc.android.rosie.home.fxcontrol.FxWorkspaceClient.5
        @Override // com.htc.android.rosie.home.fxcontrol.TimelineAnimation.OnCompleteListener
        public void onCompleted(TimelineAnimation animation) {
        }
    };
    private String[] mScopeFull = {ItemContainer.DRAG_SCOPE_FULL};
    private String[] mScopeEmpty = {ItemContainer.DRAG_SCOPE_EMPTY};
    private Marker[] mButtonBarMarkers = new Marker[5];
    private Marker[] mButtonBarDropMarkers = new Marker[3];
    Map<String, Buttons.ButtonClickListener> mButtonListenerMap = new HashMap();
    public FxDropControl[] mButtonBarDropControl = {null, null, null};
    private boolean mIsUnlockFrameSet = false;
    private int mFadeOutAnimationCompleteCount = 0;
    private Launcher mLauncher = Launcher.sRefLauncher.get();

    public interface IButtonListener {
        public static final int MSG_CLICK_ALL_APPS = 0;
        public static final int MSG_CLICK_MIDDLE_CENTER = 4;
        public static final int MSG_CLICK_MIDDLE_LEFT = 3;
        public static final int MSG_CLICK_MIDDLE_RIGHT = 5;
        public static final int MSG_CLICK_PERSONALIZE = 1;
        public static final int MSG_CLICK_PHONE = 2;

        void onClick(int i);
    }

    static {
        PAGE_SLIDE_Z = SettingUtil.isTabletDevice() ? "timeline.page_slide_z" : "timeline.page_slide_Z";
    }

    public FxWorkspaceClient(FxWorkspace fxworkspace, boolean isPortrait, IButtonListener buttonListner) {
        this.mIsPortrait = true;
        this.mFxWorkspace = fxworkspace;
        this.mIsPortrait = isPortrait;
        this.mButtonListener = buttonListner;
        initSceneAndControlls();
        populateScreens(false);
    }

    private void initSceneAndControlls() {
        initSlide();
        initLeap();
        initLeapRearrange();
    }

    public void attachTo(FxWorkspace parent, int mode) {
        if (this.mFxParent != null || this.mAttachedScene != null) {
            if (localLOGD) {
                Log.d(LOG_TAG, String.format("%s: attach but has parent, detach first", this));
            }
            detach();
        }
        FxScene scene = null;
        switch (mode) {
            case 0:
                scene = getSlideScene();
                break;
            case 1:
                scene = getLeapScene();
                break;
            case 2:
                scene = getLeapRearrangeScene();
                break;
        }
        if (scene == null) {
            Log.e(LOG_TAG, String.format("%s: attach scene but scene is null", this));
            return;
        }
        this.mAttachedScene = scene;
        this.mFxParent = parent;
        parent.addScene(scene);
        if (localLOGD) {
            Log.d(LOG_TAG, String.format("%s: attch %s", this, this.mAttachedScene));
        }
    }

    public void detach() {
        if (this.mFxParent == null || this.mAttachedScene == null) {
            Log.e(LOG_TAG, String.format("%s: detach but no parent", this));
            return;
        }
        if (localLOGD) {
            Log.d(LOG_TAG, String.format("%s: detach %s", this, this.mAttachedScene));
        }
        this.mFxParent.removeScene(this.mAttachedScene);
        this.mAttachedScene = null;
        this.mFxParent = null;
    }

    public FxScene getSlideScene() {
        return this.mSlideScene;
    }

    public FxScene getLeapScene() {
        return this.mLeapScene;
    }

    public FxScene getLeapRearrangeScene() {
        return this.mLeapRearrangeScene;
    }

    public PageSlideControl getPageSlideControl() {
        return this.mPageSlideControl;
    }

    public FxWorkspace.PageLeapControl getPageLeapControl() {
        return this.mPageLeapControl;
    }

    public PageSlideZControl getPageSlideZControl() {
        return this.mPageSlideZControl;
    }

    public IPageSinkControl getPageSinkControl() {
        return this.mPageSinkControl;
    }

    public List<FxWorkspace.ScreenHolder> getScreens() {
        return this.mScreens;
    }

    public List<FxSceneContainer> getScrollContainers() {
        return this.mScrollContainers;
    }

    public List<FxSceneContainer> getLeapContainers() {
        return this.mLeapContainers;
    }

    void switchMode(int mode, int op, int currentScreen) {
        if (localLOGD) {
            Log.d(LOG_TAG, "(Client) switchMode(" + mode + ", currentOnly? " + op + "), P? " + isPortrait());
        }
        System.currentTimeMillis();
        int prevMode = this.mMode;
        switch (mode) {
            case 0:
                if (prevMode == 1) {
                    if (this.mDontFreezeWhenLeap) {
                        freezeAllScreens();
                    }
                    this.mDontFreezeWhenLeap = false;
                }
                this.mMode = mode;
                if (this.mLeapRearrangeController != null) {
                    this.mLeapRearrangeController.setDragEenable(false);
                }
                if (op == 0) {
                    FxWorkspace.batchDetachScreens(this.mScreens);
                    FxWorkspace.batchAttachScreens(this.mScrollContainers, this.mScreens);
                    break;
                } else if (op == 1) {
                    if (currentScreen < getScreens().size() && currentScreen >= 0) {
                        FxWorkspace.ScreenHolder holder = getScreens().get(currentScreen);
                        holder.detach();
                        holder.attachTo(getScrollContainers().get(currentScreen));
                        break;
                    } else {
                        Log.w(LOG_TAG, "invalid screen " + currentScreen);
                        break;
                    }
                } else {
                    int size = getScreens().size() - 1;
                    FxSceneContainer[] fxSceneContainers = new FxSceneContainer[size];
                    FxScene[] fxScenes = new FxScene[size];
                    List<FxSceneContainer> ScrollContainers = new ArrayList<>();
                    List<FxScene> scenes = new ArrayList<>();
                    for (int i = 0; i < getScreens().size(); i++) {
                        if (currentScreen != i) {
                            ScrollContainers.add(getScrollContainers().get(i));
                            scenes.add(getScreens().get(i).mFxScreen.getScene());
                            getScreens().get(i).mFxParent = getScrollContainers().get(i);
                        }
                    }
                    for (int i2 = 0; i2 < ScrollContainers.size(); i2++) {
                        fxSceneContainers[i2] = ScrollContainers.get(i2);
                        fxScenes[i2] = scenes.get(i2);
                    }
                    FxObject[] fxObjects = new FxObject[size];
                    FxSceneContainer.batchRemoveScenes(fxSceneContainers, fxObjects);
                    FxSceneContainer.batchSetScenes(fxSceneContainers, fxScenes);
                    break;
                }
            case 1:
                this.mMode = mode;
                FxWorkspace.batchDetachScreens(this.mScreens);
                FxWorkspace.batchAttachScreens(this.mLeapContainers, this.mScreens);
                if (prevMode == 0) {
                    if (isPortrait()) {
                        showAllScreens();
                    }
                    if (this.mDontFreezeWhenLeap) {
                        thawAllScreens();
                        break;
                    } else {
                        freezeAllScreens();
                        break;
                    }
                }
                break;
            case 2:
                if (this.mLeapRearrangeController != null) {
                    if (this.mDontFreezeWhenLeap) {
                        freezeAllScreens();
                    }
                    this.mDontFreezeWhenLeap = false;
                    this.mMode = mode;
                    if (this.mLeapRearrangeController != null) {
                        this.mLeapRearrangeController.setDragEenable(true);
                    }
                    List<FxSceneContainer> leapRearrangeContainers = new ArrayList<>();
                    for (int i3 = 0; i3 < this.mScreens.size(); i3++) {
                        leapRearrangeContainers.add(this.mLeapRearrangeController.getLeapRearrangeContainer(i3));
                    }
                    if (localLOGD) {
                        Log.d("mode10", "[Rosie] Scene MODE_LEAP_REARRANGE - detach scene");
                    }
                    FxWorkspace.batchDetachScreens(this.mScreens);
                    if (localLOGD) {
                        Log.d("mode10", "[Rosie] Scene MODE_LEAP_REARRANGE - attach scene");
                    }
                    FxWorkspace.batchAttachScreens(leapRearrangeContainers, this.mScreens);
                    break;
                }
                break;
        }
    }

    public void changeScreensVisibility(boolean aligned, int currentScreen, int nextScreen, float value, float speed) {
        int N = SettingUtil.getScreenCount();
        for (int i = 0; i < N; i++) {
            FxWorkspace.ScreenHolder sh = getScreens().get(i);
            if (this.mIsPortrait) {
                sh.setSensorValue(value, speed);
                if (i == currentScreen || (!aligned && i == nextScreen)) {
                    sh.setVisibility(true);
                    if (!this.mQuickScrolling) {
                        sh.thaw();
                    }
                } else {
                    if (!sh.isFrozen()) {
                        this.mLauncher.flattenWidgets(i);
                        sh.freeze();
                    }
                    if (!this.mQuickScrolling) {
                        sh.setVisibility(false);
                    }
                }
            } else {
                sh.setSensorValue(1.0f - value, speed);
                sh.setVisibility(true);
                if (i == currentScreen || (!aligned && i == nextScreen)) {
                    if (!this.mQuickScrolling) {
                        sh.thaw();
                    }
                } else if (!sh.isFrozen()) {
                    this.mLauncher.flattenWidgets(i);
                    sh.freezeAsync();
                }
            }
        }
        if (this.mIsFirstDraw) {
            this.mIsFirstDraw = false;
        }
    }

    void quickScroll(boolean quickScroll) {
        this.mQuickScrolling = quickScroll;
    }

    public FxScreen getScreen(int screen) {
        if (isValidScreenId(screen)) {
            return getScreens().get(screen).mFxScreen;
        }
        return null;
    }

    public void showAllScreens() {
        if (localLOGD) {
            Log.d(LOG_TAG, "showAllScreens");
        }
        int N = SettingUtil.getScreenCount();
        for (int i = 0; i < N; i++) {
            FxWorkspace.ScreenHolder sh = getScreens().get(i);
            sh.setVisibility(true);
        }
    }

    public void thawAllScreens() {
        if (localLOGD) {
            Log.d(LOG_TAG, "thawAllScreens");
        }
        int N = SettingUtil.getScreenCount();
        for (int i = 0; i < N; i++) {
            FxWorkspace.ScreenHolder sh = getScreens().get(i);
            sh.thaw();
        }
    }

    public void pulseFreezeAllScreens() {
        if (localLOGD) {
            Log.d(LOG_TAG, "pulseFreezeAllScreens");
        }
        int N = SettingUtil.getScreenCount();
        for (int i = 0; i < N; i++) {
            FxWorkspace.ScreenHolder sh = this.mScreens.get(i);
            sh.pulseFreeze();
        }
    }

    public void freezeAllScreens() {
        if (localLOGD) {
            Log.d(LOG_TAG, "freezeAllScreens");
        }
        int N = SettingUtil.getScreenCount();
        for (int i = 0; i < N; i++) {
            FxWorkspace.ScreenHolder sh = this.mScreens.get(i);
            sh.freeze();
        }
    }

    public boolean addItemToScreen(int screen, long id, FxItem item, FxScreen.LayoutParams layout) {
        if (localLOGD) {
            Log.d(LOG_TAG, "add widget#" + id + " to Screen#" + screen);
        }
        if (isValidScreenId(screen)) {
            return getScreens().get(screen).mFxScreen.addItem(id, item, layout);
        }
        return false;
    }

    public boolean removeItemFromScreen(int screen, int id) {
        if (localLOGD) {
            Log.d(LOG_TAG, "remove widget from Screen#" + screen);
        }
        if (isValidScreenId(screen)) {
            return getScreens().get(screen).mFxScreen.removeItem(id);
        }
        return false;
    }

    public void removeAllItems() {
        if (getScreens() != null) {
            for (FxWorkspace.ScreenHolder holder : getScreens()) {
                if (holder != null && holder.mFxScreen != null) {
                    holder.mFxScreen.removeFolder();
                    holder.mFxScreen.removeAllItems();
                }
            }
        }
    }

    public FxWorkspace.NavigationBar getNavigationBar() {
        return this.mNavigationBar;
    }

    public void showEditControls(boolean show) {
        this.mButtons.showEditControls(show);
    }

    public void showMiddleBackgroundImageControls(boolean[] show) {
        if (SettingUtil.isDoubleShot()) {
            this.mButtons.showMiddleBackgroundImageControls(show);
        }
    }

    public void updateCustomizeShortut(int index, ApplicationInfo info) {
        this.mCustomizeShortcuts.set(index, info.icon, info.title);
    }

    public void showCustomizeShortcut(int index, boolean show) {
        this.mCustomizeShortcuts.show(index, show);
    }

    public int getButtonBarLongClickX(float x, float y) {
        float tmp;
        float tmp2;
        Resources res = this.mFxWorkspace.getResources();
        if (res.getConfiguration().orientation == 2) {
            x = y;
            y = x;
        }
        int middle_btn_top = res.getDimensionPixelSize(R.dimen.middle_left_btn_top);
        int middle_left_btn_left = res.getDimensionPixelSize(R.dimen.middle_left_btn_left);
        int middle_left_btn_right = res.getDimensionPixelSize(R.dimen.middle_left_btn_right);
        int middle_center_btn_right = res.getDimensionPixelSize(R.dimen.middle_center_btn_right);
        int middle_right_btn_right = res.getDimensionPixelSize(R.dimen.middle_right_btn_right);
        if (SettingUtil.isDoubleShot() && res.getConfiguration().orientation == 2) {
            float tempx = x;
            float x2 = y;
            int middle_right_btn_top = res.getDimensionPixelSize(R.dimen.middle_right_btn_top);
            int middle_right_btn_bottom = res.getDimensionPixelSize(R.dimen.middle_right_btn_bottom);
            int middle_center_btn_bottom = res.getDimensionPixelSize(R.dimen.middle_center_btn_bottom);
            int middle_left_btn_bottom = res.getDimensionPixelSize(R.dimen.middle_left_btn_bottom);
            if (x2 < middle_left_btn_left) {
                tmp2 = -962.0f;
            } else if (tempx < middle_right_btn_top) {
                tmp2 = -961.0f;
            } else if (tempx <= middle_right_btn_bottom) {
                tmp2 = 2.0f;
            } else if (tempx <= middle_center_btn_bottom) {
                tmp2 = 1.0f;
            } else if (tempx <= middle_left_btn_bottom) {
                tmp2 = 0.0f;
            } else {
                tmp2 = -960.0f;
            }
            return (int) tmp2;
        }
        if (y < middle_btn_top) {
            tmp = -962.0f;
        } else if (x >= middle_left_btn_left && x < middle_left_btn_right) {
            tmp = 0.0f;
        } else if (x >= middle_left_btn_right && x < middle_center_btn_right) {
            tmp = 1.0f;
        } else if (x >= middle_center_btn_right && x < middle_right_btn_right) {
            tmp = 2.0f;
        } else if (x >= middle_right_btn_right) {
            tmp = -961.0f;
        } else {
            tmp = -960.0f;
        }
        return (int) tmp;
    }

    private boolean isPortrait() {
        return this.mIsPortrait;
    }

    private void initSlide() {
        String[] controls;
        this.mSlideScene = Launcher.getFxSceneManager().getFxScene(WORKSPACE_M10, this.mIsPortrait);
        String slideControlName = this.mLauncher.getResources().getString(R.string.slide_control_name);
        if (SettingUtil.isTabletDevice()) {
            String page_slide_z = PAGE_SLIDE_Z;
            if (SettingUtil.isDoubleShot()) {
                controls = new String[]{slideControlName, SCROLL_BAR, NAVIGATION_BAR, FUNCTION_BAR, "timeline.page_slide_Z", NAME_BUTTON_PHONE, NAME_BUTTON_ALLAPPS, "btn.navBtn_side_anim-Left", "btn.navBtn_side_anim-Right", "btn.navbtn_middle_left", "btn.navbtn_middle_center", "btn.navbtn_middle_right", NAME_BUTTON_IMAGE_LEFT, NAME_BUTTON_IMAGE_CENTER, NAME_BUTTON_IMAGE_RIGHT, NAME_BUTTON_DRAG_LEFT, NAME_BUTTON_DRAG_CENTER, NAME_BUTTON_DRAG_RIGHT, NAME_BUTTON_LABEL_LEFT, NAME_BUTTON_LABEL_CENTER, NAME_BUTTON_LABEL_RIGHT, NAME_BUTTON_BACKGROUND_IMAGE_LEFT, NAME_BUTTON_BACKGROUND_IMAGE_CENTER, NAME_BUTTON_BACKGROUND_IMAGE_RIGHT};
            } else {
                controls = new String[]{slideControlName, SCROLL_BAR, NAVIGATION_BAR, FUNCTION_BAR, page_slide_z, NAME_BUTTON_ALLAPPS, NAME_BUTTON_PERSONALIZE, "btn.navBtn_side_anim-Left", "btn.navBtn_side_anim-Right", "btn.navbtn_middle_left", "btn.navbtn_middle_center", "btn.navbtn_middle_right", NAME_BUTTON_IMAGE_LEFT, NAME_BUTTON_IMAGE_CENTER, NAME_BUTTON_IMAGE_RIGHT, NAME_BUTTON_DRAG_LEFT, NAME_BUTTON_DRAG_CENTER, NAME_BUTTON_DRAG_RIGHT, NAME_BUTTON_LABEL_LEFT, NAME_BUTTON_LABEL_CENTER, NAME_BUTTON_LABEL_RIGHT};
            }
            this.mFxObjects = this.mSlideScene.getDescendants(controls);
            if (SettingUtil.localLOGD) {
                int count = this.mFxObjects.length;
                for (int i = 0; i < count; i++) {
                    if (this.mFxObjects[i] == null) {
                        Log.e(LOG_TAG, String.format("mFxObjects[%s] is null: %s", Integer.valueOf(i), controls[i]));
                    }
                }
            }
        } else {
            String[] controls2 = {slideControlName, SCROLL_BAR, NAVIGATION_BAR, FUNCTION_BAR, PAGE_SLIDE_Z, NAME_BUTTON_ALLAPPS, NAME_BUTTON_PERSONALIZE, "btn.navBtn_side_anim-Left", "btn.navBtn_side_anim-Right", "btn.navBtn_side_anim-Center", InComingCallControl.IN_COMING_CALL_CONTROL};
            this.mFxObjects = this.mSlideScene.getDescendants(controls2);
            if (SettingUtil.localLOGD) {
                int count2 = this.mFxObjects.length;
                for (int i2 = 0; i2 < count2; i2++) {
                    if (this.mFxObjects[i2] == null) {
                        Log.e(LOG_TAG, String.format("mFxObjects[%s] is null", Integer.valueOf(i2)));
                    }
                }
            }
        }
        UnlockAnimator animator = new UnlockAnimator(this.mFxWorkspace, this.mFxObjects[0]);
        this.mPageSlideControl = new PageSlideControl(this.mLauncher, this.mFxWorkspace, this.mFxObjects[0], this.mFxObjects[1], this.mLauncher.getResources(), animator, null);
        this.mPageSlideZControl = new PageSlideZControl(this.mFxObjects[4]);
        this.mPageSinkControl = new PageSinkControl(this.mFxObjects[4]);
        this.mNavigationBar = new FxWorkspace.NavigationBar.Builder().setTimeline((FxTimelineControl) this.mFxObjects[2], (FxTimelineControl) this.mFxObjects[3]).setShowButtonBarMarker(this.mSlideScene.getMarker("recent_apps_off"), new TimelineAnimation.OnCompleteListener() { // from class: com.htc.android.rosie.home.fxcontrol.FxWorkspaceClient.4
            @Override // com.htc.android.rosie.home.fxcontrol.TimelineAnimation.OnCompleteListener
            public void onCompleted(TimelineAnimation animation) {
            }
        }).setHideButtonBarMarker(this.mSlideScene.getMarker("recent_apps_on"), new TimelineAnimation.OnCompleteListener() { // from class: com.htc.android.rosie.home.fxcontrol.FxWorkspaceClient.3
            @Override // com.htc.android.rosie.home.fxcontrol.TimelineAnimation.OnCompleteListener
            public void onCompleted(TimelineAnimation animation) {
            }
        }).setShowFunctionBarMarker(this.mSlideScene.getMarker("slide_on"), new TimelineAnimation.OnCompleteListener() { // from class: com.htc.android.rosie.home.fxcontrol.FxWorkspaceClient.2
            @Override // com.htc.android.rosie.home.fxcontrol.TimelineAnimation.OnCompleteListener
            public void onCompleted(TimelineAnimation animation) {
                if (FxWorkspaceClient.this.mIsEnteringEditMode) {
                    FxWorkspaceClient.this.mIsEnteringEditMode = false;
                    if (FxWorkspaceClient.this.mEditModeListener != null) {
                        FxWorkspaceClient.this.mEditModeListener.onPostEnterEditMode();
                    }
                }
            }
        }).setHideFunctionBarMarker(this.mSlideScene.getMarker("slide_off"), new TimelineAnimation.OnCompleteListener() { // from class: com.htc.android.rosie.home.fxcontrol.FxWorkspaceClient.1
            @Override // com.htc.android.rosie.home.fxcontrol.TimelineAnimation.OnCompleteListener
            public void onCompleted(TimelineAnimation animation) {
                if (FxWorkspaceClient.this.mIsLeavingEditMode) {
                    FxWorkspaceClient.this.mIsLeavingEditMode = false;
                    if (FxWorkspaceClient.this.mEditModeListener != null) {
                        FxWorkspaceClient.this.mEditModeListener.onPostLeaveEditMode();
                        FxWorkspaceClient.this.mButtons.setButtonBarMarkersToEnd();
                    }
                }
            }
        }).build();
        this.mButtons = new Buttons();
        if (SettingUtil.isTabletDevice()) {
            this.mCustomizeShortcuts = new CustomizeShortcut();
        }
        initDropBar();
        this.mNavigationBar.showFunctionBar();
        if (!SettingUtil.isTabletDevice()) {
            this.mInComingCallControl = new InComingCallControl();
        }
    }

    private void initLeap() {
        this.mLeapScene = Launcher.getFxSceneManager().getFxScene(LEAP_M10, this.mIsPortrait);
        if (this.mPageLeapControl == null) {
            this.mPageLeapControl = new FxWorkspace.PageLeapControl(this.mLeapScene.findControl(WORKSPACE_LEAP_FX_PREFIX));
        } else {
            this.mPageLeapControl.setTimelineControl((FxTimelineControl) this.mLeapScene.findControl(WORKSPACE_LEAP_FX_PREFIX));
        }
    }

    private void initLeapRearrange() {
        this.mLeapRearrangeScene = Launcher.getFxSceneManager().getFxScene(LEAP_REARRANGE_M10, this.mIsPortrait);
        if (this.mLeapRearrangeScene != null) {
            this.mLeapRearrangeController = new LeapRearrangeController(this.mFxWorkspace, this.mLeapRearrangeScene);
        }
    }

    private void populateScreens(boolean currentOnly) {
        this.mScreens = new ArrayList();
        this.mScrollContainers = new ArrayList();
        this.mLeapContainers = new ArrayList();
        FxTimelineControl leapSceneRoot = null;
        FxScene leapScene = getLeapScene();
        if (leapScene != null) {
            leapSceneRoot = (FxTimelineControl) leapScene.findControl(WORKSPACE_LEAP_FX_PREFIX);
        }
        int N = SettingUtil.getScreenCount();
        boolean isScreenExist = this.mScreens.size() >= N;
        FxObject[] screenControls = getScreenControls(getSlideScene(), 0, N);
        for (int i = 0; i < N; i++) {
            FxTimelineControl screenRoot = (FxTimelineControl) screenControls[i];
            if (localLOGD) {
                Log.d(LOG_TAG, "Screen#" + i + " found: " + screenRoot.getName());
            }
            if (!isScreenExist) {
                FxScreen screen = new FxScreen(this.mLauncher, i, this.mIsPortrait);
                FxWorkspace.ScreenHolder holder = new FxWorkspace.ScreenHolder(screen, getSensorAnimation(screenRoot), screenRoot);
                holder.setFadeAnimation(getFadeAnimation(screenRoot));
                holder.setSensorValue(0.5f, 1.0f);
                this.mScreens.add(holder);
            } else {
                this.mScreens.get(i).mFxScreen.setBackPanelMode(isPortrait() ? 2 : 0);
                this.mScreens.get(i).updateFxScreen();
                this.mScreens.get(i).setSensor(getSensorAnimation(screenRoot));
                this.mScreens.get(i).setFadeAnimation(getFadeAnimation(screenRoot));
                this.mScreens.get(i).setPan(screenRoot);
            }
            FxSceneContainer scroll = screenRoot.getDescendant(SCROLL_CONTAINER_FX_NAME);
            this.mScrollContainers.add(scroll);
            if (leapSceneRoot != null && this.mLeapContainers != null) {
                FxSceneContainer leap = leapSceneRoot.getDescendant(LEAP_FX_PREFIX + Integer.toString(i));
                this.mLeapContainers.add(leap);
            }
        }
    }

    private FxObject[] getScreenControls(FxScene scene, int startIndex, int endIndex) {
        String[] controls = new String[endIndex - startIndex];
        for (int i = startIndex; i < endIndex; i++) {
            controls[i] = WORKSPACE_SCREEN_FX_PREFIX + Integer.toString(i);
        }
        FxObject[] retValues = scene.getDescendants(controls);
        return retValues;
    }

    private TimelineAnimation getSensorAnimation(FxTimelineControl timeline) {
        FxTimelineControl tilt = timeline.getDescendant("timeline.g-sensor_rotate");
        if (tilt != null) {
            int start = tilt.getMarker("limit_right").StartFrame;
            int end = tilt.getMarker("limit_left").StartFrame;
            TimelineAnimation anim = new TimelineAnimation(tilt, start, end - start);
            return anim;
        }
        Log.e(LOG_TAG, "fail to get g-sensor rotation timeline");
        return null;
    }

    private TimelineAnimation getFadeAnimation(FxTimelineControl timeline) {
        FxTimelineControl container = timeline.getDescendant("timeline.g-sensor_rotate");
        if (container != null) {
            Marker m = container.getMarker("Opacity_off");
            if (m == null) {
                Log.w(LOG_TAG, "Fade out marker not found");
                return null;
            }
            TimelineAnimation anim = new TimelineAnimation(container, m);
            anim.setComplateListener(this.mFadeOutListener);
            return anim;
        }
        Log.e(LOG_TAG, "fail to get g-sensor rotation timeline");
        return null;
    }

    public void fadeOtherScreens(int currentScreen) {
        if (isPortrait()) {
            int N = SettingUtil.getScreenCount();
            for (int i = 0; i < N; i++) {
                FxWorkspace.ScreenHolder sh = getScreens().get(i);
                if (i != currentScreen) {
                    sh.startFade();
                } else {
                    sh.thaw();
                }
            }
        }
    }

    public void stopFade(boolean rewind) {
        if (isPortrait()) {
            int N = SettingUtil.getScreenCount();
            for (int i = 0; i < N; i++) {
                FxWorkspace.ScreenHolder sh = getScreens().get(i);
                sh.stopFade(rewind);
            }
        }
    }

    private boolean isValidScreenId(int screen) {
        return screen >= 0 && screen < this.mScreens.size();
    }

    private boolean ensureLeapPanels() {
        if (this.mLeapScene == null) {
            return false;
        }
        if (this.mLeapPanels == null) {
            this.mLeapPanels = new ArrayList();
            for (int i = 0; i < 8; i++) {
                FxNodeControl fxNodeControl = (FxHitbox) this.mLeapScene.findControl("hitbox.leap_view_panel_0" + i);
                if (fxNodeControl != null) {
                    this.mLeapPanels.add(fxNodeControl);
                }
            }
            if (localLOGD) {
                Log.d(LOG_TAG, this.mLeapPanels.size() + " panels");
            }
        }
        return this.mLeapPanels.size() > 0;
    }

    public int findNearestLeapPanel(float x, float y) {
        if (!ensureLeapPanels()) {
            return -1;
        }
        int i = 0;
        int m = -1;
        float min = Float.MAX_VALUE;
        for (FxNodeControl c : this.mLeapPanels) {
            Point3F pos = c.getPosition();
            float dx = pos.x - x;
            float dy = pos.y - y;
            float d = (dx * dx) + (dy * dy);
            if (localLOGD) {
                Log.d("LeapMode", "findNearestLeapPanel(" + x + ", " + y + "), for " + i + " min(" + min + ") <=> d(" + d + ") = dx(" + dx + ")^2 + dy(" + dy + ")^2");
            }
            if (d < min) {
                min = d;
                m = i;
            }
            i++;
        }
        return m;
    }

    private final class Buttons {
        static final String FUSION_TAG_BTN_NAVBTN_MIDDLE_CENTER = "btn.navbtn_middle_center";
        static final String FUSION_TAG_BTN_NAVBTN_MIDDLE_LEFT = "btn.navbtn_middle_left";
        static final String FUSION_TAG_BTN_NAVBTN_MIDDLE_RIGHT = "btn.navbtn_middle_right";
        static final String FUSION_TAG_BTN_NAV_BTN_SIDE_ANIM_CENTER = "btn.navBtn_side_anim-Center";
        static final String FUSION_TAG_BTN_NAV_BTN_SIDE_ANIM_LEFT = "btn.navBtn_side_anim-Left";
        static final String FUSION_TAG_BTN_NAV_BTN_SIDE_ANIM_RIGHT = "btn.navBtn_side_anim-Right";
        private int[] mButtonActionList;
        private ArrayList<ButtonInfo> mButtonInfosArrayList;
        private String[] mFusionTag;
        private ArrayList<FxButton> mFxButtons = new ArrayList<>();

        public Buttons() {
            initButtonAndAction();
        }

        public void showEditControls(boolean show) {
            Iterator i$ = this.mFxButtons.iterator();
            while (i$.hasNext()) {
                FxButton button = i$.next();
                button.setVisibility(!show);
            }
            if (FxWorkspaceClient.localLOGD) {
                Logger.d(FxWorkspaceClient.LOG_TAG, "showEditControls:" + show);
            }
            FxWorkspaceClient.this.mfxDropRemove.setVisibility(show);
            FxWorkspaceClient.this.mfxDropEdit.setVisibility(show);
            FxWorkspaceClient.this.mButtonPersonalize.setVisibility(!show);
            FxWorkspaceClient.this.mButtonAllApps.setVisibility(!show);
        }

        public void showMiddleBackgroundImageControls(boolean[] show) {
            if (show != null) {
                FxTimelineControl buttonBar_Bkg_Img_Left = FxWorkspaceClient.this.mFxObjects[21];
                if (buttonBar_Bkg_Img_Left != null) {
                    buttonBar_Bkg_Img_Left.setVisibility(!show[0]);
                }
                FxTimelineControl buttonBar_Bkg_Img_Center = FxWorkspaceClient.this.mFxObjects[22];
                if (buttonBar_Bkg_Img_Center != null) {
                    buttonBar_Bkg_Img_Center.setVisibility(!show[1]);
                }
                FxTimelineControl buttonBar_Bkg_Img_Right = FxWorkspaceClient.this.mFxObjects[FxWorkspaceClient.ID_FXOBJ_BTN_BACKGROUND_IMAGE_RIGHT];
                if (buttonBar_Bkg_Img_Right != null) {
                    buttonBar_Bkg_Img_Right.setVisibility(!show[2]);
                }
            }
        }

        private void labelPhoneButton() {
            String phoneLabel;
            if (FxWorkspaceClient.this.mFxWorkspace != null && FxWorkspaceClient.this.mSlideScene != null && (phoneLabel = FxWorkspaceClient.this.mFxWorkspace.getResources().getString(R.string.phone)) != null) {
                SpannableString spanString = getPhoneSpan(phoneLabel);
                FxTextLabel phone = FxWorkspaceClient.this.mSlideScene.findControl("phone");
                if (phone != null) {
                    phone.setContent(spanString);
                }
            }
        }

        public SpannableString getPhoneSpan(String label) {
            SpannableString span = new SpannableString(" " + label);
            Drawable d = FxWorkspaceClient.this.mFxWorkspace.getContext().getResources().getDrawable(R.drawable.icon_p_phone_rest);
            d.setBounds(0, 0, 0, 0);
            ImageSpan image = new ImageSpan(d, 0);
            span.setSpan(image, 0, 0, 17);
            return span;
        }

        private void initButtonAndAction() {
            int[] idMappingList;
            if (SettingUtil.isTabletDevice()) {
                if (SettingUtil.isDoubleShot()) {
                    this.mButtonActionList = new int[]{2, 3, 4, 5, 0};
                } else {
                    this.mButtonActionList = new int[]{0, 3, 4, 5, 1};
                }
                idMappingList = new int[]{7, 9, 10, 11, 8};
                this.mFusionTag = new String[]{FUSION_TAG_BTN_NAV_BTN_SIDE_ANIM_LEFT, FUSION_TAG_BTN_NAVBTN_MIDDLE_LEFT, FUSION_TAG_BTN_NAVBTN_MIDDLE_CENTER, FUSION_TAG_BTN_NAVBTN_MIDDLE_RIGHT, FUSION_TAG_BTN_NAV_BTN_SIDE_ANIM_RIGHT};
            } else {
                this.mButtonActionList = new int[]{0, 2, 1};
                idMappingList = new int[]{7, 9, 8};
                this.mFusionTag = new String[]{FUSION_TAG_BTN_NAV_BTN_SIDE_ANIM_LEFT, FUSION_TAG_BTN_NAV_BTN_SIDE_ANIM_CENTER, FUSION_TAG_BTN_NAV_BTN_SIDE_ANIM_RIGHT};
                labelPhoneButton();
            }
            int ButtonCount = this.mButtonActionList.length;
            this.mButtonInfosArrayList = new ArrayList<>();
            FxWorkspaceClient.this.mButtonPersonalize = FxWorkspaceClient.this.mFxObjects[6];
            FxWorkspaceClient.this.mButtonAllApps = FxWorkspaceClient.this.mFxObjects[5];
            for (int i = 0; i < ButtonCount; i++) {
                ButtonInfo buttonInfo = new ButtonInfo(this.mButtonActionList[i], null);
                this.mButtonInfosArrayList.add(buttonInfo);
                String tag = this.mFusionTag[i];
                FxButton button = (FxButton) FxWorkspaceClient.this.mFxObjects[idMappingList[i]];
                FxWorkspaceClient.this.mButtonBarMarkers[i] = button.getMarker("down_to_up");
                if (button == null) {
                    Log.w(FxWorkspaceClient.LOG_TAG, "While binding buttons, we cannot find FxButton(" + tag + "), so Button " + i + "cannot work.");
                } else {
                    this.mFxButtons.add(button);
                    bindFxButtonClickByFusionTag(button, tag);
                    ButtonClickListener listener = FxWorkspaceClient.this.mButtonListenerMap.get(tag);
                    listener.setButtonInfo(buttonInfo);
                }
            }
        }

        public void setButtonBarMarkersToEnd() {
            for (int i = 0; i < this.mFxButtons.size(); i++) {
                this.mFxButtons.get(i).setFrame(FxWorkspaceClient.this.mButtonBarMarkers[i].EndFrame);
            }
            if (SettingUtil.isTabletDevice()) {
                for (int i2 = 0; i2 < FxWorkspaceClient.this.mButtonBarDropControl.length; i2++) {
                    FxWorkspaceClient.this.mButtonBarDropControl[i2].setFrame(FxWorkspaceClient.this.mButtonBarDropMarkers[i2].EndFrame);
                }
            }
        }

        private void bindFxButtonClickByFusionTag(FxButton button, String tag) {
            IMessageListener iMessageListener = (ButtonClickListener) FxWorkspaceClient.this.mButtonListenerMap.get(tag);
            IMessageSource<Void> clickSource = button.getClickSource();
            if (iMessageListener != null) {
                clickSource.unbind(iMessageListener);
            } else {
                iMessageListener = new ButtonClickListener();
                FxWorkspaceClient.this.mButtonListenerMap.put(tag, iMessageListener);
            }
            clickSource.bind(iMessageListener);
        }

        private final class ButtonInfo {
            private FxButton mButton;
            private Intent mIntent;
            private int mMessage;

            public ButtonInfo(int msg, Intent intent) {
                this.mMessage = msg;
                this.mIntent = intent;
            }

            public void updateButtonInfo(int msg, Intent intent) {
                this.mMessage = msg;
                this.mIntent = intent;
            }

            public void setIntent(Intent intent) {
                this.mIntent = intent;
            }
        }

        private class ButtonClickListener extends MessageListener<Void> {
            ButtonInfo mButtonInfo;

            private ButtonClickListener() {
            }

            public void setButtonInfo(ButtonInfo buttonInfo) {
                this.mButtonInfo = buttonInfo;
            }

            public void onMessageReceived(Void arg0) {
                FxWorkspaceClient.this.mButtonListener.onClick(this.mButtonInfo.mMessage);
            }
        }
    }

    public DropBar getDropBar() {
        return this.mDropBar;
    }

    final class RemoveZone extends DropZone {
        private RemoveZone(String scope, FxDropControl drop, FxDropTarget target, int overlayColor) {
            super(scope, drop, target, overlayColor);
            this.mAction = new Runnable() { // from class: com.htc.android.rosie.home.fxcontrol.FxWorkspaceClient.RemoveZone.1
                @Override // java.lang.Runnable
                public void run() {
                    if (FxWorkspaceClient.localLOGD) {
                        Logger.d("RemoveZone", "[EDIT_DEBUG]# RemoveZone.removeItem()");
                    }
                    FxDropTarget target2 = RemoveZone.this.getTarget();
                    FxWorkspaceClient.this.mLauncher.getDesktopItemController().removeItem(target2.source, target2.item);
                }
            };
        }

        @Override // com.htc.android.rosie.home.fxcontrol.DropZone
        public void updateBounds() {
            int left = FxWorkspaceClient.this.mFxWorkspace.getResources().getDimensionPixelSize(R.dimen.remove_btn_left);
            int top = FxWorkspaceClient.this.mFxWorkspace.getResources().getDimensionPixelSize(R.dimen.remove_btn_top);
            int right = FxWorkspaceClient.this.mFxWorkspace.getResources().getDimensionPixelSize(R.dimen.remove_btn_right);
            int bottom = FxWorkspaceClient.this.mFxWorkspace.getResources().getDimensionPixelSize(R.dimen.remove_btn_bottom);
            Rect removeRect = new Rect(left, top, right, bottom);
            getTarget().bounds = removeRect;
        }
    }

    private final class EditZone extends DropZone {
        EditZone(String scope, FxDropControl drop, FxDropTarget target, int overlayColor) {
            super(scope, drop, target, overlayColor);
            this.mAction = new Runnable() { // from class: com.htc.android.rosie.home.fxcontrol.FxWorkspaceClient.EditZone.1
                @Override // java.lang.Runnable
                public void run() {
                    if (FxWorkspaceClient.localLOGD) {
                        Logger.d("EditZone", "[EDIT_DEBUG] EditZone.editItem()");
                    }
                    FxDropTarget target2 = EditZone.this.getTarget();
                    FxWorkspaceClient.this.mLauncher.getDesktopItemController().editItem(target2.source, target2.item);
                }
            };
        }

        @Override // com.htc.android.rosie.home.fxcontrol.DropZone
        boolean accept(Draggee draggee) {
            return FxWorkspaceClient.this.mLauncher.getDesktopItemController().isItemEditable(draggee.getItemInfo());
        }

        @Override // com.htc.android.rosie.home.fxcontrol.DropZone
        public void updateBounds() {
            int left = FxWorkspaceClient.this.mFxWorkspace.getResources().getDimensionPixelSize(R.dimen.edit_btn_left);
            int top = FxWorkspaceClient.this.mFxWorkspace.getResources().getDimensionPixelSize(R.dimen.edit_btn_top);
            int right = FxWorkspaceClient.this.mFxWorkspace.getResources().getDimensionPixelSize(R.dimen.edit_btn_right);
            int bottom = FxWorkspaceClient.this.mFxWorkspace.getResources().getDimensionPixelSize(R.dimen.edit_btn_bottom);
            Rect removeRect = new Rect(left, top, right, bottom);
            getTarget().bounds = removeRect;
        }
    }

    private final class MiddleButtonZone extends DropZone {
        private final int INDEX_BOTTOM;
        private final int INDEX_LEFT;
        private final int INDEX_RIGHT;
        private final int INDEX_TOP;
        private int mButtonID;
        private String mControlName;
        private final int[][] resourceDimenId;

        private MiddleButtonZone(String scope, FxDropControl drop, FxDropTarget target, String controlName, int buttonID) {
            super(scope, drop, target, 0);
            this.resourceDimenId = new int[][]{new int[]{R.dimen.middle_left_btn_left, R.dimen.middle_left_btn_top, R.dimen.middle_left_btn_right, R.dimen.middle_left_btn_bottom}, new int[]{R.dimen.middle_center_btn_left, R.dimen.middle_center_btn_top, R.dimen.middle_center_btn_right, R.dimen.middle_center_btn_bottom}, new int[]{R.dimen.middle_right_btn_left, R.dimen.middle_right_btn_top, R.dimen.middle_right_btn_right, R.dimen.middle_right_btn_bottom}};
            this.INDEX_LEFT = 0;
            this.INDEX_TOP = 1;
            this.INDEX_RIGHT = 2;
            this.INDEX_BOTTOM = 3;
            this.mButtonID = buttonID;
            this.mControlName = controlName;
            this.mAction = new Runnable() { // from class: com.htc.android.rosie.home.fxcontrol.FxWorkspaceClient.MiddleButtonZone.1
                @Override // java.lang.Runnable
                public void run() {
                    FxDropTarget target2 = MiddleButtonZone.this.getTarget();
                    if (target2 != null && target2.item != null && FxWorkspaceClient.this.mFxWorkspace.mButtonBarHandler.getIsButtonBarNull(MiddleButtonZone.this.mButtonID)) {
                        if (target2.item.itemType == 0 || target2.item.itemType == 1) {
                            FxWorkspaceClient.this.mButtonBarDropControl[MiddleButtonZone.this.mButtonID].setDragScope(FxWorkspaceClient.this.mScopeFull);
                            ApplicationInfo info = new ApplicationInfo((ApplicationInfo) target2.item);
                            FxWorkspaceClient.this.mFxWorkspace.mButtonBarHandler.addButtonBarAppOrShortcut(info, MiddleButtonZone.this.mButtonID);
                            FxWorkspaceClient.this.mLauncher.getDesktopItemController().removeItem(target2.source, target2.item);
                            FxWorkspaceClient.this.mLauncher.getDesktopItemController().poofFxItem();
                        }
                    }
                }
            };
        }

        @Override // com.htc.android.rosie.home.fxcontrol.DropZone
        boolean accept(Draggee draggee) {
            ItemInfo info = draggee.getItemInfo();
            if (info.itemType == 0 || info.itemType == 1) {
                if (FxWorkspaceClient.this.mFxWorkspace.mButtonBarHandler.getIsButtonBarNull(this.mButtonID)) {
                    FxWorkspaceClient.this.mButtonBarDropControl[this.mButtonID].setDragScope(FxWorkspaceClient.this.mScopeEmpty);
                } else {
                    FxWorkspaceClient.this.mButtonBarDropControl[this.mButtonID].setDragScope(FxWorkspaceClient.this.mScopeFull);
                }
            } else {
                FxWorkspaceClient.this.mButtonBarDropControl[this.mButtonID].setDragScope(FxWorkspaceClient.this.mScopeFull);
            }
            return true;
        }

        @Override // com.htc.android.rosie.home.fxcontrol.DropZone
        String getScopeKey() {
            return this.mControlName;
        }

        @Override // com.htc.android.rosie.home.fxcontrol.DropZone
        public void updateBounds() {
            int left = FxWorkspaceClient.this.mFxWorkspace.getResources().getDimensionPixelSize(this.resourceDimenId[this.mButtonID][0]);
            int top = FxWorkspaceClient.this.mFxWorkspace.getResources().getDimensionPixelSize(this.resourceDimenId[this.mButtonID][1]);
            int right = FxWorkspaceClient.this.mFxWorkspace.getResources().getDimensionPixelSize(this.resourceDimenId[this.mButtonID][2]);
            int bottom = FxWorkspaceClient.this.mFxWorkspace.getResources().getDimensionPixelSize(this.resourceDimenId[this.mButtonID][3]);
            Rect removeRect = new Rect(left, top, right, bottom);
            getTarget().bounds = removeRect;
        }
    }

    private final class CustomizeShortcut {
        private FxDragControl mDragControlCenter;
        private FxDragControl mDragControlLeft;
        private FxDragControl mDragControlRight;
        private FxDynamicImage[] mDynamicImage;
        private FxTextLabel[] mTextLabel;

        public CustomizeShortcut() {
            this.mDynamicImage = new FxDynamicImage[]{(FxDynamicImage) FxWorkspaceClient.this.mFxObjects[12], (FxDynamicImage) FxWorkspaceClient.this.mFxObjects[13], (FxDynamicImage) FxWorkspaceClient.this.mFxObjects[14]};
            this.mDragControlLeft = FxWorkspaceClient.this.mFxObjects[15];
            this.mDragControlCenter = FxWorkspaceClient.this.mFxObjects[16];
            this.mDragControlRight = FxWorkspaceClient.this.mFxObjects[17];
            this.mDragControlLeft.setEnabled(false);
            this.mDragControlCenter.setEnabled(false);
            this.mDragControlRight.setEnabled(false);
            this.mTextLabel = new FxTextLabel[]{(FxTextLabel) FxWorkspaceClient.this.mFxObjects[18], (FxTextLabel) FxWorkspaceClient.this.mFxObjects[19], (FxTextLabel) FxWorkspaceClient.this.mFxObjects[20]};
        }

        public void set(int index, Drawable icon, CharSequence title) {
            if (icon instanceof FastBitmapDrawable) {
                this.mDynamicImage[index].setImage(((FastBitmapDrawable) icon).getBitmap());
            } else {
                this.mDynamicImage[index].setImage(icon);
            }
            this.mTextLabel[index].setString((String) title);
        }

        public void show(int index, boolean show) {
            this.mDynamicImage[index].setVisibility(show);
            this.mTextLabel[index].setVisibility(show);
        }
    }

    private void labelDrops(FxObject remove, FxObject edit) {
        if (this.mFxWorkspace != null) {
            Resources r = this.mFxWorkspace.getResources();
            if (remove != null && (remove instanceof FxTextLabel)) {
                FxTextLabel rl = (FxTextLabel) remove;
                String delete = r.getString(R.string.delete);
                if (delete != null) {
                    rl.setString(delete);
                }
            }
            if (edit != null && (edit instanceof FxTextLabel)) {
                FxTextLabel el = (FxTextLabel) edit;
                String e = r.getString(R.string.edit);
                if (e != null) {
                    el.setString(e);
                }
            }
        }
    }

    private void initDropBar() {
        String[] controls;
        FxObject[] fxObjects;
        this.mDropBar = new DropBar();
        if (SettingUtil.isTabletDevice()) {
            controls = new String[]{DROP_REMOVE_FX_NAME, DROP_EDIT_FX_NAME, DROP_MIDDLE_LEFT_FX_NAME, DROP_MIDDLE_CENTER_FX_NAME, DROP_MIDDLE_RIGHT_FX_NAME};
            fxObjects = getSlideScene().getDescendants(controls);
        } else {
            controls = new String[]{DROP_REMOVE_FX_NAME, DROP_EDIT_FX_NAME, DROP_REMOVE_LABEL, DROP_EDIT_LABEL};
            fxObjects = getSlideScene().getDescendants(controls);
            labelDrops(fxObjects[2], fxObjects[3]);
        }
        Resources r = this.mFxWorkspace.getResources();
        int left = r.getDimensionPixelSize(R.dimen.remove_btn_left);
        int top = r.getDimensionPixelSize(R.dimen.remove_btn_top);
        int right = r.getDimensionPixelSize(R.dimen.remove_btn_right);
        int bottom = r.getDimensionPixelSize(R.dimen.remove_btn_bottom);
        Rect removeRect = new Rect(left, top, right, bottom);
        int overlayColor = this.mLauncher.getResources().getColor(HtcSkinUtil.getColorResIdentifier(this.mLauncher, "rosie_delete_color_filter", R.color.delete_color_filter));
        FxDropControl fxDrop = (FxDropControl) fxObjects[0];
        this.mfxDropRemove = (FxDropControl) fxObjects[0];
        this.mfxDropEdit = (FxDropControl) fxObjects[1];
        if (SettingUtil.isTabletDevice()) {
            this.mfxDropRemove.setVisibility(false);
            this.mfxDropEdit.setVisibility(false);
        }
        DropZone drop = new RemoveZone(ItemContainer.DRAG_SCOPE_REMOVE, fxDrop, new FxDropTarget(removeRect, DragSource.DragCompletedAction.REMOVE), overlayColor);
        this.mDropBar.addDrop(drop);
        int left2 = r.getDimensionPixelSize(R.dimen.edit_btn_left);
        int top2 = r.getDimensionPixelSize(R.dimen.edit_btn_top);
        int right2 = r.getDimensionPixelSize(R.dimen.edit_btn_right);
        int bottom2 = r.getDimensionPixelSize(R.dimen.edit_btn_bottom);
        Rect editRect = new Rect(left2, top2, right2, bottom2);
        int overlayColor2 = this.mLauncher.getResources().getColor(HtcSkinUtil.getColorResIdentifier(this.mLauncher, "rosie_setting_color_filter", R.color.setting_color_filter));
        FxDropControl fxDrop2 = (FxDropControl) fxObjects[1];
        DropZone drop2 = new EditZone(ItemContainer.DRAG_SCOPE_EDIT, fxDrop2, new FxDropTarget(editRect, DragSource.DragCompletedAction.SETTING), overlayColor2);
        this.mDropBar.addDrop(drop2);
        if (SettingUtil.isTabletDevice()) {
            int left3 = this.mFxWorkspace.getResources().getDimensionPixelSize(R.dimen.middle_left_btn_left);
            int top3 = this.mFxWorkspace.getResources().getDimensionPixelSize(R.dimen.middle_left_btn_top);
            int right3 = this.mFxWorkspace.getResources().getDimensionPixelSize(R.dimen.middle_left_btn_right);
            int bottom3 = this.mFxWorkspace.getResources().getDimensionPixelSize(R.dimen.middle_left_btn_bottom);
            Rect middleLeftRect = new Rect(left3, top3, right3, bottom3);
            this.mButtonBarDropControl[0] = (FxDropControl) fxObjects[2];
            DropZone drop3 = new MiddleButtonZone(ItemContainer.DRAG_SCOPE_EMPTY, this.mButtonBarDropControl[0], new FxDropTarget(middleLeftRect, DragSource.DragCompletedAction.DROP_ON_BUTTONBAR), controls[0], 0);
            this.mDropBar.addDrop(drop3);
            int left4 = this.mFxWorkspace.getResources().getDimensionPixelSize(R.dimen.middle_center_btn_left);
            int top4 = this.mFxWorkspace.getResources().getDimensionPixelSize(R.dimen.middle_center_btn_top);
            int right4 = this.mFxWorkspace.getResources().getDimensionPixelSize(R.dimen.middle_center_btn_right);
            int bottom4 = this.mFxWorkspace.getResources().getDimensionPixelSize(R.dimen.middle_center_btn_bottom);
            Rect middleCenterRect = new Rect(left4, top4, right4, bottom4);
            this.mButtonBarDropControl[1] = (FxDropControl) fxObjects[3];
            DropZone drop4 = new MiddleButtonZone(ItemContainer.DRAG_SCOPE_EMPTY, this.mButtonBarDropControl[1], new FxDropTarget(middleCenterRect, DragSource.DragCompletedAction.DROP_ON_BUTTONBAR), controls[1], 1);
            this.mDropBar.addDrop(drop4);
            int left5 = this.mFxWorkspace.getResources().getDimensionPixelSize(R.dimen.middle_right_btn_left);
            int top5 = this.mFxWorkspace.getResources().getDimensionPixelSize(R.dimen.middle_right_btn_top);
            int right5 = this.mFxWorkspace.getResources().getDimensionPixelSize(R.dimen.middle_right_btn_right);
            int bottom5 = this.mFxWorkspace.getResources().getDimensionPixelSize(R.dimen.middle_right_btn_bottom);
            Rect middleRightRect = new Rect(left5, top5, right5, bottom5);
            this.mButtonBarDropControl[2] = (FxDropControl) fxObjects[4];
            DropZone drop5 = new MiddleButtonZone(ItemContainer.DRAG_SCOPE_EMPTY, this.mButtonBarDropControl[2], new FxDropTarget(middleRightRect, DragSource.DragCompletedAction.DROP_ON_BUTTONBAR), controls[2], 2);
            this.mDropBar.addDrop(drop5);
            for (int i = 0; i < this.mButtonBarDropControl.length; i++) {
                this.mButtonBarDropMarkers[i] = this.mButtonBarDropControl[i].getMarker("Drop_empty");
            }
        }
    }

    public void setUnlockframeFlag(boolean b) {
        this.mIsUnlockFrameSet = b;
    }

    public boolean checkUnlockFrameSet() {
        return this.mIsUnlockFrameSet;
    }

    public void prepareUnlockAnimation(boolean useCache) {
        if (this.mPageSlideControl != null) {
            if (this.mIsPortrait) {
                showAllScreens();
                if (this.mDontFreezeWhenLeap) {
                    thawAllScreens();
                } else {
                    freezeAllScreens();
                }
            } else {
                freezeAllScreens();
            }
            this.mPageSlideControl.prepareAnimation();
            setUnlockframeFlag(true);
            this.mDontFreezeWhenLeap = false;
        }
    }

    public void playPhoneAnim() {
        if (this.mInComingCallControl != null) {
            this.mInComingCallControl.play();
        }
    }

    public void stopPhoneAnim() {
        if (this.mInComingCallControl != null) {
            this.mInComingCallControl.stop();
        }
    }

    private class InComingCallControl {
        public static final String IN_COMING_CALL_CONTROL = "timeline.navbtn_side_anim-Center_inc";
        private static final String IN_COMING_CALL_MARKER = "incall_loop";
        private FxTimelineControl mControl;

        public InComingCallControl() {
            this.mControl = FxWorkspaceClient.this.mFxObjects[10];
        }

        public void play() {
            if (this.mControl != null) {
                this.mControl.playMarker(IN_COMING_CALL_MARKER, 1, 1.0f, false);
            }
        }

        public void stop() {
            if (this.mControl != null) {
                this.mControl.stop();
                this.mControl.setFrame(0.0f);
            }
        }
    }

    void setEditModeListener(FxWorkspace.IEditModeListener editModeListener) {
        this.mEditModeListener = editModeListener;
    }

    void onStartDrag() {
        this.mIsEnteringEditMode = true;
        if (this.mEditModeListener != null) {
            this.mEditModeListener.onPreEnterEditMode();
        }
    }

    void onEndDrag() {
        this.mIsLeavingEditMode = true;
        if (this.mEditModeListener != null) {
            this.mEditModeListener.onPreLeaveEditMode();
        }
    }

    public int getFadeOutAnimationCompleteCount() {
        return this.mFadeOutAnimationCompleteCount;
    }

    public void resetFadeOutAnimationCompleteCount() {
        this.mFadeOutAnimationCompleteCount = 0;
    }

    public void increseFadeOutAnimationCompleteCount() {
        this.mFadeOutAnimationCompleteCount++;
    }
}
