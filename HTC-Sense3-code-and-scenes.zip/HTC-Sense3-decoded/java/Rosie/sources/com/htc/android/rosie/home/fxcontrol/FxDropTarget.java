package com.htc.android.rosie.home.fxcontrol;

import android.graphics.Canvas;
import android.graphics.Rect;
import com.htc.launcher.DragSource;
import com.htc.launcher.Draggee;
import com.htc.launcher.DropTarget;
import com.htc.launcher.ItemInfo;
import com.htc.launcher.Launcher;
import com.htc.launcher.Logger;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class FxDropTarget implements DropTarget {
    boolean acceptDrop;
    public ItemInfo item;
    public boolean mDragOver;
    public DragSource source;
    DragSource.DragCompletedAction sourceAction;
    State state;
    int x;
    int xOffset;
    int y;
    int yOffset;
    public Rect bounds = new Rect();
    private String mName = null;

    public enum State {
        DRAG_ENTER,
        DRAG_OVER,
        DRAG_EXIT,
        DROP
    }

    public FxDropTarget(Rect rect, DragSource.DragCompletedAction action) {
        this.bounds.set(rect);
        this.sourceAction = action;
        this.acceptDrop = true;
    }

    @Override // com.htc.launcher.DropTarget
    public void onDrop(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        Logger.d("FxDropTarget", "[EDIT_DEBUG] FxDropTarget.onDrop(" + this.sourceAction + ")");
        setState(source, x, y, xOffset, yOffset, dragItem.getItemInfo(), State.DROP);
        dragItem.onDrop(null, -1, -1);
        this.mDragOver = false;
    }

    @Override // com.htc.launcher.DropTarget
    public void onDragEnter(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        Logger.d("FxDropTarget", "[EDIT_DEBUG] FxDropTarget.onDragEnter(" + this.sourceAction + ")");
        setState(source, x, y, xOffset, yOffset, dragItem.getItemInfo(), State.DRAG_ENTER);
    }

    @Override // com.htc.launcher.DropTarget
    public void onDragOver(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        Logger.d("FxDropTarget", "[EDIT_DEBUG] FxDropTarget.onDragOver(" + this.sourceAction + ")");
        setState(source, x, y, xOffset, yOffset, dragItem.getItemInfo(), State.DRAG_OVER);
    }

    @Override // com.htc.launcher.DropTarget
    public void onDragExit(DragSource source, DropTarget target, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        Logger.d("FxDropTarget", "[EDIT_DEBUG] FxDropTarget.onDragExit(" + this.sourceAction + ")");
        setState(source, x, y, xOffset, yOffset, dragItem.getItemInfo(), State.DRAG_EXIT);
    }

    @Override // com.htc.launcher.DropTarget
    public boolean acceptDrop(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem) {
        Logger.d("FxDropTarget", "[EDIT_DEBUG] FxDropTarget.acceptDrop(" + this.sourceAction + ")");
        if (this.sourceAction == DragSource.DragCompletedAction.REMOVE) {
            return true;
        }
        if (this.sourceAction == DragSource.DragCompletedAction.SETTING || this.sourceAction == DragSource.DragCompletedAction.FOLDERICON) {
            return this.acceptDrop;
        }
        if (this.sourceAction != DragSource.DragCompletedAction.DROP_ON_BUTTONBAR || (dragItem.getItemInfo().itemType != 0 && dragItem.getItemInfo().itemType != 1)) {
            return false;
        }
        Launcher launcher = Launcher.sRefLauncher.get();
        int tmp = launcher.getFxWorkspace().mButtonBarHandler.getButtonBarLongClickX(getLeft(), getTop());
        return launcher.getFxWorkspace().mButtonBarHandler.getIsButtonBarNull(tmp);
    }

    private void setState(DragSource source, int x, int y, int xOffset, int yOffset, ItemInfo dragInfo, State state) {
        this.source = source;
        this.x = x;
        this.y = y;
        this.xOffset = xOffset;
        this.yOffset = yOffset;
        this.item = dragInfo;
        this.state = state;
    }

    @Override // com.htc.launcher.DropTarget
    public Rect estimateDropLocation(DragSource source, int x, int y, int xOffset, int yOffset, Draggee dragItem, Rect recycle) {
        return null;
    }

    @Override // com.htc.launcher.DropTarget
    public void getHitRect(Rect outRect) {
        outRect.set(this.bounds);
    }

    @Override // com.htc.launcher.DropTarget
    public void getLocationOnScreen(int[] loc) {
        loc[0] = this.bounds.left;
        loc[1] = this.bounds.top;
    }

    @Override // com.htc.launcher.DropTarget
    public int getLeft() {
        return this.bounds.left;
    }

    @Override // com.htc.launcher.DropTarget
    public int getTop() {
        return this.bounds.top;
    }

    @Override // com.htc.launcher.DropTarget
    public boolean claimDrop(int x, int y, int[] coordinates) {
        if (!this.mDragOver) {
            return false;
        }
        coordinates[0] = this.bounds.width() / 2;
        coordinates[1] = this.bounds.height() / 2;
        return true;
    }

    public void resetClaimDrop() {
        Logger.d("FxDropTarget", "[EDIT_DEBUG] FxDropTarget.resetClaimDrop() DragOver:" + this.mDragOver);
        this.mDragOver = false;
    }

    @Override // com.htc.launcher.DropTarget
    public DragSource.DragCompletedAction getDragCompletedAction() {
        return this.sourceAction;
    }

    public void froceUpdateRemote(Canvas canvas) {
    }
}
