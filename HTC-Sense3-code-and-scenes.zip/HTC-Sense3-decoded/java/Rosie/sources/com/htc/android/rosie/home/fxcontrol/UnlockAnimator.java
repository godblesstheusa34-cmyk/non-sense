package com.htc.android.rosie.home.fxcontrol;

import android.util.Log;
import com.htc.android.rosie.home.fxcontrol.FxWorkspace;
import com.htc.fusion.fx.FxPlaybackInfo;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.Marker;
import com.htc.launcher.R;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class UnlockAnimator implements FxWorkspace.IUnlockAnimator {
    private static final int ANIMATION_DELAY_FRAMES = 0;
    private static final boolean IS_NEED_UNLOCK_ANIMATION = true;
    private static final String LOG_TAG = "UnlockAnimator";
    private List<String> mAnimationMarkerNames;
    private FxWorkspace mFxWorkspace;
    private FxTimelineControl mPageSlideControl;

    public UnlockAnimator(FxWorkspace fxWorkspace, FxTimelineControl pageSlideControl) {
        this.mAnimationMarkerNames = null;
        this.mFxWorkspace = null;
        this.mPageSlideControl = null;
        this.mFxWorkspace = fxWorkspace;
        this.mPageSlideControl = pageSlideControl;
        this.mAnimationMarkerNames = new ArrayList(Arrays.asList(this.mFxWorkspace.getContext().getResources().getStringArray(R.array.unlock_spin_markers)));
    }

    @Override // com.htc.android.rosie.home.fxcontrol.FxWorkspace.IUnlockAnimator
    public void startAnimation() {
        int currentScreen;
        if (this.mFxWorkspace != null && this.mAnimationMarkerNames != null && (currentScreen = this.mFxWorkspace.getCurrentScreen()) >= 0 && currentScreen < this.mAnimationMarkerNames.size()) {
            String name = this.mAnimationMarkerNames.get(currentScreen);
            if (this.mPageSlideControl != null) {
                Marker m = this.mPageSlideControl.getMarker(name);
                if (m != null) {
                    Log.d(LOG_TAG, "playMarker: " + name);
                    this.mPageSlideControl.playMarker(name, 0, 1.0f, true, 0);
                } else {
                    Log.w(LOG_TAG, " marker not found " + name);
                }
            }
        }
    }

    @Override // com.htc.android.rosie.home.fxcontrol.FxWorkspace.IUnlockAnimator
    public void stopAnimation() {
    }

    @Override // com.htc.android.rosie.home.fxcontrol.FxWorkspace.IUnlockAnimator
    public boolean isUnlockAnimation(FxPlaybackInfo fxPlaybackInfo) {
        if (this.mAnimationMarkerNames == null || fxPlaybackInfo == null) {
            return false;
        }
        return this.mAnimationMarkerNames.contains(fxPlaybackInfo.name);
    }

    @Override // com.htc.android.rosie.home.fxcontrol.FxWorkspace.IUnlockAnimator
    public void prepareAnimation() {
        int currentScreen;
        if (this.mFxWorkspace != null && this.mAnimationMarkerNames != null && (currentScreen = this.mFxWorkspace.getCurrentScreen()) >= 0 && currentScreen < this.mAnimationMarkerNames.size()) {
            String name = this.mAnimationMarkerNames.get(currentScreen);
            if (this.mPageSlideControl != null) {
                Marker m = this.mPageSlideControl.getMarker(name);
                if (m != null) {
                    Log.d(LOG_TAG, "setFrame: " + name);
                    this.mPageSlideControl.setFrame(m.StartFrame);
                } else {
                    Log.w(LOG_TAG, " marker not found " + name);
                }
            }
        }
    }
}
