package com.htc.android.rosie.home.fxcontrol;

import android.graphics.drawable.Drawable;
import com.htc.android.rosie.home.fxcontrol.FxPathFinder;
import com.htc.fusion.fx.FxDraggable;
import com.htc.fusion.fx.FxScene;
import com.htc.fusion.fx.MessageListener;
import com.htc.fusion.fx.controls.FxButton;
import com.htc.fusion.fx.controls.FxDropControl;
import com.htc.fusion.fx.controls.FxDynamicImage;
import com.htc.fusion.fx.controls.FxTextLabel;
import com.htc.launcher.DragSource;
import com.htc.launcher.Draggee;
import com.htc.launcher.DropTarget;
import com.htc.launcher.FxItem;
import com.htc.launcher.FxShortcutInfo;
import com.htc.launcher.ItemInfo;
import com.htc.launcher.Logger;
import com.htc.launcher.PendingUIUpdate;
import java.lang.ref.WeakReference;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class FxShortcutButton extends FxItem implements FxShortcutInfo.Observer {
    private static final String[] CONTROLS_FX_NAMES = {"dy.shortcut", "textlabel.Shortcut", "button.shortcut", "drop.folder"};
    private static final String SCENE_FX_NAME = "Rosie_shortcut.m10";
    private FxButton mButton;
    private FxButton mButtonLand;
    private FxListener mClickListenerLand;
    private FxListener mClickListenerPort;
    private FxDropControl mFxDrop;
    private FxDropControl mFxDropLand;
    private FxDynamicImage mIcon;
    private FxDynamicImage mIconLand;
    private FxTextLabel mLabel;
    private FxTextLabel mLabelLand;
    private MessageListener<FxDraggable> mOnDropActivateListener;
    private MessageListener<FxDraggable> mOnDropListener;
    private MessageListener<FxDraggable> mOnDropOutListener;
    private MessageListener<FxDraggable> mOnDropOverListener;
    private int mOrientation;

    public interface OnClickListener {
        void onClick(FxItem fxItem);
    }

    public FxShortcutButton(ItemInfo info, int orientation) {
        super((FxScene) null, info);
        this.mOnDropActivateListener = null;
        this.mOnDropListener = null;
        this.mOnDropOverListener = null;
        this.mOnDropOutListener = null;
        this.mClickListenerPort = new FxListener("Port");
        this.mClickListenerLand = new FxListener("Land");
        this.mOrientation = 1;
        updateOrientation(orientation);
        loadShortcutScene(info);
    }

    private FxScene loadShortcutScene(ItemInfo info) {
        FxScene scene = FxScene.create(FxPathFinder.Path.PORTRAIT.get() + SCENE_FX_NAME, true);
        FxDropControl[] descendants = scene.getDescendants(CONTROLS_FX_NAMES);
        this.mIcon = (FxDynamicImage) descendants[0];
        this.mLabel = (FxTextLabel) descendants[1];
        this.mButton = (FxButton) descendants[2];
        this.mFxDrop = descendants[3];
        if (this.mButton != null) {
            this.mButton.bindClick(this.mClickListenerPort);
        }
        FxScene sceneLand = FxScene.create(FxPathFinder.Path.LANDSCAPE.get() + SCENE_FX_NAME, true);
        if (sceneLand != null) {
            FxDropControl[] descendants2 = sceneLand.getDescendants(CONTROLS_FX_NAMES);
            this.mIconLand = (FxDynamicImage) descendants2[0];
            this.mLabelLand = (FxTextLabel) descendants2[1];
            this.mButtonLand = (FxButton) descendants2[2];
            this.mFxDropLand = descendants2[3];
            if (this.mButtonLand != null) {
                this.mButtonLand.bindClick(this.mClickListenerLand);
            }
        }
        setScene(scene);
        setOtherScene(sceneLand);
        return scene;
    }

    public FxDropControl getFxDropControl() {
        return this.mFxDrop;
    }

    public FxDropControl getFxDropControlLand() {
        return this.mFxDropLand;
    }

    void enableDropControl() {
        if (this.mFxDrop != null) {
            this.mFxDrop.setEnabled(true);
        }
        if (this.mFxDropLand != null) {
            this.mFxDropLand.setEnabled(true);
        }
    }

    void disableDropControl() {
        if (this.mFxDrop != null) {
            this.mFxDrop.setEnabled(false);
        }
        if (this.mFxDropLand != null) {
            this.mFxDropLand.setEnabled(false);
        }
    }

    public void bindDropEventListener() {
        bindDropActivateListener();
        bindDropListener();
        bindDropOverListener();
        bindDropOutListener();
    }

    private void bindDropActivateListener() {
        if (this.mOnDropActivateListener != null) {
            this.mFxDrop.getDropActivateSource().bind(this.mOnDropActivateListener);
        } else {
            this.mOnDropActivateListener = new MessageListener<FxDraggable>() { // from class: com.htc.android.rosie.home.fxcontrol.FxShortcutButton.1
                public void onMessageReceived(FxDraggable drag) {
                    Logger.d(Draggee.LOG_TAG, "[EDIT_DEBUG] FxShortcutButton - Activate");
                }
            };
            this.mFxDrop.getDropActivateSource().bind(this.mOnDropActivateListener);
        }
    }

    private void bindDropListener() {
        if (this.mOnDropListener != null) {
            this.mFxDrop.getDropSource().bind(this.mOnDropListener);
        } else {
            this.mOnDropListener = new MessageListener<FxDraggable>() { // from class: com.htc.android.rosie.home.fxcontrol.FxShortcutButton.2
                public void onMessageReceived(FxDraggable drag) {
                    Logger.d(Draggee.LOG_TAG, "[EDIT_DEBUG] FxShortcutButton - Drop");
                }
            };
            this.mFxDrop.getDropSource().bind(this.mOnDropListener);
        }
    }

    private void bindDropOverListener() {
        if (this.mOnDropOverListener != null) {
            this.mFxDrop.getDropOverSource().bind(this.mOnDropOverListener);
        } else {
            this.mOnDropOverListener = new MessageListener<FxDraggable>() { // from class: com.htc.android.rosie.home.fxcontrol.FxShortcutButton.3
                public void onMessageReceived(FxDraggable drag) {
                    Logger.d(Draggee.LOG_TAG, "[EDIT_DEBUG] FxShortcutButton - DropOver");
                }
            };
            this.mFxDrop.getDropOverSource().bind(this.mOnDropOverListener);
        }
    }

    private void bindDropOutListener() {
        if (this.mOnDropOutListener != null) {
            this.mFxDrop.getDropOutSource().bind(this.mOnDropOutListener);
        } else {
            this.mOnDropOutListener = new MessageListener<FxDraggable>() { // from class: com.htc.android.rosie.home.fxcontrol.FxShortcutButton.4
                public void onMessageReceived(FxDraggable drag) {
                    Logger.d(Draggee.LOG_TAG, "[EDIT_DEBUG] FxShortcutButton - DropOut");
                }
            };
            this.mFxDrop.getDropOutSource().bind(this.mOnDropOutListener);
        }
    }

    public void setContents(Drawable icon, CharSequence label) {
        if (icon != null) {
            this.mIcon.setImage(icon);
            if (this.mIconLand != null) {
                this.mIconLand.setImage(icon);
            }
        }
        if (label != null) {
            this.mLabel.setContent(label);
            if (this.mLabelLand != null) {
                this.mLabelLand.setContent(label);
            }
        }
    }

    public void setTitle(CharSequence title) {
        if (title != null) {
            this.mLabel.setContent(title);
            if (this.mLabelLand != null) {
                this.mLabelLand.setContent(title);
            }
        }
    }

    public void setIcon(Drawable icon) {
        if (icon != null) {
            this.mIcon.setImage(icon);
            if (this.mIconLand != null) {
                this.mIconLand.setImage(icon);
            }
        }
    }

    public void setOnClickListener(OnClickListener listener) {
        Logger.d("FxShortcutButton", "[SHORTCUT_DEBUG] setOnClickListener(" + listener + ")");
        this.mClickListenerPort.setOnClickListener(listener);
        this.mClickListenerLand.setOnClickListener(listener);
    }

    private final class FxListener extends MessageListener<Void> {
        private OnClickListener mListener;
        private String mTag;

        public FxListener(String tag) {
            this.mTag = null;
            this.mTag = tag;
        }

        public void onMessageReceived(Void v) {
            Logger.d("FxShortcutButton", "[SHORTCUT_DEBUG] " + this.mTag + ".onClick() ItemInfo:" + FxShortcutButton.this.getInfo() + ", mListener:" + this.mListener);
            if (this.mListener != null) {
                this.mListener.onClick(FxShortcutButton.this);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setOnClickListener(OnClickListener listener) {
            this.mListener = listener;
        }
    }

    @Override // com.htc.launcher.FxShortcutInfo.Observer
    public void onIconUpdate(int id, Drawable icon, CharSequence title) {
        Logger.d("FxShortcutButton", "ITEM - [SHORTCUT] UPDATE - onIconUpdate(" + id + ")");
        PendingUIUpdate.instance().postPending(id, new IconUpdateRunnable(this, title, icon));
    }

    private static class IconUpdateRunnable implements Runnable {
        private WeakReference<Drawable> mRefIcon;
        private WeakReference<FxShortcutButton> mRefView;
        private CharSequence mTitle;

        public IconUpdateRunnable(FxShortcutButton button, CharSequence title, Drawable icon) {
            this.mRefView = new WeakReference<>(button);
            this.mTitle = title;
            this.mRefIcon = new WeakReference<>(icon);
        }

        @Override // java.lang.Runnable
        public void run() {
            FxShortcutButton view = this.mRefView.get();
            Logger.d("FxShortcutButton", "[SHORTCUT] UPDATE - IconUpdateRunnable.run(" + view + ",Title(" + ((Object) this.mTitle) + ")");
            if (view != null) {
                if (this.mRefIcon.get() != null) {
                    view.setIcon(this.mRefIcon.get());
                } else {
                    Logger.e(FxShortcutButton.class.getSimpleName(), "The shortcut icon(" + ((Object) this.mTitle) + ") is GC.");
                }
                if (this.mTitle != null) {
                    view.setTitle(this.mTitle);
                }
            }
        }
    }

    @Override // com.htc.launcher.FxItem, com.htc.launcher.Draggee
    public void onDrop(DropTarget target, int cellX, int cellY) {
        Logger.d("FxShortcutButton", "[EDIT_DEBUG] FxShortcutButton.onDrop()");
        super.onDrop(target, cellX, cellY);
        super.onBeforeDrag();
        setButtonEnable(true);
    }

    @Override // com.htc.launcher.FxItem, com.htc.launcher.Draggee
    public void onDrag() {
        Logger.d("FxShortcutButton", "[EDIT_DEBUG] FxShortcutButton.onDrag()");
        super.onDrag();
        super.onBeforeDrag();
        setButtonEnable(false);
    }

    @Override // com.htc.launcher.FxItem, com.htc.launcher.Draggee
    public void onDropAbort(DragSource source) {
        Logger.d("FxShortcutButton", "[EDIT_DEBUG] FxShortcutButton.onDropAbort()");
        super.onDropAbort(source);
        setButtonEnable(true);
    }

    @Override // com.htc.launcher.FxItem
    public void onBeforeDrag() {
        Logger.d("FxShortcutButton", "[EDIT_DEBUG] FxShortcutButton.onBeforeDrag()");
        super.onBeforeDrag();
        setButtonEnable(false);
    }

    private void setButtonEnable(boolean enable) {
        if (this.mButton != null) {
            this.mButton.setEnabled(enable);
        }
        if (this.mButtonLand != null) {
            this.mButtonLand.setEnabled(enable);
        }
    }

    @Override // com.htc.launcher.FxItem
    public FxScene getScene() {
        Logger.d("FxShortcutButton", "[EDIT_DEBUG] FxShortcutButton.getScene() mOrientation:" + this.mOrientation);
        return this.mOrientation == 1 ? super.getScene() : super.getOtherScene();
    }

    public void updateOrientation(int orientation) {
        Logger.d("FxShortcutButton", "[EDIT_DEBUG] FxShortcutButton.updateOritation(orientation:" + orientation + ")");
        this.mOrientation = orientation;
    }
}
