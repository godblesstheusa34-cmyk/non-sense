package com.htc.android.rosie.home.fxcontrol;

import android.util.Log;
import com.htc.android.rosie.home.fxcontrol.FxWorkspace;
import com.htc.android.rosie.home.fxcontrol.PageSlideControl;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.Marker;
import com.htc.launcher.settings.SettingUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class PageSlideAnimator extends SlideAnimator {
    private static final String LOG_TAG = "PageSlideAnimator";

    public PageSlideAnimator(FxWorkspace fxWorkspace, FxTimelineControl slideControl, int screenCount) {
        super(fxWorkspace, slideControl, screenCount);
    }

    @Override // com.htc.android.rosie.home.fxcontrol.SlideAnimator
    protected void initMarkers(int screenCount) {
        this.mTranslationMarkers[0] = this.mSlideControl.getMarker("0toE_back");
        this.mTranslationMarkers[1] = this.mSlideControl.getMarker("0to1");
        this.mTranslationMarkers[2] = this.mSlideControl.getMarker("1to2");
        this.mTranslationMarkers[3] = this.mSlideControl.getMarker("2to3");
        this.mTranslationMarkers[4] = this.mSlideControl.getMarker("3to4");
        this.mTranslationMarkers[5] = this.mSlideControl.getMarker("4to5");
        this.mTranslationMarkers[6] = this.mSlideControl.getMarker("5to6");
        this.mTranslationMarkers[7] = this.mSlideControl.getMarker("6toE_forward");
    }

    @Override // com.htc.android.rosie.home.fxcontrol.SlideAnimator
    public float scrollXToFrame(float scrollX, int screenWidth, PageSlideControl.Direction direction, FxWorkspace.SnapInfo snapInfo) {
        int currentScreen = ((int) Math.floor(scrollX / screenWidth)) + 1;
        float shiftX = scrollX;
        while (shiftX >= screenWidth) {
            shiftX -= screenWidth;
        }
        if (SettingUtil.localLOGD) {
            Log.d(LOG_TAG, "scrollXToFrame(" + scrollX + ", " + screenWidth + ", " + direction + ", " + snapInfo.isSnap + "), currentScreen = " + currentScreen + ", shiftX = " + shiftX);
        }
        Marker marker = this.mTranslationMarkers[currentScreen];
        if (!snapInfo.isSnap) {
            this.mFxWorkspace.setPanFrame(shiftX / screenWidth);
        } else {
            this.mFxWorkspace.setPageSlideZFrame(snapInfo.begin, snapInfo.end, screenWidth, (int) scrollX);
        }
        return (((marker.EndFrame - marker.StartFrame) * shiftX) / screenWidth) + marker.StartFrame;
    }
}
