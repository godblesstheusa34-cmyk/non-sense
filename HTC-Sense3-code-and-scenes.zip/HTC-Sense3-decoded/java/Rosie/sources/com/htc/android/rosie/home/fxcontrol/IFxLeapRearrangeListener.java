package com.htc.android.rosie.home.fxcontrol;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public interface IFxLeapRearrangeListener {
    void onLeapRearrangeDrag(int i);

    void onLeapRearrangeDragDrop();

    void onLeapRearrangeDragDropCancel();

    void onLeapRearrangeDragEnd();

    void onLeapRearrangeDrop(int i);

    void onMoveAnimationEnd();
}
