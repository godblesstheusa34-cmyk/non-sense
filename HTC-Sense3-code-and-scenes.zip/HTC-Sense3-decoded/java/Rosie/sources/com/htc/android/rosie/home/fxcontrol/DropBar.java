package com.htc.android.rosie.home.fxcontrol;

import android.os.Handler;
import com.android.common.speech.LoggingEvents;
import com.htc.launcher.DragSource;
import com.htc.launcher.Draggee;
import com.htc.launcher.Logger;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class DropBar {
    private static final String LOG_TAG = DropBar.class.getSimpleName();
    private Handler mHandler = new Handler();
    Map<String, DropZone> mZones = new HashMap();

    public Handler getDropHandler() {
        return this.mHandler;
    }

    public void addDrop(DropZone drop) {
        this.mZones.put(drop.getScopeKey(), drop);
        DropEventListener l = new DropEventListener(this.mHandler, drop);
        drop.bindListener(l);
    }

    public void addDrop(DropZone drop, DropEventListener dropEventListener) {
        Logger.d(LoggingEvents.EXTRA_CALLING_APP_NAME, "DropBar.addDrop(" + drop.getScopeKey() + LoggingEvents.EXTRA_CALLING_APP_NAME);
        this.mZones.put(drop.getScopeKey(), drop);
        drop.bindListener(dropEventListener);
    }

    void enableDropByScope(String scope, boolean enable) {
        Logger.d("EditZone", "[EDIT_DEBUG] DropBar.enableDropByScope(" + enable + ")");
        DropZone drop = this.mZones.get(scope);
        if (drop != null) {
            drop.setEnabled(enable);
        }
    }

    Collection<DropZone> getDropZones() {
        return this.mZones.values();
    }

    void removeAllDrops() {
        for (DropZone drop : this.mZones.values()) {
            drop.destroy();
        }
        this.mZones.clear();
    }

    public void onDragStart(Draggee draggee, DragSource source, Object info, int dragAction) {
        Collection<DropZone> zones = this.mZones.values();
        int count = 0;
        for (DropZone z : zones) {
            boolean enable = z.accept(draggee);
            Logger.d("DropBar", "[EDIT_DEBUG] onDragStart(" + count + ") DropZone.accept:" + enable + ", DropZone=" + z);
            z.setEnabled(enable);
            count++;
        }
    }
}
