package com.htc.android.rosie.home.fxcontrol;

import android.util.Log;
import com.htc.fusion.fx.FxPlaybackInfo;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.Marker;
import com.htc.fusion.fx.MessageListener;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
final class TimelineAnimation {
    private static final String LOG_TAG = TimelineAnimation.class.getSimpleName();
    private MessageListener<FxPlaybackInfo> mAnimListener;
    private OnCompleteListener mCompleteListener;
    private final float mDuration;
    private final float mEndFrame;
    private float mFrame;
    private int mPlaybackMode;
    private float mSpeed;
    private final float mStartFrame;
    private final FxTimelineControl mTimeline;

    public interface OnCompleteListener {
        void onCompleted(TimelineAnimation timelineAnimation);
    }

    public TimelineAnimation(FxTimelineControl timeline, float start, float end) {
        this.mSpeed = 1.0f;
        this.mPlaybackMode = 0;
        this.mTimeline = timeline;
        this.mStartFrame = start;
        this.mEndFrame = end;
        this.mDuration = end - start;
    }

    public TimelineAnimation(FxTimelineControl timeline, Marker marker) {
        this(timeline, marker.StartFrame, marker.EndFrame);
    }

    public TimelineAnimation(FxTimelineControl timeline, Marker start, Marker end) {
        this(timeline, start.StartFrame, end.StartFrame);
    }

    public Marker getMarker(String name) {
        return this.mTimeline.getMarker(name);
    }

    public float getDuration() {
        return this.mDuration;
    }

    public void setPlaybackMode(int mode) {
        this.mPlaybackMode = mode;
    }

    public int getPlaybackMode() {
        return this.mPlaybackMode;
    }

    public void setSpeed(float speed) {
        this.mSpeed = speed;
    }

    public float getSpeed() {
        return this.mSpeed;
    }

    public void setComplateListener(OnCompleteListener l) {
        this.mCompleteListener = l;
        if (this.mCompleteListener != null && this.mAnimListener == null) {
            this.mAnimListener = new MessageListener<FxPlaybackInfo>() { // from class: com.htc.android.rosie.home.fxcontrol.TimelineAnimation.1
                public void onMessageReceived(FxPlaybackInfo info) {
                    if (TimelineAnimation.this.mCompleteListener != null) {
                        TimelineAnimation.this.mCompleteListener.onCompleted(TimelineAnimation.this);
                    }
                }
            };
            this.mTimeline.getPlaybackCompleteSource().bind(this.mAnimListener);
        }
    }

    public float getCurrentFrame() {
        return this.mTimeline.getFrame();
    }

    public void play() {
        play((int) this.mStartFrame, (int) this.mEndFrame);
    }

    public void play(int from, int to) {
        Log.d("DEBUG", "TimelineAnimation.play(" + from + ", " + to + ")");
        this.mTimeline.playFrames(from, to, this.mPlaybackMode, this.mSpeed, this.mCompleteListener != null);
    }

    public void playTo(int frame) {
        this.mTimeline.playFrames((int) this.mFrame, frame, this.mPlaybackMode, this.mSpeed, this.mCompleteListener != null);
    }

    public void setFrame(float frame) {
        this.mFrame = frame;
        this.mTimeline.setFrame(frame);
    }

    public void stop() {
        this.mTimeline.stop();
    }

    public void rewind() {
        this.mTimeline.setFrame(this.mStartFrame);
    }
}
