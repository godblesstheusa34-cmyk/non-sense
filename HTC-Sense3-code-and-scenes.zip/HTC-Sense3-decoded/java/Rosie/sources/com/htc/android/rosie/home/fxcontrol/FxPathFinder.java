package com.htc.android.rosie.home.fxcontrol;

import android.view.Display;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class FxPathFinder {
    private static final String LANDSCAPE_PATH = "land/scenes/";
    private static final String PORTRAIT_PATH = "port/scenes/";
    private Display mDisplay;

    public static FxPathFinder getInstance(Display display) {
        return new FxPathFinder(display);
    }

    private FxPathFinder(Display display) {
        this.mDisplay = display;
    }

    public Path getPath() {
        int w = this.mDisplay.getWidth();
        int h = this.mDisplay.getHeight();
        return w <= h ? Path.PORTRAIT : Path.LANDSCAPE;
    }

    public Path getPath(int rotation) {
        switch (rotation) {
            case 1:
                return Path.ROTATION_90;
            case 2:
                return Path.ROTATION_180;
            case 3:
                return Path.ROTATION_270;
            default:
                return Path.ROTATION_0;
        }
    }

    public enum Path {
        PORTRAIT(FxPathFinder.PORTRAIT_PATH),
        LANDSCAPE(FxPathFinder.LANDSCAPE_PATH),
        ROTATION_0(FxPathFinder.PORTRAIT_PATH),
        ROTATION_90(FxPathFinder.LANDSCAPE_PATH),
        ROTATION_180(FxPathFinder.PORTRAIT_PATH),
        ROTATION_270(FxPathFinder.LANDSCAPE_PATH);

        private String mPath;

        Path(String path) {
            this.mPath = path;
        }

        public String get() {
            return this.mPath;
        }
    }
}
