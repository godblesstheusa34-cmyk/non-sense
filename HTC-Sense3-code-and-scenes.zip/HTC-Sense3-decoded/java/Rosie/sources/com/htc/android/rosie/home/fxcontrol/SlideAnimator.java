package com.htc.android.rosie.home.fxcontrol;

import com.htc.android.rosie.home.fxcontrol.FxWorkspace;
import com.htc.android.rosie.home.fxcontrol.PageSlideControl;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.Marker;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public abstract class SlideAnimator {
    protected FxWorkspace mFxWorkspace;
    protected FxTimelineControl mSlideControl;
    protected Marker[] mTranslationMarkers;

    protected abstract void initMarkers(int i);

    public abstract float scrollXToFrame(float f, int i, PageSlideControl.Direction direction, FxWorkspace.SnapInfo snapInfo);

    public SlideAnimator(FxWorkspace fxWorkspace, FxTimelineControl slideControl, int screenCount) {
        this.mTranslationMarkers = new Marker[screenCount + 1];
        this.mSlideControl = slideControl;
        this.mFxWorkspace = fxWorkspace;
        initMarkers(screenCount);
    }

    public float getInitialFrame(int defaultScreenIndex) {
        return this.mTranslationMarkers[defaultScreenIndex].EndFrame;
    }
}
