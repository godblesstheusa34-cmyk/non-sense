package com.htc.android.rosie.home.fxcontrol;

import android.util.Log;
import android.view.Display;
import com.htc.fusion.fx.FxScene;
import com.htc.launcher.settings.SettingUtil;
import java.util.HashMap;
import java.util.Map;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class FxSceneManager {
    private static final String LANDSCAPE_PATH = "land/scenes/";
    private static final String PORTRAIT_PATH = "port/scenes/";
    private Display mDisplay;
    private static final String LOG_TAG = FxSceneManager.class.getSimpleName();
    private static final boolean localLOGD = SettingUtil.localLOGD;
    private Map<String, FxScene> mPortScenes = new HashMap();
    private Map<String, FxScene> mLandScenes = new HashMap();
    private Map<String, Map<Integer, FxScene>> mPortScenesWithID = new HashMap();
    private Map<String, Map<Integer, FxScene>> mLandScenesWithID = new HashMap();

    public static FxSceneManager getInstance(Display display) {
        return new FxSceneManager(display);
    }

    private FxSceneManager(Display display) {
        this.mDisplay = display;
    }

    public FxScene getFxScene(String path) {
        return (!SettingUtil.isTabletDevice() || isPortrait()) ? getPotraitFxScene(path) : getLandscapeFxScene(path);
    }

    public FxScene getFxScene(String path, boolean isPortrait) {
        return isPortrait ? getPotraitFxScene(path) : getLandscapeFxScene(path);
    }

    private FxScene getPotraitFxScene(String path) {
        FxScene scene = this.mPortScenes.get(path);
        if (scene == null) {
            createFxScene(path);
            return this.mPortScenes.get(path);
        }
        return scene;
    }

    private FxScene getLandscapeFxScene(String path) {
        FxScene scene = this.mLandScenes.get(path);
        if (scene == null) {
            createFxScene(path);
            return this.mLandScenes.get(path);
        }
        return scene;
    }

    public void deleteFxScene(String path) {
        if (isPortrait()) {
            if (this.mPortScenes.remove(path) != null || !localLOGD) {
                return;
            }
            Log.e(LOG_TAG, "FxScene not found: " + path);
            return;
        }
        if (this.mLandScenes.remove(path) != null || !localLOGD) {
            return;
        }
        Log.e(LOG_TAG, "FxScene not found: " + path);
    }

    public FxScene getFxScene(String path, int id, boolean isPortrait) {
        getFxScene(path, id);
        return isPortrait ? getPotraitFxScene(path, id) : getLandscapeFxScene(path, id);
    }

    private FxScene getPotraitFxScene(String path, int id) {
        Map<Integer, FxScene> scenes = this.mPortScenesWithID.get(path);
        if (scenes == null) {
            createFxScene(path, id);
            scenes = this.mPortScenesWithID.get(path);
        }
        FxScene scene = scenes.get(Integer.valueOf(id));
        if (scene == null) {
            addFxScene(path, id);
            return scenes.get(Integer.valueOf(id));
        }
        return scene;
    }

    private FxScene getLandscapeFxScene(String path, int id) {
        Map<Integer, FxScene> scenes = this.mLandScenesWithID.get(path);
        if (scenes == null) {
            createFxScene(path, id);
            scenes = this.mLandScenesWithID.get(path);
        }
        FxScene scene = scenes.get(Integer.valueOf(id));
        if (scene == null) {
            addFxScene(path, id);
            return scenes.get(Integer.valueOf(id));
        }
        return scene;
    }

    public FxScene getFxScene(String path, int id) {
        boolean isPortrait;
        FxScene scene;
        if (SettingUtil.isTabletDevice() && !isPortrait()) {
            isPortrait = false;
            scene = getLandscapeFxScene(path, id);
        } else {
            isPortrait = true;
            scene = getPotraitFxScene(path, id);
        }
        if (scene == null) {
            if (localLOGD) {
                Log.d(LOG_TAG, "getFxScene return null" + id);
            }
        } else if (localLOGD) {
            Log.d(LOG_TAG, "getFxScene return " + (isPortrait ? "port " : "land ") + path + " " + id + " / " + scene);
        }
        return scene;
    }

    public void deleteFxScene(String path, int id, boolean isPortrait) {
        if (isPortrait) {
            deletePortraitFxScene(path, id);
        } else {
            deleteLandscapeFxScene(path, id);
        }
    }

    private void deletePortraitFxScene(String path, int id) {
        synchronized (this.mPortScenesWithID) {
            Map<Integer, FxScene> scenes = this.mPortScenesWithID.get(path);
            if (scenes == null) {
                if (localLOGD) {
                    Log.e(LOG_TAG, "FxScene not found: " + path + " / " + id);
                }
            } else {
                if (scenes.remove(new Integer(id)) == null && localLOGD) {
                    Log.e(LOG_TAG, "FxScene not found: " + path + " / " + id);
                }
            }
        }
    }

    private void deleteLandscapeFxScene(String path, int id) {
        synchronized (this.mLandScenesWithID) {
            Map<Integer, FxScene> scenes = this.mLandScenesWithID.get(path);
            if (scenes == null) {
                if (localLOGD) {
                    Log.e(LOG_TAG, "FxScene not found: " + path + " / " + id);
                }
            } else {
                if (scenes.remove(new Integer(id)) == null && localLOGD) {
                    Log.e(LOG_TAG, "FxScene not found: " + path + " / " + id);
                }
            }
        }
    }

    public void deleteFxScene(String path, int id) {
        if (isPortrait()) {
            deletePortraitFxScene(path, id);
        } else {
            deleteLandscapeFxScene(path, id);
        }
    }

    private void createFxScene(String path) {
        FxScene scene = FxScene.create(PORTRAIT_PATH + path, true);
        if (localLOGD) {
            Log.d(LOG_TAG, "createFxScene port/scenes/" + path + " -> " + scene);
        }
        this.mPortScenes.put(path, scene);
        if (SettingUtil.isTabletDevice()) {
            FxScene scene2 = FxScene.create(LANDSCAPE_PATH + path, true);
            if (localLOGD) {
                Log.d(LOG_TAG, "createFxScene land/scenes/" + path + " -> " + scene2);
            }
            this.mLandScenes.put(path, scene2);
        }
    }

    private void createFxScene(String path, int id) {
        if (localLOGD) {
            Log.d(LOG_TAG, "createFxScene " + path + " / " + id);
        }
        Map<Integer, FxScene> scenes = new HashMap<>();
        FxScene scene = FxScene.create(PORTRAIT_PATH + path, true);
        scenes.put(Integer.valueOf(id), scene);
        this.mPortScenesWithID.put(path, scenes);
        if (SettingUtil.isTabletDevice()) {
            Map<Integer, FxScene> scenes2 = new HashMap<>();
            FxScene scene2 = FxScene.create(LANDSCAPE_PATH + path, true);
            scenes2.put(Integer.valueOf(id), scene2);
            this.mLandScenesWithID.put(path, scenes2);
        }
    }

    private void addFxScene(String path, int id) {
        if (localLOGD) {
            Log.d(LOG_TAG, "addFxScene " + path + " / " + id);
        }
        Map<Integer, FxScene> scenes = this.mPortScenesWithID.get(path);
        FxScene scene = FxScene.create(PORTRAIT_PATH + path, true);
        scenes.put(Integer.valueOf(id), scene);
        if (SettingUtil.isTabletDevice()) {
            Map<Integer, FxScene> scenes2 = this.mLandScenesWithID.get(path);
            FxScene scene2 = FxScene.create(LANDSCAPE_PATH + path, true);
            scenes2.put(Integer.valueOf(id), scene2);
        }
    }

    private boolean isPortrait() {
        boolean isPortrait = FxWorkspace.isPortrait();
        if (localLOGD) {
            Log.d(LOG_TAG, "isPortrait " + (isPortrait ? "portrait" : "landscape"));
        }
        return isPortrait;
    }
}
