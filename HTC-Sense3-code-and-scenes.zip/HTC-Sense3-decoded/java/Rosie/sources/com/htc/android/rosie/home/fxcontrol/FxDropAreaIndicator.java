package com.htc.android.rosie.home.fxcontrol;

import android.content.Context;
import com.htc.fusion.fx.FxObject;
import com.htc.fusion.fx.FxScene;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.Marker;
import com.htc.fusion.fx.controls.FxSceneContainer;
import com.htc.launcher.Launcher;
import com.htc.launcher.Logger;
import com.htc.launcher.R;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class FxDropAreaIndicator {
    private static final String LOG_TAG = "FxDropAreaIndicator";
    private Context mContext;
    private Marker[] mDropAreaPositionMarkers;
    private FxTimelineControl mDropAreaTimelineControl;
    private FxSceneContainer mParent;
    private int mSpanX;
    private int mSpanY;
    private FxScene mScene = null;
    private boolean mIsValid = false;
    private boolean mVisibility = false;
    private int mLastX = -1;
    private int mLastY = -1;
    private final int cellWidth = 4;
    private final int cellHeight = 4;
    private final String TIMELINECONTROL_DROPAREA = "timeline.droptarget%dx%d";
    private final String MARKER_DROPAREA_LOCATION = "p_%02d";
    private final String MARKER_VALID_IN = "highliight_in";
    private final String MARKER_VALID_OUT = "highliight_out";
    private final String MARKER_INVALID_IN = "red_in";
    private final String MARKER_INVALID_OUT = "red_out";

    FxDropAreaIndicator(FxSceneContainer parent, Context context) {
        this.mParent = parent;
        this.mContext = context;
    }

    public void loadScene(int spanX, int spanY) {
        String[] m10s = this.mContext.getResources().getStringArray(R.array.scene_droparea);
        String path = m10s[((spanX - 1) * 4) + (spanY - 1)];
        this.mScene = FxScene.create(Launcher.getFxPath() + path, true);
        if (this.mScene == null) {
            Logger.d(LOG_TAG, "mScene = null");
            return;
        }
        this.mSpanX = spanX;
        this.mSpanY = spanY;
        this.mLastX = -1;
        this.mLastY = -1;
        this.mIsValid = true;
        this.mParent.setScene(this.mScene);
        String controlName = String.format("timeline.droptarget%dx%d", Integer.valueOf(this.mSpanX), Integer.valueOf(this.mSpanY));
        this.mDropAreaTimelineControl = this.mScene.findControl(controlName);
        int countX = (4 - this.mSpanX) + 1;
        int countY = (4 - this.mSpanY) + 1;
        this.mDropAreaPositionMarkers = new Marker[countX * countY];
        for (int x = 0; x < countX; x++) {
            for (int y = 0; y < countY; y++) {
                int index = (((4 - this.mSpanX) + 1) * y) + x;
                if (index < this.mDropAreaPositionMarkers.length) {
                    String markerName = String.format("p_%02d", Integer.valueOf(index + 1));
                    this.mDropAreaPositionMarkers[index] = this.mScene.getMarker(markerName);
                }
            }
        }
    }

    public void removeScene() {
        if (this.mScene != null) {
            this.mParent.removeScene((FxObject) null);
            this.mScene = null;
            this.mDropAreaPositionMarkers = null;
            this.mDropAreaTimelineControl = null;
        }
    }

    public void showDropArea(int x, int y, boolean valid) {
        if (this.mScene != null) {
            if (!this.mVisibility) {
                this.mScene.setVisibility(true);
                this.mVisibility = true;
            }
            if (x != this.mLastX || y != this.mLastY || valid != this.mIsValid) {
                if (this.mDropAreaTimelineControl != null) {
                    if (this.mIsValid) {
                        this.mDropAreaTimelineControl.playMarker("highliight_out");
                    } else {
                        this.mDropAreaTimelineControl.playMarker("red_out");
                    }
                    int index = (((4 - this.mSpanX) + 1) * y) + x;
                    if (index >= 0 && index < this.mDropAreaPositionMarkers.length) {
                        this.mScene.setFrame(this.mDropAreaPositionMarkers[index].EndFrame);
                        this.mLastX = x;
                        this.mLastY = y;
                        this.mIsValid = valid;
                        if (this.mIsValid) {
                            this.mDropAreaTimelineControl.playMarker("highliight_in");
                            return;
                        } else {
                            this.mDropAreaTimelineControl.playMarker("red_in");
                            return;
                        }
                    }
                    Logger.e(LOG_TAG, "can't find marker " + index);
                    return;
                }
                Logger.d(LOG_TAG, "mDropAreaTimelineControl is empty");
            }
        }
    }

    public void setVisibility(boolean show) {
        if (this.mScene != null) {
            this.mVisibility = show;
            this.mScene.setVisibility(show);
        }
    }
}
