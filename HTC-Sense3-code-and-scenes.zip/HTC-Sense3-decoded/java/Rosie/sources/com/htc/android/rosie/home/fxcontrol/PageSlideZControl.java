package com.htc.android.rosie.home.fxcontrol;

import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.Marker;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class PageSlideZControl {
    private Marker mFrom0;
    private Marker mFrom1;
    private Marker mFrom5;
    private Marker mFrom6;
    private FxTimelineControl mPageSlideZControl;

    public PageSlideZControl(FxTimelineControl control) {
        this.mPageSlideZControl = control;
        if (this.mPageSlideZControl != null) {
            this.mFrom0 = this.mPageSlideZControl.getMarker("0to3");
            this.mFrom1 = this.mPageSlideZControl.getMarker("1to3");
            this.mFrom5 = this.mPageSlideZControl.getMarker("5to3");
            this.mFrom6 = this.mPageSlideZControl.getMarker("6to3");
        }
    }

    public void setFrame(int begin, int end, int screenWidth, int scrollX) {
        if (this.mPageSlideZControl != null && end == 3) {
            switch (begin) {
                case 0:
                    this.mPageSlideZControl.setFrame((((this.mFrom0.EndFrame - this.mFrom0.StartFrame) * scrollX) / (screenWidth * 3)) + this.mFrom0.StartFrame);
                    break;
                case 1:
                    this.mPageSlideZControl.setFrame((((scrollX - (screenWidth * 1)) * (this.mFrom1.EndFrame - this.mFrom1.StartFrame)) / ((screenWidth * 3) - (screenWidth * 1))) + this.mFrom1.StartFrame);
                    break;
                case 5:
                    this.mPageSlideZControl.setFrame((((scrollX - (screenWidth * 5)) * (this.mFrom5.EndFrame - this.mFrom5.StartFrame)) / ((screenWidth * 3) - (screenWidth * 5))) + this.mFrom5.StartFrame);
                    break;
                case 6:
                    this.mPageSlideZControl.setFrame((((scrollX - (screenWidth * 6)) * (this.mFrom6.EndFrame - this.mFrom6.StartFrame)) / ((screenWidth * 3) - (screenWidth * 6))) + this.mFrom6.StartFrame);
                    break;
            }
        }
    }
}
