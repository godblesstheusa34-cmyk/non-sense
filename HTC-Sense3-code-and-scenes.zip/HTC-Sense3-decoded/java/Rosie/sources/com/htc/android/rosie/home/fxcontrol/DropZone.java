package com.htc.android.rosie.home.fxcontrol;

import com.htc.android.rosie.home.fxcontrol.FxDropTarget;
import com.htc.fusion.fx.FxDraggable;
import com.htc.fusion.fx.MessageListener;
import com.htc.fusion.fx.controls.FxDropControl;
import com.htc.launcher.Draggee;
import com.htc.launcher.Logger;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public abstract class DropZone {
    protected Runnable mAction;
    private FxDropControl mFxDrop;
    private DropEventListener mListener;
    public int mOverlayColor;
    private String mScope;
    private FxDropTarget mTarget;

    public abstract void updateBounds();

    protected DropZone(String scope, FxDropControl drop, FxDropTarget target, int overlay) {
        String[] scopes = {scope};
        drop.setDragScope(scopes);
        this.mScope = scope;
        this.mFxDrop = drop;
        this.mTarget = target;
        this.mOverlayColor = overlay;
    }

    public void bindListener(DropEventListener l) {
        this.mListener = l;
        l.bindEvent(this.mFxDrop.getDropSource(), new MessageListener<FxDraggable>() { // from class: com.htc.android.rosie.home.fxcontrol.DropZone.1
            public void onMessageReceived(FxDraggable drag) {
                DropZone.this.mListener.handleEvent(drag, DropZone.this, FxDropTarget.State.DROP);
            }
        });
        l.bindEvent(this.mFxDrop.getDropOverSource(), new MessageListener<FxDraggable>() { // from class: com.htc.android.rosie.home.fxcontrol.DropZone.2
            public void onMessageReceived(FxDraggable drag) {
                DropZone.this.mListener.handleEvent(drag, DropZone.this, FxDropTarget.State.DRAG_OVER);
            }
        });
        l.bindEvent(this.mFxDrop.getDropOutSource(), new MessageListener<FxDraggable>() { // from class: com.htc.android.rosie.home.fxcontrol.DropZone.3
            public void onMessageReceived(FxDraggable drag) {
                DropZone.this.mListener.handleEvent(drag, DropZone.this, FxDropTarget.State.DRAG_EXIT);
            }
        });
    }

    void unbindListener() {
        if (this.mFxDrop != null && this.mListener != null) {
            this.mListener.destroy();
            this.mListener = null;
        }
    }

    public void setEnabled(boolean enable) {
        Logger.d("EditZone", "[EDIT_DEBUG] DropZone.setEnabled(" + enable + ")");
        this.mFxDrop.setEnabled(enable);
        this.mTarget.acceptDrop = enable;
    }

    FxDropControl getDrop() {
        return this.mFxDrop;
    }

    String getScopeKey() {
        return this.mScope;
    }

    boolean accept(Draggee draggee) {
        return true;
    }

    public FxDropTarget getTarget() {
        return this.mTarget;
    }

    public Runnable getAction() {
        return this.mAction;
    }

    void destroy() {
        unbindListener();
        this.mFxDrop = null;
        this.mScope = null;
        this.mTarget = null;
        this.mAction = null;
    }
}
