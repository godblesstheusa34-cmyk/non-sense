package com.htc.android.rosie.home.fxcontrol;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import com.htc.android.rosie.home.fxcontrol.FxScreen;
import com.htc.android.rosie.home.fxcontrol.FxWorkspaceClient;
import com.htc.android.rosie.home.fxcontrol.ItemContainer;
import com.htc.android.rosie.home.fxcontrol.PageSlideControl;
import com.htc.android.rosie.home.fxcontrol.TimelineAnimation;
import com.htc.fusion.Point3F;
import com.htc.fusion.fx.FxObject;
import com.htc.fusion.fx.FxPlaybackInfo;
import com.htc.fusion.fx.FxScene;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.FxView;
import com.htc.fusion.fx.Marker;
import com.htc.fusion.fx.controls.FxSceneContainer;
import com.htc.launcher.ApplicationInfo;
import com.htc.launcher.DesktopItemController;
import com.htc.launcher.DragController;
import com.htc.launcher.DragSource;
import com.htc.launcher.Draggee;
import com.htc.launcher.DropTarget;
import com.htc.launcher.FxItem;
import com.htc.launcher.FxItemInfo;
import com.htc.launcher.ItemInfo;
import com.htc.launcher.Launcher;
import com.htc.launcher.LauncherModel;
import com.htc.launcher.LeapController;
import com.htc.launcher.Logger;
import com.htc.launcher.R;
import com.htc.launcher.Utilities;
import com.htc.launcher.Workspace;
import com.htc.launcher.settings.SettingUtil;
import java.util.ArrayList;
import java.util.List;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class FxWorkspace extends FxView implements Launcher.TiltObserver, Workspace.OnScrollStateChangedListener, View.OnTouchListener, Workspace.OnSlideListener, DragController.DragListener, DesktopItemController.FloatingEnv, View.OnLongClickListener, DragSource, FxWorkspaceClient.IButtonListener {
    static final /* synthetic */ boolean $assertionsDisabled;
    private static final boolean DEBUG_TOUCH;
    private static final int DELAY_FOR_BTN_COMPLETE = 290;
    private static final String LOG_TAG;
    private static final int LONGCLICK_FOR_DRAG = 4;
    private static final int MIDDLE_BTN_POSITION_BOTTOM = 3;
    private static final int MIDDLE_BTN_POSITION_LEFT = 0;
    private static final int MIDDLE_BTN_POSITION_RIGHT = 2;
    private static final int MIDDLE_BTN_POSITION_TOP = 1;
    static final int MODE_LEAP = 1;
    static final int MODE_LEAP_REARRANGE = 2;
    static final int MODE_NONE = -1;
    static final int MODE_SCROLL = 0;
    static final int OP_ALL = 0;
    static final int OP_CURRENT_BESIDE = 2;
    static final int OP_CURRENT_ONLY = 1;
    private static final boolean PROFILE_ORIENTATION = false;
    private static final boolean localLOGD;
    private static FxWorkspace sFxWorkspace;
    private static boolean sIsPortrait;
    static final LauncherModel sModel;
    private ApplicationInfo mAppInfoForDropBackButtonBar;
    private ArrayList<ApplicationInfo> mApplicationInfoSaved;
    private PageSlideControl.Direction mBeginDirection;
    public ButtonBarHandler mButtonBarHandler;
    private boolean[] mButtonbarCount;
    private Context mContext;
    private int mCurrentScreen;
    private int mCurrentScrollX;
    private boolean mDidRelinquishScreenCache;
    private PageSlideControl.Direction mDirection;
    private Runnable mDragStartRunnable;
    private DragController mDragger;
    private int mEvStartX;
    private int mEvStartY;
    private RectF mFloatingBounds;
    private DesktopItem mFloatingScreenItem;
    private Rect mFocusRect;
    private boolean mFrozen;
    private int[] mHitXY;
    private int mIndexOfButtonbarTouch;
    private int mIndexOfButtonbarTouchStart;
    private boolean mIsFlingMode;
    private boolean mIsLeapMode;
    private boolean mIsLongClick;
    private boolean mIsPreviousOrientationPortrait;
    private boolean mIsScrolling;
    private boolean mIsStartDrag;
    float mLastMotionDownX;
    float mLastMotionDownY;
    private int mLastScrollX;
    private float mLastZoomRatio;
    private Launcher mLauncher;
    private FxLeapListener mLeapListener;
    private FxLeapPlayer mLeapPlayer;
    private Runnable mMiddleBtnCompleteRunnable;
    private int mMode;
    private MotionEvent mMotionEvent;
    private int mNextScreen;
    private int mOffsetX;
    private int mOffsetY;
    private int mPrevScreen;
    private boolean mQuickScrolling;
    private String[] mScopeEmpty;
    private String[] mScopeFull;
    private FxPageSinkControl mSinkControl;
    private boolean mSlideSceneVisibility;
    private SnapInfo mSnapInfo;
    private GestureDetector mTapDetector;
    private float mTiltValue;
    private int mTimeOfButtonBarLongclick;
    private boolean mTouchByDelegate;
    UiHandler mUiHandler;
    private IUnlockAnimationListener mUnlockAnimationListener;
    private View.OnTouchListener mWorkspaceTouchListener;
    private WorkspaceHolder mWorkspaces;
    private float mZoomRatio;

    public interface IEditModeListener {
        void onPostEnterEditMode();

        void onPostLeaveEditMode();

        void onPreEnterEditMode();

        void onPreLeaveEditMode();
    }

    public interface IUnlockAnimationListener {
        void onAnimationEnd();

        void onAnimationStart();
    }

    public interface IUnlockAnimator {
        boolean isUnlockAnimation(FxPlaybackInfo fxPlaybackInfo);

        void prepareAnimation();

        void startAnimation();

        void stopAnimation();
    }

    static {
        $assertionsDisabled = !FxWorkspace.class.desiredAssertionStatus();
        LOG_TAG = FxWorkspace.class.getSimpleName();
        localLOGD = SettingUtil.localLOGD;
        DEBUG_TOUCH = false;
        sModel = new LauncherModel();
    }

    public FxWorkspace(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mIsScrolling = false;
        this.mIsStartDrag = false;
        this.mSnapInfo = new SnapInfo();
        this.mApplicationInfoSaved = new ArrayList<>();
        this.mIsLongClick = false;
        this.mTimeOfButtonBarLongclick = 0;
        this.mButtonbarCount = new boolean[]{false, false, false};
        this.mScopeFull = new String[]{ItemContainer.DRAG_SCOPE_FULL};
        this.mScopeEmpty = new String[]{ItemContainer.DRAG_SCOPE_EMPTY};
        this.mIsPreviousOrientationPortrait = true;
        this.mIsLeapMode = false;
        this.mQuickScrolling = false;
        this.mBeginDirection = PageSlideControl.Direction.NONE;
        this.mCurrentScrollX = 0;
        this.mLastScrollX = this.mCurrentScrollX;
        this.mDirection = PageSlideControl.Direction.NONE;
        this.mSlideSceneVisibility = true;
        this.mFrozen = false;
        this.mMode = -1;
        this.mFloatingBounds = new RectF();
        this.mCurrentScreen = Workspace.getDefaultScreenIndex();
        this.mHitXY = new int[2];
        this.mFocusRect = new Rect();
        this.mZoomRatio = 0.0f;
        this.mLastZoomRatio = this.mZoomRatio;
        this.mIsFlingMode = false;
        this.mDragStartRunnable = null;
        this.mUiHandler = new UiHandler();
        this.mMiddleBtnCompleteRunnable = null;
        this.mDidRelinquishScreenCache = false;
        this.mContext = context;
        initFxWorkspace();
    }

    public FxWorkspace(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mIsScrolling = false;
        this.mIsStartDrag = false;
        this.mSnapInfo = new SnapInfo();
        this.mApplicationInfoSaved = new ArrayList<>();
        this.mIsLongClick = false;
        this.mTimeOfButtonBarLongclick = 0;
        this.mButtonbarCount = new boolean[]{false, false, false};
        this.mScopeFull = new String[]{ItemContainer.DRAG_SCOPE_FULL};
        this.mScopeEmpty = new String[]{ItemContainer.DRAG_SCOPE_EMPTY};
        this.mIsPreviousOrientationPortrait = true;
        this.mIsLeapMode = false;
        this.mQuickScrolling = false;
        this.mBeginDirection = PageSlideControl.Direction.NONE;
        this.mCurrentScrollX = 0;
        this.mLastScrollX = this.mCurrentScrollX;
        this.mDirection = PageSlideControl.Direction.NONE;
        this.mSlideSceneVisibility = true;
        this.mFrozen = false;
        this.mMode = -1;
        this.mFloatingBounds = new RectF();
        this.mCurrentScreen = Workspace.getDefaultScreenIndex();
        this.mHitXY = new int[2];
        this.mFocusRect = new Rect();
        this.mZoomRatio = 0.0f;
        this.mLastZoomRatio = this.mZoomRatio;
        this.mIsFlingMode = false;
        this.mDragStartRunnable = null;
        this.mUiHandler = new UiHandler();
        this.mMiddleBtnCompleteRunnable = null;
        this.mDidRelinquishScreenCache = false;
        this.mContext = context;
        initFxWorkspace();
    }

    public FxWorkspace(Context context, boolean lpBroadcast, int lpPort, boolean quitOnDisconnect) {
        super(context, lpBroadcast, lpPort, quitOnDisconnect);
        this.mIsScrolling = false;
        this.mIsStartDrag = false;
        this.mSnapInfo = new SnapInfo();
        this.mApplicationInfoSaved = new ArrayList<>();
        this.mIsLongClick = false;
        this.mTimeOfButtonBarLongclick = 0;
        this.mButtonbarCount = new boolean[]{false, false, false};
        this.mScopeFull = new String[]{ItemContainer.DRAG_SCOPE_FULL};
        this.mScopeEmpty = new String[]{ItemContainer.DRAG_SCOPE_EMPTY};
        this.mIsPreviousOrientationPortrait = true;
        this.mIsLeapMode = false;
        this.mQuickScrolling = false;
        this.mBeginDirection = PageSlideControl.Direction.NONE;
        this.mCurrentScrollX = 0;
        this.mLastScrollX = this.mCurrentScrollX;
        this.mDirection = PageSlideControl.Direction.NONE;
        this.mSlideSceneVisibility = true;
        this.mFrozen = false;
        this.mMode = -1;
        this.mFloatingBounds = new RectF();
        this.mCurrentScreen = Workspace.getDefaultScreenIndex();
        this.mHitXY = new int[2];
        this.mFocusRect = new Rect();
        this.mZoomRatio = 0.0f;
        this.mLastZoomRatio = this.mZoomRatio;
        this.mIsFlingMode = false;
        this.mDragStartRunnable = null;
        this.mUiHandler = new UiHandler();
        this.mMiddleBtnCompleteRunnable = null;
        this.mDidRelinquishScreenCache = false;
        this.mContext = context;
        initFxWorkspace();
    }

    public FxWorkspace(Context context) {
        super(context);
        this.mIsScrolling = false;
        this.mIsStartDrag = false;
        this.mSnapInfo = new SnapInfo();
        this.mApplicationInfoSaved = new ArrayList<>();
        this.mIsLongClick = false;
        this.mTimeOfButtonBarLongclick = 0;
        this.mButtonbarCount = new boolean[]{false, false, false};
        this.mScopeFull = new String[]{ItemContainer.DRAG_SCOPE_FULL};
        this.mScopeEmpty = new String[]{ItemContainer.DRAG_SCOPE_EMPTY};
        this.mIsPreviousOrientationPortrait = true;
        this.mIsLeapMode = false;
        this.mQuickScrolling = false;
        this.mBeginDirection = PageSlideControl.Direction.NONE;
        this.mCurrentScrollX = 0;
        this.mLastScrollX = this.mCurrentScrollX;
        this.mDirection = PageSlideControl.Direction.NONE;
        this.mSlideSceneVisibility = true;
        this.mFrozen = false;
        this.mMode = -1;
        this.mFloatingBounds = new RectF();
        this.mCurrentScreen = Workspace.getDefaultScreenIndex();
        this.mHitXY = new int[2];
        this.mFocusRect = new Rect();
        this.mZoomRatio = 0.0f;
        this.mLastZoomRatio = this.mZoomRatio;
        this.mIsFlingMode = false;
        this.mDragStartRunnable = null;
        this.mUiHandler = new UiHandler();
        this.mMiddleBtnCompleteRunnable = null;
        this.mDidRelinquishScreenCache = false;
        this.mContext = context;
        initFxWorkspace();
    }

    @Override // com.htc.launcher.Workspace.OnSlideListener
    public void onScrollTo(float x, float y, int scrollRange, int screenWidth) {
        if (screenWidth != 0) {
            if (x > SettingUtil.sWorkspaceScreenCount * screenWidth) {
                x %= SettingUtil.sWorkspaceScreenCount * screenWidth;
            } else if (SettingUtil.usesRingSlide() && x < 0.0f) {
                x = (SettingUtil.sWorkspaceScreenCount * screenWidth) + (x % (SettingUtil.sWorkspaceScreenCount * screenWidth));
                if (x == SettingUtil.sWorkspaceScreenCount * screenWidth) {
                    x = 0.0f;
                }
            }
            if (this.mBeginDirection == PageSlideControl.Direction.NONE) {
                if (x <= this.mLastScrollX) {
                    this.mBeginDirection = PageSlideControl.Direction.RIGHT;
                } else {
                    this.mBeginDirection = PageSlideControl.Direction.LEFT;
                }
            }
            if (this.mBeginDirection == PageSlideControl.Direction.LEFT) {
                if (x < this.mLastScrollX) {
                    this.mDirection = PageSlideControl.Direction.RIGHT;
                } else {
                    this.mDirection = PageSlideControl.Direction.LEFT;
                }
            } else if (this.mBeginDirection != PageSlideControl.Direction.RIGHT) {
                Log.e(LOG_TAG, "begin direction should not enter this state.");
            } else if (x > this.mLastScrollX) {
                this.mDirection = PageSlideControl.Direction.LEFT;
            } else {
                this.mDirection = PageSlideControl.Direction.RIGHT;
            }
            this.mCurrentScrollX = (int) x;
            boolean aligned = determineCurrentScreen(this.mCurrentScrollX, screenWidth);
            this.mWorkspaces.getCurrent().getPageSlideControl().slideTo(x, screenWidth, this.mDirection, this.mSnapInfo);
            if (!this.mIsLeapMode) {
                changeScreensVisibility(aligned);
            }
        }
    }

    public void setCurrentScreen(int screen, int width) {
        if (localLOGD) {
            Log.d(LOG_TAG, "setCurrentScreen: " + screen);
        }
        this.mCurrentScrollX = screen * width;
        this.mWorkspaces.getCurrent().getPageSlideControl().slideTo(this.mCurrentScrollX, width, this.mDirection, this.mSnapInfo);
    }

    public void updateInitFrame() {
        this.mWorkspaces.getCurrent().getPageSlideControl().initFrame();
        if (this.mWorkspaces.getAnother() != null) {
            this.mWorkspaces.getAnother().getPageSlideControl().initFrame();
        }
    }

    public class SnapInfo {
        int begin;
        int end;
        boolean isSnap;
        int snapOffset;

        public SnapInfo() {
        }

        public String toString() {
            return "s: " + this.isSnap + ", b: " + this.begin + ", e: " + this.end + ", offset: " + this.snapOffset;
        }
    }

    @Override // com.htc.launcher.Workspace.OnScrollStateChangedListener
    public void onBeginFling() {
        if (isPortrait()) {
            showAllScreens();
        }
        onQuickScroll(true);
        if (localLOGD) {
            Log.d(LOG_TAG, "onWorkspaceBeginFling()");
        }
    }

    @Override // com.htc.launcher.Workspace.OnScrollStateChangedListener
    public void onBeginScroll(boolean isSnap, int begin, int end) {
        if (!this.mIsLeapMode) {
            this.mSnapInfo.isSnap = isSnap;
            this.mSnapInfo.begin = begin;
            this.mSnapInfo.end = end;
            this.mIsScrolling = true;
            this.mIsFlingMode = false;
            this.mWorkspaces.getCurrent().stopFade(false);
            if (localLOGD) {
                Log.d(LOG_TAG, "onWorkspaceBeginScroll()");
            }
        }
    }

    @Override // com.htc.launcher.Workspace.OnScrollStateChangedListener
    public void onEndScroll() {
        if (!this.mIsLeapMode) {
            onQuickScroll(false);
            this.mLastScrollX = this.mCurrentScrollX;
            this.mBeginDirection = PageSlideControl.Direction.NONE;
            this.mIsScrolling = false;
            this.mIsFlingMode = false;
            this.mZoomRatio = 0.0f;
            this.mLastZoomRatio = 0.0f;
            if (this.mIsStartDrag) {
                this.mWorkspaces.getCurrent().getScreen(this.mSnapInfo.begin).thawChildren();
                this.mWorkspaces.getCurrent().getScreen(this.mSnapInfo.end).freezeChildren();
            }
            if (SettingUtil.isDoubleShot()) {
                this.mWorkspaces.getCurrent().getPageSlideControl().setScrollBarControlVisibility(false);
            }
            if (localLOGD) {
                Log.d(LOG_TAG, "onWorkspaceStopScroll()");
            }
        }
    }

    private void initFxWorkspace() {
        this.mLauncher = Launcher.sRefLauncher.get();
        this.mLauncher.registerTiltObserver(this);
        sFxWorkspace = this;
        sIsPortrait = this.mLauncher.isPortrait();
        if (SettingUtil.isTabletDevice()) {
            this.mButtonBarHandler = new ButtonBarHandler();
        }
        loadFxWorkspace(false);
    }

    private void initSceneAndControlls() {
        if (localLOGD) {
            Log.d("Rotate.Performance", "+initSceneAndControlls");
        }
        for (int i = 0; i < SettingUtil.getCustomizeButtonCount(); i++) {
            if (this.mApplicationInfoSaved.size() < SettingUtil.getCustomizeButtonCount()) {
                this.mApplicationInfoSaved.add(null);
            }
        }
        if (localLOGD) {
            Log.d("Rotate.Performance", "-initSceneAndControlls");
        }
    }

    public FxScreen getScreen(int screen) {
        if (isValidScreenId(screen)) {
            return this.mWorkspaces.getCurrent().getScreens().get(screen).mFxScreen;
        }
        return null;
    }

    public void show() {
        if (localLOGD) {
            Log.d(LOG_TAG, "mSlideScene Visibility: true");
        }
        this.mWorkspaces.getCurrent().getSlideScene().setVisibility(true);
        this.mSlideSceneVisibility = true;
    }

    public void hide() {
        if (localLOGD) {
            Log.d(LOG_TAG, "mSlideScene Visibility: false");
        }
        this.mWorkspaces.getCurrent().getSlideScene().setVisibility(false);
        this.mSlideSceneVisibility = false;
    }

    public void freeze(boolean enable) {
        if (this.mFrozen != enable) {
            if (enable) {
                this.mWorkspaces.getCurrent().stopFade(false);
                long start = System.currentTimeMillis();
                getViewObject().pauseRendering();
                if (localLOGD) {
                    Logger.d(SettingUtil.PERFORMANCE_TAG, "pauseRendering costs " + (System.currentTimeMillis() - start));
                }
            } else {
                long start2 = System.currentTimeMillis();
                getViewObject().resumeRendering();
                if (localLOGD) {
                    Logger.d(SettingUtil.PERFORMANCE_TAG, "resumeRendering costs " + (System.currentTimeMillis() - start2));
                }
            }
            this.mFrozen = enable;
        }
    }

    private void populateScreens(boolean currentOnly) {
        if (this.mLauncher.getWorkspace() != null) {
            syncWorkspaceScreen(this.mLauncher.getWorkspace());
        }
        switchMode(0, currentOnly ? 1 : 0);
    }

    public void populateOtherScreens() {
        changeScreensVisibility(true);
    }

    void switchMode(int mode, int op) {
        if (localLOGD) {
            Log.d(LOG_TAG, "switchMode(" + mode + ", currentOnly? " + op + ")");
        }
        long st = System.currentTimeMillis();
        freeze(true);
        boolean isSameScene = false;
        if (this.mMode != mode) {
            this.mWorkspaces.getCurrent().detach();
            this.mMode = mode;
        } else {
            isSameScene = true;
        }
        if (this.mDidRelinquishScreenCache) {
            this.mDidRelinquishScreenCache = false;
        }
        this.mIsLeapMode = false;
        this.mWorkspaces.getCurrent().switchMode(mode, op, this.mCurrentScreen);
        FxWorkspaceClient otherClient = this.mWorkspaces.getAnother();
        if (otherClient != null) {
            otherClient.switchMode(mode, op, this.mCurrentScreen);
        }
        switch (mode) {
            case 0:
                show();
                if (!isSameScene) {
                    if (localLOGD) {
                        Log.d(LOG_TAG, "addScene: SlideScene");
                    }
                    this.mWorkspaces.getCurrent().attachTo(this, 0);
                }
                if (op == 2 || op == 0) {
                }
                break;
            case 1:
                this.mIsLeapMode = true;
                if (!isSameScene) {
                    if (localLOGD) {
                        Log.d(LOG_TAG, "addScene: LeapScene");
                    }
                    this.mWorkspaces.getCurrent().attachTo(this, 1);
                    break;
                }
                break;
            case 2:
                this.mIsLeapMode = true;
                if (!isSameScene) {
                    if (localLOGD) {
                        Log.d(LOG_TAG, "addScene: LeapRearrangeScene");
                    }
                    this.mWorkspaces.getCurrent().attachTo(this, 2);
                    break;
                }
                break;
        }
        freeze(false);
        long et = System.currentTimeMillis();
        if (localLOGD) {
            Logger.d(LOG_TAG, "[ROSIE_DEBUG] switchMode(" + mode + ") " + (et - st) + "ms");
        }
    }

    public void changeScreensVisibility(boolean aligned) {
        if (!this.mLauncher.isLoading() && this.mLauncher.canFreeze()) {
            if (this.mFrozen) {
                freeze(false);
            }
            this.mWorkspaces.getCurrent().changeScreensVisibility(aligned, this.mCurrentScreen, this.mNextScreen, this.mTiltValue, Float.POSITIVE_INFINITY);
            if (this.mDidRelinquishScreenCache) {
                this.mDidRelinquishScreenCache = false;
            }
        }
    }

    public void onQuickScroll(boolean quickScroll) {
        this.mWorkspaces.getCurrent().quickScroll(quickScroll);
        if (!quickScroll && this.mQuickScrolling) {
            this.mWorkspaces.getCurrent().fadeOtherScreens(this.mCurrentScreen);
        }
        this.mQuickScrolling = quickScroll;
    }

    private void resetQuickScroll() {
        this.mQuickScrolling = false;
        this.mWorkspaces.getCurrent().quickScroll(false);
    }

    public void showAllScreens() {
        this.mWorkspaces.getCurrent().showAllScreens();
    }

    public void thawAllScreens() {
        this.mWorkspaces.getCurrent().thawAllScreens();
    }

    public void pulseFreezeAllScreens() {
        if (this.mSlideSceneVisibility) {
            this.mWorkspaces.getCurrent().pulseFreezeAllScreens();
        }
    }

    public void freezeAllScreens() {
        this.mWorkspaces.getCurrent().freezeAllScreens();
    }

    private void syncWorkspaceScreen(Workspace workspace) {
        if (this.mWorkspaces.getCurrent().getPageSlideControl() != null && workspace != null) {
            int screenWidth = workspace.getWidth();
            int scrollX = workspace.getCurrentScreenIndex() * screenWidth;
            SnapInfo si = new SnapInfo();
            si.isSnap = false;
            si.begin = 0;
            si.end = -1;
            if (localLOGD) {
                Log.d(LOG_TAG, "slideToScreen: " + scrollX + ", d: " + PageSlideControl.Direction.NONE + ", s: " + si);
            }
            this.mWorkspaces.getCurrent().getPageSlideControl().slideTo(scrollX, screenWidth, PageSlideControl.Direction.NONE, si);
        }
    }

    public void clear() {
        this.mLauncher.unregisterTiltObserver(this);
        if (this.mWorkspaces.getCurrent().getScreens() != null) {
            this.mWorkspaces.getCurrent().getScreens().clear();
        }
        if (this.mWorkspaces.getCurrent().getSlideScene() != null) {
            removeScene(this.mWorkspaces.getCurrent().getSlideScene());
        }
        if (this.mWorkspaces.getCurrent().getLeapScene() != null) {
            removeScene(this.mWorkspaces.getCurrent().getLeapScene());
        }
        if (this.mWorkspaces.getCurrent().getLeapRearrangeScene() != null) {
            removeScene(this.mWorkspaces.getCurrent().getLeapRearrangeScene());
        }
    }

    @Override // com.htc.launcher.DesktopItemController.FloatingEnv
    public boolean onFloat(Draggee item, RectF bounds) {
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] FxWorkspace.onFloat()");
        }
        return putItem((FxItem) item, bounds);
    }

    @Override // com.htc.launcher.DesktopItemController.FloatingEnv
    public boolean onPoof(Draggee item) {
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] FxWorkspace.onPoof()");
        }
        return removeItem();
    }

    @Override // com.htc.launcher.DesktopItemController.FloatingEnv
    public boolean onLand(Draggee item, int container, int x, int y) {
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] FxWorkspace.onLand()");
        }
        if (!$assertionsDisabled && item != this.mFloatingScreenItem.mFxItem) {
            throw new AssertionError();
        }
        ItemInfo info = item.getItemInfo();
        FxScreen.LayoutParams layout = new FxScreen.LayoutParams(x, y, info.spanX, info.spanY);
        return dropItemToScreen(container, layout);
    }

    public boolean putItem(FxItem item, RectF bounds) {
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] FxWorkspace.putItem()");
        }
        if (this.mFloatingScreenItem == null) {
            if (localLOGD) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG] FxWorkspace.putItem() - setupFloating()");
            }
            setupFloating(item, bounds);
            this.mIsStartDrag = true;
            return true;
        }
        Log.w(LOG_TAG, "There is something in the air already:" + this.mFloatingScreenItem.mFxItem);
        return false;
    }

    private FxScene setupFloating(FxItem item, RectF bounds) {
        FxScreen currentScreen;
        FxScene container;
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG]# FxWorkspace.setupFloating() - enter");
        }
        if (item == null || (currentScreen = getScreen(getCurrentScreen())) == null) {
            return null;
        }
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] FxWorkspace.setupFloating() - ItemInfo:" + item.getItemInfo());
        }
        ItemContainer itemContainer = null;
        DesktopItem desktopItem = currentScreen.getDesktopItem(item.getItemInfo());
        if (desktopItem != null) {
            itemContainer = desktopItem.mItemContainer;
            desktopItem.isDragging = true;
        }
        ItemInfo info = item.getInfo();
        if (itemContainer == null) {
            FxScreen layoutHelper = getScreen(0);
            container = FxScene.create(Launcher.getFxPath() + layoutHelper.getM10PathByWH(info.spanX, info.spanY), true);
            ItemContainer.Builder icb = new ItemContainer.Builder();
            itemContainer = icb.setScene(container).setContainer("container").setItem(item.getScene()).setDrag(ItemContainer.DRAG_NAME).build();
            if (localLOGD) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG] FxWorkspace.setupFloating() - new Container");
            }
        } else {
            container = itemContainer.getScene();
            if (localLOGD) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG] FxWorkspace.setupFloating() - old Container");
            }
        }
        if (container == null) {
            return null;
        }
        if (bounds == null) {
            PointF size = container.getSize();
            PointF box = currentScreen.getSize();
            bounds = this.mFloatingBounds;
            bounds.set(0.0f, 0.0f, size.x, size.y);
            bounds.offsetTo((box.x - size.x) / 2.0f, (box.y - size.y) / 2.0f);
        }
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG]# FxWorkspace.setupFloating() setPosition(" + bounds.left + ", " + bounds.top + ")");
        }
        container.setPosition(new Point3F(bounds.left, bounds.top, 0.0f));
        this.mFloatingScreenItem = new FloatingItem(item, itemContainer, bounds);
        Draggee draggee = item.getDraggee();
        if (draggee == null || !(draggee instanceof FxScreen.FxDraggee)) {
            item.setDraggee(new FxScreen.FxDraggee(info.id, this.mFloatingScreenItem, item.getDraggee()));
        } else {
            item.setDraggee(new FxScreen.FxDraggee(info.id, this.mFloatingScreenItem, null));
        }
        this.mFloatingScreenItem.attachTo(this);
        fakeTouchDown();
        return container;
    }

    public boolean removeItem() {
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG]# FxWorkspace.removeItem() - enter");
        }
        if (this.mFloatingScreenItem == null) {
            return false;
        }
        if (localLOGD) {
            Log.d(LOG_TAG, "remove floating scene");
        }
        this.mFloatingScreenItem.detach();
        this.mFloatingScreenItem = null;
        return true;
    }

    public boolean dropItemToScreen(int screen, FxScreen.LayoutParams layout) {
        FxItem floating = this.mFloatingScreenItem.mFxItem;
        if (floating != null && screen != -1) {
            ItemInfo info = floating.getItemInfo();
            if (info instanceof FxItemInfo) {
                addItemToScreen(screen, ((FxItemInfo) info).widgetId, floating, layout);
                return true;
            }
            return true;
        }
        return true;
    }

    private static class FloatingItem extends DesktopItem {
        private FloatingItem(FxItem fxItem, ItemContainer container, RectF position) {
            super(fxItem, container);
            this.mBounds.set(position);
        }
    }

    public boolean addItemToScreen(int screen, long id, FxItem item, FxScreen.LayoutParams layout) {
        Draggee draggee = item.getDraggee();
        boolean ret = this.mWorkspaces.getCurrent().addItemToScreen(screen, id, item, layout);
        FxWorkspaceClient otherClient = this.mWorkspaces.getAnother();
        if (ret && otherClient != null) {
            FxItem aItem = new FxItem(item.getInfo(), draggee);
            otherClient.addItemToScreen(screen, id, aItem, layout);
        }
        if (this.mLauncher.getDesktopItemController().IS_EXTERNAL_APP_ADDING) {
            this.mLauncher.getDesktopItemController().IS_EXTERNAL_APP_ADDING = false;
            this.mLauncher.getDesktopItemController().resumeRenderring();
        }
        return ret;
    }

    public boolean syncItemInAnotherScreen(Draggee dragItem, int from, int to, int x, int y) {
        FxWorkspaceClient otherClient = this.mWorkspaces.getAnother();
        if (otherClient != null) {
            FxScreen target = otherClient.getScreen(to);
            target.syncItemInfo(dragItem, x, y);
            return true;
        }
        return true;
    }

    public boolean resumeItemInScreen(Draggee dragItem, int from, int to, int x, int y) {
        FxScreen source = getScreen(from);
        FxScreen target = getScreen(to);
        if (dragItem == null || source == null || target == null) {
            return false;
        }
        boolean ret = source.resumeItem(dragItem, target, x, y);
        FxWorkspaceClient otherClient = this.mWorkspaces.getAnother();
        if (ret && otherClient != null) {
            otherClient.getScreen(from).resumeItem(dragItem, otherClient.getScreen(to), x, y);
        }
        return ret;
    }

    public void showDrag(ItemInfo itemInfo) {
        if (itemInfo == null) {
            if (localLOGD) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG]# FxWorkspace.showDrag() itemInfo = null, return!");
                return;
            }
            return;
        }
        FxScreen source = getScreen(itemInfo.screen);
        if (source == null) {
            if (localLOGD) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG]# FxWorkspace.showDrag() Source screen = null, return!");
                return;
            }
            return;
        }
        DesktopItem item = source.getDesktopItem(itemInfo);
        if (item == null || item.mItemContainer == null) {
            if (localLOGD) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG]# FxWorkspace.showDrag() MyItemContainer = null, return!");
            }
        } else {
            if (localLOGD) {
                Logger.d(LOG_TAG, "[EDIT_DEBUG]# FxWorkspace.showDrag(" + itemInfo + ")");
            }
            item.mItemContainer.setDragVisibility(true);
        }
    }

    public boolean removeItemFromScreen(Draggee dragItem, int from) {
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] FxWorkspace.removeItemFromScreen() - 2");
        }
        FxScreen source = getScreen(from);
        if (dragItem == null || source == null) {
            return false;
        }
        boolean ret = source.removeItem(dragItem);
        FxWorkspaceClient other = this.mWorkspaces.getAnother();
        if (ret && other != null) {
            other.getScreens().get(from).mFxScreen.removeItem(dragItem);
        }
        return ret;
    }

    public boolean removeItemSceneFromScreen(Draggee dragItem, int from) {
        if (localLOGD) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] FxWorkspace.removeItemSceneFromScreen()");
        }
        FxScreen source = getScreen(from);
        if (dragItem == null || source == null) {
            return false;
        }
        boolean ret = source.removeItemScene(dragItem);
        FxWorkspaceClient other = this.mWorkspaces.getAnother();
        if (ret && other != null) {
            other.getScreen(from).removeItemScene(dragItem);
        }
        return ret;
    }

    private boolean isValidScreenId(int screen) {
        return screen >= 0 && screen < this.mWorkspaces.getCurrent().getScreens().size();
    }

    public boolean removeItemFromScreen(int screen, int id) {
        boolean ret = this.mWorkspaces.getCurrent().removeItemFromScreen(screen, id);
        FxWorkspaceClient other = this.mWorkspaces.getAnother();
        if (ret && other != null) {
            other.removeItemFromScreen(screen, id);
        }
        return ret;
    }

    public void removeAllItems() {
        this.mWorkspaces.getCurrent().removeAllItems();
        FxWorkspaceClient anotherClient = this.mWorkspaces.getAnother();
        if (anotherClient != null) {
            anotherClient.removeAllItems();
        }
        if (SettingUtil.isTabletDevice() && this.mButtonBarHandler != null) {
            this.mButtonBarHandler.removeAllItems();
        }
    }

    private boolean determineCurrentScreen(int scrollX, int screenWidth) {
        int screen = scrollX / screenWidth;
        boolean aligned = scrollX % screenWidth == 0;
        if (this.mCurrentScreen == screen) {
            if (scrollX < 0) {
                this.mPrevScreen = this.mCurrentScreen + 1;
                this.mNextScreen = SettingUtil.getScreenCount() - 1;
            } else {
                this.mNextScreen = this.mCurrentScreen + 1;
                if (this.mNextScreen == SettingUtil.getScreenCount()) {
                    this.mNextScreen = 0;
                }
                this.mPrevScreen = this.mCurrentScreen - 1;
                if (this.mPrevScreen < 0) {
                    this.mPrevScreen = SettingUtil.getScreenCount() - 1;
                }
            }
        } else if (screen >= 0 && screen < SettingUtil.getScreenCount()) {
            this.mCurrentScreen = screen;
            this.mNextScreen = this.mCurrentScreen + 1;
            if (this.mNextScreen == SettingUtil.getScreenCount()) {
                this.mNextScreen = 0;
            }
            this.mPrevScreen = this.mCurrentScreen - 1;
            if (this.mPrevScreen < 0) {
                this.mPrevScreen = SettingUtil.getScreenCount() - 1;
            }
        }
        return aligned;
    }

    @Override // com.htc.launcher.Launcher.TiltObserver
    public void onTilt(float tilt, float speed) {
        this.mTiltValue = tilt;
        if (isPortrait()) {
            this.mWorkspaces.getCurrent().getScreens().get(this.mCurrentScreen).setSensorValue(this.mTiltValue, speed);
            return;
        }
        for (int i = 0; i < this.mWorkspaces.getCurrent().getScreens().size(); i++) {
            this.mWorkspaces.getCurrent().getScreens().get(i).setSensorValue(1.0f - this.mTiltValue, speed);
        }
    }

    public Rect getPosition() {
        if (this.mFloatingScreenItem == null) {
            return null;
        }
        FxScene floatingScene = this.mFloatingScreenItem.mItemContainer.getScene();
        Rect rect = new Rect();
        rect.left = (int) floatingScene.getWorldPosition().x;
        rect.top = (int) floatingScene.getWorldPosition().y;
        rect.right = rect.left + ((int) floatingScene.getSize().x);
        rect.bottom = rect.top + ((int) floatingScene.getSize().y);
        return rect;
    }

    public void dispatchDraw(Canvas canvas) {
        if (!this.mIsScrolling) {
            super.dispatchDraw(canvas);
        }
    }

    public int findNearestLeapPanel(float x, float y) {
        return this.mWorkspaces.getCurrent().findNearestLeapPanel(x, y);
    }

    public View.OnTouchListener asTouchListener() {
        return this.mWorkspaceTouchListener;
    }

    @Override // android.view.View.OnTouchListener
    public boolean onTouch(View from, MotionEvent ev) {
        if (SettingUtil.isTabletDevice()) {
            this.mIndexOfButtonbarTouch = this.mButtonBarHandler.getButtonBarLongClickX(ev.getX(), ev.getY());
            this.mMotionEvent = ev;
        }
        this.mSnapInfo.isSnap = false;
        this.mTouchByDelegate = true;
        boolean handled = dispatchTouchEvent(ev);
        this.mTouchByDelegate = false;
        return handled;
    }

    public void updateMotionDown(float x, float y) {
        this.mLastMotionDownX = x;
        this.mLastMotionDownY = y;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void fakeTouchDown() {
        long time = SystemClock.uptimeMillis();
        onTouch((View) this, MotionEvent.obtain(time, time, 0, this.mLastMotionDownX, this.mLastMotionDownY, 0));
    }

    public boolean dispatchTouchEvent(MotionEvent ev) {
        boolean handled;
        if (this.mTouchByDelegate) {
            if (this.mIsStartDrag && (ev.getAction() == 3 || ev.getAction() == 1)) {
                if (DEBUG_TOUCH) {
                    Logger.d(LOG_TAG, "motionevent cancel");
                }
                return true;
            }
            handled = super.dispatchTouchEvent(ev);
            if (DEBUG_TOUCH) {
                Log.d(LOG_TAG, "dispatch touch " + ev.getAction() + ":(" + ev.getX() + ", " + ev.getY() + "), is handled? " + handled);
            }
        } else {
            handled = false;
            if (DEBUG_TOUCH) {
                Log.d(LOG_TAG, "ignore touch:false");
            }
        }
        return handled;
    }

    public boolean onInterceptTouchEvent(MotionEvent ev) {
        View focus = getFocusedChild();
        if (focus != null && ev.getAction() == 0) {
            requestFocus();
        }
        boolean ret = super.onInterceptTouchEvent(ev);
        if (DEBUG_TOUCH) {
            Log.d(LOG_TAG, "intercept touch:" + ret);
            return false;
        }
        return false;
    }

    public boolean onTouchEvent(MotionEvent ev) {
        boolean ret = super.onTouchEvent(ev);
        if (DEBUG_TOUCH) {
            Log.d(LOG_TAG, "on touch:" + ret);
            return false;
        }
        return false;
    }

    @Override // com.htc.launcher.Workspace.OnSlideListener
    public void onFling(int x, int begin, int end) {
        this.mIsFlingMode = true;
        if (localLOGD) {
            Log.d(LOG_TAG, "FxWorkspace.onFling(" + x + ", " + begin + ", " + end + ")");
        }
        if (Math.abs(begin - end) > 480) {
            this.mZoomRatio = (x - begin) / (end - begin);
        } else if (this.mZoomRatio != 0.0f) {
            if (this.mLastZoomRatio >= 0.5f) {
                this.mZoomRatio = (((x - begin) * (1.0f - this.mLastZoomRatio)) / (end - begin)) + this.mLastZoomRatio;
            } else {
                this.mZoomRatio = ((x - end) * this.mLastZoomRatio) / (begin - end);
            }
        }
    }

    @Override // com.htc.launcher.Workspace.OnSlideListener
    public void onTouch(MotionEvent ev, int x) {
        if (this.mIsFlingMode) {
            this.mIsFlingMode = false;
            this.mLastZoomRatio = this.mZoomRatio;
        }
        if (ev.getAction() == 0) {
            this.mLastScrollX = (this.mCurrentScrollX / getWidth()) * getWidth();
        }
    }

    public FxWorkspaceClient getCurrentWorkspace() {
        return this.mWorkspaces.getCurrent();
    }

    public FxWorkspaceClient getAnotherWorkspace() {
        return this.mWorkspaces.getAnother();
    }

    static final class WorkspaceHolder {
        private FxWorkspaceClient mLandClient;
        private FxWorkspaceClient mPortClient;

        WorkspaceHolder(FxWorkspace fxworkspace, boolean twoOrientation) {
            if (twoOrientation) {
                this.mPortClient = new FxWorkspaceClient(fxworkspace, true, fxworkspace);
                this.mLandClient = new FxWorkspaceClient(fxworkspace, false, fxworkspace);
            } else if (FxWorkspace.isPortrait()) {
                this.mPortClient = new FxWorkspaceClient(fxworkspace, true, fxworkspace);
            } else {
                this.mLandClient = new FxWorkspaceClient(fxworkspace, false, fxworkspace);
            }
        }

        FxWorkspaceClient getCurrent() {
            return FxWorkspace.isPortrait() ? this.mPortClient : this.mLandClient;
        }

        FxWorkspaceClient getAnother() {
            return FxWorkspace.isPortrait() ? this.mLandClient : this.mPortClient;
        }
    }

    static final class ScreenHolder {
        private TimelineAnimation mFadeAnimation;
        private TimelineAnimation.OnCompleteListener mFadeCompleteListener = new TimelineAnimation.OnCompleteListener() { // from class: com.htc.android.rosie.home.fxcontrol.FxWorkspace.ScreenHolder.1
            @Override // com.htc.android.rosie.home.fxcontrol.TimelineAnimation.OnCompleteListener
            public void onCompleted(TimelineAnimation animation) {
                Logger.d(FxWorkspace.LOG_TAG, "[SCREEN_FADE] Screen[" + ScreenHolder.this.mFxScreen.getId() + "] Fade out animation complete");
                FxWorkspaceClient currentClient = FxWorkspace.sFxWorkspace.getCurrentWorkspace();
                currentClient.increseFadeOutAnimationCompleteCount();
                ScreenHolder.this.mFxScreen.onVisibilityChanged(false);
                animation.rewind();
                if (currentClient.getFadeOutAnimationCompleteCount() == SettingUtil.getScreenCount() - 1) {
                    FxWorkspace.sFxWorkspace.mLauncher.resetForSinkFadeOut();
                }
            }
        };
        FxSceneContainer mFxParent;
        final FxScreen mFxScreen;
        private Marker mLeftPanMarker;
        private FxTimelineControl mPanControl;
        private Marker mRightPanMarker;
        private TimelineAnimation mSensorAnimation;

        ScreenHolder(FxScreen fxScreen, TimelineAnimation sensor, FxTimelineControl panControl) {
            this.mFxScreen = fxScreen;
            setSensor(sensor);
            setPan(panControl);
        }

        boolean attachTo(FxSceneContainer parent) {
            if (FxWorkspace.localLOGD) {
                Log.d(FxWorkspace.LOG_TAG, "attach screen#" + this.mFxScreen.getId() + ":" + parent);
            }
            if (parent == null) {
                return false;
            }
            parent.setScene(this.mFxScreen.getScene());
            if (FxWorkspace.localLOGD) {
                Log.d(FxWorkspace.LOG_TAG, "[Rosie] attach screen#" + this.mFxScreen.getId() + ":" + parent);
            }
            this.mFxParent = parent;
            return true;
        }

        boolean detach() {
            if (this.mFxParent != null) {
                if (FxWorkspace.localLOGD) {
                    Log.d(FxWorkspace.LOG_TAG, "detach screen#" + this.mFxScreen.getId());
                }
                this.mFxParent.removeScene((FxObject) null);
                if (FxWorkspace.localLOGD) {
                    Log.d(FxWorkspace.LOG_TAG, "detach screen#" + this.mFxScreen.getId());
                }
                this.mFxParent = null;
                return true;
            }
            return false;
        }

        void setVisibility(boolean visible) {
            if (this.mFxParent != null) {
                this.mFxScreen.onVisibilityChanged(visible);
            }
        }

        boolean isFrozen() {
            return this.mFxScreen.getFrozen();
        }

        void freeze() {
            if (FxWorkspace.sFxWorkspace.shouldFreezeScreens() && !this.mFxScreen.getFrozen()) {
                if (FxWorkspace.sFxWorkspace.mFrozen) {
                    this.mFxScreen.onFreeze();
                } else {
                    this.mFxScreen.onFreeze(500L);
                }
            }
        }

        void freezeAsync() {
            if (FxWorkspace.sFxWorkspace.shouldFreezeScreens() && !this.mFxScreen.getFrozen()) {
                this.mFxScreen.onFreeze();
            }
        }

        void thaw() {
            thaw(true);
        }

        void thaw(boolean keepContent) {
            if (this.mFxScreen.getFrozen()) {
                this.mFxScreen.onThaw(keepContent);
            }
        }

        void pulseFreeze() {
            this.mFxScreen.onPulseFreeze();
        }

        void setSensorValue(float value, float speed) {
            if (this.mFxParent != null && this.mFxScreen != null) {
                float value2 = value * this.mSensorAnimation.getDuration();
                this.mSensorAnimation.setFrame(value2);
                this.mFxScreen.onTiltChanged(value2, speed);
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void setPanFrame(float value, PageSlideControl.Direction direction) {
            if (direction == PageSlideControl.Direction.RIGHT) {
                this.mPanControl.setFrame(((this.mLeftPanMarker.EndFrame - this.mLeftPanMarker.StartFrame) * value) + this.mLeftPanMarker.StartFrame);
            } else if (direction == PageSlideControl.Direction.LEFT) {
                this.mPanControl.setFrame(((this.mRightPanMarker.EndFrame - this.mRightPanMarker.StartFrame) * value) + this.mRightPanMarker.StartFrame);
            }
        }

        void setSensor(TimelineAnimation sensor) {
            this.mSensorAnimation = sensor;
        }

        void setFadeAnimation(TimelineAnimation fade) {
            this.mFadeAnimation = fade;
            this.mFadeAnimation.setComplateListener(this.mFadeCompleteListener);
        }

        void startFade() {
            if (this.mFadeAnimation != null) {
                this.mFadeAnimation.play();
            }
        }

        void stopFade(boolean rewind) {
            if (this.mFadeAnimation != null) {
                this.mFadeAnimation.stop();
                if (rewind) {
                    this.mFadeAnimation.rewind();
                }
                FxWorkspace.sFxWorkspace.getCurrentWorkspace().resetFadeOutAnimationCompleteCount();
            }
        }

        void setPan(FxTimelineControl panControl) {
            this.mPanControl = panControl;
            this.mLeftPanMarker = this.mPanControl.getMarker("PantoLeft");
            this.mRightPanMarker = this.mPanControl.getMarker("PantoRight");
        }

        void clearFxScreen() {
            this.mFxScreen.resetFxScene();
        }

        void updateFxScreen() {
            this.mFxScreen.updateFxScene();
        }

        void updateFxWidgets(Launcher launcher) {
            this.mFxScreen.reloadWidgetScene(launcher);
        }

        void updateScreenId(int id) {
            this.mFxScreen.updateId(id);
        }
    }

    public static void batchDetachScreens(List<ScreenHolder> screens) {
        if (screens != null && screens.size() != 0) {
            List<FxSceneContainer> parentList = new ArrayList<>();
            for (int i = 0; i < screens.size(); i++) {
                ScreenHolder screen = screens.get(i);
                if (screen.mFxParent != null) {
                    parentList.add(screen.mFxParent);
                    screen.mFxParent = null;
                }
            }
            int N = parentList.size();
            if (N > 0) {
                FxSceneContainer[] parents = (FxSceneContainer[]) parentList.toArray(new FxSceneContainer[N]);
                FxObject[] fxObjects = new FxObject[N];
                long start = System.currentTimeMillis();
                FxSceneContainer.batchRemoveScenes(parents, fxObjects);
                if (localLOGD) {
                    Logger.d(SettingUtil.PERFORMANCE_TAG, "batchRemoveScenes " + (System.currentTimeMillis() - start));
                }
                if (localLOGD) {
                    Log.d(LOG_TAG, "batchDetachScreens");
                }
            }
        }
    }

    public static void batchAttachScreens(List<FxSceneContainer> containers, List<ScreenHolder> screens) {
        if (screens != null && screens.size() != 0 && containers != null && containers.size() != 0 && screens.size() == containers.size()) {
            int N = screens.size();
            FxScene[] fxScenes = new FxScene[N];
            FxSceneContainer[] fxSceneContainers = new FxSceneContainer[N];
            for (int i = 0; i < N; i++) {
                ScreenHolder screen = screens.get(i);
                if (screen.mFxParent != null) {
                    Log.w(LOG_TAG, "screen " + i + " already have a parent");
                }
                fxScenes[i] = screen.mFxScreen.getScene();
                fxSceneContainers[i] = containers.get(i);
                screen.mFxParent = containers.get(i);
            }
            long start = System.currentTimeMillis();
            FxSceneContainer.batchSetScenes(fxSceneContainers, fxScenes);
            if (localLOGD) {
                Logger.d(SettingUtil.PERFORMANCE_TAG, "batchSetScenes " + (System.currentTimeMillis() - start));
            }
            if (localLOGD) {
                Log.d(LOG_TAG, "batchAttachScreens");
            }
        }
    }

    public void setPanFrame(float value) {
        for (ScreenHolder holder : this.mWorkspaces.getCurrent().getScreens()) {
            holder.setPanFrame(value, this.mDirection);
        }
    }

    public void setPageSlideZFrame(int begin, int end, int screenWidth, int scrollX) {
        this.mWorkspaces.getCurrent().getPageSlideZControl().setFrame(begin, end, screenWidth, scrollX);
    }

    class FxPageSinkControl implements IPageSinkControl {
        FxPageSinkControl() {
        }

        @Override // com.htc.android.rosie.home.fxcontrol.IPageSinkControl
        public void startSink(float extent) {
            FxWorkspace.this.mWorkspaces.getCurrent().getPageSinkControl().startSink(extent);
        }

        @Override // com.htc.android.rosie.home.fxcontrol.IPageSinkControl
        public void playSink(float speed) {
            FxWorkspace.this.mWorkspaces.getCurrent().getPageSinkControl().playSink(speed);
        }

        @Override // com.htc.android.rosie.home.fxcontrol.IPageSinkControl
        public void reset() {
            FxWorkspace.this.mWorkspaces.getCurrent().getPageSinkControl().reset();
        }

        @Override // com.htc.android.rosie.home.fxcontrol.IPageSinkControl
        public void setScrollProgress(float progress) {
            FxWorkspace.this.mWorkspaces.getCurrent().getPageSinkControl().setScrollProgress(progress);
        }

        @Override // com.htc.android.rosie.home.fxcontrol.IPageSinkControl
        public void startRise() {
            FxWorkspace.this.mWorkspaces.getCurrent().getPageSinkControl().startRise();
        }

        @Override // com.htc.android.rosie.home.fxcontrol.IPageSinkControl
        public boolean isSinking() {
            return FxWorkspace.this.mWorkspaces.getCurrent().getPageSinkControl().isSinking();
        }

        @Override // com.htc.android.rosie.home.fxcontrol.IPageSinkControl
        public float getSink() {
            return FxWorkspace.this.mWorkspaces.getCurrent().getPageSinkControl().getSink();
        }
    }

    public IPageSinkControl getPageSinkControl() {
        if (this.mSinkControl == null) {
            this.mSinkControl = new FxPageSinkControl();
        }
        return this.mSinkControl;
    }

    public static boolean isPortrait() {
        return sIsPortrait;
    }

    private void updateOrientation(Configuration newConfig) {
        sIsPortrait = newConfig.orientation == 1;
    }

    static class PageLeapControl implements LeapController.LeapAnimationPlayer, LeapController.LeapListener {
        private static final String PAGE_PREFIX = "Main_0";
        private static final String ZOOM_IN_SUFFIX = "_OUT";
        private static final String ZOOM_OUT_SUFFIX = "_IN";
        private FxTimelineControl mFxPageLeap;
        private Marker[] mZoomInMarkers;
        private Marker[] mZoomOutMarkers;

        public PageLeapControl(FxTimelineControl pageLeapControl) {
            setTimelineControl(pageLeapControl);
        }

        public void setTimelineControl(FxTimelineControl pageLeapControl) {
            this.mFxPageLeap = pageLeapControl;
            initPageLeapControl(SettingUtil.getScreenCount());
        }

        private void initPageLeapControl(int pageCount) {
            this.mZoomOutMarkers = new Marker[pageCount];
            this.mZoomInMarkers = new Marker[pageCount];
            for (int i = 0; i < pageCount; i++) {
                this.mZoomOutMarkers[i] = this.mFxPageLeap.getMarker(PAGE_PREFIX + i + ZOOM_OUT_SUFFIX);
                this.mZoomInMarkers[i] = this.mFxPageLeap.getMarker(PAGE_PREFIX + i + ZOOM_IN_SUFFIX);
            }
        }

        @Override // com.htc.launcher.LeapController.LeapListener
        public void beginLeap(int selectPage) {
            FxWorkspace.sFxWorkspace.mIsLeapMode = true;
            FxWorkspace.sFxWorkspace.mWorkspaces.getCurrent().getPageLeapControl().setZoomOutAnimationProgress(selectPage, 0, 0.0f, FxWorkspace.sFxWorkspace.mContext.getResources().getInteger(R.integer.rosie_width) * selectPage);
            FxWorkspace.sFxWorkspace.switchMode(1, 0);
            FxWorkspace.sFxWorkspace.showAllScreens();
        }

        @Override // com.htc.launcher.LeapController.LeapListener
        public void endLeap(int selectPage) {
            FxWorkspace.sFxWorkspace.switchMode(0, 0);
            FxWorkspace.sFxWorkspace.changeScreensVisibility(true);
        }

        @Override // com.htc.launcher.LeapController.LeapListener
        public void onAnimationStateChanged(boolean playing, LeapController.ZoomDirection direction) {
            FxScene leapRearrangeScene = FxWorkspace.sFxWorkspace.mWorkspaces.getCurrent().getLeapRearrangeScene();
            if (leapRearrangeScene != null) {
                if (FxWorkspace.localLOGD) {
                    Log.d(FxWorkspace.LOG_TAG, "onAnimationStateChanged(" + playing + "," + direction + ")");
                }
                if (!playing) {
                    if (direction == LeapController.ZoomDirection.ZOOM_OUT) {
                        FxWorkspace.sFxWorkspace.fromLeapToLeapRearrange();
                    }
                } else if (direction == LeapController.ZoomDirection.ZOOM_IN) {
                    FxWorkspace.sFxWorkspace.fromLeapRearrangeToLeap();
                }
            }
        }

        @Override // com.htc.launcher.LeapController.LeapAnimationPlayer
        public void setZoomInAnimationProgress(int selectPage, int action, float progress, int virtualScrollX) {
            if (FxWorkspace.sFxWorkspace.mIsLeapMode) {
                Marker marker = this.mZoomInMarkers[selectPage];
                this.mFxPageLeap.setFrame(((((marker.EndFrame - marker.StartFrame) + 1) * progress) / 1000.0f) + marker.StartFrame);
            }
        }

        @Override // com.htc.launcher.LeapController.LeapAnimationPlayer
        public void setZoomOutAnimationProgress(int selectPage, int action, float progress, int virtualScrollX) {
            if (FxWorkspace.sFxWorkspace.mIsLeapMode && selectPage >= 0 && selectPage < this.mZoomOutMarkers.length) {
                Marker marker = this.mZoomOutMarkers[selectPage];
                this.mFxPageLeap.setFrame(((((marker.EndFrame - marker.StartFrame) + 1) * progress) / 1000.0f) + marker.StartFrame);
            }
        }

        @Override // com.htc.launcher.LeapController.LeapListener
        public void onLongPress() {
            if (FxWorkspace.localLOGD) {
                Log.d(FxWorkspace.LOG_TAG, "PageLeapControl.onLongPress()");
            }
        }
    }

    public LeapController.LeapAnimationPlayer getLeapAnimationPlayer() {
        if (this.mLeapPlayer == null) {
            this.mLeapPlayer = new FxLeapPlayer();
        }
        return this.mLeapPlayer;
    }

    public LeapController.LeapListener getLeapListener() {
        if (this.mLeapListener == null) {
            this.mLeapListener = new FxLeapListener();
        }
        return this.mLeapListener;
    }

    class FxLeapListener implements LeapController.LeapListener {
        FxLeapListener() {
        }

        @Override // com.htc.launcher.LeapController.LeapListener
        public void beginLeap(int selectPage) {
            FxWorkspace.this.mLauncher.setBottomBarAreaVisibility(4);
            FxWorkspace.this.mWorkspaces.getCurrent().getPageLeapControl().beginLeap(selectPage);
            FxWorkspace.this.mWorkspaces.getCurrent().getNavigationBar().beginLeap(selectPage);
        }

        @Override // com.htc.launcher.LeapController.LeapListener
        public void endLeap(int selectPage) {
            FxWorkspace.this.mLauncher.setBottomBarAreaVisibility(0);
            FxWorkspace.this.mWorkspaces.getCurrent().getNavigationBar().endLeap(selectPage);
            FxWorkspace.this.mWorkspaces.getCurrent().getPageLeapControl().endLeap(selectPage);
        }

        @Override // com.htc.launcher.LeapController.LeapListener
        public void onAnimationStateChanged(boolean playing, LeapController.ZoomDirection direction) {
            FxWorkspace.this.mWorkspaces.getCurrent().getPageLeapControl().onAnimationStateChanged(playing, direction);
        }

        @Override // com.htc.launcher.LeapController.LeapListener
        public void onLongPress() {
            FxWorkspace.this.mWorkspaces.getCurrent().getPageLeapControl().onLongPress();
        }
    }

    class FxLeapPlayer implements LeapController.LeapAnimationPlayer {
        FxLeapPlayer() {
        }

        @Override // com.htc.launcher.LeapController.LeapAnimationPlayer
        public void setZoomInAnimationProgress(int selectPage, int action, float ratio, int virtualScrollX) {
            FxWorkspace.this.mWorkspaces.getCurrent().getPageLeapControl().setZoomInAnimationProgress(selectPage, action, ratio, virtualScrollX);
        }

        @Override // com.htc.launcher.LeapController.LeapAnimationPlayer
        public void setZoomOutAnimationProgress(int selectPage, int action, float ratio, int virtualScrollX) {
            FxWorkspace.this.mWorkspaces.getCurrent().getPageLeapControl().setZoomOutAnimationProgress(selectPage, action, ratio, virtualScrollX);
        }
    }

    static final class NavigationBar implements LeapController.LeapListener {
        private boolean isButtonShow;
        private boolean isFunctionShow;
        private final FxTimelineControl mBarTimeline;
        private boolean mFrozen;
        private final TimelineAnimation mHideButtonBarAnim;
        private final TimelineAnimation mHideFunctionBarAnim;
        private final TimelineAnimation mShowButtonBarAnim;
        private final TimelineAnimation mShowFunctionBarAnim;

        private NavigationBar(FxTimelineControl barTimeline, TimelineAnimation showButtonBarAnim, TimelineAnimation hideButtonBarAnim, TimelineAnimation showFunctionBarAnim, TimelineAnimation hideFunctionBarAnim) {
            this.mFrozen = true;
            this.isButtonShow = true;
            this.isFunctionShow = true;
            this.mBarTimeline = barTimeline;
            this.mShowButtonBarAnim = showButtonBarAnim;
            this.mHideButtonBarAnim = hideButtonBarAnim;
            this.mShowFunctionBarAnim = showFunctionBarAnim;
            this.mHideFunctionBarAnim = hideFunctionBarAnim;
        }

        public void showButtonBar() {
            this.mShowButtonBarAnim.play();
            this.isButtonShow = true;
        }

        public void hideButtonBar() {
            if (this.isButtonShow) {
                this.mHideButtonBarAnim.play();
                this.isButtonShow = false;
            }
        }

        public void showFunctionBar() {
            this.mShowFunctionBarAnim.play();
            this.isFunctionShow = true;
        }

        public void hideFunctionBar() {
            if (this.isFunctionShow) {
                this.mHideFunctionBarAnim.play();
                this.isFunctionShow = false;
            }
        }

        public void freeze(boolean toFreeze) {
            if (FxWorkspace.localLOGD) {
                Logger.d(FxWorkspace.LOG_TAG, "freeze FunctionBar: " + toFreeze);
            }
            if (this.mFrozen != toFreeze) {
                this.mFrozen = toFreeze;
                if (this.mBarTimeline != null) {
                    if (this.mFrozen) {
                        this.mBarTimeline.freeze();
                    } else {
                        this.mBarTimeline.thaw();
                    }
                }
            }
        }

        static final class Builder {
            private FxTimelineControl mBarTimeline;
            private Marker mHideButtonBarAnimMarker;
            private TimelineAnimation.OnCompleteListener mHideButtonBarCompleteListener;
            private Marker mHideFunctionBarAnimMarker;
            private TimelineAnimation.OnCompleteListener mHideFunctionBarCompleteListener;
            private Marker mShowButtonBarAnimMarker;
            private TimelineAnimation.OnCompleteListener mShowButtonBarCompleteListener;
            private Marker mShowFunctionBarAnimMarker;
            private TimelineAnimation.OnCompleteListener mShowFunctionBarCompleteListener;
            private FxTimelineControl mWorkspaceTimeline;

            Builder() {
            }

            Builder setTimeline(FxTimelineControl workspace, FxTimelineControl bar) {
                this.mWorkspaceTimeline = workspace;
                this.mBarTimeline = bar;
                return this;
            }

            Builder setShowButtonBarMarker(Marker showButtonBarMarker, TimelineAnimation.OnCompleteListener onCompleteListener) {
                this.mShowButtonBarAnimMarker = showButtonBarMarker;
                this.mShowButtonBarCompleteListener = onCompleteListener;
                return this;
            }

            Builder setHideButtonBarMarker(Marker hideButtonBarMarker, TimelineAnimation.OnCompleteListener onCompleteListener) {
                this.mHideButtonBarAnimMarker = hideButtonBarMarker;
                this.mHideButtonBarCompleteListener = onCompleteListener;
                return this;
            }

            Builder setShowFunctionBarMarker(Marker showFunctionBarMarker, TimelineAnimation.OnCompleteListener onCompleteListener) {
                this.mShowFunctionBarAnimMarker = showFunctionBarMarker;
                this.mShowFunctionBarCompleteListener = onCompleteListener;
                return this;
            }

            Builder setHideFunctionBarMarker(Marker hideFunctionBarMarker, TimelineAnimation.OnCompleteListener onCompleteListener) {
                this.mHideFunctionBarAnimMarker = hideFunctionBarMarker;
                this.mHideFunctionBarCompleteListener = onCompleteListener;
                return this;
            }

            NavigationBar build() {
                TimelineAnimation showButtonBar = new TimelineAnimation(this.mWorkspaceTimeline, this.mShowButtonBarAnimMarker);
                if (this.mShowButtonBarCompleteListener != null) {
                    showButtonBar.setComplateListener(this.mShowButtonBarCompleteListener);
                }
                TimelineAnimation hideButtonBar = new TimelineAnimation(this.mWorkspaceTimeline, this.mHideButtonBarAnimMarker);
                if (this.mHideButtonBarCompleteListener != null) {
                    hideButtonBar.setComplateListener(this.mHideButtonBarCompleteListener);
                }
                TimelineAnimation showFunctionBar = new TimelineAnimation(this.mWorkspaceTimeline, this.mShowFunctionBarAnimMarker);
                if (this.mShowFunctionBarCompleteListener != null) {
                    showFunctionBar.setComplateListener(this.mShowFunctionBarCompleteListener);
                }
                TimelineAnimation hideFunctionBar = new TimelineAnimation(this.mWorkspaceTimeline, this.mHideFunctionBarAnimMarker);
                if (this.mHideFunctionBarCompleteListener != null) {
                    hideFunctionBar.setComplateListener(this.mHideFunctionBarCompleteListener);
                }
                this.mWorkspaceTimeline.setFrame(this.mShowFunctionBarAnimMarker.StartFrame);
                return new NavigationBar(this.mBarTimeline, showButtonBar, hideButtonBar, showFunctionBar, hideFunctionBar);
            }
        }

        @Override // com.htc.launcher.LeapController.LeapListener
        public void beginLeap(int selectPage) {
            hideFunctionBar();
        }

        @Override // com.htc.launcher.LeapController.LeapListener
        public void endLeap(int selectPage) {
            showFunctionBar();
        }

        @Override // com.htc.launcher.LeapController.LeapListener
        public void onAnimationStateChanged(boolean playing, LeapController.ZoomDirection direction) {
        }

        @Override // com.htc.launcher.LeapController.LeapListener
        public void onLongPress() {
        }
    }

    @Override // com.htc.launcher.DragController.DragListener
    public void onPreDragStart(Draggee draggee, DragSource source, Object info, int dragAction) {
        this.mWorkspaces.getCurrent().onStartDrag();
        this.mWorkspaces.getCurrent().getDropBar().onDragStart(draggee, source, info, dragAction);
        this.mWorkspaces.getCurrent().getScreen(this.mCurrentScreen).freezeChildren();
        this.mIsStartDrag = true;
        this.mWorkspaces.getCurrent().getNavigationBar().hideButtonBar();
        if (SettingUtil.isTabletDevice()) {
            this.mDragStartRunnable = new Runnable() { // from class: com.htc.android.rosie.home.fxcontrol.FxWorkspace.1
                @Override // java.lang.Runnable
                public void run() {
                    FxWorkspace.this.mWorkspaces.getCurrent().showEditControls(true);
                    FxWorkspaceClient other = FxWorkspace.this.mWorkspaces.getAnother();
                    if (other != null) {
                        other.showEditControls(true);
                    }
                    FxWorkspace.this.mDragStartRunnable = null;
                }
            };
            postDelayed(this.mDragStartRunnable, 200L);
        }
        for (DropZone z : this.mWorkspaces.getCurrent().getDropBar().getDropZones()) {
            if (z != null && z.getTarget() != null) {
                z.getTarget().resetClaimDrop();
            }
        }
    }

    @Override // com.htc.launcher.DragController.DragListener
    public void onPostDragStart(Draggee draggee, DragSource source, Object info, int dragAction) {
        for (int i = 0; i < SettingUtil.getScreenCount(); i++) {
            this.mWorkspaces.getCurrent().getScreens().get(i).mFxScreen.loadOccupiedMaps();
        }
    }

    @Override // com.htc.launcher.DragController.DragListener
    public void onDragEnd() {
        if (SettingUtil.isTabletDevice()) {
            this.mWorkspaces.getCurrent().showEditControls(false);
            FxWorkspaceClient other = this.mWorkspaces.getAnother();
            if (other != null) {
                other.showEditControls(false);
            }
        }
        this.mWorkspaces.getCurrent().onEndDrag();
        this.mWorkspaces.getCurrent().getNavigationBar().showButtonBar();
        if (this.mDragStartRunnable != null) {
            removeCallbacks(this.mDragStartRunnable);
            this.mDragStartRunnable = null;
        }
        this.mWorkspaces.getCurrent().getScreen(this.mCurrentScreen).onDragEnd();
        for (int i = 0; i < SettingUtil.getScreenCount(); i++) {
            this.mWorkspaces.getCurrent().getScreen(i).thawChildren();
            if (!isPortrait()) {
                this.mWorkspaces.getCurrent().getScreen(i).setBackPanelMode(0);
            }
        }
        this.mIsStartDrag = false;
    }

    private void updateDropTargets() {
        for (DropZone z : this.mWorkspaces.getCurrent().getDropBar().getDropZones()) {
            if (z != null && z.getTarget() != null) {
                z.updateBounds();
            }
        }
    }

    public List<DropTarget> getDropTargets() {
        List<DropTarget> drops = new ArrayList<>();
        for (DropZone z : this.mWorkspaces.getCurrent().getDropBar().getDropZones()) {
            if (z != null && z.getTarget() != null) {
                drops.add(z.getTarget());
            }
        }
        return drops;
    }

    public void updateFxWorkspace(Configuration newConfiguration) {
        updateOrientation(newConfiguration);
        freeze(true);
        this.mWorkspaces.getCurrent().detach();
        FxWorkspaceClient prevClient = this.mWorkspaces.getAnother();
        if (prevClient != null) {
            prevClient.detach();
        }
        updateFxScreen();
        switch (this.mMode) {
            case 0:
                show();
                if (localLOGD) {
                    Log.d(LOG_TAG, "addScene: SlideScene");
                }
                this.mWorkspaces.getCurrent().attachTo(this, 0);
                break;
            case 1:
                if (localLOGD) {
                    Log.d(LOG_TAG, "addScene: LeapScene");
                }
                this.mWorkspaces.getCurrent().attachTo(this, 1);
                break;
            case 2:
                if (localLOGD) {
                    Log.d(LOG_TAG, "addScene: LeapRearrangeScene");
                }
                this.mWorkspaces.getCurrent().attachTo(this, 2);
                break;
        }
        if (SettingUtil.isSupportLandscape()) {
            updateDropTargets();
        }
        resetQuickScroll();
        getPageSinkControl().reset();
        freeze(false);
    }

    public void showTipBubble() {
        if (localLOGD) {
            Log.d(LOG_TAG, "showTipBubble");
        }
        for (int i = 0; i < SettingUtil.getScreenCount(); i++) {
            this.mWorkspaces.getCurrent().getScreens().get(i).mFxScreen.setBackPanelMode(0);
        }
    }

    public void hideTipBubble() {
        if (localLOGD) {
            Log.d(LOG_TAG, "hideTipBubble");
        }
        for (int i = 0; i < SettingUtil.getScreenCount(); i++) {
            this.mWorkspaces.getCurrent().getScreens().get(i).mFxScreen.setBackPanelMode(2);
        }
    }

    public void bindListenerTipBubble(View.OnClickListener listener) {
    }

    private void loadFxWorkspace(boolean currentOnly) {
        if (localLOGD) {
            Log.d("Rotate.Performance", "+loadFxWorkspace: " + currentOnly);
        }
        SettingUtil.setSceneRoot(isPortrait());
        if (SettingUtil.isTabletDevice()) {
            this.mWorkspaces = new WorkspaceHolder(this, true);
        } else {
            this.mWorkspaces = new WorkspaceHolder(this, false);
        }
        initSceneAndControlls();
        int N = getChildCount();
        for (int i = 0; i < N; i++) {
            View v = getChildAt(i);
            if (v instanceof SurfaceView) {
                v.setWillNotDraw(false);
            }
        }
        setFocusable(true);
        setFocusableInTouchMode(true);
        populateScreens(currentOnly);
        if (SettingUtil.isTabletDevice()) {
            this.mButtonBarHandler.setNullDataForButtonBar();
        }
        if (localLOGD) {
            Log.d("Rotate.Performance", "-loadFxWorkspace");
        }
    }

    public NavigationBar getNavigationBar() {
        return this.mWorkspaces.getCurrent().getNavigationBar();
    }

    public void updateFxScreen() {
        for (int i = 0; i < SettingUtil.getScreenCount(); i++) {
            this.mWorkspaces.getCurrent().getScreens().get(i).updateFxWidgets(this.mLauncher);
        }
    }

    public void unlockAnimation() {
        if (this.mWorkspaces.getCurrent().getPageSlideControl() != null) {
            this.mWorkspaces.getCurrent().getPageSlideControl().unlockAnimation();
            if (isPortrait()) {
                this.mWorkspaces.getCurrent().stopFade(true);
                this.mWorkspaces.getCurrent().showAllScreens();
            }
            show();
        }
    }

    public void playSink() {
        IPageSinkControl sinkControl = this.mWorkspaces.getCurrent().getPageSinkControl();
        if (sinkControl != null) {
            sinkControl.playSink(1.0f);
        }
    }

    public void resetSink() {
        IPageSinkControl sinkControl = this.mWorkspaces.getCurrent().getPageSinkControl();
        if (sinkControl != null) {
            sinkControl.reset();
        }
    }

    public void prepareUnlockAnimation(boolean useCache) {
        this.mWorkspaces.getCurrent().prepareUnlockAnimation(useCache);
    }

    public void setUnlockframeFlag(boolean set) {
        this.mWorkspaces.getCurrent().setUnlockframeFlag(set);
        if (this.mWorkspaces.getAnother() != null) {
            this.mWorkspaces.getAnother().setUnlockframeFlag(set);
        }
    }

    public boolean checkUnlockFrameSet() {
        return this.mWorkspaces.getCurrent().checkUnlockFrameSet();
    }

    public void setUnlockAnimationListener(IUnlockAnimationListener unlockAnimationListener) {
        this.mUnlockAnimationListener = unlockAnimationListener;
        if (this.mWorkspaces.getCurrent().getPageSlideControl() != null) {
            this.mWorkspaces.getCurrent().getPageSlideControl().setUnlockAnimationListener(this.mUnlockAnimationListener);
        }
        if (this.mWorkspaces.getAnother() != null && this.mWorkspaces.getAnother().getPageSlideControl() != null) {
            this.mWorkspaces.getAnother().getPageSlideControl().setUnlockAnimationListener(this.mUnlockAnimationListener);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void fromLeapToLeapRearrange() {
        if (this.mMode == 2) {
            Log.e(LOG_TAG, "[ROSIE_DEBUG] fromLeapToLeapRearrange() Mode is already LeapRearrange!");
        } else {
            switchMode(2, 0);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void fromLeapRearrangeToLeap() {
        if (this.mMode == 1) {
            Log.e(LOG_TAG, "[ROSIE_DEBUG] fromLeapToLeapRearrange() Mode is already Leap!");
        } else {
            switchMode(1, 0);
        }
    }

    boolean unlockFadeBackPanels() {
        if (this.mWorkspaces.getCurrent().getScreens() == null) {
            return false;
        }
        boolean canPlayAnimation = true;
        synchronized (this.mWorkspaces.getCurrent().getScreens()) {
            for (ScreenHolder sh : this.mWorkspaces.getCurrent().getScreens()) {
                if (!sh.mFxScreen.fadeBackPanel(10)) {
                    canPlayAnimation = false;
                }
            }
        }
        return canPlayAnimation;
    }

    int getCurrentScreen() {
        return this.mCurrentScreen;
    }

    int getScreenCount() {
        return SettingUtil.getScreenCount();
    }

    List<ScreenHolder> getScreens() {
        return this.mWorkspaces.getCurrent().getScreens();
    }

    public void updateScreenIndices(int[] originalIndices) {
        List<ScreenHolder> screenCaches = new ArrayList<>();
        List<TimelineAnimation> sensorAnimationCaches = new ArrayList<>();
        List<TimelineAnimation> fadeAnimationCaches = new ArrayList<>();
        for (ScreenHolder holder : this.mWorkspaces.getCurrent().getScreens()) {
            screenCaches.add(holder);
            sensorAnimationCaches.add(holder.mSensorAnimation);
            fadeAnimationCaches.add(holder.mFadeAnimation);
        }
        for (int i = 0; i < getScreens().size(); i++) {
            ScreenHolder holder2 = screenCaches.get(originalIndices[i]);
            if (localLOGD) {
                Log.d(LOG_TAG, "[ROSIE_DEBUG] set " + originalIndices[i] + " to " + i);
            }
            this.mWorkspaces.getCurrent().getScreens().set(i, holder2);
            holder2.updateScreenId(i);
            holder2.setSensor(sensorAnimationCaches.get(i));
            holder2.setFadeAnimation(fadeAnimationCaches.get(i));
            this.mLauncher.getDesktopItemController().updateWidgetContainerId(holder2.mFxScreen.getFxItems(), i);
        }
        screenCaches.clear();
        sensorAnimationCaches.clear();
        fadeAnimationCaches.clear();
        FxWorkspaceClient other = this.mWorkspaces.getAnother();
        if (other != null) {
            for (ScreenHolder holder3 : other.getScreens()) {
                screenCaches.add(holder3);
                sensorAnimationCaches.add(holder3.mSensorAnimation);
                fadeAnimationCaches.add(holder3.mFadeAnimation);
            }
            for (int i2 = 0; i2 < getScreens().size(); i2++) {
                ScreenHolder holder4 = screenCaches.get(originalIndices[i2]);
                if (localLOGD) {
                    Log.d(LOG_TAG, "[ROSIE_DEBUG] set " + originalIndices[i2] + " to " + i2);
                }
                other.getScreens().set(i2, holder4);
                holder4.updateScreenId(i2);
                holder4.setSensor(sensorAnimationCaches.get(i2));
                holder4.setFadeAnimation(fadeAnimationCaches.get(i2));
                this.mLauncher.getDesktopItemController().updateWidgetContainerId(holder4.mFxScreen.getFxItems(), i2);
            }
        }
        this.mLauncher.getDesktopItemController().onLeapRearrangeComplete(originalIndices);
    }

    public final class ButtonBarHandler {
        public ButtonBarHandler() {
        }

        public void addAndBindButtonBarItem(ApplicationInfo app) {
            try {
                ApplicationInfo newApplicationInfo = new ApplicationInfo(app);
                setDynamicImageAndText(newApplicationInfo, app.cellX);
                FxWorkspace.this.mButtonbarCount[newApplicationInfo.cellX] = true;
                FxWorkspace.this.mApplicationInfoSaved.set(newApplicationInfo.cellX, app);
                buttonBarImageTextVisibility(newApplicationInfo.cellX, true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public void addButtonBarAppOrShortcut(ApplicationInfo info, int indexOfButtonBar) {
            if (info == null) {
                Logger.e(FxWorkspace.LOG_TAG, "addButtonBarAppOrShortcut: info is null");
                return;
            }
            LauncherModel.addItemToDatabase(FxWorkspace.this.mLauncher, info, -100L, 0, indexOfButtonBar, 10, false);
            info.cellX = indexOfButtonBar;
            FxWorkspace.this.mApplicationInfoSaved.set(indexOfButtonBar, info);
            FxWorkspace.this.mButtonbarCount[indexOfButtonBar] = true;
            setDynamicImageAndText(info, indexOfButtonBar);
            buttonBarImageTextVisibility(indexOfButtonBar, true);
            FxWorkspace.this.mLauncher.resetMiddleButton();
            Launcher unused = FxWorkspace.this.mLauncher;
            Launcher.getModel().addButtonBarItem(info);
            FxWorkspace.this.mLauncher.update2DButtonBarViews();
            if (SettingUtil.isDoubleShot()) {
                FxWorkspaceClient current = FxWorkspace.this.mWorkspaces.getCurrent();
                Launcher unused2 = FxWorkspace.this.mLauncher;
                current.showMiddleBackgroundImageControls(Launcher.getModel().getButtonBarOccupied());
            }
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void buttonBarImageTextVisibility(int index, boolean show) {
            FxWorkspace.this.mWorkspaces.getCurrent().showCustomizeShortcut(index, show);
            FxWorkspace.this.mWorkspaces.getAnother().showCustomizeShortcut(index, show);
            String[] scope = show ? FxWorkspace.this.mScopeFull : FxWorkspace.this.mScopeEmpty;
            FxWorkspace.this.mWorkspaces.getCurrent().mButtonBarDropControl[index].setDragScope(scope);
            FxWorkspace.this.mWorkspaces.getAnother().mButtonBarDropControl[index].setDragScope(scope);
        }

        public void setNullDataForButtonBar() {
            if (SettingUtil.isTabletDevice()) {
                for (int i = 0; i < FxWorkspace.this.mButtonbarCount.length; i++) {
                    if (!FxWorkspace.this.mButtonbarCount[i]) {
                        buttonBarImageTextVisibility(i, false);
                        FxWorkspace.this.mApplicationInfoSaved.set(i, null);
                    }
                }
            }
        }

        public void removeAllItems() {
            if (SettingUtil.isTabletDevice()) {
                for (int i = 0; i < FxWorkspace.this.mButtonbarCount.length; i++) {
                    FxWorkspace.this.mButtonbarCount[i] = false;
                    buttonBarImageTextVisibility(i, false);
                    FxWorkspace.this.mApplicationInfoSaved.set(i, null);
                }
            }
        }

        public boolean getIsButtonBarNull(int x) {
            if (x < 0 || x >= FxWorkspace.this.mApplicationInfoSaved.size()) {
                return false;
            }
            return FxWorkspace.this.mApplicationInfoSaved.get(x) == null;
        }

        public void dropBackToButtonBar(ApplicationInfo appInfo, int index) {
            if (appInfo == null) {
                Logger.e(FxWorkspace.LOG_TAG, "dropBackToButtonBar when appInfo is null");
                return;
            }
            addButtonBarAppOrShortcut(appInfo, index);
            FxWorkspace.this.mLauncher.getDesktopItemController().poofFxItem();
            setTargetCantDrop();
        }

        public void setTargetCantDrop() {
            for (DropZone z : FxWorkspace.this.mWorkspaces.getCurrent().getDropBar().getDropZones()) {
                if (z != null && z.getTarget() != null) {
                    z.getTarget().acceptDrop = false;
                }
            }
        }

        public int getButtonBarLongClickX(float x, float y) {
            return FxWorkspace.this.mWorkspaces.getCurrent().getButtonBarLongClickX(x, y);
        }

        public void setDynamicImageAndText(ApplicationInfo info, int index) {
            FxWorkspace.this.mWorkspaces.getCurrent().updateCustomizeShortut(index, info);
            FxWorkspace.this.mWorkspaces.getAnother().updateCustomizeShortut(index, info);
        }

        public ApplicationInfo getButtonInfo(int index) {
            return (ApplicationInfo) FxWorkspace.this.mApplicationInfoSaved.get(index);
        }

        public void removeOriButtonInfo() {
            int indexX = FxWorkspace.this.mButtonBarHandler.getButtonBarLongClickX(FxWorkspace.this.mEvStartX, FxWorkspace.this.mEvStartY);
            if (indexX >= 0 && indexX < FxWorkspace.this.mApplicationInfoSaved.size()) {
                FxWorkspace.this.mApplicationInfoSaved.set(indexX, null);
                FxWorkspace.this.mButtonbarCount[indexX] = false;
                FxWorkspace.this.mButtonBarHandler.buttonBarImageTextVisibility(indexX, false);
            }
        }

        public void removeOriButtonInfo(int indexX) {
            if (indexX >= 0 && indexX < FxWorkspace.this.mApplicationInfoSaved.size()) {
                FxWorkspace.this.mApplicationInfoSaved.set(indexX, null);
                FxWorkspace.this.mButtonbarCount[indexX] = false;
                FxWorkspace.this.mButtonBarHandler.buttonBarImageTextVisibility(indexX, false);
            }
        }

        public int getButtonBarItemNum() {
            return FxWorkspace.this.mApplicationInfoSaved.size();
        }

        public void getMiddleButtonBarPosition(int[] pos, int clickPosition) {
            Resources res = FxWorkspace.this.getResources();
            pos[1] = res.getDimensionPixelSize(R.dimen.middle_left_btn_top);
            pos[3] = res.getDimensionPixelSize(R.dimen.middle_right_btn_bottom);
            if (clickPosition == 3) {
                pos[0] = res.getDimensionPixelSize(R.dimen.middle_left_btn_left);
                pos[2] = res.getDimensionPixelSize(R.dimen.middle_left_btn_right);
            } else if (clickPosition == 4) {
                pos[0] = res.getDimensionPixelSize(R.dimen.middle_left_btn_right);
                pos[2] = res.getDimensionPixelSize(R.dimen.middle_center_btn_right);
            } else if (clickPosition == 5) {
                pos[0] = res.getDimensionPixelSize(R.dimen.middle_center_btn_right);
                pos[2] = res.getDimensionPixelSize(R.dimen.middle_right_btn_right);
            }
        }
    }

    View prepareDragView(CharSequence name, Drawable icon) {
        TextView mDrag = new TextView(getContext());
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2);
        mDrag.setLayoutParams(lp);
        mDrag.setEnabled(false);
        mDrag.setGravity(17);
        mDrag.setText(name);
        mDrag.setTextColor(-1);
        mDrag.setTextSize(18.0f);
        if (icon != null) {
            icon = Utilities.createIconThumbnail(icon, this.mLauncher);
        }
        mDrag.setCompoundDrawablesWithIntrinsicBounds((Drawable) null, icon, (Drawable) null, (Drawable) null);
        if (this.mOffsetX == 0) {
            measureChildWithMargins(mDrag, 0, 0, 0, 0);
            this.mOffsetX = mDrag.getMeasuredWidth() / 2;
            this.mOffsetY = mDrag.getMeasuredHeight() / 2;
        }
        mDrag.layout(((int) this.mMotionEvent.getX()) - this.mOffsetX, ((int) this.mMotionEvent.getY()) - this.mOffsetY, ((int) this.mMotionEvent.getX()) + this.mOffsetX, ((int) this.mMotionEvent.getY()) + this.mOffsetY);
        if (!mDrag.isDrawingCacheEnabled()) {
            mDrag.setDrawingCacheEnabled(true);
            mDrag.buildDrawingCache();
        }
        return mDrag;
    }

    @Override // com.htc.launcher.DragSource
    public void setDragger(DragController dragger) {
        this.mDragger = dragger;
    }

    @Override // com.htc.launcher.DragSource
    public void onDropCompleted(DropTarget target, boolean success) {
        if (SettingUtil.isTabletDevice()) {
            if (success) {
                if (target != this) {
                    this.mButtonBarHandler.removeOriButtonInfo();
                } else if (this.mIndexOfButtonbarTouch >= 0 && this.mIndexOfButtonbarTouch <= 2 && getIsButtonBarNull(this.mIndexOfButtonbarTouch)) {
                    this.mButtonBarHandler.removeOriButtonInfo();
                }
            } else {
                this.mButtonBarHandler.dropBackToButtonBar(this.mAppInfoForDropBackButtonBar, this.mIndexOfButtonbarTouchStart);
            }
            this.mAppInfoForDropBackButtonBar = null;
            this.mIsLongClick = false;
            this.mTimeOfButtonBarLongclick = 0;
            this.mLauncher.mDesktopItemController.cleanUpFloatingFxItem();
            removeItem();
        }
    }

    @Override // android.view.View.OnLongClickListener
    public boolean onLongClick(View view) {
        if (SettingUtil.isTabletDevice()) {
            if (this.mIsLeapMode) {
                return true;
            }
            this.mIsLongClick = true;
            this.mIndexOfButtonbarTouchStart = this.mButtonBarHandler.getButtonBarLongClickX(this.mMotionEvent.getX(), this.mMotionEvent.getY());
            this.mEvStartX = (int) this.mMotionEvent.getX();
            this.mEvStartY = (int) this.mMotionEvent.getY();
            if (this.mIndexOfButtonbarTouchStart >= 0 && this.mIndexOfButtonbarTouchStart <= 2) {
                this.mMotionEvent.setAction(3);
                this.mTouchByDelegate = true;
                dispatchTouchEvent(this.mMotionEvent);
                this.mTouchByDelegate = false;
                if (getIsButtonBarNull(this.mIndexOfButtonbarTouchStart)) {
                    this.mLauncher.addButtonbarItems(this.mIndexOfButtonbarTouchStart);
                    this.mIsLongClick = false;
                } else {
                    this.mWorkspaces.getCurrent().mButtonBarDropControl[this.mIndexOfButtonbarTouchStart].setDragScope(this.mScopeEmpty);
                    ApplicationInfo applicationInfo = this.mApplicationInfoSaved.get(this.mIndexOfButtonbarTouch);
                    this.mAppInfoForDropBackButtonBar = this.mApplicationInfoSaved.get(this.mIndexOfButtonbarTouch);
                    if (applicationInfo == null) {
                        return false;
                    }
                    FxItem fxItem = (FxItem) applicationInfo.createItem(this.mLauncher, null);
                    View icon = prepareDragView(applicationInfo.title, applicationInfo.icon);
                    if (icon == null) {
                        Log.e(LOG_TAG, String.format("prepareDragView failed title:%s, icon:%s", applicationInfo.title, applicationInfo.icon));
                        return false;
                    }
                    icon.setTag(applicationInfo);
                    this.mButtonBarHandler.buttonBarImageTextVisibility(this.mIndexOfButtonbarTouchStart, false);
                    this.mApplicationInfoSaved.set(this.mIndexOfButtonbarTouchStart, null);
                    RectF bounds = this.mLauncher.getDesktopItemController().getExternalFloatingBounds(icon);
                    this.mLauncher.getDesktopItemController().startDragFxWidget(this, fxItem, bounds);
                }
            }
        }
        return false;
    }

    public boolean hasFreeRoom(int screen, FxScreen.LayoutParams layout) {
        return this.mWorkspaces.getCurrent().getScreens().get(screen).mFxScreen.hasFreeRoom(layout);
    }

    public void playPhoneAnim() {
    }

    public void stopPhoneAnim() {
    }

    public Bitmap captureScreenShot() {
        if (this.mFrozen) {
            return null;
        }
        Bitmap bmp = getViewObject().captureBackBuffer();
        return bmp;
    }

    public void addAndBindButtonBarItem(ApplicationInfo app) {
        if (SettingUtil.isTabletDevice()) {
            this.mButtonBarHandler.addAndBindButtonBarItem(app);
        }
    }

    public int getButtonBarLongClickX(float x, float y) {
        return this.mButtonBarHandler.getButtonBarLongClickX(x, y);
    }

    public boolean getIsButtonBarNull(int x) {
        return this.mButtonBarHandler.getIsButtonBarNull(x);
    }

    @Override // com.htc.android.rosie.home.fxcontrol.FxWorkspaceClient.IButtonListener
    public void onClick(int message) {
        this.mUiHandler.sendEmptyMessage(message);
    }

    private class UiHandler extends Handler {
        int[] pos;

        private UiHandler() {
            this.pos = new int[6];
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            if (FxWorkspace.localLOGD) {
                Log.d(FxWorkspace.LOG_TAG, "msg.what = " + msg.what);
            }
            switch (msg.what) {
                case 0:
                    FxWorkspace.this.mLauncher.onClickAllProgram();
                    break;
                case 1:
                    FxWorkspace.this.mLauncher.resetMiddleButton();
                    FxWorkspace.this.mLauncher.onClickAddtoHome(null);
                    SharedPreferences preferences = FxWorkspace.this.mContext.getSharedPreferences("launcher", 0);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putBoolean(Launcher.KEY_TUTORIAL_NOTICE, false);
                    editor.apply();
                    FxWorkspace.this.hideTipBubble();
                    break;
                case 2:
                    FxWorkspace.this.mLauncher.onClickPhone();
                    break;
                case 3:
                    FxWorkspace.this.mMiddleBtnCompleteRunnable = new Runnable() { // from class: com.htc.android.rosie.home.fxcontrol.FxWorkspace.UiHandler.1
                        @Override // java.lang.Runnable
                        public void run() {
                            ApplicationInfo info = (ApplicationInfo) FxWorkspace.this.mApplicationInfoSaved.get(0);
                            if (info != null && info.intent != null) {
                                FxWorkspace.this.mButtonBarHandler.getMiddleButtonBarPosition(UiHandler.this.pos, 3);
                                info.intent.setSourceBounds(new Rect(UiHandler.this.pos[0], UiHandler.this.pos[1], UiHandler.this.pos[2], UiHandler.this.pos[3]));
                                FxWorkspace.this.mLauncher.startActivitySafely(info.intent);
                            }
                            FxWorkspace.this.mMiddleBtnCompleteRunnable = null;
                        }
                    };
                    postDelayed(FxWorkspace.this.mMiddleBtnCompleteRunnable, 290L);
                    break;
                case 4:
                    FxWorkspace.this.mMiddleBtnCompleteRunnable = new Runnable() { // from class: com.htc.android.rosie.home.fxcontrol.FxWorkspace.UiHandler.2
                        @Override // java.lang.Runnable
                        public void run() {
                            ApplicationInfo info = (ApplicationInfo) FxWorkspace.this.mApplicationInfoSaved.get(1);
                            if (info != null && info.intent != null) {
                                FxWorkspace.this.mButtonBarHandler.getMiddleButtonBarPosition(UiHandler.this.pos, 4);
                                info.intent.setSourceBounds(new Rect(UiHandler.this.pos[0], UiHandler.this.pos[1], UiHandler.this.pos[2], UiHandler.this.pos[3]));
                                FxWorkspace.this.mLauncher.startActivitySafely(info.intent);
                            }
                            FxWorkspace.this.mMiddleBtnCompleteRunnable = null;
                        }
                    };
                    postDelayed(FxWorkspace.this.mMiddleBtnCompleteRunnable, 290L);
                    break;
                case 5:
                    FxWorkspace.this.mMiddleBtnCompleteRunnable = new Runnable() { // from class: com.htc.android.rosie.home.fxcontrol.FxWorkspace.UiHandler.3
                        @Override // java.lang.Runnable
                        public void run() {
                            ApplicationInfo info = (ApplicationInfo) FxWorkspace.this.mApplicationInfoSaved.get(2);
                            if (info != null && info.intent != null) {
                                FxWorkspace.this.mButtonBarHandler.getMiddleButtonBarPosition(UiHandler.this.pos, 5);
                                info.intent.setSourceBounds(new Rect(UiHandler.this.pos[0], UiHandler.this.pos[1], UiHandler.this.pos[2], UiHandler.this.pos[3]));
                                FxWorkspace.this.mLauncher.startActivitySafely(info.intent);
                            }
                            FxWorkspace.this.mMiddleBtnCompleteRunnable = null;
                        }
                    };
                    postDelayed(FxWorkspace.this.mMiddleBtnCompleteRunnable, 290L);
                    break;
            }
            super.handleMessage(msg);
        }
    }

    public void setEditModeListener(IEditModeListener editModeListener) {
        this.mWorkspaces.getCurrent().setEditModeListener(editModeListener);
        if (this.mWorkspaces.getAnother() != null) {
            this.mWorkspaces.getAnother().setEditModeListener(editModeListener);
        }
    }

    @Override // com.htc.launcher.Workspace.OnScrollStateChangedListener
    public void updateSnapInfo(int endScreen, int snapOffset) {
        this.mSnapInfo.end = endScreen;
        this.mSnapInfo.snapOffset = snapOffset;
    }

    public ArrayList<ApplicationInfo> removeButtonBarShortcut(String packageName) {
        if (this.mButtonBarHandler == null) {
            return null;
        }
        ArrayList<ApplicationInfo> appInfo = new ArrayList<>();
        for (int index = 0; index < this.mButtonBarHandler.getButtonBarItemNum(); index++) {
            ApplicationInfo info = this.mButtonBarHandler.getButtonInfo(index);
            if (info != null && info.intent.getComponent() != null && packageName.equals(info.intent.getComponent().getPackageName())) {
                this.mButtonBarHandler.removeOriButtonInfo(index);
                appInfo.add(info);
            }
        }
        return appInfo;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean shouldFreezeScreens() {
        return !this.mDidRelinquishScreenCache;
    }

    public void onLowMemory() {
        List<ScreenHolder> screens = this.mWorkspaces.getCurrent().getScreens();
        int N = screens.size();
        for (int i = 0; i < N; i++) {
            if (i != this.mCurrentScreen && i != SettingUtil.getDefaultScreenIndex()) {
                screens.get(i).thaw(false);
            }
        }
        this.mDidRelinquishScreenCache = true;
    }
}
