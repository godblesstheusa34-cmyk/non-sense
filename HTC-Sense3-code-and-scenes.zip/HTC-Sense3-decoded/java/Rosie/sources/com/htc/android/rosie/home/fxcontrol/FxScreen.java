package com.htc.android.rosie.home.fxcontrol;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Handler;
import android.util.Log;
import com.htc.android.rosie.home.fxcontrol.ItemContainer;
import com.htc.fusion.fx.FxObject;
import com.htc.fusion.fx.FxScene;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.Marker;
import com.htc.fusion.fx.MessageListener;
import com.htc.fusion.fx.controls.FxCellSceneContainer;
import com.htc.fusion.fx.controls.FxHitbox;
import com.htc.fusion.fx.controls.FxSceneContainer;
import com.htc.fusion.fx.controls.FxTextLabel;
import com.htc.launcher.CellInfo;
import com.htc.launcher.CellLayout;
import com.htc.launcher.DragSource;
import com.htc.launcher.Draggee;
import com.htc.launcher.DropTarget;
import com.htc.launcher.FxItem;
import com.htc.launcher.FxItemInfo;
import com.htc.launcher.FxShortcutInfo;
import com.htc.launcher.ItemInfo;
import com.htc.launcher.Launcher;
import com.htc.launcher.LegacyLayout;
import com.htc.launcher.Logger;
import com.htc.launcher.R;
import com.htc.launcher.settings.SettingUtil;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class FxScreen implements CellLayout.OccupiedDelegation {
    static final /* synthetic */ boolean $assertionsDisabled;
    public static final int BACK_PANEL_AUTO = 0;
    public static final int BACK_PANEL_FORCE_HIDE = 2;
    public static final int BACK_PANEL_FORCE_SHOW = 1;
    private static final String CONTAINER_FOLDER_FX_NAME = "scenecontainer.Folder";
    private static final String DROP_CONTAINER_FX_NAME = "scenecontainer.DropArea";
    static final long FREEZE_TIMEOUT = 500;
    public static final int INVALID_CELL = -1;
    public static final int INVALID_ID = -1;
    private static final String ITEM_CONTAINER_FX_NAME = "cellcontainer.Page";
    public static boolean IsOnFloating = false;
    static final String LOG_TAG;
    private static final String MARKER_NAME_PANEL_OFF = "off";
    private static final String MARKER_NAME_PANEL_ON = "on";
    private static final String SCREEN_M10 = "Rosie_screen.m10";
    private static final String TIP_BUBBLE_FX_NAME = "timeline.Tip_Bubbles_Main";
    private static final boolean localLOGD;
    private final int columns;
    private FxHitbox downHitbox;
    private Activity mActivity;
    private FxTimelineControl mBackPanel;
    private FxDropAreaIndicator mDropAreaIndicator;
    private boolean mFrozen;
    private FxCellSceneContainer mFxContainer;
    private FxSceneContainer mFxDropContainer;
    private FxSceneContainer mFxFolderContainer;
    private FxScene mFxScene;
    private Handler mHandler;
    private int mId;
    private boolean mIsPortrait;
    private final boolean[][] mOccupiedBitmap;
    private boolean mShowBackPanel;
    private Runnable mTimerRunnable;
    private boolean mVisible;
    private final int rows;
    private FxHitbox upHitbox;
    private final MessageListener<FxHitbox.TapParameters> tipUpClickListener = new MessageListener<FxHitbox.TapParameters>() { // from class: com.htc.android.rosie.home.fxcontrol.FxScreen.1
        public void onMessageReceived(FxHitbox.TapParameters tap) {
            if (FxScreen.localLOGD) {
                Log.d(FxScreen.LOG_TAG, "tap up_tip " + tap.control.getName());
            }
            FxScreen.this.setTutorialPreference();
            FxScreen.this.hideBackPanel(true);
        }
    };
    private final MessageListener<FxHitbox.TapParameters> tipDownClickListener = new MessageListener<FxHitbox.TapParameters>() { // from class: com.htc.android.rosie.home.fxcontrol.FxScreen.2
        public void onMessageReceived(FxHitbox.TapParameters tap) {
            if (FxScreen.localLOGD) {
                Log.d(FxScreen.LOG_TAG, "tap down_tip" + tap.control.getName());
            }
            FxScreen.this.setTutorialPreference();
            FxScreen.this.hideBackPanel(true);
        }
    };
    private int mBackPanelMode = 0;
    private Map<Item, LayoutParams> mMovedItems = new HashMap();
    private ArrayList<MoveSceneInfo> mMoveSceneInfo = new ArrayList<>();
    ArrayList<Draggee> mDraggeeList = new ArrayList<>();
    private boolean mIsShowDropArea = false;
    private FxScreenItemManager mItemManager = new FxScreenItemManager();

    static {
        $assertionsDisabled = !FxScreen.class.desiredAssertionStatus();
        LOG_TAG = FxScreen.class.getSimpleName();
        localLOGD = SettingUtil.localLOGD;
        IsOnFloating = false;
    }

    FxScreen(Activity activity, int id, boolean isPortrait) {
        this.mIsPortrait = true;
        this.mId = id;
        this.mActivity = activity;
        this.mIsPortrait = isPortrait;
        loadFxScene();
        RectF r = this.mFxContainer.GetCellProperties();
        this.rows = (int) r.bottom;
        this.columns = (int) r.right;
        if (localLOGD) {
            Log.d(LOG_TAG, "cell container layout:" + this.rows + "x" + this.columns);
        }
        this.mOccupiedBitmap = (boolean[][]) Array.newInstance((Class<?>) Boolean.TYPE, this.columns, this.rows);
        for (int y = 0; y < this.rows; y++) {
            for (int x = 0; x < this.columns; x++) {
                this.mOccupiedBitmap[x][y] = false;
            }
        }
        this.mHandler = new Handler();
    }

    PointF getSize() {
        return this.mFxContainer.getSize();
    }

    FxScene getScene() {
        return this.mFxScene;
    }

    public String getM10PathByWH(int w, int h) {
        String[] m10s = this.mActivity.getResources().getStringArray(R.array.widget_containers);
        String path = m10s[((w - 1) * 4) + (h - 1)];
        return path;
    }

    long getId() {
        return this.mId;
    }

    boolean getVisibility() {
        return this.mVisible;
    }

    void onVisibilityChanged(boolean visible) {
        if (this.mVisible != visible) {
            if (localLOGD) {
                Log.d(LOG_TAG, "Screen#" + this.mId + " " + this.mFxScene + " visible:" + visible + ", was:" + this.mVisible);
            }
            this.mVisible = visible;
            this.mFxScene.setVisibility(visible);
        }
    }

    synchronized boolean getFrozen() {
        return this.mFrozen;
    }

    synchronized void onFreeze(long timeout) {
        if (localLOGD) {
            Log.d(LOG_TAG, "+Screen#" + this.mId + " " + this.mFxScene + " freeze");
        }
        long start = System.currentTimeMillis();
        Future<Boolean> wait = this.mFxScene.freeze();
        Logger.d(SettingUtil.PERFORMANCE_TAG, "onFreeze " + (System.currentTimeMillis() - start));
        if (timeout > 0) {
            Logger.d(SettingUtil.PERFORMANCE_TAG, "onFreeze waiting...");
            try {
                wait.get(timeout, TimeUnit.MILLISECONDS);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (localLOGD) {
            Log.d(LOG_TAG, "-Screen#" + this.mId + " " + this.mFxScene + " freeze");
        }
        this.mFrozen = true;
    }

    synchronized void onFreeze() {
        onFreeze(0L);
    }

    synchronized void onThaw(boolean keepContent) {
        long start = System.currentTimeMillis();
        this.mFxScene.thaw(keepContent);
        Logger.d(SettingUtil.PERFORMANCE_TAG, "onThaw " + (System.currentTimeMillis() - start));
        if (localLOGD) {
            Log.d(LOG_TAG, "Screen#" + this.mId + " " + this.mFxScene + " thaw");
        }
        this.mFrozen = false;
    }

    synchronized void onPulseFreeze() {
        if (this.mFrozen) {
            if (localLOGD) {
                Log.d(LOG_TAG, "Screen#" + this.mId + " " + this.mFxScene + " pulseFreeze");
            }
            long start = System.currentTimeMillis();
            this.mFxScene.pulseFreeze();
            Logger.d(SettingUtil.PERFORMANCE_TAG, "onPulseFreeze " + (System.currentTimeMillis() - start));
        }
    }

    void onTiltChanged(float tilt, float speed) {
    }

    public boolean addItem(long id, FxItem fxItem, LayoutParams layout) {
        Logger.d("FxScreen", "[EDIT_DEBUG] FxScreen.addItem() IsOnFloat:" + IsOnFloating + " to Screen#" + this.mId);
        if (!$assertionsDisabled && this.mFxContainer == null) {
            throw new AssertionError();
        }
        if (IsOnFloating) {
            Logger.e("FxScreen", "[EDIT_DEBUG] FxScreen.addItem() - IsOnFloating, return!");
            return false;
        }
        if (layout.cellY > this.mFxContainer.GetCellProperties().bottom) {
            return false;
        }
        String path = getM10PathByWH(layout.spanX, layout.spanY);
        FxScene child = Launcher.getFxSceneManager().getFxScene(path, (int) id, this.mIsPortrait);
        Item item = createItem(id, fxItem, child, layout, true);
        Rect r = layout.asRect();
        boolean ok = item.attachTo(this.mFxContainer, r);
        if (!ok) {
            Log.e(LOG_TAG, "[EDIT_DEBUG] addScene fail");
            return false;
        }
        this.mItemManager.add(id, item);
        for (int y = r.top; y < r.bottom; y++) {
            for (int x = r.left; x < r.right; x++) {
                this.mOccupiedBitmap[x][y] = true;
            }
        }
        if (!needToShowBackPanel()) {
            hideBackPanel(true);
        }
        if (getFrozen()) {
            this.mFxScene.pulseFreeze();
        }
        return true;
    }

    Item createItem(long id, FxItem fxItem, FxScene containerScene, LayoutParams layout, boolean attach) {
        ItemContainer ic;
        ItemContainer.Builder icb = new ItemContainer.Builder();
        if (fxItem.getScene() == null) {
            ic = icb.setScene(containerScene).setContainer("container").setDrag(ItemContainer.DRAG_NAME).build();
        } else {
            ic = icb.setScene(containerScene).setContainer("container").setItem(fxItem.getScene()).setDrag(ItemContainer.DRAG_NAME).build();
        }
        Item item = new Item(fxItem, this.mFxContainer, attach, ic, layout);
        fxItem.setDraggee(new FxDraggee(id, item, fxItem.getDraggee()));
        return item;
    }

    public boolean setFolder(long id, FxScene scene) {
        if (this.mFxFolderContainer == null) {
            return false;
        }
        this.mFxFolderContainer.setScene(scene);
        return true;
    }

    boolean removeAllItems() {
        Long[] ids = (Long[]) this.mItemManager.keySet().toArray(new Long[0]);
        for (Long id : ids) {
            Item i = this.mItemManager.get(id.longValue());
            removeItem(id.longValue(), i, false);
        }
        return true;
    }

    public boolean removeItem(long id) {
        Item item = this.mItemManager.get(id);
        Logger.d(LOG_TAG, "[EDIT_DEBUG] FxScreen.removeItem(" + id + ")");
        if (item == null) {
            Logger.e(LOG_TAG, "[EDIT_DEBUG] FxScreen.removeItem(" + id + "), item is null, return!");
            return false;
        }
        boolean ok = removeItem(id, item, true);
        return ok;
    }

    private boolean removeItemScene(long id, Item item) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] FxScreen.removeItemScene(" + id + ")");
        if (this.mItemManager.get(id) == null) {
            Log.e(LOG_TAG, "item#" + id + " is not in this screen. Won't remove it!");
            return false;
        }
        boolean ok = item.detach();
        Logger.d(LOG_TAG, "[EDIT_DEBUG] FxScreen.removeItemScene(" + id + ") ok:" + ok);
        if (!ok) {
            Log.e(LOG_TAG, "removeScene fail");
            return false;
        }
        return true;
    }

    private boolean removeItem(long id, Item item, boolean animateBackPanel) {
        if (this.mItemManager.get(id) != null) {
            return remove(id, item, animateBackPanel);
        }
        Log.e(LOG_TAG, "item#" + id + " is not in this screen. Won't remove it!");
        return false;
    }

    private boolean remove(long id, Item item, boolean animateBackPanel) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] FxScreen.remove(" + id + ") from FxScreen#" + getId());
        boolean ok = item.detach();
        if (!ok) {
            Log.e(LOG_TAG, "removeScene fail");
            return false;
        }
        String path = getM10PathByWH(item.mLayout.spanX, item.mLayout.spanY);
        Launcher.getFxSceneManager().deleteFxScene(path, (int) id, this.mIsPortrait);
        Rect r = item.mLayout.asRect();
        for (int y = r.top; y < r.bottom; y++) {
            for (int x = r.left; x < r.right; x++) {
                this.mOccupiedBitmap[x][y] = false;
            }
        }
        item.mItemContainer.destroy();
        item.mItemContainer = null;
        this.mItemManager.remove(Long.valueOf(id));
        if (needToShowBackPanel()) {
            showBackPanel(animateBackPanel);
        }
        if (getFrozen()) {
            this.mFxScene.pulseFreeze();
        }
        Logger.e(LOG_TAG, "[EDIT_DEBUG] FxScreen.remove(" + id + ") end");
        return true;
    }

    boolean removeItem(Draggee item) {
        Long[] keys = (Long[]) this.mItemManager.keySet().toArray(new Long[0]);
        for (Long key : keys) {
            Item i = this.mItemManager.get(key.longValue());
            if (i.mFxItem.getItemInfo().id == item.getItemInfo().id) {
                removeItem(key.longValue(), i, true);
                return true;
            }
        }
        Logger.d(LOG_TAG, "[EDIT_DEBUG] removeItem() Could not find fx item:" + item + " in screen#" + this.mId);
        Log.e(LOG_TAG, "Could not find fx item:" + item + " in screen#" + this.mId);
        return false;
    }

    boolean removeItemScene(Draggee item) {
        Long[] keys = (Long[]) this.mItemManager.keySet().toArray(new Long[0]);
        for (Long key : keys) {
            Item i = this.mItemManager.get(key.longValue());
            if (i.mFxItem.getItemInfo().id == item.getItemInfo().id) {
                removeItemScene(key.longValue(), i);
                return true;
            }
        }
        Logger.d(LOG_TAG, "[EDIT_DEBUG] removeItemScene() Could not find fx item:" + item + " in screen#" + this.mId);
        return false;
    }

    void syncItemInfo(Draggee item, int x, int y) {
        Long[] keys = (Long[]) this.mItemManager.keySet().toArray(new Long[0]);
        for (Long key : keys) {
            Item i = this.mItemManager.get(key.longValue());
            ItemInfo info = i.mFxItem.getItemInfo();
            ItemInfo dragInfo = item.getItemInfo();
            if (info.cellX == dragInfo.cellX && info.cellY == dragInfo.cellY) {
                Logger.d("Rearrange", String.format("syncItemInfo %s to %d,%d", item.toString(), Integer.valueOf(x), Integer.valueOf(y)));
                return;
            }
        }
    }

    public void freezeChildren() {
        Long[] keys = (Long[]) this.mItemManager.keySet().toArray(new Long[0]);
        for (Long key : keys) {
            Item i = this.mItemManager.get(key.longValue());
            int type = i.mFxItem.getItemInfo().itemType;
            if (type == 5) {
                i.mItemContainer.freeze();
            }
        }
    }

    public void thawChildren() {
        Long[] keys = (Long[]) this.mItemManager.keySet().toArray(new Long[0]);
        for (Long key : keys) {
            Item i = this.mItemManager.get(key.longValue());
            int type = i.mFxItem.getItemInfo().itemType;
            if (type == 5) {
                i.mItemContainer.thaw();
            }
        }
    }

    public int getItemCount() {
        return this.mItemManager.getCount();
    }

    public boolean removeFolder() {
        if (this.mFxFolderContainer == null) {
            return false;
        }
        this.mFxFolderContainer.removeScene((FxObject) null);
        return true;
    }

    private String columnString(boolean[] column) {
        StringBuilder sb = new StringBuilder();
        int N = column.length;
        for (int i = 0; i < N; i++) {
            sb.append(column[i] ? Integer.valueOf(i) : " ");
        }
        return sb.toString();
    }

    private boolean moveItem(long id, FxScreen screen, LayoutParams layout) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] FxScreen.moveItem()");
        Item item = this.mItemManager.get(id);
        if (item == null) {
            return false;
        }
        item.isDragging = false;
        Rect to = layout.asRect();
        Rect from = item.mLayout.asRect();
        if (screen == null || screen == this) {
            boolean ok = item.attachTo(this.mFxContainer, to);
            if (!ok) {
                return false;
            }
            for (int y = to.top; y < to.bottom; y++) {
                for (int x = to.left; x < to.right; x++) {
                    this.mOccupiedBitmap[x][y] = true;
                }
            }
            item.moveTo(layout.cellX, layout.cellY);
            return true;
        }
        item.attachTo(screen.mFxContainer, to);
        this.mItemManager.remove(Long.valueOf(id));
        for (int y2 = from.top; y2 < from.bottom; y2++) {
            for (int x2 = from.left; x2 < from.right; x2++) {
                this.mOccupiedBitmap[x2][y2] = false;
            }
        }
        screen.mItemManager.add(id, item);
        item.moveTo(to.left, to.top);
        for (int y3 = to.top; y3 < to.bottom; y3++) {
            for (int x3 = to.left; x3 < to.right; x3++) {
                screen.mOccupiedBitmap[x3][y3] = true;
            }
        }
        return true;
    }

    boolean moveItemTo(Draggee item, FxScreen target, int x, int y) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] FxScreen.moveItemTo()");
        ItemInfo info = item.getItemInfo();
        if (target == this && x == info.cellX && y == info.cellY) {
            return false;
        }
        LayoutParams lp = new LayoutParams(x, y, info.spanX, info.spanY);
        if (item instanceof FxDraggee) {
            for (Long key : this.mItemManager.keySet()) {
                if (this.mItemManager.get(key.longValue()).mFxItem.getDraggee() == item) {
                    return moveItem(key.longValue(), target, lp);
                }
            }
        } else {
            for (Long key2 : this.mItemManager.keySet()) {
                if (this.mItemManager.get(key2.longValue()).mFxItem.getInfo().id == item.getItemInfo().id) {
                    return moveItem(key2.longValue(), target, lp);
                }
            }
        }
        Log.e(LOG_TAG, "Could not find fx item:" + item + " in screen#" + this.mId);
        return false;
    }

    boolean resumeItem(Draggee item, FxScreen target, int x, int y) {
        Logger.d(LOG_TAG, "[EDIT_DEBUG] FxScreen.resumeItem()");
        ItemInfo info = item.getItemInfo();
        if (target == this && x == info.cellX && y == info.cellY) {
            Logger.d(LOG_TAG, "[EDIT_DEBUG] FxScreen.resumeItem() same position, resume!!");
        }
        LayoutParams lp = new LayoutParams(x, y, info.spanX, info.spanY);
        for (Long key : this.mItemManager.keySet()) {
            if (this.mItemManager.get(key.longValue()).mFxItem.getInfo().id == item.getItemInfo().id) {
                return moveItem(key.longValue(), target, lp);
            }
        }
        Logger.d(LOG_TAG, "[EDIT_DEBUG] Could not find fx item:" + item + " in screen#" + this.mId);
        Log.e(LOG_TAG, "Could not find fx item:" + item + " in screen#" + this.mId);
        return false;
    }

    public void loadOccupiedMaps() {
        RectF r = this.mFxContainer.GetCellProperties();
        int rows = (int) r.bottom;
        int columns = (int) r.right;
        for (int y = 0; y < rows; y++) {
            for (int x = 0; x < columns; x++) {
                this.mOccupiedBitmap[x][y] = false;
            }
        }
        for (Long id : this.mItemManager.keySet()) {
            Item item = this.mItemManager.get(id.longValue());
            ItemInfo info = item.mFxItem.getItemInfo();
            for (int x2 = info.cellX; x2 < info.cellX + info.spanX; x2++) {
                for (int y2 = info.cellY; y2 < info.cellY + info.spanY; y2++) {
                    this.mOccupiedBitmap[x2][y2] = true;
                }
            }
        }
    }

    @Override // com.htc.launcher.CellLayout.OccupiedDelegation
    public boolean[][] getOccupiedCells() {
        loadOccupiedMaps();
        return this.mOccupiedBitmap;
    }

    @Override // com.htc.launcher.CellLayout.OccupiedDelegation
    public void setOccupiedCells(boolean[] flatten) {
        int i = 0;
        for (int y = 0; y < this.rows; y++) {
            int x = 0;
            while (x < this.columns) {
                this.mOccupiedBitmap[x][y] = flatten[i];
                x++;
                i++;
            }
        }
    }

    @Override // com.htc.launcher.CellLayout.OccupiedDelegation
    public boolean[][] getDraggingOccupiedCells() {
        RectF r = this.mFxContainer.GetCellProperties();
        boolean[][] occupied = (boolean[][]) Array.newInstance((Class<?>) Boolean.TYPE, (int) r.right, (int) r.bottom);
        for (Long id : this.mItemManager.keySet()) {
            Item item = this.mItemManager.get(id.longValue());
            if (!item.isDragging) {
                ItemInfo info = item.mFxItem.getItemInfo();
                for (int x = info.cellX; x < info.cellX + info.spanX; x++) {
                    for (int y = info.cellY; y < info.cellY + info.spanY; y++) {
                        occupied[x][y] = true;
                    }
                }
            }
        }
        return occupied;
    }

    class MoveSceneInfo {
        float duration;
        Rect rect;
        FxScene scene;

        public MoveSceneInfo(FxScene s, Rect r, float d) {
            this.scene = s;
            this.rect = r;
            this.duration = d;
        }
    }

    private void applyMoveScenes(boolean bAnimation) {
        int size = this.mMoveSceneInfo.size();
        if (size != 0) {
            FxScene[] scenes = new FxScene[size];
            Rect[] rects = new Rect[size];
            float[] durations = new float[size];
            for (int i = 0; i < size; i++) {
                MoveSceneInfo info = this.mMoveSceneInfo.get(i);
                scenes[i] = info.scene;
                rects[i] = info.rect;
                durations[i] = info.duration;
            }
            if (bAnimation) {
                this.mFxContainer.moveScenes(scenes, rects, durations);
            } else {
                this.mFxContainer.removeScenes(scenes);
                this.mFxContainer.addScenes(scenes, rects);
            }
            this.mMoveSceneInfo.clear();
        }
    }

    @Override // com.htc.launcher.CellLayout.OccupiedDelegation
    public void moveOccupiedCells(CellInfo cellFrom, CellInfo cellTo, FxScreen target, boolean bAnimation) {
        Item oriItem;
        Draggee dragitemTo = cellTo.item;
        FxDraggee fxDragTo = (FxDraggee) ((FxItem) dragitemTo).getDraggee();
        if (target == null || target == this) {
            for (int y = cellFrom.cellY; y < cellFrom.cellY + cellFrom.spanY; y++) {
                for (int x = cellFrom.cellX; x < cellFrom.cellX + cellFrom.spanX; x++) {
                    this.mOccupiedBitmap[x][y] = false;
                }
            }
            for (int y2 = cellTo.cellY; y2 < cellTo.cellY + cellTo.spanY; y2++) {
                for (int x2 = cellTo.cellX; x2 < cellTo.cellX + cellTo.spanX; x2++) {
                    this.mOccupiedBitmap[x2][y2] = true;
                }
            }
            if (fxDragTo.getItemInfo().itemType == 5) {
                oriItem = this.mItemManager.get(((FxItemInfo) fxDragTo.getItemInfo()).widgetId);
            } else {
                oriItem = this.mItemManager.get(fxDragTo.mId);
            }
            if (oriItem == null || cellFrom == null || cellTo == null) {
                Logger.e("Rearrange", String.format("oriItem %s, cellFrom %s, cellTo %s", oriItem, cellFrom, cellTo));
                Logger.e("Rearrange", "fxDragTo:" + fxDragTo);
                return;
            }
            Log.i("Rearrange", String.format("moveOccupiedCells %s from %d,%d to %d,%d, animation:" + bAnimation, oriItem.toString(), Integer.valueOf(cellFrom.cellX), Integer.valueOf(cellFrom.cellY), Integer.valueOf(cellTo.cellX), Integer.valueOf(cellTo.cellY)));
            Rect rect = new Rect();
            rect.left = cellTo.cellX;
            rect.top = cellTo.cellY;
            rect.right = rect.left + cellTo.spanX;
            rect.bottom = rect.top + cellTo.spanY;
            this.mMoveSceneInfo.add(new MoveSceneInfo(oriItem.mItemContainer.getScene(), rect, 0.3f));
            synchronized (this.mMovedItems) {
                if (!this.mMovedItems.containsKey(oriItem)) {
                    LayoutParams previousPosition = new LayoutParams(oriItem.mLayout.cellX, oriItem.mLayout.cellY, oriItem.mLayout.spanX, oriItem.mLayout.spanY);
                    this.mMovedItems.put(oriItem, previousPosition);
                }
            }
            oriItem.moveTo(cellTo.cellX, cellTo.cellY);
        }
    }

    public void onDragEnd() {
        this.mMovedItems.clear();
    }

    @Override // com.htc.launcher.CellLayout.OccupiedDelegation
    public ArrayList<Draggee> getRearrangeItems() {
        return this.mDraggeeList;
    }

    private boolean isValidLayout(Rect rect) {
        return rect.left >= 0 && rect.top >= 0 && rect.right <= this.columns && rect.bottom <= this.rows;
    }

    private boolean hasRoom(LayoutParams layout) {
        Rect r = layout.asRect();
        if (localLOGD) {
            Log.d(LOG_TAG, "space check for " + layout);
        }
        if (!isValidLayout(r)) {
            Log.e(LOG_TAG, "layout out of bound:" + layout);
            return false;
        }
        for (int y = r.top; y < r.bottom; y++) {
            for (int x = r.left; x < r.right; x++) {
                if (this.mOccupiedBitmap[x][y]) {
                    Log.w(LOG_TAG, "(" + x + "," + y + ") should be empty but is not!");
                    return false;
                }
            }
        }
        return true;
    }

    private boolean occupied(LayoutParams layout) {
        Rect r = layout.asRect();
        if (!isValidLayout(r)) {
            Log.e(LOG_TAG, "layout out of bound:" + layout);
            return false;
        }
        for (int y = r.top; y < r.bottom; y++) {
            for (int x = r.left; x < r.right; x++) {
                if (!this.mOccupiedBitmap[x][y]) {
                    if (localLOGD) {
                        Log.d(LOG_TAG, "(" + x + "," + y + ") should be occupied but is not!");
                    }
                    return false;
                }
            }
        }
        return true;
    }

    public boolean findItemInCell(CellInfo cellInfo) {
        synchronized (this.mItemManager) {
            for (Long id : this.mItemManager.keySet()) {
                Item item = this.mItemManager.get(id.longValue());
                LayoutParams lp = item.mLayout;
                if (lp.asRect().contains(cellInfo.cellX, cellInfo.cellY)) {
                    cellInfo.cellX = lp.cellX;
                    cellInfo.cellY = lp.cellY;
                    cellInfo.spanX = lp.spanX;
                    cellInfo.spanY = lp.spanY;
                    cellInfo.item = item.mFxItem;
                    Object cellItem = item.mFxItem.getItem();
                    if (!(cellItem instanceof LegacyLayout) || ((LegacyLayout) cellItem).getFxScene() != null) {
                        return true;
                    }
                }
            }
            return false;
        }
    }

    @Override // com.htc.launcher.CellLayout.OccupiedDelegation
    public void findCoveredCells(CellInfo dragCell, List<CellInfo> cells) {
        synchronized (this.mItemManager) {
            cells.clear();
            for (Long id : this.mItemManager.keySet()) {
                Item item = this.mItemManager.get(id.longValue());
                if (!item.isDragging) {
                    ItemInfo info = item.mFxItem.getItemInfo();
                    int X1 = info.cellX;
                    int Y1 = info.cellY;
                    int cellHSpan = info.spanX;
                    int cellVSpan = info.spanY;
                    if ((X1 <= dragCell.cellX && (X1 + cellHSpan) - 1 >= dragCell.cellX) || (dragCell.cellX <= X1 && (dragCell.cellX + dragCell.spanX) - 1 >= X1)) {
                        if ((Y1 <= dragCell.cellY && (Y1 + cellVSpan) - 1 >= dragCell.cellY) || (dragCell.cellY <= Y1 && (dragCell.cellY + dragCell.spanY) - 1 >= Y1)) {
                            CellInfo cellInfo = new CellInfo();
                            cellInfo.cellX = X1;
                            cellInfo.cellY = Y1;
                            cellInfo.spanX = cellHSpan;
                            cellInfo.spanY = cellVSpan;
                            Draggee draggee = item.mFxItem.getDraggee();
                            if (draggee instanceof FxDraggee) {
                                ((FxDraggee) draggee).setItem(item);
                            }
                            cellInfo.item = item.mFxItem;
                            cells.add(cellInfo);
                        }
                    }
                }
            }
        }
    }

    @Override // com.htc.launcher.CellLayout.OccupiedDelegation
    public boolean isTouchOnItem(int x, int y) {
        synchronized (this.mItemManager) {
            for (Long id : this.mItemManager.keySet()) {
                Item item = this.mItemManager.get(id.longValue());
                RectF r = item.getRect();
                if (r != null && r.contains(x, y)) {
                    return true;
                }
            }
            return false;
        }
    }

    @Override // com.htc.launcher.CellLayout.OccupiedDelegation
    public void performRearrange(boolean bAnimation, ArrayList<CellLayout.RearrangeInfo> rearrangeCells) {
        Logger.d("Rearrange", String.format("performRearrange " + bAnimation + ", size:%d", Integer.valueOf(rearrangeCells.size())));
        Long[] ids = (Long[]) this.mItemManager.keySet().toArray(new Long[0]);
        this.mDraggeeList.clear();
        int len$ = ids.length;
        int i$ = 0;
        while (true) {
            int i$2 = i$;
            if (i$2 >= len$) {
                break;
            }
            Long id = ids[i$2];
            Item item = this.mItemManager.get(id.longValue());
            if (item.isDragging) {
                Logger.d("Rearrange", "ignore dragging item " + toString() + ", " + item.mFxItem.toString());
            } else {
                FxItem fxItem = item.mFxItem;
                boolean bFound = false;
                Iterator i$3 = rearrangeCells.iterator();
                while (true) {
                    if (!i$3.hasNext()) {
                        break;
                    }
                    ItemInfo fromInfo = i$3.next().to.item.getItemInfo();
                    ItemInfo itemInfo = fxItem.getItemInfo();
                    if (fromInfo.cellX == itemInfo.cellX && fromInfo.cellY == itemInfo.cellY) {
                        bFound = true;
                        break;
                    }
                }
                if (!bFound) {
                    ItemInfo info = fxItem.getItemInfo();
                    if (item.mLayout.cellX != info.cellX || item.mLayout.cellY != info.cellY) {
                        CellInfo fromInfo2 = new CellInfo();
                        fromInfo2.cellX = item.mLayout.cellX;
                        fromInfo2.cellY = item.mLayout.cellY;
                        fromInfo2.spanX = item.mLayout.spanX;
                        fromInfo2.spanY = item.mLayout.spanY;
                        CellInfo toInfo = new CellInfo();
                        toInfo.cellX = info.cellX;
                        toInfo.cellY = info.cellY;
                        toInfo.spanX = info.spanX;
                        toInfo.spanY = info.spanY;
                        toInfo.item = fxItem;
                        String.format("revert cell %s from %s to %s", toString(), fromInfo2.toString(), toInfo.toString());
                        moveOccupiedCells(fromInfo2, toInfo, this, bAnimation);
                        this.mDraggeeList.add(fxItem);
                    }
                }
            }
            i$ = i$2 + 1;
        }
        int len$2 = ids.length;
        int i$4 = 0;
        while (true) {
            int i$5 = i$4;
            if (i$5 < len$2) {
                Long id2 = ids[i$5];
                Item item2 = this.mItemManager.get(id2.longValue());
                if (item2.isDragging) {
                    Logger.d("Rearrange", "ignore dragging item " + toString() + ", " + item2.mFxItem.toString());
                } else {
                    FxItem fxItem2 = item2.mFxItem;
                    Iterator i$6 = rearrangeCells.iterator();
                    while (true) {
                        if (i$6.hasNext()) {
                            CellLayout.RearrangeInfo rearrangeinfo = i$6.next();
                            ItemInfo fromInfo3 = rearrangeinfo.to.item.getItemInfo();
                            ItemInfo itemInfo2 = fxItem2.getItemInfo();
                            if (fromInfo3.cellX == itemInfo2.cellX && fromInfo3.cellY == itemInfo2.cellY) {
                                Logger.d("Rearrange", String.format("performRearrange %s from %s to %s", toString(), rearrangeinfo.from.toString(), rearrangeinfo.to.toString()));
                                moveOccupiedCells(rearrangeinfo.from, rearrangeinfo.to, this, bAnimation);
                                this.mDraggeeList.add(fxItem2);
                                break;
                            }
                        }
                    }
                }
                i$4 = i$5 + 1;
            } else {
                applyMoveScenes(bAnimation);
                return;
            }
        }
    }

    static final class FxDraggee implements Draggee {
        private Draggee mDelegate;
        private long mId;
        private DesktopItem mItem;

        FxDraggee(long id, DesktopItem item, Draggee delegate) {
            this.mId = id;
            this.mItem = item;
            this.mDelegate = delegate;
        }

        public void setItem(Item item) {
            this.mItem = item;
        }

        @Override // com.htc.launcher.Draggee
        public Object getItem() {
            if (this.mItem == null || this.mItem.mFxItem == null) {
                return null;
            }
            if (this.mDelegate != null) {
                return this.mDelegate.getItem();
            }
            return this.mItem.mFxItem;
        }

        @Override // com.htc.launcher.Draggee
        public ItemInfo getItemInfo() {
            if (this.mItem == null || this.mItem.mFxItem == null) {
                return null;
            }
            if (this.mDelegate != null) {
                return this.mDelegate.getItemInfo();
            }
            return this.mItem.mFxItem.getInfo();
        }

        @Override // com.htc.launcher.Draggee
        public Point getCellXY() {
            if (!(this.mItem instanceof Item)) {
                if (FxScreen.localLOGD) {
                    Log.d(LOG_TAG, "only screen item support cell-based layout");
                }
                return new Point(0, 0);
            }
            Item item = (Item) this.mItem;
            return new Point(item.mLayout.cellX, item.mLayout.cellY);
        }

        @Override // com.htc.launcher.Draggee
        public Rect getRectInPixels() {
            RectF rf = this.mItem.getRect();
            Rect r = new Rect((int) rf.left, (int) rf.top, (int) rf.right, (int) rf.bottom);
            if (FxScreen.localLOGD) {
                Log.d(LOG_TAG, "item rect:" + r);
            }
            return r;
        }

        @Override // com.htc.launcher.Draggee
        public void onDrop(DropTarget target, int cellX, int cellY) {
            if (FxScreen.localLOGD) {
                Log.d(LOG_TAG, "[EDIT_DEBUG] FxDraggee.onDrop() - enter");
            }
            this.mItem.drop();
            if (this.mDelegate != null) {
                this.mDelegate.onDrop(target, cellX, cellY);
            }
        }

        @Override // com.htc.launcher.Draggee
        public void onDrag() {
            if (FxScreen.localLOGD) {
                Log.d(LOG_TAG, "[EDIT_DEBUG] FxDraggee.onDrag() - 2");
            }
            if (this.mDelegate != null) {
                this.mDelegate.onDrag();
            }
            this.mItem.pick();
        }

        @Override // com.htc.launcher.Draggee
        public void onDropAbort(DragSource source) {
            if (FxScreen.localLOGD) {
                Log.d(LOG_TAG, "FxCell.onDropAbort()");
            }
            this.mItem.drop();
            if (this.mDelegate != null) {
                this.mDelegate.onDropAbort(source);
            }
        }
    }

    public boolean onLongClick(int x, int y) {
        return false;
    }

    public LayoutParams getItemLayout(int id) {
        Item i = this.mItemManager.get(id);
        if (i == null) {
            return null;
        }
        return i.mLayout;
    }

    public Point getItemPosition(int id) {
        Item i = this.mItemManager.get(id);
        if (i == null) {
            return null;
        }
        Rect r = this.mFxContainer.cellToRect(i.mLayout.asRect());
        return new Point(r.centerX(), r.centerY());
    }

    public static class ItemNotFoundException extends RuntimeException {
        private ItemNotFoundException(String message) {
            super(message);
        }
    }

    public static class FusionException extends RuntimeException {
        private FusionException(String message) {
            super(message);
        }
    }

    public static class LayoutParams {
        public int cellX;
        public int cellY;
        private Rect mRect;
        public int spanX;
        public int spanY;

        public LayoutParams(int x, int y, int width, int height) {
            this.cellX = x;
            this.cellY = y;
            this.spanX = width;
            this.spanY = height;
            this.mRect = new Rect(this.cellX, this.cellY, this.cellX + this.spanX, this.cellY + this.spanY);
        }

        Rect asRect() {
            return this.mRect;
        }

        void move(int x, int y) {
            this.cellX = x;
            this.cellY = y;
            this.mRect.offsetTo(x, y);
        }

        void resize(int width, int height) {
            this.spanX = width;
            this.spanY = height;
            this.mRect.right = this.mRect.left + width;
            this.mRect.bottom = this.mRect.top + height;
        }

        public String toString() {
            return "item layout " + this.cellX + "," + this.cellY + "-" + this.spanX + "x" + this.spanY;
        }
    }

    class Item extends DesktopItem {
        private FxCellSceneContainer mFxParent;
        public final LayoutParams mLayout;

        public Item(FxItem fxItem, FxCellSceneContainer parent, boolean attach, ItemContainer container, LayoutParams layout) {
            super(fxItem, container);
            this.mLayout = new LayoutParams(layout.cellX, layout.cellY, layout.spanX, layout.spanY);
            if (this.mBounds != null) {
                this.mBounds.set(parent.cellToRect(this.mLayout.asRect()));
            }
        }

        public void moveTo(int cellX, int cellY) {
            this.mLayout.move(cellX, cellY);
            if (getmFxParent() == null) {
                Log.w(FxScreen.LOG_TAG, "Should not invoke moveTo() if not attached");
            } else if (this.mBounds != null) {
                this.mBounds.set(getmFxParent().cellToRect(this.mLayout.asRect()));
            }
        }

        public void resize(int width, int height) {
            this.mLayout.resize(width, height);
            if (getmFxParent() == null) {
                Log.w(FxScreen.LOG_TAG, "Should not invoke moveTo() if not attached");
            } else {
                this.mBounds.set(getmFxParent().cellToRect(this.mLayout.asRect()));
            }
        }

        @Override // com.htc.android.rosie.home.fxcontrol.DesktopItem
        void pick() {
            super.pick();
        }

        @Override // com.htc.android.rosie.home.fxcontrol.DesktopItem
        void drop() {
            super.drop();
        }

        public FxCellSceneContainer getmFxParent() {
            return this.mFxCellSceneContainer;
        }

        public String toString() {
            return String.format("Item@FxItem:%s", this.mFxItem.toString());
        }
    }

    void loadFxScene() {
        this.mFxScene = Launcher.getFxSceneManager().getFxScene(SCREEN_M10, this.mId, this.mIsPortrait);
        this.mVisible = true;
        String[] controls = {ITEM_CONTAINER_FX_NAME, CONTAINER_FOLDER_FX_NAME, TIP_BUBBLE_FX_NAME, DROP_CONTAINER_FX_NAME};
        FxSceneContainer[] descendants = this.mFxScene.getDescendants(controls);
        this.mFxContainer = (FxCellSceneContainer) descendants[0];
        this.mFxFolderContainer = descendants[1];
        this.mBackPanel = (FxTimelineControl) descendants[2];
        FxTextLabel upLabel = this.mFxScene.findControl("text.label_01");
        if (upLabel != null) {
            upLabel.setContent(this.mActivity.getResources().getString(R.string.tutorial_notice_top));
        }
        FxTextLabel downLabel = this.mFxScene.findControl("text.label_02");
        if (downLabel != null) {
            downLabel.setContent(this.mActivity.getResources().getString(R.string.tutorial_notice_bottom));
        }
        this.upHitbox = this.mFxScene.findControl("hitbox.Tip_bubbles_01");
        if (this.upHitbox != null) {
            this.upHitbox.setEnabledGestures(1);
            this.upHitbox.getTapSource().bind(this.tipUpClickListener);
        }
        this.downHitbox = this.mFxScene.findControl("hitbox.Tip_bubbles_02");
        if (this.downHitbox != null) {
            this.downHitbox.setEnabledGestures(1);
            this.downHitbox.getTapSource().bind(this.tipDownClickListener);
        }
        this.mFxDropContainer = descendants[3];
        if (localLOGD) {
            Log.d(LOG_TAG, "Screen#" + this.mId + " visible:" + this.mVisible + " FolderContainer(" + (this.mFxFolderContainer == null) + ")");
        }
        this.mDropAreaIndicator = new FxDropAreaIndicator(this.mFxDropContainer, this.mActivity);
        if (this.mOccupiedBitmap != null && this.mShowBackPanel) {
            this.mShowBackPanel = false;
            showBackPanel(false);
        }
    }

    void updateFxScene() {
        loadFxScene();
    }

    void resetFxScene() {
        this.mFxContainer = null;
        this.mFxFolderContainer = null;
        this.mFxDropContainer = null;
        this.mFxScene = null;
        this.mBackPanel = null;
    }

    void reloadWidgetScene(Launcher launcher) {
        FxScene scene;
        Long[] ids = (Long[]) this.mItemManager.keySet().toArray(new Long[0]);
        for (Long id : ids) {
            Item item = this.mItemManager.get(id.longValue());
            ItemInfo itemInfo = item.mFxItem.getInfo();
            if (itemInfo instanceof FxItemInfo) {
                scene = launcher.getDesktopItemController().getWidgetScene((int) itemInfo.getId());
            } else if (itemInfo instanceof FxShortcutInfo) {
                scene = launcher.getDesktopItemController().getFxShortcutScene(itemInfo.getId());
            } else {
                scene = launcher.getDesktopItemController().getLegacyScene(getId(), itemInfo.getId());
            }
            reloadWidgetScene(id.intValue(), scene);
        }
    }

    void reloadWidgetScene(int id, FxScene fxScene) {
        Item item = this.mItemManager.get(id);
        if (fxScene != null && item.mFxItem.getScene() == null) {
            item.setFxScene(fxScene);
            item.mItemContainer.setItem(fxScene);
            if (localLOGD) {
                Log.d(LOG_TAG, "reloadWidgetScene: " + id + " " + fxScene);
            }
        }
    }

    private synchronized void showBackPanel(boolean animated) {
        Marker m;
        if (!this.mShowBackPanel && this.mBackPanelMode != 2) {
            if (localLOGD) {
                Log.d(LOG_TAG, "Screen#" + this.mId + " showBackPanel");
            }
            if (getFrozen()) {
                animated = false;
            }
            if (this.mBackPanel != null && (m = this.mBackPanel.getMarker(MARKER_NAME_PANEL_ON)) != null) {
                this.mBackPanel.setVisibility(true);
                if (animated) {
                    this.mBackPanel.playFrames(m.StartFrame, m.EndFrame);
                } else {
                    this.mBackPanel.setFrame(m.EndFrame);
                }
            }
            if (this.upHitbox != null) {
                this.upHitbox.setEnabled(true);
            }
            if (this.downHitbox != null) {
                this.downHitbox.setEnabled(true);
            }
            this.mShowBackPanel = true;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setTutorialPreference() {
        SharedPreferences preferences = this.mActivity.getSharedPreferences("launcher", 0);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean(Launcher.KEY_TUTORIAL_NOTICE, false);
        editor.apply();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public synchronized void hideBackPanel(boolean animated) {
        Marker m;
        if (this.mShowBackPanel && this.mBackPanelMode != 1) {
            if (localLOGD) {
                Log.d(LOG_TAG, "Screen#" + this.mId + " hideBackPanel");
            }
            if (getFrozen()) {
                animated = false;
            }
            if (this.mBackPanel != null && (m = this.mBackPanel.getMarker(MARKER_NAME_PANEL_OFF)) != null) {
                if (animated) {
                    this.mBackPanel.playFrames(m.StartFrame, m.EndFrame, 0, 5.0f, false);
                } else {
                    this.mBackPanel.setFrame(m.EndFrame);
                    this.mBackPanel.setVisibility(false);
                }
            }
            if (this.upHitbox != null) {
                this.upHitbox.getTapSource().unbind(this.tipUpClickListener);
                this.upHitbox.setEnabled(false);
                this.upHitbox = null;
            }
            if (this.downHitbox != null) {
                this.downHitbox.getTapSource().unbind(this.tipDownClickListener);
                this.downHitbox.setEnabled(false);
                this.downHitbox = null;
            }
            this.mShowBackPanel = false;
        }
    }

    public void setBackPanelMode(int mode) {
        Log.d(LOG_TAG, "setBackPanelMode: " + mode);
        this.mBackPanelMode = mode;
        if (this.mBackPanelMode == 1) {
            showBackPanel(false);
        } else if (this.mBackPanelMode == 2) {
            hideBackPanel(true);
        } else if (!needToShowBackPanel()) {
            hideBackPanel(true);
        } else {
            showBackPanel(false);
        }
        if (getFrozen() && this.mFxScene != null) {
            this.mFxScene.pulseFreeze();
        }
    }

    public boolean fadeBackPanel(int delay) {
        Marker off;
        if (this.mBackPanel != null && (off = this.mBackPanel.getMarker(MARKER_NAME_PANEL_OFF)) != null) {
            if (this.mBackPanelMode == 2 || (this.mBackPanelMode == 0 && !needToShowBackPanel())) {
                this.mBackPanel.playFrames(off.StartFrame, off.EndFrame, 0, 1.0f, false);
            }
            return true;
        }
        return false;
    }

    private boolean needToShowBackPanel() {
        return isEmpty();
    }

    public boolean isEmpty() {
        int count = this.mItemManager.getCount();
        Log.d(LOG_TAG, "item count: " + count);
        return count == 0;
    }

    public void showDropArea(int cellX, int cellY, int spanX, int spanY, boolean valid) {
        if (this.mFxDropContainer != null) {
            if (!this.mIsShowDropArea) {
                this.mDropAreaIndicator.loadScene(spanX, spanY);
                this.mIsShowDropArea = true;
            }
            this.mDropAreaIndicator.showDropArea(cellX, cellY, valid);
        }
    }

    public void hideDropArea() {
        if (this.mFxDropContainer != null) {
            this.mIsShowDropArea = false;
            this.mDropAreaIndicator.removeScene();
        }
    }

    public Item newItem(Long id, Item item, LayoutParams layout) {
        if (!$assertionsDisabled && this.mFxContainer == null) {
            throw new AssertionError();
        }
        String path = getM10PathByWH(layout.spanX, layout.spanY);
        FxScene child = Launcher.getFxSceneManager().getFxScene(path, id.intValue(), this.mIsPortrait);
        if (child == null) {
            Log.e(LOG_TAG, "FxScene not found: " + path);
            return null;
        }
        ItemContainer.Builder icb = new ItemContainer.Builder();
        ItemContainer ic = icb.setScene(child).setContainer("container").build();
        LayoutParams l = new LayoutParams(layout.cellX, layout.cellY, layout.spanX, layout.spanY);
        Item newItem = new Item(item.mFxItem, this.mFxContainer, true, ic, l);
        newItem.setFxScene(null);
        Rect r = layout.asRect();
        newItem.attachTo(this.mFxContainer, r);
        return newItem;
    }

    public boolean deleteItem(Long id, Item item) {
        return remove(id.longValue(), item, true);
    }

    public void updateItem(Item item) {
        if (item.mFxItem.getDraggee() instanceof FxDraggee) {
            ((FxDraggee) item.mFxItem.getDraggee()).setItem(item);
        }
    }

    public boolean hasFreeRoom(LayoutParams layout) {
        return hasRoom(layout);
    }

    private DesktopItem getDesktopItem(long id) {
        if (this.mItemManager == null) {
            return null;
        }
        return this.mItemManager.get(id);
    }

    public DesktopItem getDesktopItem(ItemInfo itemInfo) {
        long widgetId;
        Logger.d("FxScreen", "[EDIT_DEBUG] getItemContainer() - enter");
        if (itemInfo == null) {
            return null;
        }
        switch (itemInfo.itemType) {
            case 5:
                widgetId = ((FxItemInfo) itemInfo).widgetId;
                break;
            default:
                widgetId = itemInfo.id;
                break;
        }
        if (widgetId == -1) {
            return null;
        }
        DesktopItem desktopItem = getDesktopItem(widgetId);
        return desktopItem;
    }

    public void updateId(int id) {
        this.mId = id;
        Map<Long, Item> items = this.mItemManager.getAll();
        Iterator<Item> iter = items.values().iterator();
        while (iter.hasNext()) {
            iter.next().mFxItem.getInfo().screen = id;
        }
    }

    public List<FxItem> getFxItems() {
        if (this.mItemManager == null) {
            return null;
        }
        List<FxItem> fxItems = new ArrayList<>();
        Map<Long, Item> items = this.mItemManager.getAll();
        Iterator<Item> iter = items.values().iterator();
        while (iter.hasNext()) {
            fxItems.add(iter.next().mFxItem);
        }
        return fxItems;
    }
}
