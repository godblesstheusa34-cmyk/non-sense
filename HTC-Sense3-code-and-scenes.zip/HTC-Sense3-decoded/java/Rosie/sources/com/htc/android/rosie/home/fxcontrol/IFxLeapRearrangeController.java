package com.htc.android.rosie.home.fxcontrol;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public interface IFxLeapRearrangeController {
    FxLeapRearrangeDrag getDragSource();

    FxLeapRearrangeDrop getDropTarget();

    IFxLeapRearrangeListener getFxLeapRearrangeListener();

    int getMoveFrom();

    int getMoveTo();

    void hideIndicator();

    void moveOthersDown(FxLeapRearrangeDrag fxLeapRearrangeDrag);

    void moveOthersUp(FxLeapRearrangeDrag fxLeapRearrangeDrag);

    void setDragSource(FxLeapRearrangeDrag fxLeapRearrangeDrag);

    void setDropTarget(FxLeapRearrangeDrop fxLeapRearrangeDrop);

    void setFxLeapRearrangeListener(IFxLeapRearrangeListener iFxLeapRearrangeListener);

    void setMoveFrom(int i);

    void setMoveTo(int i);

    void showIndicator(int i);

    void startMoveAnimation();

    void stopMoveAnimation();
}
