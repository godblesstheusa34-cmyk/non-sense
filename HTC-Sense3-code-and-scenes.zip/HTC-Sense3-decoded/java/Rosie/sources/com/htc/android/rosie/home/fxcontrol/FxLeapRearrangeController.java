package com.htc.android.rosie.home.fxcontrol;

import android.os.Handler;
import android.os.Message;
import android.util.Log;
import com.htc.fusion.fx.FxScene;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.controls.FxDragControl;
import com.htc.fusion.fx.controls.FxDropControl;
import com.htc.fusion.fx.controls.FxSceneContainer;
import com.htc.launcher.settings.SettingUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class FxLeapRearrangeController implements IFxLeapRearrangeController {
    private static final String ID_DRAG_PREFIX = "drag.leap_view_panel_";
    private static final String ID_DRAG_SCENE_CONTAINER_PREFIX = "scenecontainer.container_main_";
    private static final String ID_DRAG_TIMELINE_PREFIX = "timeline.leap_view_panel_";
    private static final String ID_DROP_PREFIX = "drop.Leap_Main_";
    private static final String ID_DROP_TIMELINE_PREFIX = "timeline.Leap_Main_";
    private static final String ID_INDICATOR = "timeline.Insert_Indicator_Main";
    private static final String ID_INDICATOR_MARKER_PREFIX = "rearrange_P";
    private static final String TAG = "FxLeapRearrangeController";
    public static final int TIME_DELAY_TO_MOVE = 350;
    public static final int TIME_MOVE_DURATION = 0;
    public static final int WHAT_MOVE_BACKWARD = 1;
    public static final int WHAT_MOVE_FORWARD = 2;
    private static final int WHAT_MOVE_LEFT = 0;
    public static final int WHAT_MOVE_RESET = 0;
    private static final int WHAT_MOVE_RIGHT = 1;
    public static final int WHAT_UPDATE_TITLE = 3;
    public FxLeapRearrangeDrag[] mLeapDrags;
    public FxLeapRearrangeDrag[] mLeapDragsCache;
    public FxLeapRearrangeDrop[] mLeapDrops;
    private int mNumOfLeap;
    private FxTimelineControl mTLIndicator;
    public static boolean localLOGD = SettingUtil.localLOGD;
    private static final String[] DRAGDROP_SCOPE = {"0"};
    private IFxLeapRearrangeListener mLeapRearrangeListener = null;
    private FxLeapRearrangeDrag mDragSource = null;
    private FxLeapRearrangeDrop mDropTarget = null;
    private int mMoveFrom = -1;
    private int mMoveTo = -1;
    private boolean mIsMoving = false;
    private int mCurrentIndex = -1;
    Handler mMoveAnimationHandler = new Handler() { // from class: com.htc.android.rosie.home.fxcontrol.FxLeapRearrangeController.1
        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            if (FxLeapRearrangeController.this.mLeapDrags != null) {
                FxLeapRearrangeController.this.mIsMoving = true;
                int what = msg.what;
                int from = msg.arg1;
                int to = msg.arg2;
                if (FxLeapRearrangeController.localLOGD) {
                    Log.d(FxLeapRearrangeController.TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] mMoveAnimationHandler " + from + "->" + to);
                }
                FxLeapRearrangeDrag mDragFrom = FxLeapRearrangeController.this.mLeapDrags[from];
                switch (what) {
                    case 0:
                        if (FxLeapRearrangeController.localLOGD) {
                            Log.d(FxLeapRearrangeController.TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] WHAT_MOVE_BACKWARD " + from + "->" + to);
                        }
                        FxLeapRearrangeController.this.moveBackward(from, to);
                        break;
                    case 1:
                        if (FxLeapRearrangeController.localLOGD) {
                            Log.d(FxLeapRearrangeController.TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] WHAT_MOVE_FORWARD " + from + "->" + to);
                        }
                        FxLeapRearrangeController.this.moveForward(from, to);
                        break;
                }
                FxLeapRearrangeController.this.setMoveFrom(to);
                mDragFrom.setScreen(to);
                FxLeapRearrangeController.this.mLeapDrags[to] = mDragFrom;
                FxLeapRearrangeController.this.mLastMoveTime = System.currentTimeMillis();
                FxLeapRearrangeController.this.mIsMoving = false;
                if (FxLeapRearrangeController.this.getFxLeapRearrangeListener() != null) {
                    FxLeapRearrangeController.this.getFxLeapRearrangeListener().onMoveAnimationEnd();
                }
            }
        }
    };
    private long mLastMoveTime = 0;

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeController
    public void setMoveFrom(int screen) {
        this.mMoveFrom = screen;
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeController
    public void setMoveTo(int screen) {
        this.mMoveTo = screen;
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeController
    public int getMoveFrom() {
        return this.mMoveFrom;
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeController
    public int getMoveTo() {
        return this.mMoveTo;
    }

    public FxLeapRearrangeController(FxScene scene, int numOfLeap) {
        this.mNumOfLeap = 8;
        this.mTLIndicator = null;
        if (scene != null && numOfLeap > 0) {
            this.mNumOfLeap = numOfLeap;
            this.mTLIndicator = scene.findControl(ID_INDICATOR);
            this.mLeapDrops = new FxLeapRearrangeDrop[this.mNumOfLeap];
            this.mLeapDrags = new FxLeapRearrangeDrag[this.mNumOfLeap];
            this.mLeapDragsCache = new FxLeapRearrangeDrag[this.mNumOfLeap];
            for (int i = 0; i < this.mNumOfLeap; i++) {
                FxDragControl fxDrag = getFxDragControl(scene, i);
                if (fxDrag != null) {
                    this.mLeapDrags[i] = new FxLeapRearrangeDrag(i, fxDrag);
                    this.mLeapDrags[i].setNumOfScreen(this.mNumOfLeap);
                    this.mLeapDrags[i].setFxLeapRearrangeController(this);
                    this.mLeapDrags[i].setPositionTimeline(getDragPositionTimeLine(scene, i));
                    this.mLeapDrags[i].setSceneContainer(getDragSceneContainer(scene, i));
                    if (localLOGD) {
                        Log.d(TAG, "Leap[" + i + "] has SceneContainer?(" + (this.mLeapDrags[i].getSceneContainer() != null));
                    }
                    this.mLeapDrags[i].initMoveToCenter();
                    this.mLeapDragsCache[i] = this.mLeapDrags[i];
                    FxDropControl fxDrop = getFxDropControl(scene, i);
                    this.mLeapDrops[i] = new FxLeapRearrangeDrop(i, fxDrop);
                    this.mLeapDrops[i].setFxLeapRearrangeController(this);
                }
            }
            hideIndicator();
        }
    }

    public void resetAllDrags() {
        hideIndicator();
        for (int i = 0; i < this.mNumOfLeap; i++) {
            int originalScreen = this.mLeapDragsCache[i].getOriginalScreen();
            this.mLeapDrags[originalScreen] = this.mLeapDragsCache[i];
            this.mLeapDrags[originalScreen].moveToCenter(true);
            this.mLeapDrags[originalScreen].setScreen(i);
        }
        setDragSource(null);
        setDropTarget(null);
    }

    private String getDragControlId(int index) {
        return index < 10 ? "drag.leap_view_panel_0" + index : ID_DRAG_PREFIX + index;
    }

    private String getDropControlId(int index) {
        return index < 10 ? "drop.Leap_Main_0" + index : ID_DROP_PREFIX + index;
    }

    private FxDragControl getFxDragControl(FxScene scene, int index) {
        FxDragControl fxDrag = scene.findControl(getDragControlId(index));
        if (fxDrag == null) {
            return null;
        }
        fxDrag.setDragScope(DRAGDROP_SCOPE);
        return fxDrag;
    }

    private FxDropControl getFxDropControl(FxScene scene, int index) {
        FxDropControl fxDrop = scene.findControl(getDropControlId(index));
        if (fxDrop == null) {
            return null;
        }
        fxDrop.setDragScope(DRAGDROP_SCOPE);
        return fxDrop;
    }

    private String getDragMoveTimelineId(int index) {
        return index < 10 ? "timeline.leap_view_panel_0" + index : ID_DRAG_TIMELINE_PREFIX + index;
    }

    private String getDropMoveTimelineId(int index) {
        return index < 10 ? "timeline.Leap_Main_0" + index : ID_DROP_TIMELINE_PREFIX + index;
    }

    private FxTimelineControl getDragPositionTimeLine(FxScene scene, int index) {
        return scene.findControl(getDragMoveTimelineId(index));
    }

    private FxTimelineControl getDropPositionTimeLine(FxScene scene, int index) {
        return scene.findControl(getDropMoveTimelineId(index));
    }

    private String getDragSceneContainerId(int index) {
        return index < 10 ? "scenecontainer.container_main_0" + index : ID_DRAG_SCENE_CONTAINER_PREFIX + index;
    }

    private FxSceneContainer getDragSceneContainer(FxScene scene, int index) {
        return scene.findControl(getDragSceneContainerId(index));
    }

    private String getLeftIndcatorMarkerId(int emptyId) {
        int id = -1;
        if (emptyId >= 0 && emptyId <= 2) {
            id = emptyId + 1;
        }
        if (emptyId >= 3 && emptyId <= 4) {
            id = emptyId + 2;
        }
        if (emptyId >= 5 && emptyId <= 7) {
            id = emptyId + 3;
        }
        if (id < 10) {
            String markerId = "rearrange_P0" + id;
            return markerId;
        }
        String markerId2 = ID_INDICATOR_MARKER_PREFIX + id;
        return markerId2;
    }

    private String getRightIndcatorMarkerId(int emptyId) {
        int id = -1;
        if (emptyId >= 0 && emptyId <= 2) {
            id = emptyId + 2;
        }
        if (emptyId >= 3 && emptyId <= 4) {
            id = emptyId + 3;
        }
        if (emptyId >= 5 && emptyId <= 7) {
            id = emptyId + 4;
        }
        if (id < 10) {
            String markerId = "rearrange_P0" + id;
            return markerId;
        }
        String markerId2 = ID_INDICATOR_MARKER_PREFIX + id;
        return markerId2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void moveBackward(int from, int to) {
        if (from < to) {
            for (int i = from + 1; i <= to; i++) {
                this.mLeapDrags[i].moveLeft();
                this.mLeapDrags[i - 1] = this.mLeapDrags[i];
                if (localLOGD) {
                    Log.d(TAG, "[leap] [move]" + from + "-> " + to + " Drag[" + i + "][" + this.mLeapDrags[i] + "] WHAT_MOVE_BACKWARD");
                }
                delay(0L);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void moveForward(int from, int to) {
        if (from > to) {
            for (int i = from - 1; i >= to; i--) {
                this.mLeapDrags[i].moveRight();
                this.mLeapDrags[i + 1] = this.mLeapDrags[i];
                if (localLOGD) {
                    Log.d(TAG, "[leap] [move]" + from + "-> " + to + " Drag[" + i + "][" + this.mLeapDrags[i] + "] WHAT_MOVE_FORWARD");
                }
                delay(0L);
            }
        }
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeController
    public void showIndicator(int index) {
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeController
    public void hideIndicator() {
        if (this.mTLIndicator != null) {
            this.mTLIndicator.setVisibility(false);
        }
    }

    public boolean isMoving() {
        return this.mIsMoving;
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeController
    public void stopMoveAnimation() {
        if (localLOGD) {
            Log.d(TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] stopMoveAnimation()");
        }
        this.mMoveAnimationHandler.removeMessages(0);
        this.mMoveAnimationHandler.removeMessages(1);
        this.mMoveAnimationHandler.removeMessages(2);
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeController
    public void startMoveAnimation() {
        if (!this.mIsMoving) {
            if (getMoveFrom() != -1) {
                if (getMoveTo() != -1) {
                    if (getDragSource() != null) {
                        if (getDropTarget() != null) {
                            stopMoveAnimation();
                            move(getMoveFrom(), getMoveTo());
                            return;
                        } else {
                            Log.e(TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] startMoveAnimation() DropTarget = null return!");
                            return;
                        }
                    }
                    Log.e(TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] startMoveAnimation() DragSource = null return!");
                    return;
                }
                Log.e(TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] startMoveAnimation() MoveTo = -1 return!");
                return;
            }
            Log.e(TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] startMoveAnimation() MoveFrom = -1 return!");
            return;
        }
        Log.e(TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] startMoveAnimation() IsMoving(" + this.mIsMoving + ") return!");
    }

    private void move(int from, int to) {
        if (from == to) {
            if (localLOGD) {
                Log.d(TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] moveLeap() from=to, return!");
                return;
            }
            return;
        }
        if (this.mIsMoving) {
            if (localLOGD) {
                Log.d(TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] moveLeap() is moving, return!");
                return;
            }
            return;
        }
        int type = 0;
        if (from < to) {
            type = 0;
        }
        if (from > to) {
            type = 1;
        }
        if (localLOGD) {
            Log.d(TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] Move Leap From " + from + " To " + to);
        }
        Message msg = this.mMoveAnimationHandler.obtainMessage();
        msg.what = type;
        msg.arg1 = from;
        msg.arg2 = to;
        this.mMoveAnimationHandler.sendMessageDelayed(msg, 350L);
    }

    private void delay(long time) {
        if (time != 0) {
            try {
                Thread.sleep(time);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeController
    public void setFxLeapRearrangeListener(IFxLeapRearrangeListener leapRearrangeListener) {
        this.mLeapRearrangeListener = leapRearrangeListener;
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeController
    public IFxLeapRearrangeListener getFxLeapRearrangeListener() {
        return this.mLeapRearrangeListener;
    }

    public FxSceneContainer getLeapRearrangeContainer(int screen) {
        return this.mLeapDrags[screen].getSceneContainer();
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeController
    public void setDragSource(FxLeapRearrangeDrag dragSource) {
        this.mDragSource = dragSource;
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeController
    public FxLeapRearrangeDrag getDragSource() {
        return this.mDragSource;
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeController
    public void setDropTarget(FxLeapRearrangeDrop dropTarget) {
        this.mDropTarget = dropTarget;
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeController
    public FxLeapRearrangeDrop getDropTarget() {
        return this.mDropTarget;
    }

    public int getLeapDragOriginalScreen(int screen) {
        return this.mLeapDrags[screen].getOriginalScreen();
    }

    public void clean() {
        FxLeapRearrangeDrag[] arr$ = this.mLeapDrags;
        for (FxLeapRearrangeDrag fxLeapRearrangeDrag : arr$) {
        }
        if (this.mLeapDrags != null) {
            FxLeapRearrangeDrag[] arr$2 = this.mLeapDrags;
            for (FxLeapRearrangeDrag drag : arr$2) {
                if (drag != null) {
                    drag.clean();
                }
            }
        }
        this.mLeapDrops = null;
        this.mLeapDrags = null;
        this.mLeapDragsCache = null;
    }

    public String getLeapDragInfo(int screen) {
        return this.mLeapDrags[screen].toString();
    }

    public void setDragEnable(boolean enable) {
        if (this.mLeapDrags != null) {
            FxLeapRearrangeDrag[] arr$ = this.mLeapDrags;
            for (FxLeapRearrangeDrag drag : arr$) {
                if (drag != null) {
                    drag.setEnable(enable);
                }
            }
        }
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeController
    public void moveOthersDown(FxLeapRearrangeDrag fixDrag) {
        if (this.mLeapDrags != null) {
            FxLeapRearrangeDrag[] arr$ = this.mLeapDrags;
            for (FxLeapRearrangeDrag drag : arr$) {
                if (drag != null && drag != fixDrag) {
                    drag.zOrderDown();
                }
            }
        }
    }

    @Override // com.htc.android.rosie.home.fxcontrol.IFxLeapRearrangeController
    public void moveOthersUp(FxLeapRearrangeDrag fixDrag) {
        if (this.mLeapDrags != null) {
            FxLeapRearrangeDrag[] arr$ = this.mLeapDrags;
            for (FxLeapRearrangeDrag drag : arr$) {
                if (drag != null && drag != fixDrag) {
                    drag.zOrderUp();
                }
            }
        }
    }

    public void showPosition() {
        if (this.mLeapDrags != null) {
            FxLeapRearrangeDrag[] arr$ = this.mLeapDrags;
            for (FxLeapRearrangeDrag drag : arr$) {
                if (drag != null) {
                    drag.showPosition();
                }
            }
        }
    }
}
