package com.htc.android.rosie.home.fxcontrol;

import android.os.Vibrator;
import android.util.Log;
import com.htc.fusion.fx.FxDraggable;
import com.htc.fusion.fx.FxObject;
import com.htc.fusion.fx.FxPlaybackInfo;
import com.htc.fusion.fx.FxScene;
import com.htc.fusion.fx.Marker;
import com.htc.fusion.fx.MessageListener;
import com.htc.fusion.fx.controls.FxDragControl;
import com.htc.fusion.fx.controls.FxDropControl;
import com.htc.fusion.fx.controls.FxHitbox;
import com.htc.fusion.fx.controls.FxSceneContainer;
import com.htc.launcher.Logger;
import com.htc.launcher.settings.SettingUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class ItemContainer {
    public static final String CONTAINER_NAME = "container";
    public static final String DRAG_NAME = "Drag";
    private static final int PICK_VIBRATE_DURATION = 50;
    private FxSceneContainer mContainer;
    private FxDragControl mDrag;
    private MessageListener<FxDraggable> mDragBeginListener;
    private MessageListener<FxDraggable> mDragEndListener;
    private FxDropControl mDrop;
    private MessageListener<FxDraggable> mDropOverListener;
    private boolean mFrozen;
    private boolean mIsItemDraggable;
    Marker mMarkerStart;
    private OnPickListener mPickListener;
    private Vibrator mPickVibrator;
    private boolean mPicked;
    private MessageListener<FxPlaybackInfo> mPlaybackCompleteListener;
    private FxScene mScene;
    public static final String DRAG_SCOPE_REMOVE = "item.drag_scope.remove";
    public static final String DRAG_SCOPE_EDIT = "item.drag_scope.edit";
    public static final String DRAG_SCOPE_FULL = "full";
    public static final String DRAG_SCOPE_EMPTY = "empty";
    public static final String[] DRAG_SCOPE = {DRAG_SCOPE_REMOVE, DRAG_SCOPE_EDIT, DRAG_SCOPE_FULL, DRAG_SCOPE_EMPTY};
    private static final String LOG_TAG = ItemContainer.class.getSimpleName();

    private interface OnPickListener {
        void onPick(boolean z);
    }

    public static class Builder {
        private String mContainerName;
        private String mDragName;
        private String mDropName;
        private FxScene mItem;
        private FxScene mScene;

        public Builder setScene(FxScene scene) {
            this.mScene = scene;
            return this;
        }

        public Builder setDrag(String drag) {
            this.mDragName = drag;
            return this;
        }

        public Builder setContainer(String container) {
            this.mContainerName = container;
            return this;
        }

        public Builder setItem(FxScene item) {
            if (this.mContainerName != null) {
                this.mItem = item;
            }
            return this;
        }

        public Builder setDrop(String drop) {
            this.mDropName = drop;
            return this;
        }

        public ItemContainer build() {
            ItemContainer ic = new ItemContainer(this.mScene);
            if (this.mContainerName != null) {
                ic.setContainer(this.mContainerName);
                if (this.mItem != null) {
                    ic.setItem(this.mItem);
                }
            }
            if (this.mDragName != null) {
                ic.setDrag(this.mDragName);
            }
            if (this.mDropName != null) {
                ic.setDrop(this.mDropName);
            }
            return ic;
        }
    }

    public void destroy() {
        setDrop(null);
        setItem(null);
        setContainer(null);
        setDrag(null);
        this.mDragBeginListener = null;
        this.mDragEndListener = null;
        this.mDropOverListener = null;
        this.mScene = null;
    }

    private ItemContainer(FxScene scene) {
        this.mFrozen = false;
        this.mIsItemDraggable = true;
        this.mPickVibrator = new Vibrator();
        this.mDragBeginListener = new MessageListener<FxDraggable>() { // from class: com.htc.android.rosie.home.fxcontrol.ItemContainer.1
            public void onMessageReceived(FxDraggable drag) {
                if (ItemContainer.this.mDrag.equals(drag)) {
                    if (SettingUtil.localLOGD) {
                        Log.d(ItemContainer.LOG_TAG, "OnDragEvent(): begin");
                    }
                    ItemContainer.this.mPicked = true;
                    if (ItemContainer.this.mPickListener != null) {
                        ItemContainer.this.mPickListener.onPick(true);
                    }
                }
            }
        };
        this.mDragEndListener = new MessageListener<FxDraggable>() { // from class: com.htc.android.rosie.home.fxcontrol.ItemContainer.2
            public void onMessageReceived(FxDraggable drag) {
                if (SettingUtil.localLOGD) {
                    Log.d(ItemContainer.LOG_TAG, "OnDragEvent() end=" + drag + ", mDrag=" + ItemContainer.this.mDrag);
                }
                if (ItemContainer.this.mDrag.equals(drag)) {
                    if (SettingUtil.localLOGD) {
                        Log.d(ItemContainer.LOG_TAG, "OnDragEvent(): drop");
                    }
                    if (ItemContainer.this.mPickListener != null) {
                        ItemContainer.this.mPickListener.onPick(false);
                    }
                    ItemContainer.this.mPicked = false;
                }
            }
        };
        this.mPlaybackCompleteListener = new MessageListener<FxPlaybackInfo>() { // from class: com.htc.android.rosie.home.fxcontrol.ItemContainer.3
            public void onMessageReceived(FxPlaybackInfo info) {
                if (!ItemContainer.this.mPicked) {
                    Logger.d(ItemContainer.LOG_TAG, "mPlaybackCompleteListener (" + info.name + ") onMessageReceived thaw()");
                    if (ItemContainer.this.mMarkerStart != null) {
                        ItemContainer.this.mDrag.setFrame(ItemContainer.this.mMarkerStart.StartFrame);
                        Logger.d(ItemContainer.LOG_TAG, "mDrag.setFrame(mMarkerStart.StartFrame);");
                    }
                    ItemContainer.this.thaw();
                }
            }
        };
        this.mDropOverListener = new MessageListener<FxDraggable>() { // from class: com.htc.android.rosie.home.fxcontrol.ItemContainer.4
            public void onMessageReceived(FxDraggable drag) {
                if (drag == ItemContainer.this.mDrag) {
                }
            }
        };
        this.mScene = scene;
    }

    public void setContainer(String name) {
        if (this.mScene != null && name != null) {
            this.mContainer = this.mScene.getDescendantByType(FxSceneContainer.class);
        } else {
            this.mContainer = null;
        }
    }

    public void setItem(FxScene scene) {
        if (this.mContainer != null) {
            if (scene != null) {
                this.mContainer.setScene(scene);
            } else {
                this.mContainer.removeScene((FxObject) null);
            }
        }
    }

    FxScene getScene() {
        return this.mScene;
    }

    FxScene setScene(FxScene fxScene) {
        this.mScene = fxScene;
        return fxScene;
    }

    public void setDrag(String name) {
        if (this.mDrag != null) {
            this.mDrag.getBeginDragSource().unbind(this.mDragBeginListener);
            this.mDrag.getEndDragSource().unbind(this.mDragEndListener);
            this.mDrag.getPlaybackCompleteSource().unbind(this.mPlaybackCompleteListener);
            this.mDrag = null;
        }
        if (this.mScene != null && name != null) {
            this.mDrag = this.mScene.getChildByType(FxDragControl.class);
            if (this.mDrag != null) {
                if (SettingUtil.localLOGD) {
                    Log.d(LOG_TAG, "SetDrag(" + name + "): " + this.mDrag.getName());
                }
                this.mDrag.setDragScope(DRAG_SCOPE);
                this.mDrag.setBeginDragStyle(FxDraggable.BeginDragStyle.MANUAL);
                this.mDrag.getBeginDragSource().bind(this.mDragBeginListener);
                this.mDrag.setEndDragStyle(FxDraggable.EndDragStyle.MANUAL);
                this.mDrag.getEndDragSource().bind(this.mDragEndListener);
                this.mDrag.getPlaybackCompleteSource().bind(this.mPlaybackCompleteListener);
                this.mDrag.setEnabled(this.mIsItemDraggable);
                this.mMarkerStart = this.mDrag.getMarker("Drag_start");
                FxHitbox hb = this.mDrag.getChildByType(FxHitbox.class);
                if (hb != null) {
                    hb.setTouchOpacity(3);
                }
            }
        }
    }

    public void enableDrag(boolean enabled) {
        this.mDrag.setEnabled(enabled);
        this.mIsItemDraggable = enabled;
    }

    public boolean isDraggable() {
        return this.mIsItemDraggable;
    }

    public void setDrop(String name) {
        if (this.mScene != null && name != null) {
            this.mDrop = this.mScene.findControl(name);
            this.mDrop.getDropOverSource().bind(this.mDropOverListener);
        } else if (this.mDrop != null) {
            this.mDrop.getDropOverSource().unbind(this.mDropOverListener);
            this.mDrop = null;
        }
    }

    public void pick() {
        if (!this.mPicked) {
            this.mPicked = true;
            if (this.mPickListener != null) {
                this.mPickListener.onPick(true);
            }
            this.mDrag.beginDrag();
        }
    }

    public void drop() {
        if (this.mPicked) {
            this.mPicked = false;
            if (this.mDrag != null) {
                Logger.d("ItemContainer", "[EDIT_DEBUG] ItemContainer.drop() - endDrag() - start");
                this.mDrag.endDrag();
                Logger.d("ItemContainer", "[EDIT_DEBUG] ItemContainer.drop() - endDrag() - end");
            }
            if (this.mPickListener != null) {
                this.mPickListener.onPick(false);
            }
        }
    }

    public void dropObject() {
    }

    public void setOnPickListener(OnPickListener listener) {
        this.mPickListener = listener;
    }

    public void setDragVisibility(boolean visible) {
        if (this.mDrag != null) {
            this.mDrag.setVisibility(visible);
        }
    }

    public void freeze() {
        if (!this.mFrozen) {
            Logger.d(LOG_TAG, "freeze widget:" + this.mContainer);
            this.mContainer.freeze();
            this.mFrozen = true;
        }
    }

    public void thaw() {
        if (!this.mPicked && this.mFrozen) {
            Logger.d(LOG_TAG, "thaw widget:" + this.mContainer);
            if (this.mContainer != null) {
                this.mContainer.thaw();
            }
            this.mFrozen = false;
        }
    }
}
