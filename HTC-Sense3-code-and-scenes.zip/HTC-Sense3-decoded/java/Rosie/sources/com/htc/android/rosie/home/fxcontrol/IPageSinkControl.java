package com.htc.android.rosie.home.fxcontrol;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public interface IPageSinkControl {
    float getSink();

    boolean isSinking();

    void playSink(float f);

    void reset();

    void setScrollProgress(float f);

    void startRise();

    void startSink(float f);
}
