package com.htc.android.rosie.home.fxcontrol;

import android.app.Activity;
import android.content.res.Resources;
import android.util.Log;
import com.htc.android.rosie.home.fxcontrol.FxWorkspace;
import com.htc.fusion.fx.FxPlaybackInfo;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.MessageListener;
import com.htc.launcher.Workspace;
import com.htc.launcher.settings.SettingUtil;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class PageSlideControl {
    private static final String LOG_TAG = "PageSlideControl";
    static final int SPIN_DELAY_FRAMES = 10;
    private FxTimelineControl mFxPageSlide;
    private FxTimelineControl mScrollBarControl;
    private SlideAnimator mSlideAnimator;
    private MessageListener<FxPlaybackInfo> mUnlockAnimListener = new MessageListener<FxPlaybackInfo>() { // from class: com.htc.android.rosie.home.fxcontrol.PageSlideControl.1
        public void onMessageReceived(FxPlaybackInfo msg) {
            if (PageSlideControl.this.mUnlockAnimator != null && PageSlideControl.this.mUnlockAnimator.isUnlockAnimation(msg)) {
                if (SettingUtil.localLOGD) {
                    Log.d(PageSlideControl.LOG_TAG, "spin complete: " + msg.name);
                }
                if (PageSlideControl.this.mUnlockAnimationListener != null) {
                    PageSlideControl.this.mUnlockAnimationListener.onAnimationEnd();
                }
            }
        }
    };
    private FxWorkspace.IUnlockAnimationListener mUnlockAnimationListener;
    private FxWorkspace.IUnlockAnimator mUnlockAnimator;

    public enum Direction {
        LEFT,
        RIGHT,
        NONE
    }

    public PageSlideControl(Activity activity, FxWorkspace fxWorkspace, FxTimelineControl pageSlideControl, FxTimelineControl scrollBarControl, Resources res, FxWorkspace.IUnlockAnimator unlockAnimator, FxWorkspace.IUnlockAnimationListener ulockAnimationListener) {
        this.mUnlockAnimator = null;
        this.mFxPageSlide = pageSlideControl;
        this.mScrollBarControl = scrollBarControl;
        if (this.mScrollBarControl != null) {
            this.mScrollBarControl.setVisibility(false);
        }
        this.mUnlockAnimator = unlockAnimator;
        this.mUnlockAnimationListener = ulockAnimationListener;
        if (SettingUtil.isTabletDevice() || SettingUtil.sIsRingSlide) {
            this.mSlideAnimator = new RingSlideAnimator(fxWorkspace, pageSlideControl, SettingUtil.getScreenCount());
        } else {
            this.mSlideAnimator = new PageSlideAnimator(fxWorkspace, pageSlideControl, SettingUtil.getScreenCount());
        }
        this.mFxPageSlide.getPlaybackCompleteSource().unbindAll();
        this.mFxPageSlide.getPlaybackCompleteSource().bind(this.mUnlockAnimListener);
    }

    public void slideTo(float scrollX, int screenWidth, Direction direction, FxWorkspace.SnapInfo snapInfo) {
        if (this.mFxPageSlide != null) {
            float frame = this.mSlideAnimator.scrollXToFrame(scrollX, screenWidth, direction, snapInfo);
            this.mFxPageSlide.setFrame(frame);
            if (this.mScrollBarControl != null) {
                if (!SettingUtil.isDoubleShot()) {
                    this.mScrollBarControl.setFrame(frame);
                } else if (frame != this.mScrollBarControl.getFrame()) {
                    this.mScrollBarControl.setVisibility(true);
                    this.mScrollBarControl.setFrame(frame);
                }
            }
        }
    }

    public void unlockAnimation() {
        if (this.mUnlockAnimator != null) {
            if (this.mUnlockAnimationListener != null) {
                this.mUnlockAnimationListener.onAnimationStart();
            } else {
                Log.w(LOG_TAG, "no listener");
            }
            this.mUnlockAnimator.startAnimation();
            return;
        }
        Log.e(LOG_TAG, "no animator found");
    }

    public void prepareAnimation() {
        if (this.mUnlockAnimator != null) {
            this.mUnlockAnimator.prepareAnimation();
        } else {
            Log.e(LOG_TAG, "no animator found");
        }
    }

    public void setUnlockAnimationListener(FxWorkspace.IUnlockAnimationListener unlockAnimationListener) {
        this.mUnlockAnimationListener = unlockAnimationListener;
    }

    public void initFrame() {
        float frame = this.mSlideAnimator.getInitialFrame(Workspace.getDefaultScreenIndex());
        this.mFxPageSlide.setFrame(frame);
        if (this.mScrollBarControl != null) {
            if (SettingUtil.isDoubleShot()) {
                this.mScrollBarControl.setVisibility(false);
            } else {
                this.mScrollBarControl.setVisibility(true);
            }
            this.mScrollBarControl.setFrame(frame);
        }
    }

    public void setScrollBarControlVisibility(boolean visible) {
        if (this.mScrollBarControl != null) {
            this.mScrollBarControl.setVisibility(visible);
        }
    }
}
