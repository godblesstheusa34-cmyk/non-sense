package com.htc.android.rosie.home.fxcontrol;

import com.android.common.speech.LoggingEvents;
import com.htc.fusion.Point3F;
import com.htc.fusion.fx.FxDraggable;
import com.htc.fusion.fx.FxObject;
import com.htc.fusion.fx.FxPlaybackInfo;
import com.htc.fusion.fx.FxScene;
import com.htc.fusion.fx.FxTimelineControl;
import com.htc.fusion.fx.MessageListener;
import com.htc.fusion.fx.controls.FxDragControl;
import com.htc.fusion.fx.controls.FxHitbox;
import com.htc.fusion.fx.controls.FxSceneContainer;
import com.htc.launcher.Logger;

/* loaded from: /workspace/scratch/77bb5be345fd/delivery/dex/Rosie.dex */
public class FxLeapRearrangeDrag {
    private static final int ANIMATION_MOVE_CENTER_END_FRAME = 10;
    private static final int ANIMATION_MOVE_CENTER_START_FRAME = 10;
    private static final int ANIMATION_MOVE_LEFT_END_FRAME = 10;
    private static final int ANIMATION_MOVE_LEFT_START_FRAME = 0;
    private static final int ANIMATION_MOVE_RIGHT_END_FRAME = 30;
    private static final int ANIMATION_MOVE_RIGHT_START_FRAME = 20;
    private static final int ANIMATION_PLAY_MODE = 0;
    private static final float ANIMATION_PLAY_SPEED = 3.0f;
    private static final String LOG_TAG = "LeapRearrangeDrag";
    private static final int POS_CENTER = 1;
    private static final int POS_LEFT = 0;
    private static final int POS_RIGHT = 2;
    private FxDragControl mFxDrag = null;
    private int mOriginalScreen = -1;
    private int mScreen = -1;
    private IFxLeapRearrangeController mFxLeapRearrangeController = null;
    private FxTimelineControl mTimelinePosition = null;
    private FxSceneContainer mFxSceneContainer = null;
    private int mNumOfScreen = -1;
    private int mCurrentPos = 0;
    private FxScene mScene = null;
    private MessageListener<FxDraggable> mOnBeginDragMessageListener = new MessageListener<FxDraggable>() { // from class: com.htc.android.rosie.home.fxcontrol.FxLeapRearrangeDrag.1
        public void onMessageReceived(FxDraggable drag) {
            Logger.d(FxLeapRearrangeDrag.LOG_TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] OnDragEvent(" + FxLeapRearrangeDrag.this.mScreen + ") - Begin(" + drag + ")");
            if (FxLeapRearrangeDrag.this.mFxLeapRearrangeController != null) {
                FxLeapRearrangeDrag.this.mFxLeapRearrangeController.stopMoveAnimation();
                FxLeapRearrangeDrag.this.mFxLeapRearrangeController.hideIndicator();
            }
            if (FxLeapRearrangeDrag.this.mFxLeapRearrangeController != null) {
                FxLeapRearrangeDrag.this.mFxLeapRearrangeController.setDragSource(FxLeapRearrangeDrag.this);
                FxLeapRearrangeDrag.this.mFxLeapRearrangeController.setMoveFrom(FxLeapRearrangeDrag.this.mScreen);
                if (FxLeapRearrangeDrag.this.mFxLeapRearrangeController.getFxLeapRearrangeListener() != null) {
                    FxLeapRearrangeDrag.this.mFxLeapRearrangeController.getFxLeapRearrangeListener().onLeapRearrangeDrag(FxLeapRearrangeDrag.this.mScreen);
                }
            }
        }
    };
    private MessageListener<FxDraggable> mOnEndDragMessageListener = new MessageListener<FxDraggable>() { // from class: com.htc.android.rosie.home.fxcontrol.FxLeapRearrangeDrag.2
        public void onMessageReceived(FxDraggable drag) {
            Logger.d(FxLeapRearrangeDrag.LOG_TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] OnDragEvent(" + FxLeapRearrangeDrag.this.mScreen + ") - End(" + drag + ") " + FxLeapRearrangeDrag.this.mFxSceneContainer.getPosition().x + ", " + FxLeapRearrangeDrag.this.mFxSceneContainer.getPosition().y + ", " + FxLeapRearrangeDrag.this.mFxSceneContainer.getPosition().z);
            if (FxLeapRearrangeDrag.this.mFxLeapRearrangeController != null) {
                if (FxLeapRearrangeDrag.this.mFxLeapRearrangeController != null) {
                    FxLeapRearrangeDrag.this.mFxLeapRearrangeController.stopMoveAnimation();
                    FxLeapRearrangeDrag.this.mFxLeapRearrangeController.hideIndicator();
                }
                if (FxLeapRearrangeDrag.this.mFxLeapRearrangeController.getFxLeapRearrangeListener() != null) {
                    FxLeapRearrangeDrag.this.mFxLeapRearrangeController.getFxLeapRearrangeListener().onLeapRearrangeDragEnd();
                }
            }
        }
    };
    private MessageListener<FxPlaybackInfo> mPlaybackInfoListener = new MessageListener<FxPlaybackInfo>() { // from class: com.htc.android.rosie.home.fxcontrol.FxLeapRearrangeDrag.3
        public void onMessageReceived(FxPlaybackInfo msg) {
            if (FxLeapRearrangeDrag.this.mFxLeapRearrangeController != null) {
                Logger.d(FxLeapRearrangeDrag.LOG_TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] mPlaybackInfoListener() " + msg.name);
                if (msg.name != null && msg.name.equalsIgnoreCase("drag_start")) {
                    ((FxLeapRearrangeController) FxLeapRearrangeDrag.this.mFxLeapRearrangeController).moveOthersDown(FxLeapRearrangeDrag.this);
                }
                if (FxLeapRearrangeDrag.this.mFxLeapRearrangeController != null) {
                    FxLeapRearrangeDrag.this.mFxLeapRearrangeController.stopMoveAnimation();
                    FxLeapRearrangeDrag.this.mFxLeapRearrangeController.hideIndicator();
                }
                if (msg.name != null && msg.name.equalsIgnoreCase("drop")) {
                    FxLeapRearrangeDrag.this.mFxDrag.setFrame(0.0f);
                    ((FxLeapRearrangeController) FxLeapRearrangeDrag.this.mFxLeapRearrangeController).moveOthersUp(FxLeapRearrangeDrag.this);
                    if (FxLeapRearrangeDrag.this.mFxLeapRearrangeController.getDragSource() != null) {
                        Logger.d(FxLeapRearrangeDrag.LOG_TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] DragSource:" + FxLeapRearrangeDrag.this.mFxLeapRearrangeController.getDragSource());
                        if (FxLeapRearrangeDrag.this.mFxLeapRearrangeController.getDragSource().getScreen() == FxLeapRearrangeDrag.this.mFxLeapRearrangeController.getDragSource().getOriginalScreen()) {
                            Logger.d(FxLeapRearrangeDrag.LOG_TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] Drag=Drop, return!");
                            if (FxLeapRearrangeDrag.this.mFxLeapRearrangeController.getFxLeapRearrangeListener() != null) {
                                FxLeapRearrangeDrag.this.mFxLeapRearrangeController.getFxLeapRearrangeListener().onLeapRearrangeDragDropCancel();
                                return;
                            }
                            return;
                        }
                        if (FxLeapRearrangeDrag.this.mFxLeapRearrangeController.getFxLeapRearrangeListener() != null) {
                            if (FxLeapRearrangeDrag.this.mFxLeapRearrangeController != null) {
                                FxLeapRearrangeDrag.this.mFxLeapRearrangeController.stopMoveAnimation();
                                FxLeapRearrangeDrag.this.mFxLeapRearrangeController.hideIndicator();
                            }
                            FxLeapRearrangeDrag.this.mFxLeapRearrangeController.getFxLeapRearrangeListener().onLeapRearrangeDragDrop();
                        }
                    } else {
                        return;
                    }
                }
                if (msg.name != null && msg.name.equalsIgnoreCase("Drag_end")) {
                    Logger.d(FxLeapRearrangeDrag.LOG_TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] drop_end. return!");
                    if (FxLeapRearrangeDrag.this.mFxLeapRearrangeController.getFxLeapRearrangeListener() != null) {
                        FxLeapRearrangeDrag.this.mFxLeapRearrangeController.getFxLeapRearrangeListener().onLeapRearrangeDragDropCancel();
                    }
                }
            }
        }
    };

    public FxLeapRearrangeDrag(int screen, FxDragControl fxDrag) {
        setOriginalScreen(screen);
        setScreen(screen);
        setFxDrag(fxDrag);
    }

    public void setScreen(int screen) {
        this.mScreen = screen;
    }

    public int getScreen() {
        return this.mScreen;
    }

    private void setOriginalScreen(int screen) {
        this.mOriginalScreen = screen;
    }

    public int getOriginalScreen() {
        return this.mOriginalScreen;
    }

    public void setCurrentPos(int pos) {
        this.mCurrentPos = pos;
    }

    public int getCurrentPos() {
        return this.mCurrentPos;
    }

    public void setNumOfScreen(int screenCount) {
        this.mNumOfScreen = screenCount;
    }

    private void setFxDrag(FxDragControl fxDrag) {
        this.mFxDrag = fxDrag;
        FxHitbox hb = this.mFxDrag.getChildByType(FxHitbox.class);
        if (hb != null) {
            hb.setTouchOpacity(3);
        }
        this.mFxDrag.setEnabled(false);
        this.mFxDrag.getBeginDragSource().bind(this.mOnBeginDragMessageListener);
        this.mFxDrag.getEndDragSource().bind(this.mOnEndDragMessageListener);
        this.mFxDrag.getPlaybackCompleteSource().bind(this.mPlaybackInfoListener);
    }

    public void setEnable(boolean enable) {
        if (this.mFxDrag != null) {
            if (!enable || !this.mFxDrag.isEnabled()) {
                if (enable || this.mFxDrag.isEnabled()) {
                    this.mFxDrag.setEnabled(enable);
                }
            }
        }
    }

    public void setFxLeapRearrangeController(IFxLeapRearrangeController leapRearrangeController) {
        this.mFxLeapRearrangeController = leapRearrangeController;
    }

    public void setPositionTimeline(FxTimelineControl timelinePosition) {
        this.mTimelinePosition = timelinePosition;
    }

    public void setSceneContainer(FxSceneContainer fxSceneContainer) {
        this.mFxSceneContainer = fxSceneContainer;
    }

    public FxSceneContainer getSceneContainer() {
        return this.mFxSceneContainer;
    }

    public void attache(int screen, FxScene scene) {
        if (this.mFxSceneContainer != null) {
            this.mScene = scene;
            this.mFxSceneContainer.setScene(this.mScene);
        }
    }

    public void dettache() {
    }

    public void positionBackward() {
        if (this.mTimelinePosition != null && this.mCurrentPos == 1) {
            this.mScreen--;
            if (this.mScreen < 0) {
                this.mScreen = this.mNumOfScreen - 1;
            }
            this.mCurrentPos = 0;
            this.mTimelinePosition.playFrames(10, 0, 0, ANIMATION_PLAY_SPEED, false);
        }
    }

    public void initMoveToCenter() {
        if (this.mTimelinePosition != null) {
            this.mCurrentPos = 1;
            this.mTimelinePosition.playFrames(10, 10);
        }
    }

    public void moveToCenter(boolean isReset) {
        if (this.mTimelinePosition != null) {
            if (this.mCurrentPos != 1) {
                int startFrame = 10;
                int endFrame = 10;
                if (this.mCurrentPos == 0) {
                    this.mScreen++;
                    startFrame = 0;
                    endFrame = 10;
                }
                if (this.mCurrentPos == 2) {
                    this.mScreen--;
                    startFrame = ANIMATION_MOVE_RIGHT_END_FRAME;
                    endFrame = 20;
                }
                if (this.mScreen < 0) {
                    this.mScreen = this.mNumOfScreen - 1;
                }
                if (this.mScreen > this.mNumOfScreen - 1) {
                    this.mScreen = 0;
                }
                this.mCurrentPos = 1;
                if (isReset) {
                    Logger.d(LoggingEvents.EXTRA_CALLING_APP_NAME, " moveToCenter() Before: " + toString());
                    this.mTimelinePosition.setFrame(10.0f);
                    Logger.d(LoggingEvents.EXTRA_CALLING_APP_NAME, " moveToCenter() After: " + toString());
                    return;
                }
                this.mTimelinePosition.playFrames(startFrame, endFrame, 0, ANIMATION_PLAY_SPEED, false);
                return;
            }
            Logger.e(LoggingEvents.EXTRA_CALLING_APP_NAME, " screen[" + this.mScreen + "] = POS_CENTER");
        }
    }

    public void positionForward() {
        if (this.mTimelinePosition != null && this.mCurrentPos == 1) {
            this.mScreen++;
            if (this.mScreen > this.mNumOfScreen - 1) {
                this.mScreen = 0;
            }
            this.mCurrentPos = 2;
            this.mTimelinePosition.playFrames(20, ANIMATION_MOVE_RIGHT_END_FRAME, 0, ANIMATION_PLAY_SPEED, false);
        }
    }

    public void moveLeft() {
        switch (this.mCurrentPos) {
            case 1:
                positionBackward();
                break;
            case 2:
                moveToCenter(false);
                break;
        }
    }

    public void moveRight() {
        switch (this.mCurrentPos) {
            case 0:
                moveToCenter(false);
                break;
            case 1:
                positionForward();
                break;
        }
    }

    public FxDragControl getFxDrag() {
        return this.mFxDrag;
    }

    public String toString() {
        return "LeapDrag:mOriginalScreen(" + this.mOriginalScreen + ") mScreen(" + this.mScreen + ") Pos(" + this.mCurrentPos + ") Frame(" + this.mTimelinePosition.getFrame() + ")";
    }

    public void clean() {
        if (this.mFxLeapRearrangeController != null) {
            this.mFxLeapRearrangeController = null;
        }
        if (this.mTimelinePosition != null) {
            this.mTimelinePosition = null;
        }
        if (this.mFxSceneContainer != null) {
            this.mFxSceneContainer.removeScene((FxObject) null);
        }
        this.mFxSceneContainer = null;
    }

    public void reset() {
        this.mScreen = this.mOriginalScreen;
        initMoveToCenter();
    }

    public void zOrderDown() {
        if (this.mFxDrag != null) {
            this.mFxDrag.setPosition(new Point3F(this.mFxDrag.getPosition().x, this.mFxDrag.getPosition().y, this.mFxDrag.getPosition().z - 1.0f));
        }
    }

    public void zOrderUp() {
        if (this.mFxDrag != null) {
            this.mFxDrag.setPosition(new Point3F(this.mFxDrag.getPosition().x, this.mFxDrag.getPosition().y, this.mFxDrag.getPosition().z + 1.0f));
        }
    }

    public void showPosition() {
        Logger.d(LOG_TAG, "[ROSIE_DEBUG][LEAP_REARRANGE] Pos[" + this.mOriginalScreen + "] (" + this.mFxDrag.getPosition().x + ", " + this.mFxDrag.getPosition().y + "," + this.mFxDrag.getPosition().z + ")");
    }
}
