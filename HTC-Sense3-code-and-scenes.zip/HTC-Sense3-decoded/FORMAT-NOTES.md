# Mode10 v2 format and reproduction notes

The original files begin with the bytes `21 30 31 6d` (`!01m`), followed by
little-endian version 2. Records begin at byte 8.

Each record starts with two little-endian 32-bit words:

- Word 1: payload byte length in bits 4–31; kind in bits 0–3.
- Word 2: tag name hash.
- Kind 1 contains nested records; kind 2 contains a binary attribute value.
- Payloads are padded to a four-byte boundary; the length excludes padding.

Names use DJB2 starting at 5381, multiplying by 33 and adding each character,
with the high bit cleared. Known names were recovered by hashing strings in
the ROM's native libraries. Unknown hashes remain hexadecimal strings;
potential collisions are not silently assigned a name.

Property containers contain a Name hash and usually Value or Controller.
Values are interpreted according to property and object type. For example,
Sprite Size uses two integers, Text Size uses two floats, Position uses three
floats and Rotation uses four quaternion components. Unknown types retain
raw offsets and hashes. This is not a universal M10 decoder for all HTC ROMs.

## Sample tracks

Sample controllers contain Type, StartFrame, Size and Samples. StartFrame is
an integer. If Size has its top bit set, remaining bits give the count of
run-length records. Each record is uint32 frame, uint32 repeat, then the typed
value. Without the top bit, the data is an ordinary sequence of values.

The decoder checks byte lengths and contiguous run coverage. It exports the
stored samples rather than guessing original authoring curves. Fractional
frame interpolation and renderer evaluation require separate implementation.

## Markers

Markers begin with uint32 count, then repeated int32 start, int32 duration,
uint32 UTF-16 code-unit count, and UTF-16LE name without a terminator.
The Java-facing inclusive end is start + max(duration,1) - 1. This was checked
in native JNI code, not inferred solely from marker names.

## Texture exports

The native GLES texture switch maps format 6 to RGBA/unsigned-byte, format 8
to ATC RGB (GL 0x8c92), and format 9 to ATC RGBA explicit alpha (GL 0x8c93).
Format 9 uses an explicit 4-bit alpha plane followed by an ATC color block.
Only the top mip level is exported. Native row order and premultiplication
are preserved. Format 14 is explicitly left unresolved in this package.

Supporting format reference: [Khronos AMD compressed ATC specification](https://registry.khronos.org/OpenGL/extensions/AMD/AMD_compressed_ATC_texture.txt).

## Reproduce the scene outputs

Use the previously supplied HTC-Sense3-reference.zip. Unzip each app's assets
to its own input folder, and combine the matching native libraries from that
bundle with native/ in this package. Then run:

    python m10_decode.py APP_ASSET_FOLDER DECODED_OUTPUT NATIVE_LIBRARY_FOLDER
    python extract_textures.py DECODED_OUTPUT APP_ASSET_FOLDER PNG_OUTPUT

The decoder uses the Python standard library. Texture exports additionally
need Pillow, numpy and texture2ddecoder 1.0.6. The latter supplies the ATC RGB
block decoder; this package's script handles explicit alpha.

Code recovery used baksmali/smali 2.5.2 with API 10 and the matching ROM
framework directory. Additional classpath entries were com.htc.android.rosie.odex
and com.htc.fusion.fx.odex. Reassembled DEX was decompiled with JADX 1.5.1.
Resource decoding used Apktool 2.9.3 with the matching framework-res.apk and
com.htc.resources.apk. Keep Apktool's bundled dependencies out of baksmali's
Java classpath to avoid dependency conflicts.

Tools: [smali](https://github.com/JesusFreke/smali),
[JADX](https://github.com/skylot/jadx),
[Apktool](https://github.com/iBotPeaches/Apktool),
[texture2ddecoder](https://github.com/K0lb3/texture2ddecoder).

The five regenerated DEX files passed their internal SHA-1 and Adler-32
checks, and retained the original class counts. Every M10 structural parse
was independently rebuilt byte-for-byte, including padding. These checks
validate recovery and structure; they do not establish complete runtime
equivalence or a working modern Android port.
