#!/usr/bin/env python3
"""HTC Mode10 v2 structural/animation decoder, written for this supplied ROM.
No Android code is executed. Opaque data retains offsets and SHA256 hashes.
Usage: python m10_decode.py SOURCE_DIR OUTPUT_DIR NATIVE_LIB_DIR
"""
import collections, hashlib, json, re, struct, sys
from pathlib import Path

def hash_name(s):
    h=5381
    for c in s: h=(h*33+ord(c))&0x7fffffff
    return h

def dictionary(folder):
    d=collections.defaultdict(set)
    extras='ID Name Type Value Root Node Nodes Property Controller Sample StartFrame Size Samples MeshLibrary TextureLibrary MaterialLibrary FontTTFLibrary FontLibrary SoundClipLibrary UserdataType UserdataChunk None Markers'.split()
    for s in extras: d[hash_name(s)].add(s)
    for p in Path(folder).glob('*.so'):
        for raw in re.findall(rb'[A-Za-z_][A-Za-z_0-9.]{0,100}\x00',p.read_bytes()):
            s=raw[:-1].decode('ascii');d[hash_name(s)].add(s)
    return {k:sorted(v) for k,v in d.items()}

FLOATS=set('InFrame Duration TimelineInFrame TimelineDuration PlaybackSpeed FramesPerSecond Opacity ShadowOpacity ShadowDistance BlurAmount Volume LineHeight SpotCutoff SpotExponent ConstantAttenuation LinearAttenuation QuadraticAttenuation Shininess ShininessStrength'.split())
VEC3=set('Position Scale PivotPosition PivotScale'.split())
VEC4=set('Rotation PivotRotation Highlight Ambient Diffuse Specular Emission Color ShadowColor DiffuseColor'.split())
INTS=set('Layer LayerParent PlaybackMode PlaybackState DepthTest DepthSortLevel BlendMode HorzAlignment VertAlignment FontID StringID Ellipsis FadingDirection LineHeightMode MaxLineCount LabelHeightMode Format SourceWidth SourceHeight'.split())
BOOLS=set('Enabled Visible Pivot TwoDimension DepthSort Frozen Antialias Underline Strikeout Multiline Shadow EnableBackGround SelfIlluminated TwoSided Wireframe DisableCompression Premultiply AntiAliased'.split())
STRINGS=set('Name String AssetName MaterialName'.split())
HASHES=set('ID MeshID MaterialID TextureID SoundClipID DiffuseMap OpacityMap BumpMap'.split())

class Decoder:
    def __init__(self,data,names):
        self.data=data;self.names=names;self.records=0;self.unknown=collections.Counter()
    def label(self,h):
        x=self.names.get(h,[])
        if len(x)==1:return x[0]
        k=f'0x{h:08x}';self.unknown[k]+=1;return k
    def parse(self):
        assert self.data[:8]==b'!01m\x02\0\0\0'
        t=self.nodes(8,len(self.data))
        # Independent structural round-trip includes alignment bytes.
        assert self.data[:8]+b''.join(self.encode(n) for n in t)==self.data
        return t
    def nodes(self,pos,end,depth=0):
        assert depth<200
        out=[]
        while pos<end:
            assert pos+8<=end
            hdr,tag=struct.unpack_from('<II',self.data,pos);kind=hdr&15;size=hdr>>4
            stop=pos+8+size;aligned=(stop+3)&~3
            assert kind in (1,2) and aligned<=end
            n=dict(offset=pos,tag=self.label(tag),hash=tag,kind=kind,size=size,padding=self.data[stop:aligned])
            if kind==1:n['children']=self.nodes(pos+8,stop,depth+1)
            else:n['raw']=self.data[pos+8:stop]
            self.records+=1;out.append(n);pos=aligned
        assert pos==end
        return out
    def encode(self,n):
        payload=n['raw'] if n['kind']==2 else b''.join(self.encode(c) for c in n['children'])
        assert len(payload)==n['size']
        return struct.pack('<II',(len(payload)<<4)|n['kind'],n['hash'])+payload+n['padding']
    def opaque(self,b,offset):
        v=dict(encoding='opaque',offset=offset,size=len(b),sha256=hashlib.sha256(b).hexdigest())
        if len(b)<=64:v['hex']=b.hex()
        return v
    def value(self,name,b,off,owner=None):
        n=len(b)
        if name=='Size' and n==8 and owner in ('Sprite','NinePatchSprite'):
            return list(struct.unpack('<2i',b))
        if name=='Size' and n==8 and owner=='Text':
            return list(struct.unpack('<2f',b))
        if name=='FontID' and owner=='Text' and n%2==0:
            return b.decode('utf-16le').rstrip('\0')
        if owner=='Texture' and name in ('Width','Height') and n==4:return struct.unpack('<i',b)[0]
        if name in STRINGS and n%2==0:
            try:return b.decode('utf-16le').rstrip('\0')
            except UnicodeDecodeError:pass
        if name in HASHES and n==4:return self.label(struct.unpack('<I',b)[0])
        if name in BOOLS and n==1:
            assert b[0] in (0,1)
            return bool(b[0])
        if name in FLOATS and n==4:return struct.unpack('<f',b)[0]
        if name in INTS and n==4:return struct.unpack('<i',b)[0]
        if name in VEC3 and n==12:return list(struct.unpack('<3f',b))
        if name in VEC4 and n==16:return list(struct.unpack('<4f',b))
        if name=='Dimensions' and n==8:return list(struct.unpack('<2i',b))
        if name=='Markers':
            try:
                count,=struct.unpack_from('<I',b);pos=4;out=[]
                for _ in range(count):
                    start,duration,chars=struct.unpack_from('<iiI',b,pos);pos+=12
                    assert duration>=0 and chars<100000 and pos+chars*2<=n
                    text=b[pos:pos+chars*2].decode('utf-16le');pos+=chars*2
                    # Verified at native JNI conversion 0xbb1ec in libmode10fx.so.
                    out.append(dict(name=text,start_frame=start,duration_frames=duration,end_frame=start+max(duration,1)-1))
                assert pos==n
                return out
            except (AssertionError,struct.error,UnicodeDecodeError):pass
        return self.opaque(b,off)
    def controller(self,n,name):
        a={x['tag']:x for x in n['children'] if 'raw' in x};r=dict(offset=n['offset'])
        if 'Type' in a:r['type']=self.label(struct.unpack('<I',a['Type']['raw'])[0])
        if 'StartFrame' in a:r['start_frame']=struct.unpack('<i',a['StartFrame']['raw'])[0]
        if 'Size' not in a or 'Samples' not in a:
            r['status']='unsupported_controller';return r
        sw,=struct.unpack('<I',a['Size']['raw']);count=sw&0x7fffffff;packed=bool(sw&0x80000000)
        b=a['Samples']['raw'];off=a['Samples']['offset']+8
        r.update(sample_count=count,packed=packed,size_word=f'0x{sw:08x}')
        stride=len(b)//count if count else 0;width=stride-(8 if packed else 0)
        expected=1 if name in BOOLS else 4 if name in FLOATS|INTS|HASHES else 8 if name=='Dimensions' else 12 if name in VEC3 else 16 if name in VEC4 else None
        if count and len(b)%count==0 and width==expected:
            samples=[]
            for i in range(count):
                pos=i*stride
                if packed:frame,repeat=struct.unpack_from('<II',b,pos);pos+=8
                else:frame,repeat=i,1
                assert repeat>0
                samples.append(dict(frame=frame,repeat=repeat,value=self.value(name,b[pos:pos+width],off+pos)))
            if packed:assert all(a['frame']+a['repeat']==c['frame'] for a,c in zip(samples,samples[1:]))
            r.update(status='decoded',samples=samples)
        else:r.update(status='opaque_samples',payload=self.opaque(b,off))
        return r
    def property(self,n,owner):
        a={x['tag']:x for x in n['children'] if 'raw' in x}
        name=self.label(struct.unpack('<I',a['Name']['raw'])[0]);p=dict(offset=n['offset'])
        if 'Value' in a:
            v=a['Value'];p['value']=self.value(name,v['raw'],v['offset']+8,owner)
        cs=[self.controller(c,name) for c in n['children'] if c['tag']=='Controller']
        if cs:p['controllers']=cs
        return name,p
    def object(self,n):
        obj=dict(offset=n['offset'],tag=n['tag'],properties={},children=[])
        for c in n.get('children',[]):
            if c['tag']=='Type' and 'raw' in c:obj['type']=self.label(struct.unpack('<I',c['raw'])[0])
            elif c['tag']=='Property':
                k,p=self.property(c,obj.get('type'));obj['properties'][k]=p
            elif c['tag']=='Node':obj['children'].append(self.object(c))
            elif 'raw' in c:obj.setdefault('other_attributes',[]).append(dict(tag=c['tag'],**self.opaque(c['raw'],c['offset']+8)))
        obj['name']=obj['properties'].get('Name',{}).get('value','')
        return obj

def main():
    src,out,native=map(Path,sys.argv[1:4]);out.mkdir(parents=True,exist_ok=True);names=dictionary(native);inventory=[]
    for p in sorted(src.rglob('*.m10')):
        data=p.read_bytes();d=Decoder(data,names);tree=d.parse();assert len(tree)==1 and tree[0]['tag']=='Root'
        scenes=[];libraries={}
        for c in tree[0]['children']:
            if c['tag']=='Nodes':scenes.extend(d.object(n) for n in c['children'])
            else:libraries[c['tag']]=[d.object(n) for n in c.get('children',[])]
        rel=p.relative_to(src);result=dict(source=str(rel),size=len(data),sha256=hashlib.sha256(data).hexdigest(),record_count=d.records,structural_roundtrip=True,scenes=scenes,libraries=libraries,unresolved_hashes=dict(d.unknown))
        dest=out/rel.with_suffix('.json');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(json.dumps(result,allow_nan=False,separators=(',',':')))
        inventory.append({k:v for k,v in result.items() if k not in ('scenes','libraries')})
    (out/'inventory.json').write_text(json.dumps(inventory,indent=2))
    (out/'hash-dictionary.json').write_text(json.dumps({f'0x{k:08x}':v for k,v in names.items()},indent=2))
    print(json.dumps(dict(files=len(inventory),records=sum(x['record_count'] for x in inventory),roundtrip_passed=len(inventory))))
if __name__=='__main__':main()
