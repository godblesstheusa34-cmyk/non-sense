#!/usr/bin/env python3
"""Export known Mode10 texture formats. Preserve native row order/premultiplication.
Requires Pillow, numpy and texture2ddecoder==1.0.6. Top mip level only.
Usage: python extract_textures.py DECODED_JSON_DIR M10_SOURCE_DIR OUTPUT_DIR
"""
from pathlib import Path
import hashlib,json,struct,sys
import numpy as np
from PIL import Image
import texture2ddecoder

def pixels(raw,w,h,fmt):
    bx,by=(w+3)//4,(h+3)//4
    if fmt==6:
        assert len(raw)==w*h*4
        return Image.frombytes('RGBA',(w,h),raw)
    if fmt==8:
        assert len(raw)==bx*by*8
        return Image.frombytes('RGBA',(w,h),texture2ddecoder.decode_atc_rgb4(raw,w,h),'raw','BGRA')
    if fmt==9:
        assert len(raw)==bx*by*16
        blocks=np.frombuffer(raw,np.uint8).reshape(-1,16)
        rgb=texture2ddecoder.decode_atc_rgb4(blocks[:,8:].tobytes(),w,h)
        im=Image.frombytes('RGBA',(w,h),rgb,'raw','BGRA')
        a=np.empty((len(blocks),16),np.uint8)
        a[:,0::2]=(blocks[:,:8]&15)*17;a[:,1::2]=(blocks[:,:8]>>4)*17
        a=a.reshape(by,bx,4,4).transpose(0,2,1,3).reshape(by*4,bx*4)[:h,:w]
        im.putalpha(Image.fromarray(a));return im
    raise ValueError('Unverified format')

def main():
    jroot,sroot,out=map(Path,sys.argv[1:4]);out.mkdir(parents=True,exist_ok=True);rows=[];skips=[]
    for path in sorted(jroot.rglob('*.json')):
        if path.name in ('inventory.json','hash-dictionary.json'):continue
        d=json.loads(path.read_text());data=(sroot/d['source']).read_bytes()
        for n in d['libraries'].get('TextureLibrary',[]):
            p={k:v.get('value') for k,v in n['properties'].items()};pix=p.get('Pixels');level=p.get('Levels');fmt=p.get('Format')
            if not isinstance(pix,dict) or not isinstance(level,dict) or fmt not in (6,8,9):
                skips.append(dict(source=d['source'],object_offset=n['offset'],format=fmt,reason='Texture format not exported; original payload retained'));continue
            assert level['size']>=16 and level['size']%16==0
            w,h,offset,size=struct.unpack_from('<4I',data,level['offset'])
            assert 0<w<=16384 and 0<h<=16384 and offset+size<=pix['size']
            b=data[pix['offset']+offset:pix['offset']+offset+size]
            key=hashlib.sha256(struct.pack('<3I',fmt,w,h)+b).hexdigest();dest=out/(key[:24]+'.png')
            if not dest.exists():pixels(b,w,h,fmt).save(dest)
            rows.append(dict(source=d['source'],object_offset=n['offset'],id=p.get('ID'),name=p.get('Name'),width=w,height=h,format=fmt,mip_count=level['size']//16,png=dest.name,source_pixel_sha256=hashlib.sha256(b).hexdigest(),premultiply=p.get('Premultiply','unspecified'),row_order='native; no vertical flip applied'))
    (out/'index.json').write_text(json.dumps(dict(textures=rows,skipped=skips),indent=2))
    print(json.dumps(dict(references=len(rows),unique_pngs=len(list(out.glob('*.png'))),skipped=len(skips))))
if __name__=='__main__':main()
